# AIG IAM Access RPA — Administrator Guide

## Setting up, running and looking after the solution

| | |
|---|---|
| Document | Administrator Guide |
| Product | AIG IAM Access RPA, version 3.0.0 |
| Date | 16 November 2026 |
| Audience | Executives and project leads, business and operations staff, console administrators, support engineers |
| Purpose | To explain what the solution does, how to set up every module in the administration console, how to run it day to day, and what to do when something needs attention |
| Related documents | Application Installation Guide; Administrator Runbook (new with this edition: the commands from installation to daily operation); KT Session Walkthrough; Database Setup Guide; Fujitsu RACF e-mail list |

### What changed in this edition

This edition follows the 12 November 2026 edition. It describes these changes:

- **The bot's Windows session.** While the bot's Windows session is locked, disconnected or shown in a minimized remote desktop window, Windows refuses the bot's keystrokes. The bot now holds new work instead of letting requests fail: requests wait in the queue, the System page says so, and a **Bot Windows session** outage e-mail and a recovery e-mail go to the support team. An error caused by refused keystrokes is explained in plain words in the e-mails and in the console tests.
- **A result that could not be confirmed closes the ticket.** With **Close the ticket when the request failed** On (the default), a request whose result could not be confirmed (**Needs verification**) closes its ServiceNow ticket as Closed Incomplete, with a note, for both applications. No Fujitsu RACF completion ticket is created for it. With the setting Off, the review note is written and the ticket stays open, as before.
- The Fujitsu RACF **Please verify** e-mail now gives the reason, the Employee ID, the job number and where to find the screenshots.
- The code columns of the console lists are named for each application: **Affiliation** and **Employee code** for Fujitsu Mainframe, **RACF group** and **RACF ID** for Fujitsu RACF, and **Group / affiliation** and **User ID** for a list that shows both.
- With the database password from CyberArk, the outage e-mails are separate and worded for what really happened: **Database password** (the new password could not be given to the bot's login; processing continues) and **CyberArk (database password)** (CyberArk did not answer the check). Every database password event is recorded in the audit trail. The **E-mail samples** section lists these e-mails and the Windows session e-mails.
- **Transaction history** shows the current ServiceNow state of each ticket, as the Requests page does.
- Several settings now apply exactly as the console says: the CyberArk address and Application ID for the database password are required while that option is On; a change of the console port needs the bot to be stopped and started again; the OCR switch says when another setting overrides it; **State set on pickup** may be left blank; a change to the handling of refused tickets also applies to refused tickets still open; a change of a recipient list that switches e-mail on or off asks for a restart; a restart is no longer refused during a CyberArk outage when nothing changed; switching off CyberArk for the audit database, or CyberArk for the service-account password, returns to the stored password; **Check password age now** shows its result; the password reset on the server follows the console's minimum password length; the Screen reading and Error handling pages say which settings are for Fujitsu Mainframe only.
- The duplicate e-mail names the **Matching fields** in plain words in both languages (for Fujitsu RACF: Operation and RACF ID; a repeated Access Request ID as **Access Request ID**), and a ticket overtaken by a newer one says "(opposite operation)". A Fujitsu RACF duplicate uses the Fujitsu RACF labels.
- A new e-mail, **Database password changed**, tells the support team and the database team each time the bot starts using a new database password from CyberArk. It is on whenever e-mail is on.
- Every change of the database password is recorded in the audit trail, whichever way the bot found it, and so is every press of **Validate database password**.
- The **Database password** card on the System page says which password the bot uses, when it was changed in CyberArk, and when the last and next checks run. The button is called **Validate database password** everywhere, also in the e-mails.
- A database password problem ends by itself at the next good check, and the recovery e-mail says how it was found. When the database refuses the bot's login although the password in CyberArk did not change, the bot sets the login back to the password in CyberArk and sends the e-mail **Bot's database login set back to the password in CyberArk**.

---

## How to use this guide

You do not need to read every page. Start with the row that fits you.

| If you are… | Read | You will learn |
|---|---|---|
| **An executive or project lead** | Sections 1 and 2, the go-live checklist in section 9.4, and section 12 | What the bot does, what it needs from other teams, how you know it is ready, and how it stays safe |
| **A business or operations user** | Sections 1, 2, 6, 7 and 10 | How a request travels, who is told what, what happens to each ticket, and the everyday tasks |
| **A console administrator (Admin)** | Everything, in order | Every screen, setting, test and check you are responsible for |
| **A support engineer (Developer)** | Everything, with the advanced settings in section 5 and section 11 | The full configuration, the advanced options and troubleshooting |

**How the guide is written**

- Every major section starts with a short **In plain words** box. If you are not technical, the box is usually all you need; the tables below it are the detail.
- **Who does this** names the role or team that carries out the section.
- **Bold text** is exactly what you see on the screen: a page, a button or a setting.
- A path such as **Settings › Fujitsu Mainframe terminal** names a page of the console; **Settings › This machine › Database** names a section under **This machine**.
- In the settings tables, **Who can change it** says `Admin` (an Admin or a Developer can change it) or `Developer` (only a Developer can see and change it).
- **Takes effect** says whether a change applies **at once** or **after a restart** of the service.
- Values in angle brackets, such as `<assignment group>`, are your organisation's own values.
- A box that starts with **Important** marks something that stops the bot or affects security if it is missed.
- Some technical names keep the older product name because they are literal: the folder `C:\FINESIII`, script and file names, setting keys, the database name, the Windows task names and a few on-screen labels.

---

## Contents

**Part A — Understanding the solution**
1. Executive summary
2. How the solution works

**Part B — Access and first-time setup**
3. Roles and access
4. First sign-in and the setup assistant

**Part C — The modules**
5. Setting up each module
   - 5.1 ServiceNow
   - 5.2 E-mail
   - 5.3 CyberArk and the service-account passwords
   - 5.4 The Fujitsu Mainframe terminal
   - 5.5 Processing and the operating window
   - 5.6 Screens and evidence
   - 5.7 Security settings
   - 5.8 This machine
   - 5.9 Fujitsu RACF (optional, switched off by default)
6. Every e-mail at a glance
7. What happens to the ServiceNow ticket
8. Users, branding and error rules

**Part D — Go-live and operations**
9. Checking the installation and going live
10. Day-to-day operations
11. Troubleshooting

**Part E — Reference**
12. Security and compliance
13. Glossary

**Appendices**
- A. Information to collect from each team
- B. Setup record sheet
- C. QA sample values

---

# Part A — Understanding the solution

## 1. Executive summary

> **In plain words.** AIG IAM Access RPA is a software robot ("the bot") that creates and removes user accounts in two mainframe applications: **Fujitsu Mainframe** and, when it is switched on, **Fujitsu RACF**. It takes approved access requests from ServiceNow, does the same keyboard work a person would do on each application's terminal, updates the ticket and tells the right people. Every step is captured as evidence and written to an audit trail.

**What it does.** When an access request is approved in SailPoint, SailPoint creates a catalog task in ServiceNow. The bot collects these tasks at a set interval and checks each one. The application named on the ticket decides where the work is done: Fujitsu Mainframe tickets are carried out on the Fujitsu Mainframe terminal, Fujitsu RACF tickets on the Fujitsu RACF terminal. Both kinds of request wait in **one queue** and the bot handles them one at a time, each inside its own application's working hours. The bot then updates the ServiceNow task and sends the agreed e-mails.

**Why it matters.**
- **Consistency.** Every request is handled the same way, following the approved process.
- **Control.** The bot acts only on approved tickets that pass its checks. Anything unusual is handed back to a person with the reason.
- **Evidence.** Every step is captured as a screenshot, and every action, by the bot or by a person, is written to an audit trail.
- **Independence of the applications.** A problem on Fujitsu RACF (its window closed, its host down, its sign-on ID in use) holds only Fujitsu RACF requests; Fujitsu Mainframe requests keep running.
- **Time.** Staff time moves from repetitive data entry to reviewing the exceptions.

**What it takes to run.**
- One Windows server with the Fujitsu Mainframe terminal program (and the Fujitsu RACF terminal when Fujitsu RACF is used), and two PostgreSQL databases on Amazon RDS. The Application Installation Guide covers this part.
- A one-time setup in the bot's administration console: ServiceNow, e-mail, CyberArk, the Fujitsu Mainframe terminal and, when used, Fujitsu RACF. This guide covers this part.
- Input from other teams: the ServiceNow team, the mail team, the CyberArk team, the Fujitsu Mainframe team, the Fujitsu RACF team (when used), the database team and Information Security (Appendix A).

**How you know it is ready.** The Dashboard shows every health indicator as healthy, and a test ticket for each application in use travels from ServiceNow through that application and back as expected, with its evidence, audit record and e-mails. The go-live checklist in section 9.4 records this formally.

## 2. How the solution works

> **In plain words.** A request starts in SailPoint, becomes a ServiceNow ticket, is checked and queued by the bot, is carried out in Fujitsu Mainframe or Fujitsu RACF during that application's working hours, and ends with the ticket updated and the right people informed. Both applications share one queue. The bot does one request at a time and never repeats a change it has already committed.

### 2.1 The journey of one request

```mermaid
flowchart LR
    A[SailPoint<br/>access request] --> B[ServiceNow<br/>catalog task]
    B -->|every 30 minutes| C[Bot collects<br/>approved tickets]
    C --> D{Ticket checks<br/>pass?}
    D -- No --> E[Reason on the ticket<br/>and e-mail to operations]
    D -- Yes --> F[Assigned to the bot<br/>and queued: one queue<br/>for both applications]
    F -->|Fujitsu Mainframe window open| G[Bot works in Fujitsu Mainframe<br/>screenshot at every step]
    F -->|Fujitsu RACF window open| R[Bot works in Fujitsu RACF<br/>screenshot at every step]
    G --> H[Ticket closed]
    R --> H
    R -.->|optional| K[Completion ticket<br/>in ServiceNow]
    H --> I[E-mails: support report,<br/>user notices, alerts]
    H --> J[Audit trail and<br/>transaction history]
```

1. **Pick-up.** At a set interval (30 minutes by default), the bot asks ServiceNow for approved, open tickets that match its filters: the assignment group and, optionally, the bot account and the Requested For user.
2. **Which application.** The application ID named on the ticket decides the application: by default `[2565]` is Fujitsu Mainframe and `[6582]` is Fujitsu RACF (while Fujitsu RACF is switched on). A ticket for any other application is left alone.
   **Sample (QA):** the ticket text `Policy Management System - Common Process [2565]` (Fujitsu Mainframe) and `Fujitsu RACF (Resource Access Control Facility) [6582]` (Fujitsu RACF).
3. **Checks.** The bot reads each ticket and checks it: the right application, a valid code and account, one direction only (add or remove), and no duplicate of recent work. A ticket that fails a check is not processed; the reason is written on the ticket and the operations team is told.
4. **Queue.** The bot assigns the ticket to itself and queues the work. A Fujitsu Mainframe ticket with several affiliation codes becomes one request per code. A Fujitsu RACF ticket always becomes one request, because a RACF ID is created and removed as a whole (a create names exactly one group).
5. **Processing.** Each application has its own operating window (06:00 to 22:00 Japan time by default for both).
   - **Fujitsu Mainframe:** the bot signs in, opens task 903, enters the details, checks the confirmation screen, commits the change, prints the result and signs off.
   - **Fujitsu RACF:** the bot signs on with its sign-on ID, enters the create command (or, when removals are set to be done by the bot, the removal command), reads the job result and signs off with LOGOFF. By default Fujitsu RACF removals are handed to a person.
   - The bot takes a screenshot at each step.
   - With the real terminals, the bot types through its own Windows session on the server. That session must stay signed in, unlocked and not minimized. While it is locked, disconnected or shown in a minimized remote desktop window, Windows refuses the bot's keystrokes, so the bot starts no new request: requests of both applications wait in the queue and are not counted as failed, the System page says "Requests wait: … Keep the bot's session signed in, unlocked and not minimized; processing resumes by itself.", and the support team receives a **Bot Windows session** outage e-mail. Processing resumes by itself when the session takes keystrokes again, with a recovery e-mail. This check is on by default and is not used with the simulated terminal; only the server administrator can switch it off, with the environment setting `DESKTOP_SESSION_CHECK`.
6. **Close-out.** The bot updates the ServiceNow ticket, sends the agreed e-mails and writes the complete record to the audit trail. By default the ticket is closed as complete on success, and closed as incomplete on failure and when the result could not be confirmed (the "Please verify" e-mail then asks the support team to check the account in the application before anyone raises a new request). For Fujitsu RACF the bot can also create a completion ticket in ServiceNow for the application team after a confirmed success (section 5.9).

**What a request can end as.** Each request on the console carries one status. While it waits or runs: **Queued** or **In progress**. When it has finished (also on the **Transaction history** page):

| Outcome | What it means | ServiceNow ticket, with the shipped settings |
|---|---|---|
| **Completed** | The change was made and confirmed on the screen | Closed Complete |
| **Already removed** | A removal found that the account no longer exists; nothing was changed | Closed Complete, with a note that no change was needed |
| **Needs verification** | The change was sent, but the result could not be read on the screen. It may or may not have been made. It is never retried | Closed Incomplete, with a note that the result could not be confirmed. A person checks the account in the application; the **Please verify** e-mail says what to do |
| **Failed** | Every attempt failed, or the failure needs a person; nothing was changed | Closed Incomplete, with the reason |
| **Cancelled** | An operator cancelled it before it ran, or its ticket was closed or taken over in ServiceNow before it ran; nothing was changed | Cancelled by an operator: stays open, with the cancel note (or as set in section 5.1). Closed or taken over in ServiceNow: nothing is written |

Sections 5.1 and 7 describe the ticket journey in full; section 5.5 describes the processing rules; section 5.9 describes Fujitsu RACF.

**How the console shows the two applications.** While both applications are in use, the lists on **Requests**, **Transaction history** and the **Audit trail** show an **Application** column and filter, and the code columns are named for the application shown: **Affiliation** and **Employee code** for Fujitsu Mainframe, **RACF group** and **RACF ID** for Fujitsu RACF, and **Group / affiliation** and **User ID** while the list shows both. The details of a request or transaction show the ServiceNow ticket with its current **State** and **State checked** (when it was last read from ServiceNow), so the console shows what happened to the ticket after the bot finished.

### 2.2 The parts of the solution

```mermaid
flowchart TB
    subgraph Server["Application server (Windows Server 2022)"]
        S[Bot service<br/>queue, processing, ticket collection]
        C[Administration console<br/>browser on this server]
        V[Windows Credential Manager<br/>passwords and keys]
        T[Fujitsu Mainframe<br/>terminal program]
        T2[Fujitsu RACF terminal<br/>when switched on]
    end
    DB[(Application database<br/>Amazon RDS for PostgreSQL)]
    ADB[(Audit database<br/>Amazon RDS for PostgreSQL)]
    SN[ServiceNow]
    MAIL[Mail server]
    CA[CyberArk]
    MF[Fujitsu Mainframe host]
    RF[Fujitsu RACF host]
    C --- S
    S --- V
    S --- DB
    S --- ADB
    S <--> SN
    S --> MAIL
    S <--> CA
    S --> T --> MF
    S --> T2 --> RF
```

| Part | What it is |
|---|---|
| **Bot service** | The background program that does the work for both applications. It runs as the server's bot account, starts automatically and keeps running when nobody is signed in to the console. With the real terminals it types through the bot account's own Windows session, which must stay signed in, unlocked and not minimized (the unattended operation set-up of the Application Installation Guide and the Administrator Runbook covers this). Sample (QA): bot account `R6-CORE\prvrnel` on the server `qwawosis1001`. |
| **Administration console** | A web page opened in a browser **on the server itself** (reached by remote desktop). Everything is configured and monitored here. It is not published on the network. |
| **Application database** | The queue, the permanent transaction history, the console accounts and the settings. |
| **Audit database** | A separate database for the full audit trail. |
| **Credential store** | Windows Credential Manager of the bot account. Every password kept on the server is here, and is never shown again once saved. |
| **ServiceNow, mail server, CyberArk, Fujitsu Mainframe, Fujitsu RACF** | The outside systems the bot connects to (section 5). CyberArk can supply the service-account passwords and, on Amazon RDS, the database password. |

### 2.3 Where the configuration lives

You never need to edit a file for a normal setup. Everything is on the **Settings** page. Its navigation lists the pages by area:

| Where | What is kept there | Who changes it |
|---|---|---|
| **General (both applications)** | **Processing** (the essential settings of the retry policy, dispatcher and operating window), **Retry policy**, **Dispatcher**, **Operating window**, **Error handling**, **Screen reading**, **Evidence**, **ServiceNow**, **E-mail**, **CyberArk**, **Console sign-in** | Admin (essential settings) and Developer (every setting) |
| **Fujitsu Mainframe** | **Fujitsu Mainframe terminal**, **Fujitsu Mainframe window**, **Fujitsu Mainframe tickets and e-mails**, **Provisioning password** | Admin (essential settings) and Developer (every setting) |
| **Fujitsu RACF** (only while it is switched on) | **Fujitsu RACF terminal and sign-on**, **Fujitsu RACF window**, **Fujitsu RACF tickets and e-mails**, **Fujitsu RACF completion ticket** | Admin (essential settings) and Developer (every setting) |
| **This machine** | How the service starts on this server: **Deployment**, **Database**, **Screen reading (start-up)**, **Security**, **Storage**, **Fujitsu RACF (this machine)**, and **Credentials** (every password and key) | Developer; Admin for the credentials that are renewed in daily operation |
| **History** | **Recent changes**, with **Restore** | Admin and Developer |

An Admin sees the essential settings of the retry policy, the dispatcher and the operating window together on one page, **Processing**. A Developer who switches on **Show all settings** sees each of those pages separately.

**When a change takes effect.**
- ServiceNow settings, most e-mail recipient and wording settings, the support report settings, the Fujitsu RACF ticket, e-mail and completion ticket settings and the password-age settings apply **at once**.
- Other settings apply **after a restart**. The row then shows **Applies after restart** or **Restart needed**, and a banner offers **Restart now**.
- Restart with **Save and restart** on the **Settings** page, **Restart now** on the banner, or **Restart service** on the **System** page. A request in progress always finishes first.
- When the settings of the database password from CyberArk were changed, a restart from the console first applies them. If the password cannot be obtained, the service is not restarted and the console says "Not restarted: …" with the reason (section 5.8). When those settings did not change, a CyberArk outage does not stop the restart.
- A change of the console port (a machine setting) is the exception: it applies only when the bot is stopped and started again, and the row says **Saved — applies when the bot is stopped and started again**. **Restart service** keeps the port in use.
- A Developer first sees the same short list of settings as an Admin. **Show all settings** opens every setting; the browser remembers the choice.

**Badges on a setting.**

| Badge | Meaning |
|---|---|
| **Changed here** | Set in the console, overriding the shipped default |
| **Set by environment** | Set outside the console by the server administrator; it cannot be changed here |
| **Applies after restart** / **Restart needed** | Saved, but not yet in force |
| **Essential** | Shown to a Developer: this setting is also visible to an Admin |
| **Not valid — ignored, enter it again** | A stored value that the product rejects; the shipped default applies until it is corrected |

**Good to know.**
- Clearing a field returns the setting to its default.
- The **i** icon beside each setting explains it in plain language. The search box (**Find a setting…**) finds any setting by name.
- Every change is recorded with who made it and when. **Settings › History › Recent changes** lists them and can **Restore** an earlier value.
- Passwords are write-only. The console shows only whether a password is set.

### 2.4 Test first, then go live

The bot can run against a simulated terminal instead of the real Fujitsu Mainframe terminal (section 5.4), and every e-mail can be redirected to a test address (section 5.2). Do the first-time setup and the end-to-end test this way. Switch to the real terminal and real recipients only after that test succeeds (section 9). With a simulated terminal driver, Fujitsu RACF requests also run against a simulated Fujitsu RACF terminal; with the real terminal, test Fujitsu RACF on its test system (**TSS3**) before production (section 5.9).

The **Service environment** setting decides how strictly the service checks its own configuration:
- **Development** is lenient, for testing.
- **Production** is strict: the machine API key is required, and CyberArk is required with the real terminal. The service refuses to start, or refuses to process, until these conditions are met (section 5.8).

---

# Part B — Access and first-time setup

## 3. Roles and access

> **In plain words.** Everyone who uses the console signs in with their own account, and each account has one role. The role decides which pages a person sees and which buttons they can press. Four roles come with the product: Viewer, Operator, Admin and Developer. You can also build your own roles from a fixed list of permissions.

**Who does this:** Developer (accounts, roles and permissions); Admin (accounts, when the Users page is given to the Admins).

### 3.1 The four built-in roles

| Role | What it can do | Who should hold it |
|---|---|---|
| **Viewer** | Sees the Dashboard, Reports, Requests, Transaction history, Evidence and the Audit trail. Sees the essential settings, read only. Changes nothing. | Auditors, business staff and managers who follow the work. |
| **Operator** | Everything a Viewer can do, plus **Cancel** on queued requests (one at a time or with **Cancel the queued requests shown**). | The operations staff who watch the queue every day. |
| **Admin** | Runs the bot day to day: everything an Operator can do, plus the essential settings, the credentials that are renewed in daily operation, and the System page (pause, restart, stop, tests, **Validate database password**, logs, diagnostics, the e-mail outbox). The Users page only when **Users page for Administrators** is switched on (see below). | Two or more named people in the business or IT team who own the service. |
| **Developer** | Full control: every setting, the machine settings, **New request** and **Retry**, Branding, Roles & permissions, the Error rules page, the configuration files, the Users page and the Developer-only tests (for example the service-account password change on Task 0890 and the test completion ticket). | The support team that installs and maintains the solution. |

The built-in roles are part of the release. They cannot be edited, renamed or deleted, and their permission lists are restored at every start of the service. The header of the console shows your name and your role, for example **<your name> · Admin**.

**Why New request and Retry are for the Developer.** Requests come from ServiceNow with their approval. A ServiceNow request that failed has its ticket closed as incomplete, and the requester raises a new ticket. **New request** (a request typed on the console) and **Retry** are kept for testing and support, so they belong to the Developer role.

**The Users page.** By default the Users page (console accounts, signed-in sessions and **Export users**) is for the Developer only. A Developer can give it to the Admins as well with **Users page for Administrators** on **Settings › Console sign-in**; this applies at once. While no active Developer account exists, the Admins keep the Users page, so that the console accounts can always be managed. The System page then says so: "The Users page is still shown to Administrators: no active Developer account exists. Create a Developer account to keep the Users page for the Developer only."

**What Admin does not see.** The Admin role holds every permission except five: changing every setting (the advanced options), defining roles, switching error rules on or off, submitting a new request on the console and retrying a failed request. The two account permissions are added only as described above. In practice an Admin does not see:

- the advanced settings (only the essential ones are listed, and a save of any other option is refused with the message "'…' is managed by the Developer role; its current value stays in force. Nothing was saved.");
- the machine settings under **This machine**, except **Credentials**;
- the **Branding**, **Roles & permissions** and **Error rules** pages, and the **Users** page unless it was given to the Admins;
- the **Configuration files** section of the System page;
- **New request**, **Retry** and **Retry the failed requests shown** on the Requests page;
- **Discover fields** on the ServiceNow page, and **Restart service**, **Run setup again** and **Export configuration** on the Settings page (an Admin restarts with **Save and restart**, or **Restart service** on the System page);
- the Developer-only tests: **Test password screen**, **Change service-account password** and **Check password age now** (Fujitsu Mainframe), **Test completion ticket** (Fujitsu RACF), **Test CyberArk retrieval** and **Create from Windows certificates** (database password from CyberArk);
- the Database and Screen reading items of the setup checklist.

An Admin who manages accounts also cannot create, change, reset, unlock, end a session of or delete a Developer account (see 3.3).

> **Tip.** A Developer first sees the Settings page as an Admin sees it, with the note "These are the essential settings, as an administrator sees them. Switch on "Show all settings" to see and change every option." Switch on **Show all settings** to see and change every option; the choice is remembered in that browser. With it switched on, each option an Admin can see carries the badge **Essential**.

### 3.2 Custom roles

A Developer creates custom roles on **Roles & permissions** with **New role**. Use a custom role when a team needs less than a built-in role gives, for example "reads the queue but must not open screenshots".

- **Role name**: 2 to 40 characters, letters a-z, digits, `_` and `-` (no spaces or `/`). The name cannot be changed later.
- **Description**: up to 200 characters.
- **Permissions**: tick at least one.
- A role that is still held by an account cannot be deleted. Move the accounts to another role first.
- A change to a custom role applies to its holders at their next action. Their menu is built at sign-in, so ask them to sign out and in again to see the pages that changed.
- **Users page for Administrators** applies only to the built-in Admin role. A custom role that holds `users.view` or `users.manage` keeps it.

**You cannot hand out permissions you do not hold.** Nobody can create, edit or delete a role that grants a permission they do not hold themselves, and nobody can give an account a role that grants more than their own. The service refuses the attempt ("You cannot create a role with permissions you do not hold yourself") and records it in the audit trail.

### 3.3 The permissions

| Permission | What it allows | Built-in roles that hold it |
|---|---|---|
| `dashboard.view` | See the dashboard and system health | All four |
| `requests.view` | See queued requests and transaction history | All four |
| `audit.view` | Read the audit trail | All four |
| `requests.submit` | Submit new provisioning requests (**New request**) | Developer |
| `requests.retry` | Retry a failed request | Developer |
| `requests.cancel` | Cancel a queued request | Operator, Admin, Developer |
| `evidence.view` | Open evidence screenshots and their screen text | All four |
| `rules.view` | See the screen-error catalogue | All four (the page itself is shown to Developer only) |
| `rules.edit` | Switch error rules on or off | Developer |
| `users.view` | See console accounts and their roles (read only), and export them for access reviews | Developer; Admin when **Users page for Administrators** is on, or while no active Developer exists |
| `users.manage` | Create, edit and remove console accounts | Developer; Admin as for `users.view` |
| `roles.manage` | Define roles and assign their permissions | Developer |
| `settings.view` | See the configuration | All four |
| `settings.edit` | Change the configuration and restart the service | Admin, Developer |
| `settings.advanced` | See and change every setting: advanced options, machine settings, branding and configuration files. Also the Developer-only tests and buttons named in 3.1. | Developer |
| `system.view` | See service status, logs and the System page | Admin, Developer |
| `system.manage` | Change credentials; pause, resume or stop processing; run the tests, the self-test and diagnostics; validate the database password; manage the e-mail outbox; mark the setup complete | Admin, Developer |

> **Important.** `evidence.view` opens the screenshots of every step. They show personal data from the mainframe screens. Give it only to people who need to check what the bot did.

### 3.4 Protections for the last administrator

The console always keeps someone who can manage it:

- You cannot deactivate or delete the account you are signed in with, and you cannot change your own role on the Users page.
- The last active account holding Admin or Developer cannot be demoted, deactivated or deleted: "This is the last active administrator — promote another account first".
- The last active Developer account is protected in the same way: "This is the last active developer account — promote another account first".
- If no active Developer exists when the service starts but an active Admin does, the service gives one Admin the Developer role (the account named `admin` when it is one, otherwise the oldest). This is recorded in the audit trail and the service log.

> **Tip.** Before returning to an earlier application release that has no Developer role, your support team must first give the Developer accounts the Admin role with the tool supplied for that purpose, while the service is stopped. Otherwise those accounts cannot use the console on that release.

### 3.5 What happens to someone who is signed in

| Change made by an administrator | Effect on that person |
|---|---|
| Role changed | All their sessions end at once. Their window returns to the sign-in page within about 30 seconds ("Your session was ended. Sign in again."). They sign in again with the new role. |
| Account deactivated | All their sessions end at once. They cannot sign in until the account is activated again. |
| Password reset | All their sessions end and any lock is lifted. At the next sign-in they must choose their own password. |
| Account deleted | All their sessions end. |
| One session ended (Users › **Active sessions** › **End session**) | That one window is signed out. They can sign in again. |
| Custom role edited | The new permissions apply at their next action; the menu updates at their next sign-in. |
| **Users page for Administrators** switched on or off | The Admins gain or lose the account permissions at their next action; the menu updates at their next sign-in. |

### 3.6 Recommended set-up for an enterprise

1. **Least privilege.** Give each person the smallest role that lets them do their job. Most people need Viewer or Operator.
2. **Two named Admins.** Keep at least two active Admin accounts held by named people, so the service never depends on one person's holiday or departure.
3. **Developer for the support team only.** Keep the Developer role for the people who maintain the solution, again at least two of them. The Admin role is enough to run the bot.
4. **Decide who manages accounts.** Leave **Users page for Administrators** off if only the support team should create and change console accounts; switch it on if the business Admins manage them.
5. **One account per person.** Never share an account. Every change and every cancel or retry is recorded under the name of the account that made it. Once the named accounts exist, deactivate the installation account `admin` (it holds the Developer role).
6. **Regular access reviews.** Every quarter, select **Export users** on the Users page. The file lists every account with its role, the permissions of that role, whether it is active and its last sign-in. Deactivate every account that nobody needs. A custom role with only `users.view` lets a reviewer read the list and export it without changing anything.

## 4. First sign-in and the setup assistant

> **In plain words.** The first person to sign in uses a one-time password and is asked at once to choose their own. The console then offers a short setup assistant that walks through ServiceNow, e-mail, CyberArk, the Fujitsu Mainframe terminal and, while it is switched on, Fujitsu RACF. Anything you skip can be finished later.

**Who does this:** Admin or Developer (first sign-in and setup), Server team (password reset on the server).

### 4.1 First sign-in

The database setup script prepares the first console account, `admin`, on a fresh installation. By default it generates a one-time password of four groups of four letters and digits (for example `Kx7q-Pm3d-Ty8w-Rn2a`). It shows this password once on the screen, never in its report or log, and keeps it in the server's credential store until it is used. The script can also ask for a password to be typed instead, or set none.

The published default password `ChangeMe!2026` applies only when the database setup script did not set a one-time password: when no credential store was available for the account, when storing the password failed, or when the script was told not to set one. In that case sign in at once and change it.

1. Open the console and enter **Username** `admin` and the one-time password. Select **Sign in**.
2. The page **Choose a new password** opens with the text "Your password was set by an administrator. Please choose your own before you continue." Enter **Current password**, **New password** and **Confirm the new password**, then select **Set password**.
3. The console signs you in with the new password. The one-time password is then removed from the credential store.

The `admin` account holds the **Developer** role. Use it to create the named accounts (see 8.1), then deactivate it.

> **Important.** Until `admin` has chosen its own password, the System page shows a warning that anyone who knows the initial password can take over the account. When the initial password is the published default, the warning says so.

**When no account exists at all**, the console opens **First-time setup** ("No console accounts exist yet. Create the first administrator."). Enter **Administrator username**, **Display name**, the **Password** twice, and select **Create administrator**. This account also holds the Developer role and is not asked to change its password. The screen is refused once any account exists.

### 4.2 Forced password change

Every password set by someone else is provisional. The person must choose their own at the next sign-in, and until they do the console refuses every other action. This applies to the first `admin` account, to every account created on the Users page, to every password reset by an administrator or on the server, and to a password that has expired.

### 4.3 Password rules

A console password must:

- be at least 12 characters long;
- contain at least one letter and one digit;
- not contain the username (in any mix of capitals);
- differ from the current password;
- not be one of the last 5 passwords of the account.

Passwords do not expire unless a Developer sets an expiry. The password is stored only as a one-way hash.

These rules are for console accounts only. The service-account passwords of Fujitsu Mainframe and Fujitsu RACF follow the host's own rules (section 5.3).

### 4.4 Sign-in time-outs

- **Inactivity.** The console signs you out after 30 minutes without activity (keyboard, mouse or touch). The automatic refresh of the Dashboard does not count as activity.
- **"Still there?"** One minute before the limit a box appears: "The console has not been used for 29 minutes. You will be signed out in 60 seconds." Select **Stay signed in** to carry on, or **Sign out**.
- **After the limit** the sign-in page says "You were signed out after 30 minutes without activity."
- **Maximum session length.** However active you are, a session ends 12 hours after sign-in: "The session reached its maximum length of 12 hour(s) — sign in again".
- **Several tabs.** The tabs of one console share your activity. Signing out in one tab signs out the others: "You were signed out in another window of this console."
- A session survives a page reload and a restart of the service. It ends when the browser is closed.

### 4.5 Lockout

After 5 wrong passwords in a row the account is locked for 15 minutes.

- **What the user sees.** Always "Invalid username or password", also while the account is locked. The console never says that an account exists or is locked, so that nobody can guess account names.
- **A short wait after each failure.** After a wrong password, the next attempt for that username must wait a few seconds (2, 4, 8, 16, then 30 seconds at most): "Too many failed sign-in attempts. Wait N second(s) and try again."
- **What the administrators see.** The Users page shows **Locked until** with the time in the **Active** column, and an **Unlock** button. By default the administrators also receive an e-mail alert: "Console account '...' was locked after 5 failed sign-in attempts ... An administrator can unlock it on the Users page."
- When the lock ends, the count starts again from zero.

### 4.6 Change your own password

Select **Change password** in the header. Enter the current password and the new one twice, then **Set password**. Every session of your account ends and the window signs in again with the new password.

### 4.7 A lost password

- **Someone else can still sign in.** A person who has the Users page (a Developer, or an Admin when the Users page is given to the Admins) opens **Users**, selects **Edit** on the account, and uses **Reset the password** (see 8.1). An Admin cannot reset a Developer's password.
- **Nobody can sign in** (for example the only administrator forgot the password or is locked out). The server team resets it on the server, signed in as the account that runs the service, from the application folder:

```
.\.venv\Scripts\python.exe desktop\app.py --reset-console-password <username>
```

Type the new password twice when asked (it is not shown). It must have the minimum length, a letter and a digit. The password is provisional, the account is unlocked and activated, and its open sessions end. The reset is written to the service log and the audit trail.

### 4.8 Sign-in settings

These settings are on **Settings › Console sign-in** and **Settings › This machine › Security**.

| Setting | What it means | Default | Who can change it | Takes effect |
|---|---|---|---|---|
| **Sign out after inactivity (s)** | Time without activity before the console signs out (300 to 86400). | 1800 (30 minutes) | Developer | After a restart |
| **Maximum session length (hours)** | A session ends this long after sign-in, however active (1 to 24). | 12 | Developer | After a restart |
| **Minimum password length** | Shortest console password accepted (8 to 64). | 12 | Developer | After a restart |
| **Failed sign-ins before lockout** | Wrong passwords in a row before the account is locked (3 to 20). | 5 | Developer | After a restart |
| **Lockout duration (s)** | How long a locked account stays locked (60 to 86400). | 900 (15 minutes) | Developer | After a restart |
| **Allow Windows sign-on** | Shows **Sign in with your Windows account** on the sign-in page. Works only on the server itself. | Off | Developer | After a restart |
| **Users page for Administrators** | Off: the Users page is for the Developer only. On: the Admins also see and manage console accounts. While no active Developer exists, the Admins keep the Users page. | Off | Developer | At once |
| **Passwords remembered** | A new password may not be one of this many earlier ones (0 to 24). | 5 | Developer | After a restart of the service |
| **Password expiry (days)** | 0 = never. Otherwise a password older than this must be changed at the next sign-in (0 to 365). | 0 | Developer | After a restart of the service |
| **E-mail when an account is locked** | Sends an e-mail alert to the administrators when an account is locked. | On | Developer | After a restart of the service |

### 4.9 The setup checklist on the Dashboard

Until the setup is marked complete, Admins and Developers see a checklist at the top of the Dashboard: "Please finish setting up this installation. Each item can be changed later under Settings or System." Each item is marked **Done**, **To do** or **Not needed**.

| Item | Done when |
|---|---|
| **ServiceNow** | Ticket collection is on and the instance address, the account and its password or secret are set. Optional if requests arrive only through the service interface. |
| **Database** (Developer only) | The database is PostgreSQL, as expected for a shared or production installation. |
| **Mainframe service account / CyberArk** | The Fujitsu Mainframe service-account password is in the credential store, or CyberArk is in force (after a restart). **Not needed** with the simulated terminal. |
| **Screen reading** (Developer only) | Screen reading is on. Required with the real terminal. |
| **E-mail** | E-mail alerts are on. Optional. |

Select **Open Settings** to work on an item, or **Mark setup complete** to remove the checklist. If a module is switched on but not fully set up (ServiceNow, E-mail, CyberArk or the Fujitsu Mainframe terminal), the console names it and asks you to confirm first. Marking the setup complete is recorded in the audit trail.

The checklist does not cover Fujitsu RACF. When Fujitsu RACF is used, complete it with section 5.9 and its three tests before you mark the setup complete.

### 4.10 The setup assistant

The assistant **Set up the modules** opens by itself after sign-in for an Admin or Developer while the setup is not complete. It has these steps, shown as buttons at the top: **1. ServiceNow**, **2. Email (SMTP)**, **3. CyberArk**, **4. Fujitsu Mainframe target** and **5. Summary**. While Fujitsu RACF is switched on, **5. Fujitsu RACF target** is added and the summary becomes **6. Summary**. Select any step button to go straight to that page.

Each page shows the same settings as the Settings page and saves to the same place. Nothing in the assistant is stored separately.

| Control | What it does |
|---|---|
| **Save & continue** | Saves what you changed on the page, including any credentials you typed, and moves on. It reports "Saved N setting(s).", or "Nothing was changed on that page — kept as configured." for a module already set up, or "Nothing was entered on that page — it counts as skipped." |
| **Skip for now** | Moves on without saving. |
| **Back** | Returns to the previous page. Unsaved typing on the open page is lost. |
| **Close** | Closes the assistant. It is remembered for your account, so it does not open again at your next sign-in. |

**Test buttons on each page:**

- **ServiceNow**: **Test connection**, **Preview tickets** and, for a Developer, **Discover fields**. Save the page before you preview or discover.
- **Email (SMTP)**: a box for a test address (empty means the **Default recipients**) and **Send test email**.
- **CyberArk**: **Test retrieval**.
- **Fujitsu Mainframe target**: **Test mainframe host**, **Test terminal launch** and **Test sign-in and navigation**. The last one signs in to Fujitsu Mainframe with the service account. It asks for confirmation and needs processing paused on the System page. This page also has **Password source**: **Stored here (OS credential vault)** or **Fetched from CyberArk** (CyberArk must be enabled first).
- **Fujitsu RACF target** (while Fujitsu RACF is on): the Fujitsu RACF terminal, system, sign-on ID and its password, window and team, with **Test Fujitsu RACF host**, **Test Fujitsu RACF terminal launch** and **Test Fujitsu RACF sign-on** (section 5.9).
  **Sample (QA):** terminal shortcut `C:\ProgramData\Fujitsu\WSMGR\接続1.emd` (terminal program left empty; terminal started as administrator On), system `TSS3`, sign-on ID `SAILPNT`, window title `接続1 - DSPEMU`.

**Summary.** The page lists each module as it is set up at that moment: **set up**, **off** or **incomplete** (for the Fujitsu Mainframe and Fujitsu RACF targets: **saved** or **as is**), with notes such as "Saved in this run.", "Test passed." or "Not tested in this run.". **Restart service now** is always offered, because settings that take effect after a restart need one.

**Finish** marks the setup complete only when something was saved in this run or a module is already on and set up, and no switched-on module is incomplete. If a module is incomplete, the assistant asks "... is switched on but not fully set up. Close the assistant anyway? The setup stays open on the Dashboard." and the checklist stays.

**Run setup again** on the Settings page opens the assistant again. It is a Developer's button.

**Admin compared with Developer.** An Admin sees only the essential options on each page. The Fujitsu Mainframe target page shows the terminal launcher options and the service account credentials, but not the machine settings (deployment and screen reading) and not the operating window, which an Admin changes on **Settings › Processing**. **Discover fields** is not shown. Once an Admin closes the assistant, it opens again only when a Developer selects **Run setup again**; the Admin can finish the same work on the Settings page.

---

# Part C — The modules

## 5. Setting up each module

> **In plain words.** The bot connects to outside systems (ServiceNow, the mail server, CyberArk, the Fujitsu Mainframe terminal and, when it is switched on, the Fujitsu RACF terminal) and follows a few processing rules. Each module below explains what it does, the settings that control it, how to test it, and what happens in everyday situations.

**Who does this:** Admin for the essential settings; Developer for the advanced settings and **This machine**.

**How the Settings page is arranged.** The navigation on the left of **Settings** groups the pages by application, then by machine:

| Heading in the navigation | Pages |
|---|---|
| **General (both applications)** | **Processing** (the essential settings of Retry policy, Dispatcher and Operating window on one page, as an Admin sees them), **Retry policy**, **Dispatcher**, **Operating window**, **Error handling**, **Screen reading**, **Evidence**, **ServiceNow**, **E-mail**, **CyberArk**, **Console sign-in** |
| **Fujitsu Mainframe** | **Fujitsu Mainframe terminal**, **Fujitsu Mainframe window**, **Fujitsu Mainframe tickets and e-mails**, **Provisioning password** |
| **Fujitsu RACF** (only while Fujitsu RACF is switched on) | **Fujitsu RACF terminal and sign-on**, **Fujitsu RACF window**, **Fujitsu RACF tickets and e-mails**, **Fujitsu RACF completion ticket** |
| **This machine** (Developer) | **Deployment**, **Database**, **Screen reading (start-up)**, **Security**, **Storage**, **Fujitsu RACF (this machine)**, **Credentials** |
| **History** | **Recent changes**, with **Restore** |

An Admin sees only the essential settings of each page; every other option keeps its value and is managed by the Developer role. A Developer sees the same short view until **Show all settings** is switched on. **Find a setting** above the navigation searches every page. In this guide a page is written as **Settings › <page>**, for example **Settings › E-mail** or **Settings › Fujitsu Mainframe tickets and e-mails**.

Work through the modules in this order the first time: ServiceNow, E-mail, CyberArk, the Fujitsu Mainframe terminal, and Fujitsu RACF when it is used. The setup assistant (section 4) follows the same order for the first four. Most pages have a **Tests** row; use it before moving on.

Every module section uses the same layout:
- **In plain words** — what the module is for.
- **Settings** — every setting, its default, who can change it and when a change takes effect.
- **Test buttons** — how to prove the module works without waiting for a real ticket.
- **Common situations** — what the bot does in everyday cases, who is told, and which setting decides.

## 5.1 ServiceNow

> **In plain words.** Access to Fujitsu Mainframe (and to Fujitsu RACF, when it is switched on) is requested in SailPoint, and SailPoint raises each approved request as a task in ServiceNow. The bot collects these tasks at a regular interval, checks that each one is complete and meant for it, makes the change in the application and then writes the result back to the task. A task the bot cannot handle is left for a person, with the reason written on it.

**Who does this:** Admin (day-to-day settings), Developer (advanced settings), ServiceNow team (bot account, rights and groups).

The ServiceNow settings are on **Settings › ServiceNow**. The settings that decide which tickets belong to each application are on **Settings › Fujitsu Mainframe tickets and e-mails** (**Accepted application IDs**, **Affiliation attribute names**) and **Settings › Fujitsu RACF tickets and e-mails**. Every one of these settings takes effect at once: saving the page starts a poll straight away, so you do not need to restart the service.

A change to how refused tickets are handled (**Close the ticket when the bot does not process it**, **Work note on a ticket the bot rejects (ticket stays open)**, **Rejection note text**, **Hand rejected tickets to group**, **Add a work note when a ticket is queued or found to be a duplicate** or **Closing state value (failed)**) also applies to the refused tickets that are still open. At the next poll the bot handles each of them once more with the new settings (it closes, notes or hands them over as now set) and reports the refusal again.

### What it does

The ServiceNow module does four things:

1. **Collects** the open tasks that match your filters, oldest first, every **Poll interval (minutes)**.
2. **Checks** each task: is it for Fujitsu Mainframe or Fujitsu RACF, is the instruction complete, has the same thing been asked before?
3. **Queues** one request for each affiliation code on the task, after making sure the task is assigned to the bot in ServiceNow.
4. **Reports back**: when every code of the task has finished, the bot writes the outcome to the task once, and closes it or leaves it open, depending on the outcome and your settings.

What it never does:

- It never writes to a task unless ServiceNow first confirms that the task is still active and assigned to the bot account.
- It never reopens a closed task.
- It never reads a password from a task and never writes one to a task. The initial password of a new account is generated by the service.
- It never runs a task it does not understand. A task that fails a check is not queued.

### How a ticket travels

1. **SailPoint raises the task.** An approved SailPoint access request becomes a catalog task (number starting `SCTASK`) in ServiceNow, usually in a fixed assignment group. The instruction text and the account sit in the catalog variables of the requested item.
2. **The bot polls.** Every **Poll interval (minutes)** (default 30), and at once after you save a ServiceNow setting or press **Check ServiceNow now** on the **System** page, the bot asks ServiceNow for its open tasks.
3. **The filters decide which tasks are read.** Only active tasks are ever read. Each filter below is optional. A filled-in filter is applied; a **blank** filter adds no condition at all.
   - **Assignment group**: only tasks of this group.
     **Sample (QA):** `Policy Management System - Common Process-2565-JPN` (one group for the tickets of both applications).
   - **Bot account** with **Match tickets by**: `assigned_to` reads only tasks assigned to the bot account; `assignment_group` reads tasks that are unassigned or assigned to the bot account. Tasks a person has taken are never read in this mode. Blank **Bot account**: no condition on who the task is assigned to.
   - **Only approved requests**: only tasks whose requested item is approved.
   - **Open states**: only these state values. Blank: every task ServiceNow still treats as active.
   - **Requested For**: only tasks requested for these users. The bot checks this, and the group, again on every task it receives, so a task outside them is never touched.
   - **Pick up new tickets in states**: a task the bot does not hold yet is taken only in one of these states. Blank: any state. Tasks the bot already holds are still read, so that their outcome can still be written.
4. **Tasks the bot already knows are skipped.** A task for which a request exists, in any status, is not queued again. If its requests have finished but the outcome was not yet written, the bot writes it at this point.
5. **The bot reads the task.** It reads the catalog variables. If the instruction text is not in the variables (empty, or the bot account may not read their values), the bot looks for it in the fields of the task, then of the requested item, then of the request. Only a text with an instruction line counts: an `AttributeName=…; Value=…; Operation=…` group or a `code | name` line.
6. **The application is checked.** The task must name one of the **Accepted application IDs** (default `[2565]`) in the application variable, the task description or the instruction text. A task for another application is skipped silently: nothing is written to it and nobody is e-mailed. When Fujitsu RACF is switched on, tasks that name one of the **Fujitsu RACF application IDs** (default `[6582]`) are Fujitsu RACF tickets, with their own rules (see *Fujitsu RACF tickets* below). A task naming both applications is refused and left for manual handling.
   **Sample (QA):** **Accepted application IDs** `2565` (ticket text `Policy Management System - Common Process [2565]`); **Fujitsu RACF application IDs** `6582` (ticket text `Fujitsu RACF (Resource Access Control Facility) [6582]`).
7. **The checks run.** See *The checks on each ticket* below. A task that fails is not queued, and the reason is written to it.
8. **One request per affiliation code.** Every entitlement on the task is taken, whether the `AttributeName` groups are on one line separated by `;` or on several lines. A task with one code keeps its number; a task with several codes becomes `SCTASK…/1`, `SCTASK…/2` and so on. The same code twice with the same operation counts once. A code with fewer than five digits is filled with leading zeros.
9. **Duplicates and newer opposite tasks are held.** Three rules protect the application from doing a step twice or undoing a later decision:
   - **Same request**: the same operation, affiliation code and account as a request that is queued, running, completed or found already removed, within **Duplicate check window (days)** (default 30; `0` switches this rule off). If an opposite operation ran after that request (for example Add, then Remove, then Add again), the task is treated as fresh work. A task with several codes is not held by this rule alone.
   - **Same Access Request ID**: another task with the same SailPoint Access Request ID **and** the same affiliation code and account is held, whatever its age. Tasks of one access request that carry different affiliation codes are not repeats of each other, so each of them is processed.
   - **Newer task wins**: a task is held when a task for the opposite operation, on the same account and affiliation code, was created later in ServiceNow. An older removal never undoes a later registration, and the other way round.
   A failed or cancelled request never holds a later task.
   The "Request rejected (Duplicate request)" e-mail names the earlier task and the **Matching fields** in plain words, in the e-mail language: for Fujitsu Mainframe **Operation**, **Affiliation code** and **FFM Application ID / Employee code**; for Fujitsu RACF **Operation** and **RACF ID** (the group never decides a match); **Access Request ID** when the same Access Request ID was found. A task overtaken by a newer one shows the codes followed by "(opposite operation)". The ServiceNow field names that were identical are recorded only in the audit trail.
10. **The per-poll limit applies.** At most **New requests queued per poll (one per code)** requests (default 25) are queued by one poll. The codes of one task are always queued together; the other tasks wait for the next poll, and the **System** page shows how many are waiting.
11. **The task is assigned to the bot before it is queued.** With **Match tickets by** set to `assignment_group`, or with **Bot account** blank, the bot reads the task again, assigns it to the bot account (or to the ServiceNow **Username** when **Bot account** is blank) and confirms that ServiceNow kept the assignment. A task a person took in the meantime, or that was closed, is left alone. A task that cannot be assigned is not queued and is tried again at the next poll.
12. **The request is queued.** The service checks each request once more as it is received. If the service refuses it, the reason is written to the task like any refusal. A task that was assigned to the bot only for this goes to the hand-over group, or is closed, or otherwise goes back to its group, unassigned, in its earlier state.
13. **The task is claimed.** With **Claim the task on pickup (assign to the bot, set the state below)** switched on (default), the task is assigned to the bot and moved to **State set on pickup** (default `2`, Work in Progress). With **State set on pickup** emptied, the task is only assigned to the bot and its state is not changed. With **Add a work note when a ticket is queued or found to be a duplicate** switched on, the note "Queued to AIG IAM Access RPA bot (ticket …)." is added.
14. **Re-check just before the bot runs it.** Requests run one after another in queue order. Just before a request reaches the terminal, the bot checks three things: that no newer opposite task has run meanwhile, that the task still exists and is still active, and that it is still assigned to the bot. If any check fails, the request is cancelled and nothing is changed in the application. If ServiceNow cannot be reached at that moment, the request runs (the task was checked at pick-up) and the skipped check is recorded in the audit trail.
15. **The change is made in the application.** A failure that has no Fujitsu Mainframe result code is given a code that starts with `BOT:` (for example `BOT:LOGIN_FAILED`), so nobody mistakes it for a Fujitsu Mainframe code. A ticket text can show it with the placeholder `{result_code}`.
16. **The outcome is written once.** When the last code of the task has finished, ServiceNow must confirm that the task is still active and assigned to the bot. The bot then writes the outcome, as described in section 7.
17. **The console stays current.** On every poll the bot reads again the state of the open tasks of recent requests (the last 14 days). The details of the request on **Requests**, and of the transaction on **Transaction history**, show the task's current **State** and **State checked**, the time it was last read. The bot's own closing of a task updates them at once.

```mermaid
flowchart TD
    A[SailPoint raises the task in ServiceNow] --> B[Poll: open tasks inside the filters]
    B --> C{Known to the bot?}
    C -- yes --> C1[Skip; write any outcome still missing]
    C -- no --> D{For this application<br/>and in a pick-up state?}
    D -- no --> D1[Skip silently]
    D -- yes --> E{Checks passed?}
    E -- no --> E1[Note, hand-over or close; e-mail]
    E -- yes --> F{Duplicate or<br/>overtaken?}
    F -- yes --> E1
    F -- no --> G[Assign to the bot, queue one request per code]
    G --> H{Still open and the bot's<br/>just before it runs?}
    H -- no --> H1[Cancelled; nothing changed]
    H -- yes --> I[Change made in the application]
    I --> J[Outcome written once to the task]
```

> **Important.** If **Assignment group**, **Bot account** and **Requested For** are all blank, the bot reads every open task in the ticket table. Set at least the group in production. **Test connection** warns you about this.

### The checks on each ticket

**Ticket checks** decides how strict the checks are:

| Level | Use it for | What happens |
|---|---|---|
| `strict` (default) | Production | Every check in the table below. |
| `minimal` | Testing | Only what a run needs: the application, the instruction, the attribute, a known operation, the affiliation code, the account and one direction. The instance, the account variable, the account lines, the Request Type and the removal-only rule are not checked. |
| `none` | Testing only | A task that fails a check is queued anyway as an "Unchecked (testing)" request, which is cancelled before it reaches the terminal. The task is not assigned to the bot; it receives the refusal once, like a refused task. No "Request rejected" e-mail is sent. Never use this in production. |

**Ticket checks** applies to Fujitsu RACF tickets in the same way: `minimal` leaves out the instance, the account variable, the account lines, the Request Type and the removal-only rule; with `none`, a Fujitsu RACF ticket that fails a check (including a removal left for a person) is queued unchecked and cancelled before the terminal.

The reasons a task is not processed (the text in quotes is what the bot writes, after "Not processed by the AIG IAM Access RPA bot:"):

| Reason, in plain words | Written to the task | Checked in `minimal` |
|---|---|---|
| The catalog variables of the requested item could not be read, and no instruction text was found anywhere else | "the catalog variables of the requested item could not be read" | Yes |
| The Instance named on the task is not one of the **Accepted instances** | "instance '…' is not accepted on this server (accepted: …)" | No |
| There is no instruction text | "the instruction text (Description / Work notes) is empty" | Yes |
| The text has no `AttributeName` line and no `code \| name` line | "no provisioning or removal instruction was found in the ticket text" | Yes |
| A certification, transfer or termination lists no affiliation code | "no entitlement (affiliation code) was found in the … ticket" | Yes |
| The attribute is not one of the **Affiliation attribute names** | "attribute '…' is not supported by the bot" | Yes |
| The operation word is in none of the word lists | "unknown operation '…'" | Yes |
| The affiliation code is not five digits | "the affiliation code '…' is not a 5-digit code" | Yes |
| The task both adds and removes codes | "the ticket both adds and removes affiliation codes; it is left for manual handling" | Yes |
| A removal-only type (certification, transfer, termination) asks to add | "a … can only remove access, but the ticket asks to '…'" | No |
| The account variable named in **Variable: account** is not on the task | "the account variable (…) was not found on the ticket — check the 'Variable: account' setting" | No |
| The account in the text and the account variable disagree | "the account in the text (…) differs from the Account Name variable (…)" | No |
| An `Account name:` line names a different account | "… differs from the Account Name line (…)" | No |
| The text names two different accounts | "the ticket text names more than one account (…)" | Yes |
| No account at all | "the account name is missing" | Yes |
| The account is not seven half-width letters or digits | "the account '…' is not 7 characters" or "… must be 7 half-width letters or digits" | Yes |
| The Request Type says the opposite of the text | "Request Type '…' contradicts the operation in the text (…)" | No |
| The task names both Fujitsu Mainframe and Fujitsu RACF (Fujitsu RACF switched on) | "the ticket names both the Fujitsu Mainframe and the Fujitsu RACF application; it is left for manual handling" | Yes |
| The service refused the request as it was received | "the request was refused by the intake check (…)" | Yes |

For reference, these are the two text forms the bot understands. An Add or Remove task:

```
Access Request ID ... for tracking purpose is: <access request ID>
Please provision/deprovision the below attributes for account: <7-character staff code>
AttributeName=所属コード; Value=<5-digit affiliation code> | <department name>; Operation=Add
```

A certification task (one line per code, the account on a line of its own):

```
Certification: ... please revoke the below user entitlements ...
Name: <family name>, <given name>
<5-digit affiliation code> | <department name>  Revoker: <reviewer>
<5-digit affiliation code> | <department name>  Revoker: <reviewer>
Account name: <7-character staff code>
```

Full-width characters (for example `；`, `＝`, `｜` or full-width digits) are read as their half-width forms.

The account is taken from the account variable; otherwise from the phrase `for account:` in the text; otherwise from an `Account name:` line of its own, which is how certification tasks carry it. The detail lines `Request Type:`, `Account Name:`, `Employee ID:`, `Employee Name:`, `Employee Email:`, `Instance:`, `Requester Name:`, `Requester Employee ID:` and `Requester Email:` are read from the text wherever the matching variable gives no value.

When a task is refused:

- The task is handed to **Hand rejected tickets to group** when one is set; otherwise it is closed as Closed Incomplete when **Close the ticket when the bot does not process it** is on; otherwise the rejection note is added and the task stays open.
- Where the bot assigns tasks to itself before queueing them (**Match tickets by** `assignment_group`, or a blank **Bot account**), a task it closes this way is assigned to the bot in the same update, so it is never closed with **Assigned to** empty.
- The default recipients receive the "Request rejected" e-mail (when request e-mails are switched on), and the refusal is recorded in the audit trail.
- The refusal is reported once. The task is read again at every poll, but the same reason on the same content is not reported twice. When someone corrects the task in ServiceNow, it is checked afresh and processed if it passes.

### Fujitsu RACF tickets

While Fujitsu RACF is switched on, the same poll, filters and checks also take Fujitsu RACF tickets: tasks that name one of the **Fujitsu RACF application IDs** (default `6582`, page **Settings › Fujitsu RACF tickets and e-mails**). The account on the ticket is the RACF ID (up to 8 half-width letters or digits) and the attribute named in **RACF group attribute** (default `Entitlement`) carries the RACF group. Section 5.9 describes the processing; for ServiceNow, note these points:

**Sample (QA):** **Fujitsu RACF application IDs** `6582`, ticket text `Fujitsu RACF (Resource Access Control Facility) [6582]`; Fujitsu RACF tickets arrive in the same assignment group as Fujitsu Mainframe tickets, `Policy Management System - Common Process-2565-JPN`. The Fujitsu RACF completion ticket goes to `MFT-SYS Programmer-JPN` (section 5.9).

- **Removals.** A removal, transfer, termination or certification ticket is processed only while **Fujitsu RACF removals** is set to remove the whole RACF ID. With the default (left for a person), the ticket is not queued: it receives the reason "Fujitsu RACF removals are handled by a person on this server (…)", is handed to **Hand rejected tickets to group** when one is set, and the default recipients receive a "Request rejected (Handled by a person)" e-mail.
- **A ticket handed to a person is never closed by the bot.** **Close the ticket when the bot does not process it** does not apply to it: the person who removes the access closes it. It stays with that person, even if the removal setting is changed later, as long as its content is unchanged.
- **One group per new RACF ID.** A ticket that adds more than one group, or both adds and removes groups, is left for manual handling.
- **Ticket texts.** The closing comments and notes of a Fujitsu RACF ticket are built in, in Fujitsu RACF wording; the texts under **Ticket updates** below are used for Fujitsu Mainframe tickets only. The close and close-on-failure switches apply to both.
- **A result that could not be confirmed.** When the job was submitted but its result could not be read, the ticket is closed as Closed Incomplete with "The RPA bot submitted the … job for RACF ID … but could not confirm whether it was applied. Closed as incomplete; if the change is still needed, submit a new request." (while **Close the ticket when the request failed** is On), and no completion ticket is created.
- **Completion ticket.** After a successful Fujitsu RACF creation, removal or certification removal, the bot can also create a separate ServiceNow record for the app team (off by default). See *The Fujitsu RACF completion ticket* in section 5.9.
- **Duplicates.** The duplicate e-mail of a Fujitsu RACF ticket uses the Fujitsu RACF labels (RACF ID, RACF group) and names **Operation** and **RACF ID** as the matching fields.

### Settings

#### Connection

| Setting | What it means | Default | Who can change it | Takes effect |
|---|---|---|---|---|
| **Poll ServiceNow for tickets** | The main switch. Off: no tasks are collected. | Off | Admin | At once |
| **Instance URL** | The address of the instance, `https://<instance>.service-now.com`. Sample (QA): `https://aigm3.service-now.com` (QA instance; confirm). | Blank | Admin | At once |
| **Authentication** | `basic` (bot account's user name and password), `oauth_password` (OAuth client ID and secret plus the bot account), or `oauth_client_credentials` (client ID and secret only). | `basic` | Admin | At once |
| **Username** | The bot account's ServiceNow user name. Shown for `basic` and `oauth_password`. | Blank | Admin | At once |
| **ServiceNow — bot account password** | Kept in the server's credential store, never shown. | Not set | Admin | At once |
| **OAuth client ID** | From the OAuth application registry on the instance. | Blank | Admin | At once |
| **ServiceNow — OAuth client secret** | Kept in the server's credential store, never shown. | Not set | Admin | At once |
| **OAuth token URL** | Blank: `<instance URL>/oauth_token.do`. Sample (QA): `https://aigm3.service-now.com/oauth_token.do`. | Blank | Developer | At once |
| **Ticket table** | The table the tasks are in. | `sc_task` | Developer | At once |

#### Ticket selection

| Setting | What it means | Default | Who can change it | Takes effect |
|---|---|---|---|---|
| **Match tickets by** | `assigned_to`: tasks assigned to the bot account. `assignment_group`: tasks that are unassigned or assigned to the bot account; each is assigned to the bot before it is queued. | `assigned_to` | Admin | At once |
| **Bot account (sys_id, user name or name)** | The bot's ServiceNow user. Blank: no filter on the assignee, and tasks are assigned to the **Username**. | Blank | Admin | At once |
| **Assignment group (sys_id or name)** | Only tasks of this group. Blank: every group. Sample (QA): `Policy Management System - Common Process-2565-JPN` (the tickets of both applications). | Blank | Admin | At once |
| **Requested For (sys_id or name)** | Only tasks requested for these users, for example the account that raises the access requests. Separate several users with commas, or with `;` when a name contains a comma. | Blank | Admin | At once |
| **Requested For field** | Where the task holds Requested For, for example `request.requested_for`. Blank: the task's, its request's and its requested item's are all read, and any may match. | Blank | Developer | At once |
| **Only approved requests** | Pick up a task only when its request is approved. | On | Admin | At once |
| **Approval condition** | One condition, `field=value`. | `request_item.approval=approved` | Developer | At once |
| **Open states** | Raw state values counted as open. Blank: every task ServiceNow treats as active (recommended). | Blank | Developer | At once |
| **Pick up new tickets in states** | Raw state values in which a task the bot does not hold yet is taken (for catalog tasks, `1` = Open). Blank: any state. | Blank | Admin | At once |
| **Poll interval (minutes)** | How often tasks are collected. 1 to 1,440 minutes. | 30 | Admin | At once |
| **New requests queued per poll (one per code)** | The most requests added to the queue by one poll. 1 to 500. | 25 | Developer | At once |
| **Tickets read per poll (most)** | The most open tasks read in one poll, oldest first, counting every open task in the selection. Keep it well above the number of open tasks. 100 to 10,000. | 1,000 | Developer | At once |
| **Duplicate check window (days)** | How far back the "same request" rule looks. `0` switches that rule off; the other two rules always apply. 0 to 365. | 30 | Developer | At once |
| **Claim the task on pickup (assign to the bot, set the state below)** | Assigns the task to the bot and sets the state below, so others see it is being worked on. | On | Developer | At once |
| **State set on pickup** | Raw state value. Emptied: the task is assigned to the bot only and its state is not changed (the shipped value does not come back). | `2` (Work in Progress) | Developer | At once |

#### Ticket updates

| Setting | What it means | Default | Who can change it | Takes effect |
|---|---|---|---|---|
| **Add a work note when a ticket is queued or found to be a duplicate** | The two information notes. | Off | Developer | At once |
| **Close the ticket after a successful provisioning or deprovisioning** | Closes the task with the closing comment when every code has succeeded. Off: nothing is written. | On | Admin | At once |
| **Closing state value** | Raw state written on a successful close (catalog task: `3` = Closed Complete). | `3` | Developer | At once |
| **Closing comment (provisioning)** / **(deprovisioning)** / **(certification)** | The closing texts. Placeholders: `{ticket_id}` `{affiliation_code}` `{employee_code}` `{result_code}` `{completed_at}` `{request_id}`; the certification text also `{category}` and `{tracking_id}`. | Supplied | Developer | At once |
| **Close the ticket when the account was already removed** | On: a removal whose account no longer exists in Fujitsu Mainframe closes the task as complete, with a note that no change was needed. Off: the review note is written and the task stays open. | On | Admin | At once |
| **Work note when the account was already deleted (ticket stays open)** | Writes the review note when the task is not closed. Also switches the "result could not be confirmed" note, which is written only while **Close the ticket when the request failed** is Off. | On | Developer | At once |
| **Review note text** | The review note. | Supplied | Developer | At once |
| **Close the ticket when the request failed** | On: a failed request closes its task with the state below and the reason. A request whose result could not be confirmed is closed the same way, never as complete, with a note that the result could not be confirmed. Off: the failure note (or the "result could not be confirmed" note) is written and the task stays open. | On | Admin | At once |
| **Closing state value (failed)** | Raw state for a failed request (`4` = Closed Incomplete). Also used for a result that could not be confirmed, and for cancelled and not-processed tasks when those are closed. | `4` | Developer | At once |
| **Closing comment (failed)** | May also use `{attempts}` and `{error}`. | Supplied | Developer | At once |
| **Work note when the request failed (ticket stays open)** and **Failure note text** | Used while failed tasks are not closed. | On, supplied | Developer | At once |
| **Note when the result could not be confirmed (ticket stays open)** | Written when the change was submitted but the result could not be read, while **Close the ticket when the request failed** is Off. With that setting On, the task is closed as incomplete with the built-in note instead. | Supplied | Developer | At once |
| **Work note when a request is cancelled (ticket stays open)** and **Cancel note text** | Written when an operator cancels a request and the task is not closed. | On, supplied | Developer | At once |
| **Close the ticket when a request is cancelled** | On: a request cancelled on the console closes its task as Closed Incomplete, so SailPoint learns the request will not be done. | Off | Admin | At once |
| **Closing comment (cancelled)** | Blank: the built-in comment. | Blank | Developer | At once |
| **Hand rejected tickets to group** | The group that receives a task the bot does not process, or a cancelled one. Blank: the task stays where it is, with the bot. | Blank | Developer | At once |
| **Work note on a ticket the bot rejects (ticket stays open)** and **Rejection note text** | The note with the reason. Placeholders `{reason}` `{ticket_id}`. | On, supplied | Developer | At once |
| **Close the ticket when the bot does not process it** | On: a task refused by a check, held as a duplicate, overtaken by a newer task, or refused when queued is closed as Closed Incomplete with the reason. A hand-over group, when set, takes the task instead. A Fujitsu RACF removal left for a person is never closed this way. Tickets of other applications or groups are never changed. | Off | Admin | At once |

The ticket texts can use these placeholders:

| Placeholder | Filled with |
|---|---|
| `{ticket_id}` | The task number |
| `{request_id}` | The bot's request number |
| `{operation}` | `provision` or `deprovision` |
| `{affiliation_code}` | The affiliation code (several codes, separated by commas, on a task with several codes) |
| `{employee_code}` | The account (Fujitsu Mainframe staff code) |
| `{result_code}` | The Fujitsu Mainframe result code, or the bot's `BOT:` code when Fujitsu Mainframe gave none |
| `{completed_at}` | When the request finished, in Japan time (JST) |
| `{attempts}` | How many attempts were made |
| `{error}` | The reason for a failure or cancellation |
| `{status}` | The request status |
| `{category}` | The request type, for example Certification or Account Certification |
| `{tracking_id}` | The SailPoint Access Request ID |
| `{reason}` | Why the task was not processed (rejection note only) |

A placeholder without a value is left blank. A text that uses an unknown placeholder or an unbalanced brace is refused when you save it. A password is never available to these texts.

#### SailPoint tickets

| Setting | What it means | Default | Who can change it | Takes effect |
|---|---|---|---|---|
| **Ticket format** | `sailpoint` for SailPoint tasks. `fields` reads one request per task from separate fields, set up by the Developer. | `sailpoint` | Developer | At once |
| **Variable: instruction text** | Label or internal name of the variable with the instruction. Several alternatives may be listed. | `Description / Work notes` | Developer | At once |
| **Variable: account (Fujitsu Mainframe employee code)** | The variable with the account (also the RACF ID on Fujitsu RACF tickets). | `Account Name` | Developer | At once |
| **Variable: employee ID (recorded)** | Recorded with the request and used to find the person's e-mail address. | `Employee ID` | Developer | At once |
| **Variable: employee name (recorded)** | Recorded with the request and shown in the support report. | `Employee` | Developer | At once |
| **Variable: instance** | Checked against **Accepted instances**. | `Instance` | Developer | At once |
| **Variable: application** | Checked against **Accepted application IDs**. | `Application Name` | Developer | At once |
| **Variable: request type** | For example Termination or Transfer. | `Request Type` | Developer | At once |
| **Accepted application IDs** (page **Fujitsu Mainframe tickets and e-mails**) | A Fujitsu Mainframe task must name one of these in square brackets. Emptying the field (or `*`) switches the check off. Sample (QA): `2565` (ticket text `Policy Management System - Common Process [2565]`). | `2565` | Admin | At once |
| **Accepted instances** | A filled-in Instance must be one of these; an empty one is accepted. Emptying the field (or `*`) switches the check off. Applies to both applications. | `Prod` | Admin | At once |
| **Affiliation attribute names** (page **Fujitsu Mainframe tickets and e-mails**) | The attribute names that carry the Fujitsu Mainframe affiliation code. | `所属コード` | Developer | At once |
| **Task field: instruction text** | Field(s) that hold the text when the variable is empty or cannot be read, for example `description` or `request.<field>`. Blank: found automatically. | Blank | Developer | At once |
| **Ticket checks** | `strict`, `minimal` or `none` (see above). | `strict` | Admin | At once |
| **User field holding the Employee ID** | The ServiceNow user field used to find the person's e-mail address when the text has no `Employee Email:` line. | `employee_number` | Developer | At once |

#### Request types

| Setting | What it means | Default | Who can change it | Takes effect |
|---|---|---|---|---|
| **Words meaning provisioning** | Operation words that add access. Not case-sensitive. | Add, Create, Provision, Provisioning | Developer | At once |
| **Words meaning deprovisioning** | Operation words that remove access. | Remove, Delete, Deprovision, Deprovisioning, Termination, Terminate, Disable | Developer | At once |
| **Words meaning a certification (always a removal)** | A certification never adds access. | Certification, Certify, Revoke | Developer | At once |
| **Words marking a Termination** | Found in the text, the Request Type or the short description. Removes every code listed. | Termination, Terminate, Leaver | Developer | At once |
| **Words marking a Transfer** | Removes the codes listed. | Transfer, Mover | Developer | At once |
| **Words marking an Account Certification** | Other certifications are shown as Certification. Both only remove. | Account Certification, Account Cert, Account Access Review | Developer | At once |

Without a type word, the operation decides: Add is New Account Provisioning, Remove is Access Removal. Only New Account Provisioning adds access.

### Test buttons

The **Tests** row of the ServiceNow page has three buttons. None of them writes anything to ServiceNow.

| Button | Who can use it | What it shows | Unsaved values? |
|---|---|---|---|
| **Test connection** | Admin | Signs in, looks up the bot account, reads the ticket table and checks the filters. Sections: **Connection** (signed in, the account tasks are assigned to, table readable, group membership, each Requested For user found), **Ticket filters**, **Open tickets after each filter**, **Requested For on these tickets** and **Notes**. | Yes: the connection, **Bot account**, **Match tickets by**, group and Requested For values on the page. A typed password is used; a stored one is sent only to the saved instance and token address. |
| **Preview tickets** | Admin | What the next poll would do with each of the first 50 open tasks: **Summary** (read, to queue, to reject, skipped, next poll), **Ticket filters**, and a **Tickets** table with **The bot would** (Assign to the bot, then queue / Queue / Reject / Skip / Next poll) and the details or reason. Nothing is assigned, noted, e-mailed or remembered. Works while polling is off. | No: the saved settings. Save first; the page asks you to. |
| **Discover fields** | Developer | Reads two sample tasks and lists the catalog variables on the first one, then says whether each **Variable:** setting was found, and whether it was empty. Values are never shown. | Connection values on the page; filters and variable names as saved. |

**Open tickets after each filter** counts the open tasks step by step, in the bot's order: **Open tickets in the table**, **In the group '…'**, **Assigned to the bot account** (or **Unassigned or the bot account's**), **Approved**, **In the open states**, and **Requested For (checked by the bot)**. A row that drops to 0 is highlighted, so you can see which filter removes every task. The line under the table says how many tasks the next poll would read. **Pick up new tickets in states** and the application check are not part of these counts; **Preview tickets** shows their effect.

**Check ServiceNow now** on the **System** page (Admin, shown while polling is on) starts a poll at once and also releases polling that was paused after rejected sign-ins.

The **ServiceNow** card on the **System** page shows how polling is doing:

| Card shows | Meaning | What to do |
|---|---|---|
| **Off** | **Poll ServiceNow for tickets** is off. | Switch it on when the settings are tested. |
| **Not running** | The polling thread has stopped. The service restarts it automatically. | If it stays, restart the service. |
| **Paused — sign-in rejected** | ServiceNow rejected the bot's sign-in three times in a row. | Save the correct password or client secret, then press **Check ServiceNow now**. |
| **Not configured** | A setting or the password is missing on this machine. The card names it. | Complete the setting; the bot checks again every minute. |
| **Failing (n)** | ServiceNow has not answered n polls in a row. The card shows the reason and the last successful check. | See the troubleshooting section; the outage e-mail follows the third failure. |
| **On** | Polling works. The card shows the last check, the next one, and how many tasks were open, queued, not in the selection, duplicate or waiting for the next poll. | Nothing. |

The card also warns when the limit **Tickets read per poll** was reached, how many ticket updates are waiting to be written, and how many must be made by hand.

### Recommended set-ups

**Tasks arrive unassigned in a group (the usual SailPoint case).** **Match tickets by**: `assignment_group`. **Assignment group**: `<assignment group>`. **Bot account**: the bot's user name. **Requested For**: the account SailPoint raises the requests with, so that tasks raised by anyone else in the group are ignored. Optionally **Pick up new tickets in states**: `1`. The bot then assigns each task to itself before queueing it, and leaves alone any task a person has taken. The bot account must be a member of the group.

**Sample (QA):** **Instance URL** `https://aigm3.service-now.com` (QA instance; confirm); **Assignment group** `Policy Management System - Common Process-2565-JPN` for the tickets of both applications.

**Tasks are assigned directly to the bot.** **Match tickets by**: `assigned_to`. **Bot account**: the bot's user name. **Assignment group**: optional. The bot reads exactly the tasks ServiceNow routes to it and claims them after queueing.

**A test instance.** Keep the selection narrow (a test group, or a test Requested For). Set **Accepted instances** to the instance name the test tasks carry, or empty it. Use **Preview tickets** freely. Use `minimal` checks while test tasks are incomplete, and `none` only to see refused tasks in the request list. Return to `strict` before production.

### What the bot's ServiceNow account must be allowed to do

| Record (table) | Read | Write | Why |
|---|---|---|---|
| Catalog tasks (`sc_task`, or the **Ticket table**) | Yes | Assigned to, State, Work notes, Close notes, Assignment group | Collect, assign, note, close and hand over tasks |
| Requested items (`sc_req_item`) | Yes | No | Approval condition, instruction text when it is not in the variables |
| Requests (`sc_request`) | Yes | No | Instruction text, requester for the support report |
| Catalog variable values (`sc_item_option_mtom`, `sc_item_option`) | Yes, including the values | No | The instruction text, the account and the detail variables |
| Variable definitions (`item_option_new`) | Yes | No | The labels of the variables |
| Users (`sys_user`) | Yes: user name, name, employee number, e-mail, active | No | Find the bot account and Requested For users; find the person's e-mail address |
| Groups (`sys_user_group`) and group members (`sys_user_grmember`) | Yes | No | Match the group by name; **Test connection** checks the bot's membership |
| The completion ticket table (`incident` by default, or `sc_task`), only while the Fujitsu RACF completion ticket is switched on | Yes | Create, and the fields set for it | The record for the app team after a Fujitsu RACF change (section 5.9). A refusal (403) is a ServiceNow access rule (ACL) matter for the ServiceNow team. |

In addition, the account must be allowed to use the ServiceNow REST Table API, should be a member of the assignment group (otherwise ServiceNow may refuse to assign tasks to it), and, for OAuth, must be linked to an OAuth application registry entry with the chosen grant enabled.

> **Important.** Read access to the **values** of the catalog variables needs a specific check. Without it, ServiceNow returns the variables empty, not an error. The bot then depends on the text being repeated in a field of the task, the requested item or the request, and cannot find the person's e-mail address from the Employee ID.

### Common situations

| Situation | What the bot does | Who is told | Which setting decides |
|---|---|---|---|
| A task for another application is in the group | Skips it. Nothing is written. Recorded once in the audit trail. | Nobody | **Accepted application IDs** |
| A task is in the group but requested for someone else | Skips it as "not in the selection". Nothing is written. | Nobody | **Requested For** |
| A person takes a task before the bot does | Leaves it to that person. | Nobody | **Match tickets by** |
| A person takes or closes a task after it was queued | Cancels the request just before it runs. Nothing is changed in the application and nothing is written to the task. | Nobody (audit trail) | None, always |
| A task has no account | Refuses it with "the account name is missing". | Default recipients, the task | **Ticket checks** |
| A certification task carries its account on an `Account name:` line | Reads the account from that line. | Nobody | None |
| A task both adds and removes codes | Refuses it; a person handles it. | Default recipients, the task | None |
| A task lists three affiliation codes | Queues three requests, run one after another, and writes to the task once at the end, with one line per code. | The task | None |
| The same access request arrives as several tasks with different codes | Processes every task. | The tasks | None |
| The same request is raised twice under different numbers | Processes the first; holds the second as a duplicate. The e-mail names the first task and the **Matching fields**. | Default recipients, the second task | **Duplicate check window (days)** |
| A removal task is older than an Add task that already ran | Holds the removal; the later Add stands. | Default recipients, the older task | None, always |
| A refused task is corrected in ServiceNow | Checks it again at the next poll and processes it if it passes. | The task | None |
| A refused task is left unchanged | Reads it at every poll but reports it only once. | Once | None |
| The handling of refused tickets is changed (close, note, hand-over group) | At the next poll, handles each refused task still open once more with the new settings and reports it again. | The tasks; default recipients | The rejection settings under **Ticket updates** |
| The account to remove does not exist in Fujitsu Mainframe | Closes the task as complete with "No change was needed" (or writes the review note). | The task | **Close the ticket when the account was already removed** |
| A request fails after all attempts | Closes the task as Closed Incomplete with the reason (or writes the failure note). | The task, plus the request e-mails | **Close the ticket when the request failed** |
| An operator cancels a queued request | Writes the cancel note (or hands the task over, or closes it). | The task | **Close the ticket when a request is cancelled**, **Hand rejected tickets to group** |
| The result on screen could not be read (**Needs verification**) | Closes the task as Closed Incomplete with a note that the result could not be confirmed; if the change is still needed, a new request is raised after the account was checked. Never closed as complete, never retried. With the setting Off: leaves the task open with a note asking a person to check the application. | The task; the default recipients ("Please verify") | **Close the ticket when the request failed**; **Note when the result could not be confirmed (ticket stays open)** |
| More tasks arrive than the per-poll limit | Queues up to the limit; the rest wait for the next poll. | **System** page | **New requests queued per poll (one per code)** |
| More open tasks exist than can be read | Reads the oldest only; the **System** card warns that the limit was reached. | **System** page | **Tickets read per poll (most)** |
| ServiceNow does not answer | Retries with a growing wait. After three failed polls in a row, sends an outage e-mail, and a recovery e-mail later. Queued requests keep running. | ServiceNow team, default recipients | None |
| The bot's password is rejected three times in a row | Pauses polling so the account is not locked. Resumes when the password or secret is saved again or **Check ServiceNow now** is pressed. | **System** page | **ServiceNow — bot account password** |
| A task cannot be assigned to the bot | Does not queue it; tries again at every poll. The first failure is e-mailed. | ServiceNow team, default recipients | Bot account's rights and group membership |
| The bot account password is not stored yet | Shows **Not configured** on the **System** card, checks again every minute; no outage e-mail. | **System** page | **ServiceNow — bot account password** |
| A write to the task fails | Retries, then tries again at later polls. If it still fails, asks for the task to be updated by hand. The result in the application stands. | ServiceNow team, **System** page | None |
| A Fujitsu RACF removal ticket arrives with the shipped settings | Does not queue it; writes the reason on the task or hands it to the hand-over group. Never closes it. | Default recipients ("Request rejected (Handled by a person)"), the task | **Fujitsu RACF removals**, **Hand rejected tickets to group** |
| A Fujitsu RACF ticket adds two groups | Refuses it; a person handles it. | Default recipients, the task | None |
| A Fujitsu RACF ID is created and the completion ticket is switched on | Closes the source task as complete and creates a separate record for the app team. | The task; the app team's group | **Completion ticket in ServiceNow** (section 5.9) |
| A Fujitsu RACF job was submitted but its result could not be read | Closes the source task as Closed Incomplete with the reason; creates no completion ticket. | The task; default recipients ("Please verify") | **Close the ticket when the request failed** |

## 5.2 E-mail

> **In plain words.** The bot works on its own, and e-mail is how it tells people what happened. It tells the support team when a request is completed or fails. It tells the new user that their account has been created. It warns the right team when ServiceNow, CyberArk, Fujitsu Mainframe, Fujitsu RACF or the database stops answering, when the bot's own Windows session cannot take keystrokes, when something happens to the database password from CyberArk, and when a service-account password must be changed. E-mail only reports: if the mail server is down, the bot keeps working exactly as before.

**Who does this:** Admin (mail server, main switches, recipients, tests), Developer (every other e-mail setting and the look of the e-mails), Mail team (relay, sender address, distribution lists).

### What it does

The service sends four kinds of e-mail, for both applications:

- **Request e-mails.** The outcome of each request: completed, failed, needs verification, or not accepted. For SailPoint tickets the service also sends the support report and the notices to the new user.
- **System e-mails.** A notice when a system the bot depends on becomes unavailable, and another when it recovers; the bot's Windows session counts as one of these systems. With the database password from CyberArk, the notices about that password: not updated and updated again, CyberArk not answering its check, the password changed, and the bot's login set back. A notice when the service starts with a problem. Optional notices for every start and stop.
- **Password e-mails.** Reminders when a service-account password is due for a change, about to expire or expired, and a notice when the Fujitsu Mainframe service-account password was changed or not changed.
- **Alerts.** Every error the service writes to its log becomes an operational alert. A summary of the alerts is sent once a day by default.

Section 6 lists every e-mail with its recipients and switches.

The mail server, the main switches and the shared recipient lists are on **Settings › E-mail**. The e-mails of each application are on its own page: **Settings › Fujitsu Mainframe tickets and e-mails** (the Fujitsu Mainframe team and the notices to a new Fujitsu Mainframe user) and **Settings › Fujitsu RACF tickets and e-mails** (the Fujitsu RACF team and the registration notice to a new Fujitsu RACF user). The look of the e-mails (HTML design, banner, colours, footer) is on the **Branding** page. You do not need to edit a file for a normal set-up.

Two switches decide almost everything:

| Switch | Shipped default | What it controls |
|---|---|---|
| **Send email alerts** | Off | The main switch. While it is Off, the service sends no e-mail of any kind. |
| **Transaction outcome emails** | Off | Every e-mail about a request: completed, failed, needs verification, not accepted, the per-error notices, the support report and the notices to new users. A refused Fujitsu RACF sign-on is the one exception: its e-mail is sent also while this switch is Off. |

A fresh installation therefore sends nothing. With only **Send email alerts** On, you receive the system e-mails, the password e-mails, the operational alerts and the summary, but nothing about individual requests (except refused Fujitsu RACF sign-ons). A failed Fujitsu RACF request then reaches the support team as a general error e-mail.

**Who receives what.** There are six groups of recipients.

| Group | Set under | Receives |
|---|---|---|
| **Default recipients** and **Default CC** | **Settings › E-mail** (Recipients and alerts) | Everything without a list of its own: request outcomes, refusals, alerts, the summary, service notices. They also stay on every outage, recovery and password e-mail. |
| **Recipients by system**: **ServiceNow team**, **CyberArk / identity team**, **Fujitsu Mainframe account administration**, **Database team** | **Settings › E-mail** (Recipients by system) | The outage and recovery notices of their system, the alerts from their system, and the recognised errors they own. The CyberArk / identity team also receives the password e-mails. |
| The application teams: **Fujitsu Mainframe team** and **Fujitsu RACF team** | **Settings › Fujitsu Mainframe tickets and e-mails**, **Settings › Fujitsu RACF tickets and e-mails** | The support report of their application's SailPoint tickets. While their **support reports only** switch is Off, also the outage, completion and failure e-mails of their application (see below). |
| **Error-alert recipients** and CC | **Settings › E-mail** (Recipients and alerts) | The per-error notices and the refused Fujitsu RACF sign-ons, together with the owning team. |
| **Support report recipients** and CC | **Settings › E-mail** (SailPoint ticket e-mails) | The support report of each SailPoint ticket, and the password e-mails. |
| The new user | Found from the ticket | The registration notice and the password notice. For Fujitsu RACF, the registration notice only, with **Registration notice CC (Fujitsu RACF)** copied. |

> **Important.** **Send email alerts** needs **SMTP host**, **From address** and at least one recipient address anywhere: **Default recipients**, a team list, **Error-alert recipients** or **Support report recipients**. With no address at all, the service sends no e-mail, and after a restart the Dashboard and the System page show "E-mail is switched off: no recipient is set." A missing host or sender gives a similar warning that starts with "E-mail is switched off:" and names the value.

**When Default recipients is empty.** E-mail stays on while any other list is set. Each e-mail goes to its other recipients (a team, the support report recipients, the new user). An e-mail about a request goes to the team of its application instead, when that team receives more than support reports. An e-mail that has nobody left, for example the alert summary or the service notices, is not sent; the audit trail records it as `email_skipped`, with the reason "no recipient is set". An empty **Default CC** changes nothing. In production, keep the operations address in **Default recipients**.

While **Default recipients** is empty, whether e-mail is on at all depends on the other lists, and that is decided when the service starts. A change of a team list, **Error-alert recipients** or **Support report recipients** that switches e-mail on or off as a whole therefore needs a restart, although these lists otherwise apply at once. The save says so: "Restart the service to apply these. E-mail is switched on by this change (Default recipients is empty)." (or "switched off").

### Before you start

Ask the mail team for the following. One message usually covers it.

| You need | Typical answer | Where it goes |
|---|---|---|
| The name of the mail relay | `smtp.example.com` | **SMTP host** |
| The port and the kind of encryption | Port 25 with STARTTLS if offered; port 587 with STARTTLS; or port 465 with SSL/TLS | **SMTP port**, **Connection security** |
| Whether the relay asks for a sign-in | Often not: an internal relay allows the bot server by its address. Ask the mail team to allow it. | **SMTP username** and the SMTP password |
| The sender address the relay accepts | `iam-access-rpa@example.com`, and send-as rights if the relay checks them | **From address** |
| The organisation's certificate authority, if the relay's certificate is internal | A certificate file on the bot server | **Extra trusted certificate file** |
| A host name, if the relay allows senders by name | `rpa-server.example.com` | **Name given to the mail server** |
| A firewall opening from the bot server to the relay port | Confirmed by the network team | — |

Then collect the distribution lists. Distribution lists are better than personal addresses, because people change roles.

| List | Receives |
|---|---|
| The RPA support team | **Default recipients**: everything that has no list of its own. Strongly recommended. |
| The application support team | **Support report recipients**: the report of each SailPoint ticket, and the password e-mails. Optional. |
| The teams that own each system | **Recipients by system**: ServiceNow, CyberArk / identity, Fujitsu Mainframe account administration, database. Optional. |
| The application teams | **Fujitsu Mainframe team**, **Fujitsu RACF team**. Optional. |
| A list for recognised errors | **Error-alert recipients**. Optional. |
| Who is copied on the notice to a new Fujitsu RACF user, for example the app team | **Registration notice CC (Fujitsu RACF)**. Optional. Everyone copied reads the initial password rule. |
| A test mailbox | **Send every e-mail only to (testing)** while you test. |
| The contact address and the three support links shown in the e-mails | `<contact address>` and the web addresses of the help pages. Optional. |

> **Important.** Agree with the security team before you switch on **Send the initial password to the new user**. That switch sends the initial password of each new Fujitsu Mainframe account by e-mail. A Fujitsu RACF notice never contains a password.

### Settings

**Setting it up, step by step.** Open **Settings › E-mail**.

1. Enter **SMTP host** and **SMTP port**, and choose **Connection security**.
2. For a relay with sign-in, enter **SMTP username** and store the SMTP password. For a relay without sign-in, leave both blank.
3. Enter the **From address** and the **Default recipients**.
4. Press **Test connection**, then **Send test e-mail** to your own address. Both use the values on the page, so you can correct a value before saving.
5. Turn on **Send email alerts**. Turn on **Transaction outcome emails** when the support team should hear about each request.
6. Enter the team lists under **Recipients by system**, and the application teams on **Settings › Fujitsu Mainframe tickets and e-mails** and **Settings › Fujitsu RACF tickets and e-mails**. Decide whether each application team should receive more than the support report (see *The application teams* below).
7. A Developer sets the rest: the SailPoint ticket e-mails, the language, the environment name and the support links.
8. Save, then press **Restart service** on the System page (or **Save and restart** on the Settings page). Most connection settings and switches apply only after the restart.
9. Check the **E-mail** card on the System page. It should show **On**. Open **E-mail samples** at the end of the E-mail page to see who receives each e-mail now.

Changes to settings marked `After a restart` show **Saved — applies after restart** next to the setting. They take effect when the service is restarted. Settings marked `At once` apply to the next e-mail.

Several addresses can be entered in any list. Separate them with commas or semicolons. Each address is checked when you save.

#### Mail server

| Setting | What it means | Default | Who can change it | Takes effect |
|---|---|---|---|---|
| **Send email alerts** | The main switch for every e-mail the service sends. | Off | Admin | After a restart |
| **SMTP host** | The mail relay that sends the e-mails. | Blank | Admin | After a restart |
| **SMTP port** | The relay's port, 1 to 65535. | 587 | Admin | After a restart |
| **Connection security** | **STARTTLS if the server offers it** (the usual choice for an internal relay on port 25), **STARTTLS required** (port 587), **SSL/TLS from the start (port 465)**, or **None (internal relay, not encrypted)**. | Not chosen: the port decides. Port 465 uses SSL/TLS, port 25 uses STARTTLS if offered, any other port requires STARTTLS. | Admin | After a restart |
| **Use STARTTLS (port 587)** | An older switch. It is shown only while **Connection security** is not chosen. | On | Developer | After a restart |
| **Use implicit SSL (port 465)** | An older switch. It is shown only while **Connection security** is not chosen. Do not turn on both. | Off | Developer | After a restart |
| **Check the server certificate** | On: the relay's certificate must be trusted by the bot server and match the host name. Turn it off only while the certificate authority is being added. The connection stays encrypted. | On | Developer | After a restart |
| **Extra trusted certificate file** | The organisation's certificate authority, when it is not among the server's trusted certificates. The file must exist when you save. | Blank | Developer | After a restart |
| **Connection time-out (s)** | How long the service waits for the relay, 5 to 300 seconds. | 30 | Developer | After a restart |
| **Name given to the mail server** | The host name the bot gives the relay. Blank: the server's own name. | Blank | Developer | After a restart |
| **SMTP username** | The relay account. Leave it blank for a relay without sign-in. A sign-in is only ever sent over an encrypted connection. | Blank | Admin | After a restart |
| **From address** | The sender of every e-mail. | Blank | Admin | After a restart |

The SMTP password is not a setting on this page. It is kept in the server's credential store, with the other credentials (**Settings › This machine › Credentials**), and an Admin can change it there.

#### Recipients and alerts

| Setting | What it means | Default | Who can change it | Takes effect |
|---|---|---|---|---|
| **Default recipients** | The RPA support team. They receive every e-mail that has no list of its own, and they stay on the e-mails to the teams. The service notices, the **Bot Windows session** notices and the alert summary go only to these addresses. | Blank | Admin | After a restart |
| **Default CC** | Copied on every e-mail sent to the default recipients. It is not added to e-mails sent to someone else, such as a new user. | Blank | Developer | After a restart |
| **Per-error notices** | On: a request that fails on a recognised error is reported to the team that owns that error, instead of the general failure e-mail. The CyberArk / identity team and the account administration team receive their errors also while this is Off, when their list is set. A refused Fujitsu RACF sign-on is always e-mailed. | Off | Admin | After a restart |
| **Error-alert recipients** | Receive the per-error notices and the refused Fujitsu RACF sign-ons together with the owning team. Blank: the default recipients take their place. | Blank | Developer | After a restart |
| **Error-alert CC** | Copied on the per-error notices. | Blank | Developer | After a restart |
| **Transaction outcome emails** | The second main switch: every e-mail about a request (see the table at the start of this section). | Off | Admin | After a restart |

#### SailPoint ticket e-mails

These settings apply to both applications. They are shown only while **Transaction outcome emails** is On.

| Setting | What it means | Default | Who can change it | Takes effect |
|---|---|---|---|---|
| **Completion notices for SailPoint tickets** | On: the default recipients also receive **Provisioning completed** or **Deprovisioning completed** for each affiliation code (or RACF group) of a SailPoint ticket, besides the support report. They go to the default recipients and the team of the request's application. Off: the support report alone, while the report is On. | On | Admin | At once |
| **Support report per SailPoint ticket** | One report per ticket, once every affiliation code of the ticket has finished. A Fujitsu RACF ticket has its own report. | On | Admin | At once |
| **Support report recipients** | Who receives the report. Blank: the default recipients and the default CC. The team of the ticket's application is added: the Fujitsu Mainframe team for a Fujitsu Mainframe ticket, the Fujitsu RACF team for a Fujitsu RACF ticket, when its addresses are set. These recipients also receive the password e-mails. | Blank | Admin | At once |
| **Support report CC** | Copied on the report. | Blank | Developer | At once |
| **Requester (申請者) shown in the support report** | Taken from the requester lines of the ticket text when it has them. Otherwise from the ServiceNow request: `opened_by` (the person who opened it), `requested_for` (the person it was requested for) or `none` (not shown). | `opened_by` | Developer | At once |
| **Contact address shown in user e-mails** | Shown in the footer of every e-mail while the footer is switched on (Branding page). It is not the sender. | `<contact address>` | Developer | At once |
| **Link: request resources page** | Web address (`https://…`) of the page with user guides and FAQs, linked in the support block. Blank: that sentence is left out. | Blank | Developer | At once |
| **Link: administration team e-mail** | Address of the access administration team. The link opens a new e-mail with the subject "Access Requests". Blank: that sentence is left out. | Blank | Developer | At once |
| **Link: IT Self-Service Portal** | Web address (`https://…`) of the service desk portal. Blank: that sentence is left out. With all three links blank, no support block is shown. | Blank | Developer | At once |

The notices to a new user are set per application:

| Setting | Page | What it means | Default | Who can change it | Takes effect |
|---|---|---|---|---|---|
| **Registration notice to the new user** | **Fujitsu Mainframe tickets and e-mails** | The registration notice (client template, without the password) for a new Fujitsu Mainframe account from a SailPoint ticket, or from the console with the new user's address. | On | Admin | After a restart |
| **Send the initial password to the new user** | **Fujitsu Mainframe tickets and e-mails** | A separate e-mail with the initial password, for the same new accounts. Sent even while the registration notice is Off. | Off | Admin | After a restart |
| **Registration notice to the new user (Fujitsu RACF)** | **Fujitsu RACF tickets and e-mails** | The registration notice for a new Fujitsu RACF account from a SailPoint ticket: one e-mail per ticket, in Japanese then English, with the user ID, the rule for the initial password and the password rules. Never a password. | Off (until the wording is agreed) | Admin | After a restart |
| **Registration notice CC (Fujitsu RACF)** | **Fujitsu RACF tickets and e-mails** | Copied on that notice, for example the app team. Everyone copied reads the initial password rule. Empty: no copy. | Blank | Admin | At once |

The new user's address is the "Employee Email" line of the ticket text when the ticket has one. Otherwise the bot looks up the person in ServiceNow by the Employee ID on the ticket, using **User field holding the Employee ID** (ServiceNow settings, SailPoint tickets).

#### Content and delivery

| Setting | What it means | Default | Who can change it | Takes effect |
|---|---|---|---|---|
| **Send every e-mail only to (testing)** | Test mode. Every e-mail goes only to these addresses, with the same content. See "Testing safely". Keep it blank on production. | Blank | Admin | At once |
| **Mask e-mail addresses in the audit trail** | On: the audit trail records each recipient as `k***@example.com`. Off: the full addresses are recorded, so you can see who received each e-mail. The service log always masks them. Records already written keep their form. | Off | Developer | At once |
| **E-mail language** | **Japanese and English**, **Japanese only** or **English only**. | Japanese and English | Developer | At once |
| **Environment name shown in e-mails** | Shown in every subject, for example `UAT` or `PRODUCTION`. Blank: no environment name is shown. | Blank | Developer | At once |
| **Alert summary e-mail** | **Daily**, **Hourly** or **Off**. | Daily | Developer | After a restart |
| **Daily summary time (JST)** | When the daily summary is sent. Shown while the summary is daily. | 09:00 | Developer | After a restart |
| **Keep resending failed e-mails for (hours)** | How long an undelivered e-mail is kept and resent, 0 to 168. 0: not kept. | 24 | Developer | After a restart |
| **E-mail when the service starts or stops** | A notice for every normal start and stop. A start with problems is always e-mailed. | Off | Developer | After a restart |
| **Technical detail in e-mails** | On: the alerts, the summary, the outage notices and the request e-mails add the original technical message at the end, for the RPA support team. Off: each problem is explained in plain words only; the service log always keeps the full message. | Off | Developer | At once |

#### Recipients by system

Each team receives the e-mails about its own system, together with the default recipients. A blank list means those e-mails go to the default recipients only. An address in both To and CC is kept in To only.

| Setting | What it means | Default | Who can change it | Takes effect |
|---|---|---|---|---|
| **ServiceNow team** / **ServiceNow team CC** | ServiceNow polling outages and recovery, ticket update failures, tickets that could not be assigned to the bot, and other ServiceNow errors. | Blank | Admin | At once |
| **CyberArk / identity team** / **CyberArk / identity team CC** | CyberArk outages and recovery for the Fujitsu Mainframe and Fujitsu RACF passwords, the separate **CyberArk (database password)** outage and recovery, CyberArk errors, the service-account password rejected by Fujitsu Mainframe, a Fujitsu RACF password rejected or expired when CyberArk supplies it, and the password e-mails. | Blank | Admin | At once |
| **Fujitsu Mainframe account administration** / **… CC** | Operator code not registered, affiliation code not valid, sign-in message not recognised, employee code not found, employee code error. | Blank | Admin | At once |
| **Database team** / **Database team CC** | Database not reachable and recovered; with the database password from CyberArk, **Database password** not updated and updated again, **Database password changed**, and **Bot's database login set back to the password in CyberArk**. | Blank | Developer | At once |

#### The application teams

| Setting | Page | What it means | Default | Who can change it | Takes effect |
|---|---|---|---|---|---|
| **Fujitsu Mainframe team** / **Fujitsu Mainframe team CC** | **Fujitsu Mainframe tickets and e-mails** | The support report of each Fujitsu Mainframe SailPoint ticket, whatever its results. With the switch below Off, also Fujitsu Mainframe unavailable and recovered, centre not ready, line error, operational alerts of the mainframe check, and the completion notices of Fujitsu Mainframe requests. | Blank | Admin | At once |
| **Fujitsu Mainframe team: support reports only** | **Fujitsu Mainframe tickets and e-mails** | On: the Fujitsu Mainframe team and its CC list receive only the support report. Every other e-mail goes to the recipients it uses when the team list is blank. Off: the team also receives the e-mails listed above. | On | Admin | At once |
| **Fujitsu RACF team** / **Fujitsu RACF team CC** | **Fujitsu RACF tickets and e-mails** | The support report of each Fujitsu RACF SailPoint ticket, whatever its result. With the switch below Off, also Fujitsu RACF unavailable and recovered, refused sign-ons, failed requests, results to verify, Fujitsu RACF operational alerts and the completion notices of Fujitsu RACF requests. | Blank | Admin | At once |
| **Fujitsu RACF team: support reports only** | **Fujitsu RACF tickets and e-mails** | On: the Fujitsu RACF team and its CC list receive only the support report. Every other Fujitsu RACF e-mail goes to the support teams and the other teams set for it. Off: the team also receives the e-mails listed above. | On | Admin | At once |

> **Important.** Both **support reports only** switches are On by default. A team that should also be told of outages, failures and completed requests of its application needs its switch Off. Check this when the team addresses were already set before, for example after an upgrade: while the switch is On, the team receives the support report and nothing else.

**How the lists combine.** The default recipients plus the owning team. Example: the default recipients are `rpa-support@example.com` and the CyberArk / identity team is `identity-ops@example.com`. When CyberArk stops answering, the e-mail goes to both. When a request fails for an ordinary reason, it goes to `rpa-support@example.com` only.

For a per-error notice the order is: the owning team plus the **Error-alert recipients** (or the default recipients when those are blank). If the owning team's list is blank (or the team receives support reports only), the notice goes to the **Error-alert recipients**, or to the default recipients when those are blank too.

The completion notices go to the default recipients plus the team of the request's application. The support report goes to the **Support report recipients** (or the default recipients) plus the team of its own application, whatever the **support reports only** switch says. The password e-mails go to the default recipients, the **CyberArk / identity team** and the **Support report recipients**.

### How the e-mails look

**Language.** **E-mail language** decides the wording of every e-mail the service writes itself:

- **Japanese and English** (default): one message holds a complete Japanese e-mail, followed by a complete English e-mail. Each has its own banner, title, text, support block and closing. The subject carries both languages, Japanese first.
- **Japanese only** or **English only**: one e-mail in that language.

The template e-mails (the support report, the registration notice and the password notice of Fujitsu Mainframe; the support report and the registration notice of Fujitsu RACF) are written in both languages. They are always sent as the Japanese e-mail followed by the English one, whatever the language setting. Their subject is sent exactly as written in the template.

**The design.** Every e-mail has a plain-text version. While **Send e-mails in the branded HTML design** is On (Branding page, default On), it also has a designed version. The design is left-aligned and up to 800 pixels wide. The banner sits across the top: the one uploaded on the Branding page, or the built-in banner. Images travel inside the e-mail, so Outlook shows them without downloading anything. In the registration and password notices, the user's name in the greeting is shown in red.

**Greeting by name.** The registration and password notices address the user by name, taken from the ticket. A name written "Family, Given" gives "Family Given 様" in Japanese and "Dear Given," in English (the Fujitsu RACF notice uses "Family Given さん"). Without a name: "ご担当者様" and "Dear User,".

**The end of every e-mail**, in this order, in the language of each part:

1. **The support block**, headed "Additional Support". One sentence for each link set under **Link: request resources page**, **Link: administration team e-mail** and **Link: IT Self-Service Portal**. A link that is blank, or not a valid `https://` address, is left out. With no link set, there is no support block.
2. **The closing and the signature**: "よろしくお願いいたします。" in the Japanese part, "Thank you," in the English part, then the signature line.
3. **The footer**, only while **Show the footer at the end of every e-mail** is On (Branding page, default Off). It holds the company and department, the **Contact address shown in user e-mails**, and a note that the message was sent automatically. With the footer Off, every e-mail ends with the signature.

The wording of all these lines, and of every e-mail the service writes itself, is kept in the e-mail wording file, in Japanese and English. A change to that file applies to the next e-mail without a restart.

**The subject.** The service's own e-mails are built as:

`[<product name>] [<environment name>] <subject>`

For example: `[AIG IAM Access RPA] [UAT] 【要対応】<ticket number> の依頼を完了できませんでした / Action required: request for <ticket number> could not be completed`.

- The product name comes from the Branding page. The default is `AIG IAM Access RPA`.
- The environment name comes from **Environment name shown in e-mails**. When it is blank, that part is left out.
- The template e-mails keep the subject written in their template, with no product or environment name.

Typical subjects with **Japanese and English** (product and environment name left out here):

| E-mail | Subject |
|---|---|
| Provisioning completed | アカウント登録完了 / Provisioning completed — `<ticket number>` |
| Deprovisioning completed | アカウント削除完了 / Deprovisioning completed — `<ticket number>` |
| Transaction failed | 【要対応】`<ticket number>` の依頼を完了できませんでした / Action required: request for `<ticket number>` could not be completed |
| Result not confirmed | 【要確認】`<ticket number>` の処理結果を確認できませんでした / Please verify: the result for `<ticket number>` could not be confirmed |
| Request rejected | 依頼受付不可 / Request rejected (`<type>`) — `<ticket number>`; the type is 入力不備 / Validation failed, 重複申請 / Duplicate request, or 手動対応 / Handled by a person |
| Recognised error (examples) | 富士通メインフレームログイン拒否 / login rejected — service account password; 富士通 RACF サインオン拒否 / sign-on refused — password not accepted |
| Outage and recovery | `<system>`が利用できません / `<system>` Not Available, and `<system>`が復旧しました / `<system>` Recovered. Some have their own subject, for example "Fujitsu Mainframe not available: request processing is paused" or "CyberArk not available: the bot could not retrieve its password". |
| The bot's Windows session | ボットの Windows セッションが利用できません / Bot Windows session Not Available, and ボットの Windows セッションが復旧しました / Bot Windows session Recovered |
| Keystrokes refused (operational alert) | 【エラー】Windows がボットのキー入力を受け付けませんでした / Error: Windows did not accept the bot's keystrokes |
| Database password not updated, and updated again | データベースのパスワードを更新できませんでした（現在のパスワードで処理を継続しています）/ Database password not updated: the bot keeps working with the password in use; データベースのパスワードを更新しました（CyberArk の現在のパスワードを使用しています）/ Database password updated: the bot uses the current password from CyberArk |
| CyberArk not answering the database password check, and recovered | CyberArk が利用できません（データベースのパスワードを確認できません）/ CyberArk not available: the database password could not be checked; CyberArk（データベースのパスワード）が復旧しました / CyberArk (database password) Recovered |
| Database password changed | データベースのパスワードが変更されました：ボットは新しいパスワードを使用しています / Database password changed: the bot uses the new password |
| Bot's database login set back | ボットのデータベースログインのパスワードを CyberArk のパスワードに戻しました / Bot's database login set back to the password in CyberArk |
| Password e-mails | `<system>` サービスアカウントのパスワード変更時期です / `<system>` service-account password change due; 【至急】… / URGENT: `<system>` service-account password expires soon, or has expired; 富士通メインフレームのサービスアカウントのパスワードを変更しました / Fujitsu Mainframe service-account password changed (or not changed) |
| Service started with problems | サービス起動（問題あり）/ Service started with problems |
| Alert summary | 日次サマリー（`<date>`）：処理失敗 `<n>` 件、その他 `<m>` 件 / Daily summary for `<date>`: `<n>` failed requests, `<m>` other issues |
| Support report (template) | FINESIIIアカウント登録報告 / FINES III Account Registration Report (`<date>`), or the removal report; for Fujitsu RACF: 富士通 RACF アカウント登録報告 / Fujitsu RACF Account Registration Report (`<date>`) |
| Registration notice (template) | FINESIIIアカウントの新規登録について（通知）/ [Notice] New Registration of FINES III Account; for Fujitsu RACF: 【連絡】ＴＳＳユーザーＩＤ作成完了のお知らせ / [Notice] TSS User ID Created |
| Password notice (template) | FINESIIIアカウントの初期パスワードについて（通知）/ [Notice] Initial Password of FINES III Account |

**The Branding page** (Developer only) holds the look of the e-mails:

| Setting | What it means | Default |
|---|---|---|
| **Send e-mails in the branded HTML design** | Adds the designed version to every e-mail. Off: plain text only. | On |
| **Show the footer at the end of every e-mail** | Adds the footer after the signature. | Off |
| **Banner** | The image across the top of every e-mail. PNG, JPEG or GIF, at least 800 pixels wide, up to 300 KB. **Use built-in banner** returns to the shipped one. | Built-in banner |
| **Logo for e-mail, white version** | Used only when no banner image is available. Up to 100 KB. | Built-in logo |
| **Header colour**, **Accent colour** | The colours of the header bar, used when no banner image is available. | Shipped colours |
| **Company name** | The name used in the header and as the banner's alternative text. | Shipped company name |

> **Tip.** On a test or UAT server, set **Environment name shown in e-mails** to `UAT` or `TEST`, so nobody mistakes a test e-mail for a real one.

**What the support report contains.** One report per SailPoint ticket, in Japanese and then English:

- the action: registration (登録) for a new account, removal (削除) for every other request type;
- the requester: name, employee number and e-mail address;
- the person the request is for: name, Employee ID, e-mail address, and each affiliation code with its name and the employee code;
- the result of each code, in words: **Account registered**, **Account removed**, **Already removed (no change made)**, **Registration failed** or **Removal failed** (with the error), **Cancelled (no change made)**, or **Needs verification: submitted, result not confirmed**;
- a note when the user's address was missing or not valid, or when the registration or password notice could not be sent;
- the ticket number, the request number, the requested item number, the request type and the Access Request ID. A ticket without an Access Request ID, such as a certification, has no such line.

A value the bot could not find is shown as "-". The Fujitsu RACF report has the same layout with the RACF ID, the RACF group and the result of the ticket.

### Testing safely

**On the E-mail page.** Below the settings, the row **Test the mail server** has a **Test recipients** box and two buttons. Both use the values on the page, before you save, so you can correct a value first.

| Button | What it does |
|---|---|
| **Test connection** | Connects, secures the connection and signs in exactly as a real e-mail would, then disconnects. Nothing is sent. |
| **Send test e-mail** | Sends one test e-mail, in the language and design in force, to the addresses in **Test recipients** (at most five). With the box empty, it goes to the **Default recipients**. |

When a test fails, the console shows the reason and a hint in plain words. A test e-mail is never retried and never kept for resending. Each test is recorded in the audit trail.

| The hint says | What to do |
|---|---|
| The SMTP host is unreachable from this machine | Check the host name and port with the mail team, and ask for the firewall to be opened from the bot server. |
| The server's certificate is not trusted by this machine | Add the organisation's certificate authority to the server, or set **Extra trusted certificate file**. Switch **Check the server certificate** Off only for a short time. |
| The server's certificate is for a different name | Use the host name written on the certificate, not an IP address or alias. |
| The server does not offer STARTTLS | Choose **STARTTLS if the server offers it**, or check the port. |
| TLS mismatch | Use SSL/TLS for port 465 and STARTTLS for ports 587 and 25. |
| Username or password rejected | Correct them, or leave the username blank for a relay without sign-in. |
| The server offers no encryption, so the login was not sent | Clear the username for a relay without sign-in, or choose STARTTLS or SSL/TLS. |
| The server refused the From address, or the account may not send as it | Ask the mail team which sender is allowed, or for send-as rights. |
| The server refused the recipient (relaying denied) | Ask the mail team to allow the bot server on the relay for that domain. |

> **Important.** A test that uses the stored SMTP password requires **Check the server certificate** to be On. To test with certificate checking Off, type the password for that test.

The setup wizard's e-mail page has the same test as **Send test email**, with its own recipient box.

**E-mail samples.** The collapsible section **E-mail samples**, at the end of **Settings › E-mail** (Admin and Developer), lists every e-mail the service sends, for both applications, with the Fujitsu RACF e-mails in their own rows. The outage and recovery rows include **Database password**, **CyberArk (database password)** and **Bot Windows session**, and the list has rows for **Database password changed** and **Database password set back**. It reads the list when you open it.

| Column | What it shows |
|---|---|
| **E-mail** | The e-mail, with the system (for outage, recovery and alert e-mails) or the error rule (for recognised error e-mails). |
| **When** | When it is sent. |
| **On** | **Yes** when the saved settings would send it now. |
| **Who receives it** | The To and CC addresses it would go to now, built by the same code as the real e-mail. A note says when nobody would receive it (not sent, recorded as `email_skipped`), or when a recognised error falls back to the general failure e-mail. |

**Preview** shows the e-mail with sample data, in the language chosen above the table, without sending it. **Send sample** sends it only to the test addresses typed above the table, with `[TEST]` first in the subject; the real recipients receive nothing. Use this view after any change to the recipient lists or to the **support reports only** switches.

**Test mode.** **Send every e-mail only to (testing)** sends every e-mail only to the addresses you enter, with the same subject and content. That includes the user notices of both applications (and the **Registration notice CC (Fujitsu RACF)** copy), the password notice, the support report, the outcome e-mails, the password e-mails, the alerts and the test e-mail.

- The intended recipients are kept in the message headers and in the audit trail, so you can see who would have received each e-mail.
- The To line names only the testers and the CC line is removed, so "reply all" cannot reach the real recipients.
- While test mode is on, the Dashboard and the System page show a warning: "E-mail test mode: every e-mail goes only to …".
- It applies at once. An e-mail resent from the outbox while test mode is on also goes only to the testers. An e-mail kept while test mode was on still goes only to the testers after you clear it.

| What happens in test mode | Reaches real people? |
|---|---|
| Notices to new users, support report, outcome, per-error and rejection e-mails | No. Only the testers receive them. |
| Outage, recovery, password and service notices, operational alerts, the summary | No. Only the testers receive them. |
| The password notice | No, but the testers receive the real initial password. |
| ServiceNow ticket notes and closures | Yes. Test mode changes e-mail only. |

> **Important.** In test mode the testers receive real initial passwords if **Send the initial password to the new user** is On. Keep that switch Off while testing, unless you are testing the password notice itself.

**A safe test plan for a UAT server.**

1. Enter the test mailbox in **Send every e-mail only to (testing)**.
2. Set **Environment name shown in e-mails** to `UAT`.
3. Keep **Send the initial password to the new user** Off.
4. Turn on **Send email alerts** and **Transaction outcome emails**, save and restart.
5. Run a few test tickets: a new account, a removal, and one that fails the ticket checks.
6. Check in the test mailbox that each expected e-mail arrived, and in the audit trail who would have received it.
7. Before going live, clear **Send every e-mail only to (testing)** and **Environment name shown in e-mails** (or set it to `PRODUCTION`). Check that the Dashboard warning has gone.

> **Tip.** Clear **Send every e-mail only to (testing)** before going live. An e-mail kept in the outbox during the test still goes only to the testers, so let the outbox empty first or delete those e-mails.

### When delivery fails

The bot never waits for the mail server. E-mails are sent in the background, at most two connections at a time.

1. **Immediate retries.** Each e-mail is tried up to four times, with short waits of 1, 2 and 4 seconds. A refusal that retrying cannot cure is not retried: a refused sign-in, a refused sender or recipient, a certificate that is not trusted, a relay without encryption while a sign-in is set, or any permanent (5xx) answer.
2. **The outbox.** An e-mail that still fails is kept on the bot server and resent automatically. The first resend round runs 30 seconds after the service starts, then every 5 minutes, oldest first. A round stops at the first failure, because the relay is evidently still down. The outbox survives a restart.
3. **After a refused sign-in** the next round waits 30 minutes, so a wrong password cannot lock the mail account.
4. **Given up.** An e-mail kept longer than **Keep resending failed e-mails for (hours)** (default 24) is removed and recorded in the audit trail as failed.

What is not kept for resending:

- the password notice as written: only its record is kept, without the password, and the e-mail is built again from the request when it is resent. The request keeps the password for this at most 72 hours, then it is erased and the notice is given up;
- the test e-mail and the sample e-mails;
- an e-mail the relay refused because of its sender or its recipients, because resending cannot help;
- any e-mail while **Keep resending failed e-mails for (hours)** is 0.

When the service starts with e-mail switched off, or with the keep time at 0, any e-mails still kept are deleted, because nothing would ever send them.

**Where you see it.** Nothing is e-mailed about a delivery failure, because the e-mail would not arrive.

- While delivery fails, the Dashboard and the System page show: "E-mail delivery is failing (last failure … JST: …)", with the number of e-mails waiting in the outbox.
- The **E-mail** card on the System page shows **Off**, **On** or **Not delivering**, with the reason or the number of e-mails waiting.
- The **E-mail outbox** section on the System page lists each waiting e-mail with **Kept since (JST)**, **Subject**, **To**, **Attempts**, **Last error** and **Given up after (JST)**. Addresses in this list are always masked.

**Resend now** (shown while e-mails wait) runs a resend round at once. The console answers with how many were sent, given up and still waiting. If the relay refused the sign-in recently, it answers with the time of the next attempt instead.

**Delete** removes one waiting e-mail that must not be sent, for example one that is out of date, after you confirm. The removal is recorded in the audit trail.

Every e-mail sent, kept for later or given up is recorded in the audit trail (category **E-mail**) with its subject, its kind and its recipients.

### Common situations

"Outcome e-mails On" means **Send email alerts** and **Transaction outcome emails** are both On.

| Situation | What the bot does | Who is told | Which setting decides |
|---|---|---|---|
| A SailPoint new-account ticket succeeds | Sends the registration notice and, if switched on, the password notice to the new user. Sends **Provisioning completed** for the code and, once the ticket is finished, the support report. | New user; default recipients; support report recipients | Outcome e-mails On; **Registration notice to the new user**; **Send the initial password to the new user**; **Completion notices for SailPoint tickets**; **Support report per SailPoint ticket** |
| A SailPoint ticket has two affiliation codes | User notices and a completion notice after each code that succeeds. One support report when both codes have finished. | As above | As above |
| A SailPoint removal or certification ticket succeeds | **Deprovisioning completed** for each code, then the support report. No e-mail to the user. "Already removed" counts as success and says so. | Default recipients; support report recipients | **Completion notices for SailPoint tickets**; **Support report per SailPoint ticket** |
| The support report is switched off | The completion notices are sent for every SailPoint code, whatever **Completion notices for SailPoint tickets** says, so the support team is always told. User notices are unchanged. | Default recipients; new user | **Support report per SailPoint ticket** |
| A request submitted on the console succeeds | **Provisioning completed** or **Deprovisioning completed**. For a new Fujitsu Mainframe account with the user's address on the request, also the registration notice (and the password notice if switched on). No support report. | Default recipients; new user | Outcome e-mails On; **Registration notice to the new user** |
| A request fails | One failure e-mail when the request has used its attempts, or fails in a way that is not retried. Never one per attempt. For a SailPoint ticket the support report follows, with the code as failed. | Default recipients, or the owning team for a recognised error | Outcome e-mails On; **Per-error notices** |
| Fujitsu Mainframe rejects the service-account password | The request fails without further tries once no new password has arrived. The e-mail asks the team to check the password held in CyberArk. Sent also while per-error notices are Off, when the CyberArk / identity team list is set. | CyberArk / identity team and error-alert (or default) recipients; with neither per-error notices nor that list, the default recipients (**Transaction failed**) | **Per-error notices**; **CyberArk / identity team** |
| Fujitsu Mainframe refuses the operator code or the employee code | The request fails; nothing is changed. Sent also while per-error notices are Off, when the account administration list is set. | Fujitsu Mainframe account administration and error-alert (or default) recipients | **Fujitsu Mainframe account administration**; **Per-error notices** |
| Fujitsu RACF refuses the bot's sign-on | The sign-on e-mail, always, also while **Transaction outcome emails** or **Per-error notices** is Off. Fujitsu RACF requests wait. | Error-alert (or default) recipients; the CyberArk / identity team for a rejected or expired password supplied by CyberArk; the Fujitsu RACF team only while its support-reports-only switch is Off | **Send email alerts** |
| A Fujitsu RACF SailPoint new-account ticket succeeds | The registration notice to the new user (when switched on), one per ticket, in Japanese then English, never with a password. **Provisioning completed** (naming the completion ticket when one was made) and the Fujitsu RACF support report. | New user and **Registration notice CC (Fujitsu RACF)**; default recipients; support report recipients and the Fujitsu RACF team | **Registration notice to the new user (Fujitsu RACF)**; **Registration notice CC (Fujitsu RACF)** |
| A Fujitsu RACF removal ticket arrives with the shipped settings | **Request rejected (Handled by a person)**; the ticket is told why and is never closed by the bot. | Default recipients | **Fujitsu RACF removals** |
| A Fujitsu RACF job fails, or its result cannot be read | **Transaction failed** or **Result not confirmed**, worded for Fujitsu RACF. The "Please verify" e-mail gives the **Reason** (no result after the checks, no SUBMITTED line, keystrokes refused by Windows, or a step that did not finish), the **Employee ID**, the **Job number** when one was shown, and where the screenshots are. With **Transaction outcome emails** Off, the general error e-mail instead. | Default recipients (+ Fujitsu RACF team while its switch is Off) | Outcome e-mails On; **Fujitsu RACF team: support reports only** |
| The result could not be read after the change was sent | **Result not confirmed** ("Please verify"): check the account in the application and do not retry. The e-mail says that the bot closed the ServiceNow ticket as Closed Incomplete and that a new request is raised only if the change was not applied. No e-mail to the user. The support report shows the code as needing verification. Also sent at start for a request interrupted after the change was sent. | Default recipients | Outcome e-mails On |
| A ticket fails the ticket checks | **Request rejected (Validation failed)** with the reason and the data. Sent once per ticket, until the ticket's content changes. | Default recipients | Outcome e-mails On |
| A ticket duplicates an earlier one, or is overtaken by a newer ticket for the same person | **Request rejected (Duplicate request)** with the original ticket and the **Matching fields** in plain words (for example Operation, Affiliation code, FFM Application ID / Employee code; for Fujitsu RACF Operation, RACF ID; or Access Request ID), with "(opposite operation)" for a ticket overtaken by a newer one. | Default recipients | Outcome e-mails On |
| A ticket is for another application | Nothing is e-mailed. The ticket is outside the bot's selection. | Nobody | — |
| ServiceNow does not answer | After 3 failed polls in a row: **ServiceNow Polling Not Available**. **Recovered** on the first good poll. Each failed poll is also logged as an error, which can produce an operational alert. | Default recipients and ServiceNow team | **Send email alerts**; **ServiceNow team** |
| ServiceNow rejects the bot's sign-in | As above. After 3 rejections in a row, polling pauses until the password or client secret is saved again or **Check ServiceNow now** is pressed. The outage e-mail says so. | Default recipients and ServiceNow team | **Send email alerts** |
| A ServiceNow ticket cannot be updated after the work in the application | An operational alert on the first failure and when the bot gives up, asking for the ticket to be updated by hand. | Default recipients and ServiceNow team | **Send email alerts**; **ServiceNow team** |
| CyberArk stops answering | **CyberArk not available: the bot could not retrieve its password**, for the Fujitsu Mainframe or Fujitsu RACF password. The bot keeps using the last password it fetched. **Recovered** on the next successful fetch. For the database password, the separate notice below. | Default recipients and CyberArk / identity team | **Send email alerts** |
| CyberArk does not answer the bot's check of the database password | **CyberArk not available: the database password could not be checked**. Requests continue with the database password the bot received last. **CyberArk (database password) Recovered** when CyberArk answers again. | Default recipients and CyberArk / identity team | **Send email alerts** |
| Fujitsu Mainframe cannot be reached | **Fujitsu Mainframe not available** when the mainframe check fails or the terminal cannot be started. Fujitsu Mainframe requests wait in the queue. **Recovered** when the check succeeds. | Default recipients (+ Fujitsu Mainframe team while its switch is Off) | **Send email alerts**; **Fujitsu Mainframe team: support reports only** |
| Fujitsu RACF is not available (host not answering, terminal not starting, sign-on ID in use, host answering `NOT AVAILABLE`) | **Fujitsu RACF Not Available**, once per outage; **Recovered** when it works again. Fujitsu RACF requests wait; Fujitsu Mainframe continues. With **Transaction outcome emails** Off, a "not available" answer may also send the general error e-mail. | Default recipients (+ Fujitsu RACF team while its switch is Off) | **Send email alerts**; **Fujitsu RACF team: support reports only** |
| It is outside the operating window of an application | No e-mail. That application's requests wait in the queue. The default network check of the host runs outside the window too, so an unreachable host is reported at night as well. | Nobody | — |
| The database cannot be reached | After two failed checks one minute apart: **Database not available: request processing is paused**. **Recovered** on the first good check. The related error alerts are held back meanwhile. | Default recipients and database team | **Send email alerts** |
| CyberArk has a new database password, but the bot cannot give it to its database login | After three attempts, one minute apart: **Database password not updated: the bot keeps working with the password in use**. Requests continue. The problem ends by itself at the next good check: **Database password updated: the bot uses the current password from CyberArk**, with a **Found by** row (for example Scheduled check, or "Validate database password" on the console). | Default recipients and database team | **Send email alerts** |
| CyberArk changed the database password and the bot uses the new one | **Database password changed: the bot uses the new password**, once per change, with **Changed in CyberArk**, **Found by**, **Bot's database login** and **CyberArk check**. Never the password. No action is needed. There is no separate switch. | Default recipients and database team | **Send email alerts** |
| The database refuses the bot's login although the password in CyberArk did not change (someone changed the login's password outside CyberArk) | The bot sets the login back to the password in CyberArk and continues: **Bot's database login set back to the password in CyberArk**, with **Found by**. The database team should find out who changed it. | Default recipients and database team | **Send email alerts** |
| The bot's Windows session is locked, disconnected or minimized | No new request starts; requests wait. **Bot Windows session Not Available**, once; **Bot Windows session Recovered** when Windows accepts the bot's keystrokes again (checked at most once a minute after a refusal). An error logged because Windows refused the keystrokes is e-mailed as the alert **Error: Windows did not accept the bot's keystrokes**, which explains the cause in plain words. | Default recipients | **Send email alerts** |
| A service-account password is due, about to expire or expired | A reminder once a day while it lasts, checked every hour. For Fujitsu RACF the bot cannot change the password: the e-mail asks for the RACF administrators. Not sent while the date of the last change is unknown, or while CyberArk supplies that password. | Default recipients, CyberArk / identity team, support report recipients | **Send email alerts**; the **last changed on** settings |
| The Fujitsu Mainframe service-account password is changed on the console or automatically | **Service-account password changed** or **not changed**, with the account, who, how, the result and the evidence folder. Never the password. | Default recipients, CyberArk / identity team, support report recipients | **Send email alerts** |
| The mail relay is down | Four tries, then the outbox. Resent every 5 minutes for up to 24 hours. Warning on the Dashboard and System page. | Nobody by e-mail | **Keep resending failed e-mails for (hours)** |
| The relay refuses the sign-in | Not retried at once. Kept in the outbox, with 30 minutes between rounds. Warning on the Dashboard and System page. | Nobody by e-mail | **SMTP username**, SMTP password |
| The new user has no e-mail address, or an invalid one | No registration or password notice. The password is sent nowhere else. The support report notes it, and the request's details on the console say "Not sent". | Support report recipients | **User field holding the Employee ID** |
| Registration notice On, password e-mail Off | Only the registration notice. Its fixed text still says the password follows in a separate e-mail, so tell users how they will receive it. | New user | **Send the initial password to the new user** |
| The password notice cannot be delivered | Kept in the outbox as a record without the password and resent for at most 72 hours. When it is given up, reset the password and tell the user by hand; the support report says so when it is known in time. | Support report recipients | **Keep resending failed e-mails for (hours)** |
| **Transaction outcome emails** is Off | No e-mail about requests, no support report, no user notices, except the e-mail of a refused Fujitsu RACF sign-on. System e-mails, password e-mails, alerts and the summary still go out. | Default recipients and the teams (system e-mails only) | **Transaction outcome emails** |
| E-mail is On but **Default recipients** is blank | The e-mails that have other recipients still go to them. An e-mail left with nobody is not sent and is recorded as `email_skipped` in the audit trail. With no address set anywhere, no e-mail at all, and a warning "E-mail is switched off: no recipient is set." after a restart. | The other recipients only | **Default recipients** |
| A team should hear about more than the support report | Switch its **support reports only** setting Off. The change applies to the next e-mail. | That team | **Fujitsu Mainframe team: support reports only**, **Fujitsu RACF team: support reports only** |
| **Default recipients** is blank and a team list is cleared or filled in | When the change switches e-mail on or off as a whole, the save asks for a restart ("E-mail is switched on by this change (Default recipients is empty)."). Until the restart, e-mail stays as it was. | — | **Restart service** on the System page |
| The service starts with a problem | **Service started with problems**, listing the problems. Always, while e-mail is On. | Default recipients | **Send email alerts** |
| The service stopped unexpectedly and started again | An operational alert "Service recovered after an unexpected stop". A notice on the Dashboard and System page for 24 hours. | Default recipients | **Send email alerts** |
| An operator cancels a queued request | No e-mail. The ticket is updated according to the ServiceNow settings. If it was the last open code of a SailPoint ticket, no support report follows. | Nobody by e-mail | — |
| An operator retries a failed request and the outcome changes | The new outcome is e-mailed like any other. For a SailPoint ticket, a new support report shows the changed result. | As for the outcome | Outcome e-mails On |
| The requester cannot be found | The support report shows "-" for the requester. Nothing else changes. | Support report recipients | **Requester (申請者) shown in the support report** |
| CyberArk fails when the service starts | **CyberArk not available**, and **Service started with problems** naming the CyberArk problem. | Default recipients and CyberArk / identity team | **Send email alerts** |
| The relay refuses one of several recipients | The others receive the e-mail. The refused address is written to the log and recorded in the audit trail. | The accepted recipients | The recipient lists |
| The relay refuses the sender, or every recipient | The e-mail is not kept for resending, because resending cannot help. It is recorded in the audit trail as failed. | Nobody | **From address**, the recipient lists |
| You saved an e-mail setting and nothing changed | Most mail-server settings and switches apply only after a restart. The setting shows **Saved — applies after restart** until then. | — | **Restart service** on the System page |
| Test mode is on | Every e-mail goes only to the testers. Warning on the Dashboard and System page. | The testers only | **Send every e-mail only to (testing)** |

## 5.3 CyberArk and the service-account passwords

> **In plain words.** The bot signs in to Fujitsu Mainframe with one service account: an affiliation code, a staff code and an 8-character password. The codes are typed in once and stored on the server. The password can be stored the same way, or fetched automatically from CyberArk several times a day, so that a password changed in the vault reaches the bot without anyone typing it. The host expires the password after a number of days, so the bot also keeps track of its age for Fujitsu Mainframe and for Fujitsu RACF, e-mails a reminder before it expires and, for Fujitsu Mainframe only, can change it on the host. Separately, the bot can read its database password from CyberArk.

**Who does this:** Admin (switching CyberArk on, entering the connection, the date of the last password change, switching the automatic change on, **Validate database password**), Developer (advanced CyberArk options, the password-age limits, the password screen test and the password change from the console, the machine settings of the database password), CyberArk team (the safe, the account and the application ID), PAM team and database team (the database administrator account).

### Where the password comes from

| Source | When it is used | How the password reaches the bot |
|---|---|---|
| **Credentials** (on **Settings › This machine › Credentials**) | CyberArk is off | The value you type in **Service account — password** is kept in the Windows credential store of the account the service runs as. It is read when the service starts. |
| **CyberArk** | **Fetch the mainframe password from CyberArk** is On | The service fetches the password at start and then on a schedule. It is held in memory only and replaces the stored value while the service runs. |

The affiliation code and the staff code always come from **Credentials** (**Service account — affiliation code** and **Service account — staff code**). When you save them, the service checks that the affiliation code is 5 half-width digits (`<5-digit affiliation code>`) and that the staff code is 7 half-width letters or digits (`<7-character staff code>`). The password must be exactly 8 characters; this is checked when the service starts.

The **Terminal summary** on **Settings › Fujitsu Mainframe terminal** shows, under **Service account password from**, whether the running service uses **CyberArk**, **Credentials (this machine)** or **Not set**.

> **Important.** With the real terminal, the terminal is prepared when the service starts, **before** CyberArk is contacted. At that moment the service checks the service-account codes and the password. An 8-character service-account password must therefore already be stored under **Credentials** before the first start, even when CyberArk will supply the password afterwards. Without it, the System page reports that the terminal executor could not be built, and no request is processed until the password is stored and the service is restarted. Once CyberArk delivers, its password replaces the stored one in the running service.

### The two ways of talking to CyberArk

| **API** choice | What it is | What the CyberArk team provides |
|---|---|---|
| **ccp** (Central Credential Provider) | One request with the application ID. The vault decides from the allowed-machine rules, or from a client certificate, whether the bot may read the password. The usual choice for an unattended bot. | Application ID, safe, account object name (or account user name), allowed machine or client certificate |
| **pvwa** (PVWA REST) | The service signs in to the PVWA with its own CyberArk account, searches the account, retrieves the password and signs out. | A PVWA user name and password, the authentication type, safe, account object name (or account user name) |

The PVWA password is a credential: it is entered under **Settings › This machine › Credentials** as **CyberArk — PVWA service account password**, never on the CyberArk page.

### Settings (Settings › CyberArk)

| Setting | What it means | Default | Who can change it | Takes effect |
|---|---|---|---|---|
| **Fetch the mainframe password from CyberArk** | The main switch. Required in production with the real terminal. | Off | Admin | After a restart |
| **API** | **ccp** or **pvwa**, as above | ccp | Admin | After a restart |
| **Base URL** | The address of the vault, for example `https://<ccp-address>`. Checked as a web address when saved. Sample (QA): `https://pamccp.aig.net` | Empty | Admin | After a restart |
| **Verify TLS certificate** | Checks the vault's certificate. Cannot be switched off where CyberArk is required (production). | On | Developer | After a restart |
| **Client certificate (mutual TLS)** | The certificate file that identifies the bot to the vault (ccp only). The file must exist on the server. | Empty | Developer | After a restart |
| **Client private key** | The key file of that certificate (ccp only). The file must exist on the server. | Empty | Developer | After a restart |
| **Application ID** | The application ID registered for the bot (`<application ID>`). Sample (QA): `APP-10-SAILPOINT` (shared with SailPoint in QA; confirm with the PAM team) | Empty | Admin | After a restart |
| **Safe** | The safe that holds the service account (`<safe>`) | Empty | Admin | After a restart |
| **Account object name** | The account in the safe (`<account object>`). Use this or the account user name. | Empty | Admin | After a restart |
| **Account username** | The user name of the account, instead of the object name | Empty | Developer | After a restart |
| **PVWA username** | The CyberArk account the service signs in with (pvwa only) | Empty | Admin | After a restart |
| **PVWA authentication** | **CyberArk**, **LDAP** or **RADIUS** (pvwa only) | CyberArk | Developer | After a restart |
| **Refresh every (hours)** | How often the password is fetched again. From 0.25 to 24. | 4 | Developer | After a restart |
| **Check the vault is active before each fetch** | Confirms the vault answers before each fetch, so an outage is reported clearly | On | Developer | After a restart |

### A CyberArk certificate from an internal certificate authority

When the CyberArk address uses a certificate issued by the company's own certificate authority, the bot does not trust it out of the box, and every fetch fails with the vault reported as Inactive because of the certificate. The fix is a certificate file:

- **Where:** **Settings › This machine › Database › CyberArk certificate file (internal certificate authority)** (Developer; see 5.8). Despite its place in the Database group, the file is used for **every** CyberArk call: the Fujitsu Mainframe password, the Fujitsu RACF password and the database password.
- **How to make it:** **Create from Windows certificates**, next to the field, writes the certificate authorities this server already trusts (as the browser uses them) into one file in the data folder (`certs\cyberark-ca-bundle.pem`) and puts its path in the field. The message reads "Created `<path>` with `<n>` certificates from the Windows trusted store. Save and restart to use it."
- **Save check:** the file must exist on this machine, be readable and hold at least one certificate in PEM form. Otherwise nothing is saved and the message starts with "CyberArk certificate file:".
- **Takes effect:** after a restart. The file is used only while **Verify TLS certificate** is On. Empty: the built-in list of public certificate authorities.

**Sample (QA):** the file `C:\FINESIII\certs\aig-ca-bundle.pem`, in the settings file `CYBERARK_CA_BUNDLE=C:/FINESIII/certs/aig-ca-bundle.pem`. **Create from Windows certificates** writes `C:\FINESIII\data\certs\cyberark-ca-bundle.pem` instead.

### Test retrieval

**Test retrieval** on **Settings › CyberArk** uses the values on the page, before you save them. It checks that the vault answers and fetches the password once, with a 15-second time-out and no repeat. It never shows the password or its length: a success reads "Retrieved the password from `<address>` (`<API>`). The value is not shown." A failure comes with a hint, for example that the vault did not answer (check the base URL, TLS and network), that access was denied (application ID, allowed-machine rules, client certificate), or that the safe or account name should be checked. When the vault fails its availability check (Inactive), the message also gives the reason the check saw, for example that the certificate could not be verified. Every test is recorded in the audit trail.

A test of the **saved** settings that finds the vault not answering sends the CyberArk outage e-mail (once per outage), and a later passed test the recovery e-mail. Values not saved yet never send an e-mail.

The stored PVWA password is only sent to the address that is configured, and only with certificate checking on. To test another address, or without the certificate check, type the password into the test.

### When the password is fetched

- **At start.** The first fetch happens when the service starts.
- **On the schedule.** Then every **Refresh every (hours)**.
- **Sooner after a failure.** After a failed fetch the next try comes after 5 minutes (or after the regular interval, when that is shorter), because the password may have been rotated during the outage.
- **At once when Fujitsu Mainframe rejects the password.** See 5.5, "The password-rejected rule".
- **At once on request.** **Refresh CyberArk now** on the System page fetches it immediately. The message under the buttons, and the **CyberArk** card, show the outcome a few seconds later.

A successful fetch is used for the next sign-in without a restart.

### The CyberArk card on the System page

| Card shows | Meaning |
|---|---|
| **Connected** | The last fetch worked. The card shows when the password was fetched (JST). |
| **Unavailable** | The last fetch failed. The last good password stays in use. The card shows the reason in plain words; when the vault failed its availability check it reads "CyberArk did not pass its availability check; the password was not fetched". The real reason (for example a certificate the bot does not trust) is in the outage e-mail and the service log. |
| **Fallback password** | CyberArk has not delivered a password since the start; the service runs on the stored password |

A security notice also appears on the System page, under **Warnings › Security:**, when the vault is reached over a plain `http` address or without checking its certificate.

### When CyberArk is down

| Moment | What happens |
|---|---|
| **At start, with a stored password** | The service starts on the stored password (**Fallback password**). Where CyberArk is required (production with the real terminal), processing waits (**Waiting** on the Processing card) and resumes by itself once CyberArk delivers. |
| **At start, with no stored password** | CyberArk cannot start. The System page lists "CyberArk integration failed to start" under **Needs attention**. Where CyberArk is required, processing stays off until the cause is fixed and the service is restarted. |
| **During the day** | The last good password stays in use. The outage is logged as an error once, then as a warning while it lasts, and the next fetch is tried after 5 minutes. When e-mail is on, an outage notice ("CyberArk not available: the bot could not retrieve its password") and later a recovery notice go to the **Default recipients** and the **CyberArk / identity team**. The notice explains the reason in plain words, for example that the bot does not trust CyberArk's certificate. The database password from CyberArk has its own outage notice (see "The database password from CyberArk" below). |

### Switching CyberArk off

When **Fetch the mainframe password from CyberArk** is switched Off and the service is restarted (**Restart service** on the System page, or **Save and restart**), the bot stops using the password from CyberArk and the Fujitsu Mainframe password stored under **Settings › This machine › Credentials** is used again, as after a fresh start. The same applies to the Fujitsu RACF password when CyberArk no longer supplies it. A password typed under **Credentials** after CyberArk had delivered one is kept.

### The production rule

When **Service environment** is production and the real terminal is used, the mainframe password must come from CyberArk:

- **This machine** refuses to save the real terminal driver in production while CyberArk is off: "In production a real terminal driver requires the mainframe password to come from CyberArk — enable and test the CyberArk module first."
- If CyberArk is off or does not start, the service runs but does not process: "CyberArk is required here … but is not enabled or did not start. Enable it under Settings → CyberArk and restart …"
- **Verify TLS certificate** cannot be switched off there.

In the development environment none of this is enforced, and the stored password may be used on its own.

### When the mainframe password is rotated

- **With CyberArk.** Nothing to do. The rotated password is picked up at the next scheduled fetch, or at once when Fujitsu Mainframe rejects the old one. To be sure before the next request, press **Refresh CyberArk now**. CyberArk owns the password, so the bot neither tracks its age nor changes it.
- **Without CyberArk, changed by the bot.** Use **Change service-account password** (see "Changing the Fujitsu Mainframe password from the console" below), or let the automatic change do it. The bot stores the new password and uses it at once; no restart is needed, and the password age starts again from that day.
- **Without CyberArk, changed by someone else.** Type the new password under **Settings › This machine › Credentials**, save, and restart the service (**Restart service** on the System page): the password is read when the service starts. Enter the date of the change in **Service-account password: last changed on** (see "Password age and reminders"). Then retry any request that failed on the old password, if its ticket is still open.

### Password age and reminders

> **In plain words.** The host expires a service-account password after 90 days. The bot works out the age of the password from the date of its last change and, from day 80, e-mails a reminder every day until the password is changed. A few days before the expiry the reminder becomes urgent, and after the expiry it says so. This applies to the Fujitsu Mainframe service account and to the Fujitsu RACF sign-on ID, each with its own settings.

**Who does this:** Admin (the date of the last change), Developer (the limits, **Check password age now**).

The settings are on the page of each application: **Settings › Fujitsu Mainframe terminal** and **Settings › Fujitsu RACF terminal and sign-on**. The RACF settings are shown while Fujitsu RACF is switched on.

| Setting (Fujitsu Mainframe / Fujitsu RACF) | What it means | Default | Who can change it | Takes effect |
|---|---|---|---|---|
| **Service-account password: last changed on** / **RACF sign-on ID password: last changed on** | The date of the last change (YYYY-MM-DD; YYYY/MM/DD is also accepted), entered once when the bot does not know it, for example after the password was set by hand. Any other form is refused when saved: "enter the date as YYYY-MM-DD". | Empty | Admin | At once (next check) |
| **Service-account password: expires after (days)** / **RACF sign-on ID password: expires after (days)** | The host expires the password after this many days. From 1 to 3650. | 90 | Developer | At once (next check) |
| **Service-account password: change after (days)** / **RACF sign-on ID password: change after (days)** | From this age the change is due. Must be less than the expiry; when it is not, the bot uses 10 days before the expiry. | 80 | Developer | At once (next check) |
| **Service-account password: urgent e-mail (days before expiry)** / **RACF sign-on ID password: urgent e-mail (days before expiry)** | From this many days before the expiry the reminder becomes urgent. From 0 to 60. | 5 | Developer | At once (next check) |
| **Service-account password: change automatically** | Fujitsu Mainframe only. See "Automatic change of the Fujitsu Mainframe password". | Off | Admin | At once (next check) |
| **Service-account password: stop after failed tries** | Fujitsu Mainframe only. Failed automatic changes in a row before the bot stops trying. From 1 to 10. | 2 | Developer | At once (next check) |
| **RACF sign-on ID password: change automatically** / **RACF sign-on ID password: stop after failed tries** | Not available for Fujitsu RACF: the bot only tracks the age and e-mails reminders. Leave Off. | Off / 2 | Developer | Has no effect |

**How the age is counted.** The age counts from the **later** of two dates: the date of the last change the bot made itself (it records every change it makes), and the date entered in **last changed on**. So after the bot has changed the password, an older date in the setting no longer matters. When neither date is known, the bot cannot track the age and sends no reminder.

**How often.** The bot checks both applications every hour, the first time about 10 minutes after the service starts. Each kind of reminder is e-mailed at most once a day, so a due password brings one e-mail a day until it is changed.

| State | When | E-mail subject |
|---|---|---|
| Not due | Younger than **change after (days)** | None |
| Change due | From **change after (days)**, while the automatic change is off or not available | "`<system>` service-account password change due" |
| Expires soon | From **urgent e-mail (days before expiry)** days before the expiry | "URGENT: `<system>` service-account password expires soon" |
| Expired | On or after the expiry day | "URGENT: `<system>` service-account password has expired" |
| Automatic change stopped | Fujitsu Mainframe, after the automatic change failed (see below) | "URGENT: `<system>` automatic password change stopped" |

Each e-mail gives the last change, the age in days, the expiry date and the days left, and says what to do next. It never contains a password. For Fujitsu RACF it asks the RACF administrators to change the password, then to enter the new password under **Settings › This machine › Credentials** (**Fujitsu RACF service account — password**) and the date in **RACF sign-on ID password: last changed on**.

**Who receives the reminders.** The **Default recipients**, the **CyberArk / identity team** (with its CC list) and the **Support report recipients**, when e-mail is on. While **Send every e-mail only to (testing)** is set, they go only to those addresses.

**Where to see the age.** The **Tests** row of **Settings › Fujitsu Mainframe terminal** and of **Settings › Fujitsu RACF terminal and sign-on** shows one line, for example "Password last changed `<date>` (`<n>` days ago); expires `<date>` (`<n>` days left); automatic change off; a reminder is e-mailed from `<date>`." When the date is not known it reads "Password age: not known. Enter "last changed on" (Settings) so the bot can track the 90-day expiry." While CyberArk supplies the Fujitsu Mainframe password it reads "Password: supplied and changed by CyberArk." (no reminders are sent then).

**Check password age now** (Developer, in the same **Tests** row) runs the hourly check once at once, with every condition unchanged. It first answers "Password age check started. The result shows in the password-age line and the audit trail in a moment; a change takes a few minutes." and, as soon as the check has finished, shows its result, for example "Password age check: change due; a reminder was e-mailed." or "Password age check: not due yet, nothing to do." While a check is running, another one is refused ("A password age check is already running; try again when it has finished."). When the automatic change is on and the password is due, this check can change the password, exactly as the hourly check would.

**How to test the reminders.**

1. Keep **Service-account password: change automatically** **Off**, so the test cannot change the real password.
2. Optionally set **Send every e-mail only to (testing)** to your own address.
3. Enter a back-dated **last changed on**, for example 82 days ago (change due), 87 days ago (expires soon) or 91 days ago (expired), with the default limits.
4. Press **Check password age now** and wait for the result line.
5. Put the real date back afterwards, and clear the test address.

The reminder of one kind is sent once a day: a second test of the same kind on the same day sends no e-mail. A back-dated date has no effect when the bot itself recorded a later change.

### Automatic change of the Fujitsu Mainframe password

> **In plain words.** When switched on, the bot changes its own Fujitsu Mainframe password on Task 0890 once the password is old enough, with a new password it generates, and tells the support teams by e-mail. It is off by default.

**Who does this:** Admin (**Service-account password: change automatically**), Developer (the limits).

- **When it runs.** At the hourly check, once the password has reached **change after (days)** and before it has expired. At most one try a day. An expired password is not changed automatically; only the "expired" e-mail is sent.
- **When it does not start.** The check simply tries again later when the credential store is not available, when the password is not kept in the credential store, when the password was changed in the last 24 hours, outside the Fujitsu Mainframe operating hours, while Fujitsu Mainframe is not ready (centre not ready or a line error), or while an administrator has paused processing. When the password is already in the urgent period, the urgent e-mail names the reason.
- **What it does.** It holds new requests (processing shows as paused by "Automatic password change"), waits up to 30 minutes for a request in progress to finish (if one is still running, it gives up for this check and tries again later), generates a new password that follows the rules below, and runs the same change as the console (see the next subsection). Processing is resumed afterwards, unless someone else paused it in the meantime.
- **The e-mail.** "Fujitsu Mainframe service-account password changed" or "... not changed", with "How: Changed automatically by the bot, based on the password's age", to the same recipients as the console change.
- **Failure limit.** After **Service-account password: stop after failed tries** failed changes in a row (2 by default), the bot stops trying and sends "URGENT: Fujitsu Mainframe automatic password change stopped". The age line says "Automatic change stopped after `<n>` failed tries: change it here." A successful change from the console starts the automatic change again.
- **What stops it at once.** When the host refuses the current password at sign-in, the bot stops trying straight away, because another sign-in with that password could lock the account (the host locks it after about 3 wrong passwords).
- **Not possible with CyberArk.** While CyberArk supplies the Fujitsu Mainframe password, CyberArk changes it: the bot never changes it, and the setting has no effect.
- **Fujitsu RACF.** The bot cannot change the RACF sign-on ID password. For Fujitsu RACF it sends the reminders only.

### Changing the Fujitsu Mainframe password from the console (Task 0890)

> **In plain words.** A Developer can let the bot change its own Fujitsu Mainframe password. The bot signs in, opens Task 0890 (パスワードの登録と変更), types the current and the new password and confirms. It keeps the new password safe before it submits it and only starts using it once the host confirms the change.

**Who does this:** Developer. The buttons are not shown to other roles.

**Where.** **Settings › Fujitsu Mainframe terminal**, **Tests** row:

| Button | What it does |
|---|---|
| **Test password screen** | Signs in once with the service account, opens Task 0890, reads it and signs off. Nothing is typed on Task 0890. A wrong password counts toward the account lock-out. |
| **Change service-account password** | Opens the form below and changes the password on Task 0890 |

**The form.** **Current password**, **New password** and **Confirm new password**, then **Change password** (or **Cancel**). The fields are never remembered and are cleared as soon as the form is sent. After an automatic change nobody knows the current password: a Developer may then leave **Current password** empty, and the bot uses the one it holds; this is recorded in the audit trail. A confirmation box explains what will happen before anything starts.

**Password rules.** The new password must be:

- exactly 8 half-width characters, without spaces;
- a letter first, with at least one letter and one digit;
- symbols only from `@ # $ & * - _ = ! ? .` (other symbols act as key combinations on the terminal);
- different from the current password, and without the service account's staff code;
- typed the same twice.

The bot checks the rules before it signs in; the host still decides last.

**What is refused, and what the console says.** Every check below comes before the bot signs in, so none of them uses up a sign-in attempt on the host.

| Refused when | What the console says |
|---|---|
| Fujitsu Mainframe showed centre not ready or a line error | "Fujitsu Mainframe is not ready (it showed centre not ready or a line error); try again after it answers. Test sign-in and navigation shows when it does." (also for **Test password screen**) |
| CyberArk supplies the password | "The service-account password comes from CyberArk, which changes it: the bot does not change it itself." |
| The credential store is not available, or the password is not kept there | The credential store is not available on this machine, or the password is not kept in the credential store of this service, so the new one could not be stored where the bot reads it |
| The password was changed less than 24 hours ago | "The password was changed on `<date time>` (JST); the next change is possible 24 hours after it." |
| The current password is wrong | "The current password is not correct (`<n>` more attempt(s) before the change is locked)." The entry is compared with the password the bot holds, never tried on the host. |
| The current password was wrong 3 times | The form is locked for 15 minutes: "The current password was entered wrong 3 times; the change is possible again in `<n>` minute(s)." An alert is logged. |
| A password rule is broken | The first rule broken, for example "The new password must start with a letter." |
| Processing is not paused | "Pause processing first (System page > Pause processing), so no request starts during the check." |
| A request is still running, another terminal check or the scheduled sign-in check is running | The console asks you to wait and try again |
| The last sign-in check failed a short time ago | The next sign-in is possible after a few minutes, to protect the account from a lock-out |
| Outside the operating window | "Outside the operating window: Fujitsu Mainframe does not accept sign-ins now." |
| The mainframe host does not answer | "The mainframe host does not answer (…); the sign-in is not attempted." |

Leaving **Current password** empty is not counted as a wrong entry, so the 15-minute lock applies only to current passwords that are typed.

**The steps on Task 0890.** The bot signs in as for a request, opens Task 0890, types the current password in row 101 (現在のパスワード; the terminal does not show it), the new password in row 102 (変更後), and checks that row 102 holds the new password before it types `00`. If row 102 is read empty, `00` is not sent and nothing is changed. It then reads the result screen and signs off.

**The pending password.** Before `00` is sent, the new password is kept in the credential store as a *pending* password. It becomes the service account's password only when the result screen shows 終了状況 正常終了. When the host gives a reason under 不備理由, the pending password is dropped. When the result cannot be read, one sign-in with the new password settles it. If even that is not possible, the password stays pending, and the next **Change service-account password** first settles it with one sign-in before it does anything else.

| Case | What happens |
|---|---|
| The host shows 正常終了 | Changed. The new password is stored and used from now on, without a restart. The "changed" e-mail is sent. The password age starts again from today. |
| The host gives a reason (不備理由) | Not changed. The current password stays. The "not changed" e-mail gives the host's reason. |
| The result screen cannot be read; a sign-in with the new password works | Changed. The e-mail says the result screen could not be read and a sign-in with the new password succeeded. |
| The result screen cannot be read; the host refuses the new password | Not changed. The current password stays. |
| The result cannot be confirmed at all | "The result could not be confirmed. The new password is kept pending …" No e-mail. Try again later: the next change first finds out whether the pending password is in use. |
| The result cannot be confirmed and the bot could not sign off | As above, and the console asks you to close Fujitsu Mainframe on the server before trying again |
| Row 102 does not show the new password | `00` is not sent; not changed; no e-mail |
| The change stops before anything is submitted | Not changed; the current password stays; no e-mail |
| An earlier change was left pending | The next change signs in once with the pending password. If it works, it becomes the password and the password entered now is not used. If the host refuses it, it is dropped and the new change goes on. |
| The credential store did not save the new password | The service uses it until it restarts. Run the change again to store it. |

**After the change.** Processing stays paused: resume it on the System page (**Resume processing**). The message on the page gives the outcome in plain words; **Show details** lists the steps and the screenshots folder.

**The evidence.** Each change keeps screenshots of Task 0890 when it opens, after the password is typed, when `00` is typed and of the result screen, with the password fields blacked out (see 5.6), and the text read from the opened screen. Every change is recorded in the audit trail, never with a password.

**The e-mails.** "Fujitsu Mainframe service-account password changed" or "Fujitsu Mainframe service-account password not changed" goes to the **Default recipients**, the **CyberArk / identity team** and the **Support report recipients**, when e-mail is on. It is sent only when the change was submitted and its result is known. It lists the service account (affiliation / staff code), who changed it, how (entered on the console, or automatic), the result and the evidence folder. It never contains the password.

### The database password from CyberArk

> **In plain words.** On Amazon RDS the PAM team keeps the database administrator account in CyberArk and changes its password regularly. The bot does not work with that account. It works with its own database login and gives it the same password as the administrator account. So no database password for the bot needs to be stored on the server, and a password change in CyberArk reaches the bot by itself. Requests keep running while this happens, and the bot tells the support teams by e-mail each time a new password is in use.

**Who does this:** Developer (switching it on and the settings: **Settings › This machine › Database**, see 5.8), Admin and Developer (**Validate database password**), PAM team (the account in CyberArk, the application ID allowed from this server), database team (the right of the administrator account to set the bot's password).

**What the bot does.**

- **At every start** it reads the administrator password from CyberArk and checks that its own login accepts it. If not, it signs in once as the administrator and gives its own login the same password. The password is sent to the database in protected form only, so it never appears in the database server's logs. If CyberArk or the database does not answer, the bot keeps trying for up to 5 minutes; without the password the service does not start, and the reason is in the service log.
- **Every 15 minutes** (**CyberArk check interval (minutes)** in **Settings › This machine › Database**) it asks CyberArk whether the password changed, and copies a changed password the same way.
- **At once** when the database refuses the bot's sign-in (at most once a minute). If CyberArk still holds the same password, the bot's login was given another password outside CyberArk: the bot sets it back to the password in CyberArk (see the table below).
- **When a copy fails**, the bot keeps the password in use and tries again one minute later. After 3 failed tries in a row it sends a notice, and it keeps trying at every check. The first check that works again ends the problem by itself: no button needs to be pressed.
- While CyberArk reports that it is changing the password, the bot keeps the password in use, waits a minute and asks again.
- **When the setting is switched off** and the service is restarted from the console, the copy stops and the database password stored in the credential store is used again.

**Requests in progress.** A password change does not interrupt them. Connections that are already open continue; new connections use the new password. A connection refused because of its password is tried once more with the newest password.

**The Database password card (System page).** The card is shown only while the database password comes from CyberArk. It never shows a login name or a password. Its status says which password the bot uses:

| Card shows | Meaning |
|---|---|
| **Latest password from CyberArk** | The bot uses the password CyberArk holds now. The card is green unless a check met a problem, which is then named. |
| **Previous password in use** | CyberArk holds a newer password that the bot could not apply yet, for example because CyberArk is changing it right now or the copy to the bot's login failed. The reason is named; the bot tries again at every check. |
| **CyberArk not reachable** | CyberArk did not answer. The bot keeps the last password it received; whether CyberArk holds a newer one cannot be known until it answers. |

Below the status the card shows these lines, each only when it applies:

- "Password in use: the latest from CyberArk, in use since `<time>` JST.", "Password in use: the previous password, in use since `<time>` JST. CyberArk has a newer one, which the bot tries again to apply (every `<n>` min)." or "Password in use: the last one received from CyberArk, in use since `<time>` JST. Whether CyberArk has a newer one cannot be checked until it answers.";
- the reason, in plain words, when the latest password is not in use;
- "Changed in CyberArk: `<time>` JST";
- "Last successful check: `<time>` JST (every `<n>` min)";
- "Next check: `<time>` JST" (the scheduled check, or the check one minute after a failure when that comes first);
- "Last attempt failed: `<time>` JST", while the most recent attempt failed;
- a problem in plain words that did not change the password in use, for example that the database did not answer a check.

**Validate database password.** The button has the same label on the System page (shown while the database password comes from CyberArk) and on **Settings › This machine › Database**, on the **Database URL** row. An Admin or a Developer can use it. It checks at once: it reads the password from CyberArk, compares it with the one in use and checks that the bot's login accepts it. A newer password, or one the bot's login refuses, is copied and used from then on. Requests keep running. It can be used once every 30 seconds.

| Case | What the console says |
|---|---|
| Same password, accepted | "Password validated. The bot uses the latest password from CyberArk." |
| A newer password, or the bot's login had another one | "Password validated and updated. The bot now uses the latest password from CyberArk; new connections use it." |
| CyberArk is changing the password | "CyberArk is changing the password right now. The bot keeps using the password it has until the change is finished; try again in a minute." |
| CyberArk does not answer, or returns another account | "Not checked: `<reason>`." followed by the sentence saying which password is in use |
| The database cannot be checked, or the new password cannot be applied | "The password could not be checked with the database: `<reason>`." or "The new password from CyberArk could not be applied: `<reason>`.", followed by the sentence saying which password is in use |
| Pressed again within 30 seconds | "A check ran a moment ago; try again in `<n>` seconds." followed by the sentence saying which password is in use |
| The database password does not come from CyberArk | "The database password does not come from CyberArk on this server: the machine setting "Database password from CyberArk" is off. The bot uses the stored database password." |

**The e-mails.** They are sent while e-mail is on, never contain a password or a login name, and appear on the **E-mail samples** page of **Settings › E-mail** (section 6).

| E-mail subject | When | To |
|---|---|---|
| "Database password changed: the bot uses the new password" | Each time a new password from CyberArk is in use, whichever way it was found. It names when the password changed in CyberArk, how the bot found it (scheduled check, check after the database refused a sign-in, **Validate database password** on the console, bot start, service restart from the console), whether the bot's login was given the new password, and how often CyberArk is checked. The impact is none. There is no setting for it. | **Default recipients**, and the **Database team** when its addresses are set |
| "Bot's database login set back to the password in CyberArk" | The bot's login refused the unchanged password in CyberArk, so its password was changed outside CyberArk; the bot set it back and continues. The e-mail asks the database team to find out who changed it. | **Default recipients** and the **Database team** |
| "Database password not updated: the bot keeps working with the password in use" | A new password could not be given to the bot's login after 3 tries. It says that requests continue with the password in use, and that processing stops only if the database stops accepting that password. It asks the PAM team and the database team to check the accounts, then to use **Validate database password**. | **Default recipients** and the **Database team** |
| "Database password updated: the bot uses the current password from CyberArk" | The first check that works after that notice. A **Found by** row says how (scheduled check, check after a refused sign-in, or **Validate database password**). | Same as above |
| "CyberArk not available: the database password could not be checked" | CyberArk did not answer the bot's check of the database password, refused it, or its certificate is not trusted. It says that requests continue with the password received most recently, and points to **Settings › This machine › Database** (address, **Test CyberArk retrieval**, **CyberArk certificate file (internal certificate authority)**). | **Default recipients** and the **CyberArk / identity team** |
| "CyberArk (database password) Recovered" | CyberArk answers the check again | Same as above |

The two outages are kept apart from each other, from the database outage and from the CyberArk outage of the Fujitsu Mainframe password, so one never hides or closes the other. An open CyberArk outage of the database password is remembered over a restart, so its recovery e-mail still follows.

**The audit trail.** Every event below is recorded in the **system** category, with "source: CyberArk", never with a password or a login name. The automatic events are recorded under the actor **system**; the two console events under the name of the person.

| Event | When | Severity |
|---|---|---|
| `database_password_in_use` | The service started its checks of the database password | INFO |
| `database_password_changed` | A new password is in use, with how it was found (`scheduled_check`, `refused_sign_in`, `validate_button`, `service_start` or `restart`) and when it changed in CyberArk | INFO |
| `database_password_reapplied` | The bot's login was set back to the password in CyberArk | WARNING |
| `database_password_update_failed` | A new password could not be given to the bot's login after 3 tries | ERROR |
| `database_password_update_recovered` | That problem ended, with how it was found | INFO |
| `database_password_cyberark_unavailable` / `database_password_cyberark_recovered` | CyberArk did not answer the check, and answers again | WARNING / INFO |
| `database_password_validated` | Every click of **Validate database password**, with its result (`validated`, `updated`, `busy`, `unavailable`, `failed`, `wait` or `not_in_use`) | INFO, or WARNING when the check did not succeed |
| `database_password_source_changed` | **Restart service** switched the database password from CyberArk on or off | INFO |

**Good and bad cases.**

| Case | What happens |
|---|---|
| CPM changes the administrator password during the day | [OK] Within 15 minutes the bot gives its login the new password and uses it; requests keep running. "Database password changed" e-mail. |
| The password changed in CyberArk while the bot was stopped | [OK] At the start the bot gives its login the new password. "Database password changed" e-mail, found at the bot start. |
| The database refuses the bot's sign-in after a change | [OK] The bot asks CyberArk at once, uses the new password and tries the connection once more. |
| Someone changed the bot's login password in the database by hand | [OK] At the next refused sign-in, or at **Validate database password**, the bot sets it back to the password in CyberArk and continues. [NG] for the process: "Bot's database login set back" e-mail; the database team finds out who changed it. |
| CyberArk is changing the password at the moment of the check | [OK] The card shows **Previous password in use**; the bot asks again a minute later. |
| The administrator account refuses the password from CyberArk, or may not change the bot's password | [NG] The card shows **Previous password in use** with the reason. After 3 tries the "not updated" e-mail; requests continue with the password in use. The first good check ends it by itself and sends the "updated" e-mail. |
| CyberArk does not answer during the day | [NG] The card shows **CyberArk not reachable**; the "CyberArk not available: the database password could not be checked" e-mail. Requests continue with the password received most recently; the recovery e-mail follows when CyberArk answers. |
| CyberArk rotates the password while it does not answer, and the database stops accepting the old one | [NG] The bot can no longer use the database and processing stops, until CyberArk answers again. |
| No password within 5 minutes at start | [NG] The service does not start; the reason is in the service log; the scheduled task starts the service again later. |
| **Save and restart** while CyberArk does not answer, the database password settings unchanged | [OK] The service restarts with the password in use. |
| **Save and restart** after the database password settings were changed, and CyberArk cannot deliver | [NG] Nothing restarts: "Not restarted: the database password from CyberArk could not be obtained: `<reason>`. The service keeps running as it was." Correct the settings (or switch the setting Off) and restart again. |

**Going back** to a password stored on the server: switch **Database password from CyberArk** off in **Settings › This machine › Database**, give the bot's login a password of its own with the database setup tool, and restart (see 5.8).

### Common situations

| Situation | What the bot does | Who is told | Which setting decides |
|---|---|---|---|
| The vault is down for an hour during the day | Keeps signing in with the last good password; tries the vault again every 5 minutes | Outage and recovery e-mails (when e-mail is on) to the default recipients and the CyberArk / identity team | **Check the vault is active before each fetch**, **Refresh every (hours)** |
| CyberArk is unreachable when the service starts | Starts on the stored password; in production holds processing until CyberArk delivers, then resumes by itself | System page; outage e-mail | **Fetch the mainframe password from CyberArk**, **Service environment** |
| The CyberArk team rotates the password | Uses the new one at the next fetch, or at once after a rejection | Nobody | **Refresh every (hours)** |
| **Test retrieval** says access was denied | Nothing is saved or changed | The person who ran the test | **Application ID**, client certificate, allowed-machine rules in CyberArk |
| CyberArk is reported Inactive with a certificate reason | Fetches fail; the last good password stays in use | Outage e-mail naming the certificate | **CyberArk certificate file (internal certificate authority)**, **Create from Windows certificates** |
| CyberArk is switched on but no password was stored under Credentials (real terminal) | Does not build the terminal; nothing is processed | System page: "Terminal executor could not be built" | **Credentials** |
| You try to switch off **Verify TLS certificate** in production | Refuses the save | The person saving | **Service environment** |
| The Fujitsu Mainframe password reaches day 80 with the automatic change off | E-mails "change due" once a day | Default recipients, CyberArk / identity team, support report recipients | **Service-account password: change after (days)** |
| The password age line says "not known" | Sends no reminder | Nobody | **Service-account password: last changed on** / **RACF sign-on ID password: last changed on** |
| The Fujitsu RACF password is due | E-mails a reminder; cannot change it | Same as above | **RACF sign-on ID password: change after (days)** |
| The automatic change fails twice in a row | Stops trying; asks for a change on the console | "Automatic password change stopped" e-mail | **Service-account password: stop after failed tries** |
| The host refuses the current password during the automatic change | Stops trying at once, to avoid a lock-out | "Automatic password change stopped" e-mail | None: always |
| **Change service-account password** while processing runs | Refuses; nothing is typed | The person on the console | Pause processing first |
| **Change service-account password** while CyberArk supplies the password | Refuses: CyberArk owns the password | The person on the console | **Fetch the mainframe password from CyberArk** |
| The current password is typed wrong three times | Locks the form for 15 minutes; the host is never tried | The person on the console; an alert is logged | None: always |
| The result of a change cannot be read | One sign-in with the new password settles it; otherwise the password stays pending until the next change | The person on the console; e-mail when the result is known | None: always |
| CPM rotates the database administrator password | Copies it to the bot's login within 15 minutes; requests keep running | "Database password changed" e-mail to the default recipients and the Database team | **CyberArk check interval (minutes)** in **Settings › This machine › Database** |
| The database password copy keeps failing | Keeps the password in use; notice after 3 tries; ends by itself at the first good check | "Database password not updated" and later "Database password updated" to the default recipients and the Database team | The administrator account in CyberArk and its rights |
| The bot's database login was given another password by hand | Sets it back to the password in CyberArk at the next refused sign-in or **Validate database password** | "Bot's database login set back to the password in CyberArk" to the default recipients and the Database team | None: the login's password must only be set by the bot |
| CyberArk does not answer the database password check | Keeps the password received most recently; requests keep running | "CyberArk not available: the database password could not be checked", then "CyberArk (database password) Recovered", to the default recipients and the CyberArk / identity team | **CyberArk address (database)**, **CyberArk certificate file (internal certificate authority)** |
| You want to know which database password the bot uses | Shows it on the **Database password** card; **Validate database password** checks it at once | The person on the console | None |
| **Fetch the mainframe password from CyberArk** is switched Off and the service restarted | Uses the password stored under **Credentials** again | Nobody | **Fetch the mainframe password from CyberArk** |

**Limitations.** The bot cannot change the Fujitsu RACF password. One server with its own credential store is covered; several servers that each keep their own copy of the service-account password are not kept in step by the bot.

---
## 5.4 The Fujitsu Mainframe terminal

> **In plain words.** The bot works the Fujitsu Mainframe terminal on the server exactly as a person would: it starts the program from its desktop shortcut, types into its windows and reads the screen. For training and testing, the same steps can run against a simulated terminal, so nothing reaches Fujitsu Mainframe.

**Who does this:** Developer (choosing the driver), Admin (shortcut and administrator setting, tests), Server team (the Windows account and the desktop session).

### The terminal drivers

The driver is chosen under **Settings › This machine › Deployment › Terminal driver**. The list shows the technical names; the System page and the **Terminal summary** show the names in brackets below.

| Driver (System page name) | What it does | When to use it |
|---|---|---|
| **Pywinauto** (**Fujitsu Mainframe terminal**) | Starts and types into the real Fujitsu Mainframe terminal on Windows | Production and acceptance against Fujitsu Mainframe |
| **Pyautogui** (**Screen automation**) | Real terminal through screen automation | Fallback only, when agreed |
| **Tn3270** (**TN3270 terminal**) | Needs extra components that are not part of the installation | Not used in a standard installation |
| **Sim terminal** (**Terminal simulator**) | A visible simulated terminal window for every request, with the full bot logic | Demonstrations and training |
| **Mock** (**Test double**) | The full bot logic against an invisible simulated terminal | Automated tests and checks |
| **Simulator** (**Simulator**) | No terminal at all: every request ends successfully after a short delay, without screenshots | Checking the queue, e-mails and tickets end to end |

A driver that cannot run on the server (for example the real terminal on a machine without its components) is refused when you save it. The simulated drivers sign in with a built-in test account, so they need no service account. The real drivers never use it.

The development environment uses **Simulator** by default; production uses **Pywinauto**.

### Settings (Settings › Fujitsu Mainframe terminal)

The page is in the **Fujitsu Mainframe** area of the Settings navigation.

| Setting | What it means | Default | Who can change it | Takes effect |
|---|---|---|---|---|
| **Launcher shortcut** | The full location of the Windows shortcut that starts the terminal | The オンライン業務 shortcut on the public desktop | Admin | After a restart |
| **Terminal program (instead of the shortcut)** | The program itself, when it is started directly | Empty | Developer | After a restart |
| **Menu window title contains** | Text in the title of the menu window the bot attaches to | 基幹業務 | Developer | After a restart |
| **Terminal window class** | The window class of the terminal | F3BJMD101 | Developer | After a restart |
| **Start the terminal as administrator** | On: the shortcut is opened as administrator, as with right-click › Run as administrator. Off: it is opened normally. | On | Admin | After a restart |
| **Service-account password: change automatically** | On: once the password is old enough, the bot changes it itself on Task 0890. Off: the bot only e-mails a reminder when the change is due. | Off | Admin | At once |
| **Service-account password: last changed on** | The date of the last change (YYYY-MM-DD), entered once when the bot does not know it | Empty | Admin | At once |
| **Service-account password: expires after (days)** | When the host expires the password | 90 | Developer | At once |
| **Service-account password: change after (days)** | From this age the change is due; must be less than the expiry | 80 | Developer | At once |
| **Service-account password: urgent e-mail (days before expiry)** | From this many days before the expiry an urgent e-mail is sent every day | 5 | Developer | At once |
| **Service-account password: stop after failed tries** | Failed automatic changes in a row before the bot stops trying and asks for a change on the console | 2 | Developer | At once |

The service-account password settings, the reminders and the automatic change are explained in 5.3. When no shortcut location is set, or the location does not exist, the bot looks for the shortcut on the desktop of the bot's Windows account and then on the public desktop. If a terminal menu window is already open, the bot attaches to it instead of starting another one.

### What "Start the terminal as administrator" needs

Windows lets only a program that runs as administrator type into a window that runs as administrator. So with this setting On, **the service itself must run as administrator** (for example as a scheduled task with highest privileges); it then starts the terminal without a consent prompt. If the elevated start fails, the request fails with "The Fujitsu Mainframe terminal could not be started as administrator … Start the bot from a window opened with 'Run as administrator'."

The **Terminal summary (as the service runs now)** on the same page shows **Terminal driver**, **Mainframe environment**, **Screen reading (OCR)**, **Service account password from**, **Terminal started as administrator** and **This service runs as administrator**. When **Terminal started as administrator** is Yes and **This service runs as administrator** is No, a warning explains that Windows will not let the bot type into the terminal. Either start the service with highest privileges, or switch the setting Off if the terminal does not need administrator rights.

**Sample (QA):** the service runs as the scheduled task `FINESIII RPA Agent`, which the unattended operation set-up registers with highest privileges, under the bot account `R6-CORE\prvrnel` on `qwawosis1001`.

The setting applies when the terminal is started from its shortcut. A **Terminal program** set on the page is started directly, without it.

### The terminal tests

The **Tests** row of the Fujitsu Mainframe terminal page offers these tests:

| Test | What it does | Before you run it |
|---|---|---|
| **Test mainframe host** | Connects to the mainframe host and port; never signs in. Uses the values on the page. With no host set it reports that the host is assumed reachable. | Nothing |
| **Test terminal launch** | Starts the terminal, deals with any error dialog, reads the Core Business Menu once, then closes it with `99` and `XX`, as the normal sign-off does. Never signs in. A printout Fujitsu Mainframe releases at the end is saved. | Processing paused (**Pause processing** on the System page), no request running, no other check running |
| **Test sign-in and navigation** | Starts the terminal, opens Fujitsu Mainframe, signs in once with the service account, opens Task 903, reads the screen to confirm that Task 903 is showing, then signs off. Never types account data, never sends `00` at the execution field or `70`. | As above, plus: you confirm the sign-in; inside the operating window; the mainframe host answers; CyberArk has delivered (when in use); at least 10 minutes since a test that could not sign in |
| **Test password screen** (Developer) | Signs in and opens Task 0890 (password registration and change) without typing on it, then signs off. See 5.3, "Changing the Fujitsu Mainframe password from the console (Task 0890)". | As for **Test sign-in and navigation** |
| **Change service-account password** (Developer) | Changes the service-account password on Task 0890. Fully described in 5.3, "Changing the Fujitsu Mainframe password from the console (Task 0890)". | Processing paused; the other conditions are in 5.3 |

**How a screen is confirmed.** The tests do not rely on the window title alone, because the business menu and every task screen share the same window title and task number field. A screen is confirmed only when enough of its **own** identifying words are read on it. **Test terminal launch** reports "Confirmed: n of m words found" for the Core Business Menu; when the menu cannot be read, it adds a note ("Not confirmed …") but the start itself still counts as passed. **Test sign-in and navigation** fails at the step "Read the screen: Task 903 showing" when another known screen is showing instead ("Task 903 not confirmed: the terminal shows …").

Each test answers with one plain sentence ("… passed: …" or "… failed: …"). **Show details** lists the steps with the seconds each took, the step that failed with a hint, where the sign-off stopped if it did, the terminal program used and the setting the service started with. The screenshots are kept in an evidence folder of the test's own, named after the test and its time. Every test is recorded in the audit trail. For the Developer, the same row shows the age of the service-account password and a **Check password age now** button (see 5.3).

> **Tip.** The terminal tests use the settings the service was started with, not unsaved values on the page. Save and restart before testing a changed terminal setting.

After a sign-in test that could not sign in, the next sign-in test is refused for 10 minutes ("The last check could not sign in … possible in N minute(s); check the password first."), because a wrong password counts towards the lock-out of the service account. This wait survives a restart; saving a new service-account value under **Credentials** lifts it. While a test runs, **Resume processing**, **Restart service** and **Stop the bot** are refused.

A test can also change what the bot does with new requests, exactly as a request would:

- A terminal that does not start in **Test terminal launch** holds new Fujitsu Mainframe requests until it starts (see 5.5, "When Fujitsu Mainframe is not available").
- Centre not ready (センター準備中) or a line error (回線エラー) at the sign-in holds new Fujitsu Mainframe requests in the same way, and a passed **Test sign-in and navigation** releases them at once.
- A test of the saved settings that finds Fujitsu Mainframe unavailable sends the outage e-mail to its usual recipients (once per outage); a later passed test sends the recovery e-mail.
- A sign-in refused with a recognised message (for example a wrong password or an operator code that is not registered) sends the same e-mail as for a request to the team that owns the service account.

### Moving from testing to the real terminal

1. **Service account.** Under **Settings › This machine › Credentials**, store the affiliation code, the staff code and an 8-character password (see 5.3, also when CyberArk will be used).
2. **CyberArk** (production). Set it up under **Settings › CyberArk**, run **Test retrieval**, and switch **Fetch the mainframe password from CyberArk** On.
3. **Screen reading.** Make sure **Read screens with OCR** (**Settings › Screen reading**) and **Screen reading (OCR)** (**Settings › This machine › Screen reading (start-up)**) are On. The real terminal is refused without it.
4. **Terminal.** Check **Launcher shortcut** and **Start the terminal as administrator**. Make sure the service runs as administrator when the setting is On.
5. **Machine settings.** Under **Settings › This machine › Deployment** (Developer, with **Show all settings** on): **Terminal driver** = **Pywinauto**; **Mainframe environment** = development or production to match the Fujitsu Mainframe system (development puts `99` in front of the service account's affiliation code at sign-in); **Mainframe host (probe)** and **Mainframe port (probe)**.
6. **Pause first.** On the System page press **Pause processing**, so no queued request starts on the real terminal before you have tested it.
7. **Restart** the service.
8. **Test** in order: **Test mainframe host**, **Test terminal launch**, **Test sign-in and navigation**. Read the result, **Show details** and the screenshots.
9. **Resume.** Press **Resume processing** and follow the first request on the **Requests** page and in its evidence.

> **Important.** The bot works on the screen of the server. The Windows session it runs in must stay signed in and **unlocked**, its remote desktop window must not be minimized, and nobody may use the keyboard, the mouse or the Fujitsu Mainframe terminal on that desktop while requests or tests run. A window placed over the terminal or a person typing makes steps fail; in the worst case the bot and a person type into the same window. A locked, disconnected or minimized session is caught by the bot (see the next subsection).

### The bot's Windows session

> **In plain words.** The bot works the terminals by sending keystrokes to its own Windows session on the server. Windows refuses those keystrokes while that session is locked, disconnected, or shown in a remote desktop window that is minimized. Instead of letting one request after another fail, the bot then holds new work: requests wait in the queue, are not counted as failed, and are processed by themselves once the session takes keystrokes again.

**Who does this:** Server team and RPA support (keeping the session signed in, unlocked and not minimized), Admin (following the System page and the e-mails).

**What the bot checks.**

- **Before each request**, without sending anything: that the bot's session is connected and its desktop is not locked.
- **After a request ended because Windows refused its keystrokes.** A minimized remote desktop window is not reported by Windows in advance; it shows only when a keystroke is refused. From then on new work waits until Windows accepts input again. The bot tries this with a mouse move of zero pixels, at most once a minute and only while work waits. It never sends input while the session is idle, so it does not keep the session from locking itself.

**What the bot does.** While the session cannot take keystrokes, no new request of either application starts: Fujitsu Mainframe and Fujitsu RACF requests wait in the queue and are not counted as failed. A request that was already on the terminal when Windows refused its keystrokes ends as its outcome says (for example Failed after its attempts, or, for a Fujitsu RACF job whose command had already been sent, **Needs verification**). When the session works again, the waiting requests are processed automatically.

**The System page** lists the reason under **Needs attention** while requests wait, for example "Requests wait: the bot's Windows session is locked. Keep the bot's session signed in, unlocked and not minimized; processing resumes by itself." The other reasons read "the bot's Windows session is disconnected" and "Windows did not accept the bot's keystrokes (the bot's remote desktop window may be minimized)". The line goes away by itself.

**The e-mails** (while e-mail is on):

| E-mail | When | To |
|---|---|---|
| "Bot Windows session Not Available" | Once, when requests start waiting. It gives the reason, says that requests are kept and not counted as failed, and asks the RPA support team to keep the session signed in and unlocked, not to minimize the remote desktop window (or, where it must be minimized, to set `RemoteDesktop_SuppressWhenMinimized` to 2 on the computer that connects), and to disconnect only with the script of the unattended operation package (`Leave_Bot_Running.cmd`) | **Default recipients** |
| "Bot Windows session Recovered" | Once, when the session takes keystrokes again and the requests in the queue are processed | **Default recipients** |
| "Error: Windows did not accept the bot's keystrokes" | The error e-mail, when error e-mails are on, after a step failed because Windows refused the keystrokes. It explains the cause in plain words and asks to keep the session signed in, unlocked and not minimized. | As for the other error e-mails (section 6) |

Both outage e-mails are on the **E-mail samples** page of **Settings › E-mail**. The terminal tests of both applications also say in plain words when Windows did not accept the bot's keystrokes: "Unlock or restore the session, then try again."

**The setting.** The check is on by default. It applies only to the real terminal drivers that send keystrokes (**Pywinauto** and **Pyautogui**) on Windows; with the simulated drivers nothing is checked. There is no console setting and no **This machine** setting for it: it can be switched off only in the settings file of the server (`DESKTOP_SESSION_CHECK=false`), which is not recommended.

**What an administrator must do.** Keep the bot's Windows session signed in and unlocked, and do not minimize its remote desktop window. To leave the server while the bot keeps working, use `Leave_Bot_Running.cmd` of the unattended operation package instead of closing or minimizing the remote desktop window. Do not lock the session or sign it out.

**Good and bad cases.**

| Case | What happens |
|---|---|
| The session is signed in and unlocked; the remote desktop window was left with `Leave_Bot_Running.cmd` | [OK] Requests run as usual. |
| Someone locks the bot's session (Windows key + L, or the screen lock after idle time) | [NG] No new request starts; the System page names the reason; "Bot Windows session Not Available" e-mail. [OK] after it is unlocked: requests resume by themselves, "Recovered" e-mail. |
| The remote desktop window is closed with its X, so the session is disconnected | [NG] As above, with the reason "disconnected". Reconnect, then use `Leave_Bot_Running.cmd` to leave. |
| The remote desktop window is minimized | [NG] The first request meets a refused keystroke and ends as its outcome says; then new requests wait, and the bot tries input once a minute. [OK] once the window is restored: requests resume by themselves. |
| A request is waiting while the session is locked | [OK] It stays in the queue, is not counted as failed and runs after the session is unlocked. |
| The bot uses a simulated driver | [OK] Nothing is checked. |

### Common situations

| Situation | What the bot does | Who is told | Which setting decides |
|---|---|---|---|
| The shortcut cannot be found | Fails the attempt with the locations it searched (code BOT:TERMINAL_LAUNCH_FAILED); new Fujitsu Mainframe requests wait until the terminal starts; the request is tried again up to the attempt limit | Request error; outage e-mail; failure e-mail when on | **Launcher shortcut**, **Terminal start failures before Fujitsu Mainframe counts as unavailable** |
| The terminal needs administrator rights but the service does not run as administrator | The Terminal summary warns; requests fail at the start of the terminal | The warning on the settings page | **Start the terminal as administrator** |
| A Fujitsu Mainframe window from an earlier attempt is still open | Closes it before starting; if it will not close, fails the attempt naming the window ("close it on the bot machine, then retry the request") | Request error | None |
| A person signs in to Fujitsu Mainframe on the bot's desktop during the day | Steps may fail or type into the wrong window | Nobody automatically | None: keep the desktop untouched |
| The bot's Windows session is locked or disconnected | Starts no new request of either application; requests wait and resume by themselves once the session is unlocked | System page (**Needs attention**); "Bot Windows session Not Available" and "Recovered" e-mails to the default recipients | None on the console: keep the session signed in and unlocked |
| The remote desktop window of the bot's session is minimized | The request that meets the refused keystroke ends as its outcome says; then new requests wait; input is tried once a minute | As above; the error e-mail "Error: Windows did not accept the bot's keystrokes" when error e-mails are on | None on the console: restore the window, leave with `Leave_Bot_Running.cmd` |
| You want to demonstrate the bot without touching Fujitsu Mainframe | Runs every step against the simulated terminal | Nobody | **Terminal driver** = **Sim terminal** |
| **Test sign-in and navigation** fails at the sign-in | Signs off; refuses another sign-in test for 10 minutes, unless a new service-account value is saved | The person who ran the test; the owning team for a recognised refusal | Service-account **Credentials** or CyberArk |
| **Test sign-in and navigation** opens a screen other than Task 903 | Fails the confirmation step and signs off | The person who ran the test | None: compare the screenshot with the expected screen |
| **Test terminal launch** is pressed while processing is running | Refuses: "Pause processing first …" | The person who ran the test | None |

---

## 5.5 Processing and the operating window

> **In plain words.** Requests wait in one queue and the bot works through them one at a time, oldest first, only during the hours when the application is open. A request that fails for a temporary reason is tried again a little later, up to a set number of attempts. A failure that needs a person, or anything that may already have changed Fujitsu Mainframe, is never repeated automatically.

**Who does this:** Admin (attempts, hours, pause), Developer (waits, polling, error handling, **Retry** of a failed request), Operator (cancel on the Requests page).

### How the bot works through the queue

- **One at a time.** One request is on the terminal at any moment, each in its own terminal session that is opened and closed for it. Fujitsu Mainframe and Fujitsu RACF requests (when Fujitsu RACF is on) share the same queue.
- **Oldest first.** The bot takes the oldest queued request whose waiting time has passed. A request that is retried joins the back of the queue.
- **Checks before the terminal.** Just before a request runs, it is cancelled without touching the terminal if a newer ticket for the same account and the opposite operation has already run, or if its ServiceNow ticket was closed or reassigned after pickup. These cancelled requests get no outcome e-mail and no ticket note.
- **A running request is never interrupted.** Closing time, a pause or a stop of the service lets it finish and sign off.
- **Each application waits on its own.** A closed window or an outage of one application holds only that application's requests; the other one keeps running.

### Attempts per request

**Attempts per request** is the total number of attempts, the first included: 3 means the first attempt and up to two automatic retries. It is capped at 5, because each attempt can mean one sign-in with the service account, and a real service account locks out.

- A change applies at once, also to requests already in the queue.
- A **Retry** on a Failed request (Developer) is one more attempt in the same count. The Requests page shows it as "N (k by operator retry)". A request already at the limit gets that one attempt and is not retried automatically after it.
- If the service stops during a request's **last allowed** attempt, the request is recorded as Failed with code BOT:INTERRUPTED ("interrupted on the last attempt … not run again; use Retry") instead of running once more. An interrupted earlier attempt simply returns to the queue.
- If the service stops after `70` was typed, the request is never run again: it is recorded as **Needs verification**.

**Retry** is not offered, or is refused, when the request is not Failed, when its ServiceNow ticket was closed as incomplete ("Raise a new ticket to run it again"), when the password it brought is no longer held, or when the same work was submitted again. With the shipped settings a failed ServiceNow request closes its ticket as incomplete, so it is retried by raising a new ticket.

### What is retried and what never is

| Kind of failure | Retried automatically |
|---|---|
| The terminal did not start, a screen did not appear in time, the terminal window was lost | Yes, up to the limit |
| The confirmation screen could not be read, so nothing was committed | Yes, up to the limit |
| Centre not ready (センター準備中), line error (回線エラー), any other Fujitsu Mainframe error dialog | Yes, up to the limit; after centre not ready or a line error new requests wait until Fujitsu Mainframe answers again |
| Service-account password rejected (パスワードが誤っています) | Only when a different password has arrived (see below) |
| Operator code not registered (オペレーターコード未登録です) | No: the same codes give the same answer |
| Affiliation code not valid (所属コードの上2桁が不当です) | No: the same code gives the same answer |
| The sign-in was refused with a message no rule knows (the sign-in screen stays) | No: a refused sign-in is refused again |
| A COBOL run-time error of the terminal program (NetCOBOL dialogs) | No |
| Fujitsu Mainframe refused the data on its error screen (employee code not found, employee code error, any other error comment) | No |
| An error comment on the confirmation screen; a confirmation that does not match the request | No |
| Anything after `70` was typed | Never |

A failure that has no Fujitsu Mainframe result code gets a code of the bot, always starting with `BOT:` so that nobody reads it as a Fujitsu Mainframe code. Examples: BOT:TERMINAL_LAUNCH_FAILED, BOT:LOGIN_FAILED, BOT:UNEXPECTED_SCREEN, BOT:CONFIRMATION_UNREADABLE, BOT:CONFIRMATION_MISMATCH, BOT:TERMINAL_ERROR, BOT:INTERRUPTED, BOT:SYSTEM_ERROR, and BOT: followed by the name of the error rule that recognised the screen, for example BOT:EMPLOYEE_CODE_ERROR.

**COBOL run-time errors.** A program of the terminal can stop on a COBOL run-time error (for example a record locked by another session) and show two dialogs of its own: 「COBOL」 and 「NetCOBOL 診断機能」. The bot answers both (OK, then いいえ, so no report window opens), signs off and fails the request with the run-time message. It is not run again automatically, because it would fail the same way while the cause remains. Check that no other Fujitsu Mainframe session uses the bot's sign-in, then use **Retry**.

### The password-rejected rule

Each attempt makes exactly one sign-in. When Fujitsu Mainframe answers パスワードが誤っています:

1. The bot leaves from the sign-in screen and asks CyberArk for a fresh password at once.
2. The next attempt waits at least 20 seconds, so the fetch can finish.
3. If the password is still the same when the next attempt is due, the request is finished as Failed without touching the terminal: "Not retried: the mainframe rejected the service-account password and no different password has been supplied … Retry once the password is updated."

Without CyberArk the password changes only when a new one is saved under **Credentials**, so a rejected password means one sign-in and then Failed. This protects the service account from being locked.

### Waits between attempts

The wait before the next attempt starts at **Backoff base (s)**, is multiplied by **Backoff factor** for each further attempt and never exceeds **Maximum delay (s)**. The actual wait is chosen at random between half and all of that value, so retries do not bunch up. With the shipped values: 30–60 seconds after the first attempt, 60–120 seconds after the second. The **Queue** card shows how many requests are "waiting to retry".

### The operating window

Each application has its own window. New Fujitsu Mainframe work starts only between **Window opens (JST)** and **Window closes (JST)** (Settings › Fujitsu Mainframe window) minus **Stop accepting before close (min)** (Settings › Operating window), and only while the mainframe probe succeeds. Outside that, requests are accepted and stay **Queued**; they are taken, oldest first, when the window opens. The window must open and close on the same day; the stop-accepting minutes must be shorter than the window.

The settings are arranged in three places:

- **Settings › Operating window** (General, both applications): **Stop accepting before close (min)** and **Probe interval (s)**, shared by both applications.
- **Settings › Fujitsu Mainframe window** (Fujitsu Mainframe area): the Fujitsu Mainframe hours, the mainframe probe, and what happens when the terminal does not start.
- **Settings › Fujitsu RACF window** (Fujitsu RACF area, shown while Fujitsu RACF is on): the Fujitsu RACF hours and its own probe. Fujitsu RACF requests start only inside that window; Fujitsu Mainframe keeps its own. See 5.9.

An Admin sees the essential settings of this section together on **Settings › Processing**: **Attempts per request**, **Process queued work**, **Window opens (JST)** and **Window closes (JST)**.

The window card on the Dashboard (**Mainframe window**) and on the System page (**Mainframe window**, or **Fujitsu Mainframe window** while Fujitsu RACF is on):

| Card shows | Meaning |
|---|---|
| **Open** | Inside the window; new work may start |
| **Closing** | Inside the window but within the stop-accepting minutes ("closing: no new work starts") |
| **Closed** | Outside the window |

The card adds "mainframe not reachable" while the probe fails. When e-mail is on, an outage and a recovery notice go to the default recipients, and to the **Fujitsu Mainframe team** only while **Fujitsu Mainframe team: support reports only** is Off.

### When Fujitsu Mainframe is not available

Besides the closed window and a host that does not answer the probe, new Fujitsu Mainframe requests also wait in two situations:

- **The terminal does not start on the bot machine.** After **Terminal start failures before Fujitsu Mainframe counts as unavailable** requests in a row (1 with the shipped settings; 0 switches this off), Fujitsu Mainframe counts as unavailable on this machine: the outage notice is sent and the start is tried again in the background every **Try the terminal again every (min)**, inside the window and while nothing runs. A successful start, or a passed **Test terminal launch**, releases the requests.
- **Fujitsu Mainframe shows centre not ready (センター準備中) or a line error (回線エラー).** The outage notice is sent and the Fujitsu Mainframe login window is opened again every **Try the terminal again every (min)**, without signing in, until it opens without the dialog. A passed **Test sign-in and navigation** releases the requests at once.

The System page names the reason while requests wait.

**The bot's Windows session.** Requests of both applications also wait while the bot's Windows session is locked or disconnected, or after Windows refused the bot's keystrokes (for example a minimized remote desktop window). They are not counted as failed and resume by themselves; see 5.4, "The bot's Windows session".

### Process queued work versus Pause

| | **Process queued work** (setting) | **Pause processing** (System page) |
|---|---|---|
| Use it for | Switching processing off on this server for a longer time | A short stop: maintenance, tests, an incident |
| Takes effect | After a restart | At once; a request already running finishes |
| Requests | Still accepted and queued; nothing runs them | Still accepted and queued |
| Survives a restart | Yes (it is a setting) | Yes: processing stays paused until someone presses **Resume processing** |
| Clean-up of old evidence, passwords and sessions | Continues | Continues |

The **Processing** card on the System page shows **Active** (Idle, or "A transaction is in progress"), **Paused** (by whom and since when), **Stopped** (with the reason) or **Waiting** (for CyberArk, outside the operating window, the mainframe is not available, screen reading is not working, or the bot's Windows session cannot take keystrokes). While processing waits, the System page names the reason; a Windows session that cannot take keystrokes, screen reading that is not working and CyberArk that has not delivered where it is required are listed under **Needs attention**.

### Settings: Retry policy (Settings › Retry policy)

| Setting | What it means | Default | Who can change it | Takes effect |
|---|---|---|---|---|
| **Attempts per request** | Total attempts for a temporary failure, the first included; 1 to 5 | 3 | Admin | At once |
| **Backoff base (s)** | The wait before the first retry | 60 | Developer | After a restart |
| **Backoff factor** | How much longer each further wait is (2 doubles it) | 2.0 | Developer | After a restart |
| **Maximum delay (s)** | The longest wait between two attempts | 600 | Developer | After a restart |

### Settings: Dispatcher (Settings › Dispatcher)

| Setting | What it means | Default | Who can change it | Takes effect |
|---|---|---|---|---|
| **Process queued work** | Off: requests are accepted but not run | On | Admin | After a restart |
| **Poll interval (s)** | How often the queue is checked while there is work | 2 | Developer | After a restart |
| **Idle poll interval (s)** | How often the queue is checked when nothing is waiting | 5 | Developer | After a restart |
| **Shutdown drain (s)** | How long a stop or restart waits for a request that is on the terminal | 300 | Developer | After a restart |

### Settings: Operating window (Settings › Operating window, both applications)

| Setting | What it means | Default | Who can change it | Takes effect |
|---|---|---|---|---|
| **Stop accepting before close (min)** | No new request starts this close to closing time; 0 to 240 | 15 (development: 0) | Developer | After a restart |
| **Probe interval (s)** | How often the hosts are probed; 10 to 3600 | 60 | Developer | After a restart |

### Settings: Fujitsu Mainframe window (Settings › Fujitsu Mainframe window)

| Setting | What it means | Default | Who can change it | Takes effect |
|---|---|---|---|---|
| **Window opens (JST)** | From when Fujitsu Mainframe requests are processed | 06:00 (development: 00:00) | Admin | After a restart |
| **Window closes (JST)** | When Fujitsu Mainframe processing stops for the day | 22:00 (development: 23:59) | Admin | After a restart |
| **Probe the mainframe** | Checks regularly that the mainframe host answers; new work waits while it does not. With no host set, the host is assumed reachable. | On (development: Off) | Developer | After a restart |
| **Terminal start failures before Fujitsu Mainframe counts as unavailable** | Requests in a row whose terminal did not start before new requests wait; 0 = off; 0 to 10 | 1 | Developer | After a restart |
| **Try the terminal again every (min)** | How often the terminal start, or the login window after centre not ready, is tried again while requests wait; 1 to 60 | 5 | Developer | After a restart |

The host and port that are probed are machine settings (5.8). The Fujitsu RACF window settings are described in 5.9.

### Settings: Error handling (Settings › Error handling)

The page is in the General area, but its settings apply to **Fujitsu Mainframe only**, as the help of each setting says: Fujitsu RACF recognises its own sign-on and job messages (5.9).

| Setting | What it means | Default | Who can change it | Takes effect |
|---|---|---|---|---|
| **Act on recognised error screens** | Applies the error rules (see the Error rules page). Off: no rule is applied. | On | Developer | After a restart |
| **Transient retry attempts** | Repeats of a single step, used only by an error rule whose action is to retry a step. None of the shipped rules does. | 2 | Developer | After a restart |
| **Settle after dismissing a dialog (s)** | The pause after an error dialog was closed | 1.5 | Developer | After a restart |

The error rules themselves are listed on the **Error rules** page (section 8.3), which only the Developer sees. Only the Developer can switch a rule off or on, and the reason is recorded.

### Common situations

| Situation | What the bot does | Who is told | Which setting decides |
|---|---|---|---|
| A ticket arrives at 23:30 | Queues it; runs it when the window opens | Nobody | **Window opens (JST)**, **Window closes (JST)** |
| The mainframe host stops answering | No new Fujitsu Mainframe request starts; requests wait | Outage and recovery e-mails (when on) to the default recipients, and to the Fujitsu Mainframe team while its "support reports only" switch is Off | **Probe the mainframe** |
| Fujitsu Mainframe shows センター準備中 | Answers the dialog, signs off; new requests wait; the login window is opened again every few minutes; the request is tried again after the wait | Outage and recovery e-mails; failure e-mail only if every attempt fails | **Attempts per request**, **Try the terminal again every (min)** |
| The terminal does not start on the bot machine | New Fujitsu Mainframe requests wait; the start is tried again every few minutes | Outage and recovery e-mails | **Terminal start failures before Fujitsu Mainframe counts as unavailable** |
| The service-account password was rotated and CyberArk has not caught up | One sign-in, asks CyberArk at once; next attempt only with a different password, otherwise Failed | Failure notice; the CyberArk / identity team when its addresses are set | **Attempts per request**, CyberArk |
| The employee code on a ticket does not exist in Fujitsu Mainframe | Prints the error screen to PDF, leaves with `99`, signs off; Failed, not retried | Failure e-mail and ticket closed as incomplete (shipped settings) | Error rules |
| The server restarts while a request is on its last attempt | Records it as Failed (BOT:INTERRUPTED); the Developer may retry | Failure e-mail and ticket handling as for any failure | **Attempts per request** |
| The server restarts after `70` was typed | Records **Needs verification**; never runs it again | "Please verify" e-mail asking for a manual check; the ticket is closed as Closed Incomplete with the note "… Closed as incomplete; if the change is still needed, submit a new request." (section 7); a person checks Fujitsu Mainframe | **Close the ticket when the request failed** (ServiceNow; Off: the ticket stays open with a note) |
| An operator cancels a queued request | Cancels it; nothing reaches Fujitsu Mainframe | Ticket gets a cancel note and stays open, or is closed as incomplete | **Close the ticket when a request is cancelled** (ServiceNow) |
| You need to stop processing for a planned Fujitsu Mainframe outage | Press **Pause processing**; requests keep queueing | The Processing card shows who paused | Pause on the System page |
| You raise **Attempts per request** from 3 to 4 | Applies at once to every queued request | Nobody | **Attempts per request** |

---

## 5.6 Screens and evidence

> **In plain words.** For every request the bot keeps a folder of evidence: a screenshot of each step, the text it read from the important screens, and the printout Fujitsu Mainframe produces. The new account's password is blacked out in the pictures. The evidence is deleted automatically after a set number of days.

**Who does this:** Developer (screen reading and retention settings), Viewer and above (viewing evidence), Admin (checking requests that need verification).

The **Screen reading** and **Evidence** settings pages are in the General area. The **Evidence** settings and **Read screens with OCR** apply to both applications; the other **Screen reading** settings apply to Fujitsu Mainframe only. This section describes a Fujitsu Mainframe run; how the bot reads the Fujitsu RACF screens is described in 5.9.

### What a run looks like on the mainframe

```mermaid
flowchart LR
  A[Start terminal] --> B[Menus: 10, 10]
  B --> C[Sign in: codes, password, 00]
  C --> D[Task 903]
  D --> E[Type the request, 00]
  E --> F{Confirmation screen?}
  F -- yes --> G[70: commit]
  F -- no --> X[99: cancel]
  G --> H[10: print]
  H --> I[Sign off: 99 ... XX]
  X --> I
```

1. **Start.** The bot starts the terminal from its shortcut. A Fujitsu Mainframe window an earlier attempt left open is closed first. A journal prompt at start-up (ジャーナル印刷) is skipped with Enter.
2. **Open Fujitsu Mainframe.** `10`, then `10` again on the second menu: the Fujitsu Mainframe sign-in window opens.
3. **Sign in.** The affiliation code, the staff code and the password of the service account, then `00`. In the development mainframe environment `99` is put in front of the affiliation code. The answer to the sign-in is read.
4. **Task 903.** `903` on the business menu opens Task 0903 (password database update and addition).
5. **Type the request.** Processing type (2 to create, 4 to delete), the affiliation code and employee code of the account, and for a new account its initial password and the date.
6. **Confirm with `00`.** Fujitsu Mainframe shows the confirmation screen or an error screen. This screen is read.
7. **Commit with `70`.** Only on a screen recognised as the confirmation screen. The answer is read.
8. **Print with `10`.** On the print screen this queues the printout.
9. **Sign off.** From wherever Fujitsu Mainframe is: `99` back through the Fujitsu Mainframe screens, the leftover affiliation code is cleared, `99` closes Fujitsu Mainframe, then `99` and `XX` on the menu window. Fujitsu Mainframe releases the printout at the end, and the bot saves it as a PDF. The bot then checks that no Fujitsu Mainframe window is left open.

The sign-off runs after every attempt, successful or not. Where it starts depends on how far the attempt got: from the sign-in screen when the bot never signed in, from the menu window when Fujitsu Mainframe has already ended by itself (after a line error), and from the current screen otherwise. A sign-off that stops part-way does not change the outcome of the request: the audit trail names the stage at which it stopped, and a window left open is recorded with a screenshot so it can be closed by hand.

### Screen reading

The bot reads the screen with a Japanese text-recognition engine installed with the application. A read takes several seconds, so by default only the screens on which the bot decides are read:

- the answer to `00` (commit or not);
- the answer to `70` (accepted or refused);
- the answer to the sign-in, so that a refused sign-in is recognised: a rejected password, an operator code that is not registered, an affiliation code that is not valid, or a message no rule knows;
- the screen on which an attempt failed (see below);
- any Fujitsu Mainframe error dialog, which is found by its window and read after it has been acknowledged.

With **Screens that are read** set to **Every screen (slower)**, every screenshot is read and every wait follows the screen; each request then takes noticeably longer.

Screen reading is mandatory with the real terminal. It cannot be switched off there, and if the engine loads but cannot read, new work waits and the **Screen reading** card on the System page shows **Not working** until a read succeeds.

A read the bot is not confident about (below the **Confidence floor**) never triggers an error rule: it is recorded as "suspected" and the request goes on. The exceptions are the last check before `70`, where stopping is always the safe choice, and an open error dialog, which is always dealt with.

### How the outcome is decided

| After `00`, Fujitsu Mainframe shows | The bot | The request |
|---|---|---|
| The confirmation screen | Types `70` | Goes on to the commit |
| The error screen | Prints it to PDF, leaves with `99` | **Failed**, with Fujitsu Mainframe's error comment |
| On a removal: 削除済み (already deleted) | Does not commit | **Already removed** |
| A screen it cannot read | Cancels with `99` (with **Stop when the confirmation cannot be read** On) | Tried again later; nothing was committed |

| After `70`, Fujitsu Mainframe shows | The request | Result code |
|---|---|---|
| The print screen | **Completed** | ACCEPTED |
| A result line | **Completed** or **Failed** | O-0000 or E-xxxx |
| The error screen | **Failed**, never retried | REFUSED |
| Nothing the bot can read, or a later step failed | **Needs verification**, never retried | UNCONFIRMED |

**Needs verification** means the change was submitted and may have been made. The "Please verify" e-mail asks a person to check the account in Fujitsu Mainframe. With **Close the ticket when the request failed** On (the shipped setting), the bot closes the ServiceNow ticket as Closed Incomplete, never as complete, with a note that the result could not be confirmed and that a new request is needed if the change is still wanted; switched Off, the ticket stays open with the review note (section 7). Do not retry it: running it twice could register or remove the account twice.

### The evidence kept for each request

Each request has its own folder in the evidence folder. A retry adds to the same folder and continues the numbering.

| Item | What it is |
|---|---|
| Screenshots | One at each step, numbered in order, before and after the bot types. No screenshot is taken after `XX`. |
| Screenshot of the failure | When an attempt fails, the screen exactly as it was, taken before the sign-off changes it. It is always read; a short, masked extract of its text is recorded with the failure in the audit trail. |
| Text files | One beside each screenshot (with **Save the screen text beside each screenshot** On). For the screens that are read it holds the screen text; for the others it says the screen was not read. Each lists what the bot typed since the previous screenshot. Passwords are masked. |
| Printout (PDF) | The printout Fujitsu Mainframe produced, named after the ticket number. A blank printout is kept under another name and the PDF is built from the bot's screenshots. A printout from an earlier session is saved separately. A printout that cannot be saved never changes the outcome. |
| Error screens | The error screen or dialog, the bot's reaction and the state afterwards |

The console opens the screenshots and text files of a request (**Evidence**); the PDFs are kept in the request's folder on the server. Lists, details and the Evidence page show which application a request belongs to (**Fujitsu Mainframe** or **Fujitsu RACF**). Opening a request's evidence is recorded in the audit trail.

### The password is blacked out

Task 0903 shows the new account's initial password: in the entry table and again on the confirmation and error screens. Every screenshot that can show it is searched for the password, or for the label of the password field, and that place is blacked out before the file is kept. When the screen cannot be read, fixed areas where the password appears are blacked out instead. **A screenshot whose password cannot be covered is not kept**; the audit trail says so. In the text files the service-account password and the request's password are masked wherever they appear. The service-account password on the sign-in screen is hidden by the terminal itself.

### Retention and housekeeping

Clean-up runs on its own timer, whether or not processing is on:

- **Evidence**: once a day, never while a request is on the terminal. A request's folder is deleted, PDFs included, when its newest file is older than **Keep evidence for (days)**.
- **Passwords of failed requests**: checked every hour; erased after **Keep the password of a failed request for (days)**.
- **Service log**: one file per day; files older than **Keep the service log for (days)** are deleted.

### Settings: Screen reading (Settings › Screen reading)

**Read screens with OCR** applies to both applications. The other settings of this page apply to **Fujitsu Mainframe only**, as their help says: Fujitsu RACF reads its screens with its own rules, always saves the screen text and decides from its job result lines (5.9).

| Setting | What it means | Default | Who can change it | Takes effect |
|---|---|---|---|---|
| **Read screens with OCR** | Switches screen reading on. Cannot be switched off with the real terminal. When saved, it decides over the machine setting **Screen reading (OCR)**. | On | Developer | After a restart |
| **Confidence floor** | Below this, a read never triggers an error rule. Raising it makes the bot more cautious, not more accurate. | 0.75 | Developer | After a restart |
| **Save the screen text beside each screenshot** | Writes the text files | On | Developer | After a restart |
| **Screens that are read** | **Only where the bot decides (after 00 and 70)** or **Every screen (slower)** | Only where the bot decides | Developer | After a restart |
| **Stop when the confirmation cannot be read** | On: `70` is typed only on a screen the bot has read as the confirmation screen; otherwise it cancels with `99`. Off: the bot commits on the data it typed even when it cannot read the screen. The error screen is never committed on. | On | Developer | After a restart |

### Settings: Evidence (Settings › Evidence)

| Setting | What it means | Default | Who can change it | Takes effect |
|---|---|---|---|---|
| **Keep evidence for (days)** | How long screenshots, text files and PDFs are kept; 1 to 3650 | 90 | Developer | After a restart |
| **Keep the password of a failed request for (days)** | So a failed request can be retried with the same password. 0 = erased when the request fails. 0 to 30. | 7 (production: 0) | Developer | After a restart |
| **Keep the service log for (days)** | The log holds employee and affiliation codes; 1 to 365 | 30 | Developer | After a restart |

### Common situations

| Situation | What the bot does | Who is told | Which setting decides |
|---|---|---|---|
| The confirmation screen cannot be read | Cancels with `99`, nothing committed; tries again (BOT:CONFIRMATION_UNREADABLE if every attempt fails) | Failure e-mail only after the last attempt | **Stop when the confirmation cannot be read** |
| The result after `70` cannot be read | Records **Needs verification**; never retries | "Please verify" e-mail; ticket closed as Closed Incomplete with the reason (section 7); a person checks Fujitsu Mainframe | **Close the ticket when the request failed** (ServiceNow) |
| The password cannot be found in a screenshot and the area cannot be covered | Deletes that screenshot; the request continues | Audit trail | Screen reading |
| An auditor asks for the evidence of a request from four months ago | Already deleted under the shipped 90 days | Nobody | **Keep evidence for (days)** |
| You need to investigate unusual screens for a day | Reads every screen; requests take longer | Nobody | **Screens that are read** = **Every screen (slower)**, then back |
| Fujitsu Mainframe releases a blank printout | Keeps it under another name and builds the PDF from the screenshots | Audit trail | None |

---

## 5.7 Security settings

> **In plain words.** These settings decide how long people stay signed in to the console, how strict console passwords are, who may manage console accounts, and how the bot makes the initial password of each new Fujitsu Mainframe account. The System page lists anything that weakens the protection of the service.

**Who does this:** Developer.

### Settings: Console sign-in (Settings › Console sign-in)

| Setting | What it means | Default | Who can change it | Takes effect |
|---|---|---|---|---|
| **Sign out after inactivity (s)** | A console without keyboard or mouse activity for this long is signed out; a minute before, it asks "Still there?". Automatic page refreshes do not count. 300 to 86400. | 1800 | Developer | After a restart |
| **Maximum session length (hours)** | However active, a session ends this long after the sign-in; 1 to 24 | 12 | Developer | After a restart |
| **Minimum password length** | The shortest console password accepted; 8 to 64. The reset of a console password on the server itself (`desktop\app.py --reset-console-password`) applies the same length. | 12 | Developer | After a restart |
| **Failed sign-ins before lockout** | Failed sign-ins in a row before the account is locked; 3 to 20 | 5 | Developer | After a restart |
| **Lockout duration (s)** | How long a locked account stays locked | 900 | Developer | After a restart |
| **Allow Windows sign-on** | Lets people on the server itself sign in with their Windows identity. Callers from other machines are always refused. | Off | Developer | After a restart |
| **Users page for Administrators** | Off: the Users page (console accounts, signed-in sessions, export) is for the Developer only. On: Administrators see and manage console accounts as well. While no active Developer account exists, Administrators keep the Users page. | Off | Developer | At once |

The console password history, the password expiry and the e-mail on a locked account are machine settings (5.8, Security).

### Settings: Provisioning password (Settings › Provisioning password)

The page is in the **Fujitsu Mainframe** area of the Settings navigation.

| Setting | What it means | Default | Who can change it | Takes effect |
|---|---|---|---|---|
| **Symbols used in generated passwords** | The symbols the bot may use. Only `@ # $ & * - _ = ! ? .` are accepted, because other symbols cannot be typed safely on the terminal. | `@` | Developer | After a restart |
| **Leave out look-alike characters (O 0 I 1)** | Leaves out characters that are easy to confuse | On | Developer | After a restart |

### How generated passwords are made

Every new Fujitsu Mainframe account gets an initial password generated by the bot; tickets never carry one, and there is no default password. A provisioning request that somehow reaches the terminal without a password fails before anything is typed. Each generated password:

- has exactly 8 half-width characters;
- starts **and** ends with a letter;
- uses capital letters, digits and the configured symbols;
- holds at least one digit and, when symbols are configured, at least one symbol;
- leaves out O, 0, I and 1 unless that setting is switched off;
- is **never issued twice**: the service keeps a keyed fingerprint (never the password itself) of every password it has used and draws again until the password is unused.

### Security notices on the System page

The problem box at the top of the System page has two closed sections, each with its number of messages:

- **Needs attention (n)**, in red: what stops processing, and under **Security, before production use:** the security notices that must be dealt with before production use.
- **Warnings (n)**, in orange: settings that need attention although requests are still processed, and under **Security:** the other security notices.

| Notice | Where it is listed | What to do |
|---|---|---|
| Requests are accepted without an API key | **Needs attention** with a real terminal driver; **Warnings** with the simulated drivers | The Developer saves the **Machine API keys** under Credentials, switches on **Require the machine API key** and **Console sign-in may use the API** (5.8, Security) and restarts the service |
| The audit trail is off | **Warnings** | Turn on **Audit event trail** under **Settings › This machine › Database**, then restart |
| The service runs as another Windows account than the one it was set up for | **Warnings**, with a **Use this account** button | Start the service as the account of the scheduled task, or save the passwords again under Credentials and choose **Use this account** |
| The initial console administrator has not chosen its own password | **Warnings** | Sign in as that administrator and choose a new password now |
| The mainframe password is fetched from CyberArk without checking its certificate | **Warnings** | Use an https address and turn on **Verify TLS certificate** under **Settings › CyberArk** |
| The registration e-mail announces a separate password e-mail that is not sent | **Warnings** | Turn on **Send the initial password to the new user**, or tell new users their password another way |

---

## 5.8 This machine

> **In plain words.** These are the settings the service needs before it can even open its database: which environment it is, which terminal it drives, which database it uses and where its password comes from, where it keeps files, and the passwords it holds in the Windows credential store. A wrong value can stop the service from starting, so only the Developer changes them; an Admin sees and renews the credentials only.

**Who does this:** Developer (all groups), Admin (Credentials only), Server team (Windows account, environment variables).

The **This machine** pages follow the application pages in the Settings navigation: **Deployment**, **Database**, **Screen reading (start-up)**, **Security**, **Storage**, **Fujitsu RACF (this machine)** and **Credentials**, then **History**. The Developer sees the machine settings with **Show all settings** switched on; an Admin sees **Credentials** only.

### Where each value is stored

| What | Stored in |
|---|---|
| The settings on the other Settings pages | The application database |
| **This machine** settings | The **application settings file** (`.env` in the application folder) when that file already holds the key; otherwise the **machine settings file** (`finesiii.env` in the data folder) |
| **Credentials** | The Windows credential store of the account the service runs as |

Each row on **This machine** shows where its value comes from, in this order: a Windows environment variable (**Set by environment**), the **Application settings file**, the **Machine settings file**, or the default. **Save changes** writes each value to the file the service reads it from: a key the application settings file already holds is changed there in place (the console first keeps a backup copy of the file), and every other key goes to the machine settings file. A row is **locked**, and a save is refused, when the value is set by a Windows environment variable (change it there) or held in an application settings file the service cannot write (change it there, then restart). This protects you from saving a value that would never be used.

Every row carries the **Restart needed** badge, and a saved row shows **Saved — applies after restart** until then. **Restart service**, or **Save and restart** on the Settings page, re-reads both files. **Service port** and **Refuse another port** are different: **Restart service** keeps the port in use, so they apply only when the bot is stopped and started again (**Stop the bot**, then start it again, or a restart of the server). Their row shows **Saved — applies when the bot is stopped and started again**, and the restart notice on the Dashboard and the System page says "`<n>` saved setting(s) (the service port) apply when the bot is stopped and started again; Restart service does not apply them." Anything set by a Windows environment variable also needs the service to be stopped and started again.

When a console setting decides instead of a machine setting, the row says so: **Screen reading (OCR)** shows "Overridden by Settings > Screen reading > 'Read screens with OCR': that value is in force while it is set."

A save is refused, and nothing is written, when:

- the real terminal would run without screen reading;
- production would use the real terminal without CyberArk;
- the chosen driver cannot run on this server;
- a database server does not answer (unless you choose to save anyway);
- the **CyberArk certificate file (internal certificate authority)** does not exist, cannot be read or holds no certificate in PEM form ("CyberArk certificate file: … Nothing was saved.");
- **Database password from CyberArk** would be On with settings the service would refuse at its next start ("Database password from CyberArk: … Nothing was saved."), for example an empty **CyberArk address (database)** or **CyberArk Application ID (database)** ("enter CyberArk address (database)", "enter CyberArk Application ID (database)"), a **Database URL** that is not PostgreSQL, names no login, still contains a password or names the administrator login, an empty **Database administrator login**, or CyberArk values that are missing or do not check the certificate;
- someone else changed these settings after you opened the page.

### Deployment

| Setting | What it means | Default | Who can change it | Takes effect |
|---|---|---|---|---|
| **Service environment** | **Development** or **Production**. Production is strict: machine API key required, CyberArk required with the real terminal. | Development, unless set at installation | Developer | After a restart |
| **Terminal driver** | See 5.4 | Production: Pywinauto; development: Simulator | Developer | After a restart |
| **Mainframe environment** | Development puts `99` in front of the service account's affiliation code at sign-in. The affiliation code of a request is never changed. | Production (development environment: Development) | Developer | After a restart |
| **Mainframe host (probe)** | The host the availability probe checks. Empty = assumed reachable. | Empty | Developer | After a restart |
| **Mainframe port (probe)** | Its port | 23 | Developer | After a restart |
| **Service port** | The port the service and the console use | 8000 | Developer | After a stop and start |
| **Refuse another port** | On: the service does not start when its port is in use. Off: it starts on another free port and the System page says so. | Off | Developer | After a stop and start |
| **Log level** | How much the service log records; INFO is recommended | INFO (development: DEBUG) | Developer | After a restart |

### Database

| Setting | What it means | Default | Who can change it | Takes effect |
|---|---|---|---|---|
| **Database engine** | PostgreSQL (recommended for production) or SQLite | PostgreSQL (development: SQLite) | Developer | After a restart |
| **Database URL** | `postgresql://<user>@<host>:<port>/<database>`. A password typed into it is moved to the credential store. **Test connection** checks it; **Validate database password** checks the password from CyberArk (see below). Sample (QA), as the database setup script writes it (no password): `postgresql://finesiii_app@rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com:5432/finesiii_v3?sslmode=verify-full&sslrootcert=C%3A%5CFINESIII%5Capp%5Ccerts%5Crds-global-bundle.pem&connect_timeout=10&keepalives=1&keepalives_idle=60&keepalives_interval=10&keepalives_count=5&application_name=finesiii-rpa` | Set at installation | Developer | After a restart |
| **Audit event trail** | Records sign-ins, settings and credential changes, evidence views and user changes | On for the installed service | Developer | After a restart |
| **Audit backend** | Where the audit trail is kept | A local SQLite file unless an audit database is set | Developer | After a restart |
| **Audit database URL** | The audit database, when one is used. **Test connection** checks it. Sample (QA): `postgresql://finesiii_app@rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com:5432/finesiii_audit?sslmode=verify-full&sslrootcert=C%3A%5CFINESIII%5Capp%5Ccerts%5Crds-global-bundle.pem&connect_timeout=10&keepalives=1&keepalives_idle=60&keepalives_interval=10&keepalives_count=5&application_name=finesiii-rpa` | Empty | Developer | After a restart |
| **CyberArk certificate file (internal certificate authority)** | A PEM file of the certificate authorities that issued the CyberArk certificate, needed when CyberArk uses a company certificate; without it CyberArk is reported as Inactive (certificate verify failed). Used for every CyberArk call: the database password and the Fujitsu Mainframe and Fujitsu RACF passwords. **Create from Windows certificates** writes it (see below). Sample (QA): `C:/FINESIII/certs/aig-ca-bundle.pem` | Empty: the built-in list of public authorities | Developer | After a restart |
| **Database password from CyberArk** | On: at start and every few minutes the bot reads the administrator login's password from CyberArk and gives the login in **Database URL** the same password whenever it changed. **Database URL** keeps the application login and no password. Off: the password in the credential store. | Off | Developer | After a restart |
| **CyberArk address (database)** | The CyberArk CCP address up to the host, for example `https://<ccp-address>`. Required while **Database password from CyberArk** is On: the bot reads it at start, before the console settings are loaded. Sample (QA): `https://pamccp.aig.net` | Empty | Developer | After a restart |
| **CyberArk Application ID (database)** | The CCP Application ID allowed to read the administrator account from this server (`<application ID>`). Required while **Database password from CyberArk** is On. Sample (QA): `APP-10-SAILPOINT` | Empty | Developer | After a restart |
| **CyberArk safe (database)** | The safe holding the administrator account (`<safe>`). Sample (QA): `BADM_DBADMIN-ISO-POSTGRESQL` | Empty | Developer | After a restart |
| **CyberArk object (database)** | The object name of the administrator account (`<account object>`). **Test CyberArk retrieval** checks it (see below). Sample (QA): `Database---rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com---sailpoin1002---5432--dbadmin` (the database named inside it, `sailpoin1002`, is not the bot's database; the bot's database stays `finesiii_v3`) | Empty | Developer | After a restart |
| **Database administrator login** | The login CyberArk holds and rotates (`<admin login>`). It signs in only to copy a changed password. Sample (QA): `dbadmin` (settings file: `DATABASE_ADMIN_LOGIN=dbadmin`) | `dbadmin` | Developer | After a restart |
| **Audit database uses the same password** | On: the audit database address signs in with the same password. Switched Off, the audit database signs in with its own stored **Audit database password** again from the next **Restart service**. | On | Developer | After a restart |
| **CyberArk check interval (minutes)** | How often the bot asks CyberArk whether the password changed; 1 to 1440. A refused sign-in asks at once. | 15 | Developer | After a restart |

The buttons of the Database page:

| Button | Where | What it does | Who |
|---|---|---|---|
| **Test connection** | **Database URL**, **Audit database URL** | Connects with the address typed on the page and says whether the tables are in place | Developer |
| **Validate database password** | **Database URL** | Checks the database password against CyberArk now and uses a newer one at once; at most once every 30 seconds. The same button is on the System page. Answers that the password does not come from CyberArk while **Database password from CyberArk** is Off. Every click is recorded in the audit trail. | Developer (an Admin uses the one on the System page) |
| **Test CyberArk retrieval** | **CyberArk object (database)** | Reads the administrator account from CyberArk once with the values typed on the page, before they are saved. Shows the account's name, address and CPM status, never the password, and warns when CyberArk delivers another account than **Database administrator login**. | Developer |
| **Create from Windows certificates** | **CyberArk certificate file (internal certificate authority)** | Writes the certificate authorities this Windows server trusts to `certs\cyberark-ca-bundle.pem` in the data folder and puts that path in the field. The field still has to be saved (**Save and restart**). Available on a Windows server only. | Developer |

How the database password from CyberArk works (the copy to the application login, the checks and the System page **Database password** card) is described in 5.3, "The database password from CyberArk".

**Going back to a stored password.** Switch **Database password from CyberArk** Off and save. Give the application login a password of its own with the database set-up script (`Setup_Database.py` with `--set-password`, run as the bot's Windows account; Sample (QA): `R6-CORE\prvrnel`), which keeps it in the credential store, then restart the service. From then on the service signs in with the stored **Database password**; the CyberArk checks stop.

**Save and restart applies the database password setting.** A restart from the console keeps the same process, so the saved **Database password from CyberArk** settings are applied as part of the restart:

| Case at **Restart service** or **Save and restart** | What happens |
|---|---|
| The setting is On and its settings did not change | [OK] The restart goes on with the password in use, also while CyberArk does not answer. |
| The setting was switched On, or its settings were changed | The password is obtained from CyberArk once before anything restarts. [OK] when it is obtained. [NG] when it is not: nothing restarts and the console answers "Not restarted: the database password from CyberArk could not be obtained: … The service keeps running as it was." Correct the settings (or switch the setting Off) and restart again. |
| The setting was switched Off | [OK] The checks stop and the stored **Database password** is used again. |
| **Audit database uses the same password** was switched Off | [OK] The audit database uses its own stored password again. |

### Screen reading (start-up)

| Setting | What it means | Default | Who can change it | Takes effect |
|---|---|---|---|---|
| **Screen reading (OCR)** | Screen reading at start-up. Mandatory with the real terminal. Once **Read screens with OCR** has been saved on **Settings › Screen reading**, that value decides instead, and the row says "Overridden by …". | As chosen at installation | Developer | After a restart |

### Security

| Setting | What it means | Default | Who can change it | Takes effect |
|---|---|---|---|---|
| **Require the machine API key** | Other systems must present an API key to submit requests | Off (production: On) | Developer | After a restart |
| **Console sign-in may use the API** | Lets the console's own session use the request API. Machine callers still need their key. | Set at installation | Developer | After a restart |
| **Passwords remembered** | A new console password may not be one of this many earlier ones; 0 to 24 | 5 | Developer | After a restart |
| **Password expiry (days)** | 0 = never (recommended); otherwise an older console password must be changed at the next sign-in; 0 to 365 | 0 | Developer | After a restart |
| **E-mail when an account is locked** | A locked console account is reported through the e-mail alerts | On | Developer | After a restart |

### Storage

| Setting | What it means | Default | Who can change it | Takes effect |
|---|---|---|---|---|
| **Evidence folder** | Where screenshots, text files and printouts are kept | `evidence` in the data folder | Developer | After a restart |
| **Log folder** | Where the service log is kept | `logs` in the data folder | Developer | After a restart |

### Fujitsu RACF (this machine)

| Setting | What it means | Default | Who can change it | Takes effect |
|---|---|---|---|---|
| **Fujitsu RACF (second application)** | On: the bot also works on Fujitsu RACF, from the same queue. Its settings appear on the Settings page after the restart. | Off | Developer | After a restart |
| **Fujitsu RACF host (probe)** | The host the Fujitsu RACF availability check connects to. Empty = assumed reachable. Shown while Fujitsu RACF is on. | Empty | Developer | After a restart |
| **Fujitsu RACF port (probe)** | Its port. Shown while Fujitsu RACF is on. | 23 | Developer | After a restart |

Fujitsu RACF is described in 5.9.

### Credentials

Credentials are write-only: the page shows whether each one is set, never its value. Type a value to set or replace it; **leave a field blank to keep what is stored**. The page names the Windows account the values are stored for ("Stored for Windows account: …"): a service started as another Windows account does not see them, and the System page then offers **Use this account**.

**Sample (QA):** the values are stored for the bot account `R6-CORE\prvrnel`.

| Credential | Admin sees it | Takes effect |
|---|---|---|
| **Service account — affiliation code** (5 half-width digits) | Yes | At once |
| **Service account — staff code** (7 half-width letters or digits) | Yes | At once |
| **Service account — password** (8 characters) | Yes | At once; after a restart while CyberArk supplies the password |
| **SMTP password** | Yes | After a restart |
| **ServiceNow — bot account password** (shown on the ServiceNow page) | Yes | At once |
| **ServiceNow — OAuth client secret** (shown on the ServiceNow page) | Yes | At once |
| **CyberArk — PVWA service account password** | Yes | After a restart |
| **Fujitsu RACF service account — password** (only while Fujitsu RACF is on) | Yes | After a restart |
| **Database password**, **Audit database password** | No (Developer) | After a restart |
| **Machine API keys (ServiceNow connector, CLI)** | No (Developer) | After a restart |
| **Console session signing key** (changing it signs everyone out) | No (Developer) | After a restart |
| **Initial administrator password** (removed automatically once the first administrator has chosen their own) | No (Developer) | After a restart |

A saved service-account value is given to the running service at once, so it can be tested straight away; it also lifts the 10-minute wait after a sign-in test that could not sign in (5.4). A value made only of spaces is refused, and so is an affiliation code or staff code that does not follow its rule. When no credential store is available on the server, the page says so and the values must be provided by the server team as environment variables. While **Database password from CyberArk** is On, the database password comes from CyberArk and the stored **Database password** is not used.

### The production environment and the API key

With **Service environment** = Production the service is strict: **Require the machine API key** is On by default, so every other system (for example the ServiceNow connector) must present one of the **Machine API keys**; CyberArk is required with the real terminal (5.3); and the password of a failed request is erased at once. While requests are accepted without an API key, the System page lists this under **Needs attention (n)** › **Security, before production use:** when the real terminal is used, and under **Warnings (n)** › **Security:** otherwise (see 5.7, "Security notices on the System page").

### Common situations

| Situation | What the bot does | Who is told | Which setting decides |
|---|---|---|---|
| You change **Service port** and press **Restart service** | Keeps the port in use; the row and the restart notice say the change applies when the bot is stopped and started again | The person on the console | **Service port**, **Refuse another port** |
| You switch **Database password from CyberArk** On without **CyberArk address (database)** or **CyberArk Application ID (database)** | Refuses the save; nothing is written | The person saving | **CyberArk address (database)**, **CyberArk Application ID (database)** |
| **Read screens with OCR** has been saved on **Settings › Screen reading** | Uses that value; **Screen reading (OCR)** shows "Overridden by …" | The person on the console | **Read screens with OCR** |
| CyberArk does not answer when you press **Restart service**, and the database password settings did not change | Restarts with the database password in use | Nobody | None |
| You switch **Audit database uses the same password** Off | From the next **Restart service**, the audit database signs in with its own stored password | Nobody | **Audit database uses the same password**, **Audit database password** |
| A setting is set by a Windows environment variable | Locks the row and refuses a save of it | The person saving: "Set by a Windows environment variable — change it there." | The environment variable |

---

## 5.9 Fujitsu RACF (optional, switched off by default)

> **In plain words.** Fujitsu RACF is the second mainframe application on which the bot creates and removes accounts, from the same queue as Fujitsu Mainframe. Its configuration names still say TSS. It is off until a Developer switches it on. While it is off, nothing about Fujitsu RACF is shown or done, and Fujitsu Mainframe works exactly as described above. While it is on, a Fujitsu RACF problem never stops Fujitsu Mainframe requests.

**Who does this:** Developer (switching Fujitsu RACF on, the advanced settings and the completion ticket), Admin (the terminal shortcut, the system and sign-on ID, the hours, removals, the team's addresses, the registration notice and the three tests), Fujitsu RACF team (the bot's sign-on ID, test IDs, hours, decisions on removals), CyberArk team (the Fujitsu RACF account in the vault), ServiceNow team (the app team's group and the table of the completion ticket).

### Switching Fujitsu RACF on

1. Under **Settings › This machine › Fujitsu RACF (this machine)**, set **Fujitsu RACF (second application)** to On and save. Set **Fujitsu RACF host (probe)** and **Fujitsu RACF port (probe)** so the host is checked (empty host = assumed reachable).
2. Restart the service. The **Fujitsu RACF** area appears in the Settings navigation with four pages: **Fujitsu RACF terminal and sign-on**, **Fujitsu RACF window**, **Fujitsu RACF tickets and e-mails** and **Fujitsu RACF completion ticket**. **Fujitsu RACF service account — password** appears under **Settings › This machine › Credentials**.
3. Fill in the pages (see the settings below). On a test server set **Fujitsu RACF system** to **TSS3 (test)**. Leave **Fujitsu RACF window title contains** and **Fujitsu RACF terminal program (instead of the shortcut)** empty unless the Fujitsu RACF team asks otherwise.

   **Sample (QA):** **Fujitsu RACF terminal shortcut** `C:\ProgramData\Fujitsu\WSMGR\接続1.emd`; **Fujitsu RACF terminal program (instead of the shortcut)** empty (`接続1` is not a file; the shortcut is used); **Fujitsu RACF window title contains** `接続1 - DSPEMU`; **Fujitsu RACF system** `TSS3`; **Fujitsu RACF sign-on ID** `SAILPNT`; **Start the Fujitsu RACF terminal as administrator** On.

4. Pause processing (System page, **Pause processing**) and run the three tests on **Settings › Fujitsu RACF terminal and sign-on** in order: **Test Fujitsu RACF host**, **Test Fujitsu RACF terminal launch**, then **Test Fujitsu RACF sign-on** once.
5. Resume processing and follow the first Fujitsu RACF request on the **Requests** page.

### What the terminal needs

- The Fujitsu RACF console (WSMGR with the DSPEMU terminal) installed for the account that runs the bot, with the **接続1** connection, which opens the Fujitsu RACF host at `JCET020 SYSTEM READY`.
- **The shortcut.** The bot starts the console through the **接続1** icon on the desktops, or the icon named in **Fujitsu RACF terminal shortcut**. Leave **Fujitsu RACF terminal program (instead of the shortcut)** empty when the console is not started from a program file, which is the normal case for 接続1. Saving a value that is not a file on this machine is refused; a value stored earlier that is not a file is not used: the shortcut is used instead, and the log and the terminal test details say so.
- **Starting as administrator.** **Start the Fujitsu RACF terminal as administrator** stays Off. A WSMGR connection file (.emd), or a shortcut to one, cannot be started as administrator; when the bot itself runs as administrator, the console is opened normally and gets the bot's rights.
- **One start per check or request.** The terminal is started once for each request and each test. When `SYSTEM READY` does not appear, the start is not repeated: the request or test fails at the start, and Fujitsu RACF requests wait until the terminal starts again (see "Fujitsu RACF waits" below).
- **Nothing is started while processing is paused.** While processing is paused, the bot never starts the Fujitsu RACF terminal by itself: the automatic launch and sign-on checks stop too. They also wait while a request or a terminal test of either application is running. Only the tests started on the console run while processing is paused.
- The bot uses only the **接続1 - DSPEMU** window. Windows of other connections (接続2, 接続3) are never touched. With two 接続1 windows open, the start is refused with that reason instead of typing into one of them.
- A 接続1 window left open is brought back first: signed on at READY, it is signed off; waiting at `***`, it is let go on; at `ENTER LOGON OR LOGOFF`, it is answered with LOGOFF; at `REENTER`, it is left with **Ctrl+Shift+A** and nothing is typed. The password prompt is never answered; such a window does not reach `SYSTEM READY` and the start fails.
- Lines are sent with **Shift+Enter**, as on DSPEMU.
- Nobody else should sign on with the bot's sign-on ID while the bot runs: the host then refuses the bot with "ID in use" (see below).

### How a request is processed

For each request the bot follows the operators' procedure:

1. Starts the 接続1 terminal once and waits for `SYSTEM READY`.
2. Types `LOGON <Fujitsu RACF system> <sign-on ID>`, keeps a screenshot of the LOGON line before pressing Shift+Enter, and waits for the password prompt. When the host refuses the LOGON at once (ID in use, ID not authorized, host not available), no password is typed.

   **Sample (QA):** `LOGON TSS3 SAILPNT`

3. Types the password (never shown or written anywhere) and waits for `READY`. Broadcast messages that stop at `***` are let go on.
4. Types `IAMIDADD <RACF ID> <Employee ID> <group>` (create) or `IAMIDDEL <RACF ID>` (remove) and keeps a screenshot of the command before it is sent. From this moment the request is never run again automatically.
5. Reads the job number from its own `JOB ... SUBMITTED` line.
6. At `READY`, asks for the result up to three times, 30 seconds apart, until the `ENDED` line of that job is shown. A job normally ends within about 30 seconds. `ENDED` followed by `- ABENDED` or `- JCL ERROR` is a failed job.
7. Types `LOGOFF`, keeps a screenshot of the LOGOFF line before it is sent, confirms `SESSION ENDED`, `LOGGED OFF` or `SYSTEM READY` (a `***` is answered, a second READY gets a second LOGOFF), and closes the window. This is done after every request, also after a failure. A sign-off that is not confirmed on the screen, or a window that does not close, is noted on the request and in its e-mails.

**Evidence.** Each step is kept as a screenshot with a text file beside it, in the same layout as for Fujitsu Mainframe: a header (request, step, recognised screen, result, how the screen was read, window), the screen text, then an input section with what the bot typed or pressed since the previous file. The password is always blacked out on the screenshots and shown as `****` in the text. The step names are readable, for example LOGON line, password prompt, signed on (READY), LOGOFF line, signed off.

**Screen reading.** The DSPEMU window is read with screen reading (OCR). To keep it fast, only the rows of the terminal area that hold text are read, and only once for each new screen; an unchanged screen is not read again. The row and column indicator at the far right of the window (for example `02/33`), a single character on the last line (the cursor) and the word 処理中 on the cursor row are not taken as part of the screen. Every wait reads the screen once more after its time limit, so a screen that arrived in time is always seen; the evidence of a wait is the screenshot its text was read from. A screen read that takes 5 seconds or more is noted in the log once per run.

### What each outcome means

"Support teams" means the default recipients and the other recipients set for that e-mail on the **Email** page (section 6). The Fujitsu RACF team receives the e-mails marked "(team)" only while **Fujitsu RACF team: support reports only** is Off; with the shipped setting (On) it receives the support report of each ticket and nothing else.

| Case | Final status | Retried? | ServiceNow ticket | Who is told |
|---|---|---|---|---|
| The job ENDED (create or remove) | **Completed** | — | Closed as complete (section 7); a completion ticket is created when it is switched on | Completion notice to the support teams (team); support report; registration notice to the new user when it is switched on |
| The removal names a RACF ID that does not exist (once its wording is set, see "Screen wording") | **Already removed** | No | Closed as complete with a note that no change was needed | Removal e-mail: no change was needed |
| The job ENDED with JCL ERROR (the values were refused) | **Failed** | No | Closed as for a failed request (section 7) | Failure e-mail to the support teams (team) |
| The job ABENDED | The command is run once more, as the procedure says; if it abends again, **Failed** | No (the one re-run is part of the procedure) | Closed as for a failed request | Failure e-mail (team) |
| No SUBMITTED line, or no result after the three checks | **Needs verification** | No | Closed as Closed Incomplete with the note "… Closed as incomplete; if the change is still needed, submit a new request.", while **Close the ticket when the request failed** is On (the shipped setting); otherwise it stays open with the review note (section 7). No completion ticket is created. | "Please verify" e-mail (team) |
| Wrong password: the password is rejected | **Failed** at once, before any change | No: the same password is never typed again, so the sign-on ID is not locked | Closed as for a failed request | Fujitsu RACF team, plus the CyberArk team when CyberArk supplies the password; other Fujitsu RACF requests wait (see below) |
| Password expired | **Failed** before any change | No | Closed as for a failed request | Fujitsu RACF team, plus the CyberArk team when CyberArk supplies the password; Fujitsu RACF requests wait |
| Sign-on ID revoked, or not authorized for this system | **Failed** before any change | No | Closed as for a failed request | Fujitsu RACF team; Fujitsu RACF requests wait |
| Sign-on refused with a message the bot does not recognise | **Failed** before any change; the message is quoted | No | Closed as for a failed request | Fujitsu RACF team |
| Nothing follows the password (no READY, no message) | **Failed** before any change | No: the bot ends once and sends LOGOFF, so no session is left open | Closed as for a failed request | Failure e-mail |
| `LOGON REJECTED ... IN USE`: the sign-on ID is signed on elsewhere | The request **waits** in the queue; no attempt is counted, no password is typed | Yes, automatically, once the ID is free | Stays open | Fujitsu RACF outage and recovery e-mails (team) |
| `JCET014 ... NOT AVAILABLE`: the host answers that Fujitsu RACF is not available | The request **waits**, as for "ID in use"; no password is typed | Yes, automatically | Stays open | Fujitsu RACF outage and recovery e-mails (team) |
| The host does not answer the probe | Fujitsu RACF requests **wait** | Yes, once it answers | Stays open | Fujitsu RACF outage and recovery e-mails (team) |
| The Fujitsu RACF terminal cannot be started, or shows no SYSTEM READY | Fujitsu RACF requests **wait** | Yes, once it starts | Stays open | Fujitsu RACF terminal outage and recovery e-mails (team) |

The e-mails about sign-on refusals are sent also while **Per-error notices** is Off, because Fujitsu RACF requests wait until the cause is corrected. The reasons in Fujitsu RACF e-mails use Fujitsu RACF wording (RACF ID, group, Fujitsu RACF system).

### Fujitsu RACF waits, Fujitsu Mainframe continues

Fujitsu RACF has its own operating window and its own checks. In each of these cases new Fujitsu RACF requests wait in the queue while Fujitsu Mainframe requests keep running, and the System page says why:

- **Outside the Fujitsu RACF window** (**Fujitsu RACF window opens (JST)** / **Fujitsu RACF window closes (JST)**).
- **The host does not answer** the probe (**Probe Fujitsu RACF**, **Fujitsu RACF host (probe)**). It is checked again automatically; **Test Fujitsu RACF host** checks it at once.
- **The terminal cannot be started.** The launch is tried again every 5 minutes without signing on; a successful **Test Fujitsu RACF terminal launch** ends it at once.
- **The sign-on ID is in use, or the host is not available.** The sign-on is tried again every 5 minutes. While the ID is in use the host refuses the LOGON before the password, so no password is typed; once the ID is free the bot signs on and off and the waiting requests continue. A successful **Test Fujitsu RACF sign-on** ends it at once.
- **A refused password or sign-on ID** (rejected, expired, revoked, not authorized). The requests continue when another password is delivered (CyberArk, or **Settings › This machine › Credentials** and a restart), when a corrected **Fujitsu RACF sign-on ID** is saved and the service restarted, when **Test Fujitsu RACF sign-on** passes, or when processing is paused and resumed on the System page. The automatic sign-on above is never tried while a password is refused.
- **No password yet**, or CyberArk has not delivered it where CyberArk is required.
- **Screen reading is not available**, so the Fujitsu RACF screen cannot be read.

While the bot's Windows session is locked, disconnected or does not take keystrokes, the requests of **both** applications wait (5.4, "The bot's Windows session").

The automatic launch and sign-on checks run only while the desktop is free: never while processing is paused, and never while a request or a terminal test is running. One outage e-mail is sent when a wait starts and one recovery e-mail when it ends, to the support teams (and the Fujitsu RACF team while its support-reports-only switch is Off).

### The three tests (Settings › Fujitsu RACF terminal and sign-on)

The three tests are in the **Tests** row of **Settings › Fujitsu RACF terminal and sign-on** (also in the setup assistant) and can be run by an Admin or a Developer. **Test Fujitsu RACF host** uses the Fujitsu RACF host and port of the machine settings. The terminal tests use the settings the service was started with (restart after changing them) and need processing to be paused; they refuse to run while a request is still running. No command is ever typed.

| Test | What it does | E-mails |
|---|---|---|
| **Test Fujitsu RACF host** | Checks that the Fujitsu RACF host and port accept a connection. No terminal, no sign-on. Without a host set it says that the availability check assumes the host is reachable. | Outage on a failure (once per outage), recovery on a later pass |
| **Test Fujitsu RACF terminal launch** | Starts 接続1, waits for SYSTEM READY and closes it. No sign-on. | A failure opens the terminal outage (Fujitsu RACF requests wait); a pass ends it |
| **Test Fujitsu RACF sign-on** | Also signs on with the service account and off again. Asks for confirmation first, because a wrong password counts toward the lock-out. Refused outside the Fujitsu RACF window and while CyberArk has not delivered the password. Run it once after each correction. | A refusal sends the sign-on e-mail to the team that owns it (see the outcomes table), also while transaction e-mails are off. "ID in use" or "not available" opens the outage instead. A pass ends a refused-password wait and an "ID in use" outage. |

**How the results read.** Each test answers in one plain sentence, for example "Fujitsu RACF sign-on test passed: the bot signed on and off successfully." or "Fujitsu RACF sign-on test failed: the password was not accepted. Check the password before trying again." The sentence adds who was informed by e-mail, if anyone. Below it, **Show details** opens the rest:

- what was proven at each level (the terminal started and showed SYSTEM READY; the service account signed on to READY; the sign-off was confirmed) and that no command was typed;
- on a failure, the step it stopped at and what the host answered, and "No password was typed." when the host refused the LOGON before the password;
- whether the terminal window was closed, or a warning when the sign-off could not be confirmed or the window stayed open;
- the terminal used and the setting the service started with;
- the screenshots taken, by name (SYSTEM READY, LOGON line, password prompt, signed on (READY), LOGOFF line, signed off, and on a failure the refused screen);
- who the e-mails reach, with a note when no Fujitsu RACF team address is set or when the team receives support reports only.

### Settings: Fujitsu RACF terminal and sign-on

| Setting | What it means | Default | Who can change it | Takes effect |
|---|---|---|---|---|
| **Fujitsu RACF terminal shortcut** | The full location of the desktop icon that opens the Fujitsu RACF console (DSPEMU). Empty = it is looked for on the desktops. Sample (QA): `C:\ProgramData\Fujitsu\WSMGR\接続1.emd` | Empty (the 接続1 icon on the desktops) | Admin | After a restart |
| **Fujitsu RACF terminal program (instead of the shortcut)** | The program file, when the console is started directly. Leave it empty when it is not a file; a value that is not a file is refused on save. Sample (QA): empty (`接続1` is not a file; the shortcut is used) | Empty | Developer | After a restart |
| **Fujitsu RACF window title contains** | The title of the terminal window the bot uses; with two such windows open the start is refused. Sample (QA): `接続1 - DSPEMU` | 接続1 - DSPEMU | Developer | After a restart |
| **Start the Fujitsu RACF terminal as administrator** | See "What the terminal needs". Sample (QA): On (the 接続1.emd shortcut has no administrator start, so the console is opened normally and gets the bot's rights when the bot runs as administrator) | Off | Developer | After a restart |
| **Fujitsu RACF system** | The system in the sign-on command: **TSS2 (production and development)** or **TSS3 (test)**. Sample (QA): `TSS3` | TSS2 | Admin | After a restart |
| **Fujitsu RACF sign-on ID** | The bot's RACF ID; its password is a credential, not set here. Sample (QA): `SAILPNT` | SAILPNT | Admin | After a restart |
| **RACF sign-on ID password: change automatically** | Not available for Fujitsu RACF: leave Off | Off | Developer | At once |
| **RACF sign-on ID password: last changed on** | The date of the last change (YYYY-MM-DD), entered when the bot does not know it | Empty | Admin | At once |
| **RACF sign-on ID password: expires after (days)** | When the host expires the password | 90 | Developer | At once |
| **RACF sign-on ID password: change after (days)** | From this age the reminder is sent | 80 | Developer | At once |
| **RACF sign-on ID password: urgent e-mail (days before expiry)** | From this many days before the expiry an urgent reminder is sent every day | 5 | Developer | At once |
| **RACF sign-on ID password: stop after failed tries** | Used only by an automatic change, which Fujitsu RACF does not have | 2 | Developer | At once |

The password settings are described in section 5.3, "Password age and reminders". The **Tests** row of this page also shows the age of the password; **Check password age now** (Developer) runs the hourly check at once.

### Settings: Fujitsu RACF window

| Setting | What it means | Default | Who can change it | Takes effect |
|---|---|---|---|---|
| **Fujitsu RACF window opens (JST)** | Fujitsu RACF requests start only inside this window; Fujitsu Mainframe keeps its own | 06:00 | Admin | After a restart |
| **Fujitsu RACF window closes (JST)** | No Fujitsu RACF request is started after this time | 22:00 | Admin | After a restart |
| **Probe Fujitsu RACF** | Checks that the Fujitsu RACF host answers; Fujitsu RACF requests wait while it does not | On | Developer | After a restart |

### Settings: Fujitsu RACF tickets and e-mails

| Setting | What it means | Default | Who can change it | Takes effect |
|---|---|---|---|---|
| **Fujitsu RACF application IDs** | A ticket naming one of these, for example [6582], is a Fujitsu RACF ticket. Sample (QA): `6582` (ticket text "Fujitsu RACF (Resource Access Control Facility) [6582]") | 6582 | Developer | At once |
| **RACF group attribute** | The attribute name of the RACF group on the ticket | Entitlement | Developer | At once |
| **Fujitsu RACF removals** | See "Fujitsu RACF removals" below | **Left for a person (the ticket is told why)** | Admin | At once |
| **Fujitsu RACF team** | The team's addresses (commas or semicolons). It receives the support report of each Fujitsu RACF SailPoint ticket; with the next switch Off, also the outage, recovery, refused sign-on, "result to verify" and completion e-mails of Fujitsu RACF | Empty | Admin | At once |
| **Fujitsu RACF team CC** | Copied on the e-mails to the Fujitsu RACF team | Empty | Admin | At once |
| **Fujitsu RACF team: support reports only** | On: the team and its CC list receive only the support report of each Fujitsu RACF SailPoint ticket; every other e-mail goes to the support teams. Off: the team also receives those e-mails | On | Admin | At once |
| **Registration notice to the new user (Fujitsu RACF)** | The notice to the person whose RACF ID was created (see "Fujitsu RACF e-mails"). Needs **Transaction outcome emails** on | Off | Admin | After a restart |
| **Registration notice CC (Fujitsu RACF)** | Copied on the registration notice, for example the app team; everyone copied reads the initial password rule. Empty: no copy | Empty | Admin | At once |

### Settings: Fujitsu RACF completion ticket

All settings of this page are for the Developer role and take effect at once. They are listed in "The Fujitsu RACF completion ticket" below.

### Settings: This machine › Fujitsu RACF (this machine)

| Setting | What it means | Default | Who can change it | Takes effect |
|---|---|---|---|---|
| **Fujitsu RACF (second application)** | On: the bot also works on Fujitsu RACF, from the same queue | Off | Developer | After a restart |
| **Fujitsu RACF host (probe)** | The host the availability check connects to. Empty = assumed reachable | Empty | Developer | After a restart |
| **Fujitsu RACF port (probe)** | The port of that check | 23 | Developer | After a restart |

### Fujitsu RACF removals

| Choice | What happens to a removal, transfer, termination or certification ticket |
|---|---|
| **Left for a person (the ticket is told why)** (default) | The ticket is not queued. It receives the reason ("Fujitsu RACF removals are handled by a person on this server", with the RACF ID and group) and is handed to the hand-over group when one is set; a person removes the access and closes the ticket. The bot never closes such a ticket, also when it closes rejected tickets. No completion ticket follows. |
| **Remove the whole RACF ID** | The bot removes the RACF ID with `IAMIDDEL`. The command removes the whole ID, also for a ticket that names one group or a certification. Choose it only when a RACF ID carries one group. |

A ticket that was left for a person while removals were manual stays with that person after the choice is changed to **Remove the whole RACF ID**, as long as its content does not change.

Keep **Left for a person** until a removal has been tested with the Fujitsu RACF team in the test system.

With **Ticket checks** set to **none** (testing only, section 5.1), a Fujitsu RACF ticket that fails its checks, a removal left for a person included, is queued as an unchecked request and cancelled before the terminal step: nothing is typed on Fujitsu RACF.

### The Fujitsu RACF completion ticket

> **In plain words.** After the bot has created or removed a RACF ID, it can open a new ServiceNow ticket for the app team's group, so the team can check the change from their side. It is off by default and only for Fujitsu RACF; Fujitsu Mainframe requests never create one.

**When it is created.** Once, after a Fujitsu RACF request ends successfully with one of the chosen outcomes:

| Outcome | When |
|---|---|
| `provision` | A RACF ID was created (job ENDED) |
| `deprovision` | A RACF ID was removed on a removal, transfer or termination ticket |
| `certification` | A RACF ID was removed on a certification ticket |
| `already_removed` | The RACF ID to remove did not exist (not chosen by default) |

Removals and certifications are done by the bot only with **Fujitsu RACF removals** set to **Remove the whole RACF ID**. A failed request, a request that needs verification and a removal left for a person never create a completion ticket.

**Settings (Settings › Fujitsu RACF completion ticket):**

| Setting | What it means | Default | Who can change it | Takes effect |
|---|---|---|---|---|
| **Completion ticket in ServiceNow** | Creates the completion ticket after each successful Fujitsu RACF create or removal | Off | Developer | At once |
| **Completion ticket: table** | The ServiceNow table, for example incident or sc_task | Empty = incident | Developer | At once |
| **Completion ticket: assignment group** | The app team's group: its name or its sys_id. Without a group no ticket is created. Sample (QA): `MFT-SYS Programmer-JPN` | Empty | Developer | At once |
| **Completion ticket: one per** | **Request (default)**, or **ServiceNow ticket, once all its requests are done** (only when all of its Fujitsu RACF requests succeeded) | Request | Developer | At once |
| **Completion ticket: for these outcomes** | Any of provision, deprovision, already_removed, certification | Empty = provision, deprovision, certification | Developer | At once |
| **Completion ticket: after creating it** | **Leave it open for the app team (default)**, or **Resolve it (fields when resolved)** | Leave it open | Developer | At once |
| **Completion ticket: fields when resolved** | field=value pairs separated by `;`, set when the ticket is resolved, for example `state=6; close_code=Solved (Permanently); close_notes=Done by the bot`. Shown only with **Resolve it** | Empty | Developer | At once |
| **Completion ticket: other fields** | The table's other fields as field=value pairs, for example `caller_id=<sys_id>; category=inquiry; contact_type=self-service; impact=3; urgency=3; cmdb_ci=<sys_id>` | Empty | Developer | At once |
| **Completion ticket: short description** | The title, with placeholders (below); at most 160 characters | Empty = `Fujitsu RACF {operation} completed: {racf_id} ({ticket})` | Developer | At once |
| **Completion ticket: description** | The text, with the same placeholders; `\n` starts a new line | Empty = one detail per line (below) | Developer | At once |

A field name that is not a ServiceNow column name, a pair without `=`, or a placeholder that does not exist is refused on save.

**Placeholders:** `{ticket}` (the source SailPoint ticket), `{operation}` (create or removal), `{full_name}`, `{racf_id}`, `{employee_id}`, `{groups}`, `{environment}` (the Fujitsu RACF system), `{job}`, `{result_line}`, `{completed_at}` (JST), `{request_id}`, `{evidence}` (the name of the evidence folder). A password is never available to these texts.

**The default description** begins "The AIG IAM Access RPA bot completed this Fujitsu RACF request. Please check the change from your side." and then gives one line each: Source ServiceNow ticket (SailPoint request), Operation, User full name, Employee ID, RACF ID, Group, Fujitsu RACF system, Job, Result and Completed. The full name is the one on the SailPoint ticket, else the ServiceNow user the ticket is requested for.

**The ticket the bot creates** holds the short description, the description, the assignment group (a group name is looked up once and its sys_id used), the other fields, and, with **Resolve it**, the fields when resolved.

**Test completion ticket.** The **Tests** row of the page has **Test completion ticket** (Developer). It creates one sample ticket with the SAVED settings and fictional sample values, its short description starting with `[TEST]`; save your changes first. While it runs the page says "Creating a sample completion ticket in ServiceNow with the saved settings…"; it then answers with the number, the table and the group, or with the reason it was not created. No e-mail is sent and nothing is kept in a request.

**Retries.** The first attempt is made when the request ends, with a short time limit, so the completion e-mail can name the new number. When ServiceNow does not take it, the bot tries again in the background (after about 30 seconds, 2 minutes and 10 minutes) and then every 10 minutes, at most 12 attempts in all, also after a restart. The request itself is never failed or delayed by this. A missing or wrong setting (no assignment group, a table name that is not valid) does not use up attempts: the ticket is created within 10 minutes after the setting is saved.

**The "Completion ticket" row.** The details of a Fujitsu RACF request show a **Completion ticket** row: the number and table once created; "Not created yet: …" with the missing setting; or "Being created in ServiceNow" with the last reason while attempts continue. Each ticket created is also recorded in the audit trail.

**Tables and permissions.** Use **incident** (the default) or **sc_task**. A refusal with HTTP 403 on **sc_request** or **sc_req_item** means the bot's ServiceNow account may not create records in that table: this is a ServiceNow permission (ACL) matter for the ServiceNow team, not a fault of the bot. Creating a catalog request (REQ) for the app team is not available.

### Fujitsu RACF e-mails

Section 6 lists every e-mail. For Fujitsu RACF in short:

- **The Fujitsu RACF team** (**Fujitsu RACF team**, **Fujitsu RACF team CC**) receives the support report of each Fujitsu RACF SailPoint ticket. While **Fujitsu RACF team: support reports only** is On (the default), that is all it receives; switched Off, it also receives the outage and recovery e-mails, refused sign-ons, results to verify and the "Provisioning completed" and "Deprovisioning completed" notices of Fujitsu RACF requests. Without a team address, these e-mails reach the support teams only.
- **The CyberArk team** is added to a rejected or expired Fujitsu RACF password when CyberArk supplies that password.
- **Registration notice to the new user.** With **Registration notice to the new user (Fujitsu RACF)** On (and **Transaction outcome emails** on), the person whose RACF ID was created receives one notice per ticket, also when the ticket names several groups, in Japanese then English, with the subject `【連絡】ＴＳＳユーザーＩＤ作成完了のお知らせ / [Notice] TSS User ID Created`. It gives the user ID, the initial password rule (the same as the user ID) and the password rules, never a password. **Registration notice CC (Fujitsu RACF)** is copied on it.
- **Rejected tickets.** The e-mail about a Fujitsu RACF ticket the bot did not take uses Fujitsu RACF field labels and says that the request did not reach Fujitsu RACF and no change was made.
- **Duplicate or overtaken tickets.** The "Request rejected (Duplicate request)" e-mail about a Fujitsu RACF ticket uses the Fujitsu RACF labels and recipients, and the audit record names the application. Its **Matching fields** row names, in the language of the e-mail, the values that matched: **Operation** and **RACF ID**, or **Access Request ID** for the same access request. A ticket overtaken by a newer ticket with the opposite operation adds "(opposite operation)". The ServiceNow field names that matched are kept in the audit trail only.
- **Please verify.** When a job was submitted but its result could not be confirmed, the e-mail "Please verify: the result for `<ticket>` could not be confirmed" (Japanese and English) says that the bot submitted the job for the RACF ID but could not confirm whether the change was applied, and gives a **Reason** line: no result (ENDED, ABENDED or JCL ERROR) after the three checks 30 seconds apart, with the job number; no SUBMITTED line after the command; Windows stopped accepting the bot's keystrokes after the command; or a step that did not finish after the command. The details add the **Employee ID** and the **Job number**, and a note that the screenshots of each step are on the console under **Evidence** for the request. What to do: check the RACF ID in Fujitsu RACF; the ticket was closed as Closed Incomplete and the request is not run again; ask for a new request only if the change was not applied. No completion ticket is created for such a request.
- **Successful requests** carry a note when the sign-off could not be confirmed or the window stayed open.

### Seeing Fujitsu RACF on the console

While Fujitsu RACF is on:

- Lists, request details and Evidence show an application badge (**Fujitsu Mainframe** or **Fujitsu RACF**), and **Requests**, **History**, **Reports** and **Audit trail** have an **Application** filter.
- The two code columns of **Requests**, **History** and **Audit trail** are named after the application chosen in the filter: **RACF group** and **RACF ID** for Fujitsu RACF, **Affiliation** and **Employee code** for Fujitsu Mainframe, and **Group / affiliation** and **User ID** for a list of both. The request details, the Dashboard and the audit details use the labels of the request's own application (**RACF group** / **RACF ID**, or **Affiliation code** / **Employee code**).
- The header shows a chip with the Fujitsu RACF system, for example "Fujitsu RACF: TSS2".
- The System page has a **Fujitsu RACF** card: its system and window, "terminal could not be started" or "sign-on ID in use or host not available" when that is the case, and the first reason why Fujitsu RACF requests wait, or "Fujitsu Mainframe runs separately". The Fujitsu Mainframe window card is then named **Fujitsu Mainframe window**.

### The service-account password

The bot cannot change its own Fujitsu RACF password. It keeps track of the password's age and e-mails reminders when the change is due, urgent or overdue; a person then changes the password and delivers it (CyberArk, or **Settings › This machine › Credentials**). See section 5.3, "Password age and reminders".

### Credentials

The Fujitsu RACF password is either stored under **Settings › This machine › Credentials** as **Fujitsu RACF service account — password** (read when the service starts, so a restart follows) or fetched from CyberArk over the same connection as the Fujitsu Mainframe password. The Fujitsu RACF account in the vault is set in the CyberArk configuration on the server, not on the console. In production with the real terminal, the password must come from CyberArk. A rejected Fujitsu RACF password asks CyberArk for the Fujitsu RACF account only.

### Screen wording kept in configuration

The words the bot recognises on the Fujitsu RACF screen (the prompts, the refusals, the job lines, the sign-off, the lines that are not terminal output such as the row and column indicator) are kept in the Fujitsu RACF screen file of the application, so a change in wording is an edit by the support team, not a new version.

- **Host not available** is set to the host's answer `NOT AVAILABLE` (as in `JCET014 TSS3 NOT AVAILABLE`), matched only on the host's answer to LOGON, before any password is typed.
- **RACF ID not found** on a removal ships empty until the Fujitsu RACF team has confirmed the host's exact wording. Until it is set, such a removal ends as **Needs verification**.

### What is not available

- Fujitsu RACF runs only on the real terminal driver **Pywinauto**, or on the simulated drivers for testing.
- One group per new RACF ID; a ticket that both adds and removes groups is left for a person.
- Removing a single group from a RACF ID: a removal always removes the whole ID.
- Changing the bot's own Fujitsu RACF password: reminders only.
- Creating a catalog request (REQ) as the completion ticket.
- With **Transaction outcome emails** Off, a Fujitsu RACF "not available" answer may also send the general error e-mail.

### Common situations

| Situation | What the bot does | Who is told | Which setting decides |
|---|---|---|---|
| Fujitsu RACF is off and a Fujitsu RACF ticket arrives | Does not take it; it counts as not in the selection | Nobody | **Fujitsu RACF (second application)** |
| A removal ticket arrives with the shipped settings | Does not queue it; writes the reason on the ticket and leaves it for a person | ServiceNow ticket | **Fujitsu RACF removals** |
| **Fujitsu RACF terminal program** holds a value that is not a file (for example 接続1) | Refuses to save it; a value stored earlier is not used and the shortcut is used | Noted in the log and in the terminal test details | Leave **Fujitsu RACF terminal program (instead of the shortcut)** empty |
| Processing is paused | Starts no Fujitsu RACF terminal by itself; the automatic checks wait | Nobody | System page, **Pause processing** |
| Someone is signed on with the bot's sign-on ID | Fujitsu RACF requests wait; the sign-on is tried again every 5 minutes; Fujitsu Mainframe continues | Outage and recovery e-mails | None |
| The host answers NOT AVAILABLE | Fujitsu RACF requests wait; the sign-on is tried again every 5 minutes; no password is typed | Outage and recovery e-mails | None |
| A 接続1 window was left open | Signs it off and uses it | Nobody | None |
| Two 接続1 windows are open | Refuses to start; Fujitsu RACF requests wait | Terminal outage e-mail | Close one window |
| The service-account password is rejected | Fails the request at once, without a retry; Fujitsu RACF requests wait for another password | Fujitsu RACF team (plus CyberArk team when CyberArk supplies it) | **Settings › This machine › Credentials** or CyberArk |
| Nothing follows the password | Fails the request once and sends LOGOFF | Failure e-mail | None |
| A job ends with JCL ERROR | Fails the request; does not retry | Failure e-mail | None |
| A job abends | Runs the command once more; if it abends again, Failed | Failure e-mail | None |
| A Fujitsu RACF ticket repeats an earlier one, or is overtaken by a newer ticket with the opposite operation | Does not queue it | "Request rejected (Duplicate request)" with the Fujitsu RACF matching fields (Operation, RACF ID) | **Duplicate check window (days)** (for a repeated request; the opposite-operation rule always applies) |
| The bot's Windows session is locked or minimized | Fujitsu RACF and Fujitsu Mainframe requests wait and resume by themselves | "Bot Windows session Not Available" and "Recovered" e-mails | None on the console (5.4) |
| No job result after three checks | Needs verification; the ticket is closed as Closed Incomplete with a note; no completion ticket | "Please verify" e-mail with the reason, the job number and the Employee ID | **Close the ticket when the request failed** (ServiceNow) |
| The Fujitsu RACF team receives only support reports | Works as shipped | — | **Fujitsu RACF team: support reports only** |
| The new user received no registration notice | Sends it only when the notice and transaction e-mails are on | — | **Registration notice to the new user (Fujitsu RACF)**, **Transaction outcome emails** |
| No completion ticket after a successful create | "Not created yet" in the **Completion ticket** row: a setting is missing (often the assignment group) | Nobody | **Settings › Fujitsu RACF completion ticket** |
| **Test completion ticket** fails with HTTP 403 on sc_request or sc_req_item | Creates nothing | — | Ask the ServiceNow team for the permission, or use incident or sc_task |
| A ticket names both Fujitsu Mainframe and Fujitsu RACF | Leaves it for a person | ServiceNow ticket | **Accepted application IDs**, **Fujitsu RACF application IDs** |
## 6. Every e-mail at a glance

> **In plain words.** These tables list every e-mail the bot can send, for Fujitsu Mainframe and for Fujitsu RACF: when, to whom with the shipped settings, which switches must be On, and what happens if the mail server does not accept it. "Default recipients" always means **Default recipients** plus **Default CC**. Every row needs **Send email alerts** On with a valid mail server and From address, and at least one recipient for that e-mail.

**How to read the "Sent to" column.** The column shows who receives the e-mail with the shipped settings. Three settings change it:

- **Fujitsu Mainframe team: support reports only** (On by default, page **Settings › Fujitsu Mainframe tickets and e-mails**). While it is On, the **Fujitsu Mainframe team** receives only the support report of its SailPoint tickets. Switched Off, the team is also added to the e-mails marked "(+ Fujitsu Mainframe team)" below.
- **Fujitsu RACF team: support reports only** (On by default, page **Settings › Fujitsu RACF tickets and e-mails**). The same rule for the **Fujitsu RACF team** and the e-mails marked "(+ Fujitsu RACF team)".
- A team list that is blank is simply left out. When an e-mail has no recipient at all, it is not sent and the audit trail records an `email_skipped` event.

The **E-mail samples** section of **Settings › E-mail** shows the same list for your own settings: each e-mail, whether it is switched on and who receives it now (see section 5.2). It includes the database password e-mails and the **Bot Windows session** notices.

### E-mails about Fujitsu Mainframe requests

| E-mail | Sent when | Sent to | Switches that must be On | If sending fails |
|---|---|---|---|---|
| Registration notice (template) | A new Fujitsu Mainframe account is created and confirmed, from a SailPoint ticket, or from a console request that carries the user's address. Once per code. | The new user only | **Transaction outcome emails**; **Registration notice to the new user** | Kept in the outbox. If it cannot be delivered, the support report says so. |
| Password notice (template) | With the registration, as a separate e-mail. Also sent while the registration notice is Off. | The new user only | **Transaction outcome emails**; **Send the initial password to the new user** | Kept in the outbox as a record without the password, and built again when it is resent, for at most 72 hours. If it is given up, reset the password and tell the user. |
| Support report (template) | Every affiliation code of a Fujitsu Mainframe SailPoint ticket has finished, whatever the results. Again if an outcome changes later, for example after a retry. | **Support report recipients** and **Support report CC** (blank: default recipients), plus the **Fujitsu Mainframe team** when its list is set | **Transaction outcome emails**; **Support report per SailPoint ticket** | Kept in the outbox |
| Provisioning completed | A new account was created and confirmed. For SailPoint codes only while **Completion notices for SailPoint tickets** is On (default) or the support report is Off. | Default recipients (+ Fujitsu Mainframe team) | **Transaction outcome emails** | Kept in the outbox |
| Deprovisioning completed | Access was removed, or the account was already removed. Same rule for SailPoint codes. | Default recipients (+ Fujitsu Mainframe team) | **Transaction outcome emails** | Kept in the outbox |
| Transaction failed | A request failed for good on an error that has no e-mail of its own. Includes a note when the terminal session may still be open. | Default recipients | **Transaction outcome emails** | Kept in the outbox |
| Result not confirmed ("Please verify") | The change was sent but the result could not be read. Also at start for a request interrupted at that point. Asks for the account to be checked in Fujitsu Mainframe, says that the bot closed the ServiceNow ticket as Closed Incomplete and that the request is not run again, and that a new request is raised only if the change was not applied. | Default recipients | **Transaction outcome emails** | Kept in the outbox |
| Login rejected: service-account password | Fujitsu Mainframe rejected the service-account password on the final attempt. | **CyberArk / identity team** plus error-alert (or default) recipients | **Transaction outcome emails**, and either **Per-error notices** or a **CyberArk / identity team** list | Kept in the outbox |
| Login rejected: operator code not registered, affiliation code not valid, message not recognised; employee code not found; employee code error | Fujitsu Mainframe refused the codes. Nothing was changed. | **Fujitsu Mainframe account administration** plus error-alert (or default) recipients | **Transaction outcome emails**, and either **Per-error notices** or a **Fujitsu Mainframe account administration** list | Kept in the outbox |
| Line error | The host was not available on every attempt. | Error-alert (or default) recipients (+ Fujitsu Mainframe team) | **Transaction outcome emails**, and either **Per-error notices** or the Fujitsu Mainframe team receiving more than support reports | Kept in the outbox |
| Centre not ready | The host showed センター準備中 on every attempt. | Error-alert (or default) recipients (+ Fujitsu Mainframe team) | **Transaction outcome emails**; **Per-error notices** | Kept in the outbox |
| Console sign-in test refused (Fujitsu Mainframe) | **Test sign-in and navigation** was refused because of the service account's own values. Names the person who ran the test; no request is involved. | As the matching notice above | As the matching notice above | Kept in the outbox |
| Request rejected (Validation failed) | A ServiceNow ticket fails the ticket checks (once per ticket until it changes), or a program submits invalid values. | Default recipients | **Transaction outcome emails** | Kept in the outbox |
| Request rejected (Duplicate request) | A ticket or submission duplicates an earlier request, or an older ticket is overtaken by a newer one for the same person. Names the earlier ticket and the **Matching fields** in plain words: Operation, Affiliation code and FFM Application ID / Employee code, or Access Request ID; "(opposite operation)" for a ticket overtaken by a newer one. | Default recipients | **Transaction outcome emails** | Kept in the outbox |

When neither the per-error notice nor the owning team's list applies, a failed request sends the general **Transaction failed** e-mail instead. The CyberArk / identity team and the account administration team always receive their e-mail when their list is set, also while **Per-error notices** is Off. The Fujitsu Mainframe team and the Fujitsu RACF team receive the e-mails of their own errors only while their "support reports only" switch is Off.

### E-mails about Fujitsu RACF requests (only while Fujitsu RACF is switched on)

| E-mail | Sent when | Sent to | Switches that must be On | If sending fails |
|---|---|---|---|---|
| Registration notice to the new user (Fujitsu RACF template) | A RACF ID was created from a Fujitsu RACF SailPoint new-account ticket. In Japanese, then English, in one e-mail: the user ID, the rule for the initial password and the password rules, never a password. One notice per ticket and RACF ID. Subject: 【連絡】ＴＳＳユーザーＩＤ作成完了のお知らせ / [Notice] TSS User ID Created. | The new user, with **Registration notice CC (Fujitsu RACF)** copied when it is set | **Transaction outcome emails**; **Registration notice to the new user (Fujitsu RACF)** (Off by default) | Kept in the outbox |
| Support report (Fujitsu RACF template) | A Fujitsu RACF SailPoint ticket has finished, whatever the result: RACF ID, RACF group and result. | **Support report recipients** and **Support report CC** (blank: default recipients), plus the **Fujitsu RACF team** when its list is set | **Transaction outcome emails**; **Support report per SailPoint ticket** | Kept in the outbox |
| Provisioning completed (Fujitsu RACF) | A RACF ID was created and the job ENDED. Names the completion ticket for the app team when one was made, and adds a note when the sign-off could not be confirmed. Same SailPoint rule as for Fujitsu Mainframe. | Default recipients (+ Fujitsu RACF team) | **Transaction outcome emails** | Kept in the outbox |
| Deprovisioning completed (Fujitsu RACF) | A RACF ID was removed (only while **Fujitsu RACF removals** removes the whole RACF ID), or was already removed (only once the "RACF ID not found" wording is set; until then such a removal ends as **Needs verification**, see section 5.9). | Default recipients (+ Fujitsu RACF team) | **Transaction outcome emails** | Kept in the outbox |
| Transaction failed (Fujitsu RACF) | Once, after the last attempt: the job ended with JCL ERROR, abended twice, or the screen did not answer as expected. | Default recipients (+ Fujitsu RACF team) | **Transaction outcome emails** (while it is Off, the general error e-mail is sent instead) | Kept in the outbox |
| Result not confirmed (Fujitsu RACF, "Please verify") | No SUBMITTED line or no job result after the checks, or the result could not be read after the command was entered. The request shows **Needs verification**. The e-mail gives the **Reason**, the **Employee ID**, the **Job number** when the job was submitted, and where the screenshots are. It says that the bot closed the ServiceNow ticket as Closed Incomplete. No completion ticket is created. | Default recipients (+ Fujitsu RACF team) | **Transaction outcome emails** (while it is Off, the general error e-mail is sent instead) | Kept in the outbox |
| Request rejected (Handled by a person) | A removal, transfer, termination or certification ticket arrives while **Fujitsu RACF removals** leaves removals for a person (the default). | Default recipients | **Transaction outcome emails** | Kept in the outbox |
| Request rejected (Validation failed or Duplicate request), Fujitsu RACF | A Fujitsu RACF ticket cannot be processed (for example a RACF ID longer than 8 characters, a missing group or Employee ID, or more than one group to add), or duplicates an open request. Uses the Fujitsu RACF field labels and says that the request did not reach Fujitsu RACF. A duplicate names **Operation** and **RACF ID** (or **Access Request ID**) as the matching fields. | Default recipients | **Transaction outcome emails** | Kept in the outbox |
| Fujitsu RACF sign-on refused: password not accepted, password expired, sign-on ID revoked, sign-on ID not authorized, message not recognised | During a request, or during **Test Fujitsu RACF sign-on** (the test version names the person who ran it). Fujitsu RACF requests wait; Fujitsu Mainframe keeps running. | Error-alert (or default) recipients (+ Fujitsu RACF team), plus the **CyberArk / identity team** for a password not accepted or expired when CyberArk supplies the Fujitsu RACF password | **Send email alerts** only. Sent whatever **Transaction outcome emails** and **Per-error notices** say. | Kept in the outbox |

### E-mails about the systems

| E-mail | Sent when | Sent to | Switches that must be On | If sending fails |
|---|---|---|---|---|
| CyberArk Not Available / Recovered | CyberArk does not deliver the Fujitsu Mainframe or the Fujitsu RACF password. Recovered on the next successful fetch. The database password has its own notice (next section). | Default recipients and **CyberArk / identity team** | **Send email alerts** only | Kept in the outbox |
| Fujitsu Mainframe Not Available / Recovered | The mainframe check fails, or the terminal cannot be started (its own subject). Recovered when it works again. | Default recipients (+ Fujitsu Mainframe team) | **Send email alerts** only | Kept in the outbox |
| Fujitsu RACF Not Available / Recovered | Only with Fujitsu RACF switched on: the host check fails, the terminal cannot be started, the sign-on ID is in use, or the host answers that it is not available (`JCET014 … NOT AVAILABLE`). Once per outage; recovered on the first good check. | Default recipients (+ Fujitsu RACF team) | **Send email alerts** only | Kept in the outbox |
| ServiceNow Polling Not Available / Recovered | 3 failed polls in a row; the first good poll after that. | Default recipients and **ServiceNow team** | **Send email alerts** only | Kept in the outbox |
| Database Not Available / Recovered | 2 failed checks in a row, one minute apart. Request processing is paused meanwhile. Recovered on the first good check. | Default recipients and **Database team** | **Send email alerts** only | Kept in the outbox |
| Bot Windows session Not Available / Recovered | With the real terminals: the bot's Windows session is locked, disconnected, or Windows refused the bot's keystrokes (for example a minimized remote desktop window). Requests of both applications wait and are not counted as failed. Recovered when Windows accepts the bot's keystrokes again. | Default recipients only | **Send email alerts** only | Kept in the outbox |
| Service started with problems | The service starts with a problem, which the e-mail lists, for example a Fujitsu RACF part that did not start. | Default recipients only | **Send email alerts** only | Kept in the outbox |
| Service started / Service stopping | Every normal start and stop. On a stop, the service waits at most 15 seconds for the notice to go out. | Default recipients only | **E-mail when the service starts or stops** | Kept in the outbox |
| Operational alert (general error e-mail) | The service logs an error without an e-mail of its own, for example a ticket that must be updated by hand in ServiceNow, a locked console account (while **E-mail when an account is locked** is On), a Fujitsu RACF error, or an error because Windows refused the bot's keystrokes (subject "Error: Windows did not accept the bot's keystrokes", with the cause in plain words and "Keep the bot's session signed in, unlocked and not minimized"). The same alert is sent at most once in 5 minutes; the next one says how many were held back. | Default recipients, plus the team of the system the error comes from: **ServiceNow team**, **CyberArk / identity team** (+ Fujitsu Mainframe team or Fujitsu RACF team) | **Send email alerts** only | Kept in the outbox |
| Alert summary | Daily at the set time, or hourly. Lists the failed requests and every other error since the last summary, with counts, both applications included. Not sent when there was none. A final summary when the service stops. | Default recipients only | **Alert summary e-mail** not Off | Kept in the outbox |

> **Note.** With **Transaction outcome emails** Off, a Fujitsu RACF "not available" answer of the host may also send the general error e-mail, in addition to the **Fujitsu RACF Not Available** e-mail.

### E-mails about the database password (only while the database password comes from CyberArk)

None of these e-mails contains a password. They are on whenever e-mail is on; none has a switch of its own.

| E-mail | Sent when | Sent to | Switches that must be On | If sending fails |
|---|---|---|---|---|
| Database password not updated / updated | CyberArk has a new password, but the bot could not give it to its database login after three attempts, one minute apart. Requests continue with the password in use; they stop only if the database stops accepting it. The notice asks the PAM team and the database team to check, then to use **Validate database password**. "Updated" when a later check succeeds, with a **Found by** row. | Default recipients and **Database team** | **Send email alerts** only | Kept in the outbox |
| CyberArk (database password) Not Available / Recovered | CyberArk does not answer the bot's check of the database password. Requests continue with the password received last; a change made in CyberArk meanwhile is applied at the bot's next scheduled check after CyberArk answers again. Recovered when it answers again. | Default recipients and **CyberArk / identity team** | **Send email alerts** only | Kept in the outbox |
| Database password changed | The bot found a new database password in CyberArk and uses it: at its scheduled check, after the database refused a sign-in, after **Validate database password**, at the start of the bot or at a restart from the console. Once per change. Rows: **Changed in CyberArk**, **Found by**, **Bot's database login** (given the new password, or already accepted it) and **CyberArk check** (how often). No action is needed. | Default recipients and **Database team** | **Send email alerts** only | Kept in the outbox |
| Bot's database login set back to the password in CyberArk | The database refused the bot's login although the password in CyberArk did not change, so the login's password was changed outside CyberArk. The bot set it back and continues; a database action at that moment may have failed once. Asks the database team to find out who changed it. | Default recipients and **Database team** | **Send email alerts** only | Kept in the outbox |

### E-mails about service-account passwords

None of these e-mails contains a password.

| E-mail | Sent when | Sent to | Switches that must be On | If sending fails |
|---|---|---|---|---|
| Password change due (Fujitsu Mainframe or Fujitsu RACF) | The service-account password has reached **change after (days)** (80) and the automatic change is Off. For Fujitsu RACF always, because the bot cannot change that password. Checked every hour; sent once a day until the password is changed. | Default recipients, **CyberArk / identity team** and **Support report recipients** | **Send email alerts**; the date of the last change known (entered under **last changed on**, or recorded by the bot). Not sent while CyberArk supplies that password. | Kept in the outbox |
| Password expires soon (urgent) | From **urgent e-mail (days before expiry)** (5) before the expiry, once a day. | As above | As above | Kept in the outbox |
| Password expired (urgent) | On and after the expiry date (90 days), once a day, until the password and the date are updated. | As above | As above | Kept in the outbox |
| Automatic password change stopped (Fujitsu Mainframe only) | The automatic change failed **stop after failed tries** (2) times in a row, or the host refused the current password. | As above | **Send email alerts**; **Service-account password: change automatically** On | Kept in the outbox |
| Fujitsu Mainframe service-account password changed / not changed | After **Change service-account password** on the console, or after an automatic change. Rows: the account, who changed it and how, the result and the evidence folder. | Default recipients, **CyberArk / identity team** and **Support report recipients** | **Send email alerts** only | Kept in the outbox |

### Tests

| E-mail | Sent when | Sent to | Switches that must be On | If sending fails |
|---|---|---|---|---|
| Test e-mail | You press **Send test e-mail** (Settings › E-mail) or **Send test email** (setup assistant). Works while **Send email alerts** is Off. | The addresses typed, else the default recipients | None | Never kept; the console shows the reason |
| Sample e-mail | You press **Send sample** in **E-mail samples**. `[TEST]` is put first in the subject. | Only the test addresses typed; the real recipients receive nothing | None | Never kept; the console shows the reason |

Some errors are covered by their own notice: CyberArk not answering, failed ServiceNow polls, errors while the database is down, a database password that could not be updated, a refused Fujitsu RACF sign-on and a Fujitsu RACF sign-on ID in use. These are not e-mailed a second time as operational alerts, but they still count in the summary. While **Transaction outcome emails** is On, the failure lines of each request are not e-mailed as alerts either.

**What happens without Default recipients.** E-mail stays on while any address is set anywhere (a team list, **Error-alert recipients** or **Support report recipients**). Each e-mail then goes to its other recipients. An e-mail about a request goes to the team of its application when that team receives more than support reports. An e-mail with no recipient at all (for example the alert summary, the service notices or the **Bot Windows session** notices) is not sent, and the audit trail records `email_skipped`. A blank **Default CC** changes nothing. While **Default recipients** is blank, a change of another list that switches e-mail on or off as a whole applies only after a restart, and the save says so.

**Events that never send an e-mail**

- The operating window of either application opening or closing, and requests waiting in the queue.
- Each automatic retry of a request. Only the final failure is e-mailed.
- An operator cancelling, retrying or submitting a request. Only the request's outcome is e-mailed.
- A ticket for another application, which is outside the bot's selection.
- A request cancelled before it ran because its ticket was closed or taken over in ServiceNow.
- A test request read with **Ticket checks** set to `none`.
- An invalid submission typed on the console (the console shows the answer at once), and a submission refused for its size.
- The creation of a Fujitsu RACF completion ticket. The completion e-mail names its number when it was already created.
- An e-mail delivery failure. It is shown on the Dashboard and the System page instead.
- Log warnings. Only errors become alerts.
- A notice to a user whose access was removed, and any e-mail to the requester. The requester appears only in the support report.

## 7. What happens to the ServiceNow ticket

> **In plain words.** Every task the bot takes ends with a note on it. A completed task is closed as complete. A task the bot could not finish, or whose result it could not confirm, is closed as incomplete or left open with the reason, depending on your settings, so SailPoint and the people who follow the task always see what happened. A task that was never meant for the bot is not touched at all. Fujitsu RACF tickets follow the same rules, with their own wording and two additions: removals handed to a person, and the completion ticket for the app team.

### Fujitsu Mainframe tickets

| Outcome | What is written to the ticket | Ticket state afterwards | Can it be retried from the console | Setting that decides |
|---|---|---|---|---|
| Completed provisioning | **Closing comment (provisioning)**, in the work notes and the close notes | Closed Complete (`3`) | No, it is completed | **Close the ticket after a successful provisioning or deprovisioning**, **Closing state value** |
| Completed removal (Access Removal, Transfer, Termination) | **Closing comment (deprovisioning)** | Closed Complete (`3`) | No | As above |
| Certification completed (Certification, Account Certification) | **Closing comment (certification)** | Closed Complete (`3`) | No | As above |
| Already removed (the account was not in Fujitsu Mainframe) | On: "No change was needed: the Fujitsu Mainframe account … was already removed. Closed by the AIG IAM Access RPA bot." Off: the review note | On: Closed Complete. Off: stays open | No | **Close the ticket when the account was already removed**, **Work note when the account was already deleted (ticket stays open)** |
| Failed after all attempts | On: **Closing comment (failed)**, with the number of attempts and the reason. Off: the failure note | On: Closed Incomplete (`4`). Off: stays open | On: no, **Retry** is refused and a new task is needed. Off: yes (Developer) | **Close the ticket when the request failed**, **Closing state value (failed)** |
| Needs verification (change submitted, result not read) | On: "The AIG IAM Access RPA bot submitted the … for application ID … (affiliation …) but could not confirm the result on screen. Closed as incomplete; if the change is still needed, submit a new request.", followed by the detail. Off: **Note when the result could not be confirmed (ticket stays open)**, asking a person to check Fujitsu Mainframe | On: Closed Incomplete (`4`). Off: stays open | No. Check the account in Fujitsu Mainframe first; raise a new task only if the change was not made | **Close the ticket when the request failed**, **Closing state value (failed)**; while it is Off, **Work note when the account was already deleted (ticket stays open)** (switch) |
| Cancelled by an operator | Off: the cancel note; with a hand-over group, the task goes to that group, unassigned. On: **Closing comment (cancelled)** | Off: stays open. On: Closed Incomplete | No, only failed requests can be retried | **Close the ticket when a request is cancelled**, **Hand rejected tickets to group** |
| Rejected by the checks | The rejection note with the reason, or a hand-over, or the closing text "Not processed by the AIG IAM Access RPA bot: … Ticket closed; raise a new request if it is still needed." | Stays open, handed over, or Closed Incomplete | Nothing was queued; correct the task in ServiceNow | **Hand rejected tickets to group**, **Close the ticket when the bot does not process it**, **Work note on a ticket the bot rejects (ticket stays open)** |
| Duplicate | "Not processed by the AIG IAM Access RPA bot: duplicate of `<earlier task>`." as a note, with a hand-over, or as the closing text | Stays open, handed over, or Closed Incomplete | Nothing was queued | As above, and **Add a work note when a ticket is queued or found to be a duplicate** |
| Overtaken by a newer opposite ticket | The rejection note naming the newer task, or the closing text. Found when the request is about to run: the request is cancelled and the same note or close follows (no hand-over) | Stays open or Closed Incomplete | No | **Close the ticket when the bot does not process it**, **Work note on a ticket the bot rejects (ticket stays open)** |
| Not for this application | Nothing | Unchanged | Not applicable | **Accepted application IDs** |
| Outside the filters | Nothing | Unchanged | Not applicable | The **Ticket selection** settings |
| Ticket closed or reassigned in ServiceNow before the bot ran it | Nothing. The request is cancelled with the reason, which the console shows | As the person left it | No; raise a new task if the change is still wanted | None, always |
| Ticket update could not be written | Nothing yet; the bot keeps trying. The request details show **ServiceNow ticket update** with the progress | Unchanged until the update succeeds | Not applicable: the Fujitsu Mainframe result stands | None |

**Assigned to on a closed ticket.** Where the bot assigns tasks to itself before queueing them (**Match tickets by** `assignment_group`, or a blank **Bot account**), a task it closes as Closed Incomplete because it does not process it is assigned to the bot in the same update. A task is therefore never closed by the bot with **Assigned to** empty.

### Fujitsu RACF tickets

A Fujitsu RACF ticket follows the table above, with these differences:

| Outcome | What is written to the ticket | Ticket state afterwards | Setting that decides |
|---|---|---|---|
| RACF ID created | "Fujitsu RACF account created by the RPA bot. RACF ID …, group …. Completed …" | Closed Complete (`3`) | **Close the ticket after a successful provisioning or deprovisioning** |
| RACF ID removed (removal, transfer, termination) | "Fujitsu RACF account removed by the RPA bot. RACF ID …. Completed …" | Closed Complete (`3`) | As above, and **Fujitsu RACF removals** set to remove the whole RACF ID |
| Certification removal | "Certification revocation completed by the RPA bot: RACF ID … removed. Completed …" | Closed Complete (`3`) | As above |
| Needs verification (job submitted, result not read) | On: "The RPA bot submitted the … job for RACF ID … but could not confirm whether it was applied. Closed as incomplete; if the change is still needed, submit a new request.", followed by the detail. Off: "Human review required: … Please verify in Fujitsu RACF. Ticket left open." No completion ticket is created | On: Closed Incomplete (`4`). Off: stays open | **Close the ticket when the request failed**, **Closing state value (failed)** |
| Already removed, failed, cancelled | The same rules as for Fujitsu Mainframe, in Fujitsu RACF wording | As for Fujitsu Mainframe | As for Fujitsu Mainframe |
| Removal left for a person (**Fujitsu RACF removals** at its default) | "Not processed by the AIG IAM Access RPA bot: Fujitsu RACF removals are handled by a person on this server (… of RACF ID …, group …)", or the task goes to **Hand rejected tickets to group** | Stays open, or handed over. Never closed by the bot, also while **Close the ticket when the bot does not process it** is On: the person who removes the access closes it | **Fujitsu RACF removals**, **Hand rejected tickets to group** |
| Rejected by the checks, duplicate | As for Fujitsu Mainframe, with the Fujitsu RACF reason (for example "the RACF ID '…' is longer than 8 characters") | As for Fujitsu Mainframe | As for Fujitsu Mainframe |

The closing comments and notes of a Fujitsu RACF ticket are built in. The texts set on the ServiceNow page are written for Fujitsu Mainframe and are not used for Fujitsu RACF tickets.

A removal ticket that was handed to a person stays with that person, even if **Fujitsu RACF removals** is later changed to remove the whole RACF ID, as long as the ticket's content is unchanged.

**The completion ticket for the app team.** While **Completion ticket in ServiceNow** is On (Off by default, page **Settings › Fujitsu RACF completion ticket**), every successful and confirmed Fujitsu RACF creation, removal or certification removal also creates a **new** ServiceNow record (table `incident` by default) for the app team's assignment group. The source ticket is not changed by it: the new record names it in its description ("Source ServiceNow ticket (SailPoint request): …"), together with the user's full name, the RACF ID and the group. The request details on the console show the **Completion ticket** row. If ServiceNow does not take the record at once, it is tried again in the background. A request whose result could not be confirmed never creates one. A catalog request (REQ) cannot be created as the completion ticket. See section 5.9 for the settings and the test.

### For both applications

**Tasks with several affiliation codes.** The bot writes to the task only once, when every code has finished. The worst result decides the outcome: failed, then cancelled, then not confirmed, then already removed, then completed. A task with one code not confirmed (and none failed or cancelled) is therefore closed as Closed Incomplete while **Close the ticket when the request failed** is On. The note ends with "Result per affiliation code:" and one line per code, for example `- <5-digit affiliation code> <department name>: completed`. When some codes were changed and the others were already removed, the task is closed as complete with a note that says so (or left open for review when **Close the ticket when the account was already removed** is off).

**How ticket updates are retried.** Before every write, ServiceNow must confirm that the task carries the expected number, is active and is assigned to the bot. If the write fails, the bot tries three more times within about a minute, then again at each later poll while the task is still open, for up to six rounds in all. The **System** card shows "ticket update(s) waiting to be written" meanwhile, and the ServiceNow team is e-mailed on the first failure. An update that was delivered is never repeated. When the bot gives up, or when ServiceNow does not confirm that the task is still the bot's (someone closed or reassigned it), the **System** card and the Dashboard show "ticket update(s) not written: update those tickets by hand". This means: open each affected request on the **Requests** page, read its outcome and **ServiceNow ticket update** line, and write the outcome on the task in ServiceNow yourself, closing it if appropriate. The change in Fujitsu Mainframe or Fujitsu RACF has already been made or refused as recorded; only the ServiceNow task is behind.

## 8. Users, branding and error rules

### 8.1 Users

> **In plain words.** The Users page lists every console account. Here you add people, change their role, reset a forgotten password, unlock a locked account, and switch off accounts of people who have left.

**Who does this:** Developer. Administrators see and manage the Users page too when **Users page for Administrators** (Settings › Console sign-in) is On, and always while no active Developer account exists, so the console accounts can still be managed. A role with `users.view` only can read the page, export it and see the open sessions, but cannot change anything.

With **Users page for Administrators** Off on purpose and no active Developer account, the System page warns: "The Users page is still shown to Administrators: no active Developer account exists. Create a Developer account to keep the Users page for the Developer only."

**Add user.** Select **Add user**, fill in the fields and select **Create**.

| Field | Rule |
|---|---|
| **Username** | 3 to 64 characters: letters a-z, digits and `.` `_` `-`, starting with a letter or digit. Stored in lower case. |
| **Display name** | The name shown in the header and the audit trail. |
| **E-mail** | Optional. Must look like an e-mail address. |
| **Role** | Viewer is selected first. Only roles you are allowed to give are listed. |
| **Provisional password** | Follows the password rules in 4.3. The user must change it at the first sign-in. Required unless Windows sign-on is available on the service. |
| **Windows account (optional)** | `DOMAIN\user`. One Windows account can belong to one console account only. |

Give the provisional password to the user by a separate, secure channel.

**Row actions.** Each account you may change has these controls:

- **Role**: choose another role in the list. The console asks first ("Their open sessions end.").
- **Edit**: change **Display name**, **E-mail** and **Windows account (optional)**, then **Save**.
- **Unlock**: shown while the account is locked. The lock is lifted at once and the user signs in with their current password.
- **Deactivate** / **Activate**: deactivation signs the person out at once and keeps the account and its history.
- **Delete**: removes the account and ends its sessions. Its past actions stay in the audit trail.

Your own account has no role list, no **Deactivate** and no **Delete**. An account whose role grants permissions you do not hold has no buttons at all.

**Reset the password.** Open **Edit**. Under **Reset the password** enter **New password** and **Confirm the new password**, then select **Reset password** and confirm. The password is provisional, the person's sessions end and any lock is lifted. When one administrator resets the password of another Admin account, the administrators receive an e-mail alert (while **E-mail when an account is locked** is On, 5.8).

**When nobody can sign in.** If no account that may use the Users page can sign in, the server team resets the password on the server itself (section 4.7). That reset follows the same rules as the console: it refuses a password shorter than the **Minimum password length** saved under **Settings › Console sign-in**, or one without a letter and a digit, and says why ("[NG] Not reset: the password must be at least N characters"). The password it sets is provisional, the account is unlocked and activated, and its open sessions end.

**Active sessions.** Below the list, one row for each open console window: **User**, **Signed in or renewed (JST)**, **Ends (JST)** and **Browser**. **End session** signs that window out at once. Your own window has no button.

**Export users.** Downloads a CSV file of every account: username, display name, e-mail, role, the permissions of the role, whether it is active, how it signs in, the Windows account, whether a password change is pending, last sign-in, when and by whom it was created. Each export is recorded in the audit trail.

> **Tip.** Prefer **Deactivate** to **Delete** for people who leave. The account cannot be used, and a later review still shows who held it.

### 8.2 Branding

> **In plain words.** Branding sets the product name, logo, colours and font of the console, and the look of the e-mails the service sends. Changes apply as soon as they are saved, for every user and every e-mail.

**Who does this:** Developer. The **Branding** page is shown only to a role that may see every setting.

| Area | Fields and limits |
|---|---|
| **Console text** | **Product name** (60 characters; default **AIG IAM Access RPA**), **Tagline** (120; default "Identity & Access Automation Console"), **Footer text** (200), **Support contact** (200), and **Sign-in notice (shown under the sign-in form)** (600). The default sign-in notice reads "This system is for authorised use only. Activity is recorded and monitored." An empty product name or sign-in notice returns to its default. |
| **Console colours and font** | **Primary colour**, **Accent line**, **Links**, **Header colour**, **Page background**, **Panels**, **Text**. **Font**: **AIG standard (Source Sans / Hiragino / Meiryo)**, **Meiryo**, **Noto Sans JP** or **System default**. |
| **Console images** | **Logo, white version** (PNG, JPEG, GIF or WebP, up to 200 KB; **Use AIG default** restores the standard logo). **Browser icon** (PNG, JPEG, GIF, WebP or ICO, up to 64 KB; **Use AIG default**). **Sign-in panel image** (PNG, JPEG, GIF or WebP, up to 500 KB; **Remove**). SVG images are not accepted. |
| **E-mail** | **Send e-mails in the branded HTML design** (on by default; the plain-text version is always included). **Show the footer at the end of every e-mail** (off by default): adds the company and department, the contact address and the automatic-message notice after the signature. **Banner** (PNG, JPEG or GIF, at least 800 px wide is advised, up to 300 KB; **Use built-in banner**). **Logo for e-mail, white version** (PNG, JPEG or GIF, up to 100 KB; **Use AIG default**). **Header colour**, **Accent colour** (the line under the header bar when no banner is used) and **Company name** (80 characters; default "AIG General Insurance Company, Ltd."). E-mail images in SVG, WebP or ICO are refused, because e-mail programs do not show them. A preview shows the top and bottom of every e-mail. |

Select **Save** to apply. **Reset to defaults** asks "Return every branding setting to its default?" and then restores the standard design. Both are recorded in the audit trail.

### 8.3 Error rules

> **In plain words.** The bot reads every screen of the Fujitsu Mainframe terminal. When it recognises a known error screen, a rule tells it what to do: answer the dialog, print the screen, leave cleanly, and whether to try the request again. This page lists those rules.

**Who does this:** Developer. The **Error rules** page is shown only to a role that holds `rules.view` and may see every setting.

The rules on this page are the Fujitsu Mainframe rules. The Fujitsu RACF screens (sign-on refusals, results, the host not available) are recognised from the Fujitsu RACF screen wording kept in configuration (5.9); they are not listed or switched on this page. In the same way, the settings under **Settings › Error handling** (**Act on recognised error screens**, **Transient retry attempts**, **Settle after dismissing a dialog (s)**) and most of those under **Settings › Screen reading** apply to Fujitsu Mainframe only; their help text says so.

**What the page shows.** The number of error screens recognised and the catalogue version (the same version is recorded with every error screen the bot recognises). The table lists for each rule: **Order**, **Rule** (identifier and name), **Screen**, **Recognised by** (the words the bot looks for), **Bot action**, **Type** (**Business**: never tried again, or **System**), **Retry** (**Whole request** or **No**) and **In use**. Select a row for the full rule, including the message recorded with the failure. If the catalogue has a problem that would stop the bot, a red notice says so.

**Switching a rule off or on.** Only a role with `rules.edit` (the Developer) sees **Turn off** / **Turn on** in the **In use** column. The console names the rule, asks for confirmation and then for a reason, which is recorded in the audit trail. The service refuses to turn a rule off without a reason. The change applies from the next transaction; no restart is needed. **Recent changes** below the table lists the last changes with who, when and why.

> **Important.** A rule that is switched off is ignored: the bot handles that screen as if no rule matched it. Do this only on the advice of the support team.

A rule acts only on a screen read with enough confidence. An unclear read is recorded in the audit trail as suspected and changes nothing. When a rule makes a request fail, the request shows a result code starting with `BOT:` followed by the rule identifier, for example `BOT:EMPLOYEE_CODE_ERROR`, together with the rule's name.

**The shipped rules:**

| Rule | What the screen says | What the bot does | Tried again? |
|---|---|---|---|
| `NETCOBOL_REPORT_PROMPT` | A terminal program stopped with a COBOL run-time error and the dialog **NetCOBOL 診断機能** offers to open a report file. | Answers No, leaves Fujitsu Mainframe, and fails the request with the run-time message. Nothing was changed. | No. Check that no other Fujitsu Mainframe session uses the bot's sign-in, then use **Retry**. |
| `COBOL_RUNTIME_ERROR` | A **COBOL** dialog with a run-time message (for example an input/output error, 入出力エラー). | Presses OK, leaves Fujitsu Mainframe, and fails the request. Nothing was changed. | No. As above. |
| `CENTER_NOT_READY` | 「エラーメッセージ」 with センター準備中: the host centre is not ready. | Presses Enter on each error dialog and leaves cleanly. New Fujitsu Mainframe requests wait until its login window opens again (5.5, "When Fujitsu Mainframe is not available"). | Yes, the whole request, up to **Attempts per request**. |
| `LINE_ERROR` | 回線エラー: the line to the host is down and Fujitsu Mainframe closes itself. | Presses Enter and leaves from the menu. New Fujitsu Mainframe requests wait as for centre not ready. | Yes, the whole request. |
| `LOGIN_PASSWORD_INCORRECT` | パスワードが誤っています on the Fujitsu Mainframe sign-in screen. | Leaves from the sign-in screen and asks CyberArk for a fresh password. One sign-in per attempt of the request. | Only when a different password has arrived (section 5.5, "The password-rejected rule"); otherwise Failed. Check the service-account password. |
| `LOGIN_OPERATOR_NOT_REGISTERED` | オペレーターコード未登録です on the sign-in screen: the affiliation code and staff code of the service account do not belong together. | Leaves from the sign-in screen. Both codes are reported for a person to check. | No. |
| `LOGIN_AFFILIATION_CODE_INVALID` | 所属コードの上2桁が不当です on the sign-in screen: the first two digits of the affiliation code are not valid on this host. | Leaves from the sign-in screen. | No. Check the service account's affiliation code and the **Mainframe environment** (development puts `99` in front of the code). |
| `LOGIN_REJECTED_UNRECOGNISED` | Not matched on the screen text: used when the sign-in brought no business menu in time, the sign-in screen is still showing and no rule above knows its message (for example この所属コードではオンライン開局不能です). | Leaves from the sign-in screen. The e-mail quotes the message read from the screen, without codes or typed values. | No. Read the message and check the service account. Switching this rule off treats such a sign-in as a time-out, run again up to **Attempts per request**. |
| `EMPLOYEE_CODE_NOT_FOUND` | The error screen with the comment みあたらず: the employee code was not found. | Prints the screen, saves it as a PDF under the ticket number, leaves Fujitsu Mainframe. Reported as Failed; nothing was changed. | No. Check the affiliation code and employee code on the request. |
| `EMPLOYEE_CODE_ERROR` | The error screen with 社員コード エラー. | As above. | No. Check the employee code. |
| `FINES_ERROR_SCREEN` | The error screen with any other error comment. | As above. The comment is recorded with the failure. | No. See the evidence for the comment. |
| `CONFIRMATION_ERROR_COMMENT` | An error comment on the confirmation screen, other than 削除済み (already deleted). | Cancels before the commit and reports the request as Failed. | No. |
| `FINES_ERROR_DIALOG` | Any other Fujitsu Mainframe error dialog that no rule above matches. | Presses Enter and leaves cleanly, with full evidence. | Yes, the whole request. |

A confirmation screen with 削除済み is not an error: the account was already deleted, and the request ends as **Already removed**.

---

# Part D — Go-live and operations

## 9. Checking the installation and going live

> **In plain words.** Before the bot handles real requests, you prove three things: the service is healthy, one test ticket for each application in use travels all the way through as expected, and the production safety settings are in place. The go-live checklist at the end records the sign-off.

**Who does this:** Admin with the business owner; Developer for the production settings; Information Security for the approvals.

### 9.1 Restart and check the health of the service

1. **Restart.** If any setting shows **Restart needed**, select **Save and restart** on the **Settings** page, or **Restart service** on the **System** page. A request in progress finishes first.
2. **Open System.** Each card should show a healthy state:

| Card | Healthy state |
|---|---|
| **Bot service** | Running, with its uptime |
| **Processing** | Active (Idle, or a transaction in progress) |
| **Terminal** | The terminal type you chose |
| **Database** | PostgreSQL |
| **Screen reading** | On |
| **Credential store** | Available, for the bot's Windows account. Sample (QA): `R6-CORE\prvrnel` |
| **Mainframe window** (**Fujitsu Mainframe window** while Fujitsu RACF is on) | Open, during working hours |
| **Fujitsu RACF** (when used) | Open, during its working hours, with no requests waiting |
| **CyberArk** (when used) | Connected |
| **Database password** (when the database password comes from CyberArk) | **Latest password from CyberArk**, with "Password in use: the latest from CyberArk", a recent **Last successful check** and a **Next check** time, and no problem line |
| **E-mail** | On |
| **ServiceNow** | On, with the last and next check and no failures |

3. **Read the messages.** The System page groups what it finds into **Needs attention (n)** (red) and **Warnings (n)** (orange); select a heading to open it. Security notices such as "Requests are accepted without an API key" appear there too, under **Security, before production use:** or **Security:**. Each message says what to correct. With the real terminal, **Needs attention** must not show "Requests wait: …" about the bot's Windows session: the session that runs the bot stays signed in, unlocked and not minimized (section 10.2).
4. **Run self-test.** Select **Run self-test**. Every component should show **OK** or **n/a**.
5. **Check ServiceNow.** Select **Check ServiceNow now** and confirm that the ServiceNow card updates without an error.
6. **Check the database password** (when it comes from CyberArk). Select **Validate database password**. The answer should be "Password validated. The bot uses the latest password from CyberArk." (or "Password validated and updated. …" when CyberArk had a newer password, which the bot now uses).
7. **Check the Dashboard.** The **Bot service**, **Database**, **Processing** and **Queue** cards are healthy, and so are the cards of the **Fujitsu Mainframe** section and, when used, the **Fujitsu RACF** section.

### 9.2 Test the whole flow end to end

Run this test with a simulated terminal (**Terminal simulator** is easiest to follow, because its screens are visible) and with **Send every e-mail only to (testing)** set to the testers' addresses. Ask the ServiceNow team for SailPoint-format test tasks in your assignment group, with fictional test data.

**Sample (QA):** assignment group `Policy Management System - Common Process-2565-JPN`, one group for both applications (Fujitsu Mainframe tasks name application ID `2565`, Fujitsu RACF tasks `6582`); the Fujitsu RACF application team's group `MFT-SYS Programmer-JPN` is used only for the completion ticket (**Completion ticket: assignment group**).

| # | Action | Expected result | Where to look |
|---|---|---|---|
| 1 | Create an approved **Add** task for one affiliation code | At the next poll, or at once with **Check ServiceNow now**, the task is assigned to the bot and set to Work in Progress | ServiceNow task; **Requests** |
| 2 | Watch the request | Status moves from **Queued** to **In progress** to **Completed**, with a result code | **Requests** |
| 3 | Open the evidence | A screenshot for every step; the new account's password is blacked out | **Evidence** (enter the ticket number) |
| 4 | Check the ticket | Closed Complete, with the closing comment | ServiceNow task |
| 5 | Check the e-mails | The support report, and the registration notice to the test user (only when an e-mail address is found for the user) | Test mailbox |
| 6 | Check the records | A transaction history entry, and audit events for the pick-up, the processing, the e-mails and the ticket update | **Transaction history**; **Audit trail** |
| 7 | Create a **Remove** task for the same account | Processed and closed the same way | As above |
| 8 | Create a task with a 6-character account | Not processed; the ticket gets the reason; the operations team is told | ServiceNow task; test mailbox |
| 9 | Create a task with two affiliation codes | Two requests; the ticket is updated once, after both finish | **Requests**; ServiceNow task |
| 10 | Create the same request again | Not queued: recognised as a duplicate of the first | **Preview tickets**; ServiceNow task |
| 11 | Create a task while processing is paused | The request waits in the queue and runs after **Resume processing** | **Requests**; **Dashboard** |
| 12 | Cancel a queued request (Operator account) | Status **Cancelled**; the ticket gets the cancel note | **Requests**; ServiceNow task |
| 13 | Let one request fail (a failure scenario of the simulated terminal) | Status **Failed** with the reason; the ticket is closed as incomplete; **Retry** is not offered | **Requests**; ServiceNow task |
| 14 | Sign in as a **Viewer** | Can see, but cannot submit, retry, cancel or change anything | Console |
| 15 | When Fujitsu RACF is used: create an approved **Add** task for a Fujitsu RACF test ID | The request shows the **Fujitsu RACF** badge and runs inside the Fujitsu RACF window; the ticket is closed; the support report reaches the Fujitsu RACF team; the registration notice (when switched on) arrives in Japanese and English | **Requests** (filter **Application**); ServiceNow task; test mailbox |
| 16 | When the Fujitsu RACF completion ticket is used: check the record after step 15 | A completion ticket in the chosen table for the application team's group; the request details show its number under **Completion ticket** | ServiceNow; **Requests** details |
| 17 | When Fujitsu RACF is used: create a **Remove** task for the test ID | With removals left for a person: not processed, the ticket is handed over with the reason. With **Remove the whole RACF ID**: processed and closed | ServiceNow task; **Requests** |

When all of these pass, the business owner signs off the result in the go-live checklist.

### 9.3 Switch to production

Do this after the end-to-end test, in this order. A Developer makes these changes. The Administrator Runbook ("End-to-end test and go-live") gives the same sequence as numbered commands and console actions, each with its expected result.

**What Production changes.** **Service environment** set to **Production** makes the service strict ("fail-closed"). Know these rules before you switch:

| Case | What happens |
|---|---|
| Production with the real terminal, and the Fujitsu Mainframe password does not come from CyberArk | Nothing is processed. **Settings › This machine** refuses to save the real terminal driver while CyberArk is off. If CyberArk is off or does not start, the service either refuses to start or starts with processing disabled and shows "CyberArk is required here …" under **Needs attention**. While CyberArk has not yet delivered the password, the Processing card shows **Waiting** and work resumes by itself once it does (section 5.3). |
| Production with the real terminal and Fujitsu RACF on, but no Fujitsu RACF account set for CyberArk | Fujitsu RACF requests wait in the queue ("CyberArk is required here but no Fujitsu RACF account is set …"); Fujitsu Mainframe continues. The Fujitsu RACF account in the vault is set in the CyberArk configuration on the server, not on the console (section 5.9). |
| Production without a machine API key | The service refuses to start. Save the key before you switch (step 2 below). |
| **Keep the password of a failed request for (days)** | 0 in Production (7 in Development): the password of a failed request is erased at once. A password the bot generated is replaced by a new one at a **Retry**; a request that brought its own password must be submitted again. |
| **Mainframe environment** | Must match the Fujitsu Mainframe system. **Development** puts `99` in front of the service account's affiliation code at sign-in; **Production** does not. The header badge **Mainframe:** shows the value in force. |
| **Send every e-mail only to (testing)** still set | Not refused, but every e-mail still goes only to the testers, and **Warnings** shows "E-mail test mode: …". It must be empty in Production (step 7). |
| The database is SQLite | Accepted, but reported as a warning at start. Production uses PostgreSQL (Amazon RDS). |

**The steps:**

1. **Move to the real terminal.** Follow section 5.4, "Moving from testing to the real terminal". Process one controlled test task on the Fujitsu Mainframe test system and review its evidence in full. When Fujitsu RACF is used, run its three tests and one controlled request on the test system (**TSS3**) first (section 5.9).
2. **Create the machine API key.** Under **Settings › This machine › Credentials**, set **Machine API keys** to a name and a long random value, for example `snow:<a long random value>`.
3. **Switch on the API settings.** Under **Settings › This machine › Security**, turn on **Require the machine API key** and **Console sign-in may use the API**.
4. **Switch the environment.** Under **Settings › This machine › Deployment**, set **Service environment** to **Production**, and **Mainframe environment** to match the Fujitsu Mainframe system the bot will use. Production also requires CyberArk with the real terminal (section 5.3).
5. **Record the password dates.** When the bot does not yet know when a service-account password was last changed, enter **Service-account password: last changed on** (**Settings › Fujitsu Mainframe terminal**) and, when used, **RACF sign-on ID password: last changed on** (**Settings › Fujitsu RACF terminal and sign-on**), so the reminders before expiry start on time (section 5.3).
6. **Save, then restart**, and repeat section 9.1. A changed **Service port** needs the bot to be stopped and started again; **Restart service** keeps the port in use.
7. **Clear the test settings.** Empty **Send every e-mail only to (testing)**, and confirm that **Ticket checks** is **strict**.
8. **Keep the bot's Windows session usable.** With the real terminal, the bot types into its own Windows session. Leave that session signed in and unlocked, and do not minimize its remote desktop window (or disconnect it only in the way the unattended operation package describes). Otherwise requests wait (section 10.2).

> **Important.** In Production the service refuses to start without a machine API key. Always save the key (step 2) before switching the environment (step 4). If the service does stop for this reason, the server team returns the environment to Development (Application Installation Guide, troubleshooting), starts the service, and you complete step 2.

### 9.4 Go-live checklist

| # | Check | Owner | Done |
|---|---|---|---|
| 1 | Server prepared; the prerequisites and database scripts completed without errors; server time zone is Tokyo | Server team / DBA | ☐ |
| 2 | The one-time administrator password was changed; named accounts created; the Developer role is held only by the support team; decision recorded on **Users page for Administrators** | Admin / Developer | ☐ |
| 3 | ServiceNow: **Test connection** and **Preview tickets** pass; the bot account's rights confirmed | ServiceNow team / Admin | ☐ |
| 4 | E-mail: **Send test e-mail** received; recipients confirmed by the business, including the team lists and the two **support reports only** switches; **Send every e-mail only to (testing)** is empty | Mail team / business | ☐ |
| 5 | Decision recorded on e-mailing initial passwords to users | Information Security | ☐ |
| 6 | CyberArk: **Test retrieval** passes; the certificate is checked (with the certificate file when CyberArk uses an internal certificate authority) | CyberArk team | ☐ |
| 7 | Audit trail on, in its own PostgreSQL database | DBA / Developer | ☐ |
| 8 | Amazon RDS: encrypted, certificate-checked connections; port 5432 open to the application server only. Sample (QA): `rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com`, port `5432`, server `qwawosis1001.r1-core.r1.aig.net` | AWS administrator / DBA | ☐ |
| 9 | When the database password comes from CyberArk: **CyberArk address (database)** and **CyberArk Application ID (database)** saved; **Test CyberArk retrieval** passes; **Validate database password** answers "Password validated"; the **Database password** card shows **Latest password from CyberArk** with "Password in use: the latest from CyberArk", a **Next check** time and no problem line; the database team list is set to receive the database password e-mails. Sample (QA): `https://pamccp.aig.net`, `APP-10-SAILPOINT` | DBA / CyberArk team / Developer | ☐ |
| 10 | **Service environment** Production; machine API key set; both API settings on; **Mainframe environment** matches the Fujitsu Mainframe system; **Keep the password of a failed request for (days)** accepted as 0 | Developer | ☐ |
| 11 | Real terminal driver; screen reading on; self-test passes; the three terminal tests pass; the Fujitsu Mainframe password comes from CyberArk (and the Fujitsu RACF password, when used) | Developer | ☐ |
| 12 | **Start the terminal as administrator** matches how the service is started. Sample (QA): the scheduled task `FINESIII RPA Agent` | Server team / Developer | ☐ |
| 13 | The bot's Windows session stays signed in and unlocked, and its remote desktop window is not minimized (or the unattended operation set-up is in place); no "Requests wait: …" about the Windows session under **Needs attention** | Server team | ☐ |
| 14 | Operating window matches the hours of Fujitsu Mainframe | Fujitsu Mainframe team | ☐ |
| 15 | When Fujitsu RACF is used: the three Fujitsu RACF tests pass; its window, removal choice and team addresses agreed; the completion ticket (if used) tested with **Test completion ticket** | Fujitsu RACF team / Developer | ☐ |
| 16 | Service-account password dates entered; reminders reach the CyberArk / identity team; decision recorded on the automatic change for Fujitsu Mainframe | CyberArk team / Fujitsu Mainframe team | ☐ |
| 17 | Evidence retention period approved | Information Security | ☐ |
| 18 | Users and roles reviewed: least privilege; Evidence limited to those who need it | Business owner | ☐ |
| 19 | End-to-end tests (section 9.2) passed and signed off | Business owner | ☐ |
| 20 | Error rules reviewed; all rules on | Support lead | ☐ |
| 21 | Monitoring agreed: who watches the Dashboard and the alert mailbox | Operations lead | ☐ |
| 22 | **Mark setup complete** selected; the checklist has left the Dashboard | Admin | ☐ |

## 10. Day-to-day operations

### 10.1 The pages of the console

> **In plain words.** The console has twelve pages in four groups. Each person sees only the pages their role allows; a group with no page for that role is not shown.

**Who does this:** Everyone with a console account.

| Page | What it is for | Who sees it |
|---|---|---|
| **Dashboard** | Health of the bot right now, figures for a chosen period, the latest transactions. | Viewer, Operator, Admin, Developer |
| **Reports** | Processing and audit figures for a period, for review and printing. | Viewer, Operator, Admin, Developer |
| **Requests** | Every request in the queue and its state. **Cancel**, and for the Developer **New request** and **Retry**. | All four; **Cancel** for Operator, Admin, Developer |
| **Transaction history** | The permanent record of every finished transaction. Read only. | Viewer, Operator, Admin, Developer |
| **Evidence** | The screenshot of every step, with the text read from the screen. | Viewer, Operator, Admin, Developer |
| **Audit trail** | Every action of the service and of console users. Export to CSV. | Viewer, Operator, Admin, Developer |
| **Error rules** | The error screens the bot recognises. | Developer |
| **Settings** | How the service behaves. | Viewer and Operator read the essential settings; Admin changes them; Developer sees and changes everything |
| **Branding** | Name, logo and colours of the console and the e-mails. | Developer |
| **Users** | Console accounts and open sessions. | Developer; Admin when **Users page for Administrators** is on, or while no active Developer exists (section 3.1) |
| **Roles & permissions** | Built-in and custom roles. | Developer |
| **System** | The background service: cards, controls, outbox, log. | Admin, Developer |

The page you are on is kept in the address, so a reload or a bookmark opens it again. A page your role may not open gives "You do not have access to that page; your first page is shown." A role with no page at all sees "Your role has no pages in this console. Contact the administrator."

The header shows the badges **Service:** and **Mainframe:**, each **Development** or **Production**, and, while Fujitsu RACF is on, **Fujitsu RACF:** with its system (for example **TSS2**). If the service cannot be reached, a banner says so and the values shown are the last ones received; the console keeps trying.

**Which application.** While both applications are in use, every list, request detail and evidence page shows an application badge, **Fujitsu Mainframe** or **Fujitsu RACF**, always in the same name and colour. **Requests**, **Transaction history**, **Reports** and the **Audit trail** then also have an **Application** filter (**All applications**, **Fujitsu Mainframe**, **Fujitsu RACF**). The two code columns carry the names of the application shown:

| List shows | Code column headings |
|---|---|
| Fujitsu Mainframe only (filter **Fujitsu Mainframe**, or only Fujitsu Mainframe in use) | **Affiliation** and **Employee code** |
| Fujitsu RACF only (filter **Fujitsu RACF**) | **RACF group** and **RACF ID** |
| Both applications (filter **All applications**) | **Group / affiliation** and **User ID** |

The request and transaction details always use the names of the request's own application (**Affiliation code** and **Employee code**, or **RACF group** and **RACF ID**). **Recent transactions** on the Dashboard uses the names of the rows it shows.

### 10.2 Reading the Dashboard and the System page

> **In plain words.** Green means all is well, amber means something needs a look, red means work is stopped. The Dashboard is the place to start each day; the System page has the detail and the controls.

**Who does this:** Admin, Developer (Viewers and Operators see the Dashboard without the problem lists).

**Dashboard.** The line under the title names the terminal, the mainframe environment, the database and whether screen reading is on. **Last updated** shows the time of the last refresh (health every 5 seconds, figures every minute). Choose the period (**Today**, **Last 7 days**, **Last 30 days**, **Last 90 days**) for the figures.

The cards of the bot itself come first:

| Card | States |
|---|---|
| **Bot service** | **Running** or **Not running**. |
| **Database** | **Connected** or **Unavailable**, with the database type. |
| **Processing** | **Active** (Idle, or "A transaction is in progress"), **Paused** ("Paused by <name> since <time>"), **Waiting** ("CyberArk has not delivered the mainframe password yet", or "Outside the operating window, or the mainframe is not available") or **Stopped** (with the reason). When new work is held, always read **Needs attention** for the reason (for example "Requests wait: …" for the bot's Windows session). |
| **Queue** | "N waiting", with how many are in progress, how many are waiting to retry, and since when the oldest has waited. **Unavailable** if the queue could not be read. The queue holds the requests of both applications. |
| **Audit trail** | Shown only when events are waiting to be written to the audit database, or the state is unknown. |

Then one section per application:

| Section | Card | States |
|---|---|---|
| **Fujitsu Mainframe** | **Mainframe window** | **Open**, **Closing** (no new work starts) or **Closed**, with the window times and "mainframe not reachable" when the health check fails. |
| **Fujitsu Mainframe** | **Mainframe environment** | **Development** or **Production**, with the terminal type. |
| **Fujitsu RACF** (only while it is on) | **Fujitsu RACF window** | **Open**, **Closing** or **Closed**, with its own window times and "Fujitsu RACF host not reachable" when its host check fails. |
| **Fujitsu RACF** | **Fujitsu RACF system** | The system (**TSS2** or **TSS3**) with "Terminal steps ready", or "Fujitsu RACF cannot run on this server". |
| **Fujitsu RACF** | **Fujitsu RACF** | Shown only while Fujitsu RACF requests wait: **Needs attention**, with the reason (for example the sign-on ID in use, or no password yet). |

**Processing figures.** **Volume and outcome**: **Transactions**, **Success rate** and the chart **Daily volume by outcome** (Completed, Failed, Needs verification, Other). **Needs attention**: **Failed**, **Needs verification**, **Backlog now** and the chart **Most frequent failure reasons**. Each figure has an **i** button that explains it. **Recent transactions** lists the latest ten.

Reports adds, for the period chosen (**Last 7 days**, **Last 30 days**, **Last 90 days** or **Custom range**) and, while both applications are in use, the application chosen: **By request type**, **Where requests came from**, **Speed** (**Turnaround time (TAT)** with "95% within ..."), and a closed **More detail** block with **Retried**, **Bot processing time**, **Processing time**, **Activity by hour of day** and **All requests by status**. The **Audit and security** half (for `audit.view`) shows whether the audit trail is protected, **Errors**, **Failed sign-ins**, **Account changes**, **Evidence opened**, **Data exports**, **Configuration changes**, and its own **More detail**. **Print** adds a footer with the time, your name and the period.

**Needs attention and Warnings.** For Admins and Developers, the Dashboard and the System page group their messages into two closed sections. Each heading carries the number of messages; select it to open the list.

- **Needs attention (n)**, in red: something stops work. The note beside the heading says what it means: "requests are not being processed", or "Fujitsu RACF requests wait; Fujitsu Mainframe continues" when only Fujitsu RACF is affected. With both kinds, the list has the sub-headings **All requests:** and **Fujitsu RACF requests only (Fujitsu Mainframe continues):**. On the System page, the security notices that must be dealt with before production use are listed here under **Security, before production use:**. When the bot's Windows session cannot take keystrokes, the list shows, for example, "Requests wait: the bot's Windows session is locked. Keep the bot's session signed in, unlocked and not minimized; processing resumes by itself." (see "The bot's Windows session" below).
- **Warnings (n)**, in orange: "requests are still processed". For example ServiceNow failing or paused, ServiceNow ticket updates to make by hand, CyberArk unavailable, e-mail not delivering, e-mail test mode, a stored setting that is not valid, the time-zone warning and the crash notice. On the System page, the other security notices are listed here under **Security:**.
- Separately, "N saved setting(s) are waiting for a restart of the service." with **Restart now**. A saved **Service port** or **Refuse another port** is listed apart: "N saved setting(s) (the service port) apply when the bot is stopped and started again; Restart service does not apply them." On the Settings page such a row reads "Saved — applies when the bot is stopped and started again" until then.

A section with no messages is left out.

**The bot's Windows session.** With the real terminal on Windows, the bot types into its own Windows session. Windows refuses those keystrokes while the session is locked, disconnected, or shown in a remote desktop window that is minimized. The bot checks this before each request, without typing anything:

| Case | What happens |
|---|---|
| The session is signed in, unlocked and its window is not minimized | Requests run as usual. |
| The session is locked or disconnected | New requests of both applications wait in the queue; they are not failed and do not use up attempts. **Needs attention** shows "Requests wait: the bot's Windows session is locked." (or "… is disconnected."), with "Keep the bot's session signed in, unlocked and not minimized; processing resumes by itself." One outage e-mail, "Bot Windows session Not Available", goes to the default recipients. |
| Windows refuses a keystroke during a request (for example a minimized remote desktop window) | The error e-mail for that request explains the cause in plain words ("Error: Windows did not accept the bot's keystrokes"). New requests then wait, with "Requests wait: Windows did not accept the bot's keystrokes (the bot's remote desktop window may be minimized). …". The bot tries at most once a minute whether Windows accepts input again, with a mouse movement of zero pixels. |
| The session can take keystrokes again | Processing resumes by itself and a recovery e-mail, "Bot Windows session Recovered", follows. |
| A simulated terminal is used, or the server is not Windows | Nothing is checked. |

The check is on by default. There is no console setting for it: it can be switched off only in the application settings file (`.env`) on the server, with `DESKTOP_SESSION_CHECK=false`, which is not advised. The Application Installation Guide and the unattended operation package describe how to keep the session usable when nobody is signed in at the server.

**The crash notice.** If the service stopped unexpectedly, the next start records it in the audit trail and shows for 24 hours: "The service stopped unexpectedly (previous run started ...) and was started again at ... JST. See the audit trail and the service log for the cause."

**The time-zone warning.** If the server clock is not on Japan time: "This server's clock is not on Japan time ... Set the server's time zone to (UTC+09:00) Osaka, Sapporo, Tokyo." Transaction IDs, screenshot names and evidence times follow the server clock, while the console and e-mails show JST.

**System page.** The line under the title shows the mode and the version. Then come **Needs attention (n)** and **Warnings (n)**, the restart banner and these cards:

| Card | States |
|---|---|
| **Bot service** | **Running** or **Running with problems**, uptime, and the address it listens on (this machine only). |
| **Processing** | As on the Dashboard. |
| **Terminal** | The terminal type and the mainframe environment. |
| **Database** | The database type. |
| **Screen reading** | **On**, **Off** or **Not working** (with the reason). |
| **Credential store** | **Available** (with the Windows account it belongs to) or **Unavailable**. |
| **Machine settings** | **Customised** or **Defaults**, and where the start-up values come from. |
| **Mainframe window** | As on the Dashboard. While Fujitsu RACF is on, this card is called **Fujitsu Mainframe window**. |
| **Fujitsu RACF** | Only while Fujitsu RACF is on: **Open**, **Closing** or **Closed** (its window), **Requests wait** (with the first reason) or **Not running**. The line below names the system and window, and when it applies "terminal could not be started" or "sign-on ID in use or host not available"; otherwise "Fujitsu Mainframe runs separately". |
| **CyberArk** | When in use: **Connected**, **Fallback password** or **Unavailable**, with the time the password was fetched and, when it fails, the reason (for example that the certificate is not trusted). |
| **Database password** | Only when the database password comes from CyberArk. See "The Database password card" below. |
| **E-mail** | **Off**, **On** or **Not delivering**, and how many e-mails wait to be resent. |
| **ServiceNow** | **Off**, **Not running**, **Paused — sign-in rejected**, **Not configured**, **Failing (n)** or **On**, with the last and next check, the tickets found and queued, and ticket updates not yet written. |

**The Database password card.** It says which database password the bot uses, and never shows a password or a login name. Its heading is one of three states:

| State | Line "Password in use" | What it means |
|---|---|---|
| **Latest password from CyberArk** (green) | "Password in use: the latest from CyberArk, in use since … JST." | All is well. |
| **Previous password in use** (amber) | "Password in use: the previous password, in use since … JST. CyberArk has a newer one, which the bot tries again to apply (every N min)." | CyberArk holds a newer password that the bot could not yet give to its database login. Requests keep running with the previous password. The line below gives the reason in plain words. |
| **CyberArk not reachable** (amber) | "Password in use: the last one received from CyberArk, in use since … JST. Whether CyberArk has a newer one cannot be checked until it answers." | CyberArk did not answer the check (or its certificate is not trusted). Requests keep running with the password in use. |

The lines below, each shown when it applies: the reason, **Changed in CyberArk** (when CyberArk last changed the password), **Last successful check** (with the check interval, 15 minutes by default), **Next check**, **Last attempt failed** (while the most recent attempt failed) and a problem in plain words, for example that the database did not answer a check. A problem line also turns a green card amber.

**Validate database password** (System page controls, and beside **Database URL** under **Settings › This machine › Database**) asks CyberArk at once and signs the bot's login in with the password CyberArk returns. A newer password, or one the login no longer accepts, is applied at once; open connections and requests in progress are not affected. The answers:

| Answer | What it means |
|---|---|
| "Password validated. The bot uses the latest password from CyberArk." | Nothing to do. |
| "Password validated and updated. The bot now uses the latest password from CyberArk; new connections use it." | CyberArk had a newer password, or the bot's login had another one; the bot applied it. A "Database password changed" or "set back" e-mail follows (section 10.5). |
| "A check ran a moment ago; try again in N seconds. …" | At most one check every 30 seconds. |
| "CyberArk is changing the password right now. …" | CyberArk is rotating the password at that moment; try again in a minute. |
| "Not checked: … ." or "The new password from CyberArk could not be applied: … ." | The reason follows in plain words, then which password the bot keeps using. |
| "The database password does not come from CyberArk on this server …" | **Database password from CyberArk** is off; the bot uses the stored database password. |

Every click is recorded in the audit trail with its result.

**Security notices** (System page, under **Security, before production use:** in **Needs attention**, or **Security:** in **Warnings**):

- Requests are accepted without an API key (under **Needs attention** with the real terminal). A Developer saves the machine API keys, switches on **Require the machine API key** and **Console sign-in may use the API**, and restarts.
- The audit trail is off.
- The service runs under a different Windows account from the one it was set up for, with **Use this account** for an Admin or Developer once the passwords have been saved again.
- The console administrator has not chosen its own password yet.
- CyberArk is reached without checking its certificate.
- The registration e-mail promises a password e-mail that is switched off.

### 10.3 Requests: statuses, Retry, Cancel and New request

> **In plain words.** Every request has one status. Requests still waiting can be cancelled. A Developer can try a failed request again with Retry, or type a request by hand with New request.

**Who does this:** Operator, Admin, Developer (Cancel); Developer (Retry and New request); Viewers read only.

**Statuses.**

| Status | Meaning |
|---|---|
| **Queued** | Waiting to be processed. When it waits for its next automatic attempt, "next attempt hh:mm" is shown beside it, and the Queue card counts it under "waiting to retry". |
| **In progress** | The bot is working on it now. |
| **Completed** | The change was made and confirmed on the screen. |
| **Needs verification** | The change was submitted, but the result could not be confirmed on the screen. Check the account in the application. It is not tried again automatically and has no Retry. With **Close the ticket when the request failed** On (the default), its ServiceNow ticket is closed as Closed Incomplete with the note "Closed as incomplete; if the change is still needed, submit a new request.", never as complete; the "Please verify" e-mail asks for the manual check, and for Fujitsu RACF no completion ticket is created. With the setting Off, a review note is written and the ticket stays open. |
| **Failed** | Not done after every allowed attempt, or refused by Fujitsu Mainframe or Fujitsu RACF. |
| **Already removed** | A removal whose account was already deleted in the application. No change was needed. |
| **Cancelled** | Cancelled from the console, or never run. |

The **Request type** column shows **New account**, **Access removal**, **Certification**, **Account certification**, **Transfer** or **Termination**. **Unchecked (testing)** marks a ticket that failed a check while ticket checks were set to "none" for testing: it is never run, and values the bot did not read from the ticket show "Not read".

**Result code** shows the code the application returned. A failure without such a code shows a code of the bot starting with `BOT:`, for example `BOT:LOGIN_FAILED`, `BOT:TERMINAL_LAUNCH_FAILED`, `BOT:UNEXPECTED_SCREEN`, `BOT:CONFIRMATION_UNREADABLE`, `BOT:CONFIRMATION_MISMATCH`, `BOT:INVALID_REQUEST`, `BOT:TERMINAL_ERROR`, `BOT:INTERRUPTED`, `BOT:SYSTEM_ERROR`, or `BOT:` with the name of an error rule.

**Attempts** counts every attempt, automatic and by a retry. In the details it reads, for example, "3 (1 by operator retry)".

**The details panel.** Select a row to see status, codes, result, error, attempts and times, then **Ticket details**, **ServiceNow ticket** (state in words such as **Closed Incomplete**, with **State checked** showing when it was last read), **Catalog variables** and the first 50 **Audit events**. While both applications are in use, an **Application** row shows the badge. A Fujitsu RACF request whose completion ticket is switched on has a **Completion ticket** row: the record number and table once it exists, "Being created in ServiceNow" while the bot is still trying, or "Not created yet: … It is created within 10 minutes once the completion ticket settings are saved." when a setting is missing. The buttons are **Retry**, **Cancel request** and **Open evidence**.

The details of a finished transaction on **Transaction history** show the same **ServiceNow ticket** section: the ticket's current state, kept up to date by every poll and by the bot's own closing of the ticket, with **State checked**, not the state at the time the request ran.

**Filters and columns.** Filter by **Status**, **Operation**, **Source**, **Application** (while both applications are in use), **Received from** and **Received to**, search, sort, choose columns and **Export CSV**. The code columns are headed as described in section 10.1.

**Retry.** Offered only on **Failed** rows, to roles with `requests.retry` (the Developer). The console asks first: "Retry <ticket>? The <operation> is carried out on the mainframe again. This will be attempt N (limit N, "Attempts per request"); it is not repeated automatically if it fails." The retry is the next attempt of the same request; the count continues. Retry is not offered, or is refused, when:

- the ServiceNow ticket of the request was closed as incomplete: "Raise a new ticket to run it again." With **Close the ticket when the request failed** switched on, this applies to every failed ServiceNow request;
- the password supplied with a provisioning request has been erased after its retention period, or no password is held: submit the request again with its password;
- the request was submitted again after it failed: use the newer request;
- the request is not Failed ("only failed requests can be retried").

A password that the bot generated and that was erased is replaced by a new one at the retry.

**Cancel.** Offered only on **Queued** rows, to roles with `requests.cancel`. Other statuses are refused: "only queued requests can be cancelled". A cancelled request appears in Transaction history. For a ServiceNow request a note is written to the ticket at once; the ticket is closed only when **Close the ticket when a request is cancelled** is on.

**Bulk buttons.** **Retry the failed requests shown** (Developer) and **Cancel the queued requests shown** act on the rows of the current page only, after one confirmation. The result says how many were done and why any were refused. Use them after a mainframe outage, for example.

**New request** (Developer). Select **New request**, fill in the form and select **Submit**. The request runs on the terminal of its application like one from a ticket, with the same format and duplicate checks.

| Field | Rule |
|---|---|
| **Application** | Shown only while both applications are in use: **Fujitsu Mainframe** or **Fujitsu RACF**. |
| **Operation** | **Provision (register)** or **Deprovision (remove)**. |
| **Affiliation code (5 digits)** | 5 half-width digits. For Fujitsu RACF the field reads **RACF group (letters and digits)** (required to create). |
| **Employee code (7 characters)** | Exactly 7 half-width letters or digits. For Fujitsu RACF the field reads **RACF ID (up to 8 letters or digits)**. |
| **Employee ID (7 digits)** | Fujitsu RACF only, to create an account. |
| **Ticket number (optional)** | Required by the service despite its label: "Enter the ticket number of the request." |
| **Initial password (optional)** | Fujitsu Mainframe provisioning only. Exactly 8 half-width characters, starting with a letter. Blank means the bot generates one. |
| **New user's name (optional)**, **New user's e-mail address (optional)** | Fujitsu Mainframe provisioning only. With an address, the new user receives the registration and password notices. |

A request entered here is always recorded with the source **Console or API (not specified)** and with your name as **Submitted by**. It never updates a ServiceNow ticket. A ticket number already used by a request that is waiting, in progress, completed or already removed is refused as a duplicate, and so is the same account and operation already waiting or in progress. After a successful submission the message gives the request ID, its position in the queue and whether processing is paused, outside the window or waiting for the mainframe.

### 10.4 Everyday tasks

**Who does this:** Admin, Developer (Operators: cancelling requests).

| Need | Where | What to do |
|---|---|---|
| Stop new work for a while | System | **Pause processing**. A transaction in progress finishes. The pause survives a restart, a crash or a reboot. **Resume processing** when ready; it is refused while a terminal check runs. |
| Fetch tickets at once | System | **Check ServiceNow now** (shown while ticket collection is on). The card updates within seconds, or after about 30 seconds if ServiceNow does not answer. |
| Fetch the mainframe password again | System | **Refresh CyberArk now** (shown when CyberArk is in use). |
| Check the database password from CyberArk | System, or **Settings › This machine › Database** | **Validate database password** on the System page, or the button of the same name beside **Database URL**. A newer password in CyberArk is copied and used at once; requests keep running. At most one check every 30 seconds. The answers are listed in section 10.2. |
| Act on a password reminder | **Settings › Fujitsu Mainframe terminal** or **Settings › Fujitsu RACF terminal and sign-on** | The reminder e-mails say when a service-account password is due, urgent or expired. The **Tests** row of the page shows the password age. Change the password (below for Fujitsu Mainframe; with the Fujitsu RACF team for Fujitsu RACF, then save it under **Credentials** or in CyberArk), then enter the **last changed on** date when the bot did not make the change itself. Section 5.3 explains the reminders. |
| Change the Fujitsu Mainframe service-account password (Developer) | **Settings › Fujitsu Mainframe terminal**, **Tests** row | Pause processing first. **Test password screen** opens Task 0890 without typing on it. **Change service-account password** asks for the current password, the new one and its confirmation, and makes the change on Task 0890. Not offered when CyberArk supplies the password. Section 5.3 gives the rules and the safeguards. |
| Run the password-age check now (Developer) | Same pages, **Tests** row | **Check password age now** runs the hourly check at once. When the check has finished, the password-age line is read again and a message gives the result, for example "Password age check: not due yet, nothing to do." or "Password age check: change due; a reminder was e-mailed." The result is also in the audit trail. |
| Apply settings that need a restart | Dashboard, System or Settings | **Restart now** on the banner, **Restart service** on System, or **Save and restart** on Settings. A transaction in progress finishes first. A changed **Service port** or **Refuse another port** is not applied by these: stop the bot and start it again on the server. |
| Stop the bot | System | **Stop the bot**, then confirm. Nothing is processed until the service is started again on the server. |
| Look at the bot's Windows session | The server | Keep the session that runs the bot signed in and unlocked, and do not minimize its remote desktop window. While **Needs attention** shows "Requests wait: …" about the session, unlock or reconnect it; processing resumes by itself (section 10.2). Sample (QA): the session of `R6-CORE\prvrnel` on `qwawosis1001` |
| Read the log | System › **Service log** | Choose **Service log** or **Agent console**, the number of lines, the level (**All levels**, **Warnings and errors**, **Errors only**), search, **Refresh**. Secrets are masked. |
| Check the installation | System | **Run self-test**: each component is marked **OK**, **Failed** or **n/a**. |
| Send a support package | System | **Download diagnostics**: a zip with the status, the self-test, the log tails and the machine settings, with secrets masked. |
| Unlock a user | Users | **Unlock** on the row. |
| Reset a password | Users | **Edit** › **Reset the password**. |
| End a session | Users › **Active sessions** | **End session** on the row. |
| Cancel or retry work | Requests | **Cancel** on the row, or the bulk button. **Retry** for the Developer. |
| Enter a request by hand (Developer) | Requests | **New request**. |
| Undo a settings change | Settings › **History** › **Recent changes** | **Restore** on the row. It is saved and recorded like any change. |
| Record the configuration | Settings | **Export configuration** (Developer): every setting with its value and source, secrets masked. |
| Access review | Users | **Export users**. |
| Export audit events | Audit trail, or Reports | Set **From** and **To** (or one request or ticket, and the application when both are in use), then **Export CSV**; or **Export audit events** on Reports for the period shown. At most 50,000 rows per file. Each export is recorded. |
| E-mails that were not delivered | System › **E-mail outbox** | **Resend now**, or **Delete** an e-mail that must not be sent. Each e-mail is kept for 24 hours by default. A password notice is kept only as a record, without the password, and is built again when it is resent; it is kept no longer than the other e-mails and never more than 72 hours. |

### 10.5 Common situations

**Who does this:** Admin, Developer.

| Situation | What the bot does | Who is told | Which setting decides |
|---|---|---|---|
| The host centre is not ready (センター準備中) during a Fujitsu Mainframe request | Answers the dialog, leaves cleanly and tries the whole request again later, up to the limit. Then the request is Failed. | On the final failure: the outcome e-mail, and the ServiceNow ticket is closed as Closed Incomplete. | **Attempts per request** (default 3); **Close the ticket when the request failed** (default On). |
| Fujitsu Mainframe refuses the employee code (error screen) | Prints the error screen, saves it as a PDF under the ticket number, leaves Fujitsu Mainframe. Failed with `BOT:EMPLOYEE_CODE_ERROR`; not tried again. | Outcome e-mail; the ticket is closed as Closed Incomplete with the reason. | The error rule; **Close the ticket when the request failed**. |
| A removal for an account that is already deleted | Changes nothing. The request ends as **Already removed**. | The ticket is closed as complete with a note that no change was needed. | **Close the ticket when the account was already removed** (default On; Off leaves the ticket open with a review note). |
| The result cannot be confirmed after the change was submitted | Marks the request **Needs verification**. Not tried again, never closed as complete, and for Fujitsu RACF no completion ticket is created. | The "Please verify" e-mail, which asks for a manual check; the ticket is closed as Closed Incomplete with the note "Closed as incomplete; if the change is still needed, submit a new request."; the Dashboard counts it under **Needs verification**. | **Close the ticket when the request failed** (default On; Off: a review note and the ticket stays open). A person checks the account in the application, and asks for a new request only if the change was not made. |
| Someone wants to retry a failed ServiceNow request | Refuses: the ticket was closed as incomplete. | The Developer sees "Raise a new ticket to run it again." | **Close the ticket when the request failed**. |
| An operator cancels a queued ServiceNow request | Cancels it and records it in Transaction history. | A note is written to the ticket, which stays open. | **Close the ticket when a request is cancelled** (default Off). |
| The same ticket is submitted twice | Refuses the second request as a duplicate of the first. | The submitter sees "Duplicate of req_... (status: ...)"; a rejection alert is e-mailed when e-mail alerts are on. | None. A failed or cancelled request does not block a new one. |
| A request arrives outside its application's operating window | Queues it. It starts when that window opens. | The submitter sees that the mainframe is offline outside the window. | **Window opens (JST)**, **Window closes (JST)**, and for Fujitsu RACF **Fujitsu RACF window opens / closes (JST)** (default 06:00 to 22:00 for both). |
| Fujitsu RACF requests wait (window closed, host down, sign-on ID in use, terminal not started, password refused) | Holds only the Fujitsu RACF requests; Fujitsu Mainframe requests keep running. | **Needs attention** with "Fujitsu RACF requests wait; Fujitsu Mainframe continues"; the Fujitsu RACF card; outage and recovery e-mails. | Section 5.9. |
| A Fujitsu RACF removal ticket arrives while removals are left for a person | Does not remove anything; the ticket is handed to a person with the reason. Such a ticket is never closed by **Close the ticket when the bot does not process it**. | The ticket carries the reason. | **Fujitsu RACF removals** (default: left for a person). |
| A service-account password is close to its expiry | Sends a reminder once a day: due, then urgent in the last days, then expired. With the automatic change on (Fujitsu Mainframe only), changes it itself instead. No reminder is sent while CyberArk supplies the password. | Default recipients, the CyberArk / identity team and the support report recipients. | The password-age settings (section 5.3). |
| Processing is paused and requests keep arriving | Queues them. Nothing starts until **Resume processing**. | The Processing card shows "Paused by <name> since <time>"; a New request message says processing is paused. | System › **Pause processing**. |
| CyberArk does not deliver the mainframe password | Does not start work. | The Processing card shows **Waiting**; **Warnings** names CyberArk. | The CyberArk settings; **Refresh CyberArk now**. |
| CyberArk rotates the database password | Copies the new password to the application login within the check interval (15 minutes by default), or at once when the database refuses the old one. Requests in progress are not affected. | The **Database password** card shows **Changed in CyberArk**; the e-mail "Database password changed: the bot uses the new password" (with a **Found by** row) goes to the default recipients and the database team. It is always on; there is no setting for it. | The database password settings under **Settings › This machine › Database** (section 5.8). |
| The new database password cannot be given to the bot's login | Keeps the password in use and tries again a minute later; after the third failed try in a row it sends one e-mail and tries again at each scheduled check. Requests keep running, and the card shows the reason. The next good check ends the problem by itself. | "Database password not updated: the bot keeps working with the password in use" to the default recipients and the database team; later "Database password updated: the bot uses the current password from CyberArk", with a **Found by** row. | None. The PAM team and the database team act on the reason given. |
| The bot's database login refuses the CyberArk password, which did not change | Someone changed the login's password outside CyberArk. The bot sets the login back to the password in CyberArk and continues; one database action at that moment may have failed once. | "Bot's database login set back to the password in CyberArk" to the default recipients and the database team. | None. Ask the database team who changed it; only the bot sets this password. |
| CyberArk does not answer the database password check | Keeps the password in use. Requests keep running; a rotation in CyberArk is applied only once CyberArk answers again. | The card shows **CyberArk not reachable**; "CyberArk not available: the database password could not be checked" to the default recipients and the CyberArk / identity team, then a recovery e-mail. | The CyberArk settings for the database (section 5.8). |
| The bot's Windows session is locked, disconnected or minimized (real terminal) | Holds new requests of both applications in the queue; resumes by itself once Windows accepts keystrokes again. | **Needs attention**: "Requests wait: …"; "Bot Windows session Not Available" and later "… Recovered" to the default recipients. | None. Keep the session signed in, unlocked and not minimized (section 10.2). |
| The mail server does not accept e-mails | Keeps them in the outbox and resends them every 5 minutes. | The E-mail card shows **Not delivering** or the number waiting. | **Keep resending failed e-mails for (hours)** (default 24). |
| An e-mail has no recipient at all | Does not send it, and writes an `email_skipped` event to the audit trail. Other e-mails are not affected. | Nobody. | The recipient lists on **Settings › E-mail** and the team lists of each application. |
| ServiceNow rejects the bot's sign-in | Pauses ticket collection so the bot account is not locked out. | The ServiceNow card shows **Paused — sign-in rejected**; **Warnings** on the Dashboard. | The ServiceNow account and password on **Settings › ServiceNow**. |
| A ticket update cannot be written to ServiceNow | Tries again on the next polls, then gives up. | The ServiceNow card and the Dashboard say how many tickets to update by hand. | None. Update those tickets by hand. |
| A user types a wrong password five times | Locks the account for 15 minutes. The user still sees only "Invalid username or password". | The administrators by e-mail alert; Users shows **Locked until**. | **Failed sign-ins before lockout**, **Lockout duration (s)**, **E-mail when an account is locked**. |
| A user leaves the console open and walks away | Asks "Still there?" after 29 minutes, signs out after 30. | The user, on the sign-in page. | **Sign out after inactivity (s)**. |
| An administrator resets another account's password | Makes the password provisional, ends that person's sessions, lifts any lock. | The person, at the next sign-in; the reset is recorded in the audit trail. | None. |
| The service stops unexpectedly | On the next start, records it in the audit trail. | **Warnings** on the Dashboard and System page for 24 hours. | None. Read the service log for the cause. |
| E-mail test mode is left on | Sends every e-mail only to the testers. | **Warnings**: "E-mail test mode: every e-mail goes only to ...". | **Send every e-mail only to (testing)**: clear it to end test mode. |
| The server clock is not on Japan time | Carries on; IDs and evidence times follow the server clock. | **Warnings** with the time-zone warning. | The Windows time zone of the server. |

## 11. Troubleshooting

> **In plain words.** Find what you see in the first column. The tables are grouped by area. If nothing matches, select **Download diagnostics** on the System page and send the file to the support team: passwords and keys are masked in it.

**Who does this:** Admin first; Developer for anything that needs an advanced or machine setting.

**Where to look first**

| Place | What it tells you |
|---|---|
| **Dashboard** | Whether the service, database, processing, each application's window and the queue are healthy, and anything under **Needs attention** or **Warnings** |
| **System** | The state of every module, the start-up problems and notices, and the service log |
| **Requests** → a request | Its application, status, result code, error, attempts, the ServiceNow ticket, the completion ticket and its audit events |
| **Audit trail** | Every action by the bot and by people, with the time and the account; filter by **Application** while both are in use |
| **Evidence** | The screenshots and screen text of each step |

### ServiceNow

| What you see | Likely cause | What to do |
|---|---|---|
| No tickets are collected | **Poll ServiceNow for tickets** is off, or a filter removes every ticket | Switch polling on. Run **Test connection** and look at **Open tickets after each filter** to find the step that drops to 0. |
| The System card shows **Paused — sign-in rejected** | ServiceNow rejected the bot's sign-in three times in a row | Save the correct password or client secret, then select **Check ServiceNow now**. |
| The System card shows **Not configured** | The password, client secret or another required setting is missing on this server | Complete the named setting. The bot checks again every minute. |
| The System card shows **Failing (n)** and an outage e-mail arrived | ServiceNow did not answer (network, proxy, instance address or a server error) | Check the instance address and the network path. Queued requests keep running; a recovery e-mail follows. |
| A ticket stays unassigned in the group and is never queued | The bot account cannot assign tickets to itself (its rights, group membership or an instance rule) | Check the bot account's role and group membership with the ServiceNow team. The bot tries again at every poll. |
| Tickets are refused with "the instruction text … is empty" or "catalog variables … could not be read" | The bot account cannot read the catalog variable values, and the text is not repeated in a task field | Ask the ServiceNow team for read access to the variable values, or set **Task field: instruction text**. |
| Tickets are refused with "the account name is missing" | The text has no `for account:` phrase, no `Account name:` line and no readable account variable | Correct the ticket or the SailPoint template. The bot checks it again at the next poll. |
| Tickets are refused with "instance '…' is not accepted on this server" | The ticket's Instance is not in **Accepted instances** | Correct the list (or empty it on a test server), or correct the ticket. |
| A ticket is skipped and nothing is written on it | It names another application ID, or is outside the group, Requested For or pick-up states | Run **Preview tickets**. The reason is shown as "not in the selection". Sample (QA): application IDs `2565` (Fujitsu Mainframe) and `6582` (Fujitsu RACF). |
| Preview shows "already known to the bot" | A request for this ticket already exists, in any status | Nothing to do for a processed ticket. Raise a new ticket if the work is still needed. |
| Retry is refused: "the ServiceNow ticket of this request was closed as incomplete" | **Close the ticket when the request failed** is on, so the ticket is final | Raise a new ticket, or switch the setting off if failed tickets should stay open for a retry. |
| A ticket was closed as Closed Incomplete although the change may have been made | The request shows **Needs verification**: the change was submitted but its result could not be confirmed. With **Close the ticket when the request failed** on, such a ticket is closed as Closed Incomplete with the note "Closed as incomplete; if the change is still needed, submit a new request." | Check the account in the application, as the "Please verify" e-mail asks. Ask for a new request only if the change was not made. |
| A request was cancelled before it ran ("the ServiceNow ticket was closed before it ran" or "assigned to someone else") | A person closed or reassigned the ticket after the bot picked it up | This is expected. Raise a new ticket if the change is still wanted. |
| The System page says "ticket update(s) not written: update those tickets by hand" | Writing the outcome failed for six rounds, or ServiceNow no longer showed the ticket as the bot's | Open each request, read its outcome and update the ticket in ServiceNow yourself. |
| The System card warns that the limit of tickets read per poll was reached | More open tickets match the filters than the limit allows, so newer ones are not read | Close old tickets, narrow the filters, or raise **Tickets read per poll (most)** (Developer). |
| Tickets close with an unexpected state | The instance uses other state values | Set **Closing state value** and **Closing state value (failed)** (Developer). |

### E-mail

| What you see | Likely cause | What to do |
|---|---|---|
| No e-mail of any kind | **Send email alerts** is Off, or it was saved but the service was not restarted | Turn it on, select **Restart service**, then use **Send test e-mail**. |
| **Warnings** shows "E-mail is switched off: no recipient is set …" | No recipient list is set at all: neither **Default recipients** nor any other list | Enter **Default recipients** (or a team's addresses) under **Settings › E-mail** and restart. An empty **Default recipients** alone does not switch e-mail off. |
| **Warnings** shows another "E-mail is switched off: …" | **SMTP host** or **From address** is blank, or the security settings conflict | Fill in the value the warning names and restart. |
| Saving a recipient list answers "Restart the service to apply these. E-mail is switched on by this change …" (or "… switched off …") | The lists themselves apply at once, but this save gives the service its first recipient list, or removes its last one, and that switches e-mail on or off when the service starts | Select **Restart service**. Until then, e-mail stays as it was. |
| An expected e-mail was not sent, and the audit trail shows `email_skipped` | That e-mail had no recipient: its own list, the defaults and the team lists were all empty | Fill in the list that should receive it. |
| System alerts arrive, but nothing about requests | **Transaction outcome emails** is Off (the shipped default) | An Admin turns it on and restarts. |
| **Test connection**: the host cannot be reached | Wrong host or port, or a firewall blocks the server | Confirm the host and port with the mail team, and ask for the port to be opened. |
| **Test connection**: the certificate is not trusted | The organisation's certificate authority is not known to the server | Add it to the server, or set **Extra trusted certificate file** (Developer). Avoid switching certificate checking off. |
| **Test connection**: user name or password rejected | Wrong sign-in details, or the relay expects no sign-in | Correct them, or leave the user name blank for a relay without sign-in. |
| The test refuses to use the stored password | **Check the server certificate** is Off | Switch it on, or type the password for the test. |
| "E-mail delivery is failing …" on the Dashboard; the E-mail card shows **Not delivering** | The relay is down or refuses the bot | Fix the relay or the settings. Kept e-mails are sent again every 5 minutes, or select **Resend now**. |
| **Resend now** answers with a later time | The relay recently refused the sign-in, so the bot waits 30 minutes to avoid a lock-out | Correct the SMTP password, then wait or restart. |
| A failure went to the default recipients, not the owning team | **Per-error notices** is Off, or the error is not one of the recognised errors | A Developer turns it on. Other errors always get the general failure e-mail. |
| The Fujitsu Mainframe team or the Fujitsu RACF team receives only the support report | **Fujitsu Mainframe team: support reports only** or **Fujitsu RACF team: support reports only** is On (the default) | This is expected. Switch it off if that team should also receive the outage, sign-in and completion e-mails. |
| The owning team receives nothing | Its list is blank (under **Recipients by system**, or on the tickets and e-mails page of its application) | An Admin enters the list. It applies at once. |
| A Fujitsu RACF "not available" situation also sent the general error e-mail | With **Transaction outcome emails** Off, both e-mails can be sent for the same event | Known limitation; no action is needed. |
| The new user received nothing | No valid e-mail address was found for the person, or the user notice switches are off | Read the note in the support report and the request details. Check the person's ServiceNow record and **User field holding the Employee ID**. |
| Only the testers receive e-mails | **Send every e-mail only to (testing)** is set | Clear it. The Dashboard warning disappears. |
| The support report shows "-" for the requester | The ServiceNow field chosen names nobody | Choose the other option under **Requester (申請者) shown in the support report**, or `none`. |
| The same alert arrives every 5 minutes | The cause is still there. Identical alerts are sent at most once every 5 minutes. | Fix the cause. The alert summary shows how often it happened. |

### The terminal, CyberArk and processing

| What you see | Likely cause | What to do |
|---|---|---|
| System page: "Terminal executor could not be built … Processing is disabled" | Real terminal with no valid 8-character service-account password stored (also when CyberArk is on), or the codes are in the wrong format | Store the affiliation code, staff code and an 8-character password under **Settings › This machine › Credentials**, then restart. |
| System page: "CyberArk is required here …" | Production with the real terminal, and CyberArk is off or its settings are not valid | Complete **Settings › CyberArk**, run **Test retrieval**, switch it on and restart. |
| Processing card **Waiting**: "CyberArk has not delivered the mainframe password yet" | CyberArk is required and the bot is still on its stored password, or screen reading is not working | Read **Needs attention** for the reason. Check the CyberArk card and select **Refresh CyberArk now**. Check that the **Screen reading** card does not show **Not working**. For the bot's Windows session, go by the "Requests wait: …" line (next rows). |
| **Needs attention**: "Requests wait: the bot's Windows session is locked." or "… is disconnected." | The session that runs the bot was locked, or the remote desktop connection was closed without the unattended operation scripts | Sign in to the session again (unlock it), or reconnect. Processing resumes by itself and the recovery e-mail follows. To leave the server unattended, use the unattended operation package (Application Installation Guide). |
| **Needs attention**: "Requests wait: Windows did not accept the bot's keystrokes …"; a request failed with the e-mail "Error: Windows did not accept the bot's keystrokes" | Windows refused the bot's keystrokes during a request, usually because the remote desktop window of the bot's session was minimized | Restore the remote desktop window (do not minimize it), or have the server team set the remote desktop option that keeps a minimized window usable, as the outage e-mail describes. The bot tries once a minute whether keystrokes are accepted again and then resumes. Raise a new ticket for the failed request if its ticket was closed. |
| CyberArk card **Unavailable** | The vault does not answer, or access is denied | Run **Test retrieval** and follow its hint. The last good password stays in use, and the vault is tried again every 5 minutes. |
| CyberArk card or **Test retrieval** names a certificate problem (for example "certificate verify failed"), or CyberArk shows as Inactive | CyberArk uses a certificate from the organisation's own certificate authority, which the bot does not trust | A Developer sets **CyberArk certificate file (internal certificate authority)** under **Settings › This machine › Database**, for example with **Create from Windows certificates**, then saves and restarts. The file is used for every CyberArk call. Do not switch certificate checking off. Sample (QA): `C:\FINESIII\certs\aig-ca-bundle.pem` |
| Saving **CyberArk certificate file (internal certificate authority)** is refused | The file does not exist on this machine, cannot be read, or holds no certificate in PEM form | Correct the path, or create the file again with **Create from Windows certificates**. |
| Request failed: "Not retried: the mainframe rejected the service-account password …" | The password was rotated or is wrong, and no different password has arrived | With CyberArk: confirm the vault holds the current password, then select **Refresh CyberArk now**. Without CyberArk: save the new password and restart. Then raise a new ticket, or retry if the ticket is still open. |
| Request failed: operator code not registered | The service-account codes do not match, or **Mainframe environment** is wrong | Check both codes under Credentials, and **Mainframe environment** (Developer). |
| Request failed with a terminal launch error: "Desktop shortcut … not found" | **Launcher shortcut** is wrong, or the shortcut is missing for the bot's account | Correct the shortcut, restart, and run **Test terminal launch**. |
| "could not be started as administrator", or a warning in the terminal summary | **Start the terminal as administrator** is on, but the service is not running with administrator rights | Run the scheduled task with highest privileges (Application Installation Guide), or switch the setting off if the terminal does not need it. Sample (QA): the scheduled task `FINESIII RPA Agent` |
| "A Fujitsu Mainframe window left open by an earlier attempt could not be closed" | A Fujitsu Mainframe window or dialog is still open on the bot's desktop | Close it on the server, then try again. |
| Request failed with a COBOL run-time message | A terminal program stopped, for example because a record was locked by another session | Make sure no other Fujitsu Mainframe session uses the bot's sign-in, then try again. |
| Requests stay **Queued**; the Mainframe window card shows **Closed** or **Closing** | Outside the operating window, or inside the last minutes before closing | Nothing to do: they run when the window opens. Correct **Window opens / closes (JST)** if the hours are wrong. |
| Requests stay **Queued**; the card shows "mainframe not reachable" | The probe cannot reach the mainframe host | Run **Test mainframe host**, and check the host, port and firewall. |
| Requests stay **Queued**; Processing shows **Paused** | Someone paused processing (a pause survives restarts) | Select **Resume processing** on the System page. |
| The **Screen reading** card shows **Not working** | The reading engine loads but cannot read | Check the server (memory, models). New work waits, and resumes by itself once a read succeeds. |
| A request shows **Needs verification** | The answer to the commit could not be read, or the service stopped after the commit | Check the account in the application. Do not retry. With **Close the ticket when the request failed** on (the default), the bot has already closed the ticket as Closed Incomplete; ask for a new request only if the change was not made. With the setting off, update the ticket by hand. |
| A request failed with the code for an interrupted attempt | The service stopped during the last allowed attempt | Retry from the console (Developer) if the ticket is still open, or raise a new ticket. |
| **Test sign-in and navigation** refused: "possible in N minute(s)" | The previous sign-in test could not sign in (a 10-minute lock-out protection) | Check the password first, wait, then test again. |
| A terminal test is refused: "Pause processing first" | Processing is active | Select **Pause processing**, run the test, then **Resume processing**. |
| A provisioning screenshot is missing from the evidence | The password could not be found and covered, so the screenshot was not kept | This is a safeguard and is recorded in the audit trail. Use the screen text and the printout. |

### Fujitsu RACF

| What you see | Likely cause | What to do |
|---|---|---|
| Fujitsu RACF requests stay **Queued** while Fujitsu Mainframe requests run | The Fujitsu RACF window is closed, the host is down or answers that it is not available, the terminal cannot be started, the sign-on ID is in use, a password was refused, or there is no password yet | **Needs attention** on the Dashboard and the **Fujitsu RACF** card on the System page name the reason. Fix it; the bot tries again by itself every 5 minutes, and a passed Fujitsu RACF test ends the wait at once. While processing is paused, the bot does not start the Fujitsu RACF terminal by itself. |
| A Fujitsu RACF test fails | The answer names the level that failed (host, terminal launch or sign-on) | Read the plain-words answer and select **Show details** for the screenshots and the screen text of each step. Section 5.9 describes each test. |
| Saving **Fujitsu RACF terminal program (instead of the shortcut)** is refused | The value is not a program file on this machine (for example a connection name such as 接続1) | Leave the field empty: the bot then uses the Fujitsu RACF terminal shortcut. Sample (QA): the shortcut `C:\ProgramData\Fujitsu\WSMGR\接続1.emd` |
| A Fujitsu RACF request failed at once after a refused password | The host refused the password; the bot does not try the same password again, so the sign-on ID is not locked | Confirm the current password with the Fujitsu RACF team and save it (under **Credentials**, or in CyberArk), then run **Test Fujitsu RACF sign-on**. |
| A Fujitsu RACF removal ticket is not processed and is handed to a person | **Fujitsu RACF removals** is set to leave removals for a person (the default) | Expected: a person removes the access. Choose **Remove the whole RACF ID** only when each RACF ID carries one group. |
| **Completion ticket** row: "Not created yet: …" | A completion ticket setting is missing, for example the assignment group | A Developer completes **Settings › Fujitsu RACF completion ticket**. The ticket is created within 10 minutes of saving; a missing setting does not use up the bot's tries. |
| **Test completion ticket** answers "ServiceNow did not create the sample: …" with 403 | The bot's ServiceNow account may not create records in the chosen table (a ServiceNow permission rule) | Ask the ServiceNow team for the right to create records in that table. A catalog request (sc_request or sc_req_item) is not available as a completion ticket; use **incident** or **sc_task**. |

### Passwords and the database password

| What you see | Likely cause | What to do |
|---|---|---|
| A reminder e-mail: a service-account password is due, urgent or expired | The password is near or past the host's expiry (90 days by default) | Change the password (Fujitsu Mainframe: **Change service-account password**, Developer; Fujitsu RACF: with the Fujitsu RACF team, then save it), and enter the **last changed on** date if the bot did not make the change. See section 5.3. |
| The password-age line says "Password age: not known. Enter "last changed on" …" | The bot does not know when the password was last changed | Enter the date in **Service-account password: last changed on** or **RACF sign-on ID password: last changed on**. |
| The password-age line says "Automatic change stopped after N failed tries: change it here." | The automatic change of the Fujitsu Mainframe password failed too often in a row, or the host refused the current password | Change the password on the console (Developer), after checking the current password. |
| **Change service-account password** answers "Pause processing first …" or "Outside the operating window: Fujitsu Mainframe does not accept sign-ins now." | The change needs paused processing and the Fujitsu Mainframe operating window | Pause processing, and make the change inside the operating window. |
| **Change service-account password** answers "Fujitsu Mainframe is not ready …" | Fujitsu Mainframe last showed centre not ready or a line error | Wait until it answers again (**Test sign-in and navigation** shows when it does), then try again. |
| **Change service-account password** answers "The service-account password comes from CyberArk, which changes it …" | CyberArk supplies the Fujitsu Mainframe password, so CyberArk owns its changes | Ask the CyberArk team to change it in CyberArk. |
| **Change service-account password** answers "The password was changed on … (JST); the next change is possible 24 hours after it." | At most one change per 24 hours | Wait until the time named. |
| **Change service-account password** answers "The current password is not correct …" or "… the change is possible again in N minute(s)." | The current password was entered wrong; after 3 wrong entries the form is locked for 15 minutes | Check the current password with the person who set it, and wait for the lock to end. A wrong entry here never reaches the host. |
| **Change service-account password** refuses the new password (for example "The new password must start with a letter.") | The new password does not meet the host's rules | Choose a password of exactly 8 half-width characters, starting with a letter, with at least one letter and one digit, only the symbols named, different from the current one and without the staff code. |
| The "not changed" e-mail arrived after a change | The host gave a reason, or the result could not be confirmed and one sign-in with the new password did not succeed | Read the detail rows of the e-mail and the evidence. The bot keeps the password that works. |
| The **Database password** card shows **Previous password in use**, or a problem line; the service log shows "Database password not copied (attempt N): …" | The bot could not give the new password from CyberArk to its database login. The card names the cause, for example that the database administrator account refused the password from CyberArk, that it could not change the bot's database password, or that the database did not answer | Follow the hint: the PAM team checks the account in CyberArk, the database team checks the rights. The bot keeps the password in use and requests keep running. After the third failed try in a row, the e-mail "Database password not updated: the bot keeps working with the password in use" goes to the default recipients and the database team. The next good check ends the problem by itself and sends "Database password updated: …". To check at once, select **Validate database password**. |
| The card or **Validate database password** says that "CyberArk returned another account than the database administrator" | **CyberArk object (database)** names another account | A Developer corrects **CyberArk object (database)** under **Settings › This machine › Database** and runs **Test CyberArk retrieval**. Sample (QA): `Database---rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com---sailpoin1002---5432--dbadmin` |
| The **Database password** card shows **CyberArk not reachable**; the e-mail "CyberArk not available: the database password could not be checked" arrived | CyberArk did not answer the bot's check of the database password, or its certificate is not trusted | Check CyberArk, **CyberArk address (database)** (Sample (QA): `https://pamccp.aig.net`) and the certificate file (above), and run **Test CyberArk retrieval**. Requests keep running with the password in use; a rotation made in CyberArk meanwhile is applied once CyberArk answers. A recovery e-mail follows. If the database stops accepting the password in use before then, processing stops. |
| The e-mail "Bot's database login set back to the password in CyberArk" arrived | The bot's database login refused the password in CyberArk, although that password had not changed: someone changed the login's password outside CyberArk. The bot set it back and continues | Ask the database team to find in the database log who changed it and when. Only the bot sets the password of its login. The event is recorded in the audit trail as a warning. |
| The e-mail "Database password changed: the bot uses the new password" arrived | CyberArk rotated the database password and the bot now uses it. The **Found by** row says how the bot noticed (scheduled check, a refused sign-in, **Validate database password**, the bot's start or a restart) | Nothing to do. If database errors follow, select **Validate database password** and read the answer. |
| Saving the database settings is refused: "Database password from CyberArk: enter CyberArk address (database); enter CyberArk Application ID (database). Nothing was saved." | **Database password from CyberArk** is on, but **CyberArk address (database)** or **CyberArk Application ID (database)** is empty. The bot reads both at start, before the other settings, so the service could not start without them | Enter both values (from the CyberArk team: `<ccp-address>` and `<application ID>`), then save again. Sample (QA): `https://pamccp.aig.net` and `APP-10-SAILPOINT` |
| **Validate database password** answers "A check ran a moment ago; try again in N seconds." | At most one check every 30 seconds | Wait and try again. |
| **Validate database password** answers "CyberArk is changing the password right now …" | CyberArk is rotating the password at that moment | Try again in a minute. |
| A restart from the console answers "Not restarted: the database password from CyberArk could not be obtained: …" | The database password settings were changed and saved, but the password could not be read or applied with the new settings. The service keeps running as it was. When those settings were not changed, a restart goes ahead even while CyberArk does not answer | Correct the cause named. To stop using CyberArk for the database password, a Developer switches **Database password from CyberArk** off and the server team sets the password with the database setup tool (Database Setup Guide). |

### Signing in, users and the console

| What you see | Likely cause | What to do |
|---|---|---|
| "Invalid username or password" although the password is right | The account is locked after too many wrong passwords (the message never says "locked"), or it is deactivated | A person with the Users page opens **Users**: **Locked until** → **Unlock**; **Active: No** → **Activate**. Or wait 15 minutes for the lock to end. |
| "Too many failed sign-in attempts. Wait N second(s) and try again." | A short wait after each wrong password (up to 30 seconds) | Wait the time shown, then type the password carefully. |
| After signing in, only "Choose a new password" appears | The password was set by an administrator, at installation or by a server reset, or it has expired | Enter the current password and a new one twice (12 or more characters, a letter and a digit, not the user name, not one of the last 5). |
| "New password must not be one of your last 5 passwords" | Password history | Choose a password you have not used recently. |
| "You were signed out after 30 minutes without activity." | The inactivity limit | Sign in again. Next time, answer **Stay signed in** on the "Still there?" prompt. |
| "The session reached its maximum length of 12 hour(s) — sign in again" | The maximum session length | Sign in again. |
| "Your session was ended. Sign in again." | An administrator changed your role, deactivated the account, reset the password or ended the session | Sign in again, or ask an administrator why. |
| A user's menu lacks a page they need | Their role does not include it, or their custom role was changed while they were signed in | Check the role on **Users**. After a role change, ask them to sign out and in again. |
| "You do not have access to that page; your first page is shown." | A bookmark or link to a page the role may not open | Use a role that includes the page, or ignore the message. |
| An Admin cannot see **Branding**, **Error rules**, **Roles & permissions**, an advanced setting, **New request** or **Retry** | These belong to the Developer role | Ask a Developer (support team) to make the change. |
| An Admin cannot see the **Users** page | **Users page for Administrators** is Off (the default) | A Developer manages the accounts, or switches the setting on under **Settings › Console sign-in**. |
| An Admin sees no buttons on an account row | That account holds the Developer role, which grants more than an Admin holds | A Developer manages that account. |
| "This is the last active administrator — promote another account first" | Deactivating, demoting or deleting the last active Admin or Developer account | Give another account the Admin or Developer role first. |
| Nobody can sign in (the only administrator forgot the password or is locked out) | No other account can reset it | The server team runs the server-side password reset (section 4), then the user chooses a new password at sign-in. |
| The server-side password reset answers "[NG] Not reset: the password must be at least N characters …" | The new password is shorter than the **Minimum password length** saved on the console, or has no letter or no digit | Run the reset again with a password that meets the console's rules (section 4.3). |
| A changed **Service port** still shows "Saved — applies when the bot is stopped and started again" after **Restart service** | **Restart service** keeps the port in use; the service port and **Refuse another port** apply only when the bot is stopped and started again | **Stop the bot** on the System page, then the server team starts it again (scheduled task or launcher). Open the console at the new port. Sample (QA): the scheduled task `FINESIII RPA Agent` |
| Banner: "The service cannot be reached — it may have been stopped" | The background service is stopped or restarting | Wait for a restart to finish, or ask the server team to start the service. The console keeps trying. |
| The setup assistant does not open again for an Admin | The Admin closed it (remembered per account), and **Run setup again** is for Developers | Finish the remaining items on the **Settings** page and the Dashboard checklist, or ask a Developer to select **Run setup again**. |

---

# Part E — Reference

## 12. Security and compliance

> **In plain words.** The bot is built to act only on approved work, to keep secrets out of files and screenshots, to give each person only the access they need, and to leave a complete, unchangeable record of everything it does.

**Who does this:** Information Security, the business owner and the Developer (support team).

### 12.1 Controls at a glance

| Area | How the solution meets it | Who owns it |
|---|---|---|
| **Authorised work only** | Only approved ServiceNow tickets that match the filters are collected. Each ticket is checked before it is queued and checked again just before the bot runs it. Anything unusual is handed back to a person. | ServiceNow team; Admin |
| **No double changes** | One request at a time, for both applications. Duplicates are caught at pick-up. A change is never repeated automatically once it has been committed in Fujitsu Mainframe or submitted in Fujitsu RACF. | Built in |
| **Least privilege** | Four roles (Viewer, Operator, Admin, Developer) and custom roles. Nobody can give another person a permission they do not hold. The advanced configuration, **New request**, **Retry** and, by default, the Users page belong to the Developer role. | Business owner; Admin |
| **Separation of duties** | Day-to-day administration (Admin) is separate from the advanced configuration, roles, error rules, branding and the password changes (Developer). Keep the Developer role for the support team. | Business owner |
| **Named accounts** | One console account per person; the audit trail records every action under that account. The built-in administrator account is for the first sign-in only. | Admin |
| **Console sign-in** | Passwords of 12 or more characters with a letter and a digit, not containing the user name, not one of the last 5. Lock-out after 5 wrong passwords. Sign-out after 30 minutes without activity and after 12 hours at most. | Developer (settings) |
| **Console exposure** | The console listens only on the server itself; it is reached by remote desktop and is not published on the network. | Server team |
| **Secrets** | Passwords and keys are kept in Windows Credential Manager of the bot account, or fetched from CyberArk. They are never shown again, never written to the settings database, and masked in logs, diagnostics and e-mails. | Developer; CyberArk team |
| **Service-account passwords** | The age of each service-account password is tracked and reminders are sent before it expires; no password is ever shown, logged or e-mailed. The Fujitsu Mainframe change on Task 0890 is a Developer's action: the current password is checked by the bot before any sign-in, so a wrong entry never reaches the host; after 3 wrong current passwords the form is locked for 15 minutes; at most one change per 24 hours; refused while CyberArk owns the password. The new password is kept as pending until the host confirms it, and every change leaves evidence and an audit record. The bot never changes the Fujitsu RACF password itself. | Developer; CyberArk team |
| **Database password from CyberArk** | When CyberArk rotates the database administrator login, the bot reads the password from CyberArk and gives its own application login the same password. It sends the database only a SCRAM verifier of the password, never the password itself, so the password does not reach the database's statement log. The administrator login is used only for this copy; the application keeps signing in with its own login, and its database address holds no password. The console shows no password and no login name. Every change of the password in use, on every path, and every **Validate database password** click is recorded in the audit trail (see below), and a change outside CyberArk is set back and reported. | DBA; CyberArk team |
| **Developer-only actions** | **Test password screen**, **Change service-account password**, **Check password age now**, **Test completion ticket**, **Test CyberArk retrieval** and **Create from Windows certificates** are offered to the Developer role only, and the service refuses them for any other role. | Developer |
| **Service interface** | Other systems must present a machine API key in Production. | Developer |
| **Encryption in transit** | The database connection is encrypted and, with the database addresses the Application Installation Guide uses, the certificate is checked against the database address. The mail connection uses STARTTLS or SSL/TLS where the relay offers it, with certificate checking on by default. CyberArk requires a checked certificate where it is mandatory; a certificate file for an internal certificate authority keeps the check on. | DBA; Mail team; CyberArk team |
| **Account passwords for new users** | Generated by the bot: 8 characters, never taken from a ticket and never reused. Blacked out in the evidence screenshots. E-mailing the password to the user is off unless Information Security agrees. | Information Security |
| **Evidence** | Screenshots and screen text of every step, kept for 90 days by default and then deleted. Access needs the Evidence permission, and every viewing is recorded. | Information Security; Admin |
| **Audit trail** | Append-only. Every sign-in, setting change, credential change, password change and check, evidence view, export, e-mail and bot action is recorded with who and when. Kept in its own database. | DBA; Admin |
| **Database rights** | The application's login cannot rewrite the transaction history or the audit trail. | DBA |
| **Change control** | Every setting change is recorded and can be restored. Software updates arrive as update folders that are checked against a checksum list before they are applied, with a backup to go back to. | Developer; Server team |
| **Monitoring** | Outage and recovery e-mails for ServiceNow, CyberArk, Fujitsu Mainframe, Fujitsu RACF, the database, the database password, CyberArk (database password) and the bot's Windows session; the "Database password changed" and "set back" e-mails; password-age reminders; alerts for errors; a daily summary; the **Needs attention** and **Warnings** lists. | Operations lead |
| **Resilience** | Requests survive a restart. A request interrupted before the commit is tried again (unless that was its last attempt); one interrupted after the commit is marked for a person to check, and its ticket is never closed as complete. E-mails and ticket updates that could not be delivered are retried. A rotation of the database password does not interrupt requests in progress. While the bot's Windows session cannot take keystrokes, new requests wait instead of failing. | Built in |

**Known limitations.** Creating a catalog request (REQ) as the Fujitsu RACF completion ticket is not available. The bot cannot change the Fujitsu RACF password itself; it only reminds. Several servers that each keep their own credential store are not covered by a single setup. Where the Developer leaves the current password empty in the password change form (allowed so that a password set by the automatic change can still be replaced), the 15-minute lock on wrong current passwords does not apply to that attempt.

**Audit events of the database password.** When the database password comes from CyberArk, these events are written to the audit trail. The automatic ones are recorded under the actor "system" with the detail "source: CyberArk"; none holds a password or a login name.

| Event | Severity | When |
|---|---|---|
| `database_password_in_use` | Information | The service started using the password from CyberArk, with when it was last changed in CyberArk and the check interval |
| `database_password_changed` | Information | The bot uses a new password from CyberArk, whichever way it was found (scheduled check, refused sign-in, **Validate database password**, start, restart), and whether the bot's login was given it |
| `database_password_reapplied` | Warning | The bot's login had another password, changed outside CyberArk, and was set back to the password in CyberArk |
| `database_password_update_failed` | Error | The new password could not be given to the bot's login three times in a row |
| `database_password_update_recovered` | Information | A failing copy works again, with how it was found |
| `database_password_cyberark_unavailable` / `database_password_cyberark_recovered` | Warning / Information | CyberArk stopped and started answering the check of the database password |
| `database_password_validated` | Information, or Warning when the check failed | Every **Validate database password** click, by the person who clicked, with its result |
| `database_password_source_changed` | Information | A console restart switched the database password from CyberArk on or off |

### 12.2 Periodic reviews

| Review | How | Suggested frequency |
|---|---|---|
| Access review | **Users › Export users** lists every account with its role and permissions | Quarterly |
| Active sessions | **Users › Active sessions**; end any session that should not be there | As needed |
| Configuration changes | **Settings › History › Recent changes**, or the **Audit trail** filtered on the console | Monthly |
| Evidence access | **Audit trail** filtered on evidence | Monthly |
| Database password changes | **Audit trail** filtered on the `database_password_` events; any `database_password_reapplied` is followed up with the database team | Monthly |
| Service-account passwords | The password-age line on **Settings › Fujitsu Mainframe terminal** and **Settings › Fujitsu RACF terminal and sign-on**; the reminder e-mails | Monthly |
| Audit export for records | **Audit trail** with From and To → **Export CSV**, or **Reports › Export audit events** | As your retention policy requires |
| Error rules | **Error rules** page: every rule on, unless the support team advises otherwise | After each update |

### 12.3 Backups

- Include the application database and the audit database in the organisation's database backups (Amazon RDS automated backups and snapshots).
- Include the data folder on the server in the server backups. It holds the logs, the evidence, the machine settings and, when created, the CyberArk certificate file. Sample (QA): `C:\FINESIII\data`.
- The Application Installation Guide describes restore and moving to another database instance.

## 13. Glossary

| Term | Meaning |
|---|---|
| **AIG IAM Access RPA** | The product described in this guide; "the bot" in running text |
| **Fujitsu Mainframe** | The first mainframe application the bot works on (account creation and removal on task 903) |
| **Fujitsu RACF** | The second mainframe application, optional and switched off by default; its settings keys and system names still say TSS |
| **Affiliation code (所属コード)** | The 5-digit Fujitsu Mainframe organisation code an account belongs to |
| **Staff code / employee code** | The 7-character Fujitsu Mainframe account code |
| **RACF ID, RACF group** | The Fujitsu RACF account the bot creates or removes, and the group it is created with |
| **Sign-on ID** | The Fujitsu RACF ID the bot itself signs on with |
| **Bot account** | The ServiceNow account (and the Windows account) the bot works as |
| **Service account** | The Fujitsu Mainframe account the bot signs in with (for Fujitsu RACF: its sign-on ID) |
| **Assignment group** | The ServiceNow group SailPoint sends the tasks to |
| **SailPoint** | The identity system where access requests start |
| **Catalog task (SCTASK)** | The ServiceNow ticket the bot works on |
| **Completion ticket** | An optional ServiceNow record the bot creates for the application team after a successful Fujitsu RACF create or removal, with the details to check |
| **Support report** | The e-mail report of one SailPoint ticket, sent once all its requests are finished, to the support report recipients and the team of its application |
| **Poll** | One collection of tickets from ServiceNow |
| **Queue** | The list of requests waiting to be processed, for both applications |
| **Operating window** | The hours in which the bot may use an application; each application has its own |
| **Commit ("70")** | The Fujitsu Mainframe command that makes the change final. After it, a request is never repeated automatically. |
| **Task 0890** | The Fujitsu Mainframe task (パスワードの登録と変更) on which the service account's own password is changed |
| **Password age** | How long ago a service-account password was last changed, compared with the host's expiry; the bot sends reminders as it nears the expiry |
| **Needs verification** | The change was submitted but the result could not be confirmed. A person must check the application. The request is never run again, and with **Close the ticket when the request failed** on (the default) its ServiceNow ticket is closed as Closed Incomplete; the "Please verify" e-mail asks for that check. |
| **Bot Windows session** | The Windows session on the server in which the bot runs and types into the terminals. It must stay signed in and unlocked, with its remote desktop window not minimized; otherwise requests wait. Also the name of its outage and recovery e-mails |
| **Password in use** | On the **Database password** card: which database password the bot uses now (the latest from CyberArk, the previous one, or the last one received while CyberArk does not answer) |
| **Already removed** | A removal found that the account no longer existed; nothing was changed |
| **Evidence** | The screenshots, screen text and printouts saved for every step |
| **Audit trail** | The permanent, unchangeable record of every action |
| **Credential store** | Windows Credential Manager, where passwords and keys are kept |
| **CyberArk (CCP / PVWA)** | The organisation's password vault, and its two interfaces: Central Credential Provider and Password Vault Web Access |
| **CCP** | Central Credential Provider: the CyberArk interface the bot uses to read a password with its application ID, without a password of its own |
| **CPM** | Central Policy Manager: the part of CyberArk that changes (rotates) passwords on a schedule. When CPM owns a password, the bot does not change it itself. |
| **Certificate file (CA bundle)** | A file of the certificate authorities that issued the CyberArk certificate, needed when that certificate comes from the organisation's own certificate authority |
| **SCRAM verifier** | A one-way form of a password that a PostgreSQL database stores and checks; the bot sends only this form when it sets its database password |
| **Screen reading (OCR)** | Optical character recognition: how the bot reads what the terminal shows |
| **Terminal simulator / Test double / Simulator** | Test modes that imitate the terminal without touching the mainframe |
| **Admin** | The role that runs the bot day to day, with the essential settings |
| **Developer** | The role with full control, including the advanced settings, roles, error rules, branding, New request, Retry and the password changes |
| **Essential settings** | The settings an Admin can see and change |
| **Provisional password** | A password set by an administrator; the user must change it at the next sign-in |
| **Update folder** | A folder with the changed application files, a checksum list and instructions, used to update an installation |

---

# Appendices

## Appendix A — Information to collect from each team

Collect these before you start, so the setup assistant can be completed in one sitting. Never write passwords on this sheet: they are typed into the console when needed.

| Team | What to provide | Used in |
|---|---|---|
| **ServiceNow team** | Instance address (Sample (QA): `https://aigm3.service-now.com`, QA instance; confirm); sign-in method (user name and password, or OAuth); the bot account and its rights; the assignment group (Sample (QA): `Policy Management System - Common Process-2565-JPN`, for both applications; `MFT-SYS Programmer-JPN` is the group of the Fujitsu RACF completion ticket); the Requested For user, if tickets are filtered on it; a test task; for the Fujitsu RACF completion ticket: the table (for example incident or sc_task), the application team's assignment group, the other fields and values the table needs, and the bot account's right to create records in that table | Sections 5.1, 5.9 |
| **Mail team** | Mail server and port; connection security; sending account (if the relay needs a sign-in); sender address; the operations, support and team distribution lists | Section 5.2 |
| **CyberArk team** | CCP or PVWA; base address; application ID; safe; account object or user name; client certificate (if required); the certificate file of the organisation's certificate authority when CyberArk uses one; the Fujitsu RACF account (when used); who changes the service-account passwords (CPM or the bot) | Section 5.3 |
| **CyberArk team with the DBA** (database password from CyberArk) | The CCP address `<ccp-address>`, the application ID `<application ID>`, the safe `<safe>` and the account object `<account object>` of the database administrator login, and the name of that login `<admin login>`; the database team's address list for the database password e-mails. Sample (QA): `https://pamccp.aig.net`, `APP-10-SAILPOINT`, `BADM_DBADMIN-ISO-POSTGRESQL`, `Database---rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com---sailpoin1002---5432--dbadmin`, `dbadmin` | Sections 5.3, 5.8, 10.5 |
| **Server team** | The bot's Windows account `<bot account>` (Sample (QA): `R6-CORE\prvrnel` on `qwawosis1001.r1-core.r1.aig.net`); how its Windows session is kept signed in, unlocked and not minimized (or the unattended operation set-up); who may change the service port | Sections 9.3, 10.2 |
| **Fujitsu Mainframe team** | The service account's affiliation code and staff code; the date its password was last changed; the terminal program on the server and its shortcut; the mainframe host for the reachability check; the operating hours; development or production system | Sections 5.3–5.5 |
| **Fujitsu RACF team** (when used) | The bot's sign-on ID (Sample (QA): `SAILPNT`) and the date its password was last changed; the system (TSS2 or TSS3; Sample (QA): `TSS3`); the host and port for the availability check; the operating hours; test RACF IDs; the decision on removals; the team addresses and the copy address for the registration notice | Section 5.9 |
| **Information Security** | Approval of the production settings, of e-mailing passwords to users (or not), of the evidence retention period and of the automatic password change (or not) | Sections 5.2, 5.3, 5.6, 9 |
| **Business owner** | The recipients of the reports and notices; who needs console access and with which role; whether the Admins manage console accounts; sign-off of the test results | Sections 3, 5.2, 9 |

## Appendix B — Setup record sheet

Keep a completed copy with the project records. Do **not** write passwords on this sheet.

**Sample (QA):** Appendix C lists the values of the client QA environment for the items of this sheet.

| Item | Value chosen | Provided by | Date | Verified by |
|---|---|---|---|---|
| Server name and bot Windows account | | | | |
| Database addresses (application, audit) | | | | |
| ServiceNow instance and sign-in method | | | | |
| Bot account / assignment group / Requested For | | | | |
| Mail server, port and connection security | | | | |
| Sender address | | | | |
| Default recipients / support report recipients | | | | |
| Recipients by system (ServiceNow, CyberArk, Fujitsu Mainframe, account administration, database) | | | | |
| Fujitsu Mainframe team and Fujitsu RACF team: support reports only (On / Off) | | | | |
| Initial password e-mail approved (yes / no) | | | | |
| CyberArk base address, application ID, safe, account object | | | | |
| CyberArk certificate file (path), if an internal certificate authority is used | | | | |
| Database password from CyberArk (yes / no): `<ccp-address>`, `<application ID>`, `<safe>`, `<account object>`, `<admin login>`; check interval (minutes); database team list | | | | |
| Bot Windows session: how it is kept usable (signed in at the server / unattended operation) | | | | |
| Service environment and Mainframe environment (Development / Production) | | | | |
| Fujitsu Mainframe service account (affiliation and staff codes) | | | | |
| Fujitsu Mainframe service-account password: last changed on; automatic change (On / Off) | | | | |
| Mainframe host and environment | | | | |
| Operating window | | | | |
| Fujitsu RACF (yes / no): system, sign-on ID, host and port, window, removals | | | | |
| Fujitsu RACF sign-on ID password: last changed on | | | | |
| Fujitsu RACF completion ticket: table, assignment group, outcomes, one per, after creating it, fields | | | | |
| Fujitsu RACF registration notice (On / Off) and its CC | | | | |
| Evidence retention (days) | | | | |
| Console administrators (Admin) and support (Developer); Users page for Administrators (On / Off) | | | | |
| End-to-end test sign-off | | | | |
| Go-live approval | | | | |

## Appendix C — QA sample values

Values of the client QA environment, given as worked examples. Use your own environment's values in production. No password is listed: passwords are typed into the console or held in CyberArk.

| Item | QA value |
|---|---|
| Bot server (host name) | `qwawosis1001.r1-core.r1.aig.net` (short name `qwawosis1001`) |
| Bot account (Windows) | `R6-CORE\prvrnel` |
| Install root / application folder / data folder | `C:\FINESIII`, `C:\FINESIII\app`, `C:\FINESIII\data` |
| Scheduled task | `FINESIII RPA Agent` |
| RDS / Aurora PostgreSQL cluster endpoint | `rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com` |
| Port | `5432` |
| Engine | Amazon Aurora PostgreSQL 17 (region us-east-1) |
| RDS administrator login (rotated by CyberArk) | `dbadmin` (settings file: `DATABASE_ADMIN_LOGIN=dbadmin`) |
| Application login / database | `finesiii_app` / `finesiii_v3` |
| Audit database | `finesiii_audit` |
| RDS certificate bundle (shipped) | `C:\FINESIII\app\certs\rds-global-bundle.pem` |
| Database URL (application, no password) | `postgresql://finesiii_app@rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com:5432/finesiii_v3?sslmode=verify-full&sslrootcert=C%3A%5CFINESIII%5Capp%5Ccerts%5Crds-global-bundle.pem&connect_timeout=10&keepalives=1&keepalives_idle=60&keepalives_interval=10&keepalives_count=5&application_name=finesiii-rpa` |
| CyberArk CCP address | `https://pamccp.aig.net` |
| CyberArk Application ID | `APP-10-SAILPOINT` (shared with SailPoint in QA; confirm with the PAM team whether production gets its own) |
| CyberArk safe | `BADM_DBADMIN-ISO-POSTGRESQL` |
| CyberArk account object (database administrator) | `Database---rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com---sailpoin1002---5432--dbadmin` (the database named inside it, `sailpoin1002`, is not the bot's database; the bot's database stays `finesiii_v3`) |
| CyberArk certificate file (internal certificate authority) | `C:\FINESIII\certs\aig-ca-bundle.pem`; settings file: `CYBERARK_CA_BUNDLE=C:/FINESIII/certs/aig-ca-bundle.pem` (**Create from Windows certificates** writes `C:\FINESIII\data\certs\cyberark-ca-bundle.pem` instead) |
| ServiceNow instance | `https://aigm3.service-now.com` (QA instance; confirm) |
| ServiceNow application ID, Fujitsu Mainframe | `2565` (ticket text "Policy Management System - Common Process [2565]") |
| ServiceNow application ID, Fujitsu RACF | `6582` (ticket text "Fujitsu RACF (Resource Access Control Facility) [6582]") |
| Assignment group the bot reads tickets from (both applications) | `Policy Management System - Common Process-2565-JPN` |
| Assignment group of the Fujitsu RACF completion ticket (**Completion ticket: assignment group**) | `MFT-SYS Programmer-JPN` |
| Fujitsu RACF terminal shortcut | `C:\ProgramData\Fujitsu\WSMGR\接続1.emd` |
| Fujitsu RACF terminal program | Empty (`接続1` is not a file; the shortcut is used) |
| Fujitsu RACF window title | `接続1 - DSPEMU` |
| Fujitsu RACF system (LOGON target) | `TSS3` (TSS2 also exists) |
| Fujitsu RACF sign-on ID | `SAILPNT` |
| Fujitsu RACF terminal started as administrator | On |
