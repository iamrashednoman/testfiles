# AIG IAM Access RPA — Application Installation Guide

## Windows Server 2022 with Amazon RDS for PostgreSQL

| | |
|---|---|
| Document | Application Installation Guide |
| Product | AIG IAM Access RPA, version 3.0.0 |
| Date | 16 November 2026 |
| Platform | Windows Server 2022 (64-bit) application server; Amazon RDS for PostgreSQL (or Amazon Aurora PostgreSQL) database, administered with pgAdmin 4 |
| Audience | Executives and project leads, operations and business staff, server administrators, database administrators and support engineers |
| Purpose | To install the application on a server, connect it securely to Amazon RDS, run it as a background service, and hand over a verified installation for configuration in the console |
| Related documents | Administrator Guide; Administrator Runbook (the full command sequence from an empty server to daily operation); Unattended Operation Guide; KT Session Walkthrough; Database Setup Guide |

**What changed in this edition**

- The bot's Windows session: while it is locked, disconnected or shown in a minimized remote-desktop window, Windows refuses the bot's keystrokes, so the bot holds new work (requests wait in the queue) and sends a **Bot Windows session** outage e-mail, then a recovery e-mail. Sections 15.6 to 15.8 say how to keep the session available, including the unattended options of the `unattended` folder.
- Section 13.7 (database password from CyberArk): **CyberArk address (database)** and **CyberArk Application ID (database)** are required while the option is on; the **Database password** card lines (**Password in use**, **Last successful check**, **Next check**); the one button **Validate database password**; the **Database password changed** e-mail; what a rotation looks like after installation; the audit events.
- New in 13.7: the safe order for running `Setup_Database.py` while the database password comes from CyberArk (`--admin-password-from-cyberark` together with `--set-password`, the service stopped). `scripts\setup_rds_database.py` cannot be used while that option is on. Sections 20.3 to 20.5 follow it.
- A change of **Service port** applies only when the bot is stopped and started again; **Restart service** does not apply it. A change of a recipient list that switches e-mail on or off asks for a restart (sections 16 and 18).
- New optional section 16.2: switching the installation to production mode, and what changes with it.
- Section 2 and 13.1: where the audit trail is kept (the local file in the data folder, or the audit database on RDS).
- Sign-off checklist (section 17), troubleshooting (section 22, new 22.10) and the appendices have rows for all of the above.

---

## How to use this guide

| If you are... | Read | You will learn |
|---|---|---|
| **An executive or project lead** | Part A, then the sign-off checklist (section 17) | What is installed, who is involved, how long it takes and how completion is proven |
| **Operations and business staff** | Parts A and B, then section 18 | What the installation needs from each team, and how the installed service is started, stopped and checked |
| **A server or database administrator** | Everything, in order | Every step and command, what each setup script does, what a good result looks like, and how to fix what goes wrong |
| **Anyone who wants only the commands** | The Administrator Runbook, with this guide for the explanations | The full command sequence, step by step, with the expected results |

Conventions used in this guide:

- **Bold text** is exactly what you see on the screen.
- `Code text` is typed exactly as shown. Replace each `<placeholder>` with your value, for example `<rds-endpoint>`.
- A **Sample (QA):** line or block below a placeholder shows the same command or value filled in with the values of the client QA environment, as a worked example (section 6, "QA sample values"). Use your own environment's values in production.
- Every command is written out in full. Copy one command at a time.
- `[OK]` describes a good result. `[NG]` describes a common problem and what to do.
- "Administrator window" means Windows PowerShell opened with **Run as administrator**. "Bot window" means Windows PowerShell opened normally while signed in as the bot account.
- Never type a password inside a command. The scripts ask for passwords without showing them.

> **Tip.** All commands use the folder `C:\FINESIII`. To install on another drive, for example `D:\FINESIII`, make a copy of this guide and use **Find and Replace** twice: `C:\FINESIII` to `D:\FINESIII`, and `C:/FINESIII` to `D:/FINESIII`. The folder path must not contain spaces.

---

# Part A — Overview

## 1. Executive summary

> **In plain words.** AIG IAM Access RPA is a software robot ("the bot") that creates and removes user accounts in the Fujitsu Mainframe system (and, where it is switched on, in Fujitsu RACF), following approved access requests that arrive through ServiceNow. This guide installs it on one Windows server, connects it to the organisation's Amazon RDS database, and leaves it running quietly in the background, ready for the console administrator to configure.

**Who does this:** Server team, Database administrator.

**What is installed.** The application runs on a Windows Server 2022 machine. It keeps its work queue, transaction history, console accounts and settings in one database on the organisation's existing Amazon RDS for PostgreSQL instance. Its audit trail is kept in a second database on the same instance (recommended, and the path of this guide) or, when the organisation decides so, in a local file in the data folder (section 13.1).

**How it is installed.** Two ready-made setup scripts do almost all the work:

| Script | What it does for you |
|---|---|
| **Setup_Prerequisites.ps1** | Checks the server and installs what the application needs: Python 3.13, the Microsoft Visual C++ runtime, the application's own Python environment and packages, and the screen-reading models. It creates the data folder, writes a starter settings file and ends with a self-test. |
| **Setup_Database.py** | With one command, connects to Amazon RDS over an encrypted and certificate-checked connection, creates the application's own login, both databases and all tables with only the rights the application needs, proves them with a test write that it takes back, records the connection, and creates a one-time password for the first console administrator. |

After the two scripts, the server administrator starts the application once to check it, makes it run in the background (it starts by itself when the bot account signs in and restarts itself after an unexpected stop), and hands over to the console administrator.

**How long it takes.** The prerequisites script needs 15 to 30 minutes on its first run, mostly downloading. The remaining steps take about an hour once the worksheet in section 6 is complete.

**How you know it is done.** The sign-off checklist in section 17 is complete: the service starts by itself, the self-test passes, the console opens, and pgAdmin shows the application connected over an encrypted connection.

## 2. What gets installed, and where

> **In plain words.** Everything the bot needs is placed in two folders on the server: one for the program and one for its working data. Passwords are not kept in files; Windows keeps them for the bot's own account. The data itself lives in Amazon RDS.

**Who does this:** Server team.

```mermaid
flowchart TB
    subgraph SRV["Windows Server 2022"]
        subgraph APPF["C:\FINESIII\app - application folder"]
            CODE["Program files and setup scripts"]
            VENV["Python environment (.venv)"]
            ENV["Settings file (.env)"]
            LAUNCH["Background launcher"]
        end
        subgraph DATAF["C:\FINESIII\data - data folder"]
            LOGS["Logs"]
            EVID["Evidence screenshots"]
            STATE["Service keys and state"]
        end
        CM["Windows Credential Manager of the bot account"]
        TASK["Scheduled task: starts the launcher at sign-in"]
        SVC["AIG IAM Access RPA service, in the bot account's session"]
        BROWSER["Browser: console at 127.0.0.1"]
    end
    RDS[("Amazon RDS: finesiii_v3 and finesiii_audit")]
    TASK --> LAUNCH --> SVC
    SVC --> ENV
    SVC --> CM
    SVC --> DATAF
    BROWSER --> SVC
    SVC == "encrypted, certificate checked, port 5432" ==> RDS
```

| Item | Location or name | Created by | Notes |
|---|---|---|---|
| Application folder | `C:\FINESIII\app` | You (step 2) | The package content. Read-only for the bot account, except the settings file and the `config` folder. |
| Python environment | `C:\FINESIII\app\.venv` | Prerequisites script | Python 3.13 side by side with any other Python. An existing Python is not changed. |
| Settings file | `C:\FINESIII\app\.env` | Prerequisites script (starter), database script (database lines), console (machine settings) | How the service starts. Holds no passwords. Appendix B. |
| AWS certificate bundle | `C:\FINESIII\app\certs\rds-global-bundle.pem` | Part of the package | Lets the application prove it is talking to your RDS instance |
| Data folder | `C:\FINESIII\data` | Prerequisites script | Logs, evidence, service keys and state. Include it in server backups. |
| Machine variable `FINESIII_DATA_DIR` | Windows system environment | Prerequisites script | Tells every program where the data folder is |
| Credential store | Windows Credential Manager of the **bot account** | Database script, later the console | Every password and key the service uses |
| Databases | `finesiii_v3` and `finesiii_audit` on the RDS instance | Database script | Used through the login `finesiii_app`, which has no administrative rights |
| Local audit file (only without the audit database) | `C:\FINESIII\data\finesiii_audit.db` | The service | Used when the database script is run without `--audit-database` (section 13.1) |
| Background launcher | `C:\FINESIII\app\Start_FINESIII_Service.pyw` | You (step 8) | Starts the service without a window and restarts it after an unexpected stop. With an unattended option (section 15.8) the copy `C:\FINESIII\app\unattended\Start_FINESIII_Service.pyw` of the package is used instead. |
| Scheduled task | **FINESIII RPA Agent** in the Task Scheduler folder **AIG** | You (step 8), or `unattended\Setup_Unattended.ps1` (section 15.8) | Starts the launcher when the bot account signs in |

**One installation for everyone.** The application is installed once per server. One copy of the service runs, as the bot account. Everyone else who signs in to the server uses it through the console in their own browser, with their own console account. Nothing is installed per person.

## 3. The installation at a glance

> **In plain words.** The installation is nine steps. Most are done by the server administrator; the database administrator joins for the database step. The console administrator takes over at the end. Two optional steps follow only where they are needed.

**Who does this:** Server team, Database administrator, Admin.

| Step | What | Signed in as | Window | Time |
|---|---|---|---|---|
| Part B | Collect the worksheet values and accounts | - | - | Before the day |
| 1 | Prepare the bot account | Administrator | Administrator window | 10 minutes |
| 2 | Copy and verify the package | Administrator | Administrator window | 10 minutes |
| 3 | Install the prerequisites; set the time zone | Administrator | Administrator window | 15-30 minutes |
| 4 | Set the folder permissions | Administrator | Administrator window | 5 minutes |
| 5 | Prepare the RDS connection | **Bot account** (pgAdmin: database administrator) | Bot window, pgAdmin | 10 minutes |
| 6 | Create the database | **Bot account** (the database administrator types the master password) | Bot window | 10 minutes |
| 7 | First start, self-test, first sign-in | **Bot account** | Two bot windows, browser | 15 minutes |
| 8 | Run in the background | Administrator, then bot account | Administrator window | 15 minutes |
| 9 | Hand over to the console | Console administrator | Browser | Continues in the Administrator Guide |
| 13.7 | Optional: database password from CyberArk | Developer (console), with the PAM team | Browser | 30-60 minutes |
| 15.8 | Optional: unattended operation (the bot keeps working while nobody is connected) | Administrator, signed in as the bot account | Administrator window | 30-60 minutes |
| 16.1 | Optional: Fujitsu RACF on this server | Server team, then Developer (console) | Bot's desktop, browser | 30-60 minutes |
| 16.2 | Optional: switch to production mode (after the console set-up and the end-to-end test) | Developer (console), Server team | Browser | 15 minutes |
| Part D | Optional test instance | **Bot account** | Bot windows | 30-60 minutes |

> **Important.** The service reads its passwords from the Windows Credential Manager of the bot account, and each Windows account has its own store. The database script saves the database password and the one-time console password in the store of **whoever runs it**. Steps 5 to 7 must therefore be done **signed in as the bot account**.

## 4. Who is involved

> **In plain words.** Several teams each provide one piece: a server, an account, network access, a database login. The table shows who provides what, and when.

**Who does this:** Server team, Database administrator.

| Team | Provides | For step |
|---|---|---|
| Server team | The Windows Server 2022 machine, the bot's Windows account and its group membership, remote-desktop access, internet access (or a proxy) during installation, the time zone | 1-4, 8 |
| Server team (cloud network) | A security-group rule that lets this server reach the RDS endpoint on port 5432; name resolution of the endpoint | 5 |
| Database administrator | The RDS endpoint, the master user (typed at the prompt, never stored), confirmation that encryption is enforced | 5-6 |
| PAM / CyberArk team (only with section 13.7) | The CyberArk details of the database administrator login, the bot server's access to them, and the agreement that the bot copies that password to its own login | 13.7 |
| Information security | Approval of the bot account's rights (administrator by default, section 8), the password handling and the session policy for the bot's desktop | 1, 8 |
| Project lead | Collects the worksheet (section 6) and signs off the checklist (section 17) | 6, 17 |
| Admin (console administrator) | Takes over in the console after step 9 | 9 |

---

# Part B — Before you start

## 5. Requirements

> **In plain words.** Before the day of installation, make sure the server, the accounts, the network path to the database and the database instance are ready. Nothing has to be installed on the server beforehand.

**Who does this:** Server team, Database administrator.

### 5.1 Server

| Requirement | Detail |
|---|---|
| Operating system | Windows Server 2022, 64-bit (Windows Server 2019 and Windows 10 / 11, 64-bit, also work) |
| Free disk space | At least 5 GB. Evidence screenshots grow with the number of requests. |
| PowerShell | Windows PowerShell 5.1 (built in) |
| Browser | Microsoft Edge or Google Chrome |
| pgAdmin 4 | With access to the RDS instance, for the database administrator's checks |
| Software to install beforehand | None. An existing Python of any version is left unchanged. |
| Folder path | `C:\FINESIII` (or another short path without spaces) |

### 5.2 Accounts

| Account | Needed for | Rights |
|---|---|---|
| Server administrator (Windows) | Steps 1-4 and 8 | Member of the local Administrators group |
| **Bot account** (Windows) | Runs the service; steps 5-7 | Member of the local **Administrators** group (main path, section 8). It must sign in to the server interactively, by remote desktop, because the bot works in a terminal window on its desktop. A normal user is enough only in the alternative set-up of section 8. |
| RDS master user | Step 6 only | Can create logins and databases. Typed at the prompt for that run only and stored nowhere. |
| Application login `finesiii_app` | Everyday database use by the service | Created in step 6, with no administrative rights |
| Database administrator login in CyberArk `<admin login>` (optional) | Only with section 13.7: the bot reads its password to give `finesiii_app` the same one | Held and rotated by the PAM team; usually the RDS master user |
| Console administrator `admin` | First sign-in to the console (step 7) | Created at the first start, with a one-time password from step 6 |

**Sample (QA):** bot account `R6-CORE\prvrnel`; RDS administrator login (also the database administrator login in CyberArk) `dbadmin`.

**Why the bot account is an administrator by default.** The console setting **Start the terminal as administrator** is On by default. Windows only lets a program that itself runs as administrator type into a window that was started as administrator. The service therefore runs with administrator rights, through a scheduled task with highest privileges. If the Fujitsu Mainframe terminal on your server works without administrator rights, the alternative in section 8 avoids this.

### 5.3 Network

| From the server to | Port | Why | When |
|---|---|---|---|
| `pypi.org`, `files.pythonhosted.org` | 443 | Python packages | Installation and updates that add packages |
| `www.python.org` | 443 | Python 3.13 installer | Installation |
| `aka.ms` (Microsoft download) | 443 | Visual C++ runtime | Installation |
| `truststore.pki.rds.amazonaws.com` | 443 | A fresh AWS certificate bundle | Only when the bundle is refreshed (section 20.5) |
| The RDS endpoint | 5432 | The application's databases | Always |
| The CyberArk Central Credential Provider (`<ccp-address>`) | 443 | The database password from CyberArk | Only with section 13.7 |

**Sample (QA):** RDS endpoint `rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com` (port 5432); CyberArk Central Credential Provider `pamccp.aig.net` (port 443).

The prerequisites script accepts a web proxy (section 10). During console configuration the server also needs to reach ServiceNow, the mail relay, CyberArk, the Fujitsu Mainframe host and, when it is used, the Fujitsu RACF host; the Administrator Guide lists them.

### 5.4 The Amazon RDS instance

The instance already exists and is managed by the organisation. Confirm the following with the database administrator:

| Check | Expected | Why |
|---|---|---|
| Engine | Amazon RDS for PostgreSQL or Aurora PostgreSQL, version 13 or later | The setup warns below version 13 |
| Security group | Inbound TCP 5432 from this server's private address (`/32`) or its security group only | Only this server reaches the database |
| Public access | **Publicly accessible: No** when the server reaches RDS privately | The database stays off the internet |
| Encryption enforced | Parameter group: `rds.force_ssl = 1` | Unencrypted connections are refused |
| Authentication | Password authentication for the application login | The service signs in with a stored password. AWS IAM database tokens and AWS Secrets Manager are not used. |
| Automatic password rotation | Not applied to the application login. When the PAM team rotates the administrator login with CyberArk, the bot can follow it (section 13.7); otherwise a manual change is agreed (section 20.4) | Without section 13.7 the service keeps the password in the bot account's credential store |
| Connections | About 20 free connections for this installation | The service keeps a pool of up to 10, plus the audit trail and the tools |
| Resilience | Automated backups, deletion protection, Multi-AZ, and a maintenance window outside the operating window (06:00-22:00 JST by default) | Recommended for production |

### 5.5 Server time zone

The server's time zone must be **(UTC+09:00) Osaka, Sapporo, Tokyo**. Transaction IDs, screenshot names and the time on evidence follow the server clock, while the console and e-mails show Japan time (JST). On another time zone the service still runs, but the console's System page shows a warning (section 22.5). Step 3 checks and sets it.

## 6. Installation worksheet

> **In plain words.** Collect these values before the day. Most have a standard value; only the account, the endpoint and the master user are yours.

**Who does this:** Server team, Database administrator.

A blank copy is in Appendix C. Passwords are never written on the worksheet.

| # | Item | Standard value | QA value (sample) | Your value |
|---|---|---|---|---|
| 1 | Application folder | `C:\FINESIII\app` | `C:\FINESIII\app` | |
| 2 | Data folder | `C:\FINESIII\data` | `C:\FINESIII\data` | |
| 3 | Bot Windows account | `<DOMAIN>\<bot-account>` | `R6-CORE\prvrnel` | |
| 4 | RDS endpoint (instance endpoint, or the Aurora writer endpoint) | `<rds-endpoint>` (`<name>.<id>.<region>.rds.amazonaws.com`) | `rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com` | |
| 5 | RDS port | `5432` | `5432` | |
| 6 | RDS master user (setup only) | `<master-user>` | `dbadmin` | |
| 7 | Application login | `finesiii_app` | `finesiii_app` | |
| 8 | Application database | `finesiii_v3` | `finesiii_v3` | |
| 9 | Audit database | `finesiii_audit` | `finesiii_audit` | |
| 10 | Web proxy, if any | `http://<proxy-host>:<port>` | - | |
| 11 | Console address | `http://127.0.0.1:8000` | - | |
| 12 | Server time zone | (UTC+09:00) Osaka, Sapporo, Tokyo | - | |
| 13 | Terminal needs administrator rights? | Yes (main path) | - | |
| 14 | Optional test instance (Part D) | `C:\FINESIII\data-test`, port 8001 | - | |
| 15 | Optional: database password from CyberArk (13.7) | `<ccp-address>`, `<application ID>`, `<safe>`, `<account object>`, `<admin login>` | `https://pamccp.aig.net`, `APP-10-SAILPOINT`, `BADM_DBADMIN-ISO-POSTGRESQL`, `Database---rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com---sailpoin1002---5432--dbadmin`, `dbadmin` | |
| 16 | Optional: Fujitsu RACF on this server (16.1) | Fujitsu RACF host and port, the bot's sign-on ID | Sign-on ID `SAILPNT`, system `TSS3`; host and port: from your team | |
| 17 | Optional: unattended option (15.8) | A, B, C or D, as agreed with information security | - | |
| 18 | Optional: production mode (16.2) | **Mainframe environment** the host expects (`production` or `development`); the CyberArk accounts of the service accounts | - | |

**QA sample values.** Values of the client QA environment, given as worked examples. Use your own environment's values in production. They are the values used in every **Sample (QA):** of this guide. No password is ever written here.

| Item | QA value |
|---|---|
| Bot server (host name) | `qwawosis1001.r1-core.r1.aig.net` (short name `qwawosis1001`) |
| Bot account (Windows) | `R6-CORE\prvrnel` |
| Install folder, application folder, data folder | `C:\FINESIII`, `C:\FINESIII\app`, `C:\FINESIII\data` |
| RDS / Aurora PostgreSQL cluster endpoint | `rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com` |
| Port | `5432` |
| Engine | Amazon Aurora PostgreSQL 17 (region us-east-1) |
| RDS administrator login (rotated by CyberArk) | `dbadmin` |
| Application login / database | `finesiii_app` / `finesiii_v3` |
| Audit database | `finesiii_audit` |
| RDS certificate bundle (shipped) | `C:\FINESIII\app\certs\rds-global-bundle.pem` |
| CyberArk CCP address (**CyberArk address (database)**) | `https://pamccp.aig.net` |
| CyberArk Application ID (**CyberArk Application ID (database)**) | `APP-10-SAILPOINT` (shared with SailPoint in QA; confirm with the PAM team whether production gets its own) |
| CyberArk safe (**CyberArk safe (database)**) | `BADM_DBADMIN-ISO-POSTGRESQL` |
| CyberArk account object of the database administrator (**CyberArk object (database)**) | `Database---rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com---sailpoin1002---5432--dbadmin` (the database named inside the object, `sailpoin1002`, is not the bot's database; the bot's database stays `finesiii_v3`) |
| Database administrator login (**Database administrator login**) | `DATABASE_ADMIN_LOGIN=dbadmin` |
| Internal certificate authority bundle for CyberArk (**CyberArk certificate file (internal certificate authority)**) | File `C:\FINESIII\certs\aig-ca-bundle.pem`; in `.env`: `CYBERARK_CA_BUNDLE=C:/FINESIII/certs/aig-ca-bundle.pem` (the console button **Create from Windows certificates** writes its own file, `C:\FINESIII\data\certs\cyberark-ca-bundle.pem`, instead) |
| Database URL (application, no password), as `Setup_Database.py --rds` writes it | `postgresql://finesiii_app@rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com:5432/finesiii_v3?sslmode=verify-full&sslrootcert=C%3A%5CFINESIII%5Capp%5Ccerts%5Crds-global-bundle.pem&connect_timeout=10&keepalives=1&keepalives_idle=60&keepalives_interval=10&keepalives_count=5&application_name=finesiii-rpa` |
| ServiceNow instance | `https://aigm3.service-now.com` (QA instance; confirm) |
| ServiceNow application ID, Fujitsu Mainframe | `2565` (ticket text "Policy Management System - Common Process [2565]") |
| ServiceNow application ID, Fujitsu RACF | `6582` (ticket text "Fujitsu RACF (Resource Access Control Facility) [6582]") |
| **Assignment group (sys_id or name)**: the one group the bot reads the tickets of both applications from | `Policy Management System - Common Process-2565-JPN` |
| **Completion ticket: assignment group** (Fujitsu RACF completion ticket only; not a group the bot reads tickets from) | `MFT-SYS Programmer-JPN` |
| **Fujitsu RACF terminal shortcut** | `C:\ProgramData\Fujitsu\WSMGR\接続1.emd` |
| **Fujitsu RACF terminal program (instead of the shortcut)** | Empty (`接続1` is not a file; the shortcut is used) |
| **Fujitsu RACF window title contains** | `接続1 - DSPEMU` |
| **Fujitsu RACF system** (LOGON target) | `TSS3` (TSS2 also exists) |
| **Fujitsu RACF sign-on ID** | `SAILPNT` |
| **Start the Fujitsu RACF terminal as administrator** | On |
| Scheduled task name | `FINESIII RPA Agent` |

## 7. The scripts and tools in the package

> **In plain words.** The package contains two setup scripts, one program with several start options, and a few tools. This section says which ones the installation uses.

**Who does this:** Server team.

| Script or tool | Purpose | Used in | Run as |
|---|---|---|---|
| `Setup_Prerequisites.ps1` | Setup script 1. Checks the server and installs what is missing. Safe to run again at any time: what is in place is left alone. Options: `-CheckOnly`, `-Proxy`, `-DataDir`, `-SkipOcr`. | Step 3; updates | Administrator window |
| `Setup_Database.py` | Setup script 2. Creates and checks the database objects, records the connection, creates the one-time console password. Safe to run again: nothing is dropped and no row is changed. All options in section 13.6. While the database password comes from CyberArk, run it only in the order of section 13.7. | Step 6; section 20 | Bot account |
| `desktop\app.py --agent` | Starts the service with the console. In a PowerShell window it runs in the foreground until stopped. | Step 7 | Bot account |
| `desktop\app.py --stop` | Asks the running service to finish a transaction in progress and stop | Step 7; operation | Bot account or administrator |
| `desktop\app.py --selftest` | Checks each component: simulator window support, screen reading, error rules, credential store, database. `--json` gives the full detail. | Step 7; support | Bot account |
| `desktop\app.py --check-db` | Checks the database the service is configured for. `--json` gives the full detail. | Step 6; support | Bot account |
| `desktop\app.py --headless` | Runs the service in the foreground and stops at the first start-up error, printing it | Troubleshooting | Bot account |
| `desktop\app.py --reset-console-password <user>` | Sets a provisional console password from the server itself. It follows the console's password rules, including the minimum length saved in the console. | Lost administrator password | Bot account |
| `desktop\app.py --configure ...` | An installer step that writes the machine settings file in the data folder and can register its own task. **Not used** here: this installation keeps its settings in `.env`, which wins over that file, and its own task would not start in the application folder. | Not used | - |
| `Start_FINESIII_Service.pyw` | The background launcher, written in step 8 | Step 8; operation | Started by the scheduled task |
| `PACKAGE_CONTENTS.txt` | A SHA-256 checksum for every file of the package: the checksum, two spaces, and the path inside the package | Step 2 | Administrator |
| `certs\rds-global-bundle.pem` | The AWS certificate bundle for RDS and Aurora | Steps 5-6 | - |
| `scripts\schema.sql`, `scripts\audit_schema.sql` | The table definitions. The database script uses them; a database administrator can also run them in pgAdmin (section 13.4). | Optional | Database administrator |
| `scripts\download_ocr_models.py` | Downloads the screen-reading models again. The package already contains them. | Rarely | Administrator |
| `scripts\run_mock_snow_server.py`, `scripts\run_snow_ticket_seeder.py` | A stand-in for ServiceNow with fictional SailPoint tickets, and a ticket generator, for the test instance | Part D | Bot account |
| `scripts\rpa_cli.py` | Runs a single provisioning or removal on the terminal without the queue | Support only | Bot account |
| `scripts\run_servicenow_connector.py` | A separate ServiceNow collector. **Not needed**: the service collects tickets itself. | Not used | - |
| `scripts\migrate_v2_data.py` | Copies the queue and history of the previous version once | Only when migrating | Bot account |
| `scripts\setup_rds_database.py` | A guided form of the one-command RDS mode: asks for the endpoint and the administrator's password (or reads it from CyberArk with `--admin-password-from-cyberark`), runs `Setup_Database.py --rds` first as a check, then, after a confirmation, for real. It stops the service before the setup and offers to start it afterwards. Options: `--cluster`, `--port`, `--admin-login`, `--app-login`, `--database`, `--audit-database`, `--tls`, `--set-password`, `--check-only`, `--no-service`, `--admin-password`, `--admin-password-from-cyberark`, `--yes`. Not usable while the database password comes from CyberArk (section 13.7): its check then stops the run. | Instead of 13.1 or 20.4, when preferred | Bot account |
| `scripts\transfer_sqlite_to_postgres.py` | Copies the queue, history, console accounts, roles and settings of an earlier installation that used the built-in database file into PostgreSQL, in one checked transaction. `--check-only` tries it and undoes it. | Only when moving from a database file | Bot account, service stopped |
| `scripts\clear_ticket_data.py` | Removes the requests of a test round from the queue and the history, keeping completed requests; shows what it would remove unless `--apply` is given | Test servers only | Bot account, service stopped |
| `scripts\developer_role_to_admin.py` | Gives Developer accounts the administrator role, before going back to an application version that has no Developer role | Only when going back | Bot account |
| `run.py` | Starts the service without the console. **Not used**. Never run it beside the service. | Not used | - |
| `Technical Documentation\Database_Setup_Scripts` | A SQL script set with the Database Setup Guide, for database administrators who prefer psql | Optional | Database administrator |
| `unattended\` | Scripts that keep the bot working while nobody is connected to the server: `Setup_Unattended.ps1` (sets up option A, B, C or D, or removes it with `-Remove`), `Check_Unattended.ps1` (shows what is set up; changes nothing), `Leave_Bot_Running.cmd` (leaves the server without locking the bot's session), `Keep_Bot_Session.pyw` (options B and D), and their own copy of the launcher. Described in section 15.8 and the Unattended Operation Guide. | Optional, section 15.8 | Administrator window, signed in as the bot account |

**Sample (QA):** the guided tool `scripts\setup_rds_database.py` with the QA cluster, in a bot window (it asks for the administrator's password without showing it):

```powershell
cd C:\FINESIII\app
.\.venv\Scripts\python.exe scripts\setup_rds_database.py --cluster rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com --admin-login dbadmin --audit-database finesiii_audit
```

---

# Part C — Installation

## 8. Step 1: Prepare the bot account

> **In plain words.** The bot needs its own Windows account. It signs in to the server like a person, because it works in the Fujitsu Mainframe terminal window on its own desktop. By default it is a local administrator, so that it can operate a terminal that runs as administrator.

**Who does this:** Server team.

*Signed in as: server administrator. Window: administrator window.*

1. The server team creates the bot's Windows account (worksheet item 3), with a password that follows the organisation's policy for service accounts.
2. Add it to the local Administrators group. The group is named by its fixed identifier, so the command also works on Japanese-language Windows:

```powershell
Add-LocalGroupMember -SID 'S-1-5-32-544' -Member '<DOMAIN>\<bot-account>'
Get-LocalGroupMember -SID 'S-1-5-32-544'
```

**Sample (QA):**

```powershell
Add-LocalGroupMember -SID 'S-1-5-32-544' -Member 'R6-CORE\prvrnel'
Get-LocalGroupMember -SID 'S-1-5-32-544'
```

`[OK]` The bot account is listed.
`[NG]` "Principal ... was not found": the account name is mistyped. Use `DOMAIN\name` for a domain account, or `<server-name>\name` for a local account.
`[NG]` "...is already a member of group...": nothing to do.

3. Sign in to the server **once as the bot account** by remote desktop, so that Windows creates its profile, then sign out.

> **Important.** Information security approves the bot account's administrator rights before go-live. They are needed because the terminal is started as administrator (section 5.2). The service then runs with full rights on this server, so access to the bot account and its desktop session must be limited to the operations team.

> **Tip. The alternative: a bot without administrator rights.** Use it only when the Fujitsu Mainframe terminal on this server works without administrator rights. Then:
> - skip command 2 above; instead let the bot sign in by remote desktop: `Add-LocalGroupMember -SID 'S-1-5-32-555' -Member '<DOMAIN>\<bot-account>'` (the Remote Desktop Users group; **Sample (QA):** `Add-LocalGroupMember -SID 'S-1-5-32-555' -Member 'R6-CORE\prvrnel'`);
> - in step 8 register the task with `-RunLevel Limited` instead of `-RunLevel Highest`;
> - after hand-over, a console administrator switches **Start the terminal as administrator** Off under **Settings › Fujitsu Mainframe terminal**.
>
> Trade-off: the service then has only normal user rights (least privilege), but if the terminal does need administrator rights, Windows does not let the bot type into it. The console shows this under **Settings › Fujitsu Mainframe terminal › Terminal summary (as the service runs now)**: **Terminal started as administrator** and **This service runs as administrator** must not be **Yes** and **No**.

## 9. Step 2: Copy and verify the package

> **In plain words.** Copy the delivered package to the server, then prove with checksums that every file arrived complete and unchanged.

**Who does this:** Server team.

*Signed in as: server administrator. Window: administrator window.*

1. Create the folders and copy the **content** of the package folder (including the `models` and `certs` folders) into `C:\FINESIII\app`, so that `C:\FINESIII\app\Setup_Prerequisites.ps1` exists:

```powershell
New-Item -ItemType Directory -Force -Path 'C:\FINESIII\app'
```

2. Unblock the files (Windows marks files copied from another machine as blocked) and look at the content:

```powershell
cd C:\FINESIII\app
Get-ChildItem -Recurse -File | Unblock-File
Get-ChildItem -Force | Select-Object Name
```

`[OK]` `certs`, `config`, `desktop`, `docs`, `models`, `scripts`, `src`, `tests`, `Technical Documentation`, `unattended`, `.env.example`, `00_READ_FIRST.txt`, `PACKAGE_CONTENTS.txt`, `pytest.ini`, `requirements.txt`, `requirements-worker.txt`, `requirements-ocr.txt`, `run.py`, `RUN_COMMANDS.txt`, `Setup_Database.py`, `Setup_Prerequisites.ps1`. A `Documentation` folder with the guides may also be present when they are delivered with the package.
`[NG]` `.env`, `.venv`, `logs` or a `.db` file is present: it came from another machine. Delete it; the setup creates its own.

3. Prove that every file is complete and unchanged (about one minute):

```powershell
Get-Content .\PACKAGE_CONTENTS.txt | Where-Object { $_ -match '^[0-9a-f]{64}  ' } | ForEach-Object { if (-not (Test-Path -LiteralPath $_.Substring(66))) { 'MISSING  ' + $_.Substring(66) } elseif ((Get-FileHash -Algorithm SHA256 -LiteralPath $_.Substring(66)).Hash -ne $_.Substring(0, 64)) { 'CHANGED  ' + $_.Substring(66) } }
```

`[OK]` No output.
`[NG]` `MISSING` or `CHANGED` lines: copy the package again (section 22.1).

## 10. Step 3: Install the prerequisites

> **In plain words.** One script checks the server and installs everything that is missing. It ends with READY or tells you exactly what to correct. Then the server clock is set to Japan time.

**Who does this:** Server team.

*Signed in as: server administrator. Window: administrator window.*

### 10.1 Run the prerequisites script

```powershell
cd C:\FINESIII\app
powershell -NoProfile -ExecutionPolicy Bypass -File .\Setup_Prerequisites.ps1
```

Behind a web proxy, add `-Proxy http://<proxy-host>:<port>` at the end. Each check is reported as **OK**, **INSTALLED**, **INFO**, **WARN** or **FAIL**:

| # | Check | What it does |
|---|---|---|
| 1/12 | Server | 64-bit Windows, PowerShell 5.1 or later, administrator window, application files present, free disk space (5 GB), folder path length. Stops at once if application files are missing. |
| 2/12 | Internet access | Tests `pypi.org`, `files.pythonhosted.org` and `www.python.org` |
| 3/12 | Python 3.13 (64-bit) | When missing, downloads the installer and runs it only after checking its SHA-256 checksum and its signature by the Python Software Foundation. Installed for all users, without changing the PATH or an existing Python. |
| 4/12 | Visual C++ runtime | When missing, downloads it and installs it after checking its signature by Microsoft Corporation. It may ask for a server restart. |
| 5/12 | Python environment | Creates `C:\FINESIII\app\.venv`; rebuilds one made with another Python version |
| 6/12 | Application packages | Installs the service, terminal-automation and screen-reading packages (the screen-reading packages take 10 to 20 minutes) |
| 7/12 | OCR models | Confirms the screen-reading models of the package; downloads them only when missing |
| 8/12 | Data folder | Creates `C:\FINESIII\data` with `logs` and `evidence`, and sets the machine variable `FINESIII_DATA_DIR` |
| 9/12 | Settings file | Creates a starter `C:\FINESIII\app\.env` when there is none: Development environment, simulator, no API key. An existing file is left unchanged. |
| 10/12 | Stored credentials | Reports credentials of an earlier installation in this account's store (report only) |
| 11/12 | Browser and service port | Reports Edge or Chrome, and whether port 8000 is free (report only) |
| 12/12 | Component self-test | Runs the application's self-test |

`[OK]` A summary table, then **READY.** and exit code 0 (type `$LASTEXITCODE` to see it). **READY, with warnings** (exit code 2) is also acceptable once each WARN line is understood. One INFO line is expected: **Production: the starter settings file is for testing (APP_ENV=development, no API key)...** The console administrator switches to production later (Administrator Guide).
`[NG]` **NOT READY** (exit code 1): correct each FAIL line as it says and run the same command again. Section 22.2 lists every message.

A transcript of every run is kept as `C:\FINESIII\data\logs\setup_<date>_<time>.log`.

| Option | Use |
|---|---|
| `-CheckOnly` | Report only; nothing is installed or changed |
| `-Proxy http://<proxy-host>:<port>` | Download through a web proxy |
| `-DataDir <folder>` | Another data folder (default `C:\FINESIII\data`) |
| `-SkipOcr` | Leaves out screen reading. **Do not use**: screen reading is mandatory with the real terminal. |

### 10.2 Set the server time zone

```powershell
Get-TimeZone | Select-Object Id, DisplayName
```

`[OK]` `Tokyo Standard Time` and `(UTC+09:00) Osaka, Sapporo, Tokyo`.
`[NG]` Another time zone: agree the change with the server team, then:

```powershell
Set-TimeZone -Id 'Tokyo Standard Time'
```

> **Important.** Close this window. Windows shows the machine variable created by the script only to windows opened afterwards. Every later step starts in a freshly opened window.

## 11. Step 4: Set the folder permissions

> **In plain words.** By default, every user who signs in to a Windows server can read new folders on the system drive. The evidence screenshots show initial passwords of new accounts, so access is limited to the system, administrators and the bot account.

**Who does this:** Server team.

*Signed in as: server administrator. Window: a freshly opened administrator window.*

| Folder or file | SYSTEM and Administrators | Bot account | Everyone else | Why the bot needs it |
|---|---|---|---|---|
| `C:\FINESIII` | Full control | Read (this folder only) | No access | To reach the two folders |
| `C:\FINESIII\data` | Full control | **Modify** | No access | Logs, evidence, service keys and state, the setup logs, backups of `.env` |
| `C:\FINESIII\app` | Full control | **Read & execute** | No access | To run the program |
| `C:\FINESIII\app\.env` | Full control | **Modify** | No access | The database script writes the database lines; the console writes machine settings into it, keeping a dated backup |
| `C:\FINESIII\app\config` | Full control | **Modify** | No access | A Developer may switch error rules on and off on the **Error rules** page; the service then replaces `config\errors.yaml` with an updated copy |

```powershell
icacls 'C:\FINESIII' /inheritance:r /grant:r "*S-1-5-18:(OI)(CI)F" "*S-1-5-32-544:(OI)(CI)F" "<DOMAIN>\<bot-account>:RX"
icacls 'C:\FINESIII\data' /inheritance:r /grant:r "*S-1-5-18:(OI)(CI)F" "*S-1-5-32-544:(OI)(CI)F" "<DOMAIN>\<bot-account>:(OI)(CI)M"
icacls 'C:\FINESIII\app' /inheritance:r /grant:r "*S-1-5-18:(OI)(CI)F" "*S-1-5-32-544:(OI)(CI)F" "<DOMAIN>\<bot-account>:(OI)(CI)RX"
icacls 'C:\FINESIII\app\.env' /grant "<DOMAIN>\<bot-account>:M"
icacls 'C:\FINESIII\app\config' /grant "<DOMAIN>\<bot-account>:(OI)(CI)M"
```

**Sample (QA):**

```powershell
icacls 'C:\FINESIII' /inheritance:r /grant:r "*S-1-5-18:(OI)(CI)F" "*S-1-5-32-544:(OI)(CI)F" "R6-CORE\prvrnel:RX"
icacls 'C:\FINESIII\data' /inheritance:r /grant:r "*S-1-5-18:(OI)(CI)F" "*S-1-5-32-544:(OI)(CI)F" "R6-CORE\prvrnel:(OI)(CI)M"
icacls 'C:\FINESIII\app' /inheritance:r /grant:r "*S-1-5-18:(OI)(CI)F" "*S-1-5-32-544:(OI)(CI)F" "R6-CORE\prvrnel:(OI)(CI)RX"
icacls 'C:\FINESIII\app\.env' /grant "R6-CORE\prvrnel:M"
icacls 'C:\FINESIII\app\config' /grant "R6-CORE\prvrnel:(OI)(CI)M"
```

`*S-1-5-18` is SYSTEM and `*S-1-5-32-544` is the local Administrators group. The identifiers work on English and Japanese Windows alike.

`[OK]` Each command ends with **Successfully processed ... files; Failed processing 0 files**.
`[NG]` "No mapping between account names and security IDs was done": the bot account name is mistyped (section 22.3).

Check the result:

```powershell
icacls 'C:\FINESIII\data'
icacls 'C:\FINESIII\app'
```

`[OK]` Only SYSTEM, Administrators (shown with their local names) and the bot account are listed; no `Users` or `Authenticated Users` line.

> **Tip.** On the main path the service runs with administrator rights and reaches both folders through the Administrators group anyway. The grants above are still needed: the bot's normal windows (steps 5 to 7) do not use administrator rights, and the alternative set-up of section 8 relies on them. Where the application folder is read-only for the process, the console keeps its backups of `.env` in `C:\FINESIII\data\backups` instead of next to `.env`.

## 12. Step 5: Prepare the RDS connection

> **In plain words.** Before the database is created, three things are confirmed: the AWS certificate bundle is present, the server can reach the database, and the database administrator's own pgAdmin connection is encrypted the same way.

**Who does this:** Server team (as the bot account), Database administrator (pgAdmin).

*Signed in as: **the bot account**, for this step and the next two. Window: a bot window (normal, not as administrator).*

First confirm that the window sees the data folder:

```powershell
$env:FINESIII_DATA_DIR
```

`[OK]` `C:\FINESIII\data`.
`[NG]` Blank: the window was opened before step 3 finished, or the bot was signed in during step 3. Sign the bot out and in again, and open a fresh window.

### 12.1 The certificate bundle

The bundle lets the application check that it is really talking to your RDS instance (`verify-full`). The package contains the current AWS global bundle, which covers every RDS and Aurora certificate authority.

```powershell
(Select-String -Path 'C:\FINESIII\app\certs\rds-global-bundle.pem' -Pattern 'BEGIN CERTIFICATE').Count
```

`[OK]` A number above 100.
`[NG]` An error or 0: copy the `certs` folder from the package again and repeat the checksum check of step 2.

### 12.2 Test the network path

```powershell
Resolve-DnsName <rds-endpoint>
Test-NetConnection -ComputerName <rds-endpoint> -Port 5432
```

**Sample (QA):**

```powershell
Resolve-DnsName rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com
Test-NetConnection -ComputerName rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com -Port 5432
```

`[OK]` The name resolves to a private address, and **TcpTestSucceeded : True**.
`[NG]` "Name resolution ... failed" or **TcpTestSucceeded : False**: the security group, a firewall, routing or DNS blocks the server. Do not continue; see section 22.4.

### 12.3 Check the connection in pgAdmin

*Done by the database administrator, in pgAdmin, signed in as the master user.*

pgAdmin runs under the database administrator's own Windows account, which cannot read the application folder. Give pgAdmin its own copy of the bundle, in an administrator window of that account:

```powershell
Copy-Item 'C:\FINESIII\app\certs\rds-global-bundle.pem' "$env:USERPROFILE\Documents\rds-global-bundle.pem"
```

1. In pgAdmin, right-click the RDS server, choose **Properties**, and on the connection parameters set **SSL mode** to `verify-full` and **Root certificate** to the copied file. The host name must be the RDS endpoint **name**, not an IP address. Save and reconnect.
2. Open **Query Tool** on the `postgres` database and run:

```sql
SHOW rds.force_ssl;
SELECT version();
SELECT ssl, version, cipher FROM pg_stat_ssl WHERE pid = pg_backend_pid();
```

`[OK]` `rds.force_ssl` is `1` (or `on`), the engine version is 13 or later, and `ssl` is `true` with a version such as `TLSv1.3`.
`[NG]` `rds.force_ssl` is `0`: the database administrator sets it to `1` in the instance's parameter group before go-live.

## 13. Step 6: Create the database

> **In plain words.** One command creates everything the application needs on RDS, with only the rights it needs, and proves it works. The database administrator types the master password once; it is never stored. At the end, the script shows a one-time password for the first console administrator.

**Who does this:** Server team (as the bot account), Database administrator (types the master password).

*Signed in as: the bot account. Window: the bot window of step 5.*

### 13.1 Recommended: the one-command Amazon RDS mode

```powershell
cd C:\FINESIII\app
.\.venv\Scripts\python.exe Setup_Database.py --rds --host <rds-endpoint> --admin-login <master-user> --audit-database finesiii_audit
```

**Sample (QA):**

```powershell
cd C:\FINESIII\app
.\.venv\Scripts\python.exe Setup_Database.py --rds --host rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com --admin-login dbadmin --audit-database finesiii_audit
```

| Part of the command | Meaning |
|---|---|
| `--rds --host <rds-endpoint>` | The endpoint alone, as shown in the AWS console: no `postgresql://`, no login, no port. Every address is built from it. |
| `--admin-login <master-user>` | The RDS master user, for this run only. Without this option the script uses the name `dbadmin`. |
| `--audit-database finesiii_audit` | Also creates the audit database and switches the audit trail to it. Without it, the audit trail stays in the local file `C:\FINESIII\data\finesiii_audit.db` (see "Where the audit trail is kept" below). |
| (defaults) | Application login `finesiii_app`, application database `finesiii_v3`, port 5432, `--tls verify-full` with `C:\FINESIII\app\certs\rds-global-bundle.pem` |

**What it asks.** One prompt: **Password of '<master-user>' at <rds-endpoint> (not shown, Enter for none):**. The database administrator pastes the current master password from the organisation's password vault. It is used for this run only and never stored, so it can be rotated afterwards.

**Sample (QA):** **Password of 'dbadmin' at rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com (not shown, Enter for none):**

**What it does.** The password of the application login is **generated** (32 letters and digits), stored at once in the bot account's Credential Manager, and never shown. Each report line is marked **OK**, **CREATED**, **INFO**, **WARN** or **FAIL**:

| Step shown | What happens | Good result |
|---|---|---|
| 1/8 Address | Builds and checks the three addresses; checks the certificate bundle; names the settings file | **Certificate bundle**: ... (N certificates); **Settings file**: the address will be written to `C:\FINESIII\app\.env` |
| 2/8 Network | Opens a connection to the endpoint on port 5432 | **reachable** |
| 3/8 Sign-in | Signs in as the master user; reports the server type, version and encryption | **Server type: Amazon RDS for PostgreSQL** (or Aurora); **Connection: encrypted (TLS), the server's certificate and name checked** |
| 4/8 Login and database | Generates and stores the application password; creates the login `finesiii_app` (no administrative rights) and the database `finesiii_v3` in UTF8 | **generated and kept in the credential store of <DOMAIN>\<bot-account> (never shown)**; **created** |
| 5/8 Tables | Creates the six tables `request_queue`, `transaction_history`, `app_users`, `app_sessions`, `app_roles`, `app_settings`, owned by the master user | **created** |
| 6/8 Rights of the application login | The queue may be read, added to and changed, never deleted; the history only read and added to; the console tables fully. The new database is closed to the other logins of the server. | **Rights of 'finesiii_app'**: request_queue read/add/change; transaction_history read/add; console tables full |
| 7/8 Verification as the application login | Signs in as `finesiii_app`, measures the time per database call, writes test rows, reads them and takes them back, then runs the application's own readiness check | **Protection of the history: enforced by the database**; **Write test**: rows written, read and taken back; **Application readiness check: passed** |
| Audit database | Creates `finesiii_audit`, the `audit` schema and the audit table. The application may add and read audit events, never change or delete them. | **Protection of the audit events: enforced by the database** |
| 8/8 Settings file | Records the database lines in `.env`; the passwords stay in Credential Manager | **Password: stored in the credential store of ... (not in a file)**; **Settings file**: ... DATABASE_ENGINE, DATABASE_URL, AUDIT_ENABLED, AUDIT_BACKEND, AUDIT_DATABASE_URL |
| Console administrator | Creates the one-time password of the first console administrator | **CREATED** ... shown once below |

**Sample (QA):** step 4/8 reads **generated and kept in the credential store of R6-CORE\prvrnel (never shown)**.

`[OK]` The run ends with **READY.**, exit code 0, and **Next: start the application**. A second run reports the same lines as OK, "left unchanged".
`[NG]` **NOT READY** (exit code 1) or **READY, with warnings** (exit code 2): read the FAIL and WARN lines of the summary; section 22.4 lists each message. Correct the cause and run the same command again: the script adds only what is still missing.

The full report is saved as `C:\FINESIII\data\logs\setup_database_<date>_<time>.log`. It never contains a password.

**Where the audit trail is kept.** Decide this before step 6 and record it on the worksheet.

| Case | What happens |
|---|---|
| `--audit-database finesiii_audit` given (recommended, this guide) | The audit events go to `finesiii_audit` on RDS. The application may add and read them, never change or delete them; RDS backups cover them. |
| Option left out | The audit events go to the local file `C:\FINESIII\data\finesiii_audit.db`. Include the data folder in the server backup (section 20.1). |
| Switched to the audit database later (the same command with `--audit-database` added, section 20.3 order) | New events go to `finesiii_audit` from the next start. The events already in the local file stay in that file: they are not copied. Keep the file with the server backup for the agreed retention. |

### 13.2 The one-time console administrator password

On a database with no console accounts yet, the script ends with a box like this:

```
  -----------------------------------------------------------------
   Console administrator : admin
   Initial password      : Kx7q-Pm3d-Ty8w-Rn2a
   Shown only now. Sign in to the console after the first
   start and choose your own password; this one is then
   removed from the credential store.
  -----------------------------------------------------------------
```

The password above is an example. The real one is four groups of four letters and digits. It is shown only on the screen, never in the report or the log file.

> **Important.** Write it down or keep it in the password vault at once; step 7 needs it. It is kept in the bot account's Credential Manager until the administrator chooses their own password at the first sign-in. Do **not** start the optional test instance of Part D before that first sign-in (Part D explains why).

| Situation | What to do |
|---|---|
| You prefer to type the initial password yourself | Add `--console-admin ask`. You type it twice (at least 12 characters, with a letter and a digit, not containing the user name). |
| You do not want a one-time password | `--console-admin skip`. The first start then creates `admin` with the published default password `ChangeMe!2026`, which must be changed at once. |
| The one-time password was lost **before the first start** | Run the same command with `--new-admin-password` added. It replaces the stored password while the console has no accounts. |
| It was lost **after the first start** | As the bot account: `.\.venv\Scripts\python.exe desktop\app.py --reset-console-password admin` (section 22.7) |
| The script reports **no credential store for this account** | It was not run as the bot account in a normal sign-in. `admin` would get the published default password `ChangeMe!2026`; run the script again correctly instead. |

### 13.3 Check first (optional)

To see what the script would do without changing anything, add `--check-only`:

```powershell
.\.venv\Scripts\python.exe Setup_Database.py --rds --host <rds-endpoint> --admin-login <master-user> --audit-database finesiii_audit --check-only
```

**Sample (QA):**

```powershell
.\.venv\Scripts\python.exe Setup_Database.py --rds --host rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com --admin-login dbadmin --audit-database finesiii_audit --check-only
```

On an instance where nothing exists yet, this ends with **NOT READY** because the login and database are reported as missing. That is expected; the run without `--check-only` creates them. On an installed system it confirms that everything is in place.

### 13.4 Other ways to create the database

**A. The address form.** Use it when the database team wants to choose the application password, or uses other names. The addresses are written out in full; the `&` is safe inside single quotes:

```powershell
.\.venv\Scripts\python.exe Setup_Database.py 'postgresql://finesiii_app@<rds-endpoint>:5432/finesiii_v3?sslmode=verify-full&sslrootcert=C:/FINESIII/app/certs/rds-global-bundle.pem' --admin-url 'postgresql://<master-user>@<rds-endpoint>:5432/postgres?sslmode=verify-full&sslrootcert=C:/FINESIII/app/certs/rds-global-bundle.pem' --audit-url 'postgresql://finesiii_app@<rds-endpoint>:5432/finesiii_audit?sslmode=verify-full&sslrootcert=C:/FINESIII/app/certs/rds-global-bundle.pem'
```

**Sample (QA):**

```powershell
.\.venv\Scripts\python.exe Setup_Database.py 'postgresql://finesiii_app@rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com:5432/finesiii_v3?sslmode=verify-full&sslrootcert=C:/FINESIII/app/certs/rds-global-bundle.pem' --admin-url 'postgresql://dbadmin@rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com:5432/postgres?sslmode=verify-full&sslrootcert=C:/FINESIII/app/certs/rds-global-bundle.pem' --audit-url 'postgresql://finesiii_app@rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com:5432/finesiii_audit?sslmode=verify-full&sslrootcert=C:/FINESIII/app/certs/rds-global-bundle.pem'
```

It asks for two passwords: the master user (this run only) and the application login (a new login is created with it; an existing login must be given its current password). Add `--app-password generate` to have the application password generated instead. The steps and results are the same as in 13.1. `sslmode=verify-full` encrypts the connection and checks that the certificate belongs to this endpoint. The one-command mode also adds a connection time limit, keep-alive checks and the session name `finesiii-rpa`, which the address form does not.

**B. The database administrator creates the objects in pgAdmin.** For a database team that does not want to type the master password at the bot's keyboard. In this form the application login is named `finesiii`, because the shipped table script grants its rights to that name.

1. **Login.** Right-click **Login/Group Roles**, **Create › Login/Group Role...**, **Name** `finesiii`; on **Definition** enter a password; on **Privileges** only **Can login?** is on.
2. **Databases.** Right-click **Databases**, **Create › Database...**: `finesiii_v3`, then `finesiii_audit`, each with **Encoding** `UTF8` and **Template** `template0`. Leave the master user as owner.
3. **Tables.** On `finesiii_v3` open **Query Tool**, open `scripts\schema.sql` from the package with **Open File**, run it, then run:

```sql
REVOKE CONNECT ON DATABASE finesiii_v3 FROM PUBLIC;
GRANT CONNECT ON DATABASE finesiii_v3 TO finesiii;
GRANT USAGE ON SCHEMA public TO finesiii;
```

4. **Audit table.** On `finesiii_audit` open **Query Tool**, open `scripts\audit_schema.sql`, run it, then run:

```sql
REVOKE CONNECT ON DATABASE finesiii_audit FROM PUBLIC;
GRANT CONNECT ON DATABASE finesiii_audit TO finesiii;
GRANT USAGE ON SCHEMA audit TO finesiii;
GRANT SELECT, INSERT ON audit.audit_events TO finesiii;
GRANT SELECT ON audit.error_events TO finesiii;
```

5. **Verify and record**, as the bot account, without the master user. The database administrator types the password of `finesiii` at the prompt:

```powershell
.\.venv\Scripts\python.exe Setup_Database.py 'postgresql://finesiii@<rds-endpoint>:5432/finesiii_v3?sslmode=verify-full&sslrootcert=C:/FINESIII/app/certs/rds-global-bundle.pem' --audit-url 'postgresql://finesiii@<rds-endpoint>:5432/finesiii_audit?sslmode=verify-full&sslrootcert=C:/FINESIII/app/certs/rds-global-bundle.pem'
```

**Sample (QA):**

```powershell
.\.venv\Scripts\python.exe Setup_Database.py 'postgresql://finesiii@rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com:5432/finesiii_v3?sslmode=verify-full&sslrootcert=C:/FINESIII/app/certs/rds-global-bundle.pem' --audit-url 'postgresql://finesiii@rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com:5432/finesiii_audit?sslmode=verify-full&sslrootcert=C:/FINESIII/app/certs/rds-global-bundle.pem'
```

`[OK]` **READY**; step 4/8 shows **Login and database: used as they are (no administrator address)**, and the history is reported as protected because the master user owns the tables.

The SQL script set under `Technical Documentation\Database_Setup_Scripts` uses psql commands and cannot run in pgAdmin's Query Tool; see the Database Setup Guide.

### 13.5 Check the database the way the service will

```powershell
.\.venv\Scripts\python.exe desktop\app.py --check-db
```

`[OK]` **Database** (the address without a password), **Engine : postgres**, **Server : PostgreSQL ...**, **User : finesiii_app**, **Result : OK**, exit code 0.
`[NG]` **Result : FAILED**: the **Error** and **Hint** lines name the cause (section 22.4).
`[NG]` **Engine : sqlite**: the command did not run in `C:\FINESIII\app`. Run `cd C:\FINESIII\app` first.

### 13.6 All options of Setup_Database.py

| Option | Use |
|---|---|
| `<address>` (first value) | The address the application uses: `postgresql://<login>@<host>:5432/<database>` |
| `--admin-url <address>` | The administrator's address, used only to create the login, databases, tables and rights |
| `--audit-url <address>` | Also prepares the audit database and switches the audit trail to it |
| `--rds` | Amazon RDS or Aurora mode: only `--host` is given, the addresses are built |
| `--host <endpoint>` | With `--rds`: the endpoint |
| `--port <number>` | With `--rds`: the port (default 5432) |
| `--admin-login <login>` | With `--rds`: the administrator login (default `dbadmin`) |
| `--app-login <login>` | With `--rds`: the application login, created when missing (default `finesiii_app`) |
| `--database <name>` | With `--rds`: the application database (default `finesiii_v3`) |
| `--audit-database <name>` | With `--rds`: also prepares this audit database |
| `--tls verify-full` or `--tls require` | With `--rds`: `verify-full` (default) checks the server's certificate and name; `require` only encrypts, for an endpoint reached through another name, such as an alias |
| `--ca-bundle <file>` | With `--rds`: another certificate bundle (default `C:\FINESIII\app\certs\rds-global-bundle.pem`) |
| `--app-password ask` or `generate` | The password of a new application login: typed, or generated and stored without being shown. `generate` is the default with `--rds` and needs an administrator. |
| `--set-password` | Gives an existing application login a new password: a generated one (with `--rds`) or the one you type. Needs an administrator. While the database password comes from CyberArk (section 13.7) the script warns (**WARN Password: the bot copies the administrator's password from CyberArk to the application login (CYBERARK_DB_ENABLED); the password set now is replaced at its next check**). While that option is on, every re-run of the script needs this option (section 13.7, the safe order). |
| `--admin-password-from-cyberark` | Reads the administrator's password from CyberArk (the CyberArk database settings of section 13.7, also while **Database password from CyberArk** is still Off) instead of asking for it. CyberArk must return the same login as the administrator login of the run. It supplies the administrator's password only, not the password of `finesiii_app`. |
| `--fix-ownership` | Hands tables owned by the application login to the administrator; the rows are kept. Needs an administrator. |
| `--check-only` | Validates only; creates and changes nothing |
| `--no-save` | Does not write the settings file |
| `--password-store auto`, `vault` or `env-file` | Where the application password is kept. `auto` (default) uses the bot account's Credential Manager. `env-file` writes it into the settings file after a typed `YES` and restricts the file; not recommended. |
| `--console-admin generate`, `ask` or `skip` | The first console administrator's one-time password (section 13.2) |
| `--new-admin-password` | Replaces a lost one-time password while the console has no accounts |
| `--env-file <file>` | Another settings file (default `C:\FINESIII\app\.env`; without a `.env`, the machine settings file `C:\FINESIII\data\finesiii.env`) |
| `--timeout <seconds>` | Connection time limit (default 10) |
| `--no-prompt` | Never asks at the keyboard, for scripted runs. Not used in this guide. |
| `--help` | Shows every option |

### 13.7 Optional: database password from CyberArk

> **In plain words.** In some organisations the PAM team keeps the database administrator login in CyberArk, and CyberArk's password manager (CPM) changes its password regularly. The bot can then follow those changes by itself. It reads the administrator's password from CyberArk and gives its own login, `finesiii_app`, the same password. Nobody types or stores a database password. Skip this section when the database password is handled as in section 20.4.

**Who does this:** PAM / CyberArk team (the CyberArk details), Database administrator (the administrator's rights), Developer (the console settings), Server team (the certificate file).

*When: after step 8, once the service runs in the background, or at any later time. Steps 6 to 8 are done first as described, with the master password typed at the prompt (or read from CyberArk, see the tip under "The safe order"). Once this option is on, every later run of the database script follows "The safe order" below.*

**When to use it.**

| Use it when | Do not use it when |
|---|---|
| The PAM team vaults the database administrator login (`<admin login>`, usually the RDS master user) in CyberArk and CPM rotates its password | The database password is changed by hand on an agreed date (section 20.4) |
| The organisation does not want a database password kept in the bot account's Credential Manager | CyberArk cannot be reached from this server on port 443 |

**How it works.**

- The bot never works as the administrator. It keeps working as `finesiii_app`; **Database URL** keeps naming `finesiii_app`, with no password in it. The application login keeps its limited rights; only its password becomes the same as the administrator's.
- At every start, and then every 15 minutes (**CyberArk check interval (minutes)**), the bot asks CyberArk's Central Credential Provider (CCP) for the administrator's password. When `finesiii_app` does not accept it, the bot signs in once as the administrator and gives `finesiii_app` the same password. Only the encrypted form (a SCRAM-SHA-256 verifier) is sent, so the password never appears in the database's statement log.
- A refused sign-in makes the bot ask CyberArk at once (at most once a minute). While CPM is changing the password, CyberArk reports "password change in process" and the bot asks again after a minute.
- Requests in progress are not affected by a rotation: open connections continue, new connections use the new password, and a refused connection is tried once more with the newest password.
- At start the service waits up to 5 minutes for the password. Without it the service does not start: `agent.log` shows **[FATAL] The service did not start: ...**, and the launcher starts it again after 60 seconds.
- Each new password taken into use is announced once by the e-mail **Database password changed: the bot uses the new password** (on by default; there is no setting for it).
- When CyberArk does not answer, the bot keeps the password in use and requests continue; it sends one **CyberArk not available: the database password could not be checked** e-mail, then a recovery e-mail. When giving a new password to `finesiii_app` fails 3 times in a row, it sends **Database password not updated: the bot keeps working with the password in use**; requests continue with the password in use, and the next good check ends the problem by itself, with the e-mail **Database password updated: the bot uses the current password from CyberArk**.
- When the password of `finesiii_app` was changed outside CyberArk, the bot sets it back to the password in CyberArk and sends **Bot's database login set back to the password in CyberArk**.
- The password is never shown, logged, e-mailed or written to a file. The Credential Manager of the bot account keeps the password stored at installation; it is no longer the password of `finesiii_app` once the bot has copied the password from CyberArk (this matters for the database script, see "The database script while this option is on" below).

**What to ask the PAM / CyberArk team.** Write the values on the worksheet (item 15); never the password.

| Ask for | Placeholder | Goes into |
|---|---|---|
| The CCP address, up to the host name only (no `/AIMWebService` path, no trailing slash, https) | `https://<ccp-address>` | **CyberArk address (database)** |
| The CCP Application ID allowed to read the administrator account **from this server** | `<application ID>` | **CyberArk Application ID (database)** |
| The safe that holds the administrator account | `<safe>` | **CyberArk safe (database)** |
| The full object name of the administrator account, copied exactly | `<account object>` | **CyberArk object (database)** |
| The user name CyberArk returns for that account | `<admin login>` | **Database administrator login** |
| Whether the CCP certificate is issued by the company's own certificate authority | - | **CyberArk certificate file (internal certificate authority)** |
| Written agreement that the bot copies the administrator's password to its own login | - | The change record |

**Sample (QA):** CCP address `https://pamccp.aig.net`; Application ID `APP-10-SAILPOINT` (shared with SailPoint in QA; confirm with the PAM team whether production gets its own); safe `BADM_DBADMIN-ISO-POSTGRESQL`; object `Database---rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com---sailpoin1002---5432--dbadmin` (the database `sailpoin1002` named inside the object is not the bot's database; the bot's database stays `finesiii_v3`); user name `dbadmin`; CCP certificate issued by the company's own authority, bundle file `C:\FINESIII\certs\aig-ca-bundle.pem`.

The database administrator confirms that `<admin login>` may connect to `finesiii_v3` and change the password of `finesiii_app` (on Amazon RDS the master user normally has this right). The address and port CyberArk holds for the account are not used: the bot always uses **Database URL**, and only notes a difference once in the service log.

**The settings.** *Settings › This machine › Database, signed in as a Developer.* These are machine settings: they are read before the database opens and apply at the next start, or with **Save and restart**. The console keeps them in the machine settings file `C:\FINESIII\data\finesiii.env`, or changes them in `C:\FINESIII\app\.env` when that file already holds the line (Appendix B).

| Setting | What it means | Default | Who can change it | Takes effect |
|---|---|---|---|---|
| **Database password from CyberArk** | On: the bot reads the administrator's password from CyberArk and keeps `finesiii_app` on the same password. Off: the password in the bot account's Credential Manager is used. Switch it on only after **Test CyberArk retrieval** passes. | Off | Developer | **Save and restart** |
| **CyberArk address (database)** | `https://<ccp-address>`. **Required** while **Database password from CyberArk** is on: the bot reads it at start, before the console's other CyberArk settings are loaded. | Empty | Developer | **Save and restart** |
| **CyberArk Application ID (database)** | `<application ID>`. **Required** while **Database password from CyberArk** is on. | Empty | Developer | **Save and restart** |
| **CyberArk safe (database)** | `<safe>` | Empty | Developer | **Save and restart** |
| **CyberArk object (database)** | `<account object>` | Empty | Developer | **Save and restart** |
| **Database administrator login** | `<admin login>`: must be the user name CyberArk returns | `dbadmin` | Developer | **Save and restart** |
| **Audit database uses the same password** | The audit database signs in with the same password | On | Developer | **Save and restart** |
| **CyberArk check interval (minutes)** | How often the bot asks CyberArk whether the password changed (1 to 1440) | 15 | Developer | **Save and restart** |
| **CyberArk certificate file (internal certificate authority)** | A PEM file of the certificate authorities that issued the CyberArk certificate. Used for every CyberArk call: the database password and the Fujitsu Mainframe and Fujitsu RACF passwords. Empty: the built-in list of public authorities. | Empty | Developer | **Save and restart** |

**Sample (QA):** **CyberArk address (database)** `https://pamccp.aig.net`; **CyberArk Application ID (database)** `APP-10-SAILPOINT`; **CyberArk safe (database)** `BADM_DBADMIN-ISO-POSTGRESQL`; **CyberArk object (database)** `Database---rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com---sailpoin1002---5432--dbadmin`; **Database administrator login** `dbadmin`; **CyberArk certificate file (internal certificate authority)** `C:/FINESIII/certs/aig-ca-bundle.pem`.

**Database URL** and **Database engine** stay as the database script wrote them: the engine is `postgres`, the login in the address is `finesiii_app` (not `<admin login>`), and the address holds no password. **Verify TLS certificate** (Settings › CyberArk) stays On: the bot never reads a password over a connection whose certificate is not checked.

**The internal certificate bundle.** When CyberArk uses a certificate of the company's own certificate authority, the browser on the server trusts it, but the bot does not, because it checks certificates against its own built-in list. **Test CyberArk retrieval** then answers **CyberArk did not deliver the account: CyberArk availability check failed (Inactive) — fetch skipped: ... certificate verify failed ...**. To fix it:

1. Next to **CyberArk certificate file (internal certificate authority)**, click **Create from Windows certificates**. It writes the certificate authorities this server trusts to `C:\FINESIII\data\certs\cyberark-ca-bundle.pem` and puts that path in the field (not saved yet). `[OK]` **Created C:/FINESIII/data/certs/cyberark-ca-bundle.pem with N certificates from the Windows trusted store. Save and restart to use it.**
2. Run **Test CyberArk retrieval** again; it uses the path on the page before it is saved.
3. **Save and restart.** The save is refused when the file does not exist, cannot be read or holds no certificate.

`[NG]` The Windows store does not hold the company's authority: open the CCP address in the browser on the server, padlock, **Certificate**, **Certification Path**, export the root and each intermediate certificate as **Base-64 encoded X.509 (.CER)**, paste them one after another into one file, for example `C:\FINESIII\certs\cyberark-ca-bundle.pem` (outside the application folder, so that updates do not replace it; readable by the bot account), and enter that path in the field.

**Set it up and test.** *Settings › This machine › Database, signed in as a Developer.*

1. Check **Database engine** (`postgres`) and **Database URL** (`finesiii_app`, no password), and run **Test connection** on **Database URL**.
2. Fill in the CyberArk settings from the table above. Leave **Database password from CyberArk** Off.
3. Click **Test CyberArk retrieval** (next to **CyberArk object (database)**). It uses the values on the page before they are saved and never shows the password.
   - `[OK]` **CyberArk delivered the account <admin login> (<rds-endpoint>:5432), CPM status .... The password is not shown.**
     - **Sample (QA):** **CyberArk delivered the account dbadmin (rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com:5432), CPM status .... The password is not shown.**
   - `[NG]` Any other answer: correct the value it names (section 22.9) and test again.
4. Switch **Database password from CyberArk** On and click **Save and restart**. The save is refused, with the reason and **Nothing was saved.**, when a value would stop the service from starting: for example **Database password from CyberArk: enter CyberArk address (database); enter CyberArk Application ID (database). Nothing was saved.**, or a password in **Database URL**. The restart first reads the password from CyberArk and applies it.
   - `[OK]` The service comes back; the service log shows **Database password copied from <admin login> to finesiii_app** (the first time only) and **Database password from CyberArk (<admin login>), in use for finesiii_app**. The default recipients (and the **Database team**, when its addresses are set) receive **Database password changed: the bot uses the new password**, with **Found by: Service restart from the console**.
     - **Sample (QA):** **Database password copied from dbadmin to finesiii_app** and **Database password from CyberArk (dbadmin), in use for finesiii_app**.
   - `[NG]` **Not restarted: the database password from CyberArk could not be obtained: <reason>. The service keeps running as it was.** Nothing was changed; correct the reason (section 22.9) and click **Save and restart** again.
5. On the **System** page, the **Database password** card shows the status **Latest password from CyberArk** and these lines (the card names no login):
   - **Password in use: the latest from CyberArk, in use since ... JST.**
   - **Changed in CyberArk: ... JST** (when CyberArk reports the time of the last change);
   - **Last successful check: ... JST (every 15 min)**;
   - **Next check: ... JST** (the scheduled check, or the check a minute after a failure);
   - **Last attempt failed: ... JST** and the problem in plain words, only when there is one.
6. Click **Validate database password** in the row of buttons at the top of the **System** page (Admin or Developer; the button of the same name next to **Database URL** does the same). Every click is recorded in the audit trail. A second click within 30 seconds is answered **A check ran a moment ago; try again in N seconds.**
   - `[OK]` **Password validated. The bot uses the latest password from CyberArk.**, or, when CyberArk had a newer one, **Password validated and updated. The bot now uses the latest password from CyberArk; new connections use it.**
   - `[NG]` **CyberArk is changing the password right now. The bot keeps using the password it has until the change is finished; try again in a minute.**: CPM is rotating it; wait a minute. **Not checked: ...**, **The password could not be checked with the database: ...** or **The new password from CyberArk could not be applied: ...**: the reason follows (section 22.9).
7. Let one request run, and check that `desktop\app.py --check-db` still shows **Result : OK** (one-off commands read the password from CyberArk once).
8. On **Settings › E-mail**, the section **E-mail samples** shows the database password e-mails for review with the database team: **Database password changed (support and database team)**, **Database password set back (support and database team)**, and the **System not available (system team)** and **System recovered (system team)** samples of **Database password** and **CyberArk (database password)**.
9. With the PAM team, optionally prove a rotation: set **CyberArk check interval (minutes)** to `1`, **Save and restart**, let PAM change the password in CyberArk, and within about a minute see **Changed in CyberArk** move on the card and the e-mail **Database password changed: the bot uses the new password** arrive (**Found by: Scheduled check**), while requests keep working. Set the interval back to `15` and **Save and restart**.

**What a rotation looks like after installation.** Nothing is done on the server. CPM changes the administrator's password in CyberArk on its schedule; the bot notices it at its next check and gives `finesiii_app` the same password. The **Bot's database login** row of the e-mail says **Given the new password** (the bot changed it) or **Already accepted the new password**.

| Case | What happens |
|---|---|
| CPM rotates the password; CyberArk and the database answer | Within one check interval (15 minutes by default) the bot uses the new password. Requests in progress continue; new connections use the new password. E-mail **Database password changed: the bot uses the new password**, **Found by: Scheduled check**. Audit event `database_password_changed`. |
| The database refuses a sign-in before the scheduled check | The bot asks CyberArk at once (at most once a minute) and takes the new password into use. The same e-mail, **Found by: Check after the database refused a sign-in**. One database action at that moment may fail once and is tried again with the newest password. |
| The password changes while the bot is stopped | At the next start the bot gives `finesiii_app` the current password before it opens the database. The same e-mail, **Found by: Bot start**. |
| CyberArk reports "password change in process" | The bot keeps the password it has and asks again a minute later. The card shows **Previous password in use** until the change is finished. |
| CyberArk does not answer | Requests continue with the password in use. The card shows **CyberArk not reachable**; e-mail **CyberArk not available: the database password could not be checked** to the CyberArk / identity team and the default recipients, then a recovery e-mail. Audit events `database_password_cyberark_unavailable` and `database_password_cyberark_recovered`. If the database stops accepting the password in use before CyberArk answers again, processing stops. |
| The new password cannot be given to `finesiii_app` (3 attempts, about 3 minutes) | Requests continue with the password in use. E-mail **Database password not updated: the bot keeps working with the password in use** to the **Database team** and the default recipients; audit event `database_password_update_failed`. The next good check ends it by itself: **Database password updated: the bot uses the current password from CyberArk** with a **Found by** row; audit event `database_password_update_recovered`. |
| Someone changed the password of `finesiii_app` by hand | The bot sets it back to the password in CyberArk and continues. E-mail **Bot's database login set back to the password in CyberArk** (warning); audit event `database_password_reapplied`. The database team checks who changed it. |

The audit trail (category **system**, actor **system** for the bot's own checks) also records `database_password_in_use` at each start and `database_password_validated` with the administrator's name at each click on **Validate database password**. The e-mails never contain the password.

**Common problems.**

| What you see | Likely cause | What to do |
|---|---|---|
| `[NG]` **... certificate verify failed ...** | The CCP certificate comes from the company's own authority | The internal certificate bundle, above |
| `[NG]` **CyberArk delivered the account <name>, not <admin login>: check the object name.** | Wrong object, or **Database administrator login** differs from the user name in CyberArk | Copy the object again, or correct the login |
| `[NG]` An answer with **403** (for example **APPAP227E**) | Access denied: the Application ID may not read the account from this server | The PAM team allows this server for the Application ID |
| `[NG]` An answer with **404**, or the object is not found | Safe or object misspelt, or the Application ID is not a member of the safe | Copy both again; the PAM team checks the safe's members |
| `[NG]` **CyberArk is changing the password right now** | Password change in process (CPM) | Wait a minute; the bot asks again by itself |
| `[NG]` **Database password from CyberArk: DATABASE_URL contains a password ...** or **... must name the application login, not <admin login>** | **Database URL** changed by hand | Keep the address the database script wrote (section 20.3) |

**Sample (QA):** in these messages `<admin login>` reads `dbadmin`, for example **CyberArk delivered the account <name>, not dbadmin: check the object name.**

**Without the console.** When the server team prefers to keep these lines in the settings file, they can be added to `C:\FINESIII\app\.env` in an administrator window with Notepad. The console then shows them and changes them in place. Keep `CYBERARK_DB_ENABLED=false` until **Test CyberArk retrieval** passes, then switch it on and restart the service:

```
CYBERARK_DB_ENABLED=false
CYBERARK_DB_BASE_URL=https://<ccp-address>
CYBERARK_DB_APP_ID=<application ID>
CYBERARK_DB_SAFE=<safe>
CYBERARK_DB_OBJECT=<account object>
DATABASE_ADMIN_LOGIN=<admin login>
CYBERARK_DB_FOR_AUDIT=true
CYBERARK_DB_REFRESH_MINUTES=15
CYBERARK_CA_BUNDLE=C:/FINESIII/data/certs/cyberark-ca-bundle.pem
```

**Sample (QA):** the same lines with the QA values (the QA certificate file is kept in `C:\FINESIII\certs`, not in the data folder):

```
CYBERARK_DB_ENABLED=false
CYBERARK_DB_BASE_URL=https://pamccp.aig.net
CYBERARK_DB_APP_ID=APP-10-SAILPOINT
CYBERARK_DB_SAFE=BADM_DBADMIN-ISO-POSTGRESQL
CYBERARK_DB_OBJECT=Database---rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com---sailpoin1002---5432--dbadmin
DATABASE_ADMIN_LOGIN=dbadmin
CYBERARK_DB_FOR_AUDIT=true
CYBERARK_DB_REFRESH_MINUTES=15
CYBERARK_CA_BUNDLE=C:/FINESIII/certs/aig-ca-bundle.pem
```

The last line is needed only with the internal certificate bundle. None of these lines is a password.

**The database script while this option is on.** Once the CyberArk database settings are in place, `Setup_Database.py` can read the administrator's password from CyberArk instead of asking for it (`--admin-password-from-cyberark`, with `--admin-login <admin login>`); **Administrator password: read from CyberArk for '<admin login>' (not shown)** confirms it (**Sample (QA):** `--admin-login dbadmin`; **Administrator password: read from CyberArk for 'dbadmin' (not shown)**). That option supplies only the administrator's password. For `finesiii_app` the script uses the password kept in the bot account's Credential Manager, which is the password stored at installation, not the one the bot copied from CyberArk.

| Case | What happens |
|---|---|
| `Setup_Database.py` run again without `--set-password` while the option is on (also with `--admin-password-from-cyberark`, also with `--check-only`) | `[NG]` Step **7/8 Verification as the application login** fails: **Sign-in as 'finesiii_app'**: ... **The login 'finesiii_app' exists with another password. Use the password it has, or run the script again with --set-password to give it the one you typed.** The run ends **NOT READY**; the settings file is not written. Nothing is damaged. |
| `scripts\setup_rds_database.py` while the option is on | `[NG]` Its first run (the check) fails in the same way, and the tool stops: **Correct the FAIL lines above and run this script again. Nothing was changed.** Use `Setup_Database.py` in the safe order below instead. |
| `Setup_Database.py` in the safe order below | `[OK]` **READY, with warnings** (the warning about `--set-password` is expected); at its next start the bot gives `finesiii_app` the CyberArk password again. |

**The safe order** for every later run of the database script while the option is on (moving the endpoint 20.3, refreshing the certificate bundle 20.5, adding the audit database 13.1):

1. Pause processing (console, **System › Pause processing**) and let a running request finish.
2. Stop the service, as the bot account:

```powershell
cd C:\FINESIII\app
.\.venv\Scripts\python.exe desktop\app.py --stop
```

3. Run the database script with both options, adding the options of the task (for example `--host <new-rds-endpoint>` or `--ca-bundle <file>`):

```powershell
.\.venv\Scripts\python.exe Setup_Database.py --rds --host <rds-endpoint> --admin-login <admin login> --audit-database finesiii_audit --admin-password-from-cyberark --set-password
```

**Sample (QA):**

```powershell
.\.venv\Scripts\python.exe Setup_Database.py --rds --host rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com --admin-login dbadmin --audit-database finesiii_audit --admin-password-from-cyberark --set-password
```

`[OK]` **Administrator password: read from CyberArk for '<admin login>' (not shown)** (**Sample (QA):** **Administrator password: read from CyberArk for 'dbadmin' (not shown)**), the WARN line **Password: the bot copies the administrator's password from CyberArk to the application login (CYBERARK_DB_ENABLED); the password set now is replaced at its next check**, then **READY, with warnings** (exit code 2). `finesiii_app` now has a freshly generated password, kept in the bot account's Credential Manager; the verification of step 7/8 passes with it.

4. Start the service:

```powershell
Start-ScheduledTask -TaskPath '\AIG\' -TaskName 'FINESIII RPA Agent'
```

`[OK]` At start the bot gives `finesiii_app` the password in CyberArk again: the service log shows **Database password copied from <admin login> to finesiii_app** (**Sample (QA):** **Database password copied from dbadmin to finesiii_app**), and the e-mail **Database password changed: the bot uses the new password** arrives with **Found by: Bot start**. The **Database password** card shows **Latest password from CyberArk**.

5. Check, as the bot account, and resume processing:

```powershell
.\.venv\Scripts\python.exe desktop\app.py --check-db
```

`[OK]` **Result : OK**. Then **System › Resume processing**.

> **Important.** Do not run the script with `--set-password` while the service runs with this option on: the bot's open connections keep working, but the bot sets the login back at its next check and sends **Bot's database login set back to the password in CyberArk**. To check the database without changing anything while the option is on, use `desktop\app.py --check-db`, not `Setup_Database.py --check-only`.

> **Tip. When the master password is only in CyberArk on the day of installation.** The CyberArk database lines can be added to `C:\FINESIII\app\.env` before step 6 (see "Without the console" above, with `CYBERARK_DB_ENABLED=false`), and step 6 then run with `--admin-login <admin login> --admin-password-from-cyberark` instead of typing the password. With a company certificate authority the certificate file must then be created by hand (the `[NG]` line of "The internal certificate bundle"), because the console button is not available before the first start.

**Sample (QA):** step 6 with the administrator's password read from CyberArk:

```powershell
cd C:\FINESIII\app
.\.venv\Scripts\python.exe Setup_Database.py --rds --host rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com --admin-login dbadmin --audit-database finesiii_audit --admin-password-from-cyberark
```

**Going back** to a password of the bot's own, kept in Credential Manager:

1. *Settings › This machine › Database:* switch **Database password from CyberArk** Off and click **Save changes** (not **Save and restart**).
2. Stop the service (`desktop\app.py --stop`, as in the safe order above).
3. As the bot account, give `finesiii_app` a new generated password of its own (section 20.4). `--admin-password-from-cyberark` may still be used to read the administrator's password, because the CyberArk database settings stay in place:

```powershell
.\.venv\Scripts\python.exe Setup_Database.py --rds --host <rds-endpoint> --admin-login <admin login> --audit-database finesiii_audit --admin-password-from-cyberark --set-password
```

**Sample (QA):**

```powershell
.\.venv\Scripts\python.exe Setup_Database.py --rds --host rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com --admin-login dbadmin --audit-database finesiii_audit --admin-password-from-cyberark --set-password
```

`[OK]` **READY.** The WARN line about the CyberArk copy no longer appears, because the option is off.

4. Start the service (`Start-ScheduledTask -TaskPath '\AIG\' -TaskName 'FINESIII RPA Agent'`). The **Database password** card is no longer shown, and the **Dashboard** shows **Database** **Connected**.

Switching the setting off and restarting without step 3 leaves the bot with the password stored at installation, which the database no longer accepts.

## 14. Step 7: First start and verification

> **In plain words.** The service is started once in a visible window so that every start-up message can be read. You run the self-test, sign in to the console for the first time and choose your own password, confirm in pgAdmin that the connection is encrypted, and stop it again.

**Who does this:** Server team (as the bot account), Admin, Database administrator.

*Signed in as: the bot account.*

### 14.1 Start in the foreground

In a bot window:

```powershell
cd C:\FINESIII\app
.\.venv\Scripts\python.exe desktop\app.py --agent
```

`[OK]` The start summary shows:
- **Environment : development (DevelopmentConfig)** - the safe test mode of the starter settings;
- **Driver : simulator (canned executor, no UI — fastest)**;
- **Database : postgres — postgresql://finesiii_app:\*\*\*@<rds-endpoint>:5432/finesiii_v3?...** - the password masked (**Sample (QA):** **Database : postgres — postgresql://finesiii_app:\*\*\*@rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com:5432/finesiii_v3?...**);
- **Audit trail : enabled**, **OCR : enabled**, **Error rules : ...**.

It ends with **Ready — http://127.0.0.1:8000 (pid ...). Running in the background until stopped.** Leave this window open.

`[NG]` A line starting with **[FATAL]** or **[STOP]**: section 22.5.

### 14.2 Self-test

Open a **second** bot window:

```powershell
cd C:\FINESIII\app
.\.venv\Scripts\python.exe desktop\app.py --selftest
$LASTEXITCODE
```

`[OK]` Each line is **OK** or **n/a**, the last line is **result : ALL COMPONENTS USABLE**, and the exit code is 0. **desktop window toolkit: n/a** is normal: the desktop window is not part of this delivery. Loading the screen-reading engine takes up to a minute.
`[NG]` **FAILED** on a line, or **N COMPONENT(S) UNUSABLE** and exit code 1: section 22.6.

### 14.3 First sign-in

In the second window:

```powershell
Start-Process 'http://127.0.0.1:8000/'
```

1. Sign in with **Username** `admin` and the one-time **Password** from step 6.
2. The page **Choose a new password** opens. Enter a **New password** and **Confirm the new password**, then **Set password**. Rules: at least 12 characters, with a letter and a digit, not containing the user name, and not one of the last five passwords. The console signs in again with it.
3. If the page **Set up the modules** opens, choose **Skip for now**. The console administrator completes it later (Administrator Guide).
4. On the **Dashboard**, **Bot service** shows **Running** and **Database** shows **Connected**.
5. On the **System** page, **Warnings** lists **Requests are accepted without an API key...** under **Security:**. This is expected with the simulated terminal right after installation. Once the real terminal driver is chosen, the same notice moves to **Needs attention** under **Security, before production use:** until the machine API key is switched on before production use.

`[OK]` The one-time password is removed from the bot account's Credential Manager the moment you set your own.

The `admin` account holds the **Developer** role: full control, including every setting. Keep it for administration and create a personal account for each person (Administrator Guide).

### 14.4 Confirm the encrypted connection in pgAdmin

*Done by the database administrator, signed in as the master user:*

```sql
SELECT a.datname, a.usename, a.application_name, s.ssl, s.version
FROM pg_stat_activity a JOIN pg_stat_ssl s ON s.pid = a.pid
WHERE a.usename = 'finesiii_app';
```

`[OK]` Rows for `finesiii_v3` and `finesiii_audit`, all with `ssl = true`.

### 14.5 Stop the foreground run

In the second window:

```powershell
.\.venv\Scripts\python.exe desktop\app.py --stop
```

`[OK]` **Asking the agent at http://127.0.0.1:8000 (pid ...) to stop…**, then **Agent stopped.** The first window shows **Stop requested — finishing any transaction in progress, then stopping…** and **Stopped.** Both windows can be closed. (Ctrl+C in the first window stops it the same way.)

## 15. Step 8: Run in the background

> **In plain words.** In daily use no window stays open. A scheduled task starts a small launcher when the bot account signs in; the launcher starts the service without a window and restarts it within a minute if it ever stops unexpectedly.

**Who does this:** Server team.

### 15.1 How it works

```mermaid
flowchart LR
    T["Scheduled task at sign-in of the bot account"] --> L["Launcher, no window"]
    L -->|starts| S["AIG IAM Access RPA service"]
    S -->|output| LOG[("C:\FINESIII\data\logs\agent.log")]
    S -. "stops unexpectedly" .-> L
    L -. "waits 60 seconds, starts it again" .-> S
    OP["--stop, or Stop the bot in the console"] -->|normal stop| S
```

| Part | Role |
|---|---|
| Scheduled task **FINESIII RPA Agent** | Starts the launcher when the bot account signs in, in the bot's own session, with highest privileges. It can also be started on demand. |
| Launcher `Start_FINESIII_Service.pyw` | Runs without a window. Starts the service in the background and waits for it. Exit 0 (a normal stop) or exit 3 (a copy is already running) ends the launcher; any other end is noted in `agent.log` and the service is started again after 60 seconds. |
| The service | The same program as in step 7, without a window. Its output (the start summary and any **[FATAL]** line) goes to `C:\FINESIII\data\logs\agent.log`, shown in the console under **System › Service log › Agent console**. |

> **Tip. Why not a Windows service?** A Windows service runs in an invisible system session. The bot types into the Fujitsu Mainframe terminal window on the bot account's desktop and reads its passwords from the bot account's own Credential Manager, so it must run in the bot account's session. The task and the launcher give the same result: background, automatic start, automatic recovery.

### 15.2 Write the launcher

*Signed in as: server administrator. Window: administrator window.* Copy the whole block, from the line `@'` down to and including the line with `Set-Content`:

```powershell
@'
"""AIG IAM Access RPA - background service launcher (scheduled task)."""
import os
import sys
import time
from datetime import datetime
from pathlib import Path

APP = Path(__file__).resolve().parent
os.chdir(APP)
sys.path.insert(0, str(APP))
os.environ.setdefault("PYTHONIOENCODING", "utf-8")

from desktop import runtime  # noqa: E402

RESTART_DELAY_SECONDS = 60
EXIT_ALREADY_RUNNING = 3


def note(text):
    log = runtime.agent_log_path()
    log.parent.mkdir(parents=True, exist_ok=True)
    with open(log, "a", encoding="utf-8") as f:
        f.write(f"{datetime.now():%Y-%m-%d %H:%M:%S} | LAUNCHER | {text}\n")


while True:
    note("starting the service")
    code = runtime.spawn_agent().wait()
    if code == 0:
        note("the service stopped normally; the launcher ends")
        break
    if code == EXIT_ALREADY_RUNNING:
        note("the service is already running; the launcher ends")
        break
    note(f"the service stopped unexpectedly (exit code {code}); "
         f"starting it again in {RESTART_DELAY_SECONDS} seconds")
    time.sleep(RESTART_DELAY_SECONDS)
'@ | Set-Content -Path 'C:\FINESIII\app\Start_FINESIII_Service.pyw' -Encoding ASCII
Get-Item 'C:\FINESIII\app\Start_FINESIII_Service.pyw' | Select-Object Name, Length
```

`[OK]` `Start_FINESIII_Service.pyw`, about 1 KB.

This launcher file is written on the server, so the checksum check of step 2 ignores it. Keep it during updates and include it in backups. (The package's own copy, `unattended\Start_FINESIII_Service.pyw`, behaves the same and is used only by the unattended options of section 15.8.)

### 15.3 Register the scheduled task

*Same administrator window.* One command over six lines; copy them together:

```powershell
Register-ScheduledTask -TaskPath '\AIG\' -TaskName 'FINESIII RPA Agent' `
  -Action (New-ScheduledTaskAction -Execute 'C:\FINESIII\app\.venv\Scripts\pythonw.exe' -Argument 'Start_FINESIII_Service.pyw' -WorkingDirectory 'C:\FINESIII\app') `
  -Trigger (New-ScheduledTaskTrigger -AtLogOn -User '<DOMAIN>\<bot-account>') `
  -Principal (New-ScheduledTaskPrincipal -UserId '<DOMAIN>\<bot-account>' -LogonType Interactive -RunLevel Highest) `
  -Settings (New-ScheduledTaskSettingsSet -MultipleInstances IgnoreNew -ExecutionTimeLimit ([TimeSpan]::Zero) -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1) -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries) `
  -Description 'AIG IAM Access RPA service (the bot). Starts at sign-in of the bot account.'
```

**Sample (QA):**

```powershell
Register-ScheduledTask -TaskPath '\AIG\' -TaskName 'FINESIII RPA Agent' `
  -Action (New-ScheduledTaskAction -Execute 'C:\FINESIII\app\.venv\Scripts\pythonw.exe' -Argument 'Start_FINESIII_Service.pyw' -WorkingDirectory 'C:\FINESIII\app') `
  -Trigger (New-ScheduledTaskTrigger -AtLogOn -User 'R6-CORE\prvrnel') `
  -Principal (New-ScheduledTaskPrincipal -UserId 'R6-CORE\prvrnel' -LogonType Interactive -RunLevel Highest) `
  -Settings (New-ScheduledTaskSettingsSet -MultipleInstances IgnoreNew -ExecutionTimeLimit ([TimeSpan]::Zero) -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1) -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries) `
  -Description 'AIG IAM Access RPA service (the bot). Starts at sign-in of the bot account.'
```

`[OK]` **Task Scheduler › Task Scheduler Library › AIG** shows **FINESIII RPA Agent** with state **Ready**.
`[NG]` "Cannot create a file when that file already exists": the task exists. Remove it, then register again: `Unregister-ScheduledTask -TaskPath '\AIG\' -TaskName 'FINESIII RPA Agent' -Confirm:$false`

| Setting | Why |
|---|---|
| Program `pythonw.exe` of the application's environment | Runs without a window |
| Start folder `C:\FINESIII\app` | The service reads `.env` from the folder it starts in |
| Interactive, as the bot account | The bot needs its desktop for the terminal window and its Credential Manager for the passwords |
| `-RunLevel Highest` | The service runs as administrator, so that it can operate a terminal started as administrator (the default). In the alternative set-up of section 8, use `-RunLevel Limited`. |
| No time limit, never two copies | The service runs continuously; a second start while it runs is ignored |
| Restart 3 times, 1 minute apart | Covers the rare case that Windows cannot start the launcher. Recovery of the service itself is the launcher's job. |

### 15.4 Start it and close the window

The bot account must be signed in. As the bot account, or as an administrator:

```powershell
Start-ScheduledTask -TaskPath '\AIG\' -TaskName 'FINESIII RPA Agent'
```

The command returns at once. Allow 15 to 30 seconds (up to a minute while the screen-reading engine loads), then check (15.5). From then on the service starts by itself whenever the bot account signs in. Closing PowerShell does not stop it; signing the bot account out does.

### 15.5 Check that it is running

```powershell
Get-Content 'C:\FINESIII\data\agent.json' -ErrorAction SilentlyContinue
Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:8000/api/v1/ping' | Select-Object StatusCode, Content
Get-ScheduledTask -TaskPath '\AIG\' -TaskName 'FINESIII RPA Agent' | Get-ScheduledTaskInfo | Select-Object LastRunTime, LastTaskResult
Get-Content 'C:\FINESIII\data\logs\agent.log' -Tail 25 -Encoding UTF8
```

`[OK]`
- `agent.json` shows `url`, `port`, `pid`, `version` and `started_at` (present only while the service runs);
- the ping answers `200` and `{"status":"ok"}`;
- `LastTaskResult` is `267009` (the task is running);
- the end of `agent.log` shows `LAUNCHER | starting the service`, the start summary and the **Ready** line.

Then, in the console, **Settings › Fujitsu Mainframe terminal › Terminal summary (as the service runs now)** shows **This service runs as administrator: Yes** (main path).

`[NG]` No `agent.json`, the ping fails, or `agent.log` shows repeated restarts: section 22.8.

### 15.6 Test the automatic start and the recovery

1. **Automatic start.** Sign the bot account out and in again. After about 30 seconds repeat the checks of 15.5.
2. **Recovery** (before go-live only). In an **administrator window** (the service runs with administrator rights, so a normal window cannot end it), end the service process:

```powershell
Stop-Process -Id (Get-Content 'C:\FINESIII\data\agent.json' -Raw | ConvertFrom-Json).pid
```

`[OK]` Within about a minute `agent.log` shows `the service stopped unexpectedly (exit code ...); starting it again in 60 seconds`, then a fresh **Ready** line, and `agent.json` shows another `pid`. The **Dashboard** and **System** page show **The service stopped unexpectedly (previous run started ...) and was started again at HH:MM JST.**

3. **Normal stop.** In a bot window:

```powershell
cd C:\FINESIII\app
.\.venv\Scripts\python.exe desktop\app.py --stop
```

`[OK]` **Agent stopped.**, and `agent.log` shows `the service stopped normally; the launcher ends`. Start it again with 15.4.

> **Important. Keep the bot's desktop available.** With the real Fujitsu Mainframe terminal (and the Fujitsu RACF terminal), the bot types into a window on the bot account's desktop. Windows accepts those keystrokes only while the bot's session is **signed in, unlocked and not minimized**.
> - While the session is locked, disconnected, or shown in a minimized remote-desktop window, requests of both applications **wait in the queue**; they are not counted as failed (section 15.7, "The bot's Windows session check").
> - A transaction that is running at the moment the session is locked or minimized can fail at that step; its error text (and the error e-mail, where error e-mails are switched on) says in plain words that Windows did not accept the bot's keystrokes.
> - Signing the bot account out stops the service.
> - The server team decides, under the organisation's security policy, how the bot account's session stays signed in and unlocked. The `unattended` folder of the package sets up the supported ways (section 15.8).
> - Before connecting to or disconnecting from that session, confirm on the **Dashboard** that no transaction is running.
>
> With the simulator used right after installation, no visible desktop is needed and the session is not checked.

### 15.7 Sharing the server with other users

The application is installed once and serves everyone who signs in to this server.

| Rule | Why |
|---|---|
| Only the bot account runs the service, through the scheduled task. Nobody else runs `desktop\app.py --agent` or the launcher. | A second copy in another account would use different passwords and put the terminal window on the wrong desktop. Two copies on the same data folder are refused. |
| Every person uses the console in a browser in their own session, with their **own console account**. The `admin` account is never shared. | Every action is recorded in the audit trail under the person's name, and each person sees only what their role allows |
| People reach the console by signing in to the server by remote desktop with their own Windows account | The console answers only on the server itself (`127.0.0.1`) |
| Everyday control (pause, resume, restart, stop, self-test, logs, diagnostics) is done on the console's **System** page | Protected by console permissions and recorded in the audit trail; no file access is needed |
| Nobody signs in **as the bot account** from another computer | That takes over the bot's session and interrupts a transaction in progress |
| Nobody locks, minimizes or disconnects the bot's session (except with the unattended tools of section 15.8) | Windows then refuses the bot's keystrokes and requests wait until the session is available again |

**A shortcut on every user's desktop** (administrator window, once):

```powershell
Set-Content -Path 'C:\Users\Public\Desktop\AIG IAM Access RPA.url' -Value "[InternetShortcut]`r`nURL=http://127.0.0.1:8000/" -Encoding ASCII
```

`[OK]` An **AIG IAM Access RPA** shortcut appears on the desktop of everyone who signs in, and opens the console.

Keep port 8000 free. If it is taken when the service starts, the service uses another free port; the shortcut then does not match, and the current address is in `agent.json` and on the **System** page.

> **Important.** In the test mode left by the installation, the service's request interface asks for no key, so anyone signed in to the server could create requests without the console. Before other people use the server, a Developer saves the machine API keys under **Settings › This machine › Credentials** (**Machine API keys (ServiceNow connector, CLI)**), switches on **Require the machine API key** and **Console sign-in may use the API**, and restarts the service, as the Administrator Guide describes.

**Remote-desktop sessions.** The bot's session takes one session and stays signed in. Windows Server allows two simultaneous remote-desktop sessions for administration; more people at once need the Remote Desktop Session Host role and client access licences, which the server team decides. Other people sign out of their own sessions when they finish; the service is not affected.

**The bot's Windows session check.** With a real terminal driver (`pywinauto`) on Windows, the bot checks that its own Windows session can take keystrokes before it starts a request. The check is on by default and has no console setting.

| Case | What happens |
|---|---|
| The bot's session is signed in, unlocked and its window is not minimized | Requests run as usual |
| The session is locked (for example Windows key + L, or a screen-saver lock) | New requests of both applications stay **Queued**. The **System** page shows under **Needs attention**: **Requests wait: the bot's Windows session is locked. Keep the bot's session signed in, unlocked and not minimized; processing resumes by itself.** The default recipients receive **Bot Windows session Not Available**. |
| The session is disconnected (the remote-desktop window was closed without the unattended tools) | The same, with **the bot's Windows session is disconnected** |
| The remote-desktop window of the bot's session is minimized | Windows refuses the next keystroke. The request at that step can fail; then new requests wait, with **Windows did not accept the bot's keystrokes (the bot's remote desktop window may be minimized)**. The bot tries again at most once a minute. |
| The session takes keystrokes again | Processing resumes by itself; the queued requests run; e-mail **Bot Windows session Recovered** |
| Simulator drivers (right after installation) | The session is not checked |

To keep a minimized remote-desktop window drawing, set this once on the computer that **connects** to the bot's session, signed in there as the person who connects (the unattended options B and D set it themselves on the server):

```powershell
if (-not (Test-Path 'HKCU:\Software\Microsoft\Terminal Server Client')) { New-Item -Path 'HKCU:\Software\Microsoft\Terminal Server Client' | Out-Null }
New-ItemProperty -Path 'HKCU:\Software\Microsoft\Terminal Server Client' -Name 'RemoteDesktop_SuppressWhenMinimized' -PropertyType DWord -Value 2 -Force
```

The check can be switched off only in the settings file, for example on a server where support asks for it: add the line `DESKTOP_SESSION_CHECK=false` to `C:\FINESIII\app\.env` (administrator window, Notepad) and stop and start the service. Requests then fail instead of waiting while the session cannot take keystrokes. Keep it on in operation.

### 15.8 Optional: unattended operation (the bot keeps working while nobody is connected)

> **In plain words.** The background run of section 15 needs the bot account to be signed in with an unlocked desktop. The scripts of the `unattended` folder set up one of four supported ways to keep it so, even when nobody is connected to the server. The Unattended Operation Guide explains the options in full; this section gives the commands.

**Who does this:** Server team, with the approval of information security for the chosen option.

| Option | What it does | When |
|---|---|---|
| A | The bot runs in the bot account's own session. When the person leaves the server, the **Leave Bot Running** shortcut moves the session to the server's own screen, signed in and unlocked, instead of disconnecting it. | The simplest set-up, when someone signs in after each server restart |
| B | The bot runs in a second session of the same account, which the server opens to itself (`127.0.0.2`) and opens again when it closes (task **FINESIII Bot Session Keeper**) | People connect as the bot account from time to time without taking over the bot's screen |
| C | Option A plus automatic sign-in of the bot account after a server restart | No one has to sign in after a restart |
| D | Option B plus automatic sign-in after a server restart | As B, without sign-in after a restart |

*Signed in as: **the bot account**, in an administrator window (Run as administrator), in `C:\FINESIII\app`.* Option A as the example; for another option change the letter. `-SeparateSessions` (options A and C) lets later remote-desktop visits of the account open a session of their own:

```powershell
cd C:\FINESIII\app
powershell -NoProfile -ExecutionPolicy Bypass -File .\unattended\Setup_Unattended.ps1 -Option A -Account '<DOMAIN>\<bot-account>'
```

**Sample (QA):**

```powershell
cd C:\FINESIII\app
powershell -NoProfile -ExecutionPolicy Bypass -File .\unattended\Setup_Unattended.ps1 -Option A -Account 'R6-CORE\prvrnel'
```

`[OK]` Lines marked **OK**, **DONE** or **INFO**, including **Task 'FINESIII RPA Agent': starts the bot when <DOMAIN>\<bot-account> signs in** (**Sample (QA):** **... when R6-CORE\prvrnel signs in**), and exit code 0 (2: done, with warnings to read). For options B and D the script asks once for the bot account's Windows password, which it saves in that account's Credential Manager for the session to itself. For options C and D, automatic sign-in is switched on with the Microsoft Autologon tool as the Unattended Operation Guide describes; the script only checks it.
`[NG]` **FAIL** with a reason (exit code 1), for example a missing file of the `unattended` folder: correct it and run the same command again. A **WARN** about a company policy that locks the screen: ask IT for an exception for this server.

> **Important.** `Setup_Unattended.ps1` replaces the scheduled task **FINESIII RPA Agent** of section 15.3 with its own, which starts `unattended\Start_FINESIII_Service.pyw` (the same restart behaviour) with highest privileges. It also switches off sleep, the screen switching off and the screen saver lock for the bot account. It does not start or stop the bot. `-Remove` deletes the task **FINESIII RPA Agent** as well: afterwards register it again with section 15.3, or the bot no longer starts at sign-in.

Then start the bot and check the set-up:

```powershell
Start-ScheduledTask -TaskPath '\AIG\' -TaskName 'FINESIII RPA Agent'
powershell -NoProfile -ExecutionPolicy Bypass -File .\unattended\Check_Unattended.ps1
```

For options B and D start the bot's session instead of the first command: `Start-ScheduledTask -TaskPath '\AIG\' -TaskName 'FINESIII Bot Session Keeper'`.

`[OK]` `Check_Unattended.ps1` changes nothing and ends with exit code 0 (all OK) or 2 (warnings only): **Task 'FINESIII RPA Agent': state ...**, **Option set up: A**, **Running: http://127.0.0.1:8000 ...**, **The bot answers (200)**, **Launcher running (restarts the bot after a crash) ...**.
`[NG]` Exit code 1: each **FAIL** line says what to do, for example **The bot is not running** or **Session 0 has no screen: the bot cannot use the terminal there. Start it through the scheduled task.**

**Leaving the server (options A, B and C).** Do not close the remote-desktop window and do not lock the screen. Double-click **Leave Bot Running** on the bot account's desktop (it runs `unattended\Leave_Bot_Running.cmd` as administrator). The remote-desktop window closes at once; that is expected, and the session stays signed in and unlocked on the server's own screen. Then confirm in your own session, on the **System** page, that nothing about the Windows session is listed under **Needs attention**.

**Remove the set-up** (administrator window, as the bot account), then register the task again with section 15.3:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\unattended\Setup_Unattended.ps1 -Remove -Account '<DOMAIN>\<bot-account>'
```

**Sample (QA):**

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\unattended\Setup_Unattended.ps1 -Remove -Account 'R6-CORE\prvrnel'
```

## 16. Step 9: Hand over to the console

> **In plain words.** The installation is complete and runs safely in test mode: simulated terminal, no real system touched. The console administrator then connects the real systems, following the Administrator Guide.

**Who does this:** Admin, Developer.

State at hand-over: the **Development** environment, the **simulator** terminal driver, screen reading on, no machine API key, the database on RDS, the audit trail on RDS, and the service in the background.

The console administrator continues with the Administrator Guide:

1. Complete **Set up the modules** (**Settings › Run setup again**): ServiceNow, Email (SMTP), CyberArk, Fujitsu Mainframe target. Every page has a test button.
   - **Sample (QA):** ServiceNow **Instance URL** `https://aigm3.service-now.com` (QA instance; confirm); **Assignment group (sys_id or name)** `Policy Management System - Common Process-2565-JPN` (one group for the tickets of both applications).
2. Store the service-account values and the other passwords under **Settings › This machine › Credentials**.
3. Enter the date each service-account password was last changed: **Service-account password: last changed on** (Settings › Fujitsu Mainframe terminal) and, with Fujitsu RACF, **RACF sign-on ID password: last changed on** (Settings › Fujitsu RACF terminal and sign-on), as YYYY-MM-DD. The bot counts the password's age from this date (the host expires it after 90 days) and sends its reminders from it: a reminder when the change is due (80 days), an urgent one in the last 5 days, and an expired notice, to the default recipients, the CyberArk / identity team and the support report recipients. Without the date the age is not known. While CyberArk supplies a password, CPM changes it and no reminder is sent for it.
4. Create a console account for each person and assign roles.
5. Switch on the machine API key before other people use the server (section 15.7).
6. Test end to end, switch to the real terminal, then complete the go-live checklist.
7. Optional: the database password from CyberArk (section 13.7).
8. Before real work: production mode (section 16.2).

> **Important. The service-account password must be stored before the first start with the real terminal, even when CyberArk will supply it.** The service checks the three service-account values when it starts with the real terminal driver: **Service account — affiliation code** (5 digits), **Service account — staff code** (7 letters or digits) and **Service account — password** (exactly 8 characters; the console does not check its length, the service does). Without valid values the terminal part cannot be built: the **System** page shows **Terminal executor could not be built — Credential validation failed: ... Processing is disabled until the Fujitsu Mainframe settings are completed and the service is restarted.**, and CyberArk has nothing to deliver its password to. Store all three under **Settings › This machine › Credentials** first; CyberArk then replaces the password while the service runs.

**Changing the Fujitsu Mainframe service-account password on the console.** A Developer can change the service-account password on Task 0890 (パスワードの登録と変更) from **Settings › Fujitsu Mainframe terminal**, in the row of tests: **Test password screen** signs in and opens Task 0890 without typing on it; **Change service-account password** asks for the current password, the new one and its confirmation, and sets it on the host. The new password has exactly 8 characters, a letter first, at least one letter and one digit, only the symbols `@ # $ & * - _ = ! ? .`, and not the staff code. Processing must be paused, the operating window must be open and Fujitsu Mainframe ready; the change is refused while CyberArk supplies the password and more than once in 24 hours. The bot keeps the new password and e-mails the result (changed or not changed, never the password) to the CyberArk / identity team, the default recipients and the support report recipients. The Fujitsu RACF password cannot be changed by the bot: it only reminds. The Administrator Guide describes both.

The settings the hand-over most often touches:

| Setting | What it means | Default | Who can change it | Takes effect |
|---|---|---|---|---|
| **Start the terminal as administrator** (Settings › Fujitsu Mainframe terminal) | Opens the terminal as administrator; needs the service itself to run as administrator (step 8) | On | Admin | After a restart |
| **Launcher shortcut** (Settings › Fujitsu Mainframe terminal) | The full location of the shortcut that starts the Fujitsu Mainframe terminal | `C:\Users\Public\Desktop\オンライン業務.lnk` | Admin | After a restart |
| **Service account — affiliation code**, **staff code**, **password** (This machine › Credentials) | The bot's own sign-in to Fujitsu Mainframe | Not set | Admin | After a restart |
| **Service-account password: last changed on** (Settings › Fujitsu Mainframe terminal) | The date of the last change of the service-account password (YYYY-MM-DD), for the age and the reminders. The bot records the date of each change it makes itself; the later date is used. | Not set | Admin | At once |
| **Service-account password: change automatically** (Settings › Fujitsu Mainframe terminal) | On: once the password is old enough, the bot changes it itself on Task 0890. Off: reminders only. | Off | Admin | At once |
| **Terminal driver** (This machine › Deployment) | `simulator` for testing; `pywinauto` for the real terminal | `simulator` (starter file) | Developer | After a restart (the console's **Restart service** is enough) |
| **Screen reading (OCR)** (This machine › Screen reading (start-up)) | Mandatory with the real terminal | On (starter file) | Developer | After a restart (**Restart service**) |
| **Service environment** (This machine › Deployment) | `production` requires the machine API key, and CyberArk with the real terminal | `development` (starter file) | Developer | After a restart (**Restart service**) |
| **Require the machine API key** (This machine › Security) | The request interface asks for a key | Off (starter file) | Developer | After a restart (**Restart service**) |
| **Service port** and **Refuse another port** (This machine › Deployment) | The port of the console and the request interface on `127.0.0.1` | 8000; Off | Developer | Only when the bot is **stopped and started again** (`desktop\app.py --stop`, then `Start-ScheduledTask`). **Restart service** keeps the port in use; the row shows **Saved — applies when the bot is stopped and started again**. |
| **Default recipients** and the team and support-report lists (Settings › E-mail and the application pages) | Who receives the e-mails | Empty | Admin (some lists Developer) | The lists apply at once. While **Default recipients** is empty, a change that switches e-mail on or off as a whole asks for a restart: **Restart the service to apply these. E-mail is switched on by this change (Default recipients is empty).** (or **off**) |

After changing **Service port**, also correct the desktop shortcut of section 15.7, and use the new address in the browser.

Machine settings saved in the console are written into `C:\FINESIII\app\.env` when that file holds the setting, with a dated backup of the file kept first; otherwise into the machine settings file `C:\FINESIII\data\finesiii.env` (Appendix B). Change the database lines only with the database script (section 20.3), not in the console.

### 16.1 Optional: Fujitsu RACF on this server

> **In plain words.** Fujitsu RACF is the second mainframe application the bot can work on (its configuration names say TSS). It is switched off after the installation. Prepare the server as below only when Fujitsu RACF requests will be handled on it; the console part is in the Administrator Guide (section 5.9).

**Who does this:** Server team (the Fujitsu RACF console), Fujitsu RACF team (the bot's sign-on ID and test IDs), Developer (the console settings).

Before switching it on:

1. **The Fujitsu RACF console.** WSMGR with the DSPEMU terminal is installed for the bot account, with the **接続1** connection on the desktop. Opened by hand in the bot's session, 接続1 shows `JCET020 SYSTEM READY`. Close it again: the bot opens it itself.
2. **Only 接続1.** The bot uses the window titled **接続1 - DSPEMU** and never touches other connections. Do not keep a 接続1 window open in the bot's session: with two such windows open the start is refused.
3. **The bot's sign-on ID.** The Fujitsu RACF team confirms the bot's sign-on ID (SAILPNT by default) and its password for the system to use: **TSS3** on a test server, **TSS2** in production. Nobody signs on with this ID by hand while the bot runs.
   - **Sample (QA):** sign-on ID `SAILPNT`, system `TSS3` (TSS2 also exists).
4. **The password.** Store it under **Settings › This machine › Credentials** as **Fujitsu RACF service account — password**, or set up the Fujitsu RACF account in CyberArk (required in production with the real terminal). The bot cannot change this password; it reminds when the change is due (section 16).
5. **The network.** The server reaches the Fujitsu RACF host; note its host name and port for **Fujitsu RACF host (probe)** and **Fujitsu RACF port (probe)**.

Then, in the console, as a Developer:

1. **Settings › This machine › Fujitsu RACF**: switch **Fujitsu RACF (second application)** on, enter the host and port, **Save and restart**. The Fujitsu RACF pages appear under **Settings** after the restart.
2. **Settings › Fujitsu RACF terminal and sign-on**: set **Fujitsu RACF system**, keep **Fujitsu RACF window title contains** at its default `接続1 - DSPEMU`, and leave **Fujitsu RACF terminal program (instead of the shortcut)** empty unless the console is started from a program file. A connection such as 接続1 is not a file: the shortcut is then used (**Fujitsu RACF terminal shortcut**, or, when that is empty, the icon found on the desktops), and a value that is not a file on this server is refused when saved. Enter **RACF sign-on ID password: last changed on**. Save and restart.
   - **Sample (QA):** **Fujitsu RACF terminal shortcut** `C:\ProgramData\Fujitsu\WSMGR\接続1.emd`; **Fujitsu RACF terminal program (instead of the shortcut)** empty (`接続1` is not a file; the shortcut is used); **Fujitsu RACF window title contains** `接続1 - DSPEMU`; **Fujitsu RACF system** `TSS3`; **Fujitsu RACF sign-on ID** `SAILPNT`; **Start the Fujitsu RACF terminal as administrator** On.
3. **Settings › Fujitsu RACF tickets and e-mails**: enter the **Fujitsu RACF team** addresses and keep **Fujitsu RACF removals** on **Left for a person (the ticket is told why)** for now. **Fujitsu RACF team: support reports only** is On by default: the team then receives only the support report of each Fujitsu RACF SailPoint ticket, and every other Fujitsu RACF e-mail goes to the support teams and the other teams set for it.
4. **Settings › Fujitsu RACF completion ticket**: **Completion ticket in ServiceNow** is Off by default. Switch it on only when the app team wants a ServiceNow record after each successful create or removal, and prove it with **Test completion ticket** (Administrator Guide).
   - **Sample (QA):** **Completion ticket: assignment group** `MFT-SYS Programmer-JPN` (this group only receives the completion tickets; the bot does not read tickets from it).
5. Pause processing and run **Test Fujitsu RACF host**, **Test Fujitsu RACF terminal launch**, then **Test Fujitsu RACF sign-on** once (on **Settings › Fujitsu RACF terminal and sign-on**). All three pass. Each check or request starts the Fujitsu RACF terminal once; while processing is paused the bot does not start it by itself.
6. Resume processing. The first create and removal are tested with the Fujitsu RACF team, in the test system, with test IDs (Administrator Guide, section 5.9).

Updates that change Fujitsu RACF are installed with update folders like any other (section 19). Their PATCH_README names the checks to run afterwards.

### 16.2 Optional: switching to production mode

> **In plain words.** The installation is left in the Development environment, the safe test mode. Before real work, a Developer switches the **Service environment** to `production`. Production is strict: it refuses to work on the real terminal unless the service-account password comes from CyberArk, and some defaults become stricter. Do it after the console set-up and the end-to-end test of the Administrator Guide, outside the operating window.

**Who does this:** Developer (console), Server team (settings file, only for Fujitsu RACF), CyberArk / identity team.

**What changes with `APP_ENV=production`.** A value saved in the console, or a line in `.env` or `finesiii.env`, always wins over these defaults.

| Item | Development (as installed) | Production |
|---|---|---|
| Fujitsu Mainframe password with the real terminal (`pywinauto`) | May come from the bot account's Credential Manager | Must come from CyberArk (**Settings › CyberArk**). Saving the real driver without CyberArk is refused: **In production a real terminal driver requires the mainframe password to come from CyberArk — enable and test the CyberArk module first.** Without it the service starts, but processing is disabled and the **System** page shows **CyberArk is required here (require_cyberark with a real terminal driver) but is not enabled or did not start. ...**. Until CyberArk has delivered the password, processing is paused by itself. |
| Fujitsu RACF password with the real terminal (only when Fujitsu RACF is on) | May come from the Credential Manager | Must come from CyberArk. Its account is named only in the settings file (no console field): without it, Fujitsu RACF requests wait in the queue and the **System** page shows **CyberArk is required here but no Fujitsu RACF account is set (CYBERARK_TSS_OBJECT or CYBERARK_TSS_ACCOUNT_USERNAME); Fujitsu RACF requests wait in the queue.** |
| Machine API key | Not required | Required by default. The starter `.env` holds `AUTH_ENABLED=false`, which wins: switch **Require the machine API key** On in the console (it changes that line). |
| **Mainframe environment** (the `99` before the sign-in affiliation code) | `development`: `99` is added | `production`: nothing is added. Set **Mainframe environment** explicitly to what the Fujitsu Mainframe host of this server expects. |
| **Keep the password of a failed request for (days)** | 7 | 0: the password is erased when the request fails, so **Retry** is refused for a provisioning request that brought its own password |
| Operating window and **Probe the mainframe** | All day (00:00-23:59), no probe | 06:00-22:00 JST with the probe, unless the console has saved other values |
| Log level | DEBUG | INFO |

**Steps** (signed in to the console as a Developer, processing paused):

1. **Settings › CyberArk**: the Fujitsu Mainframe service-account password comes from CyberArk and its test passes (Administrator Guide). **Verify TLS certificate** stays On.
2. Only with Fujitsu RACF on: the server team adds the Fujitsu RACF account to `C:\FINESIII\app\.env` (administrator window, Notepad). `CYBERARK_TSS_SAFE` is needed only when the account is in another safe than the Fujitsu Mainframe account:

```
CYBERARK_TSS_OBJECT=<account object>
CYBERARK_TSS_SAFE=<safe>
```

3. **Settings › This machine › Credentials**: save **Machine API keys (ServiceNow connector, CLI)**. **Settings › This machine › Security**: **Require the machine API key** On and **Console sign-in may use the API** On.
4. **Settings › This machine › Deployment**: **Mainframe environment** as agreed (worksheet item 18), **Terminal driver** `pywinauto`, **Service environment** `production`. **Settings › This machine › Screen reading (start-up)**: **Screen reading (OCR)** On.
5. **Settings › E-mail**: **Send every e-mail only to (testing)** empty. While it holds an address, every e-mail goes only there and the **Dashboard** shows a warning.
6. Click **Save and restart**.

`[OK]` The start summary in `agent.log` shows **Environment : production (ProductionConfig)**; the **System** page lists nothing under **Needs attention** (no CyberArk or API key notice); the **Dashboard** shows **Database** **Connected**. Resume processing.
`[NG]` A notice under **Needs attention** names what is missing (section 22.10).

| Case | What happens |
|---|---|
| Production with the real terminal, CyberArk set up and tested | Requests are processed; the service-account password is refreshed from CyberArk |
| Production, **Terminal driver** `pywinauto`, CyberArk off | The save is refused; if set in the settings file instead, the service starts with processing disabled and says why |
| Production, Fujitsu RACF on, no `CYBERARK_TSS_OBJECT` / `CYBERARK_TSS_ACCOUNT_USERNAME` | Fujitsu Mainframe requests run; Fujitsu RACF requests wait in the queue |
| Production with `AUTH_ENABLED=false` still in `.env` | The service runs, but **Needs attention** shows **Requests are accepted without an API key...** in red with the real terminal |
| Production, **Mainframe environment** left to its default | The bot signs in without `99`; on a host that needs `99` the sign-in is refused |

> **Important.** There is no import of settings from another server. **Export configuration** (Settings page) downloads every setting as a CSV file with the secrets masked, for change control and hand-over; on a new server the settings and the passwords are entered again in the console.

## 17. Installation sign-off checklist

> **In plain words.** One line per proof. When every line is ticked, the installation is complete.

**Who does this:** Server team, Database administrator, Admin.

| # | Check | Evidence | Done |
|---|---|---|---|
| 1 | Package complete and unchanged | No output from the checksum check (step 2) | ☐ |
| 2 | Prerequisites complete | **READY** from `Setup_Prerequisites.ps1`; `-CheckOnly` shows no FAIL | ☐ |
| 3 | Time zone | `Get-TimeZone` shows `Tokyo Standard Time` | ☐ |
| 4 | Data folder variable | `$env:FINESIII_DATA_DIR` shows `C:\FINESIII\data` in a bot window | ☐ |
| 5 | Folder permissions | `icacls` lists only SYSTEM, Administrators and the bot account (step 4) | ☐ |
| 6 | Bot account rights approved | Administrator membership (or the alternative) approved by information security | ☐ |
| 7 | RDS reachable only as intended | `TcpTestSucceeded : True`; security group limited to this server | ☐ |
| 8 | Encryption enforced and checked | `rds.force_ssl = 1`; `verify-full`; pgAdmin shows `ssl = true` for `finesiii_app` | ☐ |
| 9 | Database created with least privilege | **READY** from `Setup_Database.py`; history and audit events protected by the database | ☐ |
| 10 | No password in files | `.env` holds no password (Appendix B) | ☐ |
| 11 | Database check | `desktop\app.py --check-db` shows **Result : OK** | ☐ |
| 12 | Self-test | **ALL COMPONENTS USABLE**, exit code 0 | ☐ |
| 13 | First sign-in done | `admin` chose its own password; **Bot service Running**, **Database Connected** | ☐ |
| 14 | Background service | Started by the task; the 15.5 checks pass; no window left open | ☐ |
| 15 | Runs as administrator (main path) | **This service runs as administrator: Yes** | ☐ |
| 16 | Automatic start, recovery and stop | Section 15.6, all three | ☐ |
| 17 | Bot desktop session policy agreed | Decision recorded by the server team and security: signed in, unlocked, not minimized; the unattended option chosen, if any (section 15.8) | ☐ |
| 18 | Backups | Data folder in the server backup; RDS automated backups on (section 20) | ☐ |
| 19 | Shared use prepared | Own console account per person; shortcut on the public desktop; machine API key on before shared use | ☐ |
| 20 | Hand-over | Console administrator has the Administrator Guide and the service-account values | ☐ |
| 21 | Fujitsu RACF (only when used on this server) | 接続1 opens at SYSTEM READY in the bot's session; **Fujitsu RACF terminal program** empty unless it is a file; the three Fujitsu RACF tests pass (section 16.1) | ☐ |
| 22 | Service-account password dates | **last changed on** entered for Fujitsu Mainframe (and Fujitsu RACF when used), so that the reminders follow the real age (section 16) | ☐ |
| 23 | Database password from CyberArk (only when used) | **Test CyberArk retrieval** names the administrator account; after **Save and restart** the **Database password** card shows **Latest password from CyberArk** with **Last successful check** and **Next check**; **Validate database password** answers **Password validated**; the **Database password changed** e-mail was received; the safe order for the database script and the way back are recorded (section 13.7) | ☐ |
| 24 | Audit trail location decided | Audit database `finesiii_audit` on RDS, or the local file in the data folder, recorded on the worksheet (section 13.1) | ☐ |
| 25 | Bot's Windows session check (with the real terminal, before go-live, no request running) | Session locked for two minutes: new requests stay **Queued**, the **System** page shows **Requests wait: the bot's Windows session is locked...**, **Bot Windows session Not Available** e-mail; after unlocking, the requests run and **Bot Windows session Recovered** arrives (section 15.7) | ☐ |
| 26 | Unattended operation (only when used) | `Check_Unattended.ps1` ends with exit code 0 or 2 and no **FAIL**; **Leave Bot Running** tested; the bot keeps working after the remote-desktop window closes (section 15.8) | ☐ |
| 27 | Production mode (when switched) | **Environment : production (ProductionConfig)** in `agent.log`; CyberArk delivers the service-account passwords; machine API key on; **Mainframe environment** set; **Send every e-mail only to (testing)** empty; nothing under **Needs attention** (section 16.2) | ☐ |
| 28 | Service port (only when changed) | The bot was stopped and started again; the shortcut and `agent.json` show the new port (section 16) | ☐ |

Signed off by (installation administrator / project lead / date): ____________________

---

# Part D — Optional test instance on the same server

> **In plain words.** A second, separate copy of the service can run on the same server for rehearsals and demonstrations. It uses its own data folder and a database file instead of RDS, a stand-in for ServiceNow, and a simulated Fujitsu Mainframe terminal window, so no real system is touched.

**Who does this:** Server team (as the bot account), Developer.

|  | Production instance | Test instance |
|---|---|---|
| Data folder | `C:\FINESIII\data` | `C:\FINESIII\data-test` |
| Database | Amazon RDS | A database file in `C:\FINESIII\data-test` |
| Console address | `http://127.0.0.1:8000` | `http://127.0.0.1:8001` |
| ServiceNow | The real instance | Stand-in on port 8090 |
| Fujitsu Mainframe | The real terminal | Simulated terminal window |
| Runs | In the background (scheduled task) | In a bot window, only when needed |

> **Important. Safe order.** Start the test instance only **after** the production first start and first sign-in (step 7). Both instances run as the bot account and therefore share its Credential Manager. When the test console's administrator chooses a password, the stored one-time password of production is removed from that shared store. Before the production first sign-in that would cost you the production one-time password.

> **Important. Never change shared things in the test console.** In the test console (port 8001) never save anything under **Settings › This machine** (neither **Credentials** nor the machine settings) and never switch rules on the **Error rules** page. Credentials are shared with production, machine settings are written into the same `C:\FINESIII\app\.env`, and the error rules are the same `config\errors.yaml`. The test window gives its own values for everything it needs.

**D.1 Prepare the folder** (administrator window, once):

```powershell
New-Item -ItemType Directory -Force -Path 'C:\FINESIII\data-test'
icacls 'C:\FINESIII\data-test' /inheritance:r /grant:r "*S-1-5-18:(OI)(CI)F" "*S-1-5-32-544:(OI)(CI)F" "<DOMAIN>\<bot-account>:(OI)(CI)M"
```

**Sample (QA):**

```powershell
New-Item -ItemType Directory -Force -Path 'C:\FINESIII\data-test'
icacls 'C:\FINESIII\data-test' /inheritance:r /grant:r "*S-1-5-18:(OI)(CI)F" "*S-1-5-32-544:(OI)(CI)F" "R6-CORE\prvrnel:(OI)(CI)M"
```

**D.2 Start the test instance** (bot window 1; keep it open). Paste the whole block; the values apply to this window only and take priority over `.env` and the stored credentials:

```powershell
cd C:\FINESIII\app
$env:FINESIII_DATA_DIR = 'C:\FINESIII\data-test'
$env:API_PORT          = '8001'
$env:APP_ENV           = 'development'
$env:DATABASE_ENGINE   = 'sqlite'
$env:AUDIT_BACKEND     = 'sqlite'
$env:OCR_ENABLED       = 'false'
$env:AUTH_ENABLED      = 'false'
$env:TERMINAL_DRIVER   = 'sim_terminal'
$env:SIM_ACTION_DELAY  = '0.3'
$env:AUTH_DEFAULT_ADMIN_PASSWORD = 'ChangeMe!2026'
$env:SNOW_PASSWORD               = 'mock-password'
$env:FINESIII_AFFILIATION_CODE   = '03325'
$env:FINESIII_APPLICATION_ID     = '12N3940'
$env:FINESIII_PASSWORD           = 'TEST0000'
.\.venv\Scripts\python.exe desktop\app.py --agent
```

The service-account values are the simulator's built-in test account, so the real values stored for production are never used by the test instance. `sim_terminal` shows the simulated terminal window; `mock` runs the same steps without a window, faster.

`[OK]` **Driver : sim_terminal ...**, **Database : sqlite — C:\FINESIII\data-test\finesiii_v3.db**, **Ready — http://127.0.0.1:8001 ...**
`[NG]` **Database : postgres**: the block was not pasted completely. Stop the instance (D.5) and start again.
`[NG]` **[STOP] Another AIG IAM Access RPA desktop instance is already running (lock: C:\FINESIII\data-test\agent.lock)**: the test instance is already running.

**D.3 First sign-in to the test console.** `Start-Process 'http://127.0.0.1:8001/'`. Sign in as `admin` with the published default password `ChangeMe!2026` (set in the block above, for the test instance only), and choose a test password. The **System** page lists the notice about requests without an API key under **Needs attention**; that is expected here.

**D.4 The ServiceNow stand-in** (bot window 2):

```powershell
cd C:\FINESIII\app
.\.venv\Scripts\python.exe scripts\run_mock_snow_server.py --port 8090 --samples --process --include-bad --unassigned
Start-Process 'http://127.0.0.1:8090/'
```

`[OK]` **Pre-seeded N task(s) in group '<group name>'** and **Live ticket board: http://127.0.0.1:8090/**. The tickets use fictional people; the board refreshes by itself. Any user name and any non-empty password are accepted.

In the test console, **Settings › ServiceNow**: **Poll ServiceNow for tickets** On, **Instance URL** `http://127.0.0.1:8090`, **Authentication** `basic`, **Username** `finesiii.bot`, **Match tickets by** `assignment_group`, **Assignment group (sys_id or name)** the group name printed by the stand-in, **Bot account (sys_id, user name or name)** `finesiii.bot`. Use **Test connection** and **Preview tickets** (nothing is written), then **Save changes**. The password comes from the test window; do not type it under **Credentials**. More tickets while it runs (bot window 3):

```powershell
cd C:\FINESIII\app
$env:SNOW_INSTANCE_URL = 'http://127.0.0.1:8090'
.\.venv\Scripts\python.exe scripts\run_snow_ticket_seeder.py --sailpoint --count 6
```

Watch the **Dashboard**, **Requests**, the simulated terminal window and the ticket board. When production already processes real work with the real terminal, pause it first (production console, **System › Pause processing**) so that only one instance uses the bot's desktop, and resume it afterwards.

**D.5 Stop the test instance.** Stop the stand-in with Ctrl+C in window 2. Then, in any bot window:

```powershell
cd C:\FINESIII\app
$env:FINESIII_DATA_DIR = 'C:\FINESIII\data-test'
.\.venv\Scripts\python.exe desktop\app.py --stop
```

> **Important.** Without the first two lines, `--stop` stops the **production** service. Close the test windows afterwards; their values end with them.

**D.6 Start it again empty.** Stop it, then in an administrator window rename the folder and repeat D.1 and D.2:

```powershell
Rename-Item 'C:\FINESIII\data-test' ('data-test_old_' + (Get-Date -Format yyyyMMdd_HHmm))
```

---

# Part E — Operating the installation

## 18. Start, stop, status, logs and health checks

> **In plain words.** A handful of short commands start, stop and check the service; each returns at once. Most of the same controls are on the console's System page.

**Who does this:** Server team, Admin.

Run these from `C:\FINESIII\app` as the bot account, or as an administrator. The self-test, the database check and the database script must run **as the bot account**, because they read its Credential Manager.

| Need | Command |
|---|---|
| Start in the background | `Start-ScheduledTask -TaskPath '\AIG\' -TaskName 'FINESIII RPA Agent'` |
| Stop (a transaction in progress finishes first) | `.\.venv\Scripts\python.exe desktop\app.py --stop` |
| Restart after a change outside the console | Stop, then Start |
| Restart after a change in the console | Console: **Restart service** (System page) or **Save and restart** (Settings). Nothing to do on the server. |
| Apply a changed **Service port** or **Refuse another port** | **Restart service** does not apply them: stop, then start (the two rows above). The console says **... saved setting(s) (the service port) apply when the bot is stopped and started again; Restart service does not apply them.** |
| Running? On which address? | `Get-Content 'C:\FINESIII\data\agent.json'` |
| Answering? | `Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:8000/api/v1/ping'` |
| Task state | `Get-ScheduledTask -TaskPath '\AIG\' -TaskName 'FINESIII RPA Agent' \| Get-ScheduledTaskInfo` |
| Start-up messages and launcher notes | `Get-Content 'C:\FINESIII\data\logs\agent.log' -Tail 50 -Encoding UTF8` |
| Follow the service log | `Get-Content 'C:\FINESIII\data\logs\finesiii_rpa_v3.log' -Tail 50 -Wait -Encoding UTF8` (Ctrl+C ends only the display) |
| Recent errors | `Select-String -Path 'C:\FINESIII\data\logs\finesiii_rpa_v3.log' -Pattern 'ERROR' \| Select-Object -Last 20` |
| Component self-test | `.\.venv\Scripts\python.exe desktop\app.py --selftest` |
| Database check | `.\.venv\Scripts\python.exe desktop\app.py --check-db` |
| Database objects and rights (asks for the master password; not while the database password comes from CyberArk, section 13.7) | `.\.venv\Scripts\python.exe Setup_Database.py --rds --host <rds-endpoint> --admin-login <master-user> --audit-database finesiii_audit --check-only` |
| Database password from CyberArk (13.7): check it now | Console: **Validate database password** (System page) |
| Unattended set-up (15.8): what is set up, where the bot runs | `powershell -NoProfile -ExecutionPolicy Bypass -File .\unattended\Check_Unattended.ps1` (administrator window, as the bot account) |
| Prerequisites still complete? | `powershell -NoProfile -ExecutionPolicy Bypass -File .\Setup_Prerequisites.ps1 -CheckOnly` (administrator window) |
| Forgotten or locked console administrator | `.\.venv\Scripts\python.exe desktop\app.py --reset-console-password admin` (bot window) |

**Sample (QA):** the database objects and rights check:

```powershell
.\.venv\Scripts\python.exe Setup_Database.py --rds --host rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com --admin-login dbadmin --audit-database finesiii_audit --check-only
```

> **Important.** Never stop the service by ending processes in Task Manager or with **End** on the scheduled task. **End** stops only the launcher, while the service keeps running without automatic recovery. Use `--stop`, or **System › Stop the bot** in the console.

**In the console**, the **System** page shows the bot service, processing, terminal, database, screen reading and credential store (and, when used, the **Database password** card of section 13.7 and the Fujitsu RACF card), lists problems under **Needs attention** (for example **Requests wait: the bot's Windows session is locked...**, section 15.7) and **Warnings**, and offers **Pause processing** / **Resume processing**, **Run self-test**, **Download diagnostics** (passwords masked), **Restart service**, **Stop the bot**, **Configuration files**, and the log viewer (**Service log** and **Agent console**).

**Logs and their rotation.**

| Log | Location | Rotation |
|---|---|---|
| Service log | `C:\FINESIII\data\logs\finesiii_rpa_v3.log` | A new file every midnight; earlier days kept as `finesiii_rpa_v3.log.<YYYY-MM-DD>`. Files older than **Keep the service log for (days)** (default 30) are deleted. |
| Agent console | `C:\FINESIII\data\logs\agent.log` | Limited to 10 MB, checked at each start and every hour while running; the earlier content is kept as `agent.log.1` (one file) |
| Setup logs | `C:\FINESIII\data\logs\setup_*.log`, `setup_database_*.log` | Not rotated. Delete old ones in the regular clean-up. |
| Evidence | `C:\FINESIII\data\evidence` | Deleted automatically after **Keep evidence for (days)** (default 90) |

## 19. Updates with update folders

> **In plain words.** Fixes and improvements arrive as an update folder that holds only the changed files. You confirm the server has the expected versions, stop the service, keep a copy of the files that are replaced, copy the new files, verify them, start and check. If anything is wrong, you put the copy back.

**Who does this:** Server team.

An update folder contains:

| File | Purpose |
|---|---|
| `PATCH_README.txt` | Which servers the update is for, what it changes, the files that may show as NEW, the steps with their commands, the checks after the update and the way back. **Its commands always take priority over this section.** |
| `PRECHECK_ACCEPTED.txt` | Every version of each file the update may replace, as SHA-256 checksum, two spaces, path inside the application folder. A file may be listed more than once. |
| `PATCH_CONTENTS.txt` | Every file as it is after the update, in the same format |
| `app\` | The files, in the same folders as in `C:\FINESIII\app` |

Updates are cumulative: the newest folder contains every earlier update that its README names, so only the newest one is installed. The README names the updates a server must already have.

*Signed in as: server administrator. Window: administrator window, in `C:\FINESIII\app`.* Replace `<update folder>` with the full path of the update folder and `<name>` with a short name of the update.

**Before the update.** Pause processing (console, **System › Pause processing**) and let a running request finish. Close any terminal window or dialog left open in the bot's session. Keep a copy of any configuration file the README names that was edited on this server.

**1. Precheck.** Confirm that the files on the server are versions this update replaces:

```powershell
cd C:\FINESIII\app
$ok = @{}
Get-Content '<update folder>\PRECHECK_ACCEPTED.txt' | Where-Object { $_ -match '^[0-9a-f]{64}  ' } | ForEach-Object {
    $hash, $path = $_ -split '  ', 2
    if (-not $ok.ContainsKey($path)) { $ok[$path] = @() }
    $ok[$path] += $hash
}
$ok.Keys | Sort-Object | ForEach-Object {
    if (-not (Test-Path -LiteralPath $_)) { "NEW      $_" }
    elseif ($ok[$_] -notcontains (Get-FileHash -Algorithm SHA256 -LiteralPath $_).Hash.ToLower()) { "CHANGED  $_" }
}
```

`[OK]` No output, or `NEW` only for the files the README names as new (for example new test files).
`[NG]` `CHANGED` lines: follow the README. A configuration file edited on this server is either kept (removed from the update's `app` folder before step 4) or replaced and edited again, as the README says for that file. For any other file, do not install the update; report the lines.

**2. Stop.**

```powershell
.\.venv\Scripts\python.exe desktop\app.py --stop
```

`[OK]` **Agent stopped.**

**3. Back up** the files that are replaced, and note the new ones:

```powershell
$stamp = Get-Date -Format yyyyMMdd-HHmm
$backup = "C:\FINESIII\backup-<name>-$stamp"
$patch = '<update folder>\app'
New-Item -ItemType Directory -Force -Path $backup | Out-Null
Get-ChildItem $patch -Recurse -File -Force | ForEach-Object { $_.FullName.Substring($patch.Length + 1) } | ForEach-Object {
  if (Test-Path -LiteralPath ".\$_") {
    New-Item -ItemType Directory -Force -Path (Split-Path "$backup\$_") | Out-Null
    Copy-Item -LiteralPath ".\$_" "$backup\$_"
  } else {
    Add-Content -LiteralPath "$backup\NEW_FILES.txt" -Value $_
  }
}
"Backup: $backup"
```

Note the folder name shown: going back needs it. When the README lists files that the update removes, its own step 3 also backs them up; use the README's commands in that case. When the README says the update changes the database, the database administrator also takes a manual RDS snapshot at this point.

**4. Copy the files:**

```powershell
Copy-Item "$patch\*" C:\FINESIII\app -Recurse -Force
Get-ChildItem C:\FINESIII\app -Recurse -File | Unblock-File
```

Then remove the files the README lists as no longer used, and, when the README says so, run `Setup_Prerequisites.ps1` (new packages) or `Setup_Database.py` (database changes) as it describes.

**5. Verify every file:**

```powershell
Get-Content '<update folder>\PATCH_CONTENTS.txt' | Where-Object { $_ -match '^[0-9a-f]{64}  ' } | ForEach-Object {
    $hash, $path = $_ -split '  ', 2
    if (-not (Test-Path -LiteralPath $path)) { "MISSING  $path" }
    elseif ((Get-FileHash -Algorithm SHA256 -LiteralPath $path).Hash -ne $hash) { "CHANGED  $path" }
}
```

`[OK]` No output, or only the files deliberately kept in step 1.

**6. Start and check:**

```powershell
Start-ScheduledTask -TaskPath '\AIG\' -TaskName 'FINESIII RPA Agent'
```

Then the 15.5 checks, Ctrl+F5 in the browser to load the updated console, the checks the README lists, and **System › Resume processing**. The README may also offer automated tests to run. Keep the backup until the update is confirmed in operation.

**Going back.** In a new administrator window, with the backup folder of step 3:

```powershell
cd C:\FINESIII\app
$backup = 'C:\FINESIII\backup-<name>-<stamp>'
if (-not (Test-Path -LiteralPath "$backup")) { throw "Backup folder not found: $backup" }
.\.venv\Scripts\python.exe desktop\app.py --stop
Copy-Item "$backup\*" C:\FINESIII\app -Recurse -Force -Exclude NEW_FILES.txt
if (Test-Path -LiteralPath "$backup\NEW_FILES.txt") {
  Get-Content -LiteralPath "$backup\NEW_FILES.txt" | ForEach-Object { Remove-Item -LiteralPath "C:\FINESIII\app\$_" -ErrorAction SilentlyContinue }
}
Start-ScheduledTask -TaskPath '\AIG\' -TaskName 'FINESIII RPA Agent'
```

Then refresh the console with Ctrl+F5. Follow any extra going-back steps in the README.

## 20. Backup and restore, moving the database, passwords and certificates

> **In plain words.** The database is protected by Amazon RDS backups; the server keeps the evidence, logs and service keys in the data folder. Passwords are not in any backup and are entered again after a restore. This section also covers moving to another RDS instance, changing the database password and refreshing the AWS certificate bundle.

**Who does this:** Server team, Database administrator.

### 20.1 What to back up

| What | Where | How |
|---|---|---|
| Queue, history, console accounts, settings, audit trail | RDS `finesiii_v3` and `finesiii_audit` | RDS automated backups; a manual snapshot before updates and moves |
| Evidence, logs, service keys and state | `C:\FINESIII\data` | The server's regular backup. It holds the console session key, the password fingerprint key (which prevents an issued password from being issued twice), the instance identity, the e-mail outbox, the audit spool and the backups of `.env`. Evidence contains personal data and passwords, so protect the backup accordingly. |
| Settings file, launcher, edited error rules, a CyberArk certificate file kept outside the data folder | `C:\FINESIII\app\.env`, `Start_FINESIII_Service.pyw`, `config\errors.yaml`, `C:\FINESIII\certs` (section 13.7) | The server's regular backup. The rest of the folder comes from the package and its updates. |
| Passwords and keys | The bot account's Credential Manager | Not backed up. Keep the values in the organisation's password vault; enter them again after a restore. |

### 20.2 Restore the data folder on the same server

1. Stop the service (`desktop\app.py --stop`).
2. In an administrator window, restore `C:\FINESIII\data` from the server backup.
3. Repeat the `C:\FINESIII\data` line of step 4 if the permissions were not restored.
4. Start the service and run the 15.5 checks.

### 20.3 Move to another RDS instance or endpoint

For example after a snapshot restore or a migration.

1. Stop the service.
2. Confirm the network path to the new endpoint (12.2).
3. As the bot account, run the one-command mode with the new endpoint:

```powershell
cd C:\FINESIII\app
.\.venv\Scripts\python.exe Setup_Database.py --rds --host <new-rds-endpoint> --admin-login <master-user> --audit-database finesiii_audit
```

On a restored snapshot the login already exists and keeps the password stored for it. Missing objects are created. The script writes the new addresses into `.env`.

4. `.\.venv\Scripts\python.exe desktop\app.py --check-db`, then start the service.

**With the database password from CyberArk (section 13.7)** step 3 changes, because the script must not use the stored password (13.7, the safe order):

1. The PAM team confirms which CyberArk account holds the administrator login of the new instance. When the account changed, and with the service stopped, correct the lines `CYBERARK_DB_OBJECT` (and `CYBERARK_DB_SAFE`, `DATABASE_ADMIN_LOGIN`) in the file that holds them (`C:\FINESIII\data\finesiii.env`, or `C:\FINESIII\app\.env`; administrator window, Notepad).
2. Run the database script in the safe order:

```powershell
.\.venv\Scripts\python.exe Setup_Database.py --rds --host <new-rds-endpoint> --admin-login <admin login> --audit-database finesiii_audit --admin-password-from-cyberark --set-password
```

3. Start the service; at start the bot gives `finesiii_app` on the new instance the password in CyberArk. On **Settings › This machine › Database**, run **Test CyberArk retrieval** and **Validate database password** to confirm.

The bot always connects to the address the script wrote, not to the address stored in CyberArk.

> **Important.** The database lines in `.env` are maintained by the database script. Change the database address with the script, not by hand and not in the console.

### 20.4 Change the database password

**When the database password comes from CyberArk (section 13.7)** nothing is done on the server: CPM changes the administrator's password in CyberArk, and the bot gives `finesiii_app` the same password at its next check (every 15 minutes by default), at once after a refused sign-in, and at every start. Requests keep running. To make the bot pick up a change at once, click **Validate database password** on the **System** page; the **Database password** card then shows the new **Changed in CyberArk** time and **Password in use: the latest from CyberArk, in use since ... JST.**, and the e-mail **Database password changed: the bot uses the new password** follows. Do not change the password of `finesiii_app` by hand or with `--set-password` while the service runs with this option: the bot sets it back at its next check and sends **Bot's database login set back to the password in CyberArk**. A database script run follows the safe order of section 13.7.

**Otherwise**, do this outside the operating window (06:00-22:00 JST by default):

1. Stop the service.
2. As the bot account, give the application login a fresh generated password:

```powershell
cd C:\FINESIII\app
.\.venv\Scripts\python.exe Setup_Database.py --rds --host <rds-endpoint> --admin-login <master-user> --audit-database finesiii_audit --set-password
```

**Sample (QA):**

```powershell
cd C:\FINESIII\app
.\.venv\Scripts\python.exe Setup_Database.py --rds --host rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com --admin-login dbadmin --audit-database finesiii_audit --set-password
```

The password is generated, stored in the bot account's Credential Manager, set on the login and verified. With the address form, add `--set-password` to the command of 13.4 A and type the password. When the database administrator changes it in pgAdmin instead, run the address form without `--admin-url` and type the password it was given. `scripts\setup_rds_database.py --set-password` does the same as a guided run (only while the database password does not come from CyberArk).

3. Start the service and check the **Dashboard**.

The master user's own password can be rotated at any time; the installation does not store it. When CyberArk holds the master user, `--admin-password-from-cyberark` reads it instead of the prompt (section 13.7).

### 20.5 AWS certificate rotation

The bundle in `C:\FINESIII\app\certs` covers every current RDS certificate authority, so a rotation of the instance's certificate to one of them needs nothing on the server. When AWS publishes a certificate authority that the bundle does not contain, either install an update folder that brings a refreshed bundle, or, as the bot account:

```powershell
New-Item -ItemType Directory -Force -Path 'C:\FINESIII\data\certs'
Invoke-WebRequest -UseBasicParsing -Uri 'https://truststore.pki.rds.amazonaws.com/global/global-bundle.pem' -OutFile 'C:\FINESIII\data\certs\global-bundle.pem'
(Select-String -Path 'C:\FINESIII\data\certs\global-bundle.pem' -Pattern 'BEGIN CERTIFICATE').Count
cd C:\FINESIII\app
.\.venv\Scripts\python.exe desktop\app.py --stop
.\.venv\Scripts\python.exe Setup_Database.py --rds --host <rds-endpoint> --admin-login <master-user> --audit-database finesiii_audit --ca-bundle C:\FINESIII\data\certs\global-bundle.pem
Start-ScheduledTask -TaskPath '\AIG\' -TaskName 'FINESIII RPA Agent'
```

**Sample (QA):**

```powershell
New-Item -ItemType Directory -Force -Path 'C:\FINESIII\data\certs'
Invoke-WebRequest -UseBasicParsing -Uri 'https://truststore.pki.rds.amazonaws.com/global/global-bundle.pem' -OutFile 'C:\FINESIII\data\certs\global-bundle.pem'
(Select-String -Path 'C:\FINESIII\data\certs\global-bundle.pem' -Pattern 'BEGIN CERTIFICATE').Count
cd C:\FINESIII\app
.\.venv\Scripts\python.exe desktop\app.py --stop
.\.venv\Scripts\python.exe Setup_Database.py --rds --host rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com --admin-login dbadmin --audit-database finesiii_audit --ca-bundle C:\FINESIII\data\certs\global-bundle.pem
Start-ScheduledTask -TaskPath '\AIG\' -TaskName 'FINESIII RPA Agent'
```

Behind a proxy, add `-Proxy 'http://<proxy-host>:<port>' -ProxyUseDefaultCredentials` to the download. The database administrator also points pgAdmin's **Root certificate** to the refreshed file.

With the database password from CyberArk (section 13.7), use this database command instead of the one above (the safe order):

```powershell
.\.venv\Scripts\python.exe Setup_Database.py --rds --host <rds-endpoint> --admin-login <admin login> --audit-database finesiii_audit --ca-bundle C:\FINESIII\data\certs\global-bundle.pem --admin-password-from-cyberark --set-password
```

**Sample (QA):**

```powershell
.\.venv\Scripts\python.exe Setup_Database.py --rds --host rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com --admin-login dbadmin --audit-database finesiii_audit --ca-bundle C:\FINESIII\data\certs\global-bundle.pem --admin-password-from-cyberark --set-password
```

## 21. Removing the installation

> **In plain words.** Removal undoes each piece in reverse order: the service, the task, the stored passwords, the folders, the machine variable, and finally the databases once the retention period allows it.

**Who does this:** Server team, Database administrator.

1. **Stop the service** (bot window):

```powershell
cd C:\FINESIII\app
.\.venv\Scripts\python.exe desktop\app.py --stop
```

2. **Remove the stored credentials** of the bot account (bot window, same folder):

```powershell
.\.venv\Scripts\python.exe -c "from desktop import vault; [vault.delete_secret(k) for k in vault.SECRET_KEYS]; print('removed')"
```

`[OK]` `removed`.

3. **Remove the task, the shortcut and the machine variable** (administrator window). The second shortcut name is that of a shortcut made with an earlier edition of this guide:

```powershell
Unregister-ScheduledTask -TaskPath '\AIG\' -TaskName 'FINESIII RPA Agent' -Confirm:$false
Remove-Item -LiteralPath 'C:\Users\Public\Desktop\AIG IAM Access RPA.url', 'C:\Users\Public\Desktop\FINES III RPA.url' -ErrorAction SilentlyContinue
[Environment]::SetEnvironmentVariable('FINESIII_DATA_DIR', $null, 'Machine')
```

4. **Archive, then delete the folders.** Archive `C:\FINESIII\data` first if the organisation's retention rules require it (evidence and logs). Then, in the administrator window:

```powershell
cd C:\
Remove-Item -LiteralPath 'C:\FINESIII' -Recurse -Force
```

This removes the application folder with the launcher and the backups of `.env`, the data folder with its `backups` folder, the optional `C:\FINESIII\data-test`, the update backups `C:\FINESIII\backup-*`, and a certificate file kept in `C:\FINESIII\certs` (section 13.7).

5. **Optional clean-up.** Remove the bot account from the Administrators group (`Remove-LocalGroupMember -SID 'S-1-5-32-544' -Member '<DOMAIN>\<bot-account>'`; **Sample (QA):** `Remove-LocalGroupMember -SID 'S-1-5-32-544' -Member 'R6-CORE\prvrnel'`) or delete the account; uninstall Python 3.13 in **Settings › Apps** if nothing else uses it; delete the download cache `finesiii-setup` in the administrator's temporary folder.

6. **Database.** After the agreed retention of the history and the audit trail, the database administrator removes the databases `finesiii_v3` and `finesiii_audit` and the login `finesiii_app` in pgAdmin.

---

# Part F — Reference

## 22. Troubleshooting by step

> **In plain words.** Each table lists what you see, the likely cause and what to do. Every script can be run again safely after a correction.

**Who does this:** Server team, Database administrator, Developer.

**Where to look.** Prerequisites: `C:\FINESIII\data\logs\setup_<date>_<time>.log`. Database script: `setup_database_<date>_<time>.log` in the same folder. Start-up: `agent.log`. Running service: `finesiii_rpa_v3.log`. Task: **Task Scheduler › AIG › FINESIII RPA Agent › History**. Console: **System** page. For support, send **System › Download diagnostics** (passwords masked), the newest setup logs, the output of `desktop\app.py --selftest --json` and `--check-db --json`, and the exact message with its time.

### 22.1 Step 2 - copying the package

| What you see | Likely cause | What to do |
|---|---|---|
| `MISSING <file>` | Incomplete copy or extraction | Extract the package completely and copy it again |
| `CHANGED <file>` | Altered in transit, by an editor or by a scanner | Copy that file again from the original package; if it keeps changing, ask security whether a scanner modifies it |
| Scripts refuse to run or ask for confirmation | Files marked as downloaded | `Get-ChildItem -Recurse -File \| Unblock-File` in `C:\FINESIII\app` |

### 22.2 Step 3 - Setup_Prerequisites.ps1

| What you see | Likely cause | What to do |
|---|---|---|
| "running scripts is disabled on this system" | Execution policy | Type the full command with `-ExecutionPolicy Bypass` |
| **Operating system**: ... is 32-bit; a 64-bit Windows is required | Wrong operating system | Use a 64-bit server |
| **Application files**: missing: ... Copy the complete application folder again. | Incomplete copy | Section 22.1 |
| **Administrator rights**: not an administrator window... | Not started with **Run as administrator** | Open an administrator window |
| **Free disk space**: ... at least 5 GB is recommended | Low disk space | Free space, or use a larger drive with `-DataDir` |
| **Folder path length**: ... Use a short folder such as C:\FINESIII\app | Long path | Use the standard folder |
| ... not reachable from this server (use -Proxy...) | No direct internet access | Add `-Proxy http://<proxy-host>:<port>` |
| download of ... failed / ... a proxy or sign-in page was returned instead of the file | Download blocked | Use `-Proxy`, or download the named file on another machine and place it in the folder the message names |
| refusing to run ... its SHA-256 checksum does not match / its digital signature is not valid / it is not signed by ... | Not the genuine installer, or altered by a proxy | Download it again from the named address. Never bypass the check. |
| **Python 3.13**: not available. Install the 'Windows installer (64-bit)' of Python ... | Installation did not complete | Install that exact version by hand (no PATH change needed), then run again |
| **Visual C++ runtime**: not installed. Run this script in an administrator window... | Not elevated, or download blocked | Run as administrator, or install the Microsoft package by hand |
| a restart of the server is required to finish this installation | Visual C++ runtime | Restart the server, then run again |
| **Python environment**: was made with another Python version... | An old `.venv` | Run without `-CheckOnly`; the environment is rebuilt |
| ... pip ended with exit code ...; the message above names the package | Download blocked or proxy authentication | Use `-Proxy`; read the pip message above the line |
| ... installed but do not load: ... | Usually the Visual C++ runtime; for screen reading, a processor without AVX support (some virtual machines) | Fix the runtime and run again; otherwise ask the infrastructure team to expose AVX to the virtual machine |
| **OCR models**: not found in ... | The `models` folder was not copied | Copy it from the package and repeat the checksum check |
| **FINESIII_DATA_DIR**: not set / is ..., expected ... | Not elevated, or another `-DataDir` used earlier | Run in an administrator window with the intended `-DataDir`, then open a fresh window |
| **Stored credentials**: found for this Windows account: ... | Passwords of an earlier installation in this account's store | For a clean start remove them as that account (section 21, step 2) |
| **Port 8000**: in use by ... | Another program | Acceptable: the service uses another port and shows it. Or stop the other program. |
| **Self-test**: produced no report... | The self-test itself could not run | Run `.\.venv\Scripts\python.exe desktop\app.py --selftest` by hand and see 22.6 |

### 22.3 Step 4 - folder permissions and the bot account

| What you see | Likely cause | What to do |
|---|---|---|
| "No mapping between account names and security IDs was done" | Bot account name mistyped | Use `DOMAIN\name`; check it with `whoami` while signed in as the bot |
| "Access is denied" from `icacls` | Not elevated | Use an administrator window |
| `icacls` on `.env`: "The system cannot find the file specified" | Step 3 did not create the settings file | Run step 3 again |
| As the bot: "Permission denied" on the data folder, `agent.json` or the logs | Step 4 skipped or used another account | Repeat step 4 with the right account |
| An administrator gets "Access is denied" in the folders | The window is not elevated | Use an administrator window |
| `icacls` still lists `Users` or `Authenticated Users` | `/inheritance:r` left out | Repeat the commands exactly |

### 22.4 Steps 5 and 6 - RDS connection and Setup_Database.py

| What you see | Likely cause | What to do |
|---|---|---|
| `Test-NetConnection`: "Name resolution of ... failed" | DNS cannot resolve the endpoint | Check the spelling; the network team checks DNS for the AWS private zone |
| **TcpTestSucceeded : False** | Security group, network ACL, firewall or routing | Compare the address the security group allows with the server's address (`ipconfig`) |
| The PostgreSQL driver is not installed in this Python... | Another Python used | Use `.\.venv\Scripts\python.exe` in `C:\FINESIII\app` |
| --rds needs the endpoint of the cluster: --host <endpoint>... | `--host` missing | Add `--host <rds-endpoint>` |
| --host takes the endpoint alone, without a scheme, a login or a port... | `postgresql://`, a login or `:5432` in `--host` | Give the endpoint only; the port is `--port` |
| With --rds give the endpoint with --host, not addresses... | Addresses mixed with `--rds` | Use one form or the other |
| **Certificate bundle**: ... is missing. It is part of the application package (certs folder)... | `certs` folder not copied | Copy it from the package |
| The password of the application login is generated and kept in the credential store of this account, and there is none here (...) | Not run as the bot account in a normal sign-in | Sign in as the bot by remote desktop and run it in a bot window |
| the host name '...' is not known on this machine... | DNS | As above |
| The cluster ... cannot be reached from this machine: the name does not resolve on this network, or the cluster's security group or a firewall on the way does not let this server through to port 5432. | Network path | Section 12.2 |
| The password of '<master-user>' is not correct. Take the current one from the password vault: it is changed regularly. | Wrong or rotated master password | Paste the current one |
| The server's certificate could not be checked against the AWS bundle... | Old bundle, or an alias or address used as `--host` | Use the endpoint name exactly as in the AWS console; refresh the bundle (20.5); for an alias use `--tls require` |
| The cluster refused '...' from this machine, or a connection without encryption... | Login name wrong, or encryption not used | Check the login name; use the commands as given (they always encrypt) |
| **Administrator rights**: '...' is not a superuser and may not create logins and databases... | The login is not the master user | Use the master user, or section 13.4 B |
| **Password of 'finesiii_app'**: the login exists, and its password is not in the credential store of this account... | Run by another Windows account than before | Run as the bot account that ran it before, or add `--set-password` |
| **Login '...'**: exists but is not allowed to sign in | Created without the login right | The database administrator runs `ALTER ROLE finesiii_app LOGIN;`, then run again |
| **Database '...'**: could not be created: ... | No right to create databases | Use the master user |
| **Database '...'**: encoding is ...; UTF8 is required... | A database created with another encoding | Use another database name (`--database`), or have it recreated in UTF8 |
| **Tables**: missing: ... The login '...' is not allowed to create tables in this database... | Address form without `--admin-url` on an empty database | Add `--admin-url`, or section 13.4 B |
| **Table owner**: the application login '...' owns: ... | Tables created by the application login | Run again with the administrator and `--fix-ownership` |
| **Protection of the history**: NOT enforced by the database... | As above | `--fix-ownership` with the administrator |
| **Rights needed by the application**: missing: ... Run the script with --admin-url. | Grants missing | Run with the administrator |
| **Time per database call**: about ... ms (the server is far from this machine)... | Over 100 ms per call | The service works but is slower; review where the instance and server are placed |
| **Settings file**: could not be written: ... | The bot cannot write `.env` | Step 4, `.env` line |

**Sample (QA):** `--host rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com`; in the password message `<master-user>` reads `dbadmin`.
| **Setup**: unexpected problem: ... | Something the script does not recognise | Keep the log and contact support |
| `--check-db`: **Hint : The user name or password is wrong.** | Run as another Windows account, or the password changed | Run as the bot account; section 20.4 |
| `--check-db`: **Hint : The database has not been created — ask the DBA to run the setup scripts.** | Wrong name, or step 6 not done | Run step 6 |
| `--check-db`: **Error : Connected to ..., but the application tables are missing** | Step 6 not completed | Run step 6 |
| `--check-db`: **Engine : sqlite** | Not run in `C:\FINESIII\app` | `cd C:\FINESIII\app` first |

### 22.5 Step 7 - starting the service

| What you see | Likely cause | What to do |
|---|---|---|
| **[STOP] Another AIG IAM Access RPA desktop instance is already running (lock: C:\FINESIII\data\agent.lock)** (exit code 3) | A copy already runs, for example from the task | Use it, or stop it with `--stop` first |
| **[FATAL] The database cannot be reached (...): .... Correct DATABASE_URL in C:\FINESIII\app\.env (or DATABASE_ENGINE), then start again.** | RDS unreachable, DNS, or a wrong address | `--check-db` and 22.4; change the address only with the database script (20.3) |
| **[FATAL] Configuration is not valid: ... must be one of: ... (got '...')** | A machine setting has an unknown value | Open `C:\FINESIII\app\.env` in Notepad (administrator window), correct that line or copy back the newest `.env.bak-<date>` kept by the console (next to `.env` or in `C:\FINESIII\data\backups`), then start again |
| **[FATAL] Cannot read .env: ... — check the service account's permissions** | The bot cannot read the settings file | Step 4 |
| **[FATAL] The service did not become ready — see the log above.** | A start-up error | Read the lines above it in `agent.log` or the window |
| **[FATAL] The service did not start: database password from CyberArk: ...**, or **[FATAL] The service did not start: ...** after up to 5 minutes | The database password from CyberArk is switched on (section 13.7) and could not be obtained; the launcher tries again every 60 seconds | Section 22.9 for the reason. To start without it, set `CYBERARK_DB_ENABLED=false` in the file that holds it (`C:\FINESIII\data\finesiii.env` or `.env`, administrator window) and follow the way back of section 13.7 |
| **[WARN] credential vault not consulted: ...** | Credential Manager unreadable | Run as the bot account in an interactive session; keep the task **Interactive** |
| **Terminal executor could not be built — ...**, then **Ready** | The console works, but requests are not processed: service-account values missing (section 16), invalid error rules, or screen reading cannot load | Read the reason on the **System** page; correct it; restart |
| Console and System page: **This server's clock is not on Japan time (it is UTC...)...** | Wrong time zone | Section 10.2, then restart the service |
| **The desktop window is not part of this delivery. Use --agent to start the bot and --stop to stop it.** (exit code 2) | `desktop\app.py` started without an option | Use `--agent` |
| The address shows a port other than 8000 | Port 8000 was taken | Use the address shown; `agent.json` always has it |

### 22.6 Self-test

| Component | What you see | Likely cause | What to do |
|---|---|---|---|
| (start) | **[WARN] configuration did not load: ...** | A setting is not valid (named) | Correct it; the **database** line then shows **n/a** |
| tkinter (simulator window) | `No module named 'tkinter'` | Python installed without Tcl/Tk | Repair Python 3.13 (**Settings › Apps**, **Modify**, tick **tcl/tk**); needed for the visible simulator only |
| paddlex metadata | Package metadata missing | Screen-reading packages incomplete | Run step 3 again |
| ocr engine | Model not found | `models` folder missing or incomplete | Copy it again and repeat the checksum check |
| ocr engine | "DLL load failed" | Visual C++ runtime missing | Step 3 in an administrator window |
| ocr engine | **the engine loads but cannot read: ...**, or the process ends abruptly | Processor without AVX support | Ask the infrastructure team to expose AVX |
| error catalogue | Not found, or a YAML error naming a line | `config\errors.yaml` missing or edited incorrectly | Restore it from the package or the backup; the service refuses to process while it is invalid |
| credential vault | No credential store | A session without a loaded user profile | Run as the bot account in a normal desktop session |
| database | The same errors and hints as `--check-db` | See 22.4 | See 22.4 |

### 22.7 The console

| What you see | Likely cause | What to do |
|---|---|---|
| "This site can't be reached" | The service is not running, or uses another port | Section 15.5; use the address in `agent.json` |
| The page looks unstyled or out of date | Cached files of an earlier version | Ctrl+F5 |
| **Invalid username or password** with the one-time password | Mistyped, already changed, or the account is locked after 5 wrong attempts (15 minutes) | Wait 15 minutes; if lost, `.\.venv\Scripts\python.exe desktop\app.py --reset-console-password admin` as the bot account, type a provisional password twice, then sign in and choose your own |
| **Too many failed sign-in attempts. Wait N second(s) and try again.** | Repeated wrong passwords | Wait as shown; each wrong attempt makes the wait longer |
| `admin` signs in with `ChangeMe!2026` instead of a one-time password | The one-time password was not in the bot's store at the first start (script run as another account, `--console-admin skip`, or removed by a test instance) | Choose your own password at once; the **System** page shows a warning until you do |
| **This service runs as ..., but it was set up to run as ...** | The service was started by another Windows account | Stop it; start it with the scheduled task |
| **Database** card **Unavailable** | RDS unreachable after start | 22.4; requests wait until the database answers |
| **Not restarted: the database password from CyberArk could not be obtained: ... The service keeps running as it was.** after **Save and restart** or **Restart service** | The database password from CyberArk was switched on or changed and the password could not be read or applied | Nothing changed; section 22.9 for the reason, then restart again |
| A setting shows **Saved — applies when the bot is stopped and started again**, and the console keeps the old port after **Restart service** | **Service port** or **Refuse another port** changed | Stop the bot and start it again (section 18); then open the new address and correct the desktop shortcut |
| After a save: **Restart the service to apply these. E-mail is switched on by this change (Default recipients is empty).** (or **off**) | **Default recipients** is empty, and the change of a team or support-report list switches e-mail as a whole on or off | Click **Restart service**. Until then the e-mails stay as they were. |
| **Not reset: the password ...** from `--reset-console-password` | The provisional password does not follow the console's password rules (for example the minimum length saved in the console) | Run it again with a longer password |

### 22.8 Step 8 - background service and scheduled task

| What you see | Likely cause | What to do |
|---|---|---|
| `Register-ScheduledTask`: "No mapping between account names and security IDs was done" | Bot account name wrong | Correct it (22.3) |
| `Register-ScheduledTask`: "Access is denied" | Not elevated | Administrator window |
| `LastTaskResult` `267011` | The task has not run | Check that the trigger and **Run as** show the bot account and that the task is enabled |
| `LastTaskResult` `2147942402` (file not found) | Program or start folder wrong | **Actions**: program `C:\FINESIII\app\.venv\Scripts\pythonw.exe`, argument `Start_FINESIII_Service.pyw`, **Start in** `C:\FINESIII\app` |
| `LastTaskResult` `2147943645` | The bot account was not signed in | Sign in as the bot account, then start the task |
| The task runs, but `agent.log` has no `LAUNCHER` lines | Launcher missing or damaged | Run it visibly: `.\.venv\Scripts\python.exe Start_FINESIII_Service.pyw`; recreate it with 15.2 |
| `LAUNCHER \| the service stopped unexpectedly (exit code 1); starting it again in 60 seconds`, repeating | The service fails at start; the lines above name the reason | Fix the cause (22.5). To watch the start directly, `--stop`, then start in the foreground with `desktop\app.py --agent`. |
| **Stopped (drain timed out — see the log).** followed by a launcher restart | A transaction did not finish within 5 minutes of a stop | Check the transaction on the **Dashboard**; stop again when it is idle |
| `LAUNCHER \| the service is already running; the launcher ends` | A copy was started by hand before the task | That copy has no recovery: `--stop`, then `Start-ScheduledTask` |
| `--stop`: **[WARN] The agent is still running — a transaction may be in progress. It will stop when the drain completes.** (exit code 1) | A transaction is finishing (up to about 5 minutes) | Wait, then run `--stop` again |
| `--stop`: **An agent is running but not answering — asking it to stop…** | The service is unresponsive | Wait and try again; as a last resort end the process named in `agent.json` from an administrator window |
| The service stops when the bot's remote-desktop session is signed out | By design | Follow the session policy of 15.6, or an unattended option (15.8) |
| **System** page: **Requests wait: the bot's Windows session is locked. Keep the bot's session signed in, unlocked and not minimized; processing resumes by itself.** (or **... is disconnected**), requests stay **Queued**, e-mail **Bot Windows session Not Available** | The bot's session was locked, or its remote-desktop window was closed | Sign in to the bot's session and unlock it; for leaving the server use **Leave Bot Running** (15.8). Processing resumes by itself; **Bot Windows session Recovered** follows. |
| **Requests wait: Windows did not accept the bot's keystrokes (the bot's remote desktop window may be minimized). ...**; a request failed with that reason | The bot's remote-desktop window was minimized | Restore the window; set `RemoteDesktop_SuppressWhenMinimized` on the connecting computer (15.7). The bot checks again at most once a minute. Retry the failed request after checking its evidence. |
| Requests wait every time the person who connected leaves | The remote-desktop window is closed (disconnect) or the screen is locked when leaving | Use **Leave Bot Running** (options A to C), or option B or D (15.8) |
| `Setup_Unattended.ps1`: **[FAIL] Missing: ... Install the application first (Setup_Prerequisites.ps1) and copy the whole package, including the folder 'unattended'.** | The `unattended` folder or the Python environment is missing | Copy the folder from the package; run step 3 |
| `Setup_Unattended.ps1` or `Check_Unattended.ps1`: **WARN** about a company policy that locks the screen | A group policy locks the screen after a time or with the screen saver | Ask IT for an exception for this server; otherwise requests wait whenever the screen locks |
| `Check_Unattended.ps1`: **[FAIL] Task 'FINESIII RPA Agent' is missing.** | `Setup_Unattended.ps1 -Remove` was run, or the task was deleted | Run `Setup_Unattended.ps1` again, or register the task with 15.3 |
| After `Setup_Unattended.ps1` the task starts `unattended\Start_FINESIII_Service.pyw` instead of the launcher of 15.2 | By design | Nothing to do: both launchers behave the same |
| **Terminal started as administrator: Yes** and **This service runs as administrator: No** | Task registered with `-RunLevel Limited`, or the service started from a normal window | Register the task with `-RunLevel Highest` (15.3), or use the alternative of section 8 |

### 22.9 Optional - database password from CyberArk

The console names the reason in plain words, without login names; the service log (`finesiii_rpa_v3.log`) and the audit trail keep the technical reason.

| What you see | Likely cause | What to do |
|---|---|---|
| **CyberArk did not deliver the account: CyberArk availability check failed (Inactive) — fetch skipped: ... certificate verify failed ...**; on the card or after **Not restarted**: **the bot does not trust the CyberArk certificate (set CyberArk certificate file)** | The CCP certificate is issued by the company's own certificate authority | **Create from Windows certificates**, test, **Save and restart** (section 13.7, the internal certificate bundle) |
| **... (Inactive) — fetch skipped: ConnectTimeout ...**, **ConnectError ...** or a name that does not resolve | Port 443 to the CCP address blocked, or DNS | The network team opens port 443 from this server to `<ccp-address>`, or fixes the name |
| **CyberArk certificate file: the certificate file ... does not exist on this machine. Nothing was saved.** (or **cannot be read**, or **holds no certificate in PEM form**) | Wrong path, a file the bot account cannot read, or a file in another format | Correct the path, or create the file again; it must hold `-----BEGIN CERTIFICATE-----` blocks |
| **CyberArk delivered the account <name>, not <admin login>: check the object name.**, or **CyberArk returned another account than the database administrator (check CyberArk object (database))** | Wrong user name: the object points at another account, or **Database administrator login** differs | Copy the object again from CyberArk, or correct the login |
| An answer with **403** (for example **APPAP227E**) | Access denied: the Application ID may not read the account from this server | The PAM team adds this server to the Application ID's allowed machines |
| An answer with **404**, or the object is not found | Safe or object misspelt, or no access to the safe | Copy both again; the PAM team checks the safe's members |
| **CyberArk is changing the password right now. The bot keeps using the password it has until the change is finished; try again in a minute.**; the card shows **Previous password in use** | Password change in process: CPM is rotating it | Wait a minute; the bot asks again by itself |
| Answers of **Validate database password** start with **Not checked: ...** (CyberArk did not deliver), **The password could not be checked with the database: ...** (same password, the database step failed) or **The new password from CyberArk could not be applied: ...** (a newer password), and end with the password the bot keeps using, for example **The bot keeps using the previous password until the new one can be applied.** | The reason in the middle names the cause; the rows below list them | As in the row of that reason |
| **... the database administrator account refused the password from CyberArk. Ask the PAM team to check the account in CyberArk** | Database password copy refused: the password in CyberArk is not the one the database has | The PAM team reconciles the account in CyberArk; then **Validate database password** |
| **... the database administrator account could not change the bot's database password. Ask the database team to check its rights** | The administrator login may not change the password of `finesiii_app` | The database administrator grants the right; then validate again |
| **... the database did not accept the password from CyberArk for the bot. Ask the database team to check the bot's database account** | The copy ran, but `finesiii_app` still refuses the password | The database administrator checks the login `finesiii_app` (for example that it may sign in) |
| **... the database administrator account could not sign in. Ask the PAM team to check the account in CyberArk** | The administrator login could not connect with the password from CyberArk | The PAM team checks the account in CyberArk; the database administrator checks the login's access to `finesiii_v3` |
| **... the password from CyberArk could not be applied (see the service log)** | A reason the console does not put into plain words | Read the service log `finesiii_rpa_v3.log` for the technical reason |
| **Database password from CyberArk: DATABASE_URL contains a password: remove it, the password comes from CyberArk. Nothing was saved.** | A password was typed into **Database URL** | Keep the address the database script wrote |
| **Database password from CyberArk: DATABASE_URL must name the application login, not <admin login>. Nothing was saved.** | **Database URL** names the administrator | Use `finesiii_app` in the address |
| **Database password from CyberArk: DATABASE_ENGINE must be postgres. Nothing was saved.** | The database is the built-in file | Use this option only with RDS |
| **Not restarted: the database password from CyberArk could not be obtained: ... The service keeps running as it was.** | Any of the reasons above, found when **Save and restart** or **Restart service** applied the setting | Correct the reason named; restart again |
| **A check ran a moment ago; try again in N seconds.** | **Validate database password** was clicked within 30 seconds | Wait and click again |
| **The database password does not come from CyberArk on this server: the machine setting "Database password from CyberArk" is off. The bot uses the stored database password.** | **Validate database password** next to **Database URL** used while the option is off | Nothing to do, or set up section 13.7 |
| **Database password** card **CyberArk not reachable**, and the e-mail **CyberArk not available: the database password could not be checked** | CyberArk does not answer | The bot keeps the password in use and requests continue; the PAM or network team restores CyberArk; **CyberArk (database password) Recovered** follows |
| E-mail **Database password not updated: the bot keeps working with the password in use** after a rotation; card **Previous password in use** with **Last attempt failed** | Giving the new password to `finesiii_app` failed 3 times in a row | Requests continue. Fix the reason shown on the card (rows above); the next good check ends it by itself with **Database password updated: the bot uses the current password from CyberArk**, or click **Validate database password** |
| E-mail **Bot's database login set back to the password in CyberArk** | The password of `finesiii_app` was changed outside CyberArk (by hand, in pgAdmin, or with `Setup_Database.py --set-password` while the service ran) | Nothing to do for the bot. The database team finds out who changed it; database script runs follow the safe order of section 13.7 |
| `Setup_Database.py`: **Sign-in as 'finesiii_app'** ... **exists with another password ...** at step 7/8, while the option is on | The script used the password stored at installation; `finesiii_app` has the CyberArk password | Use the safe order of section 13.7 (`--admin-password-from-cyberark --set-password`, service stopped) |
| `scripts\setup_rds_database.py` stops after its check while the option is on | The same cause | Use `Setup_Database.py` in the safe order of section 13.7 |
| Save refused: **Database password from CyberArk: enter CyberArk address (database); enter CyberArk Application ID (database). Nothing was saved.** | The option is on and the address or the Application ID of the database account is empty | Enter both on **Settings › This machine › Database**, test, save again |

**Sample (QA):** port 443 is opened to `pamccp.aig.net`; in these messages `<admin login>` reads `dbadmin`.

### 22.10 Optional - production mode

| What you see | Likely cause | What to do |
|---|---|---|
| Saving **Terminal driver** `pywinauto`: **In production a real terminal driver requires the mainframe password to come from CyberArk — enable and test the CyberArk module first.** | **Service environment** is `production` and **Settings › CyberArk** is off | Set up and test CyberArk first (Administrator Guide), then save again |
| **System** page: **CyberArk is required here (require_cyberark with a real terminal driver) but is not enabled or did not start. ...**; requests are not processed | Production with the real terminal set in a settings file, CyberArk off or not started | Switch on and test **Settings › CyberArk**, then **Restart service** |
| **CyberArk is required here but has not delivered the mainframe password yet — ... Processing is paused and resumes automatically once CyberArk delivers the password.** | CyberArk did not answer the first request for the Fujitsu Mainframe password | Nothing to do when CyberArk comes back; otherwise check the CyberArk settings and the network (port 443) |
| **CyberArk is required here but no Fujitsu RACF account is set (CYBERARK_TSS_OBJECT or CYBERARK_TSS_ACCOUNT_USERNAME); Fujitsu RACF requests wait in the queue.** | Production, Fujitsu RACF on, its CyberArk account not in the settings file | Add the lines of section 16.2, step 2, then stop and start the service |
| **CyberArk has not delivered the Fujitsu RACF password yet; Fujitsu RACF requests wait in the queue.** | CyberArk has not answered for the Fujitsu RACF account | Check the object name and the safe with the PAM team |
| **Requests are accepted without an API key...** in red under **Needs attention** | `AUTH_ENABLED=false` still in `.env` | **Require the machine API key** On (section 16.2, step 3), then **Save and restart** |
| Fujitsu Mainframe refuses the bot's sign-in after the switch | **Mainframe environment** left at the production default; the host expects `99` (or the other way round) | Set **Mainframe environment** as the host expects, then **Save and restart** |
| **Retry** is refused for a failed provisioning request | Production keeps the password of a failed request for 0 days | As designed; a new request is needed, or set **Keep the password of a failed request for (days)** as the organisation decides |
| E-mails reach only the testers; the **Dashboard** shows a warning | **Send every e-mail only to (testing)** still holds addresses | Empty it on **Settings › E-mail** |

## 23. Security considerations

> **In plain words.** The installation follows least privilege wherever the product allows, encrypts and verifies every database connection, keeps every password in Windows Credential Manager, and records who did what.

**Who does this:** Server team, Database administrator, Developer.

- **Least privilege in the database.** The application login cannot create logins or databases, cannot delete requests, and cannot change or delete the transaction history or the audit events; the database enforces this because the master user owns the tables. A database created by the script is closed to the other logins of the instance. The master user is used only during setup runs and stored nowhere.
- **Least privilege on the server.** The application and data folders are limited to SYSTEM, Administrators and the bot account. On the main path the bot account is a local administrator because the terminal runs as administrator; this gives the service full rights on the server, so access to the bot account, its password and its desktop session is limited to the operations team. Where the terminal works without administrator rights, the alternative of section 8 removes those rights.
- **Encryption in transit.** Every database connection uses TLS with `verify-full`: the server's certificate is checked against the AWS bundle and must match the endpoint name. `rds.force_ssl = 1` makes RDS refuse any unencrypted connection. The console listens only on `127.0.0.1` and is never reachable over the network.
- **Secrets in Credential Manager.** The database password, the service-account values, the mail, ServiceNow and CyberArk passwords and the machine API keys are kept in the bot account's Windows Credential Manager, protected by Windows for that account. Passwords are typed without being shown and never appear in the command history, the settings files, the setup reports or the diagnostics download. The application password is generated (32 characters) and never shown.
- **Database password from CyberArk (optional).** With section 13.7 the bot reads the administrator's password from CyberArk over a certificate-checked connection only, never shows, logs or stores it, signs in as the administrator only to copy a changed password, and sends only its SCRAM-SHA-256 verifier. The application login keeps its limited rights. The PAM team's written agreement to this copy is kept with the change record.
- **Verified software.** Python and the Visual C++ runtime are installed only after their checksum and publisher signature are checked. The package and every update are checked file by file against SHA-256 checksums.
- **RDS settings.** Security group limited to this server on port 5432; no public access; `rds.force_ssl = 1`; automated backups and deletion protection; encryption at rest as the organisation's AWS standard requires; a maintenance window outside the operating window.
- **Folder access and evidence.** Evidence screenshots can show initial passwords of new accounts; only the bot and administrators can read them, and they are deleted after the retention period (default 90 days). Back-ups of the data folder need the same protection.
- **Audit.** The audit trail in `finesiii_audit` records sign-ins, settings and credential changes, evidence views, user changes and the bot's work, and cannot be changed by the application. Every person uses their own console account. Setup runs are kept in the setup logs; the task history is in Task Scheduler.
- **Before production use** a Developer switches on the machine API key and the Production environment, and CyberArk supplies the terminal passwords (section 16.2). **Send every e-mail only to (testing)** is empty in production.
- **The bot's desktop session.** The bot's session stays signed in and unlocked so that Windows takes its keystrokes; the unattended options switch off the screen lock for the bot account only, with the approval of information security (section 15.8). Access to that session is limited to the operations team.

## 24. Assumptions and limitations

> **In plain words.** These are the conditions the installation relies on and the things it does not do.

**Who does this:** Server team, Database administrator.

- The Amazon RDS for PostgreSQL (or Aurora PostgreSQL) instance exists, is managed by the organisation and is reachable from the server on port 5432.
- The application runs from the delivered package as a background service of the bot's Windows account, started by a scheduled task and the launcher written in step 8. A signed installer is not part of the delivery.
- The bot needs an interactive, unlocked desktop session, whose remote-desktop window is not minimized, for the real terminal. While it is not available, requests wait in the queue; signing the bot account out stops the service.
- There is no import of settings from another server. **Export configuration** gives a CSV file with the secrets masked, for change control; a new server is set up in its console.
- While the database password comes from CyberArk, the database script must be run in the order of section 13.7, and `scripts\setup_rds_database.py` cannot be used.
- The audit events already kept in the local audit file are not copied when the audit trail is moved to the audit database.
- The console is reachable only on the server itself. People sign in to the server by remote desktop to use it.
- The service signs in to the database with a password kept in Credential Manager, or, with section 13.7, with the administrator's password read from CyberArk (CCP only) and copied to its own login. AWS IAM database authentication and automatic rotation through AWS Secrets Manager are not supported; password changes follow section 20.4.
- Several servers that each have their own credential store are not covered by this guide: each server is installed and set up on its own.
- The bot changes the Fujitsu Mainframe service-account password on Task 0890 only when a Developer asks for it, or automatically when that is switched on; it cannot change the Fujitsu RACF password and only reminds.
- Commands are written for Windows PowerShell 5.1 and the standard folders. Folder paths must not contain spaces.
- Times given are from the product's own installation notes and depend on network speed.

## 25. Glossary

| Term | Meaning |
|---|---|
| Application folder | `C:\FINESIII\app`: the program and the setup scripts |
| Data folder | `C:\FINESIII\data`: logs, evidence, service keys and state |
| Bot account | The Windows account the service runs as |
| Credential Manager | The Windows store for passwords, one per account |
| RDS endpoint | The host name of the Amazon RDS instance (or Aurora writer endpoint) |
| Master user | The administrator login created with the RDS instance |
| Application login | `finesiii_app`: the database login the service uses, with no administrative rights |
| `verify-full` | Encrypts the connection and checks the server's certificate against its name |
| Certificate bundle | The file of AWS certificate authorities used for that check |
| Security group | The AWS firewall rules in front of the RDS instance |
| Scheduled task | The Task Scheduler entry that starts the launcher at the bot's sign-in |
| Launcher | The small program that runs the service without a window and restarts it after an unexpected stop |
| Foreground / background | In a PowerShell window that must stay open / without any window |
| Test mode | Development environment with the simulator: nothing reaches Fujitsu Mainframe or Fujitsu RACF |
| Update folder | A delivery that holds only changed files, with a precheck list and a contents list |
| CyberArk CCP | CyberArk's Central Credential Provider: the web service from which the bot reads a password with its Application ID |
| PAM / CPM | The team that manages privileged accounts in CyberArk / CyberArk's component that changes their passwords on a schedule |
| Fujitsu Mainframe / Fujitsu RACF | The two applications the bot works on; Fujitsu RACF is optional and switched off after the installation |
| Bot's Windows session | The signed-in desktop session of the bot account, where the terminal windows run; it must stay signed in, unlocked and not minimized |
| Unattended option | One of the set-ups A to D of the `unattended` folder that keep the bot's session available while nobody is connected |
| Production mode | **Service environment** `production`: CyberArk required for the terminal passwords, machine API key required, stricter defaults (section 16.2) |
| Safe order | The way to run the database script while the database password comes from CyberArk: service stopped, `--admin-password-from-cyberark --set-password`, then start (section 13.7) |

---

# Appendices

## Appendix A — Command sheet

> **In plain words.** Every command of the installation, in order, ready to copy.

**Who does this:** Server team.

**Administrator window - steps 1 to 3:**

```powershell
Add-LocalGroupMember -SID 'S-1-5-32-544' -Member '<DOMAIN>\<bot-account>'
New-Item -ItemType Directory -Force -Path 'C:\FINESIII\app'
# copy the package content into C:\FINESIII\app
cd C:\FINESIII\app
Get-ChildItem -Recurse -File | Unblock-File
Get-Content .\PACKAGE_CONTENTS.txt | Where-Object { $_ -match '^[0-9a-f]{64}  ' } | ForEach-Object { if (-not (Test-Path -LiteralPath $_.Substring(66))) { 'MISSING  ' + $_.Substring(66) } elseif ((Get-FileHash -Algorithm SHA256 -LiteralPath $_.Substring(66)).Hash -ne $_.Substring(0, 64)) { 'CHANGED  ' + $_.Substring(66) } }
powershell -NoProfile -ExecutionPolicy Bypass -File .\Setup_Prerequisites.ps1
Get-TimeZone | Select-Object Id, DisplayName
Set-TimeZone -Id 'Tokyo Standard Time'
# close this window
```

**Sample (QA):** the first line becomes:

```powershell
Add-LocalGroupMember -SID 'S-1-5-32-544' -Member 'R6-CORE\prvrnel'
```

**Fresh administrator window - step 4:**

```powershell
icacls 'C:\FINESIII' /inheritance:r /grant:r "*S-1-5-18:(OI)(CI)F" "*S-1-5-32-544:(OI)(CI)F" "<DOMAIN>\<bot-account>:RX"
icacls 'C:\FINESIII\data' /inheritance:r /grant:r "*S-1-5-18:(OI)(CI)F" "*S-1-5-32-544:(OI)(CI)F" "<DOMAIN>\<bot-account>:(OI)(CI)M"
icacls 'C:\FINESIII\app' /inheritance:r /grant:r "*S-1-5-18:(OI)(CI)F" "*S-1-5-32-544:(OI)(CI)F" "<DOMAIN>\<bot-account>:(OI)(CI)RX"
icacls 'C:\FINESIII\app\.env' /grant "<DOMAIN>\<bot-account>:M"
icacls 'C:\FINESIII\app\config' /grant "<DOMAIN>\<bot-account>:(OI)(CI)M"
```

**Sample (QA):**

```powershell
icacls 'C:\FINESIII' /inheritance:r /grant:r "*S-1-5-18:(OI)(CI)F" "*S-1-5-32-544:(OI)(CI)F" "R6-CORE\prvrnel:RX"
icacls 'C:\FINESIII\data' /inheritance:r /grant:r "*S-1-5-18:(OI)(CI)F" "*S-1-5-32-544:(OI)(CI)F" "R6-CORE\prvrnel:(OI)(CI)M"
icacls 'C:\FINESIII\app' /inheritance:r /grant:r "*S-1-5-18:(OI)(CI)F" "*S-1-5-32-544:(OI)(CI)F" "R6-CORE\prvrnel:(OI)(CI)RX"
icacls 'C:\FINESIII\app\.env' /grant "R6-CORE\prvrnel:M"
icacls 'C:\FINESIII\app\config' /grant "R6-CORE\prvrnel:(OI)(CI)M"
```

**Bot window - steps 5 to 7:**

```powershell
$env:FINESIII_DATA_DIR
(Select-String -Path 'C:\FINESIII\app\certs\rds-global-bundle.pem' -Pattern 'BEGIN CERTIFICATE').Count
Resolve-DnsName <rds-endpoint>
Test-NetConnection -ComputerName <rds-endpoint> -Port 5432
cd C:\FINESIII\app
.\.venv\Scripts\python.exe Setup_Database.py --rds --host <rds-endpoint> --admin-login <master-user> --audit-database finesiii_audit
# write down the one-time console password
.\.venv\Scripts\python.exe desktop\app.py --check-db
.\.venv\Scripts\python.exe desktop\app.py --agent
```

**Sample (QA):**

```powershell
$env:FINESIII_DATA_DIR
(Select-String -Path 'C:\FINESIII\app\certs\rds-global-bundle.pem' -Pattern 'BEGIN CERTIFICATE').Count
Resolve-DnsName rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com
Test-NetConnection -ComputerName rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com -Port 5432
cd C:\FINESIII\app
.\.venv\Scripts\python.exe Setup_Database.py --rds --host rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com --admin-login dbadmin --audit-database finesiii_audit
# write down the one-time console password
.\.venv\Scripts\python.exe desktop\app.py --check-db
.\.venv\Scripts\python.exe desktop\app.py --agent
```

**Second bot window - step 7:**

```powershell
cd C:\FINESIII\app
.\.venv\Scripts\python.exe desktop\app.py --selftest
Start-Process 'http://127.0.0.1:8000/'
# first sign-in as admin; choose your own password
.\.venv\Scripts\python.exe desktop\app.py --stop
```

**Administrator window - step 8:** the launcher block of section 15.2, then the task command of section 15.3, then:

```powershell
Start-ScheduledTask -TaskPath '\AIG\' -TaskName 'FINESIII RPA Agent'
Get-Content 'C:\FINESIII\data\agent.json' -ErrorAction SilentlyContinue
Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:8000/api/v1/ping' | Select-Object StatusCode, Content
Get-ScheduledTask -TaskPath '\AIG\' -TaskName 'FINESIII RPA Agent' | Get-ScheduledTaskInfo | Select-Object LastRunTime, LastTaskResult
Get-Content 'C:\FINESIII\data\logs\agent.log' -Tail 25 -Encoding UTF8
Set-Content -Path 'C:\Users\Public\Desktop\AIG IAM Access RPA.url' -Value "[InternetShortcut]`r`nURL=http://127.0.0.1:8000/" -Encoding ASCII
```

**Optional - unattended operation (section 15.8), administrator window, signed in as the bot account:**

```powershell
cd C:\FINESIII\app
powershell -NoProfile -ExecutionPolicy Bypass -File .\unattended\Setup_Unattended.ps1 -Option A -Account '<DOMAIN>\<bot-account>'
Start-ScheduledTask -TaskPath '\AIG\' -TaskName 'FINESIII RPA Agent'
powershell -NoProfile -ExecutionPolicy Bypass -File .\unattended\Check_Unattended.ps1
```

**Sample (QA):**

```powershell
cd C:\FINESIII\app
powershell -NoProfile -ExecutionPolicy Bypass -File .\unattended\Setup_Unattended.ps1 -Option A -Account 'R6-CORE\prvrnel'
Start-ScheduledTask -TaskPath '\AIG\' -TaskName 'FINESIII RPA Agent'
powershell -NoProfile -ExecutionPolicy Bypass -File .\unattended\Check_Unattended.ps1
```

**Optional - the database script while the database password comes from CyberArk (section 13.7), bot window:**

```powershell
cd C:\FINESIII\app
.\.venv\Scripts\python.exe desktop\app.py --stop
.\.venv\Scripts\python.exe Setup_Database.py --rds --host <rds-endpoint> --admin-login <admin login> --audit-database finesiii_audit --admin-password-from-cyberark --set-password
Start-ScheduledTask -TaskPath '\AIG\' -TaskName 'FINESIII RPA Agent'
.\.venv\Scripts\python.exe desktop\app.py --check-db
```

**Sample (QA):**

```powershell
cd C:\FINESIII\app
.\.venv\Scripts\python.exe desktop\app.py --stop
.\.venv\Scripts\python.exe Setup_Database.py --rds --host rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com --admin-login dbadmin --audit-database finesiii_audit --admin-password-from-cyberark --set-password
Start-ScheduledTask -TaskPath '\AIG\' -TaskName 'FINESIII RPA Agent'
.\.venv\Scripts\python.exe desktop\app.py --check-db
```

**After a change of Service port (section 16), bot window:**

```powershell
cd C:\FINESIII\app
.\.venv\Scripts\python.exe desktop\app.py --stop
Start-ScheduledTask -TaskPath '\AIG\' -TaskName 'FINESIII RPA Agent'
Get-Content 'C:\FINESIII\data\agent.json'
```

**Day to day:**

```powershell
Start-ScheduledTask -TaskPath '\AIG\' -TaskName 'FINESIII RPA Agent'
cd C:\FINESIII\app
.\.venv\Scripts\python.exe desktop\app.py --stop
Get-Content 'C:\FINESIII\data\agent.json'
Get-Content 'C:\FINESIII\data\logs\agent.log' -Tail 30 -Encoding UTF8
.\.venv\Scripts\python.exe desktop\app.py --selftest
```

## Appendix B — The settings files after installation

> **In plain words.** Two small text files decide how the service starts. Neither holds a password. The one in the application folder wins.

**Who does this:** Developer, Server team.

**Which value wins.** For each machine setting the service uses the first value it finds in this order: a Windows environment variable, then `C:\FINESIII\app\.env`, then `C:\FINESIII\data\finesiii.env`, then the built-in default. Passwords and keys come from the bot account's Credential Manager. Module settings (ServiceNow, e-mail, CyberArk, terminal, processing) are stored in the application database and changed in the console.

**`C:\FINESIII\app\.env` - the application settings file.** Created by the prerequisites script; the database script adds the database lines; the console changes a line in place when it saves a machine setting this file holds, keeping a dated backup (`.env.bak-<YYYYMMDD-HHMMSS>`, the newest five) first. Its setting lines after installation (the comment lines are left out here):

```
APP_ENV=development
API_PORT=8000
TERMINAL_DRIVER=simulator
SIM_SCENARIO=success
SIM_ACTION_DELAY=0.6
DATABASE_ENGINE=postgres
DATABASE_URL=postgresql://finesiii_app@<rds-endpoint>:5432/finesiii_v3?sslmode=verify-full&sslrootcert=C%3A%5CFINESIII%5Capp%5Ccerts%5Crds-global-bundle.pem&connect_timeout=10&keepalives=1&keepalives_idle=60&keepalives_interval=10&keepalives_count=5&application_name=finesiii-rpa
AUDIT_ENABLED=true
AUDIT_BACKEND=postgres
AUDIT_DATABASE_URL=postgresql://finesiii_app@<rds-endpoint>:5432/finesiii_audit?sslmode=verify-full&sslrootcert=C%3A%5CFINESIII%5Capp%5Ccerts%5Crds-global-bundle.pem&connect_timeout=10&keepalives=1&keepalives_idle=60&keepalives_interval=10&keepalives_count=5&application_name=finesiii-rpa
OCR_ENABLED=true
AUTH_ENABLED=false
```

**Sample (QA):** the two database lines as `Setup_Database.py --rds` writes them for the QA cluster:

```
DATABASE_URL=postgresql://finesiii_app@rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com:5432/finesiii_v3?sslmode=verify-full&sslrootcert=C%3A%5CFINESIII%5Capp%5Ccerts%5Crds-global-bundle.pem&connect_timeout=10&keepalives=1&keepalives_idle=60&keepalives_interval=10&keepalives_count=5&application_name=finesiii-rpa
AUDIT_DATABASE_URL=postgresql://finesiii_app@rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com:5432/finesiii_audit?sslmode=verify-full&sslrootcert=C%3A%5CFINESIII%5Capp%5Ccerts%5Crds-global-bundle.pem&connect_timeout=10&keepalives=1&keepalives_idle=60&keepalives_interval=10&keepalives_count=5&application_name=finesiii-rpa
```

| Lines | What they hold | Maintained by |
|---|---|---|
| Environment, port, terminal driver, simulator, screen reading, API key switch | How the service starts | Console (**Settings › This machine**, Developer) |
| Database engine, the two database addresses, audit trail | Where the data is | `Setup_Database.py` (change them only with it) |
| `CYBERARK_DB_*`, `DATABASE_ADMIN_LOGIN`, `CYBERARK_CA_BUNDLE` (only with section 13.7, when kept in this file) | Where the database password comes from, and the CyberArk certificate file | Console (**Settings › This machine › Database**, Developer) |
| `CYBERARK_TSS_OBJECT`, `CYBERARK_TSS_SAFE` (only with Fujitsu RACF in production, section 16.2) | The CyberArk account of the Fujitsu RACF sign-on ID | Server team, by hand (no console field) |
| `DESKTOP_SESSION_CHECK=false` (only when support asks, section 15.7) | Switches off the bot's Windows session check; absent means on | Server team, by hand (no console field) |

- The certificate location appears encoded (`%3A` is `:`, `%5C` is `\`). This is expected.
- **No line contains a password.**
- The service always listens on `127.0.0.1`, whatever the file says.

**`C:\FINESIII\data\finesiii.env` - the machine settings file.** Absent right after installation. The console creates it when a Developer saves a machine setting that `.env` does not hold (for example **Mainframe environment**, **Console sign-in may use the API**, or the CyberArk database settings of section 13.7). It is rewritten as a whole on each save, holds no passwords, and is read below `.env`.

> **Important.** Do not edit either file by hand unless support asks you to. When a value is set in both files, `.env` wins and the console shows the source of each value under **Settings › This machine** and on the **System** page under **Configuration files**.

## Appendix C — Installation record sheet

> **In plain words.** Keep a completed copy with the project records. Do not write passwords on it.

**Who does this:** Server team.

| Item | Value | Done by | Date |
|---|---|---|---|
| Server name | | | |
| Application folder / data folder | | | |
| Bot Windows account | | | |
| Bot account rights (Administrators, or the alternative) and approval | | | |
| Server time zone confirmed | | | |
| Package checksum check (no output) | | | |
| Prerequisites result (READY / with warnings) | | | |
| Folder permissions set and checked | | | |
| RDS endpoint and port | | | |
| RDS engine version | | | |
| Security-group rule (source) | | | |
| `rds.force_ssl` confirmed | | | |
| Application login / databases | | | |
| Database script result (READY / with warnings) | | | |
| One-time console password handed over (not written here) | | | |
| `--check-db` and self-test results | | | |
| First sign-in done, `admin` password changed | | | |
| pgAdmin shows `ssl = true` | | | |
| Launcher written; task registered (`-RunLevel Highest` or `Limited`) | | | |
| Automatic start, recovery and stop verified | | | |
| Bot desktop session policy | | | |
| Machine API key on before shared use | | | |
| People using the server, and their console roles | | | |
| Remote-desktop sessions and licensing agreed | | | |
| Backups confirmed (data folder, RDS) | | | |
| Optional test instance prepared | | | |
| Service-account password "last changed on" dates entered | | | |
| Optional: database password from CyberArk (CCP address, Application ID, safe, object, administrator login; certificate file; test results) | | | |
| Audit trail location (audit database or local file) | | | |
| Bot's Windows session check tested (lock, wait, recovery e-mails) | | | |
| Optional: unattended option set up (A, B, C or D) and `Check_Unattended.ps1` result | | | |
| Optional: the safe order of the database script with CyberArk recorded in the operations procedures | | | |
| Optional: Fujitsu RACF prepared and its three tests passed | | | |
| Optional: production mode switched (date, **Mainframe environment**, API key on, test recipients empty) | | | |
| Handed over to the console administrator | | | |
