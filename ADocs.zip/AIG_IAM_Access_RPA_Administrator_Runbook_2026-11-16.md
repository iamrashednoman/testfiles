# AIG IAM Access RPA — Administrator Runbook

## Commands from installation to daily operation — Windows Server 2022, Amazon RDS for PostgreSQL and CyberArk

| | |
|---|---|
| Document | Administrator Runbook |
| Product | AIG IAM Access RPA, version 3.0.0 |
| Date | 16 November 2026 |
| Platform | Windows Server 2022 (64-bit) application server; Amazon RDS for PostgreSQL (or Amazon Aurora PostgreSQL); CyberArk Central Credential Provider (CCP) |
| Audience | The administration team that installs and runs the bot: server administrators, database administrators, the PAM / CyberArk contact and console administrators |
| Purpose | The exact sequence of commands and console actions, from an empty server to a running, verified installation with the database password from CyberArk, and every routine task afterwards, each with the expected result and what to do when it differs |
| Related documents | Administrator Guide; Application Installation Guide; Fujitsu RACF e-mail list |

**What changed in this edition**

- First edition of the runbook. It follows the application as delivered on 16 November 2026.
- It covers the database password from CyberArk end to end: the settings, the command-line and console tests, the **Database password** card on the System page and the **Validate database password** button.
- It includes the bot Windows session check (requests wait while the bot's session is locked, disconnected or minimized) and the unattended operation scripts of the `unattended` folder.
- Part 2 (sections 14 to 22) covers daily operation, updates, passwords, backups, troubleshooting, removal and the reference tables.

---

## How to use this runbook

> **In plain words.** Work through Part 1 from top to bottom. Each step says who does it, in which window, what to type, what you should see, and what to do when you see something else. Do not skip a step; when a step does not apply, it says so.

**Conventions**

- **Bold text** is exactly what you see on the screen (a button, a page, a message).
- `Code text` is typed exactly as shown. Replace each `<placeholder>` with your value from the worksheet in section 2.
- Every command is written out in full, one command per line. Copy one command at a time.
- `[OK]` is the good result. `[NG]` is a common problem, written as symptom → cause → fix.
- **Good and bad cases** tables list what happens in each situation (Case | What happens).
- Each section ends with **Before you go on**: the checks that must be true before the next section.
- Never type a password inside a command. The scripts ask for passwords without showing them.
- Console paths are written like **Settings › This machine › Database**.

**The windows used in this runbook**

| Name in this runbook | What it is |
|---|---|
| **Administrator window** | Windows PowerShell opened with **Run as administrator**, signed in as a server administrator |
| **Bot window** | Windows PowerShell opened normally (not as administrator) while signed in to the server as the bot account |
| **Bot administrator window** | Windows PowerShell opened with **Run as administrator** while signed in as the bot account (the bot account is a local administrator on the main path) |
| **pgAdmin** | pgAdmin 4 of the database administrator, connected to the RDS instance |
| **Console** | The AIG IAM Access RPA console in Microsoft Edge or Google Chrome on the server, at `http://127.0.0.1:<console port>/` |

**Who runs what**

| Role | Sections |
|---|---|
| Server administrator | 3, 4, 5, 6, 7.1–7.2, 11 |
| Database administrator | 7.3, 8 (types the administrator password, or confirms CyberArk), 10.6 |
| PAM / CyberArk contact | 2 (inputs), 9 |
| Bot account (signed in by the server administrator) | 7, 8, 9.1, 10, 11 |
| Console administrator (Developer role) | 9.1 console steps, 9.2, 9.3, 10.5, 12, 13 |
| Project lead | 2 (worksheet), 13.8 (sign-off) |

> **Important.** The service reads every password from the Windows Credential Manager of the account it runs as, and each Windows account has its own store. Sections 7 to 10 are therefore done **signed in as the bot account**. A database script run as another account stores the passwords where the service never finds them.

> **Tip.** All commands use the folder `C:\FINESIII`. For another drive, make a copy of this runbook and replace `C:\FINESIII` with the new folder, and `C:/FINESIII` with the same folder written with forward slashes. The path must not contain spaces.

---

## Contents

**Part 1 — Installation**

1. What this runbook covers
2. Before you start
3. Prepare the server and the bot account
4. Copy and verify the package
5. Install the prerequisites
6. Folder permissions
7. Prepare the RDS connection
8. Create the databases
9. CyberArk integration
   - 9.1 Database password from CyberArk (CCP)
   - 9.2 Fujitsu Mainframe service-account password
   - 9.3 Fujitsu RACF sign-on password
10. First start and verification
11. Run in the background
12. Configure the console, module by module
13. End-to-end test and go-live

**Part 2 — Operation**

14. Daily operation commands
15. Applying an update folder
16. Passwords and secrets
    - 16.1 Database password rotated by CyberArk
    - 16.2 Fujitsu Mainframe service-account password
    - 16.3 Fujitsu RACF password
    - 16.4 Console administrator passwords, locked accounts, break-glass
    - 16.5 Certificates
17. Backup, restore and moving the database
18. Troubleshooting recipes
19. Removing the installation
20. Reference
21. Points to note
22. What was checked for this document

---

# Part 1 — Installation

## 1. What this runbook covers

> **In plain words.** AIG IAM Access RPA ("the bot") creates and removes user accounts in Fujitsu Mainframe and, where it is switched on, in Fujitsu RACF, following approved access requests that arrive from ServiceNow. It runs on one Windows server, inside the Windows session of its own account, and keeps its data in Amazon RDS. This runbook takes you from an empty server to that state, and then through daily operation.

**Who does this:** everyone in the table "Who runs what" above; the project lead reads this section first.

### 1.1 The path at a glance

```
 EMPTY SERVER                                                     LIVE SERVICE
 ------------                                                     ------------

  [3] Prepare server     bot account, administrator rights, time zone JST
        |
  [4] Copy package       C:\FINESIII\app, checksums verified
        |
  [5] Prerequisites      Python 3.13, packages, OCR models, data folder,
        |                FINESIII_DATA_DIR, starter .env
  [6] Permissions        icacls: SYSTEM, Administrators, bot account only
        |
  [7] RDS connection     certificate bundle, port 5432 reachable, TLS checked
        |
  [8] Databases          finesiii_v3 + finesiii_audit, login finesiii_app,
        |                one-time console password
  [9] CyberArk           database password (CCP); Fujitsu Mainframe and
        |                Fujitsu RACF passwords
  [10] First start       foreground start, self-test, check-db, first sign-in
        |
  [11] Background run    scheduled task + launcher, automatic start and recovery,
        |                session kept signed in and unlocked
  [12] Console set-up    ServiceNow, e-mail, CyberArk, Fujitsu Mainframe
        |                terminal, Fujitsu RACF (optional), tests
  [13] Go-live           end-to-end test, API key, production mode, sign-off
        |
  [14-22] Daily operation, updates, passwords, backups, troubleshooting
```

### 1.2 How a request travels

```
 ServiceNow ticket (SailPoint)          Console "New request" / API call
            |                                         |
            v                                         v
   +---------------------------------------------------------+
   | Intake: ticket checks, duplicate check  -> status queued |
   +---------------------------------------------------------+
            |
            v   waits while: outside the operating window, paused,
            |   host not available, bot Windows session locked
   +---------------------------------------------------------+
   | Dispatcher: one request at a time        -> status running|
   +---------------------------------------------------------+
            |
            v
   Fujitsu Mainframe terminal  or  Fujitsu RACF terminal (DSPEMU)
            |   screenshots and screen text kept as evidence
            v
   Result recorded: queue, transaction history, audit trail
            |
            v
   ServiceNow ticket closed or noted; e-mails to the people concerned
```

### 1.3 The statuses of a request

The same statuses apply to Fujitsu Mainframe and Fujitsu RACF requests. The **History** page also shows the current ServiceNow state of the ticket.

| Status (console) | Meaning | Final? |
|---|---|---|
| **Queued** (`queued`) | Accepted, waiting for its turn, the operating window or the host | No |
| **In progress** (`running`) | Being processed on the terminal | No |
| **Completed** (`done`) | Finished and confirmed on the screen | Yes |
| **Needs verification** (`done` with result `UNCONFIRMED`) | Submitted, but the result could not be confirmed on the screen. With **Close the ticket when the request failed** On (default), the ticket is closed as Closed Incomplete with a note asking for a manual check; no Fujitsu RACF completion ticket is created. | Yes |
| **Already removed** (`already_deleted`) | A removal was asked for, and the account no longer existed | Yes |
| **Failed** (`failed`) | Could not be completed after the allowed attempts | Yes (an operator may use **Retry**) |
| **Cancelled** (`cancelled`) | Cancelled by an operator before it started | Yes |

**Before you go on:** the project lead has read sections 1 and 2 and agreed the dates with each team.

---

## 2. Before you start

> **In plain words.** Each team provides one piece: a server, an account, a network path, a database login, CyberArk details, mail and ServiceNow access, and the mainframe accounts. Collect them on the worksheet before the day. Passwords are never written on the worksheet.

**Who does this:** Project lead, with each team.

### Step 2.1 Collect the inputs from each team

| Team | Provides | Needed in |
|---|---|---|
| Server team | Windows Server 2022 (64-bit), 5 GB free disk, the bot's Windows account `<bot account>`, remote desktop access, internet access (or a proxy) during installation, time zone (UTC+09:00) | 3–6, 11 |
| Cloud network team | Security-group rule: this server to `<rds-endpoint>` on TCP `<rds-port>`; name resolution of the endpoint | 7 |
| Database administrator | `<rds-endpoint>`, `<rds-port>`, the administrator login `<admin login>` (usually the RDS master user), confirmation that `rds.force_ssl = 1`, engine version 13 or later, about 20 free connections | 7, 8 |
| PAM / CyberArk team | `<ccp-address>`, `<application ID>` allowed for this server, `<safe>`, `<account object>` of the database administrator account and the user name it holds (`<admin login>`); the same for the Fujitsu Mainframe service account (and the Fujitsu RACF account when used); whether the CCP certificate comes from the company's own certificate authority; written agreement that the bot copies the administrator's password to its own login | 9 |
| ServiceNow team | `<servicenow instance>`, the bot's ServiceNow account (basic or OAuth), the assignment group of the SailPoint tasks, the rights of the bot account | 12.2 |
| Mail team | `<smtp host>`, port (25, 587 or 465), security mode, sender address, whether a login is needed, a test mailbox | 12.3 |
| Fujitsu Mainframe team | The terminal program on the server (the **オンライン業務** shortcut), the bot's service account (affiliation code, staff code, 8-character password), the date the password was last changed, the operating window, test accounts | 9.2, 12.5, 12.8 |
| Fujitsu RACF team (only when used) | WSMGR / DSPEMU with the **接続1** connection, the bot's sign-on ID (SAILPNT by default) and its password, the system (TSS3 test, TSS2 production), host and port, test IDs | 9.3, 12.9 |
| Information security | Approval of the bot account's administrator rights, the session policy for the bot's desktop, the password handling | 3, 11 |

### Step 2.2 Fill in the worksheet

The **Sample (QA)** column: Values of the client QA environment, given as worked examples. Use your own environment's values in production.

| # | Placeholder | What it is | Standard value | Sample (QA) | Your value |
|---|---|---|---|---|---|
| 1 | `C:\FINESIII` | Install root | `C:\FINESIII` | `C:\FINESIII` | |
| 2 | `C:\FINESIII\app` | Application folder | `C:\FINESIII\app` | `C:\FINESIII\app` | |
| 3 | `C:\FINESIII\data` | Data folder (`FINESIII_DATA_DIR`) | `C:\FINESIII\data` | `C:\FINESIII\data` | |
| 4 | `<bot account>` | The bot's Windows account, `DOMAIN\user` (a local account: `<server name>\user`) | — | `R6-CORE\prvrnel` | |
| 5 | `<rds-endpoint>` | RDS instance endpoint or Aurora writer endpoint, as shown in the AWS console | — | `rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com` | |
| 6 | `<rds-port>` | RDS port | `5432` | `5432` | |
| 7 | `<admin login>` | RDS administrator login (the master user), whose password the PAM team rotates in CyberArk | — | `dbadmin` | |
| 8 | `finesiii_app` | Application login (created in section 8) | `finesiii_app` | `finesiii_app` | |
| 9 | `finesiii_v3` | Application database | `finesiii_v3` | `finesiii_v3` | |
| 10 | `<audit database>` | Audit database. There is no built-in default: the name is given with `--audit-database`; without it the audit trail stays in a file in the data folder. This runbook uses `finesiii_audit`. | `finesiii_audit` | `finesiii_audit` | |
| 11 | `<ccp-address>` | CyberArk CCP host, used as `https://<ccp-address>` (no path, no trailing slash) | — | `pamccp.aig.net` (used as `https://pamccp.aig.net`) | |
| 12 | `<application ID>` | CCP Application ID allowed for this server | — | `APP-10-SAILPOINT` (shared with SailPoint in QA; confirm with the PAM team whether production gets its own) | |
| 13 | `<safe>` | Safe of the database administrator account | — | `BADM_DBADMIN-ISO-POSTGRESQL` | |
| 14 | `<account object>` | Object name of the database administrator account, copied exactly | — | `Database---rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com---sailpoin1002---5432--dbadmin` (the database named inside it, `sailpoin1002`, is not the bot's database; the bot's database stays `finesiii_v3`) | |
| 15 | Fujitsu Mainframe CyberArk account | Safe and object of the service account (may use the same Application ID) | — | — | |
| 16 | Fujitsu RACF CyberArk account (optional) | Object (and safe when different) of the sign-on ID | — | — | |
| 17 | `<smtp host>` | Mail relay and port | — | — | |
| 18 | `<servicenow instance>` | `https://<servicenow instance>` | — | `https://aigm3.service-now.com` (QA instance; confirm) | |
| 19 | `<console port>` | Console and service port | `8000` | — | |
| 20 | Web proxy | `http://<proxy-host>:<port>`, only when there is no direct internet access | — | — | |
| 21 | Bot account rights | Local administrator (main path) or normal user (alternative, Step 11.5) | Administrator | — | |

**QA sample values** (not in the worksheet above). Values of the client QA environment, given as worked examples. Use your own environment's values in production.

| Item | Sample (QA) |
|---|---|
| Bot server (host name) | `qwawosis1001.r1-core.r1.aig.net` (short name `qwawosis1001`) |
| Database engine | Amazon Aurora PostgreSQL 17 (region us-east-1) |
| RDS certificate bundle (shipped) | `C:\FINESIII\app\certs\rds-global-bundle.pem` |
| Certificate file for CyberArk (internal certificate authority) | `C:\FINESIII\certs\aig-ca-bundle.pem`; in `.env`: `CYBERARK_CA_BUNDLE=C:/FINESIII/certs/aig-ca-bundle.pem` |
| Database URL (application, no password) | `postgresql://finesiii_app@rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com:5432/finesiii_v3?sslmode=verify-full&sslrootcert=C%3A%5CFINESIII%5Capp%5Ccerts%5Crds-global-bundle.pem&connect_timeout=10&keepalives=1&keepalives_idle=60&keepalives_interval=10&keepalives_count=5&application_name=finesiii-rpa` |
| ServiceNow application ID, Fujitsu Mainframe | `2565` (ticket text `Policy Management System - Common Process [2565]`) |
| ServiceNow application ID, Fujitsu RACF | `6582` (ticket text `Fujitsu RACF (Resource Access Control Facility) [6582]`) |
| Assignment group the bot reads tickets from (both applications) | `Policy Management System - Common Process-2565-JPN` |
| Assignment group of the Fujitsu RACF completion ticket (**Completion ticket: assignment group**) | `MFT-SYS Programmer-JPN` |
| Fujitsu RACF terminal shortcut | `C:\ProgramData\Fujitsu\WSMGR\接続1.emd` |
| Fujitsu RACF terminal program | empty (`接続1` is not a file; the shortcut is used) |
| Fujitsu RACF window title | `接続1 - DSPEMU` |
| Fujitsu RACF system (LOGON target) | `TSS3` (TSS2 also exists) |
| Fujitsu RACF sign-on ID | `SAILPNT` |
| Start the Fujitsu RACF terminal as administrator | On |
| Scheduled task | `FINESIII RPA Agent` |

### Step 2.3 Network ports

| From the server to | Port | Why | When |
|---|---|---|---|
| `pypi.org`, `files.pythonhosted.org`, `www.python.org`, `aka.ms` | 443 | Python 3.13, the packages, the Visual C++ runtime | Installation, and updates that add packages |
| `<rds-endpoint>` | `<rds-port>` (5432) | The databases | Always |
| `https://<ccp-address>` | 443 | Database password and service-account passwords from CyberArk | Always, with CyberArk |
| `https://<servicenow instance>` | 443 | Tickets | Always, with ServiceNow polling |
| `<smtp host>` | 25, 587 or 465 | E-mail | Always, with e-mail |
| Fujitsu Mainframe host | the probe port (23 by default) | Availability check, when a host is set | Always |
| Fujitsu RACF host (optional) | the probe port (23 by default) | Availability check | With Fujitsu RACF |
| `truststore.pki.rds.amazonaws.com` | 443 | A fresh AWS certificate bundle | Only when the bundle is refreshed (section 16.5) |

**Sample (QA):** `rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com` on TCP `5432`; `https://pamccp.aig.net` on 443; `https://aigm3.service-now.com` on 443 (QA instance; confirm).

The console listens only on `127.0.0.1`; no inbound port is opened on the server.

### Step 2.4 Timing

| Section | Time |
|---|---|
| 3–4 Server, bot account, package | 20 minutes |
| 5 Prerequisites | 15–30 minutes (downloads) |
| 6–8 Permissions, RDS, databases | 30 minutes |
| 9.1 Database password from CyberArk | 30–60 minutes, with the PAM team |
| 10–11 First start, background run | 30 minutes |
| 12 Console set-up | 2–4 hours, with each team |
| 13 End-to-end test and go-live | half a day, with the Fujitsu Mainframe (and Fujitsu RACF) team |

**Before you go on:** every row of the worksheet that applies has a value; information security has approved the bot account's rights; the PAM team's agreement is on the change record.

---

## 3. Prepare the server and the bot account

> **In plain words.** The bot needs its own Windows account, because it types into the terminal window on its own desktop and reads its passwords from its own credential store. By default it is a local administrator, so that it can type into a terminal that was started as administrator.

**Who does this:** Server team. **Where:** administrator window.

### Step 3.1 Create the bot account

The server team creates `<bot account>` with a password that follows the policy for service accounts. Keep that password in the organisation's password vault.

### Step 3.2 Make the bot account a local administrator (main path)

The group is named by its fixed identifier, so the command works on English and Japanese Windows alike.

```powershell
Add-LocalGroupMember -SID 'S-1-5-32-544' -Member '<bot account>'
Get-LocalGroupMember -SID 'S-1-5-32-544'
```

**Sample (QA):**

```powershell
Add-LocalGroupMember -SID 'S-1-5-32-544' -Member 'R6-CORE\prvrnel'
Get-LocalGroupMember -SID 'S-1-5-32-544'
```

`[OK]` The bot account is listed.
`[NG]` **Principal ... was not found** → name mistyped → use `DOMAIN\user`, or `<server name>\user` for a local account.
`[NG]` **... is already a member of group ...** → nothing to do.

> **Why administrator.** **Start the terminal as administrator** (**Settings › Fujitsu Mainframe terminal**) is On by default. Windows lets only a program that itself runs as administrator type into a window started as administrator, so the service runs with highest privileges (section 11). If the Fujitsu Mainframe terminal on this server works without administrator rights, use the alternative of Step 11.5 instead and skip this step.

### Step 3.3 Let the bot sign in by remote desktop (alternative path only)

Only when the bot account is **not** made an administrator in Step 3.2:

```powershell
Add-LocalGroupMember -SID 'S-1-5-32-555' -Member '<bot account>'
```

**Sample (QA):**

```powershell
Add-LocalGroupMember -SID 'S-1-5-32-555' -Member 'R6-CORE\prvrnel'
```

`[OK]` No output. (`S-1-5-32-555` is the Remote Desktop Users group.)

### Step 3.4 Create the bot account's profile

Sign in to the server **once as the bot account** by remote desktop, so that Windows creates its profile and its Credential Manager, then sign out.

`[OK]` The desktop of the bot account appears.
`[NG]` **The connection was denied because the user account is not authorized for remote login** → Step 3.2 or 3.3 not done.

### Step 3.5 Check and set the time zone

```powershell
Get-TimeZone | Select-Object Id, DisplayName
```

`[OK]` `Tokyo Standard Time` and `(UTC+09:00) Osaka, Sapporo, Tokyo`.
`[NG]` Another time zone → transaction IDs, screenshot names and evidence times follow the server clock, while the console and e-mails show JST, and the System page shows **This server's clock is not on Japan time (it is UTC...)** → agree the change with the server team, then:

```powershell
Set-TimeZone -Id 'Tokyo Standard Time'
```

**Before you go on:**

- `<bot account>` exists, is in the local Administrators group (or Remote Desktop Users on the alternative path) and has signed in once.
- `Get-TimeZone` shows `Tokyo Standard Time`.

---

## 4. Copy and verify the package

> **In plain words.** Copy the delivered fresh installation package to the server and prove with checksums that every file arrived complete and unchanged.

**Who does this:** Server team. **Where:** administrator window.

### Step 4.1 Create the folder and copy the package

```powershell
New-Item -ItemType Directory -Force -Path 'C:\FINESIII\app'
```

Copy the **content** of the package folder (not the folder itself) into `C:\FINESIII\app`, so that `C:\FINESIII\app\Setup_Prerequisites.ps1` exists. Copy the extracted files; do not copy a `.env`, `.venv`, `logs` folder or `.db` file from another machine.

### Step 4.2 Unblock the files and look at the content

```powershell
cd C:\FINESIII\app
Get-ChildItem -Recurse -File | Unblock-File
Get-ChildItem -Force | Select-Object Name
```

`[OK]` The list holds: `.env.example`, `00_READ_FIRST.txt`, `PACKAGE_CONTENTS.txt`, `RUN_COMMANDS.txt`, `Setup_Database.py`, `Setup_Prerequisites.ps1`, `Technical Documentation`, `certs`, `config`, `desktop`, `docs`, `models`, `pytest.ini`, `requirements-ocr.txt`, `requirements-worker.txt`, `requirements.txt`, `run.py`, `scripts`, `src`, `tests`, `unattended`.
`[NG]` `.env`, `.venv`, `logs` or a `.db` file is listed → it came from another machine → delete it; the setup creates its own.
`[NG]` `unattended` or `certs` is missing → incomplete copy → copy the package again.

### Step 4.3 Verify every file against PACKAGE_CONTENTS.txt

Each line of `PACKAGE_CONTENTS.txt` is a SHA-256 checksum, two spaces and the path inside the package. The command prints only the files that are missing or different (about one minute):

```powershell
Get-Content .\PACKAGE_CONTENTS.txt | Where-Object { $_ -match '^[0-9a-f]{64}  ' } | ForEach-Object { if (-not (Test-Path -LiteralPath $_.Substring(66))) { 'MISSING  ' + $_.Substring(66) } elseif ((Get-FileHash -Algorithm SHA256 -LiteralPath $_.Substring(66)).Hash -ne $_.Substring(0, 64)) { 'CHANGED  ' + $_.Substring(66) } }
```

`[OK]` No output.
`[NG]` `MISSING <file>` → incomplete copy or extraction → extract the package completely and copy it again.
`[NG]` `CHANGED <file>` → altered in transit, by an editor or by a scanner → copy that file again from the original package; if it keeps changing, ask information security whether a scanner modifies it.

| Case | What happens |
|---|---|
| **No output** | The package is complete and unchanged; continue with section 5 |
| A `MISSING` line | That file is not on the server; the setup may stop with **Application files: missing: ...** |
| A `CHANGED` line | That file differs from the delivered one; do not continue until it is copied again |
| An update folder newer than the package was delivered | Install the package first, finish section 10, then apply the update folder with section 15 |

**Before you go on:** the checksum command prints nothing.

---

## 5. Install the prerequisites

> **In plain words.** One script checks the server and installs everything the bot needs: Python 3.13, the Microsoft Visual C++ runtime, the application's Python environment and packages, the screen-reading models, the data folder and a starter settings file. It can be run again at any time; what is in place is left alone.

**Who does this:** Server team. **Where:** administrator window, in `C:\FINESIII\app`.

### Step 5.1 Run the script

```powershell
cd C:\FINESIII\app
powershell -NoProfile -ExecutionPolicy Bypass -File .\Setup_Prerequisites.ps1
```

Behind a web proxy:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Setup_Prerequisites.ps1 -Proxy http://<proxy-host>:<port>
```

| Option | Use |
|---|---|
| `-CheckOnly` | Reports only; installs and changes nothing |
| `-Proxy http://<proxy-host>:<port>` | Downloads through a web proxy |
| `-DataDir <folder>` | Another data folder (default `C:\FINESIII\data`) |
| `-SkipOcr` | Leaves out screen reading. **Do not use**: the real terminal is refused without it. |

**What it does.** Each check prints a line `[OK]`, `[INSTALLED]`, `[INFO]`, `[WARN]` or `[FAIL]`:

| Step | What it does |
|---|---|
| 1/12 Server | 64-bit Windows, PowerShell 5.1, administrator window, application files, 5 GB free, folder path length. Stops at once when application files are missing. |
| 2/12 Internet access | Tests `pypi.org`, `files.pythonhosted.org`, `www.python.org` |
| 3/12 Python 3.13 (64-bit) | Installs Python 3.13.15 side by side when missing, after checking its SHA-256 checksum and its signature by the Python Software Foundation. An existing Python is left unchanged. |
| 4/12 Microsoft Visual C++ runtime | Installs it when missing, after checking its signature by Microsoft Corporation |
| 5/12 Python environment (.venv) | Creates `C:\FINESIII\app\.venv`; rebuilds one made with another Python version |
| 6/12 Application packages | Installs the service, terminal and screen-reading packages (the screen-reading packages take 10 to 20 minutes) |
| 7/12 OCR models | Confirms the models in `models\paddleocr` |
| 8/12 Data folder | Creates `C:\FINESIII\data` with `logs` and `evidence`; sets the machine variable `FINESIII_DATA_DIR` |
| 9/12 Settings file (.env) | Creates a starter `C:\FINESIII\app\.env` (development, simulator, built-in database, no API key) when there is none |
| 10/12 Stored credentials | Reports passwords of an earlier installation in this account's store (report only) |
| 11/12 Browser and service port | Reports Edge or Chrome, and whether port 8000 is free (report only) |
| 12/12 Component self-test | Runs the application's self-test |

`[OK]` The run ends with a summary and

```
 READY. Open a NEW PowerShell window. Database: Setup_Database.py, then start
        the application (RUN_COMMANDS.txt, sections 3 and 5).
```

and exit code 0 (type `$LASTEXITCODE`). Expected lines on a first run:

- `[INSTALLED] FINESIII_DATA_DIR: C:\FINESIII\data (machine level). Open a NEW PowerShell window before starting the application`
- `[INSTALLED] Settings file: C:\FINESIII\app\.env created (simulator, built-in database)`
- `[INFO     ] Production: the starter settings file is for testing (APP_ENV=development, no API key). Before production use set APP_ENV=production as described in the installation guide` (section 13 does this)

`[OK]` **READY, with warnings - read the WARN lines above.** (exit code 2) is acceptable once every WARN line is understood.
`[NG]` **NOT READY - correct the FAIL lines above and run the script again.** (exit code 1) → correct each FAIL line and run the same command again. A transcript is kept as `C:\FINESIII\data\logs\setup_<date>_<time>.log`.

### Step 5.2 Common results and what to do

| What you see | Cause | Fix |
|---|---|---|
| **running scripts is disabled on this system** | Execution policy | Type the command exactly, with `-ExecutionPolicy Bypass` |
| `[WARN] Administrator rights: not an administrator window; ...` | Not opened with **Run as administrator** | Close it, open an administrator window, run again |
| `[FAIL] Application files: missing: ... Copy the complete application folder again.` | Incomplete copy | Section 4 again |
| `[WARN] pypi.org: not reachable from this server (use -Proxy, ...)` | No direct internet | Add `-Proxy http://<proxy-host>:<port>` |
| **refusing to run ... its SHA-256 checksum does not match** or **... is not signed by ...** | Not the genuine installer, or changed by a proxy | Download again; never bypass the check |
| **a restart of the server is required to finish this installation** | Visual C++ runtime | Restart the server, then run again |
| `[FAIL] ...: pip ended with exit code ...; the message above names the package. Behind a proxy use -Proxy http://host:port` | Download blocked | Use `-Proxy`; read the pip message above the line |
| `[FAIL] ...: installed but do not load: ...` | Visual C++ runtime missing, or (screen reading) a processor without AVX support | Fix the runtime and run again; otherwise ask the infrastructure team to expose AVX to the virtual machine |
| `[FAIL] OCR models: not found in ...` | `models` folder not copied | Copy it from the package; repeat Step 4.3 |
| `[WARN] Stored credentials: found for this Windows account: ...` | Passwords of an earlier installation | For a clean start remove them as that account (section 19) |
| `[WARN] Port 8000: in use by ...` | Another program | Acceptable: the service then picks another free port and shows it. Better: stop the other program. |
| `[FAIL] Self-test: produced no report. ...` | The self-test could not run | Run `.\.venv\Scripts\python.exe desktop\app.py --selftest` and read the FAILED line (section 18) |

### Step 5.3 Verify the machine variable

Close the administrator window. Open a **new** administrator window:

```powershell
[Environment]::GetEnvironmentVariable('FINESIII_DATA_DIR', 'Machine')
Test-Path 'C:\FINESIII\app\.venv\Scripts\python.exe'
Test-Path 'C:\FINESIII\app\.env'
```

`[OK]` `C:\FINESIII\data`, `True`, `True`.
`[NG]` Blank first line → the script ran in a window without administrator rights (it then sets the variable for that user only) → run Step 5.1 in an administrator window.

| Case | What happens |
|---|---|
| **First run on an empty server** | Python, runtime, environment, packages and data folder are installed; READY |
| Second run, nothing missing | Every line OK; nothing changed; READY |
| Run with `-CheckOnly` | Reports only; `FINESIII_DATA_DIR` and `.env` are reported as FAIL / WARN when missing |
| An existing Python of another version | Left unchanged; Python 3.13 is installed beside it |
| A `.env` already exists | Left unchanged |

**Before you go on:** READY (or READY with understood warnings); `FINESIII_DATA_DIR` is `C:\FINESIII\data` at machine level.

---

## 6. Folder permissions

> **In plain words.** By default every user of a Windows server can read new folders. The evidence screenshots show initial passwords of new accounts, so access is limited to the system, the administrators and the bot account.

**Who does this:** Server team. **Where:** a new administrator window.

| Folder or file | SYSTEM and Administrators | Bot account | Everyone else | Why the bot needs it |
|---|---|---|---|---|
| `C:\FINESIII` | Full control | Read (this folder only) | No access | To reach the two folders |
| `C:\FINESIII\data` | Full control | **Modify** | No access | Logs, evidence, service keys and state, `.env` backups, the CyberArk certificate file |
| `C:\FINESIII\app` | Full control | **Read & execute** | No access | To run the program |
| `C:\FINESIII\app\.env` | Full control | **Modify** | No access | The database script and the console write settings into it, with a dated backup |
| `C:\FINESIII\app\config` | Full control | **Modify** | No access | A Developer may switch error rules on the **Error rules** page; `config\errors.yaml` is then rewritten |

### Step 6.1 Set the permissions

`*S-1-5-18` is SYSTEM and `*S-1-5-32-544` is the local Administrators group.

```powershell
icacls 'C:\FINESIII' /inheritance:r /grant:r "*S-1-5-18:(OI)(CI)F" "*S-1-5-32-544:(OI)(CI)F" "<bot account>:RX"
icacls 'C:\FINESIII\data' /inheritance:r /grant:r "*S-1-5-18:(OI)(CI)F" "*S-1-5-32-544:(OI)(CI)F" "<bot account>:(OI)(CI)M"
icacls 'C:\FINESIII\app' /inheritance:r /grant:r "*S-1-5-18:(OI)(CI)F" "*S-1-5-32-544:(OI)(CI)F" "<bot account>:(OI)(CI)RX"
icacls 'C:\FINESIII\app\.env' /grant "<bot account>:M"
icacls 'C:\FINESIII\app\config' /grant "<bot account>:(OI)(CI)M"
```

**Sample (QA):**

```powershell
icacls 'C:\FINESIII' /inheritance:r /grant:r "*S-1-5-18:(OI)(CI)F" "*S-1-5-32-544:(OI)(CI)F" "R6-CORE\prvrnel:RX"
icacls 'C:\FINESIII\data' /inheritance:r /grant:r "*S-1-5-18:(OI)(CI)F" "*S-1-5-32-544:(OI)(CI)F" "R6-CORE\prvrnel:(OI)(CI)M"
icacls 'C:\FINESIII\app' /inheritance:r /grant:r "*S-1-5-18:(OI)(CI)F" "*S-1-5-32-544:(OI)(CI)F" "R6-CORE\prvrnel:(OI)(CI)RX"
icacls 'C:\FINESIII\app\.env' /grant "R6-CORE\prvrnel:M"
icacls 'C:\FINESIII\app\config' /grant "R6-CORE\prvrnel:(OI)(CI)M"
```

`[OK]` Each command ends with **Successfully processed ... files; Failed processing 0 files**.
`[NG]` **No mapping between account names and security IDs was done** → bot account mistyped → check with `whoami` while signed in as the bot; run again.
`[NG]` **Access is denied** → window not elevated → administrator window.
`[NG]` `.env`: **The system cannot find the file specified** → section 5 did not create it → run Step 5.1 again.

### Step 6.2 Check the result

```powershell
icacls 'C:\FINESIII\data'
icacls 'C:\FINESIII\app'
```

`[OK]` Only SYSTEM, Administrators (shown with their local names) and the bot account are listed; no `Users` and no `Authenticated Users` line.
`[NG]` `Users` or `Authenticated Users` still listed → `/inheritance:r` left out → repeat Step 6.1 exactly.

> **Tip.** Where the application folder is read-only for the process, the console keeps its backups of `.env` in `C:\FINESIII\data\backups` instead of next to `.env`.

**Before you go on:** `icacls` lists only SYSTEM, Administrators and the bot account on `C:\FINESIII\data` and `C:\FINESIII\app`.

---

## 7. Prepare the RDS connection

> **In plain words.** Before the databases are created, three things are proved: the AWS certificate bundle is present, the server reaches the database on its port, and the database enforces encryption.

**Who does this:** Server team (signed in as the bot account), Database administrator (pgAdmin). **Where:** a bot window. From this section to section 10, stay signed in as the bot account.

### Step 7.1 Confirm the window sees the data folder

Sign in to the server as `<bot account>` by remote desktop and open a bot window:

```powershell
$env:FINESIII_DATA_DIR
whoami
```

`[OK]` `C:\FINESIII\data`, and the bot account in lower case.
Sample (QA): signed in as `R6-CORE\prvrnel` on `qwawosis1001`, the window shows `C:\FINESIII\data` and `r6-core\prvrnel`.
`[NG]` Blank → the bot was signed in while section 5 ran → sign the bot out and in again, open a new bot window.

### Step 7.2 The certificate bundle and the network path

```powershell
(Select-String -Path 'C:\FINESIII\app\certs\rds-global-bundle.pem' -Pattern 'BEGIN CERTIFICATE').Count
Resolve-DnsName <rds-endpoint>
Test-NetConnection -ComputerName <rds-endpoint> -Port 5432
```

**Sample (QA):**

```powershell
(Select-String -Path 'C:\FINESIII\app\certs\rds-global-bundle.pem' -Pattern 'BEGIN CERTIFICATE').Count
Resolve-DnsName rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com
Test-NetConnection -ComputerName rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com -Port 5432
```

With another port, use `-Port <rds-port>`.

`[OK]` A number above 100; the endpoint resolves to a private address; **TcpTestSucceeded : True**.
`[NG]` 0 or an error on the first command → `certs` folder missing → copy it again and repeat Step 4.3.
`[NG]` **Resolve-DnsName : ... DNS name does not exist** → DNS for the AWS private zone → network team.
`[NG]` **TcpTestSucceeded : False** → security group, network ACL, firewall or routing → compare the source allowed by the security group with the server's address (`ipconfig`). Do not continue.

### Step 7.3 Check encryption in pgAdmin (database administrator)

pgAdmin runs under the database administrator's own Windows account, which cannot read the application folder. Give it a copy of the bundle, in an administrator window of that account:

```powershell
Copy-Item 'C:\FINESIII\app\certs\rds-global-bundle.pem' "$env:USERPROFILE\Documents\rds-global-bundle.pem"
```

In pgAdmin, on the server connection: **SSL mode** `verify-full`, **Root certificate** the copied file, host name the endpoint **name** (not an IP address). Reconnect, open **Query Tool** on `postgres` and run:

```sql
SHOW rds.force_ssl;
SELECT version();
SELECT ssl, version, cipher FROM pg_stat_ssl WHERE pid = pg_backend_pid();
```

`[OK]` `rds.force_ssl` is `1` (or `on`); version 13 or later; `ssl` is `true` with `TLSv1.2` or `TLSv1.3`.
`[NG]` `rds.force_ssl` is `0` → unencrypted connections allowed → the database administrator sets `rds.force_ssl = 1` in the parameter group before go-live.
`[NG]` Version below 13 → the database script warns → plan an engine upgrade.

**Before you go on:** bundle present; **TcpTestSucceeded : True**; `rds.force_ssl` is `1`.

---

## 8. Create the databases

> **In plain words.** One command, run as the bot account, creates the application login `finesiii_app` with no administrative rights, the application database `finesiii_v3`, the audit database `finesiii_audit`, every table and only the rights the bot needs, and proves them with a test write that it takes back. The application login gets a generated password that nobody sees. The administrator password is used for this run only and is never stored. At the end the script shows a one-time password for the first console administrator.

**Who does this:** Server team (signed in as the bot account), Database administrator (provides the administrator password, or confirms the CyberArk details). **Where:** the bot window of section 7, in `C:\FINESIII\app`.

### Step 8.1 Decide where the administrator password comes from

| Way | Use it when | Command option |
|---|---|---|
| **A. Typed at the prompt** (recommended for the first run) | The database administrator can paste the current `<admin login>` password from the vault | none: the script asks |
| **B. Read from CyberArk** | Nobody may see the administrator password | `--admin-password-from-cyberark`, after Steps 9.1.2 and 9.1.3 (the CyberArk settings lines and their test) |

With way B, do Steps 9.1.2 and 9.1.3 now, then come back here.

### Step 8.2 Check first (optional, recommended)

```powershell
cd C:\FINESIII\app
.\.venv\Scripts\python.exe Setup_Database.py --rds --host <rds-endpoint> --admin-login <admin login> --audit-database finesiii_audit --check-only
```

**Sample (QA):**

```powershell
cd C:\FINESIII\app
.\.venv\Scripts\python.exe Setup_Database.py --rds --host rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com --admin-login dbadmin --audit-database finesiii_audit --check-only
```

With another port add `--port <rds-port>`. With way B add `--admin-password-from-cyberark`.

**Prompt (way A):** `Password of '<admin login>' at <rds-endpoint> (not shown, Enter for none):` → paste the password, press Enter.
Sample (QA): `Password of 'dbadmin' at rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com (not shown, Enter for none):`

`[OK]` On an instance where nothing exists yet, the run stops at step 4/8 with `[FAIL   ] Login 'finesiii_app': does not exist` and **NOT READY**. This is expected: steps 1/8 to 3/8 have proved the address, the certificate, the network, the administrator password and the encryption. On an installed system it ends with **READY.**
`[NG]` Any other FAIL line → see Step 8.6.

### Step 8.3 Create the databases

```powershell
.\.venv\Scripts\python.exe Setup_Database.py --rds --host <rds-endpoint> --admin-login <admin login> --audit-database finesiii_audit
```

**Sample (QA):**

```powershell
.\.venv\Scripts\python.exe Setup_Database.py --rds --host rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com --admin-login dbadmin --audit-database finesiii_audit
```

With another port add `--port <rds-port>`. With way B add `--admin-password-from-cyberark` (then there is no prompt, and the line `[OK     ] Administrator password: read from CyberArk for '<admin login>' (not shown)` appears).

| Part of the command | Meaning |
|---|---|
| `--rds --host <rds-endpoint>` | The endpoint alone: no `postgresql://`, no login, no port. Every address is built from it. |
| `--admin-login <admin login>` | The administrator login for this run. Without it the script uses `dbadmin`. |
| `--audit-database finesiii_audit` | Also creates the audit database and switches the audit trail to it. Without it the audit trail stays in a file in the data folder. |
| (defaults) | Application login `finesiii_app`, database `finesiii_v3`, port 5432, `--tls verify-full` with `C:\FINESIII\app\certs\rds-global-bundle.pem` |

**Expected report** (lines `[OK     ]`, `[CREATED]`, `[INFO   ]`, `[WARN   ]`, `[FAIL   ]`):

| Step shown | Good result |
|---|---|
| `=== 1/8 Address` | `Application address`, `Administrator address`, `Audit address` (no password); `Certificate bundle: C:\FINESIII\app\certs\rds-global-bundle.pem (N certificates)`; `Settings file: the address will be written to C:\FINESIII\app\.env` |
| `=== 2/8 Network` | `Server <rds-endpoint>:5432: reachable (<address>)` |
| `=== 3/8 Sign-in` | `Sign-in as '<admin login>': database 'postgres'`; `Server type: Amazon RDS for PostgreSQL` (or `Amazon Aurora PostgreSQL (...)`); `Server version`; `Connection: encrypted (TLS), the server's certificate and name checked` |
| `=== 4/8 Login and database` | `[CREATED] Password of 'finesiii_app': generated and kept in the credential store of <bot account> (never shown)`; `[CREATED] Login 'finesiii_app': created (no administrative rights)`; `[CREATED] Database 'finesiii_v3': created (encoding UTF8)` |
| `=== 5/8 Tables` | The six tables `request_queue`, `transaction_history`, `app_users`, `app_sessions`, `app_roles`, `app_settings` created |
| `=== 6/8 Rights of the application login` | The queue may be read, added to and changed, never deleted; the history only read and added to; the console tables fully; the new database closed to the other logins |
| `=== 7/8 Verification as the application login` | `Sign-in as 'finesiii_app'`; `Tables seen by the application`; `Rights needed by the application: all present`; `Protection of the history: enforced by the database: ...`; the write test; `Application readiness check: passed` |
| `=== Audit database` | `Audit table: audit.audit_events created`; `Audit rights of 'finesiii_app': audit events: read and add only`; `Protection of the audit events: enforced by the database: events can be added and read, never changed or deleted` |
| `=== 8/8 Settings file` | `[CREATED] Password: stored in the credential store of <bot account> (not in a file)`; `[CREATED] Settings file: settings file C:\FINESIII\app\.env: DATABASE_ENGINE, DATABASE_URL, AUDIT_ENABLED, AUDIT_BACKEND, AUDIT_DATABASE_URL` |
| `=== Console administrator` | `[CREATED] Initial administrator password: for 'admin', in the credential store of <bot account>; shown once below` |

**Sample (QA):** the lines step 8/8 writes into `C:\FINESIII\app\.env` (no password; `sslrootcert` is the path of the certificate bundle, URL-encoded):

```
DATABASE_ENGINE=postgres
DATABASE_URL=postgresql://finesiii_app@rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com:5432/finesiii_v3?sslmode=verify-full&sslrootcert=C%3A%5CFINESIII%5Capp%5Ccerts%5Crds-global-bundle.pem&connect_timeout=10&keepalives=1&keepalives_idle=60&keepalives_interval=10&keepalives_count=5&application_name=finesiii-rpa
AUDIT_ENABLED=true
AUDIT_BACKEND=postgres
AUDIT_DATABASE_URL=postgresql://finesiii_app@rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com:5432/finesiii_audit?sslmode=verify-full&sslrootcert=C%3A%5CFINESIII%5Capp%5Ccerts%5Crds-global-bundle.pem&connect_timeout=10&keepalives=1&keepalives_idle=60&keepalives_interval=10&keepalives_count=5&application_name=finesiii-rpa
```

`[OK]` The run ends with:

```
 READY.
 Next: start the application
   .\.venv\Scripts\python.exe desktop\app.py --agent
 Log   : C:\FINESIII\data\logs\setup_database_<date>_<time>.log
```

and exit code 0. A second run reports the same items as OK, "left unchanged".
`[NG]` **READY, with warnings** (exit code 2) or **NOT READY** (exit code 1) → read the WARN and FAIL lines of the summary, correct the cause (Step 8.6) and run the same command again; only what is missing is added.

### Step 8.4 Keep the one-time console password

On a database without console accounts the script shows, once:

```
  -----------------------------------------------------------------
   Console administrator : admin
   Initial password      : <four groups of four letters and digits>
   Shown only now. Sign in to the console after the first
   start and choose your own password; this one is then
   removed from the credential store.
  -----------------------------------------------------------------
```

Store it in the password vault at once. It is never written to the report or the log.

| Situation | What to do |
|---|---|
| You want to type the initial password yourself | Add `--console-admin ask` (at least 12 characters, a letter and a digit, not containing the user name; typed twice) |
| Lost before the first start | Run the Step 8.3 command again with `--new-admin-password` added |
| Lost after the first start | As the bot account: `.\.venv\Scripts\python.exe desktop\app.py --reset-console-password admin` (section 16.4) |
| The report says `no credential store for this account: 'admin' gets the published initial password at the first start` | The script was not run as the bot account in a normal sign-in. Sign in correctly and run it again |

### Step 8.5 Check the database the way the service will

```powershell
.\.venv\Scripts\python.exe desktop\app.py --check-db
```

`[OK]`

```
 Database : postgresql://finesiii_app@<rds-endpoint>:5432/finesiii_v3?sslmode=verify-full&...
 Engine   : postgres
 Server   : PostgreSQL ...
 User     : finesiii_app
 Result   : OK
```

**Sample (QA):**

```
 Database : postgresql://finesiii_app@rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com:5432/finesiii_v3?sslmode=verify-full&...
```

and exit code 0. `--check-db --json` gives the same in full detail.
`[NG]` **Engine : sqlite** → not run in `C:\FINESIII\app` → `cd C:\FINESIII\app` first.
`[NG]` **Result : FAILED** → the **Error** and **Hint** lines name the cause: **Hint : The user name or password is wrong.** (run as another Windows account) or **Hint : The database has not been created — ask the DBA to run the setup scripts.** (Step 8.3 not done).

### Step 8.6 Common results and what to do

| What you see | Cause | Fix |
|---|---|---|
| **--rds needs the endpoint of the cluster: --host <endpoint> ...** | `--host` missing | Add `--host <rds-endpoint>` (Sample (QA): `--host rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com`) |
| **--host takes the endpoint alone, without a scheme, a login or a port ...** | `postgresql://`, a login or `:5432` in `--host` | Endpoint only; the port is `--port` |
| `Certificate bundle: ... is missing. It is part of the application package (certs folder). ...` | `certs` not copied | Copy it; Step 4.3 |
| **The password of the application login is generated and kept in the credential store of this account, and there is none here (...)** | Not run as the bot account in a normal sign-in | Sign in as the bot by remote desktop; run it in a bot window |
| `Server ...: the host name '...' is not known on this machine. ...` | DNS | Step 7.2 |
| `Server ...: not reachable (...)` | Network path | Step 7.2 |
| `Sign-in as '<admin login>': ...` with a password message | Wrong or rotated administrator password | Paste the current one from the vault, or use way B |
| `Administrator password` / **The administrator's password could not be read from CyberArk: ...** (way B) | CyberArk settings or access | Step 9.1.3 table |
| **CyberArk returned the account '...', not the administrator '<admin login>' (check CYBERARK_DB_OBJECT).** | Wrong object or login name | Copy the object again, or correct `DATABASE_ADMIN_LOGIN` and `--admin-login` |
| `Administrator rights: '...' is not a superuser and may not create logins and databases; ...` | Not the master user | Use the master user |
| `Password of 'finesiii_app': the login exists, and its password is not in the credential store of this account. ...` | Run by another Windows account than before | Run as the bot account that ran it before, or add `--set-password` |
| `Login 'finesiii_app': exists but is not allowed to sign in` | Created without the login right | Database administrator: `ALTER ROLE finesiii_app LOGIN;`, then run again |
| `Table owner: ...` or `Protection of the history: NOT enforced by the database - ...` | Tables created by the application login earlier | Run again with `--fix-ownership` |
| `Time per database call: about ... ms (...)` (WARN) | More than 100 ms per call | The bot works, but slower; review where the server and the instance are placed |
| `Settings file: could not be written: ...` | The bot cannot write `.env` | Section 6, the `.env` line |
| `Setup: unexpected problem: ...` | Not recognised | Keep the log file; contact support |

**Good and bad cases — database creation**

| Case | What happens |
|---|---|
| **New instance, way A, password correct** | Login, databases, tables, rights and audit database created; password generated and stored for the bot; READY; one-time console password shown |
| **New instance, way B, CyberArk answers** | As above, with no prompt; `Administrator password: read from CyberArk ...` |
| Run again on an installed system | Everything reported OK, "left unchanged"; no password changed; no one-time password (the console has accounts) |
| Run by another Windows account than the bot | Stops at step 4/8 (no stored password for this account) or warns that `admin` gets the published password; nothing is broken: run it again as the bot |
| Wrong administrator password | Stops at step 3/8; nothing created |
| `--check-only` on a new instance | Stops at step 4/8 with `Login 'finesiii_app': does not exist`; nothing created |
| Run again **while the database password from CyberArk is on** (section 9.1) | The stored application password is no longer the one the database has, so step 7/8 fails at **Sign-in as 'finesiii_app'**. Use the safe order of Step 9.1.9 instead |

> **Tip. The guided tool.** `scripts\setup_rds_database.py` asks for the endpoint and the administrator password (or reads it with `--admin-password-from-cyberark`), runs `Setup_Database.py --rds` first as a check, then, after a confirmation, for real. It stops the service before the setup and offers to start the scheduled task afterwards. On the first installation the task does not exist yet, so add `--no-service`:
>
> ```powershell
> .\.venv\Scripts\python.exe scripts\setup_rds_database.py --cluster <rds-endpoint> --admin-login <admin login> --audit-database finesiii_audit --no-service
> ```
>
> **Sample (QA):**
>
> ```powershell
> .\.venv\Scripts\python.exe scripts\setup_rds_database.py --cluster rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com --admin-login dbadmin --audit-database finesiii_audit --no-service
> ```
>
> `[OK]` `Check: the cluster, the administrator password and the encryption are in order.`, then after `y`: `Setup: READY`. The tool refuses to run while `DATABASE_PASSWORD` or `AUDIT_DATABASE_PASSWORD` is set in the account's environment.

**Before you go on:**

- `Setup_Database.py` ended with **READY.**
- The one-time console password is in the vault.
- `desktop\app.py --check-db` shows **Result : OK** and **User : finesiii_app**.

---

## 9. CyberArk integration

> **In plain words.** CyberArk can supply three passwords: the database password (the bot reads the database administrator's password and gives its own login the same one), the Fujitsu Mainframe service-account password, and the Fujitsu RACF sign-on password. Each is set up on its own. Section 9.1 is done now, before the first start. Sections 9.2 and 9.3 need the console and are carried out from section 12, at the step that names them.

**Who does this:** PAM / CyberArk contact (the values and the access), Database administrator (the administrator's right to change the password of `finesiii_app`), Developer (the console steps), Server team (the settings file).

### 9.1 Database password from CyberArk (CCP)

**How it works.**

- The bot keeps working as `finesiii_app`. **Database URL** keeps naming `finesiii_app`, with no password in it. Only the password of `finesiii_app` becomes the same as the administrator's.
- At every start, and every **CyberArk check interval (minutes)** (15), the bot asks CCP for the administrator's password. When `finesiii_app` does not accept it, the bot signs in once as `<admin login>` and gives `finesiii_app` the same password, sent only as its SCRAM-SHA-256 verifier.
- A refused sign-in makes the bot ask at once (at most once a minute). While CPM is changing the password, the bot keeps the password in use and asks again a minute later.
- At start the service waits up to 5 minutes for the password. Without it the service does not start (`[FATAL] The service did not start: ...`); the launcher starts it again after 60 seconds.
- The password is never shown, logged, e-mailed or written to a file.

**When to use it.**

| Use it when | Do not use it when |
|---|---|
| The PAM team keeps `<admin login>` in CyberArk and CPM rotates its password | The database password is changed by hand on agreed dates (section 16.1) |
| No database password should be kept in the bot account's Credential Manager | CyberArk cannot be reached from this server on port 443 |

#### Step 9.1.1 Confirm the inputs

| Value | Placeholder | Sample (QA) | Setting (settings file / console label) |
|---|---|---|---|
| CCP address, host only, https | `https://<ccp-address>` | `https://pamccp.aig.net` | `CYBERARK_DB_BASE_URL` / **CyberArk address (database)** |
| Application ID allowed from this server | `<application ID>` | `APP-10-SAILPOINT` (shared with SailPoint in QA; confirm with the PAM team whether production gets its own) | `CYBERARK_DB_APP_ID` / **CyberArk Application ID (database)** |
| Safe | `<safe>` | `BADM_DBADMIN-ISO-POSTGRESQL` | `CYBERARK_DB_SAFE` / **CyberArk safe (database)** |
| Object name, copied exactly | `<account object>` | `Database---rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com---sailpoin1002---5432--dbadmin` | `CYBERARK_DB_OBJECT` / **CyberArk object (database)** |
| User name CyberArk returns for that object | `<admin login>` | `dbadmin` | `DATABASE_ADMIN_LOGIN` / **Database administrator login** (default `dbadmin`) |
| Audit database uses the same password | `true` | — | `CYBERARK_DB_FOR_AUDIT` / **Audit database uses the same password** (default On) |
| Check interval in minutes | `15` | — | `CYBERARK_DB_REFRESH_MINUTES` / **CyberArk check interval (minutes)** (1 to 1440) |
| Certificate file, only with an internal certificate authority | `C:/FINESIII/data/certs/cyberark-ca-bundle.pem` | `C:/FINESIII/certs/aig-ca-bundle.pem` | `CYBERARK_CA_BUNDLE` / **CyberArk certificate file (internal certificate authority)** |

The **Sample (QA)** column: Values of the client QA environment, given as worked examples. Use your own environment's values in production. In the QA object name the database named inside it (`sailpoin1002`) is not the bot's database; the bot's database stays `finesiii_v3`.

The database administrator confirms that `<admin login>` may connect to `finesiii_v3` and change the password of `finesiii_app` (the RDS master user normally may). The address and port CyberArk holds for the account are not used; the bot always connects to **Database URL**.

#### Step 9.1.2 Add the settings lines (switch still off)

*Bot window.* Open the settings file:

```powershell
notepad C:\FINESIII\app\.env
```

Add these lines at the end, with your values, and save. Keep `CYBERARK_DB_ENABLED=false` for now. Leave out the last line unless the CCP certificate is issued by the company's own certificate authority (Step 9.1.4).

```
CYBERARK_DB_ENABLED=false
CYBERARK_DB_BASE_URL=https://<ccp-address>
CYBERARK_DB_APP_ID=<application ID>
CYBERARK_DB_SAFE=<safe>
CYBERARK_DB_OBJECT=<account object>
DATABASE_ADMIN_LOGIN=<admin login>
CYBERARK_DB_FOR_AUDIT=true
CYBERARK_DB_REFRESH_MINUTES=15
CYBERARK_CA_BUNDLE=C:/FINESIII/data/certs/cyberark-ca-bundle.pem
```

**Sample (QA)** (QA uses a certificate file of the internal certificate authority, so the last line is kept):

```
CYBERARK_DB_ENABLED=false
CYBERARK_DB_BASE_URL=https://pamccp.aig.net
CYBERARK_DB_APP_ID=APP-10-SAILPOINT
CYBERARK_DB_SAFE=BADM_DBADMIN-ISO-POSTGRESQL
CYBERARK_DB_OBJECT=Database---rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com---sailpoin1002---5432--dbadmin
DATABASE_ADMIN_LOGIN=dbadmin
CYBERARK_DB_FOR_AUDIT=true
CYBERARK_DB_REFRESH_MINUTES=15
CYBERARK_CA_BUNDLE=C:/FINESIII/certs/aig-ca-bundle.pem
```

None of these lines is a password. The console shows them later under **Settings › This machine › Database** and changes them in place.

#### Step 9.1.3 Test the CyberArk retrieval from the command line

This reads the administrator's password from CyberArk and signs in with it, without changing anything:

```powershell
cd C:\FINESIII\app
.\.venv\Scripts\python.exe Setup_Database.py --rds --host <rds-endpoint> --admin-login <admin login> --audit-database finesiii_audit --admin-password-from-cyberark --check-only
```

**Sample (QA):**

```powershell
cd C:\FINESIII\app
.\.venv\Scripts\python.exe Setup_Database.py --rds --host rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com --admin-login dbadmin --audit-database finesiii_audit --admin-password-from-cyberark --check-only
```

`[OK]` `[OK     ] Administrator password: read from CyberArk for '<admin login>' (not shown)`, then `Sign-in as '<admin login>'` OK, and **READY.** (exit code 0). This proves the CCP address, the Application ID, the safe, the object, the login name and that the password in CyberArk is the one the database has.

| What you see | Cause | Fix |
|---|---|---|
| **The administrator's password could not be read from CyberArk: CyberArk configuration invalid: ...** | A line missing or mistyped (for example **base_url is empty**) | Correct the line in `.env` |
| **The administrator's password could not be read from CyberArk: ... certificate verify failed ...** | The CCP certificate comes from the company's own certificate authority | Step 9.1.4 |
| **... ConnectTimeout ...**, **... ConnectError ...**, or a name that does not resolve | Port 443 to `<ccp-address>` blocked, or DNS | Network team opens port 443 from this server, or fixes the name |
| An answer with **403** (for example **APPAP227E**) | The Application ID may not read the account from this server | PAM team allows this server for the Application ID |
| An answer with **404**, or the object is not found | Safe or object misspelt, or the Application ID is not a member of the safe | Copy both again; PAM team checks the safe's members |
| **CyberArk returned the account '...', not the administrator '<admin login>' (check CYBERARK_DB_OBJECT).** | Wrong object, or `DATABASE_ADMIN_LOGIN` differs from the user name in CyberArk | Copy the object again or correct the login (and `--admin-login`) |
| `Sign-in as '<admin login>'` FAIL with a password message | The password in CyberArk is not the one the database has | PAM team reconciles the account in CyberArk |

#### Step 9.1.4 Only with an internal certificate authority: the certificate file

The bot checks CyberArk's certificate against its own built-in list of public authorities, not against the Windows store. With a company certificate authority, create the certificate file **in the console** after the first start:

1. Leave `CYBERARK_DB_ENABLED=false`, continue with sections 10 and 11, then come back to this step.
2. *Console, Developer:* **Settings › This machine › Database**, next to **CyberArk certificate file (internal certificate authority)**, click **Create from Windows certificates**.
   `[OK]` **Created C:/FINESIII/data/certs/cyberark-ca-bundle.pem with N certificates from the Windows trusted store. Save and restart to use it.** The path is put in the field (not saved yet).
   `[NG]` **No certificate was found in the Windows trusted store of this server.** → export the root and intermediate certificates of the CCP address from the browser (padlock, **Certificate**, **Certification Path**, **Base-64 encoded X.509 (.CER)**), paste them one after another into `C:\FINESIII\certs\cyberark-ca-bundle.pem`, readable by the bot account, and enter that path.
   Sample (QA): the file `C:\FINESIII\certs\aig-ca-bundle.pem`, entered as `C:/FINESIII/certs/aig-ca-bundle.pem`.
3. Click **Test CyberArk retrieval** (next to **CyberArk object (database)**). It uses the values on the page before they are saved.
4. Click **Save and restart**. A file that does not exist, cannot be read or holds no PEM certificate is refused: **CyberArk certificate file: ... Nothing was saved.**
5. Run Step 9.1.3 again; it now reads the saved file.

The same file is used for every CyberArk call: the database password and the Fujitsu Mainframe and Fujitsu RACF passwords.

#### Step 9.1.5 Switch it on

*Bot window.* `notepad C:\FINESIII\app\.env` → change `CYBERARK_DB_ENABLED=false` to `CYBERARK_DB_ENABLED=true` → save.

The first start (section 10) then reads the password, gives it to `finesiii_app` and records the change. Do not run `Setup_Database.py --set-password` from now on (Step 9.1.9).

> **The console route.** Instead of Steps 9.1.2 and 9.1.5, a Developer can enter the same values under **Settings › This machine › Database**, run **Test CyberArk retrieval**, switch **Database password from CyberArk** On and click **Save and restart**. The save is refused, with the reason, when **CyberArk address (database)** or **CyberArk Application ID (database)** is empty (**Database password from CyberArk: enter CyberArk address (database); ... Nothing was saved.**), when **Database URL** holds a password, names the administrator, or the engine is not `postgres`. The restart first reads the password and applies it; when it cannot: **Not restarted: the database password from CyberArk could not be obtained: <reason>. The service keeps running as it was.**

#### Step 9.1.6 Verify after the first start (done in section 10)

These checks are run in Step 10.5, once the console is open:

1. **System** page: the **Database password** card shows **Latest password from CyberArk** and the lines:
   - **Password in use: the latest from CyberArk, in use since ... JST.**
   - **Changed in CyberArk: ... JST**
   - **Last successful check: ... JST (every 15 min)**
   - **Next check: ... JST**
   - (only after a failure) **Last attempt failed: ... JST** and the problem in plain words.
2. Click **Validate database password** (System page, row of buttons; Admin or Developer; also next to **Database URL** on **Settings › This machine › Database**).
3. `.\.venv\Scripts\python.exe desktop\app.py --check-db` → **Result : OK**, with no `[WARN] database password from CyberArk ...` line before it.

**Good and bad cases — CyberArk retrieval and Validate database password**

| Case | What happens |
|---|---|
| **Test retrieval passes** (console) | **CyberArk delivered the account <admin login> (<rds-endpoint>:5432), CPM status .... The password is not shown.** |
| Test retrieval names another account | **CyberArk delivered the account <name>, not <admin login>: check the object name.** |
| Test retrieval with a certificate problem | **CyberArk did not deliver the account: ... certificate verify failed ...** → Step 9.1.4 |
| **Validate: same password, accepted** | **Password validated. The bot uses the latest password from CyberArk.** |
| **Validate: CyberArk has a newer password** | **Password validated and updated. The bot now uses the latest password from CyberArk; new connections use it.** A **Database password changed: the bot uses the new password** e-mail and an audit event follow |
| Validate: the bot's login had another password, CyberArk's did not change | Validated and the login is set back; e-mail **Bot's database login set back to the password in CyberArk**; audit event (WARNING) |
| Validate while CPM changes the password | **CyberArk is changing the password right now. The bot keeps using the password it has until the change is finished; try again in a minute.** |
| Validate when CyberArk does not answer | **Not checked: <reason>. The bot keeps using the last password it received from CyberArk.** |
| Validate when the copy is refused | **The new password from CyberArk could not be applied: <reason>. ...** or **The password could not be checked with the database: <reason>. ...** |
| Validate clicked twice within 30 seconds | **A check ran a moment ago; try again in N seconds. ...** |
| Validate while the option is off | **The database password does not come from CyberArk on this server: the machine setting "Database password from CyberArk" is off. The bot uses the stored database password.** |
| CyberArk down during the day | The card shows **CyberArk not reachable**; the bot keeps the password in use; e-mail **CyberArk not available: the database password could not be checked**, later **CyberArk (database password) Recovered** |
| Copy fails 3 times in a row | E-mail **Database password not updated: the bot keeps working with the password in use**; when it works again (scheduled check, Validate, start), **Database password updated: the bot uses the current password from CyberArk** with a "Found by" row |
| Service start without the password (5 minutes) | `[FATAL] The service did not start: ...` in `agent.log`; the launcher tries again every 60 seconds |

**Sample (QA):** **CyberArk delivered the account dbadmin (rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com:5432), CPM status .... The password is not shown.**

Every **Validate database password** click and every password change is recorded in the audit trail.

#### Step 9.1.7 Optional: prove a rotation with the PAM team

1. **Settings › This machine › Database**: **CyberArk check interval (minutes)** `1`, **Save and restart**.
2. PAM changes the password in CyberArk.
3. Within about a minute **Changed in CyberArk** shows the new time, the card stays **Latest password from CyberArk**, requests keep working, and a **Database password changed: the bot uses the new password** e-mail arrives (when e-mail is set up).
4. Set the interval back to `15`, **Save and restart**.

#### Step 9.1.8 Going back to a password of the bot's own

1. *Console, Developer:* **Settings › This machine › Database**: **Database password from CyberArk** Off, **Save changes** (not restart).
2. *Bot window:* stop the service: `.\.venv\Scripts\python.exe desktop\app.py --stop`.
3. *Bot window:* give `finesiii_app` a new generated password of its own (the administrator password can still be read from CyberArk while the other CyberArk lines are kept):

```powershell
cd C:\FINESIII\app
.\.venv\Scripts\python.exe Setup_Database.py --rds --host <rds-endpoint> --admin-login <admin login> --audit-database finesiii_audit --admin-password-from-cyberark --set-password
```

**Sample (QA):**

```powershell
cd C:\FINESIII\app
.\.venv\Scripts\python.exe Setup_Database.py --rds --host rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com --admin-login dbadmin --audit-database finesiii_audit --admin-password-from-cyberark --set-password
```

4. Start the service (section 14). The **Database password** card is no longer shown; **Dashboard** › **Database** shows **Connected**.

Switching the setting off and restarting without step 3 leaves the bot with the password stored before, which the database no longer accepts.

#### Step 9.1.9 Running the database script while the CyberArk copy is on

While `CYBERARK_DB_ENABLED=true`, the password kept in the bot account's Credential Manager is the one generated in section 8, and the database no longer accepts it. A run of `Setup_Database.py` without `--set-password` (also `--check-only`) therefore fails at **Sign-in as 'finesiii_app'**, and `scripts\setup_rds_database.py` stops at its check. Use this order when the script must run (for example to move to another endpoint or to refresh the certificate bundle):

1. Stop the service: `.\.venv\Scripts\python.exe desktop\app.py --stop`.
2. Run the script with both options:

```powershell
.\.venv\Scripts\python.exe Setup_Database.py --rds --host <rds-endpoint> --admin-login <admin login> --audit-database finesiii_audit --admin-password-from-cyberark --set-password
```

**Sample (QA):**

```powershell
.\.venv\Scripts\python.exe Setup_Database.py --rds --host rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com --admin-login dbadmin --audit-database finesiii_audit --admin-password-from-cyberark --set-password
```

   `[OK]` **READY, with warnings** (exit code 2) with `[WARN   ] Password: the bot copies the administrator's password from CyberArk to the application login (CYBERARK_DB_ENABLED); the password set now is replaced at its next check`.
3. Start the service. At start the bot gives `finesiii_app` the CyberArk password again; a **Database password changed: the bot uses the new password** e-mail and an audit event record it.

For a check only, use `desktop\app.py --check-db` and **Validate database password**, not `Setup_Database.py --check-only`.

### 9.2 Fujitsu Mainframe service-account password

> **In plain words.** The bot signs in to Fujitsu Mainframe with one service account: a 5-digit affiliation code, a 7-character staff code and an 8-character password. The two codes are always stored on this machine. The password is stored too, and in production it must also come from CyberArk.

*When: during section 12, Step 12.4 and Step 12.5. Where: the console, Admin or Developer.*

| Rule | What it means |
|---|---|
| Store all three values first | With the real terminal the service checks the three values when it starts, before CyberArk is asked. Without valid values the System page shows **Terminal executor could not be built — ... Processing is disabled until the Fujitsu Mainframe settings are completed and the service is restarted.** Store them even when CyberArk will supply the password. |
| Production rule | With **Service environment** = production and the real terminal, the password must come from CyberArk. **This machine** refuses to save the real terminal driver in production while CyberArk is off: **In production a real terminal driver requires the mainframe password to come from CyberArk — enable and test the CyberArk module first.** If CyberArk is off or does not start, the service runs but does not process: **CyberArk is required here (require_cyberark with a real terminal driver) but is not enabled or did not start. ...** |
| CyberArk owns the password | While CyberArk supplies it, the bot neither reminds about its age nor changes it, and **Change service-account password** is refused |

#### Step 9.2.1 Store the service-account values

**Settings › This machine › Credentials**: **Service account — affiliation code** (5 half-width digits), **Service account — staff code** (7 half-width letters or digits), **Service account — password** (exactly 8 characters) → **Save changes**.

`[OK]` Each shows as set; the values are never shown again.
`[NG]` The save is refused for a code that does not follow its rule → correct it. A password of another length is reported when the service starts with the real terminal.

#### Step 9.2.2 Set up CyberArk for the service account

**Settings › CyberArk** (Admin):

| Setting | Value | Default |
|---|---|---|
| **Fetch the mainframe password from CyberArk** | On | Off |
| **API** | `ccp` | ccp |
| **Base URL** | `https://<ccp-address>` | Empty |
| **Application ID** | `<application ID>` | Empty |
| **Safe** | the safe of the service account | Empty |
| **Account object name** | the object of the service account | Empty |
| **Verify TLS certificate** (Developer) | On | On |
| **Refresh every (hours)** (Developer) | 4 | 4 |

**Sample (QA):** **Base URL** `https://pamccp.aig.net`, **Application ID** `APP-10-SAILPOINT` (shared with SailPoint in QA; confirm with the PAM team whether production gets its own); the safe and the object of the Fujitsu Mainframe service account come from the PAM team.

1. Click **Test retrieval** (uses the values on the page).
   `[OK]` **Retrieved the password from https://<ccp-address> (ccp). The value is not shown.**
   Sample (QA): **Retrieved the password from https://pamccp.aig.net (ccp). The value is not shown.**
   `[NG]` A hint: the vault did not answer (base URL, TLS, network), access denied (Application ID, allowed machines), or check the safe and object. A certificate problem → Step 9.1.4 (the same file serves this call).
2. **Save changes**, then **System › Restart service**.
3. **System** page: the **CyberArk** card shows **Connected** with the time of the fetch. **Settings › Fujitsu Mainframe terminal › Terminal summary (as the service runs now)** shows **Service account password from: CyberArk**.
4. **Refresh CyberArk now** (System page) fetches again at once: **The password is being fetched; the CyberArk card shows the result in a few seconds.**

| Case | What happens |
|---|---|
| **CyberArk delivers at start** | **Connected**; the CyberArk password replaces the stored one while the service runs |
| CyberArk down at start, stored password present | **Fallback password**; in production with the real terminal processing waits and resumes by itself once CyberArk delivers |
| CyberArk down at start, no stored password | **CyberArk integration failed to start** under **Needs attention** |
| CyberArk down during the day | The last good password stays in use; **CyberArk not available: the bot could not retrieve its password** e-mail, later a recovery e-mail |
| Fujitsu Mainframe rejects the password | The bot asks CyberArk at once |

### 9.3 Fujitsu RACF sign-on password

*Only when Fujitsu RACF is used. When: during section 12, Step 12.9.*

| Way | How | Notes |
|---|---|---|
| **Stored** | **Settings › This machine › Credentials** › **Fujitsu RACF service account — password** (shown while Fujitsu RACF is on) → **Save changes** → restart | Takes effect after a restart |
| **From CyberArk** (required in production with the real terminal) | The Fujitsu RACF account uses the same CyberArk connection as Fujitsu Mainframe (**Settings › CyberArk**, which must be On). Its account is named by **Windows environment variables only** — there is no console setting: `CYBERARK_TSS_OBJECT` (or `CYBERARK_TSS_ACCOUNT_USERNAME`) and, when it is in another safe, `CYBERARK_TSS_SAFE` | Without them in production with the real terminal: **CyberArk is required here but no Fujitsu RACF account is set (CYBERARK_TSS_OBJECT or CYBERARK_TSS_ACCOUNT_USERNAME); Fujitsu RACF requests wait in the queue.** Fujitsu Mainframe is not affected |

#### Step 9.3.1 Set the Fujitsu RACF CyberArk account (administrator window)

```powershell
[Environment]::SetEnvironmentVariable('CYBERARK_TSS_OBJECT', '<RACF account object>', 'Machine')
[Environment]::SetEnvironmentVariable('CYBERARK_TSS_SAFE', '<RACF safe>', 'Machine')
```

Leave out the second line when the account is in the same safe as the Fujitsu Mainframe account. Then stop the service, sign the bot account out and in again (so that the service gets the new variables), and start it (section 11).

`[OK]` The service log shows **CyberArk Fujitsu RACF account enabled: ...**; the Fujitsu RACF card on the System page shows no CyberArk problem.
`[NG]` **CyberArk has not delivered the Fujitsu RACF password yet; Fujitsu RACF requests wait in the queue.** → check the object and safe with the PAM team.

The bot cannot change the Fujitsu RACF password; it only reminds when the change is due (section 16.3).

**Before you go on (section 9):**

- Step 9.1.3 ended with **READY.** and the line **Administrator password: read from CyberArk for '<admin login>' (not shown)**.
- `CYBERARK_DB_ENABLED=true` is in `.env` (or the console route is planned after section 11, Step 9.1.4).
- The inputs for 9.2 (and 9.3) are at hand for section 12.

---

## 10. First start and verification

> **In plain words.** The service is started once in a visible window, so that every start-up message can be read. You run the self-test and the database check, sign in to the console for the first time and choose your own password, check the System page and the database password, confirm the encrypted connection in pgAdmin, and stop it again.

**Who does this:** Server team (signed in as the bot account), console administrator, Database administrator.

### Step 10.1 Start in the foreground

*Bot window 1:*

```powershell
cd C:\FINESIII\app
.\.venv\Scripts\python.exe desktop\app.py --agent
```

`[OK]` The start summary shows:

```
 AIG IAM Access RPA — background agent starting
 Environment : development (DevelopmentConfig)
 Driver      : simulator (canned executor, no UI — fastest)
 Database    : postgres — postgresql://finesiii_app:***@<rds-endpoint>:5432/finesiii_v3?...
 Dispatcher  : enabled
 Audit trail : enabled
 OCR         : enabled
 Error rules : ...
```

**Sample (QA)**, the database line:

```
 Database    : postgres — postgresql://finesiii_app:***@rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com:5432/finesiii_v3?...
```

then **Starting the AIG IAM Access RPA service…** and **Ready — http://127.0.0.1:8000 (pid ...). Running in the background until stopped.** Leave this window open. With the CyberArk copy on, the start can take up to a minute longer while the password is read.

| What you see | Cause | Fix |
|---|---|---|
| **[STOP] Another AIG IAM Access RPA desktop instance is already running (lock: C:\FINESIII\data\agent.lock)** (exit code 3) | A copy already runs | Use it, or stop it with `--stop` first |
| **[FATAL] The service did not start: database password from CyberArk: ...** | A CyberArk line is incomplete or **Database URL** is not as the script wrote it | Correct the line named (Step 9.1.2) |
| **[FATAL] The service did not start: ...** after up to 5 minutes | The password from CyberArk could not be obtained | Step 9.1.3 table; to start without it set `CYBERARK_DB_ENABLED=false` and follow Step 9.1.8 |
| **[FATAL] The database cannot be reached (...): .... Correct DATABASE_URL in ... (or DATABASE_ENGINE), then start again.** | RDS not reachable, DNS, or a wrong address | Step 7.2 and Step 8.5; change the address only with the database script |
| **[FATAL] Configuration is not valid: ...** | A setting has an unknown value | Correct the line named in `.env` |
| **[WARN] credential vault not consulted: ...** | Credential Manager not readable | Run as the bot account in an interactive session |
| **The desktop window is not part of this delivery. Use --agent to start the bot and --stop to stop it.** (exit code 2) | `desktop\app.py` started without an option | Use `--agent` |
| The address shows another port than 8000 | Port 8000 is taken | Use the address shown; `C:\FINESIII\data\agent.json` always has it |

### Step 10.2 Self-test

*Bot window 2:*

```powershell
cd C:\FINESIII\app
.\.venv\Scripts\python.exe desktop\app.py --selftest
$LASTEXITCODE
```

`[OK]` Each component line is **OK** or **n/a**, the last line is **result      : ALL COMPONENTS USABLE**, exit code 0. **n/a** for the desktop window toolkit is normal. Loading the screen-reading engine takes up to a minute.
`[NG]` A **FAILED** line and **N COMPONENT(S) UNUSABLE**, exit code 1 → the line names the component (section 18). `--selftest --json` gives the full detail.

### Step 10.3 Database check

*Bot window 2:*

```powershell
.\.venv\Scripts\python.exe desktop\app.py --check-db
```

`[OK]` **Result : OK**, **User : finesiii_app**; with the CyberArk copy on, no `[WARN] database password from CyberArk ...` line above it.

### Step 10.4 First sign-in

*Bot window 2:*

```powershell
Start-Process 'http://127.0.0.1:8000/'
```

1. **Username** `admin`, **Password** the one-time password of Step 8.4.
2. The page **Choose a new password** opens: **New password**, **Confirm the new password**, **Set password**. Rules: at least 12 characters, a letter and a digit, not containing the user name, not one of the last passwords. The console signs in again with it.
3. The assistant **Set up the modules** may open: choose **Skip for now** (section 12 completes it).
4. **Dashboard**: **Bot service** **Running**, **Database** **Connected**.

`[OK]` The one-time password is removed from the bot account's Credential Manager the moment you set your own. The `admin` account holds the **Developer** role.

| Case | What happens |
|---|---|
| **One-time password correct** | **Choose a new password**; afterwards the Dashboard |
| Wrong password | **Invalid username or password**; after 5 wrong attempts the account is locked for 15 minutes |
| Repeated wrong passwords | **Too many failed sign-in attempts. Wait N second(s) and try again.** |
| `admin` signs in with `ChangeMe!2026` | The one-time password was not in the bot's store at the first start (script run as another account, or `--console-admin skip`); choose your own password at once; the System page warns until you do |
| One-time password lost after the first start | `.\.venv\Scripts\python.exe desktop\app.py --reset-console-password admin` in a bot window (section 16.4) |

### Step 10.5 System page checks

Open **System**.

| Check | Expected now | If different |
|---|---|---|
| **Needs attention** | Empty | Read each line; it says what to do |
| **Warnings** › **Security:** | **Requests are accepted without an API key. ...** (expected with the simulator until Step 13.5) | — |
| **Database** card | Connected | Section 18 |
| **Database password** card (CyberArk copy on) | **Latest password from CyberArk** with the lines of Step 9.1.6 | **CyberArk not reachable** or **Previous password in use**: the problem line names the reason (Step 9.1.3 table) |
| **Validate database password** | **Password validated. The bot uses the latest password from CyberArk.** | Step 9.1.6 table |
| Clock | No **This server's clock is not on Japan time ...** line | Step 3.5, then restart |

If the internal certificate file is needed (Step 9.1.4), it is done after section 11.

### Step 10.6 Confirm the encrypted connection in pgAdmin

*Database administrator, signed in as the administrator:*

```sql
SELECT a.datname, a.usename, a.application_name, s.ssl, s.version
FROM pg_stat_activity a JOIN pg_stat_ssl s ON s.pid = a.pid
WHERE a.usename = 'finesiii_app';
```

`[OK]` Rows for `finesiii_v3` and `finesiii_audit`, `application_name` `finesiii-rpa`, all with `ssl = true`.

### Step 10.7 Stop the foreground run

*Bot window 2:*

```powershell
.\.venv\Scripts\python.exe desktop\app.py --stop
```

`[OK]` **Asking the agent at http://127.0.0.1:8000 (pid ...) to stop…**, then **Agent stopped.** Window 1 shows **Stop requested — finishing any transaction in progress, then stopping…** and **Stopped.** Close both windows.

**Good and bad cases — first start**

| Case | What happens |
|---|---|
| **Everything prepared** | Start summary, **Ready — http://127.0.0.1:8000 ...**; self-test ALL COMPONENTS USABLE; check-db OK; first sign-in with the one-time password |
| CyberArk copy on, CyberArk answers | The password is read and given to `finesiii_app`; the service log shows **Database password copied from <admin login> to finesiii_app** and **Database password from CyberArk (<admin login>), in use for finesiii_app** |
| CyberArk copy on, CyberArk does not answer | The start waits up to 5 minutes, then `[FATAL] The service did not start: ...` |
| RDS not reachable | `[FATAL] The database cannot be reached ...` at once |
| Started as another Windows account | The System page shows **This service runs as ..., but it was set up to run as ...**; stop it and start as the bot account |
| A second start while one runs | `[STOP] Another AIG IAM Access RPA desktop instance is already running ...`, exit code 3 |

**Sample (QA):** **Database password copied from dbadmin to finesiii_app** and **Database password from CyberArk (dbadmin), in use for finesiii_app**

**Before you go on:**

- **Ready** line seen; self-test exit code 0; check-db **Result : OK**.
- `admin` has its own password; **Bot service Running**, **Database Connected**.
- With the CyberArk copy: the **Database password** card shows **Latest password from CyberArk**; **Validate database password** answers **Password validated**.
- pgAdmin shows `ssl = true` for `finesiii_app`.
- The foreground run is stopped.

---

## 11. Run in the background

> **In plain words.** In daily use no window stays open. A scheduled task starts a small launcher when the bot account signs in; the launcher starts the service without a window and starts it again 60 seconds after an unexpected stop. With the real terminal, the bot's Windows session must stay signed in, unlocked and not minimized, because Windows refuses keystrokes otherwise.

**Who does this:** Server team.

### Step 11.1 Choose how the bot's session is kept available

The scripts of the `unattended` folder set up one of four options. Each registers the scheduled task **FINESIII RPA Agent** (folder **AIG**) with the launcher `C:\FINESIII\app\unattended\Start_FINESIII_Service.pyw`, run as the bot account with highest privileges.

| Option | The bot runs in | After a server restart | Leaving the server |
|---|---|---|---|
| **A** (simplest) | The bot account's own remote desktop session | The bot account signs in once by remote desktop | **Leave Bot Running** shortcut on the bot's desktop (moves the session to the server's own screen; it stays signed in and unlocked) |
| **B** | A second session of the bot account that the server opens to itself (127.0.0.2), 1920 x 1080 | The bot account signs in once | Sign out of your own session as usual |
| **C** | As A | Automatic sign-in (Microsoft Autologon tool) | As A |
| **D** | As B | Automatic sign-in | As B |

Information security decides the option. The script also switches off the screen saver lock for the bot account and stops the server from sleeping; it reports company policies that lock the screen or end idle sessions as WARN lines for IT.

### Step 11.2 Set up the option

*Signed in as the bot account, in a bot administrator window:*

```powershell
cd C:\FINESIII\app
powershell -NoProfile -ExecutionPolicy Bypass -File .\unattended\Setup_Unattended.ps1 -Option A -Account '<bot account>'
```

**Sample (QA):**

```powershell
cd C:\FINESIII\app
powershell -NoProfile -ExecutionPolicy Bypass -File .\unattended\Setup_Unattended.ps1 -Option A -Account 'R6-CORE\prvrnel'
```

For option B or D, the script asks for the Windows password of the bot account once (saved for the bot's own session in its Credential Manager). For options A and C, `-SeparateSessions` lets a later remote desktop visit of the bot account open its own session instead of taking over the bot's.

`[OK]` `[OK  ] Administrator window`, `[OK  ] Account <bot account>`, `[DONE] Task 'FINESIII RPA Agent': starts the bot when <bot account> signs in`, `[DONE] Shortcut 'Leave Bot Running' on the desktop (runs as administrator)` (A, B, C), and at the end **Option A is set up.** (exit code 0), or **Option A is set up, with N warning(s) above to read.** (exit code 2).
`[NG]` `[FAIL] This window has no administrator rights. ...` → open the window with **Run as administrator**.
`[NG]` `[FAIL] The account '...' was not found. Write it as DOMAIN\name, exactly as in 'whoami'.` → correct `-Account`.
`[NG]` `[WARN] This window runs as ..., not as <bot account>. ...` → sign in as the bot account and run the same command again.
`[NG]` `[WARN] A company policy locks the screen ...` → ask IT for an exception for this server.

### Step 11.3 Start it and check

*Same window:*

```powershell
Start-ScheduledTask -TaskPath '\AIG\' -TaskName 'FINESIII RPA Agent'
```

Wait 30 seconds (up to a minute while the screen-reading engine loads), then:

```powershell
Get-Content 'C:\FINESIII\data\agent.json' -ErrorAction SilentlyContinue
Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:8000/api/v1/ping' | Select-Object StatusCode, Content
Get-ScheduledTask -TaskPath '\AIG\' -TaskName 'FINESIII RPA Agent' | Get-ScheduledTaskInfo | Select-Object LastRunTime, LastTaskResult
Get-Content 'C:\FINESIII\data\logs\agent.log' -Tail 25 -Encoding UTF8
powershell -NoProfile -ExecutionPolicy Bypass -File .\unattended\Check_Unattended.ps1
```

`[OK]`

- `agent.json` shows `url`, `port`, `pid`, `version` (`3.0.0`) and `started_at` (it exists only while the service runs);
- the ping answers `200` and `{"status":"ok"}`;
- `LastTaskResult` is `267009` (running);
- `agent.log` ends with `LAUNCHER | starting the service`, the start summary and the **Ready** line;
- `Check_Unattended.ps1` shows `[OK  ] Task 'FINESIII RPA Agent': state Running, ...`, `[OK  ] Running: http://127.0.0.1:8000 (process ..., started ...)`, `[OK  ] The bot answers (200)`, `[OK  ] Launcher running (restarts the bot after a crash), session N`, and no FAIL line.

Then in the console **Settings › Fujitsu Mainframe terminal › Terminal summary (as the service runs now)**: **This service runs as administrator: Yes**.

| What you see | Cause | Fix |
|---|---|---|
| `LastTaskResult` `267011` | The task has not run | Check the trigger and **Run as** show the bot account; the task is enabled |
| `LastTaskResult` `2147943645` | The bot account was not signed in | Sign in as the bot account, start the task again |
| `LastTaskResult` `2147942402` | Program or start folder wrong | Run Step 11.2 again |
| `LAUNCHER \| the service stopped unexpectedly (exit code 1); starting it again in 60 seconds`, repeating | The service fails at start; the lines above name the reason | Fix the cause (Step 10.1 table); to watch it, `--stop`, then a foreground start |
| `LAUNCHER \| the service is already running; the launcher ends` | A copy was started by hand before | That copy has no recovery: `--stop`, then `Start-ScheduledTask` |
| `[FAIL] Session 0 has no screen: ...` (Check_Unattended) | Started outside the bot's session | Start it only through the scheduled task |
| `[WARN] No launcher found ...` | Started by hand | `--stop`, then `Start-ScheduledTask` |

### Step 11.4 Test the automatic start, the recovery and the normal stop

1. **Automatic start.** Sign the bot account out and in again (option B/D: start **FINESIII Bot Session Keeper** if it is not running: `Start-ScheduledTask -TaskPath '\AIG\' -TaskName 'FINESIII Bot Session Keeper'`). After about 30 seconds repeat the checks of Step 11.3.
2. **Recovery** (before go-live only). *Bot administrator window* (the service runs as administrator, so a normal window cannot end it):

```powershell
Stop-Process -Id (Get-Content 'C:\FINESIII\data\agent.json' -Raw | ConvertFrom-Json).pid
```

   `[OK]` Within about a minute `agent.log` shows `the service stopped unexpectedly (exit code ...); starting it again in 60 seconds`, then a new **Ready** line; `agent.json` has another `pid`. The **Dashboard** and **System** page show **The service stopped unexpectedly (previous run started ...) and was started again at ... JST. See the audit trail and the service log for the cause.**

3. **Normal stop.** *Bot window:*

```powershell
cd C:\FINESIII\app
.\.venv\Scripts\python.exe desktop\app.py --stop
```

   `[OK]` **Agent stopped.**; `agent.log` shows `the service stopped normally; the launcher ends`. Start it again with `Start-ScheduledTask -TaskPath '\AIG\' -TaskName 'FINESIII RPA Agent'`.

> **Important.** Never stop the service in Task Manager or with **End** on the scheduled task: **End** stops only the launcher, while the service keeps running without recovery. Use `--stop` or **System › Stop the bot**.

### Step 11.5 Alternative: a bot without administrator rights

Only when the Fujitsu Mainframe terminal works without administrator rights (Step 3.3 instead of 3.2). `Setup_Unattended.ps1` always registers the task with highest privileges, so register the task by hand. *Administrator window, one command over six lines:*

```powershell
Register-ScheduledTask -TaskPath '\AIG\' -TaskName 'FINESIII RPA Agent' `
  -Action (New-ScheduledTaskAction -Execute 'C:\FINESIII\app\.venv\Scripts\pythonw.exe' -Argument '"C:\FINESIII\app\unattended\Start_FINESIII_Service.pyw"' -WorkingDirectory 'C:\FINESIII\app') `
  -Trigger (New-ScheduledTaskTrigger -AtLogOn -User '<bot account>') `
  -Principal (New-ScheduledTaskPrincipal -UserId '<bot account>' -LogonType Interactive -RunLevel Limited) `
  -Settings (New-ScheduledTaskSettingsSet -MultipleInstances IgnoreNew -ExecutionTimeLimit ([TimeSpan]::Zero) -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1) -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries) `
  -Description 'AIG IAM Access RPA service (the bot). Starts at sign-in of the bot account.'
```

**Sample (QA):**

```powershell
Register-ScheduledTask -TaskPath '\AIG\' -TaskName 'FINESIII RPA Agent' `
  -Action (New-ScheduledTaskAction -Execute 'C:\FINESIII\app\.venv\Scripts\pythonw.exe' -Argument '"C:\FINESIII\app\unattended\Start_FINESIII_Service.pyw"' -WorkingDirectory 'C:\FINESIII\app') `
  -Trigger (New-ScheduledTaskTrigger -AtLogOn -User 'R6-CORE\prvrnel') `
  -Principal (New-ScheduledTaskPrincipal -UserId 'R6-CORE\prvrnel' -LogonType Interactive -RunLevel Limited) `
  -Settings (New-ScheduledTaskSettingsSet -MultipleInstances IgnoreNew -ExecutionTimeLimit ([TimeSpan]::Zero) -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1) -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries) `
  -Description 'AIG IAM Access RPA service (the bot). Starts at sign-in of the bot account.'
```

`[OK]` **Task Scheduler › Task Scheduler Library › AIG** shows **FINESIII RPA Agent** with state **Ready**. Continue with Steps 11.3 and 11.4. In section 12 a console administrator switches **Start the terminal as administrator** Off.
`[NG]` **Cannot create a file when that file already exists** → the task exists → `Unregister-ScheduledTask -TaskPath '\AIG\' -TaskName 'FINESIII RPA Agent' -Confirm:$false`, then register again.

An installation that already has a launcher written by an earlier guide (`C:\FINESIII\app\Start_FINESIII_Service.pyw`) works the same way; the shipped copy in `unattended` is covered by the package checksums.

### Step 11.6 The bot's Windows session

With the real terminal (driver `pywinauto` or `pyautogui`), the bot types into its own Windows session. Windows refuses keystrokes while that session is locked, disconnected, or shown in a minimized remote desktop window.

| Case | What happens |
|---|---|
| **Session signed in, unlocked, window not minimized** | Requests run |
| Session locked or disconnected | New requests wait in the queue (no request is started); the System page shows **Requests wait: the bot's Windows session is locked. Keep the bot's session signed in, unlocked and not minimized; processing resumes by itself.** (or **... is disconnected ...**); an outage e-mail **Bot Windows session Not Available** goes to the default recipients, and **Bot Windows session Recovered** follows when work resumes |
| A request fails because Windows refused the keystrokes (for example a minimized remote desktop window) | New requests wait; the reason reads **Windows did not accept the bot's keystrokes (the bot's remote desktop window may be minimized)**; the bot tests at most once a minute whether input is accepted again and resumes by itself; the error e-mail explains the cause in plain words |
| Bot account signed out | The service stops (the task starts it again at the next sign-in) |
| Simulator driver | Nothing is checked |

The check is on by default and has no console setting; it is switched off only with `DESKTOP_SESSION_CHECK=false` in `C:\FINESIII\app\.env` (not recommended). Before connecting to or disconnecting from the bot's session, confirm on the **Dashboard** that no transaction is running. With option A leave with the **Leave Bot Running** shortcut, never with **Disconnect** or a minimized window.

### Step 11.7 A console shortcut for every user

*Administrator window, once:*

```powershell
Set-Content -Path 'C:\Users\Public\Desktop\AIG IAM Access RPA.url' -Value "[InternetShortcut]`r`nURL=http://127.0.0.1:8000/" -Encoding ASCII
```

`[OK]` An **AIG IAM Access RPA** shortcut on every desktop opens the console. Other people sign in to the server with their own Windows account and use their own console account; nobody else runs the service or signs in as the bot account.

**Before you go on:**

- The task **FINESIII RPA Agent** starts the service at the bot's sign-in; the Step 11.3 checks pass; `Check_Unattended.ps1` shows no FAIL.
- Automatic start, recovery and normal stop were tested.
- **This service runs as administrator: Yes** (main path).
- If Step 9.1.4 (internal certificate file) is needed, do it now, then Step 9.1.5 through the console route.

---

## 12. Configure the console, module by module

> **In plain words.** The console administrator connects the real systems one at a time, each with its own test, while the simulator is still the terminal driver. Then the bot is rehearsed with the simulator, switched to the real Fujitsu Mainframe terminal and tested there, and, when used, Fujitsu RACF is switched on and tested.

**Who does this:** Developer (machine settings, advanced settings), Admin (module settings), with the ServiceNow, mail, CyberArk, Fujitsu Mainframe and Fujitsu RACF teams. **Where:** the console.

> **Important.** Keep **Poll ServiceNow for tickets** Off while the simulator is the terminal driver: the simulator reports every request as done, and the bot would close real tickets as complete.

### Step 12.1 Open the setup assistant

Sign in as a Developer. **Settings** › **Run setup again** opens **Set up the modules**, in this order: **1. ServiceNow**, **2. Email (SMTP)**, **3. CyberArk**, **4. Fujitsu Mainframe target**, then (while Fujitsu RACF is on) **Fujitsu RACF target**, and **Summary**. Each page shows the same settings as the Settings page; **Save & continue** saves, **Skip for now** moves on without saving. The same work can be done on each Settings page.

### Step 12.2 ServiceNow

**Settings › ServiceNow** (or assistant page 1):

| Setting | Value |
|---|---|
| **Poll ServiceNow for tickets** | Off for now (On in Step 13.2) |
| **Instance URL** | `https://<servicenow instance>` |
| **Authentication** | `basic`, `oauth_password` or `oauth_client_credentials` |
| **Username** | the bot's ServiceNow account |
| **ServiceNow — bot account password** / **ServiceNow — OAuth client secret** | typed here; kept in Credential Manager |
| **Match tickets by** | `assignment_group` (SailPoint tasks in a group) or `assigned_to` |
| **Assignment group (sys_id or name)** | the group of the SailPoint tasks |
| **Bot account (sys_id, user name or name)** | the bot's ServiceNow user |
| **Requested For (sys_id or name)** | the account SailPoint raises the requests with (optional) |
| **Accepted application IDs** | `2565` (default) |
| **Close the ticket when the request failed** | On (default): failed and unconfirmed results close the ticket as Closed Incomplete |
| **State set on pickup** | `2` (default); may be left blank (= the state is not changed and not checked) |

**Sample (QA):** **Instance URL** `https://aigm3.service-now.com` (QA instance; confirm); **Accepted application IDs** `2565` (ticket text `Policy Management System - Common Process [2565]`); with Fujitsu RACF, **Fujitsu RACF application IDs** `6582` (**Settings › Fujitsu RACF tickets and e-mails**, Developer; ticket text `Fujitsu RACF (Resource Access Control Facility) [6582]`). **Assignment group (sys_id or name)** `Policy Management System - Common Process-2565-JPN`: the tickets of both applications are read from this one group (filled in, only tickets of that group; empty, tickets of every group). `MFT-SYS Programmer-JPN` is not entered here: it is the group of the Fujitsu RACF completion ticket (step 5 below).

1. **Test connection** (uses the values on the page). `[OK]` **Connection** signed in, the bot account found, the table readable, group membership; **Open tickets after each filter** shows no row that drops to 0 unexpectedly.
2. **Save changes**.
3. **Preview tickets** (uses the saved settings). `[OK]` For each open task, **The bot would**: Assign to the bot, then queue / Queue / Reject / Skip / Next poll, with the reason. Nothing is written to ServiceNow.
4. Developer, optional: **Discover fields** lists the catalog variables of a sample task.

`[NG]` A test hint names the cause (address, account, rights, filter). A test of the saved settings that finds ServiceNow unavailable sends its outage e-mail once.

### Step 12.3 E-mail

**Settings › E-mail** (assistant page 2):

| Setting | Value |
|---|---|
| **Send email alerts** | On |
| **SMTP host**, **SMTP port**, **Connection security** | `<smtp host>`, 25 / 587 / 465, as the mail team says |
| **SMTP username** / **SMTP password** | blank for a relay without login |
| **From address** | the agreed sender |
| **Default recipients** | the operations address (service notices and the alert summary go only here) |
| **Transaction outcome emails** | On |
| **Send every e-mail only to (testing)** | the test mailbox, until Step 13.6 |
| **Environment name shown in e-mails** | `UAT` while testing, `PRODUCTION` (or blank) at go-live |
| **Send the initial password to the new user** | Off while testing |
| Team lists | **ServiceNow team**, **CyberArk / identity team**, **Fujitsu Mainframe account administration**, **Database team** (Developer), **Fujitsu Mainframe team**, and with Fujitsu RACF the **Fujitsu RACF team** |
| **Fujitsu Mainframe team: support reports only** / **Fujitsu RACF team: support reports only** | On (default): the team receives only the support report of each SailPoint ticket of its application |

1. **Save changes**, then **System › Restart service** (the e-mail settings take effect after a restart).
2. Row **Test the mail server**: **Test connection** (nothing is sent), then **Send test e-mail** to a **Test recipients** address.
   `[OK]` Connected, encrypted, signed in (or relay); the test e-mail arrives.
   `[NG]` The hint names the cause: host unreachable, certificate not trusted or for another name, STARTTLS not offered, login rejected, sender or recipient refused.
3. **E-mail samples** (end of the page): check **On** and **Who receives it** for each e-mail, including **Database password changed: the bot uses the new password**, the database password and CyberArk (database password) outages and the **Bot Windows session** outage. **Send sample** sends one with `[TEST]` to test addresses only.

### Step 12.4 CyberArk for the Fujitsu Mainframe password

Do Steps **9.2.1** and **9.2.2** now (assistant page 3 shows the same settings with **Test retrieval**).

### Step 12.5 Fujitsu Mainframe target (still the simulator)

**Settings › Fujitsu Mainframe terminal**, **Settings › Fujitsu Mainframe window** and **Settings › This machine** (assistant page 4):

| Setting | Value | Who | Takes effect |
|---|---|---|---|
| **Launcher shortcut** | full path of the **オンライン業務** shortcut, for example `C:\Users\Public\Desktop\オンライン業務.lnk` | Admin | After a restart |
| **Start the terminal as administrator** | On (main path); Off on the alternative path of Step 11.5 | Admin | After a restart |
| **Service-account password: last changed on** | the date of the last change, `YYYY-MM-DD` | Admin | At once |
| **Service-account password: change automatically** | Off (default) | Admin | At once |
| **Window opens (JST)** / **Window closes (JST)** | the agreed operating window | Admin | After a restart |
| **Mainframe environment** (This machine › Deployment) | `production` for the production host, `development` for a test host (development puts `99` in front of the sign-in affiliation code). Set it explicitly: its default follows the **Service environment** | Developer | After a restart |
| **Mainframe host (probe)** / **Mainframe port (probe)** (This machine › Deployment) | the host and port; empty = assumed reachable | Developer | After a restart |
| **Service port** (This machine › Deployment) | `8000`; a change needs a full stop and start (Step 11.4 stop, then the task), not **Restart service** | Developer | After stop and start |

The **Tests** row shows the password age: **Password last changed <date> (<n> days ago); expires <date> (<n> days left); ...**, or **Password: supplied and changed by CyberArk.** while CyberArk supplies it. **Check password age now** (Developer) runs the check once and shows its result.

**Save changes**, then **System › Restart service**.

### Step 12.6 Rehearse with the simulator

The simulator processes a request in about a second, without touching Fujitsu Mainframe, and never with the real terminal. Do this rehearsal now, before Step 12.7 switches to the real terminal.

*Console, Admin or Developer:* **Requests** › **New request**:

| Field | Value |
|---|---|
| **Application** | **Fujitsu Mainframe** |
| **Operation** | **Provision (register)** |
| **Affiliation code (5 digits)** | a fictional code, for example `03325` |
| **Employee code (7 characters)** | a fictional code, for example `T000001` |
| **Ticket number (optional)** | `TEST-001` |
| **New user's e-mail address (optional)** | the test mailbox |

**Submit**. Repeat with **Deprovision (remove)** and the same codes, and `TEST-002`.

`[OK]` Both requests reach **Completed** within seconds; **History** and **Evidence** show them; the test mailbox receives the outcome e-mails (test mode of Step 12.3).
`[NG]` The request stays **Queued** → processing is paused, or outside the operating window (Dashboard).
`[NG]` The form refuses a value → it names the field and the rule (for example 5 digits).
`[NG]` **409** / duplicate → the same work was submitted before; use other codes or another ticket number.

> **Tip.** To see that the bot keeps working while nobody is connected, submit a request, leave the server as Step 11.6 describes for the chosen option, come back after a few minutes and check **Requests**. The `unattended\README.txt` names a script for test requests (`Submit_Test_Requests.ps1`); it is not part of the delivered package, so the console is used instead.

### Step 12.7 Switch to the real Fujitsu Mainframe terminal and test it

1. **System › Pause processing**, so that no queued request starts on the real terminal before it is tested.
2. Check **Settings › Screen reading** › **Read screens with OCR** On and **Settings › This machine › Screen reading (start-up)** › **Screen reading (OCR)** On.
3. **Settings › This machine › Deployment** (Developer, **Show all settings**): **Terminal driver** `pywinauto`. The save is refused without screen reading, and in production while CyberArk is off.
4. **Save and restart**.
5. **Settings › Fujitsu Mainframe terminal** › **Tests**, in this order:

| Test | What it does | `[OK]` |
|---|---|---|
| **Test mainframe host** | Connects to the host and port; never signs in | The host answers (or "assumed reachable" without a host) |
| **Test terminal launch** | Starts the terminal, reads the Core Business Menu, closes it with `99` and `XX`; never signs in | **... passed: ...**; **Show details** lists the steps and screenshots |
| **Test sign-in and navigation** | Asks for confirmation, signs in once with the service account, opens Task 903, confirms it on the screen, signs off. Never types account data | **... passed: ...** |
| **Test password screen** (Developer, optional) | Signs in and opens Task 0890 without typing on it | **... passed: ...** |

   `[NG]` **Pause processing first (System page > Pause processing) ...** → step 1. **Outside the operating window: ...** → test inside the window. **The last check could not sign in. To protect the service account from a lock-out, the next sign-in check is possible in N minute(s); check the password first.** → check the service-account values (Step 9.2.1); saving a new value lifts the wait. **Terminal executor could not be built — ...** on the System page → Step 9.2.1.
6. **Settings › Fujitsu Mainframe terminal › Terminal summary (as the service runs now)**: **Terminal started as administrator** and **This service runs as administrator** are not **Yes** and **No**.
7. Leave processing **paused** until Step 13.2.

**Good and bad cases — terminal tests**

| Case | What happens |
|---|---|
| **All three tests pass** | The real terminal is ready; processing can be resumed in Step 13.2 |
| Terminal does not start in **Test terminal launch** | New Fujitsu Mainframe requests are held until it starts, as after a failed request |
| センター準備中 (centre not ready) or 回線エラー (line error) at sign-in | New Fujitsu Mainframe requests are held; a later passed sign-in test releases them |
| Sign-in refused with a recognised message (wrong password, operator code not registered) | The same e-mail as for a request goes to the team that owns the service account; the next sign-in test waits 10 minutes |
| Windows refuses the keystrokes (session locked or minimized) | The test fails; requests wait (Step 11.6) |
| A test of the saved settings finds Fujitsu Mainframe unavailable | Outage e-mail once; a later passed test sends the recovery e-mail |

### Step 12.8 Fujitsu RACF (optional)

Prepare the server first: WSMGR with DSPEMU is installed for the bot account, with the **接続1** connection on the desktop; opened by hand in the bot's session it shows `JCET020 SYSTEM READY`; close it again (the bot opens it itself, and with two **接続1 - DSPEMU** windows open the start is refused).

1. **Settings › This machine › Fujitsu RACF** (Developer): **Fujitsu RACF (second application)** On, **Fujitsu RACF host (probe)**, **Fujitsu RACF port (probe)** → **Save and restart**. The Fujitsu RACF pages appear under **Settings**.
2. The password: Step **9.3** (stored, or from CyberArk).
3. **Settings › Fujitsu RACF terminal and sign-on**: **Fujitsu RACF system** (`TSS3` test, `TSS2` production), **Fujitsu RACF sign-on ID** (`SAILPNT`), **Fujitsu RACF window title contains** `接続1 - DSPEMU` (default), **Fujitsu RACF terminal program (instead of the shortcut)** empty unless the console is started from a program file (a value that is not a file is refused), **RACF sign-on ID password: last changed on** `YYYY-MM-DD` → **Save changes**, **Restart service**.
   **Sample (QA):** **Fujitsu RACF terminal shortcut** `C:\ProgramData\Fujitsu\WSMGR\接続1.emd`; **Fujitsu RACF terminal program (instead of the shortcut)** empty (`接続1` is not a file; the shortcut is used); **Fujitsu RACF window title contains** `接続1 - DSPEMU`; **Fujitsu RACF system** `TSS3`; **Fujitsu RACF sign-on ID** `SAILPNT`; **Start the Fujitsu RACF terminal as administrator** (Developer) On.
4. **Settings › Fujitsu RACF tickets and e-mails**: **Fujitsu RACF team** addresses; **Fujitsu RACF team: support reports only** On (default); **Fujitsu RACF removals** **Left for a person (the ticket is told why)** for now.
5. **Settings › Fujitsu RACF completion ticket** (Developer, optional): **Completion ticket in ServiceNow** On only when the app team wants one, **Completion ticket: assignment group** set (Sample (QA): `MFT-SYS Programmer-JPN`); **Save changes**; **Test completion ticket** creates one sample ticket marked `[TEST]`.
6. **System › Pause processing** (if not paused), then on **Settings › Fujitsu RACF terminal and sign-on**: **Test Fujitsu RACF host**, **Test Fujitsu RACF terminal launch**, **Test Fujitsu RACF sign-on** (asks for confirmation). Each test starts the Fujitsu RACF terminal once; no command is typed.

**Good and bad cases — Fujitsu RACF tests**

| Case | What happens |
|---|---|
| **All three pass** | Fujitsu RACF is ready; its first create and removal are tested in Step 13.3 with test IDs |
| The sign-on ID is in use, or the host is not available | Fujitsu RACF requests wait; the sign-on is tried again; Fujitsu Mainframe keeps running |
| The password is refused | The e-mail goes to the teams set for refused sign-ons; correct the password (Step 9.3) and restart |
| Production, real terminal, no Fujitsu RACF CyberArk account | Fujitsu RACF requests wait (Step 9.3) |

### Step 12.9 Finish the setup

1. **Settings › This machine › Credentials**: every value needed shows as set (the page names the Windows account the values are stored for, which must be the bot account).
2. Close the assistant's **Summary** with **Finish**, or on the **Dashboard** checklist select **Mark setup complete**.
3. Create a personal console account for each person (**Users**) with the right role; keep `admin` for administration only.

**Before you go on:**

- ServiceNow **Test connection** and **Preview tickets** pass; polling is still Off.
- **Send test e-mail** arrives; test mode points at the test mailbox.
- **CyberArk** card **Connected**; **Service account password from: CyberArk**.
- The simulator rehearsal completed; the real terminal's three tests pass; processing is paused.
- The **last changed on** dates are entered.
- Fujitsu RACF (when used): its three tests pass.

---

## 13. End-to-end test and go-live

> **In plain words.** Real test tickets are processed end to end on the real terminal, the results are checked everywhere they appear, the service is locked down for production, test mode is switched off, and the sign-off checklist is completed.

**Who does this:** Admin and Developer, with the ServiceNow, Fujitsu Mainframe (and Fujitsu RACF) teams; Project lead signs off.

### Step 13.1 Prepare test tickets

With the Fujitsu Mainframe team (and the Fujitsu RACF team), agree test accounts and raise SailPoint test tickets in ServiceNow: one create, one removal, one that fails the ticket checks (for example a missing affiliation code), and with Fujitsu RACF one create and one removal in the test system with test IDs. From now on every request works on the real terminal: use only the agreed test accounts.

### Step 13.2 Start polling and processing

1. **Settings › ServiceNow** › **Poll ServiceNow for tickets** On → **Save changes** (applies at once).
2. **System › Resume processing**.
3. **System › Check ServiceNow now** to poll at once.

### Step 13.3 Check each result

| Where | What to check |
|---|---|
| **Dashboard** | The requests move from **Queued** to **In progress** to a final status; no **Needs attention** line |
| **Requests** | **Completed** for the create and the removal; the ticket that failed the checks is rejected with its reason |
| **Evidence** | The screenshots of each step; the initial password of a new account is blacked out |
| **History** | Each request with its outcome and the current ServiceNow state of the ticket |
| ServiceNow | The task was claimed (**State set on pickup**), then closed with the closing comment; the rejected ticket noted (or handed to the rejection group) |
| Test mailbox | The outcome e-mails, the support report per SailPoint ticket, the registration notice; every e-mail with the `UAT` name |
| **Audit** | The sign-ins, settings changes, requests and e-mails, with the intended recipients |

**Good and bad cases — end-to-end**

| Case | What happens |
|---|---|
| **Create succeeds** | **Completed**; ticket closed complete; support report and completion notice |
| **Removal of an account that no longer exists** | **Already removed**; ticket closed complete with a note that no change was needed (**Close the ticket when the account was already removed** On) |
| Result could not be confirmed on the screen | **Needs verification**; ticket closed as Closed Incomplete with a note asking for a manual check; a "please verify" e-mail; for Fujitsu RACF no completion ticket |
| Failure after the allowed attempts | **Failed**; ticket closed as Closed Incomplete with the reason (**Close the ticket when the request failed** On) |
| Ticket fails the checks | Not queued; rejection note on the ticket; rejection e-mail |
| Duplicate ticket | Not queued; the duplicate e-mail lists the **Matching fields** in readable labels |
| Outside the operating window, or paused | The request waits as **Queued** |
| Bot's Windows session locked | The request waits; **Requests wait: ...** on the System page (Step 11.6) |

### Step 13.4 Store the machine API key

Requests from other programs (and the bot's own ServiceNow collector, which uses the first key) must present a key. The first entry should be the ServiceNow client. *Bot window*, generate a key:

```powershell
$bytes = New-Object byte[] 32
[Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($bytes)
'snow:' + [Convert]::ToBase64String($bytes)
```

`[OK]` One line `snow:<44 characters>`. Keep it in the password vault.

*Console, Developer:* **Settings › This machine › Credentials** › **Machine API keys (ServiceNow connector, CLI)**: paste the line → **Save changes**. Several clients are separated by commas (`snow:<key>,cli:<key>`).

### Step 13.5 Switch to production mode

*Console, Developer, **Settings › This machine**, in this order:*

1. **Security**: **Require the machine API key** On; **Console sign-in may use the API** On (so that **New request** in the console keeps working).
2. **Deployment**: **Mainframe environment** set explicitly (`production` for the production host).
3. **Deployment**: **Service environment** `production`.
4. **Save and restart**.

| What production changes | Consequence |
|---|---|
| The machine API key | The production default is On, but the starter `.env` holds `AUTH_ENABLED=false`, which wins: the key is required only once **Require the machine API key** is switched On (item 1). With it On and no **Machine API keys**, the service does not start: `auth_enabled=True but FINESIII_API_KEYS is empty — refusing to start an unauthenticated service (fail-closed).` Hence Step 13.4 first |
| CyberArk required with the real terminal | Fujitsu Mainframe requests are processed only while the password comes from CyberArk (Step 9.2); Fujitsu RACF requests wait without its CyberArk account (Step 9.3) |
| Failed-request password kept 0 days | The password of a failed request is erased at once (**Keep the password of a failed request for (days)** default 0); a bot-generated one is replaced on **Retry**, a ticket-supplied one needs a resubmission |
| **Mainframe environment** default | `production` (no `99` prefix) unless set |
| **Verify TLS certificate** (CyberArk) | Cannot be switched off |

`[OK]` `agent.log` shows **Environment : production (ProductionConfig)**; the System page no longer shows **Requests are accepted without an API key. ...**; **Dashboard** **Bot service Running**.
`[NG]` The service does not come back and `agent.log` shows the API key line above → `notepad C:\FINESIII\app\.env` (bot window); set `AUTH_ENABLED=false`; start the task; do Step 13.4; repeat this step.
`[NG]` The System page still shows **Requests are accepted without an API key. ...** → **Require the machine API key** is not On (the `.env` line `AUTH_ENABLED=false` is still in force) → item 1, **Save and restart**.

### Step 13.6 Leave e-mail test mode

**Settings › E-mail**: clear **Send every e-mail only to (testing)**; set **Environment name shown in e-mails** to `PRODUCTION` (or blank); decide **Send the initial password to the new user** with information security → **Save changes**. Let the e-mail outbox empty first, or delete e-mails kept during the test. `[OK]` The Dashboard warning **E-mail test mode: every e-mail goes only to ...** is gone.

### Step 13.7 Go live

1. **System**: **Needs attention** empty; **Database**, **Database password** (latest from CyberArk), **CyberArk**, **ServiceNow** (On) and the terminal cards in order.
2. **Validate database password** → **Password validated. ...**
3. Processing resumed; the first real tickets followed on **Requests** and **Evidence**.
4. Section 14's morning checks are handed to the operations team.

### Step 13.8 Sign-off checklist

| # | Check | Evidence | Done |
|---|---|---|---|
| 1 | Package complete | Step 4.3 printed nothing | ☐ |
| 2 | Prerequisites | **READY** (section 5); `FINESIII_DATA_DIR` = `C:\FINESIII\data` | ☐ |
| 3 | Time zone | `Tokyo Standard Time` | ☐ |
| 4 | Permissions | `icacls` lists only SYSTEM, Administrators and the bot account | ☐ |
| 5 | Bot account rights approved | Administrators (or the alternative), approved by information security | ☐ |
| 6 | RDS reachable and encrypted | `TcpTestSucceeded : True`; `rds.force_ssl = 1`; pgAdmin `ssl = true` | ☐ |
| 7 | Databases with least privilege | **READY** from `Setup_Database.py`; history and audit events protected by the database | ☐ |
| 8 | No password in files | `.env` holds no password | ☐ |
| 9 | Database password from CyberArk | Step 9.1.3 **READY**; card **Latest password from CyberArk**; **Validate database password** → **Password validated** | ☐ |
| 10 | First start | **Ready** line; self-test exit code 0; `--check-db` **Result : OK** | ☐ |
| 11 | `admin` password changed; personal accounts created | **Bot service Running**, **Database Connected** | ☐ |
| 12 | Background run | Task started; Step 11.3 checks; `Check_Unattended.ps1` no FAIL | ☐ |
| 13 | Automatic start, recovery and stop | Step 11.4 | ☐ |
| 14 | Session policy | Option A–D recorded; screen-lock exceptions from IT | ☐ |
| 15 | ServiceNow | **Test connection**, **Preview tickets**; polling On | ☐ |
| 16 | E-mail | **Send test e-mail**; E-mail samples reviewed; test mode off | ☐ |
| 17 | Fujitsu Mainframe CyberArk | **CyberArk** card **Connected** | ☐ |
| 18 | Real terminal | The three tests pass; **This service runs as administrator: Yes** | ☐ |
| 19 | Password dates | **last changed on** entered (Fujitsu Mainframe, and Fujitsu RACF when used) | ☐ |
| 20 | Fujitsu RACF (when used) | Three tests pass; first create and removal with test IDs | ☐ |
| 21 | End-to-end | Step 13.3 results as expected | ☐ |
| 22 | Production mode | API key stored; **Environment : production**; no API key notice | ☐ |
| 23 | Backups | Data folder in the server backup; RDS automated backups on | ☐ |

Signed off by (installation administrator / project lead / date): ____________________

**Before you go on:** every line of the checklist is ticked. Daily operation continues with Part 2, section 14.
## 14. Daily operation commands

> **In plain words.** Once the bot runs in the background, most daily work is done on the console's **System** page: pause and resume, check ServiceNow now, validate the database password, run the self-test, restart and stop. A handful of PowerShell commands do the same from the server and show the logs. Each command returns at once and changes nothing unless it says so.

**Who does this:** Server team (PowerShell), Admin and Developer (console).

**Where:** PowerShell commands run from `C:\FINESIII\app`. Run them **as the bot account** (`<bot account>`) unless the step says *administrator window*: the self-test, the database check and the password reset read the bot account's Credential Manager. Replace `8000` with your `<console port>` if it differs.

**Sample (QA):** bot account `R6-CORE\prvrnel`.

### Step 14.1 Is the bot running?

*As the bot account, or in an administrator window.*

```powershell
cd C:\FINESIII\app
Get-Content 'C:\FINESIII\data\agent.json' -ErrorAction SilentlyContinue
Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:8000/api/v1/ping' | Select-Object StatusCode, Content
Get-ScheduledTask -TaskPath '\AIG\' -TaskName 'FINESIII RPA Agent' | Get-ScheduledTaskInfo | Select-Object LastRunTime, LastTaskResult
```

**Expected result**

- `[OK]` `agent.json` shows `url`, `port`, `pid`, `version` (`3.0.0`) and `started_at`. The file exists only while the service runs.
- `[OK]` The ping answers `200` and `{"status":"ok"}`. The ping needs no key and tells nothing about the database.
- `[OK]` `LastTaskResult` is `267009` (the task's launcher is running).

**If it is different**

| Symptom | Cause | Fix |
|---|---|---|
| `[NG]` No `agent.json`, the ping fails | The service is stopped, or is starting (allow up to a minute while the screen-reading engine loads) | Wait a minute and repeat. Still nothing: Step 14.3, then section 18.1. |
| `[NG]` `agent.json` names another port than 8000 | Port 8000 was taken when the service started; the service took a free port | Use the address in `agent.json`. Free port 8000 and restart (Step 14.4). |
| `[NG]` `LastTaskResult` is `0` and the ping fails | The launcher ended because the service was stopped normally | Start it (Step 14.3). |

### Step 14.2 Is the database healthy?

The ping does not look at the database; the health address does. In test mode it needs no key. With **Require the machine API key** on (production), add the key of the machine API keys:

```powershell
Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:8000/api/v1/health' -Headers @{ 'X-API-Key' = '<API key>' } | Select-Object StatusCode, Content
.\.venv\Scripts\python.exe desktop\app.py --check-db
```

**Expected result**

- `[OK]` `200` with `"service":"up"`, `"database":"up"`, `"engine":"postgres"`, the queue depth and the availability state.
- `[OK]` `--check-db` ends with ` Result   : OK` and exit code 0. With the database password from CyberArk, the command reads the password from CyberArk once before it checks.

**If it is different**

| Symptom | Cause | Fix |
|---|---|---|
| `[NG]` `503` and `"database":"down"` | The service runs but cannot reach the database | Section 18.2. Requests wait; nothing is lost. |
| `[NG]` `401` | The machine API key is required and was not given or is wrong | Add the header with a key from **Settings › This machine › Credentials › Machine API keys (ServiceNow connector, CLI)**. |
| `[NG]` `--check-db` shows ` Error    :` and ` Result   : FAILED` | The address, the password or the network is wrong | Read the ` Hint     :` line; section 18.2. |
| `[NG]` `[WARN] database password from CyberArk: ...` before the result | The CyberArk settings are incomplete or CyberArk did not answer | Section 18.3. |

### Step 14.3 Start the service

*As the bot account, or in an administrator window. The bot account must be signed in.*

```powershell
Start-ScheduledTask -TaskPath '\AIG\' -TaskName 'FINESIII RPA Agent'
```

The command returns at once. Allow 15 to 30 seconds, up to a minute, then repeat Step 14.1.

**Expected result**

- `[OK]` `C:\FINESIII\data\logs\agent.log` ends with `LAUNCHER | starting the service`, the start summary and ` Ready — http://127.0.0.1:8000 (pid <n>). Running in the background until stopped.`
- `[OK]` A pause set before the stop is kept: the **System** page still shows **Resume processing** until someone selects it.

For troubleshooting only, the service can run in the foreground in a visible window. Do not do this while the scheduled task runs it: a second copy on the same data folder is refused with `[STOP]` and exit code 3.

```powershell
cd C:\FINESIII\app
.\.venv\Scripts\python.exe desktop\app.py --agent
```

Stop a foreground run with Ctrl+C in its window, or with Step 14.4 from another window.

### Step 14.4 Stop and restart

**From the console** (Admin or Developer): **System › Stop the bot** stops the service after the request in progress; **System › Restart service** (or **Save and restart** on the Settings page) rebuilds the service in the same process and comes back by itself. The console waits for the restart and says **Restarted.** or **Restarted — the saved settings are now in force.**

**From PowerShell** (as the bot account, or in an administrator window):

```powershell
cd C:\FINESIII\app
.\.venv\Scripts\python.exe desktop\app.py --stop
```

To restart from PowerShell, stop, then start:

```powershell
.\.venv\Scripts\python.exe desktop\app.py --stop
Start-ScheduledTask -TaskPath '\AIG\' -TaskName 'FINESIII RPA Agent'
```

**Expected result**

- `[OK]` ` Asking the agent at http://127.0.0.1:8000 (pid <n>) to stop…`, then ` Agent stopped.` and exit code 0. `agent.log` shows `the service stopped normally; the launcher ends`.
- `[OK]` ` No AIG IAM Access RPA agent is running.` (exit code 0): it was not running.

**If it is different**

| Symptom | Cause | Fix |
|---|---|---|
| `[NG]` ` [WARN] The agent is still running — a transaction may be in progress. It will stop when the drain completes.` (exit code 1) | A request is still on the terminal. `--stop` waits about 5.5 minutes | Wait. Do not end the process: the terminal would be left on the screen it was on. Repeat Step 14.1 later. |
| `[NG]` **Restart service** answers "A terminal check is running. Wait until it has finished (it signs off the terminal), then restart." | A console terminal test is running | Wait for the test to finish, then restart. |
| `[NG]` **Restart service** answers "Not restarted: the database password from CyberArk could not be obtained: ... The service keeps running as it was." | The database password from CyberArk is on and the restart could not read or apply it | Nothing changed. Correct the cause (section 18.3) and restart again. |
| `[NG]` A changed **Service port** has no effect after **Restart service** | The port is kept by a restart in the same process | Stop and start (PowerShell commands above). |

> **Important.** Never end the service in Task Manager or with **End** on the scheduled task. **End** stops only the launcher; the service keeps running without automatic recovery. A forced end in the middle of a request leaves the terminal on its last screen.

**Good and bad cases**

| Case | What happens |
|---|---|
| **Stop while idle** | The service stops within seconds. |
| **Stop while a request runs** | The request finishes first, including the sign-off, for up to **Shutdown drain (s)** (300 by default). |
| The request does not finish in that time | The service stops and reports `Stopped (drain timed out — see the log).` At the next start the request is put back in the queue. |
| The service ends unexpectedly (crash) | The launcher notes `the service stopped unexpectedly (exit code <n>); starting it again in 60 seconds` and starts it again. The Dashboard and System page report the unexpected end once. |
| The bot account signs out | The service stops with the session. It starts again at the next sign-in of the bot account. |
| **Restart service** while a request runs | The console says it waits for the request in progress; the restart follows. |

### Step 14.5 Pause and resume processing

*Console, System page, Admin or Developer.* There is no PowerShell command for this; the pause is a console action recorded in the audit trail with your name.

1. Select **Pause processing**. `[OK]` **Paused. No new work starts; a transaction in progress finishes.** New requests are still accepted and wait in the queue.
2. Select **Resume processing** when ready. `[OK]` **Processing resumed.**

| Case | What happens |
|---|---|
| **Pause, then restart or reboot** | The pause is kept: processing stays paused until someone selects **Resume processing**. |
| **Resume while a terminal test runs** | Refused: "A terminal check is running; resume once it has finished." |
| **Resume after a refused Fujitsu RACF sign-on** | The resume also ends the Fujitsu RACF hold: the person resuming is taken to have dealt with the password. |
| **Process queued work** (Settings › Dispatcher) switched off | Not a pause: nothing runs the queue after the restart. Use **Pause processing** to stop work for a while. |

### Step 14.6 Check ServiceNow now, refresh CyberArk now

*Console, System page.*

| Button | Shown when | What it does | Expected result |
|---|---|---|---|
| **Check ServiceNow now** | **Poll ServiceNow for tickets** is on | Fetches tickets now instead of at the next poll (every 30 minutes by default) | `[OK]` **Checking now — the card updates in a few seconds, or after about 30 seconds when ServiceNow does not answer.** The **ServiceNow** card shows the result. |
| **Refresh CyberArk now** | **Fetch the mainframe password from CyberArk** is on | Fetches the Fujitsu Mainframe service-account password now | `[OK]` **Password fetched from CyberArk at <time> (JST).** `[NG]` **CyberArk did not deliver the password: <reason>**: section 18.3. |
| **Validate database password** | **Database password from CyberArk** is on | Checks the database password against CyberArk now | Section 16.1, Step 16.1.2. |

### Step 14.7 Read the logs

*As the bot account, or in an administrator window.*

```powershell
Get-Content 'C:\FINESIII\data\logs\agent.log' -Tail 50 -Encoding UTF8
Get-Content 'C:\FINESIII\data\logs\finesiii_rpa_v3.log' -Tail 50 -Wait -Encoding UTF8
Select-String -Path 'C:\FINESIII\data\logs\finesiii_rpa_v3.log' -Pattern 'ERROR' | Select-Object -Last 20
```

`-Wait` follows the log; Ctrl+C ends only the display. An empty `ERROR` search is a good result. In the console, the same logs are at the foot of the **System** page: **Service log** or **Agent console**, the number of lines, **Warnings and errors** or **Errors only**, and **Search the log**.

| Log | Holds | Rotation |
|---|---|---|
| `C:\FINESIII\data\logs\agent.log` | The launcher's notes, the start summary, the **Ready** line and any `[FATAL]` line | Limited to 10 MB, checked at each start and every hour; the earlier content is kept as `agent.log.1` |
| `C:\FINESIII\data\logs\finesiii_rpa_v3.log` | Everything the running service does | A new file every midnight, earlier days as `finesiii_rpa_v3.log.<YYYY-MM-DD>`, deleted after **Keep the service log for (days)** (30 by default) |
| `C:\FINESIII\data\logs\setup_*.log`, `setup_database_*.log` | Each run of the set-up scripts | Not rotated: delete old ones in the regular clean-up |
| `C:\FINESIII\data\logs\ticket_data_reset.log` | Each run of the clear-ticket-data tool (section 17.6) | Not rotated |

The service log holds employee and affiliation codes; it never holds a password. Treat it as personal data.

### Step 14.8 Self-test and diagnostics

```powershell
.\.venv\Scripts\python.exe desktop\app.py --selftest
$LASTEXITCODE
```

- `[OK]` Every line OK or skipped, exit code `0`. The same test is **System › Run self-test**: **Every component is usable.**
- `[NG]` A failed line names the component, exit code `1`. "ocr engine": the screen-reading packages or models are missing; run `Setup_Prerequisites.ps1 -CheckOnly` (administrator window) and follow its FAIL lines.

For support, collect **System › Download diagnostics** (`finesiii-diagnostics.zip`, passwords and keys masked) and:

```powershell
.\.venv\Scripts\python.exe desktop\app.py --selftest --json
.\.venv\Scripts\python.exe desktop\app.py --check-db --json
```

### Step 14.9 The morning check

*Console, Admin; about five minutes.*

| # | Where | Look for | `[OK]` | When it is different |
|---|---|---|---|---|
| 1 | **Dashboard** | Service, database, processing, the window of each application, the queue | All healthy; queue moving inside the operating window | Section 18 for the area named |
| 2 | **Dashboard** and **System**: **Needs attention** (red) and **Warnings** | Problems and security notices | Empty | Each line says what to do |
| 3 | **System › Processing** card | Running, paused or waiting, and why | Running (or paused on purpose) | **Resume processing**, or the reason named |
| 4 | **System › Database password** card (when used) | **Latest password from CyberArk**, **Last successful check** within the check interval | Green card, no problem line | Section 16.1 |
| 5 | **System › CyberArk** card (when used) | Last fetch, no error | Fetched within the refresh interval | **Refresh CyberArk now**, section 18.3 |
| 6 | **System › ServiceNow** card | Last poll and its result | Recent poll, no failures | Section 18.4 |
| 7 | **System › E-mail** card and **E-mail outbox** | Delivery | **On**, outbox empty | Section 18.5 |
| 8 | **Requests**, filtered on **Failed** and **Needs verification** | New failures since yesterday | None, or each one handled | A **Needs verification** request: check the account by hand, do not retry |
| 9 | **Settings › Fujitsu Mainframe terminal** and **Fujitsu RACF terminal and sign-on**, **Tests** row | The password-age line | Not due | Section 16.2 or 16.3 |
| 10 | Server: `unattended\Check_Unattended.ps1` (administrator window, weekly) | The unattended set-up | No FAIL line | Section 18.7 |

### Step 14.10 What the System page tells you

| Part | What it shows |
|---|---|
| Row of buttons | **Pause processing** / **Resume processing**, **Refresh CyberArk now**, **Check ServiceNow now**, **Validate database password**, **Run self-test**, **Download diagnostics**, **Restart service**, **Stop the bot**. Each appears only when it applies and the role allows it. |
| **Needs attention** and **Warnings** | Why requests wait or a function is off, in plain words, with what to do. The bot's Windows session line reads, for example, "Requests wait: the bot's Windows session is locked. Keep the bot's session signed in, unlocked and not minimized; processing resumes by itself." |
| **Bot service** | **Running** or **Running with problems**, how long it has run, and a port warning when it runs on another port than configured |
| **Processing** | Running, paused (by whom, since when) or waiting, with the reason |
| **Terminal**, **Database**, **Screen reading**, **Credential store** | The terminal driver and mainframe environment, the database engine, whether screen reading works, whether the bot account's Credential Manager is available |
| **Fujitsu Mainframe window** (**Mainframe window** while Fujitsu RACF is off), **Fujitsu RACF** | Each application's window, availability and reasons to wait |
| **CyberArk**, **Database password** | The Fujitsu Mainframe password from CyberArk, and the database password from CyberArk (section 16.1) |
| **E-mail**, **E-mail outbox** | Delivery, and e-mails kept for resending (**Resend now**) |
| **ServiceNow** | The last poll, its counts and its problems |
| **Configuration files**, **Service log** | The configuration files in force, and the log viewer |

**Before you go on**

- [ ] You can tell from Step 14.1 whether the bot runs, and from Step 14.2 whether its database is healthy.
- [ ] You stop the bot only with `--stop` or **Stop the bot**, and pause it with **Pause processing**.
- [ ] The morning check is part of the daily routine.

---

## 15. Applying an update folder

> **In plain words.** Fixes and improvements arrive as an update folder that holds only the changed files. You confirm that the server has the expected versions, stop the service, keep a copy of the files that are replaced, copy the new files, verify them, start the service and check it. If anything is wrong, you put the copy back. The update's own `PATCH_README.txt` names its files, its checks and any extra step; **its commands always take priority over this section.**

**Who does this:** Server team. Admin for the checks on the console.

**Where:** an administrator window (an account that may write to `C:\FINESIII\app`), in `C:\FINESIII\app`. Replace `<update folder>` with the full path of the update folder, and `<name>` with a short name of the update (for example the end of the folder name).

An update folder contains:

| File | Purpose |
|---|---|
| `PATCH_README.txt` | Which servers the update is for, what it changes, the files that may show as NEW, the steps with their commands, the checks after the update and the way back |
| `PRECHECK_ACCEPTED.txt` | Every version of each file the update may replace: SHA-256 checksum, two spaces, path inside the application folder. A file may be listed more than once; any listed version is accepted. |
| `PATCH_CONTENTS.txt` | Every file as it is after the update, in the same format |
| `app\` | The files, in the same folders as in `C:\FINESIII\app` |

Updates are cumulative: the newest folder contains every earlier update its README names. Install only the newest one. The README names the updates a server must already have.

### Step 15.1 Before the update

1. Read the whole `PATCH_README.txt`, in particular "What changes", "Files" (files removed, database changes, new packages) and "Check after the update".
2. Agree a time outside busy hours. When the README says the update changes the database, the database administrator takes a manual RDS snapshot first.
3. *Console:* **System › Pause processing**, and wait until no request is running (**Processing** card).
4. On the bot's desktop, close any terminal window or dialog left open, including a Fujitsu Mainframe window left after a check after "centre not ready", and the menu window (`99`, then `XX`).
5. Keep a copy of each configuration file the README names that was edited on this server (for example `config\email_messages.yaml`, `config\notifications.yaml`, `src\rpa\screens\layouts.yaml`).

### Step 15.2 Precheck: the server has versions this update replaces

```powershell
cd C:\FINESIII\app
$ok = @{}
Get-Content '<update folder>\PRECHECK_ACCEPTED.txt' | Where-Object { $_ -match '^[0-9a-f]{64}  ' } | ForEach-Object {
    $hash, $path = $_ -split '  ', 2
    if (-not $ok.ContainsKey($path)) { $ok[$path] = @() }
    $ok[$path] += $hash
}
$ok.Keys | Sort-Object | ForEach-Object {
    if (-not (Test-Path -LiteralPath $_)) { "NEW      $_" }
    elseif ($ok[$_] -notcontains (Get-FileHash -Algorithm SHA256 -LiteralPath $_).Hash.ToLower()) { "CHANGED  $_" }
}
```

**Expected result**

- `[OK]` No output, or `NEW` only for the files the README names as possibly new (for example test files, or tool scripts that were delivered in their own folders).

**If it is different**

| Symptom | Cause | Fix |
|---|---|---|
| `[NG]` `CHANGED  config\...yaml` or another configuration file | The file was edited on this server | Do what the README says for that file: either keep the local file (delete it from the update's `app` folder before Step 15.5), or let the update replace it and enter the local changes again in the new file. Some files must always be the update's; the README lists them. |
| `[NG]` `CHANGED` for any other file | The server is not at one of the versions the update was built for | Do not install the update. Send the lines to the support team. |
| `[NG]` Many `NEW` lines the README does not name | The server lacks an earlier update the README requires, or the command ran in the wrong folder | Check the folder (`C:\FINESIII\app`) and the README's list of required updates. |

### Step 15.3 Stop the service

```powershell
.\.venv\Scripts\python.exe desktop\app.py --stop
```

`[OK]` ` Agent stopped.` `[NG]` ` [WARN] The agent is still running ...`: a request is still running; wait and repeat (Step 14.4).

### Step 15.4 Back up the files that are replaced or removed

Set `$retired` to the files the README lists as removed, or leave it empty (`@()`) when it lists none.

```powershell
$stamp = Get-Date -Format yyyyMMdd-HHmm
$backup = "C:\FINESIII\backup-<name>-$stamp"
$patch = '<update folder>\app'
$retired = @()
New-Item -ItemType Directory -Force -Path $backup | Out-Null
$files = @(Get-ChildItem $patch -Recurse -File -Force | ForEach-Object { $_.FullName.Substring($patch.Length + 1) }) + $retired
$files | ForEach-Object {
  if (Test-Path -LiteralPath ".\$_") {
    New-Item -ItemType Directory -Force -Path (Split-Path "$backup\$_") | Out-Null
    Copy-Item -LiteralPath ".\$_" "$backup\$_"
  } elseif ($retired -notcontains $_) {
    Add-Content -LiteralPath "$backup\NEW_FILES.txt" -Value $_
  }
}
"Backup: $backup"
```

`[OK]` `Backup: C:\FINESIII\backup-<name>-<stamp>`. **Write this folder name down**: going back needs it. `NEW_FILES.txt` in it lists the files the update adds.

### Step 15.5 Copy the files

```powershell
Copy-Item "$patch\*" C:\FINESIII\app -Recurse -Force
Get-ChildItem C:\FINESIII\app -Recurse -File | Unblock-File
if ($retired.Count) { Remove-Item -LiteralPath $retired -ErrorAction SilentlyContinue }
```

Then do any extra step the README names at this point: `Setup_Prerequisites.ps1` for new packages, or `Setup_Database.py` for a database change (with the database password from CyberArk, use the command order of Step 16.1.6).

### Step 15.6 Verify every file

```powershell
Get-Content '<update folder>\PATCH_CONTENTS.txt' | Where-Object { $_ -match '^[0-9a-f]{64}  ' } | ForEach-Object {
    $hash, $path = $_ -split '  ', 2
    if (-not (Test-Path -LiteralPath $path)) { "MISSING  $path" }
    elseif ((Get-FileHash -Algorithm SHA256 -LiteralPath $path).Hash -ne $hash) { "CHANGED  $path" }
}
```

`[OK]` No output, or only the files deliberately kept in Step 15.2.
`[NG]` `MISSING` or `CHANGED` for other files: the copy was incomplete. Repeat Step 15.5, then this step. Still failing: go back (Step 15.8).

### Step 15.7 Start and check

```powershell
Start-ScheduledTask -TaskPath '\AIG\' -TaskName 'FINESIII RPA Agent'
```

1. After 15 to 60 seconds, the checks of Step 14.1 and Step 14.2.
2. In the browser, refresh the console with **Ctrl+F5**, so that the updated console files are loaded.
3. The checks the README lists under "Check after the update".
4. **System › Resume processing**, and confirm that requests are processed as before.
5. Optional: the automated tests the README names. Run them in a new PowerShell window with a temporary data folder, as `RUN_COMMANDS.txt` section 12 shows, so that they never touch the service's data: `$env:FINESIII_DATA_DIR = Join-Path $env:TEMP 'finesiii-tests'`, then the README's `.\.venv\Scripts\python.exe -m pytest ...` line. `[OK]` no failure. Close that window afterwards.

Keep the backup folder until the update is confirmed in operation.

**If it is different**

| Symptom | Cause | Fix |
|---|---|---|
| `[NG]` The console looks unchanged or unstyled | The browser kept the earlier console files | **Ctrl+F5** once. |
| `[NG]` The service does not come back (Step 14.1 fails) | A start-up error, shown in `agent.log` | Read the `[FATAL]` line (section 18.1). If it is not clearly a setting, go back (Step 15.8). |
| `[NG]` A README check fails | The update does not behave as described on this server | Note the check and the time, go back (Step 15.8) if processing is affected, and send the diagnostics. |

### Step 15.8 Going back

*A new administrator window. Use the backup folder of Step 15.4.*

```powershell
cd C:\FINESIII\app
$backup = 'C:\FINESIII\backup-<name>-<stamp>'
if (-not (Test-Path -LiteralPath "$backup")) { throw "Backup folder not found: $backup" }
.\.venv\Scripts\python.exe desktop\app.py --stop
Copy-Item "$backup\*" C:\FINESIII\app -Recurse -Force -Exclude NEW_FILES.txt
if (Test-Path -LiteralPath "$backup\NEW_FILES.txt") {
  Get-Content -LiteralPath "$backup\NEW_FILES.txt" | ForEach-Object { Remove-Item -LiteralPath "C:\FINESIII\app\$_" -ErrorAction SilentlyContinue }
}
Start-ScheduledTask -TaskPath '\AIG\' -TaskName 'FINESIII RPA Agent'
```

Then **Ctrl+F5** in the browser, and any extra going-back step of the README.

`[OK]` The service starts on the earlier files; Step 14.1 passes.
`[NG]` `Backup folder not found`: the name is mistyped. List the backups with `Get-ChildItem 'C:\FINESIII' -Directory -Filter 'backup-*'`.

> **Note.** Going back to a version that does not know the **Developer** role needs one more step *before* the files are taken back, with the service stopped, as the bot account: `.\.venv\Scripts\python.exe scripts\developer_role_to_admin.py` lists the Developer accounts, and `.\.venv\Scripts\python.exe scripts\developer_role_to_admin.py --apply` gives them the Administrator role. A README says when this applies.

**Good and bad cases**

| Case | What happens |
|---|---|
| **Precheck clean, copy verified, checks pass** | The update is in operation; delete the backup after the agreed period. |
| Precheck shows `CHANGED` for an edited configuration file | Handled as the README says for that file; the rest of the update is installed normally. |
| Precheck shows `CHANGED` for program files | The update is not installed. Nothing on the server changed. |
| The update is copied while the service runs | Not allowed: files in use may be mixed old and new. Always stop first (Step 15.3). |
| An older update folder is installed after a newer one | The precheck shows `CHANGED` lines: the server is newer than the update expects. Do not install it. |
| The service does not start after the update | Go back with Step 15.8; the earlier version starts on the same data. |
| A setting saved on the console before the update | Kept: updates never change saved settings unless the README says so. |

**Before you go on**

- [ ] The backup folder name is written down.
- [ ] Step 15.6 shows no output, and the README checks pass.
- [ ] Processing is resumed.

---
## 16. Passwords and secrets

> **In plain words.** The bot uses five kinds of secrets: the database password, the Fujitsu Mainframe service-account password, the Fujitsu RACF sign-on password, the console accounts' passwords, and the certificates it trusts. This section gives, for each one, what happens by itself, what a person does, and what to expect. No password is ever shown on the console, written to a log or sent by e-mail.

**Who does this:** as named in each part.

| Secret | Kept in | Changed by | Section |
|---|---|---|---|
| Database password (login `finesiii_app`) | From CyberArk (the administrator login's password, copied by the bot), or the bot account's Credential Manager | CyberArk's password manager (CPM), or the server team with `Setup_Database.py --set-password` | 16.1 |
| Fujitsu Mainframe service-account password | From CyberArk, or Credential Manager (**Service account — password**) | CyberArk; or a Developer on Task 0890 from the console; or the bot itself (automatic change, off by default) | 16.2 |
| Fujitsu RACF sign-on password | Credential Manager (**Fujitsu RACF service account — password**), or CyberArk (settings file only) | The RACF administrators; the bot only reminds | 16.3 |
| Console passwords | The application database (hashed) | Each person; an administrator (provisional); the server team (break-glass) | 16.4 |
| Certificates | `C:\FINESIII\app\certs`, `C:\FINESIII\data\certs` | AWS (RDS); the organisation's certificate authority (CyberArk) | 16.5 |

### 16.1 Database password rotated by CyberArk, and manual database password change

> **In plain words.** When **Database password from CyberArk** is on (section 9.1, Database password from CyberArk (CCP)), CPM changes the administrator login's password in CyberArk, and the bot gives its own login `finesiii_app` the same password by itself. Nobody types or stores a database password, and requests keep running during a change. Without CyberArk, the server team changes the password with the database script on an agreed date.

**Who does this:** nobody for a routine rotation. Admin or Developer for **Validate database password**; PAM team and database team when something fails; Server team for the manual change.

#### Step 16.1.1 What happens by itself

| When | What the bot does | E-mail (when e-mail is on) | Audit event (category `system`, actor `system`) |
|---|---|---|---|
| At start | Asks CyberArk for the administrator's password, waits up to 5 minutes for it, and gives `finesiii_app` the same password when it does not accept it yet. Without the password the service does not start (`[FATAL] The service did not start: ...`) and the launcher tries again 60 seconds later. | "Database password changed: the bot uses the new password" when the login had to be given a new password (**Found by: Bot start**) | `database_password_in_use`; `database_password_changed` when a new one was taken into use |
| Every **CyberArk check interval (minutes)** (15 by default) | Asks CyberArk whether the password changed; copies a new one | "Database password changed: the bot uses the new password" (**Found by: Scheduled check**) | `database_password_changed` |
| A database sign-in is refused | Asks CyberArk at once (at most once a minute) and copies the newest password | as above (**Found by: Check after the database refused a sign-in**) | `database_password_changed` |
| CyberArk says CPM is changing the password | Keeps the password in use and asks again a minute later | none | none |
| The copy fails (for example the administrator refuses the password) | Keeps the password in use and tries again a minute later, three times in all | After the third failure: "Database password not updated: the bot keeps working with the password in use" | `database_password_update_failed` (ERROR) |
| The next check works again | Ends the failure by itself; no click needed | "Database password updated: the bot uses the current password from CyberArk", with a **Found by** row | `database_password_update_recovered`, with `found_by` |
| CyberArk does not answer | Keeps the password in use | "CyberArk not available: the database password could not be checked", then "CyberArk (database password) Recovered" | `database_password_cyberark_unavailable`, `database_password_cyberark_recovered` |
| `finesiii_app` refuses the password in CyberArk, which did not change (someone changed the login's password outside CyberArk) | Sets the login back to the password in CyberArk and continues | "Bot's database login set back to the password in CyberArk" | `database_password_reapplied` (WARNING) |

The subjects above are the English half; each subject carries the Japanese text first, then ` / ` and the English text. The "changed" and "set back" e-mails go to the **Default recipients** and the **Database team** (Settings › E-mail › Recipients by system) when its addresses are set; they have no switch of their own. The "not updated" and "updated" e-mails go to the database team's routing, the CyberArk e-mails to the **CyberArk / identity team** routing; with an empty team list they reach the default recipients. No e-mail ever contains a password. Open connections are not affected by a change; new connections use the new password.

#### Step 16.1.2 Validate database password

*Console, Admin or Developer:* **System › Validate database password** (also next to **Database URL** on **Settings › This machine › Database**). It compares the password the bot uses with CyberArk, signs in with it, and copies a newer one at once. It can run once every 30 seconds; every click is recorded as `database_password_validated` with your name.

| Answer | Meaning | What to do |
|---|---|---|
| `[OK]` **Password validated. The bot uses the latest password from CyberArk.** | Same password, accepted by the database | Nothing |
| `[OK]` **Password validated and updated. The bot now uses the latest password from CyberArk; new connections use it.** | CyberArk had a newer password, or the login had to be set back; it is in use now | Nothing. The "changed" or "set back" e-mail follows. |
| `[NG]` **A check ran a moment ago; try again in N seconds.** ... | At most one check every 30 seconds | Wait and click again |
| `[NG]` **CyberArk is changing the password right now. The bot keeps using the password it has until the change is finished; try again in a minute.** | CPM is rotating it now | Wait a minute |
| `[NG]` **Not checked: <reason>.** followed by which password is in use | CyberArk did not answer or returned another account | Section 18.3 |
| `[NG]` **The new password from CyberArk could not be applied: <reason>.** or **The password could not be checked with the database: <reason>.** | The copy or the sign-in failed | Follow the reason: the PAM team checks the account in CyberArk, the database team checks the administrator's rights or the bot's login |
| `[NG]` **The database password does not come from CyberArk on this server ...** | **Database password from CyberArk** is off | Nothing to validate: the stored password is used |

#### Step 16.1.3 Read the Database password card

*Console, System page.* The card names no login.

| Line or title | Meaning |
|---|---|
| Title **Latest password from CyberArk** (green) | The bot uses the newest password |
| Title **Previous password in use** (amber) | CyberArk has a newer password that the bot could not apply yet; it tries again at each check |
| Title **CyberArk not reachable** (amber) | CyberArk does not answer; whether a newer password exists cannot be known |
| **Password in use: ...** | "the latest from CyberArk", "the previous password" or "the last one received from CyberArk", with the time it was taken into use |
| **Changed in CyberArk: ... JST** | When CPM last changed the password |
| **Last successful check: ... JST (every N min)** | The last check that worked |
| **Next check: ... JST** | The scheduled check, or the check a minute after a failure |
| **Last attempt failed: ... JST** | Shown while the latest attempt failed |
| A last line in plain words | The problem, for example "the database administrator account refused the password from CyberArk. Ask the PAM team to check the account in CyberArk" |

#### Step 16.1.4 Prove a rotation (test window, with the PAM team)

1. *Settings › This machine › Database* (Developer): set **CyberArk check interval (minutes)** to `1`, **Save and restart**.
2. The PAM team changes the password in CyberArk (a CPM change).
3. Within about a minute: `[OK]` **Changed in CyberArk** shows the new time, the "Database password changed" e-mail arrives with **Found by: Scheduled check**, and requests keep running.
4. Set the interval back to `15`, **Save and restart**.

**Good and bad cases**

| Case | What happens |
|---|---|
| **CPM rotates the password** | The bot copies it at the next check (or at the next refused sign-in); one "changed" e-mail; no interruption. |
| **The bot is stopped during a rotation** | At the next start the bot copies the password; "changed" e-mail with **Found by: Bot start**. |
| CyberArk is down for an hour | The bot keeps working with the password in use. Outage and recovery e-mails. A rotation in that hour is picked up at the first check after CyberArk answers. |
| The password is changed in the CyberArk vault only (not on the database) | The administrator refuses the new password; after three attempts "Database password not updated"; the bot keeps working with the previous password. Once the vault is put right, the next check ends the failure by itself. |
| Someone changes `finesiii_app`'s password by hand | The next new connection is refused; the bot sets the password back at once and sends "Bot's database login set back ...". Ask the database team who changed it. |
| `Setup_Database.py --set-password` is run while this is on | The script warns that the bot replaces the password; the bot sets the login back to the CyberArk password at its next start or refused sign-in. |

#### Step 16.1.5 Change the database password without CyberArk

*When **Database password from CyberArk** is off. Outside the operating window (06:00–22:00 JST by default). As the bot account, in `C:\FINESIII\app`.*

1. Stop the service:

```powershell
.\.venv\Scripts\python.exe desktop\app.py --stop
```

2. Give `finesiii_app` a fresh generated password. The script asks for the current password of `<admin login>` (paste it from the password vault; it is used for this run only). Add `--audit-database <audit database>` only when the audit trail is kept in PostgreSQL (section 8, Create the databases).

```powershell
.\.venv\Scripts\python.exe Setup_Database.py --rds --host <rds-endpoint> --admin-login <admin login> --set-password
```

**Sample (QA):**

```powershell
.\.venv\Scripts\python.exe Setup_Database.py --rds --host rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com --admin-login dbadmin --set-password
```

**Sample (QA)**, with the audit trail in PostgreSQL:

```powershell
.\.venv\Scripts\python.exe Setup_Database.py --rds --host rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com --admin-login dbadmin --audit-database finesiii_audit --set-password
```

3. Start the service and check it:

```powershell
Start-ScheduledTask -TaskPath '\AIG\' -TaskName 'FINESIII RPA Agent'
.\.venv\Scripts\python.exe desktop\app.py --check-db
```

**Expected result**

- `[OK]` The script shows `[CREATED] Password of 'finesiii_app': generated and kept in the credential store of <bot account> (never shown)` and `[CREATED] Login 'finesiii_app': exists - password set`, the verification as the application login passes, and the exit code is `0` (or `2`: ready, with warnings to read). **Sample (QA):** `... kept in the credential store of R6-CORE\prvrnel (never shown)`.
- `[OK]` `--check-db` ends with ` Result   : OK`; the **Dashboard** shows the database connected.

**If it is different**

| Symptom | Cause | Fix |
|---|---|---|
| `[NG]` `Sign-in as '<admin login>'` FAIL (Sample (QA): `Sign-in as 'dbadmin'`) | Wrong or rotated administrator password | Paste the current one from the vault; or, when CyberArk holds the administrator login, add `--admin-password-from-cyberark`. |
| `[NG]` The generated password "could not be stored" | The script was not run as the bot account in a normal sign-in | Run it again as the bot account. |
| `[NG]` The service starts but the database refuses it | The script ran as another Windows account, whose Credential Manager now holds the password | Run the script again as the bot account with `--set-password`. |

The guided tool `scripts\setup_rds_database.py --set-password` does the same and stops and starts the service itself (not while the database password comes from CyberArk: Step 16.1.6). When the database administrator sets the password in pgAdmin instead, run `Setup_Database.py` with the address form and type the password it was given (section 8).

#### Step 16.1.6 Running the database script while the password comes from CyberArk

> **Important.** While **Database password from CyberArk** is on, the password that the bot account's Credential Manager holds for `finesiii_app` is the one from before CyberArk took over, and the login no longer accepts it. `Setup_Database.py` reads that stored password. A run without `--set-password`, including `--check-only`, therefore stops at "7/8 Verification as the application login" with "The login 'finesiii_app' exists with another password". `--admin-password-from-cyberark` alone does not avoid this: it supplies only the administrator's password. The guided tool `scripts\setup_rds_database.py` cannot be used in this set-up, because its first step is such a check. To check the database in this set-up, use `desktop\app.py --check-db`, which reads the password from CyberArk.

When the script must run (a move to another endpoint, a refreshed certificate bundle, an update that changes the database), use this order. As the bot account, in `C:\FINESIII\app`:

1. When the administrator account in CyberArk changes (for example a new instance), a Developer first enters the new **CyberArk object (database)** (and **CyberArk safe (database)**) on **Settings › This machine › Database**, runs **Test CyberArk retrieval** and selects **Save changes**.

   **Sample (QA):** **CyberArk safe (database)** `BADM_DBADMIN-ISO-POSTGRESQL`; **CyberArk object (database)** `Database---rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com---sailpoin1002---5432--dbadmin`; **CyberArk address (database)** `https://pamccp.aig.net`; **CyberArk Application ID (database)** `APP-10-SAILPOINT`; **Database administrator login** `dbadmin`. The database named inside the object (`sailpoin1002`) is not the bot's database; the bot's database stays `finesiii_v3`. In the settings file these are `CYBERARK_DB_SAFE`, `CYBERARK_DB_OBJECT`, `CYBERARK_DB_BASE_URL`, `CYBERARK_DB_APP_ID` and `DATABASE_ADMIN_LOGIN=dbadmin`.

2. Stop the service:

```powershell
.\.venv\Scripts\python.exe desktop\app.py --stop
```

3. Run the script with the administrator password from CyberArk and a new password for the login (plus the options of the task, for example `--ca-bundle <path>`; and `--audit-database <audit database>` only when the audit trail is in PostgreSQL):

```powershell
.\.venv\Scripts\python.exe Setup_Database.py --rds --host <rds-endpoint> --admin-login <admin login> --admin-password-from-cyberark --set-password
```

**Sample (QA):**

```powershell
.\.venv\Scripts\python.exe Setup_Database.py --rds --host rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com --admin-login dbadmin --admin-password-from-cyberark --set-password
```

**Sample (QA)**, with the audit trail in PostgreSQL:

```powershell
.\.venv\Scripts\python.exe Setup_Database.py --rds --host rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com --admin-login dbadmin --audit-database finesiii_audit --admin-password-from-cyberark --set-password
```

4. Start the service:

```powershell
Start-ScheduledTask -TaskPath '\AIG\' -TaskName 'FINESIII RPA Agent'
```

**Expected result**

- `[OK]` `Administrator password: read from CyberArk for '<admin login>' (not shown)` (Sample (QA): `read from CyberArk for 'dbadmin' (not shown)`), a `[WARN] Password` line saying the bot replaces the password set now at its next check, and a clean verification.
- `[OK]` At start the bot gives `finesiii_app` the CyberArk password again: the "Database password changed" e-mail with **Found by: Bot start**, and the **Database password** card shows **Latest password from CyberArk**.

#### Step 16.1.7 Switch the CyberArk copy off (going back)

1. *Settings › This machine › Database* (Developer): switch **Database password from CyberArk** off, select **Save changes**.
2. Stop the service (Step 14.4).
3. As the bot account, give `finesiii_app` a password of its own with the command of Step 16.1.5, step 2 (with `--admin-password-from-cyberark` while CyberArk still holds the administrator login).
4. Start the service. `[OK]` The **Database password** card is no longer shown; the **Dashboard** shows the database connected.

`[NG]` Switching off and restarting without step 3: the bot goes back to the stored password, which the database no longer accepts. Run step 3.

### 16.2 Fujitsu Mainframe service-account password

> **In plain words.** The bot signs in to Fujitsu Mainframe with one service account (affiliation code, staff code, password). The password expires on the host after 90 days. It is either kept in CyberArk, which then also changes it, or kept in the bot account's Credential Manager. In the second case a Developer changes it from the console on Task 0890, or the bot changes it itself when the automatic change is switched on. Either way, the bot tracks the password's age and e-mails reminders.

**Who does this:** CyberArk / PAM team (password in CyberArk), Developer (change on the console), Admin (the "last changed on" date and the reminders).

**Production rule.** With **Service environment** `production` and the real terminal driver, the bot processes no Fujitsu Mainframe request unless the password comes from CyberArk. The **System** page says so under **Needs attention**.

#### Step 16.2.1 Password from CyberArk

Set up in section 9.2 (Fujitsu Mainframe service-account password). In operation:

| When | What happens |
|---|---|
| At start, then every **Refresh every (hours)** (4 by default) | The bot fetches the password and keeps it in memory only |
| **Refresh CyberArk now** (System page) | Fetches it now. `[OK]` **Password fetched from CyberArk at <time> (JST).** |
| CPM rotates the password | The bot uses the new one from the next fetch. A request refused for the password triggers a fresh fetch at once. |
| CyberArk does not answer | The last good password stays in use; the bot tries again every 5 minutes; "CyberArk not available: the bot could not retrieve its password", then a recovery e-mail |
| The mainframe refuses the password and no newer one arrives | The request fails as "Not retried: the mainframe rejected the service-account password ..."; the CyberArk / identity team is told | 

The password-age line reads **Password: supplied and changed by CyberArk.**; no reminder is sent and the console change is refused.

#### Step 16.2.2 Password kept in Credential Manager (stored)

*Settings › This machine › Credentials, Developer.*

1. Enter the new value in **Service account — password** and save. It applies to the running service at once (no restart).
2. *Settings › Fujitsu Mainframe terminal:* enter **Service-account password: last changed on** (YYYY-MM-DD) when the password was changed outside the bot.
3. Pause processing, run **Test sign-in and navigation**, then resume processing.

`[OK]` The test passes and the password-age line shows the new date. `[NG]` The test cannot sign in: the next sign-in test is possible only after a 10-minute wait, to protect the account from a lock-out. Check the password before testing again.

#### Step 16.2.3 Change the password on Task 0890 from the console

*Developer role. Settings › Fujitsu Mainframe terminal › Tests row.* Only when the password is kept in Credential Manager.

1. **System › Pause processing**, and wait until no request is running.
2. Optional: **Test password screen**. The bot signs in once, opens Task 0890 without typing on it and signs off. `[OK]` "Password screen test passed: the bot opened the password change screen and signed off."
3. **Change service-account password**. Fill in **Current password**, **New password** and **Confirm new password**, select **Change password**, and confirm the question. The new password must be exactly 8 half-width characters, a letter first, at least one letter and one digit, symbols only from `@ # $ & * - _ = ! ? .`, different from the current one, and must not contain the staff code. After an automatic change nobody knows the current password: a Developer may leave **Current password** empty and the bot uses the one it holds (recorded in the audit trail).
4. Wait for the answer (up to a few minutes). The bot signs in, enters the new password on Task 0890 and commits it. The new password is kept in Credential Manager before it is submitted, and becomes the one in use when the host answers 正常終了.
5. **System › Resume processing**.

**Expected result**

- `[OK]` A message that the password was changed, and "The support teams were told by e-mail (without the password)." E-mail: "Fujitsu Mainframe service-account password changed" with **Changed by**, **How**, **Result** and **Evidence folder**.
- `[OK]` The password-age line shows today's date; the automatic change starts counting again.

**If it is different**

| Answer | Cause | Fix |
|---|---|---|
| `[NG]` "Pause processing first (System page > Pause processing), so no request starts during the check." | Processing runs | Step 1 |
| `[NG]` "A request is still running. Wait until it has finished, then run the check." | A request is on the terminal | Wait |
| `[NG]` "Outside the operating window: Fujitsu Mainframe does not accept sign-ins now." | Outside the Fujitsu Mainframe window | Try inside the window |
| `[NG]` "Fujitsu Mainframe is not ready (it showed centre not ready or a line error); try again after it answers. ..." | The host last showed センター準備中 or a line error | Wait until **Test sign-in and navigation** passes |
| `[NG]` "The mainframe host does not answer (...); the sign-in is not attempted." | Network or host down | Section 18.6 |
| `[NG]` "The service-account password comes from CyberArk, which changes it: the bot does not change it itself." | CyberArk supplies the password | The CyberArk team changes it (Step 16.2.1) |
| `[NG]` "The service-account password is not kept in the credential store of this service (Settings > Credentials), ..." | The password comes from another place (for example the environment) | Save it under **Credentials** first |
| `[NG]` "The password was changed on <date> (JST); the next change is possible 24 hours after it." | At most one change per 24 hours | Wait until the time named |
| `[NG]` The current password is refused | It is checked against the password the bot holds and never sent to the host | Check it. After 3 wrong entries the change is locked for 15 minutes. |
| `[NG]` The new password is refused with its reason | It breaks a rule of step 3 | Choose another |
| `[NG]` "The last check could not sign in. To protect the service account from a lock-out, the next sign-in check is possible in N minute(s); ..." | A sign-in test failed shortly before | Check the password, then wait |
| "Fujitsu Mainframe service-account password not changed" e-mail | The host gave a reason, or the result could not be read and a sign-in with the new password did not succeed | Read the reason and the evidence. The bot keeps the password that works. |

#### Step 16.2.4 Automatic change (off by default)

*Settings › Fujitsu Mainframe terminal, Admin:* **Service-account password: change automatically**. Applies at the next hourly check, no restart.

| Rule | Value |
|---|---|
| Checked | Every hour; the first check 10 minutes after a start |
| Due from | **Service-account password: change after (days)**, 80 by default (expiry 90) |
| Runs only | Inside the Fujitsu Mainframe operating hours, with the password in Credential Manager, not within 24 hours of the last change, not while Fujitsu Mainframe shows centre not ready, and never while processing is paused by an administrator |
| While it runs | New requests are held; it waits up to 30 minutes for a running request, otherwise it tries at the next check |
| At most | One try a day |
| Stops | After **Service-account password: stop after failed tries** (2) failures in a row, or at once when the host refuses the current password (protection from a lock-out) |
| Tells | "Fujitsu Mainframe service-account password changed" (**How**: changed automatically by the bot) or "... not changed"; "URGENT: Fujitsu Mainframe automatic password change stopped" when it stops |
| Not available | When CyberArk supplies the password |

After a stop, change the password once on the console (Step 16.2.3); the automatic change then resumes.

#### Step 16.2.5 Password age reminders and Check password age now

The **Tests** row of **Settings › Fujitsu Mainframe terminal** shows a line such as "Password last changed <date> (<n> days ago); expires <date> (<n> days left); automatic change off; a reminder is e-mailed from <date>." When the date is not known: "Password age: not known. Enter "last changed on" (Settings) so the bot can track the 90-day expiry."

| E-mail subject (English half) | When | Sent |
|---|---|---|
| "Fujitsu Mainframe service-account password change due" | From the change-after age, with the automatic change off | Once a day |
| "URGENT: Fujitsu Mainframe service-account password expires soon" | From **Service-account password: urgent e-mail (days before expiry)** (5) days before the expiry | Every day until changed |
| "URGENT: Fujitsu Mainframe automatic password change stopped" | The automatic change stopped | Once a day |
| "URGENT: Fujitsu Mainframe service-account password has expired" | On or after the expiry date | Once a day |

They go to the default recipients, the CyberArk / identity team and the support report recipients.

**Check password age now** (Developer, next to the tests) runs the hourly check once. `[OK]` **Password age check started. ...**, then a line such as **Password age check: not due yet, nothing to do.**, **... change due; a reminder was e-mailed.**, **... the password was changed.** or **... the change could not start now (see the log).** `[NG]` **A password age check is already running; try again when it has finished.** The check obeys every rule of Step 16.2.4: it changes a due password only when the automatic change is on.

**Good and bad cases**

| Case | What happens |
|---|---|
| **Password from CyberArk** | No reminders, no console change; CyberArk owns the rotation. |
| **Stored password, automatic change off, day 80** | A daily "change due" reminder; a Developer changes it (Step 16.2.3). |
| **Stored password, automatic change on, day 80, inside the hours** | The bot changes it, holds new requests for a few minutes, and e-mails the result. |
| Automatic change on, processing paused by an administrator | Not started; tried again at the next hourly check after the resume. |
| The host refuses the current password during an automatic change | The automatic change stops at once; "automatic password change stopped" e-mail; change it on the console after checking the password. |
| Nobody entered "last changed on" and the bot never changed it | The age is not known; no reminder. Enter the date. |

### 16.3 Fujitsu RACF password

> **In plain words.** The bot signs on to Fujitsu RACF with its RACF sign-on ID (`SAILPNT` by default). It cannot change this password itself: the RACF administrators change it. The bot tracks its age and e-mails reminders, and a person then saves the new password and the date.

**Who does this:** RACF administrators (the change), Developer (the credential), Admin (the date).

#### Step 16.3.1 After the RACF administrators changed the password

1. *Settings › This machine › Credentials* (Developer): enter the new value in **Fujitsu RACF service account — password** and save. `[OK]` The save says a restart is needed.
2. **System › Restart service** (or **Save and restart**). The Fujitsu RACF password applies only after a restart.
3. *Settings › Fujitsu RACF terminal and sign-on* (Admin): enter **RACF sign-on ID password: last changed on** (YYYY-MM-DD).
4. **System › Pause processing**, then **Test Fujitsu RACF sign-on**. `[OK]` The sign-on test passes.
5. **System › Resume processing**. This also ends a Fujitsu RACF hold after an earlier refused sign-on.

When the Fujitsu RACF password comes from CyberArk instead (set in the settings file only, as section 9.3 describes), the CyberArk team changes it there; the bot reads it with the other CyberArk passwords. In production with the real terminal driver, Fujitsu RACF requests wait until CyberArk has delivered it.

#### Step 16.3.2 Reminders

The same rules and subjects as Step 16.2.5, with "Fujitsu RACF" as the system, and wording that asks the RACF administrators to change the password, then to enter it under **Settings › Credentials** and the date under **RACF sign-on ID password: last changed on**. **RACF sign-on ID password: change automatically** is not available for Fujitsu RACF; leave it off. The password-age line says "automatic change not available yet; a reminder is e-mailed".

**Good and bad cases**

| Case | What happens |
|---|---|
| **New password saved and service restarted** | Fujitsu RACF requests sign on with it; the reminders stop once the date is entered. |
| New password saved, no restart | The bot still uses the old password: a sign-on is refused and Fujitsu RACF requests are held. Restart. |
| The host refuses the password | The bot does not try the same password again (the RACF ID would lock); Fujitsu RACF requests wait; Fujitsu Mainframe continues. Save the right password, restart, test, resume. |
| The date is not entered | The age is not known; no reminder before the expiry. |

### 16.4 Console administrator passwords, locked accounts, break-glass

> **In plain words.** Every person has their own console account. A forgotten password is reset by a colleague with the Users page; a locked account unlocks by itself after 15 minutes or at once on the Users page. When nobody can sign in any more, the server team sets a provisional password from the server itself ("break-glass").

**Who does this:** each user (own password); Developer, or Admin when **Users page for Administrators** is on (other accounts); Server team (break-glass).

| Rule | Default | Setting (Settings › Console sign-in, Developer) |
|---|---|---|
| Minimum length, with a letter and a digit, not the user name | 12 | **Minimum password length** |
| Not one of the last passwords | 5 | **Passwords remembered** (This machine › Security) |
| Lock after wrong passwords | 5 | **Failed sign-ins before lockout** |
| Lock duration | 900 s (15 minutes) | **Lockout duration (s)** |
| Sign out after inactivity | 1800 s (30 minutes) | **Sign out after inactivity (s)** |
| Maximum session | 12 hours | **Maximum session length (hours)** |

#### Step 16.4.1 Change your own password

User menu › **Change password**: the current password, then the new one twice. `[OK]` Signed in again with the new password; other sessions of the account end.

#### Step 16.4.2 Reset another person's password, unlock an account

*Users page.* On the account's row:

- **Unlock** (shown while it is locked): `[OK]` "The account <name> was unlocked."
- **Activate** for an account that is switched off.
- **Edit › Reset the password**: **New password** and **Confirm the new password**, then **Reset password**. `[OK]` "The password of <name> was reset. They must change it at the next sign-in." Their sessions end and a lock is lifted.

`[NG]` A locked account shows only "Invalid username or password" at sign-in (the message never says "locked"): unlock it, or wait 15 minutes. `[NG]` "This is the last active administrator — promote another account first": give another account the Administrator or Developer role first.

#### Step 16.4.3 Break-glass: set a provisional password from the server

*When the only administrator has forgotten the password or is locked out. As the bot account (the command reads the database password the way the service does), in `C:\FINESIII\app`.*

```powershell
.\.venv\Scripts\python.exe desktop\app.py --reset-console-password <username>
```

Type the new password twice (it is not shown). It must meet the console's **Minimum password length** and rules.

**Expected result**

- `[OK]` ` [OK] The password of '<username>' was reset. Sign in with it; a new password is asked for at once. Open sessions ended: <n>.` Exit code `0`. The account is unlocked and switched on; the reset is written to the service log and the audit trail (`password_reset_break_glass`, WARNING, by `server:<Windows account>`).
- Sign in with the provisional password and choose a new one at once.

**If it is different**

| Symptom | Cause | Fix |
|---|---|---|
| `[NG]` ` [NG] No console account '<username>'.` (exit 1) | Misspelt user name | User names are lower case; check the spelling. |
| `[NG]` ` [NG] Not reset: the two passwords are not the same.` | Typing error | Run it again. |
| `[NG]` ` [NG] Not reset: the password ...` | Too short, no letter or digit, or the user name | Choose a password that meets the rules. |
| `[NG]` ` Usage: --reset-console-password <username>` (exit 2) | No or two user names | Give exactly one. |
| `[NG]` A database error | Run as another Windows account, or the database cannot be reached | Run as the bot account; Step 14.2. |

For a scripted reset without a keyboard, set the password in the environment variable `FINESIII_NEW_CONSOLE_PASSWORD` of that window for the one run, then remove it (`Remove-Item Env:FINESIII_NEW_CONSOLE_PASSWORD`) and clear the PowerShell history.

#### Step 16.4.4 The one-time password of a new installation was lost

Only while the console has no account at all, as the bot account:

```powershell
.\.venv\Scripts\python.exe Setup_Database.py --rds --host <rds-endpoint> --admin-login <admin login> --new-admin-password
```

**Sample (QA):**

```powershell
.\.venv\Scripts\python.exe Setup_Database.py --rds --host rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com --admin-login dbadmin --new-admin-password
```

`[OK]` A new one-time password is shown once; it must be changed at the first sign-in. Once any account exists, use Step 16.4.3 instead. (With the database password from CyberArk, see Step 16.1.6 first.)

### 16.5 Certificates

> **In plain words.** The bot checks the certificate of every server it talks to. For Amazon RDS it uses the AWS certificate bundle in the application folder. For CyberArk, when the CCP certificate comes from the organisation's own certificate authority, it uses a certificate file made from the server's trusted certificates. Both need attention only when the certificate authority changes.

**Who does this:** Server team; Developer for the console setting.

#### Step 16.5.1 Amazon RDS certificate rotation

The bundle `C:\FINESIII\app\certs\rds-global-bundle.pem` covers every current RDS certificate authority, so a rotation of the instance certificate to one of them needs nothing on the server. When AWS publishes an authority the bundle does not contain, either install an update folder that brings a refreshed bundle (section 15; nothing else to do), or, as the bot account:

```powershell
New-Item -ItemType Directory -Force -Path 'C:\FINESIII\data\certs'
Invoke-WebRequest -UseBasicParsing -Uri 'https://truststore.pki.rds.amazonaws.com/global/global-bundle.pem' -OutFile 'C:\FINESIII\data\certs\global-bundle.pem'
(Select-String -Path 'C:\FINESIII\data\certs\global-bundle.pem' -Pattern 'BEGIN CERTIFICATE').Count
cd C:\FINESIII\app
.\.venv\Scripts\python.exe desktop\app.py --stop
.\.venv\Scripts\python.exe Setup_Database.py --rds --host <rds-endpoint> --admin-login <admin login> --ca-bundle C:\FINESIII\data\certs\global-bundle.pem
Start-ScheduledTask -TaskPath '\AIG\' -TaskName 'FINESIII RPA Agent'
.\.venv\Scripts\python.exe desktop\app.py --check-db
```

**Sample (QA)**, the database script line of the block above:

```powershell
.\.venv\Scripts\python.exe Setup_Database.py --rds --host rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com --admin-login dbadmin --ca-bundle C:\FINESIII\data\certs\global-bundle.pem
```

**Sample (QA)**, the same with the database password from CyberArk:

```powershell
.\.venv\Scripts\python.exe Setup_Database.py --rds --host rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com --admin-login dbadmin --ca-bundle C:\FINESIII\data\certs\global-bundle.pem --admin-password-from-cyberark --set-password
```

With the database password from CyberArk, use the order of Step 16.1.6 (add `--admin-password-from-cyberark --set-password`). Add `--audit-database <audit database>` only when the audit trail is in PostgreSQL. Behind a proxy, add `-Proxy 'http://<proxy-host>:<port>' -ProxyUseDefaultCredentials` to the download.

`[OK]` The count is more than 100; the script's verification passes; `--check-db` shows ` Result   : OK`. The database administrator also points pgAdmin's **Root certificate** to the new file.
`[NG]` `certificate verify failed` in the script: the bundle does not contain the instance's authority; download it again, or ask AWS support which bundle applies.

#### Step 16.5.2 Internal certificate authority for CyberArk

*Settings › This machine › Database, Developer.* Needed when **Test CyberArk retrieval** or **Test retrieval** answers with "certificate verify failed" or reports CyberArk as Inactive, for example after the organisation renewed its certificate authority.

1. Next to **CyberArk certificate file (internal certificate authority)**, select **Create from Windows certificates**. `[OK]` **Created C:/FINESIII/data/certs/cyberark-ca-bundle.pem with N certificates from the Windows trusted store. Save and restart to use it.** The path is put in the field, not yet saved.
2. **Test CyberArk retrieval** again (it uses the path on the page).
3. **Save and restart**. The save is refused when the file does not exist, cannot be read or holds no certificate.

`[NG]` "No certificate was found in the Windows trusted store of this server.", or the test still fails: the server does not trust the new authority. Ask the server team to install the organisation's root and intermediate certificates in the Windows store, then repeat step 1. Or export them from the browser as **Base-64 encoded X.509 (.CER)**, paste them one after the other into one file outside the application folder (for example `C:\FINESIII\certs\cyberark-ca-bundle.pem`, readable by the bot account), enter that path and **Save and restart**.

**Sample (QA):** the certificate file `C:\FINESIII\certs\aig-ca-bundle.pem`; in **CyberArk certificate file (internal certificate authority)** enter `C:/FINESIII/certs/aig-ca-bundle.pem` (settings file line: `CYBERARK_CA_BUNDLE=C:/FINESIII/certs/aig-ca-bundle.pem`). The CyberArk address it is used for: `https://pamccp.aig.net`.

The same file is used for every CyberArk call: the database password, and the Fujitsu Mainframe and Fujitsu RACF passwords. The mail server has its own **Extra trusted certificate file** (Settings › E-mail, Developer).

**Before you go on**

- [ ] You know which secrets on this server come from CyberArk and which are stored.
- [ ] The "last changed on" dates are filled in for every stored service-account password.
- [ ] At least two people hold an account that can reset console passwords, and the server team knows the break-glass command.

---
## 17. Backup, restore and moving the database

> **In plain words.** The queue, history, console accounts and settings live in the RDS database, which Amazon RDS backs up. The server keeps the evidence, logs and service keys in the data folder. Passwords are in no backup: they are in CyberArk or in the bot account's Credential Manager, and are entered again after a restore. This section also covers moving to another RDS endpoint, moving data from the built-in SQLite file to PostgreSQL, and clearing test tickets before go-live.

**Who does this:** Server team, Database administrator.

### Step 17.1 What to back up

| What | Where | How |
|---|---|---|
| Queue, history, console accounts, roles, settings saved on the console | RDS database `finesiii_v3` | RDS automated backups; a manual snapshot before updates that change the database and before moves |
| Audit trail | The SQLite file `C:\FINESIII\data\finesiii_audit.db` while the audit trail is kept locally; or the RDS database `<audit database>` when it is in PostgreSQL (Sample (QA): `finesiii_audit`) | With the data folder, or with the RDS backups |
| Evidence, logs, service keys and state | `C:\FINESIII\data` | The server's regular backup. It holds the console session key, the password fingerprint key (which stops an issued password being issued twice), the instance identity, the e-mail outbox, the audit spool, the machine settings file `finesiii.env`, the CyberArk certificate file `certs\cyberark-ca-bundle.pem` and the backups of `.env`. Evidence contains personal data and initial passwords: protect the backup accordingly. |
| Settings file, edited configuration, certificate files kept outside the data folder | `C:\FINESIII\app\.env`, any edited `config\*.yaml`, `C:\FINESIII\certs` | The server's regular backup. The rest of `C:\FINESIII\app` comes from the package and its updates. |
| Passwords and keys | CyberArk, or the bot account's Credential Manager | Not backed up. Keep the stored values in the organisation's password vault. |

### Step 17.2 Export the settings for change control

*Console, Settings page:* **Export configuration** downloads `configuration.csv`: every setting with its value and where it comes from, secrets masked, and the configuration files in force. It is a record, not a transfer: there is no import. Settings on another server are entered on that server's console (or come with its database).

### Step 17.3 Restore the data folder on the same server

1. Stop the service (Step 14.4).
2. In an administrator window, restore `C:\FINESIII\data` from the server backup.
3. Give the bot account its rights on the folder again if the permissions were not restored (section 6, Folder permissions).
4. Start the service; Step 14.1 and Step 14.2.

`[OK]` The console opens with the same accounts and settings; the evidence of earlier requests is shown.
`[NG]` The evidence of earlier requests is missing: the `evidence` folder was not in the restored backup.

### Step 17.4 Move to another RDS instance or endpoint

For example after a snapshot restore or a migration. As the bot account, in `C:\FINESIII\app`.

1. Confirm the network path to the new endpoint:

```powershell
Test-NetConnection -ComputerName <rds-endpoint> -Port 5432
```

**Sample (QA):**

```powershell
Test-NetConnection -ComputerName rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com -Port 5432
```

`[OK]` `TcpTestSucceeded : True`.

2. Stop the service:

```powershell
.\.venv\Scripts\python.exe desktop\app.py --stop
```

3. Run the one-command mode with the new endpoint. The script asks for the current password of `<admin login>`. Add `--audit-database <audit database>` only when the audit trail is in PostgreSQL.

```powershell
.\.venv\Scripts\python.exe Setup_Database.py --rds --host <rds-endpoint> --admin-login <admin login>
```

**Sample (QA):**

```powershell
.\.venv\Scripts\python.exe Setup_Database.py --rds --host rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com --admin-login dbadmin
```

**Sample (QA)**, with the audit trail in PostgreSQL:

```powershell
.\.venv\Scripts\python.exe Setup_Database.py --rds --host rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com --admin-login dbadmin --audit-database finesiii_audit
```

**Sample (QA)**, with the database password from CyberArk (order of Step 16.1.6):

```powershell
.\.venv\Scripts\python.exe Setup_Database.py --rds --host rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com --admin-login dbadmin --admin-password-from-cyberark --set-password
```

With the database password from CyberArk, use the order of Step 16.1.6 instead (the PAM team first confirms which CyberArk account holds the new instance's administrator login; update **CyberArk object (database)** when it changed).

4. Check and start:

```powershell
.\.venv\Scripts\python.exe desktop\app.py --check-db
Start-ScheduledTask -TaskPath '\AIG\' -TaskName 'FINESIII RPA Agent'
```

**Expected result**

- `[OK]` The script ends ready (exit code 0, or 2 with warnings to read) and writes the new address to `.env`; `--check-db` shows ` Result   : OK`; the **Dashboard** shows the requests and history of the restored database.

**Sample (QA)** of the address the script writes to `.env` (no password; the password is kept in the bot account's Credential Manager):

```text
DATABASE_ENGINE=postgres
DATABASE_URL=postgresql://finesiii_app@rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com:5432/finesiii_v3?sslmode=verify-full&sslrootcert=C%3A%5CFINESIII%5Capp%5Ccerts%5Crds-global-bundle.pem&connect_timeout=10&keepalives=1&keepalives_idle=60&keepalives_interval=10&keepalives_count=5&application_name=finesiii-rpa
```

**If it is different**

| Symptom | Cause | Fix |
|---|---|---|
| `[NG]` `Sign-in as 'finesiii_app'` FAIL, "exists with another password" | On a restored snapshot the login keeps the password stored for it at the time of the snapshot | Run the command again with `--set-password`. |
| `[NG]` `TcpTestSucceeded : False` | Security group, routing or DNS | Ask the AWS team to open port 5432 from this server. |
| `[NG]` The service still connects to the old endpoint | `DATABASE_URL` was changed by hand in another settings file, or the script ran with `--no-save` | Let the script write the address. The database lines in `.env` are maintained by the database script: change the address with the script, not by hand and not on the console. |

The bot always connects to the address the script wrote, never to the address held in CyberArk.

### Step 17.5 Move the data from the SQLite file to PostgreSQL

For a server that ran on the built-in SQLite file (`finesiii_v3.db` in the data folder) and now uses RDS. After section 8 (Create the databases), as the bot account, in `C:\FINESIII\app`:

```powershell
.\.venv\Scripts\python.exe scripts\transfer_sqlite_to_postgres.py --check-only
.\.venv\Scripts\python.exe scripts\transfer_sqlite_to_postgres.py --yes
```

The tool copies the requests, history, console accounts, custom roles and console settings (not the sessions: everyone signs in again; not the audit trail). It writes a consistent copy of the SQLite file to the `backups` folder first, writes everything in one transaction, reads every row back and compares it before it commits. `--check-only` does the same and then undoes it. `--yes` also stops the service before and starts it afterwards; `--no-service` leaves the service alone (it must already be stopped). `--source <path>` names another SQLite file.

`[OK]` Exit code `0`: done, or the check passed. `[NG]` Exit code `1`: stopped, nothing changed; the message names the reason (for example a column missing in PostgreSQL: run `Setup_Database.py` first).

A row already in PostgreSQL with the same key and the same values is left as it is, so the tool can be run again; history and requests already in PostgreSQL are never overwritten.

### Step 17.6 Clear test ticket data before go-live

Removes the requests of a test round so that the lists start empty. Completed requests and their history are kept by default; console accounts, roles, settings, credentials, the audit trail, evidence and logs are never touched. As the bot account, with the service stopped:

```powershell
.\.venv\Scripts\python.exe desktop\app.py --stop
.\.venv\Scripts\python.exe scripts\clear_ticket_data.py
.\.venv\Scripts\python.exe scripts\clear_ticket_data.py --apply --admin-url 'postgresql://<admin login>@<rds-endpoint>:5432/postgres'
Start-ScheduledTask -TaskPath '\AIG\' -TaskName 'FINESIII RPA Agent'
```

**Sample (QA)**, the run that removes the data:

```powershell
.\.venv\Scripts\python.exe scripts\clear_ticket_data.py --apply --admin-url 'postgresql://dbadmin@rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com:5432/postgres'
```

The first run only shows the data folder, the database found and what would be removed. The second asks for the administrator's password (the application login may not delete history, by design) and for the word `DELETE` to confirm. Options: `--keep completed,needs_verification,already_removed` (statuses to keep; also `failed`, `cancelled`, `queued`, `in_progress`), `--reset-ticket-memory` (report again the ServiceNow tickets the bot refused earlier), `--data-dir C:\FINESIII\data`, `--backup-dir <path>`, `--yes`.

`[OK]` `Done. Start the service again: ...`, exit code `0`; the removed rows are in a backup file in `C:\FINESIII\data\backups` (passwords left out), and the run is noted in `ticket_data_reset.log`.
`[NG]` `[STOP   ] ...` (exit code 2): stopped for safety, nothing changed, for example because the service is running or a request is in progress. Stop the service and run it again.

**Good and bad cases**

| Case | What happens |
|---|---|
| **RDS snapshot restored to a new endpoint** | Step 17.4 points the bot to it; the data of the snapshot time is in use. |
| **Data folder restored** | Evidence and keys are back; passwords are entered again only if the Credential Manager of the bot account was lost too. |
| The bot account is recreated (new profile) | Its Credential Manager is empty: enter the stored passwords again (**Settings › This machine › Credentials**), or give `finesiii_app` a new password (Step 16.1.5). |
| The transfer tool finds a difference after copying | The whole transfer is undone; nothing is kept in PostgreSQL. |
| The clear tool is run while the service runs | It stops for safety (exit code 2); nothing is removed. |

**Before you go on**

- [ ] RDS backups and the server backup of `C:\FINESIII\data` and `.env` are in place.
- [ ] The stored passwords are kept in the organisation's password vault.

---

## 18. Troubleshooting recipes

> **In plain words.** Find what you see in the first column, run the check, and apply the fix. The tables are grouped by area. Each script and test can be run again safely after a correction. When nothing matches, send **System › Download diagnostics**, the newest `setup_*.log`, the output of `desktop\app.py --selftest --json` and `--check-db --json`, and the exact message with its time.

**Who does this:** Server team and Admin first; Developer for machine and advanced settings.

**Where to look first:** start-up: `agent.log`; running service: `finesiii_rpa_v3.log` and the **System** page; the task: **Task Scheduler › AIG › FINESIII RPA Agent › History**; a request: **Requests** › the request (status, result, attempts, audit events, evidence).

### 18.1 The service does not start

| What you see | Check | Fix |
|---|---|---|
| `agent.log`: `[STOP] Another instance is already running ...`, exit code 3 | `Get-Content 'C:\FINESIII\data\agent.json'` | A copy is already running; use it. The launcher ends on exit code 3. |
| `agent.log`: `[FATAL] The database cannot be reached (...): .... Correct ... then start again.` | `Test-NetConnection -ComputerName <rds-endpoint> -Port 5432`; `desktop\app.py --check-db` | Network, endpoint or RDS down: 18.2. The launcher starts the service again every 60 seconds. |
| `agent.log`: `[FATAL] The service did not start: database password from CyberArk: ...` | The reason after the colon | Settings missing (for example "DATABASE_URL contains a password", "must name the application login") or CyberArk not delivering within 5 minutes: 18.3. |
| `agent.log`: `[FATAL] Configuration is not valid: ...` | The setting named | Correct it in `.env` or `C:\FINESIII\data\finesiii.env` (for example `TERMINAL_DRIVER`, `DATABASE_ENGINE`, `AUDIT_BACKEND`, or a window that crosses midnight). |
| `agent.log`: `[FATAL] The service did not become ready — see the log above.` | The lines above it | Follow the first error. |
| `agent.log`: repeated `the service stopped unexpectedly (exit code 1); starting it again in 60 seconds` | The `[FATAL]` line between them | Fix that cause; the launcher keeps trying. |
| `agent.log`: `not the bot's own session; the service starts only there (options B and D)` | `unattended\Check_Unattended.ps1` | Expected in the owner's own remote session under options B and D; the bot runs in its own session. |
| Task **Last Run Result** not `267009`, no `agent.log` lines | Task history | The bot account is not signed in, or the task's account or start folder is wrong. Sign in the bot account; register the task again (section 11). |
| The service runs on another port | `agent.json`, **Bot service** card | Port 8000 was taken. Free it and restart; or switch on **Refuse another port** (This machine › Deployment) so that the service refuses to start instead. |
| `ModuleNotFoundError` | The command used | Use `.\.venv\Scripts\python.exe` from `C:\FINESIII\app`. |
| Runs, but "Terminal executor could not be built ..." on the System page | **Needs attention** | Requests wait. Store the service-account codes and an 8-character password (**Credentials**), or correct the named file, then restart. |

**Sample (QA)** of the network check in this table:

```powershell
Test-NetConnection -ComputerName rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com -Port 5432
```

### 18.2 Database, RDS and the database password

| What you see | Check | Fix |
|---|---|---|
| `--check-db`: `Error : ... timeout` or `could not connect` | `Test-NetConnection -ComputerName <rds-endpoint> -Port 5432` | Security group or DNS (AWS team). |
| `--check-db`: `password authentication failed for user "finesiii_app"` (CyberArk copy off) | Was the password changed on the database? | Step 16.1.5 with `--set-password`. |
| The same with the CyberArk copy on | **Database password** card, **Validate database password** | The bot fixes this by itself (set back, or copy). If the card shows a problem, follow it (18.3). |
| `--check-db`: `certificate verify failed` | `certs\rds-global-bundle.pem`, AWS notices | Step 16.5.1. |
| `--check-db`: `Missing : <tables>` | Tables not created | Run `Setup_Database.py` (section 8; with CyberArk, Step 16.1.6). |
| `Setup_Database.py`: "The login 'finesiii_app' exists with another password" | Is the CyberArk copy on? | On: use `desktop\app.py --check-db` to check, and the order of Step 16.1.6 to run the script. Off: run it again with `--set-password`. |
| E-mail "Database password not updated: the bot keeps working with the password in use" | **Database password** card, last line | The plain reason says who acts: PAM team (account in CyberArk), database team (administrator rights, bot's login). The next successful check ends it by itself and sends "Database password updated ...". |
| E-mail "Bot's database login set back to the password in CyberArk" | Audit trail, category `system`, `database_password_reapplied` | Someone changed `finesiii_app`'s password outside CyberArk. Ask the database team to find who, in the database log. |
| E-mail "Database not available: request processing is paused" | **Dashboard**, Step 14.2 | The database does not answer. Requests wait; a recovery e-mail follows. Check RDS with the AWS team. |
| **Health** answers `503` | Step 14.2 | As above. |

**Sample (QA)** of the network check in this table:

```powershell
Test-NetConnection -ComputerName rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com -Port 5432
```

### 18.3 CyberArk and certificates

| What you see | Check | Fix |
|---|---|---|
| **Test CyberArk retrieval** / **Test retrieval**: "... certificate verify failed ...", or CyberArk shown as Inactive | The CCP certificate's issuer | Step 16.5.2. |
| "... CyberArk delivered the account <name>, not <admin login>: check the object name." | **CyberArk object (database)**, **Database administrator login** | Copy the object name again exactly, or correct the login. Sample (QA): login `dbadmin`, object `Database---rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com---sailpoin1002---5432--dbadmin`. |
| An answer with `403` (for example `APPAP227E`) | Application ID permissions | The PAM team allows this server for `<application ID>` (Sample (QA): `APP-10-SAILPOINT` at `https://pamccp.aig.net`). |
| An answer with `404`, or the object is not found | Safe and object | Copy both again; the PAM team checks the safe's members. Sample (QA): safe `BADM_DBADMIN-ISO-POSTGRESQL`. |
| Saving **Database password from CyberArk** On is refused | The message | **CyberArk address (database)** and **CyberArk Application ID (database)** are required while it is on; **Database URL** must name `finesiii_app` without a password. |
| **Database password** card: **CyberArk not reachable** | **Test CyberArk retrieval** | Requests keep running with the password in use. Check CyberArk and the certificate file. |
| **Database password** card: **Previous password in use** | The reason line | The bot tries again every check; act on the reason (PAM or database team). |
| **CyberArk** card unavailable; e-mail "CyberArk not available: the bot could not retrieve its password" | **Test retrieval** on **Settings › CyberArk** | The last good Fujitsu Mainframe password stays in use; the bot tries every 5 minutes. |
| Requests wait: "CyberArk has not delivered the mainframe password yet" | **CyberArk** card | **Refresh CyberArk now**; correct the CyberArk settings. |
| "CyberArk is required here ..." | **Service environment** | Production with the real terminal requires the password from CyberArk (section 9.2). |

### 18.4 ServiceNow

| What you see | Check | Fix |
|---|---|---|
| No tickets collected | **Settings › ServiceNow › Test connection**, **Open tickets after each filter** | Switch **Poll ServiceNow for tickets** on; find the filter that drops to 0. |
| **ServiceNow** card: **Paused — sign-in rejected** | The ServiceNow password or client secret | Save the right one, then **Check ServiceNow now**. |
| Card: **Not configured** | The setting named | Complete it; the bot checks again every minute. |
| Card: failing, outage e-mail | Network, proxy, instance address | Correct; queued requests keep running; a recovery e-mail follows. |
| A ticket is skipped without a note | **Preview tickets** | It names another application ID, or is outside the group, Requested For or pick-up states. |
| Retry refused: the ticket "was closed as incomplete" | **Close the ticket when the request failed** | The ticket is final; raise a new ticket. |
| A **Needs verification** request: the ticket is closed as Closed Incomplete | **Close the ticket when the request failed** is On (default) | Expected: the ticket note ends "Closed as incomplete; if the change is still needed, submit a new request." Check the account by hand (the "Please verify" e-mail names it). Do not retry. With the setting Off, the ticket stays open with a review note. |
| "ticket update(s) not written: update those tickets by hand" | System page | Update those tickets in ServiceNow from each request's outcome. |

### 18.5 E-mail

| What you see | Check | Fix |
|---|---|---|
| No e-mail of any kind | **Send email alerts**, **Warnings** | Switch on, **Restart service**, **Send test e-mail**. |
| **Warnings**: "E-mail is switched off: no recipient is set ..." | All recipient lists empty | Enter **Default recipients** and restart (a change that switches e-mail on or off asks for a restart). |
| E-mail card **Not delivering**, outbox growing | **Test connection** on **Settings › E-mail** | Fix the relay or settings; kept e-mails are resent every 5 minutes, or **Resend now**. |
| Only the testers receive e-mails | **Send every e-mail only to (testing)** | Clear it in production; the Dashboard warning disappears. |
| An expected e-mail is missing; the audit trail shows `email_skipped` | Its recipient lists | Fill in the list that should receive it. |
| You want to see what an e-mail looks like | **Settings › E-mail › E-mail samples** | Preview any e-mail, including the database password and Windows session notices. |

### 18.6 Fujitsu Mainframe terminal

| What you see | Check | Fix |
|---|---|---|
| E-mail "Fujitsu Mainframe not available: request processing is paused"; requests wait | The host showed センター準備中 (centre not ready) or a line error | Nothing to do: the bot checks again and resumes; a recovery e-mail follows. **Test sign-in and navigation** (processing paused) clears it at once once the host answers. |
| "Fujitsu Mainframe not available: the terminal could not be started" | **Test terminal launch** | Correct **Launcher shortcut**; check **This service runs as administrator: Yes** when **Start the terminal as administrator** is on. |
| Request failed: "Not retried: the mainframe rejected the service-account password ..." | Where the password comes from | CyberArk: confirm the vault, **Refresh CyberArk now**. Stored: Step 16.2.2. Then a new ticket, or Retry while the ticket is open. |
| Request failed: operator code not registered | **Credentials**, **Mainframe environment** | Check the codes; `development` adds `99` in front of the sign-in affiliation code, `production` does not. |
| Requests stay **Queued**, window card **Closed** | Operating window | Expected outside **Window opens / closes (JST)**. |
| Requests stay **Queued**, "mainframe not reachable" | **Test mainframe host** | Host, port, firewall. |
| A terminal test refused: "Pause processing first ..." | Processing card | Pause, test, resume. |
| "A Fujitsu Mainframe window left open by an earlier attempt could not be closed" | The bot's desktop | Close the window on the server, then retry. |

### 18.7 The bot's Windows session and unattended operation

| What you see | Check | Fix |
|---|---|---|
| System page: "Requests wait: the bot's Windows session is locked. ..." (or "disconnected", or "Windows did not accept the bot's keystrokes (the bot's remote desktop window may be minimized)"); e-mail "Bot Windows session Not Available" | `query session` in an administrator window; `unattended\Check_Unattended.ps1` | Sign in to or unlock the bot's session, or restore its minimized remote desktop window. Leave it with the **Leave Bot Running** shortcut (`unattended\Leave_Bot_Running.cmd`, run as administrator), not by disconnecting. Processing resumes by itself (the session is checked at most every 60 seconds after a refused keystroke) and "Bot Windows session Recovered" follows. |
| The same each time the remote desktop window is minimized | The connecting computer | Do not minimize it, or set `RemoteDesktop_SuppressWhenMinimized` (DWORD, value `2`) on the computer that connects, as the unattended operation guide describes. |
| `Check_Unattended.ps1`: `[FAIL]` or `[WARN]` lines | Each line says what to do | Usually: run `Setup_Unattended.ps1` again as the owner account. |
| "No launcher found ... the bot was started by hand" | `Check_Unattended.ps1` | Stop the hand-started copy, start the task (Step 14.3). |
| The check is not wanted (for example a test server with the simulator) | — | It applies only to the real keystroke drivers on Windows. It can be switched off only with `DESKTOP_SESSION_CHECK=false` in `.env` and a restart; there is no console setting. |

### 18.8 Fujitsu RACF

| What you see | Check | Fix |
|---|---|---|
| Fujitsu RACF requests stay **Queued**, Fujitsu Mainframe runs | **Fujitsu RACF** card, **Needs attention** | The reason is named: window closed, host not answering, terminal not starting, sign-on ID in use, password refused, no password, or (production) CyberArk not delivered. Fix it; the bot retries by itself. |
| "Fujitsu RACF cannot run on this server: ... TSS_PASSWORD ..." | **Credentials** | Save **Fujitsu RACF service account — password** and **Restart service**. |
| A Fujitsu RACF request failed at once after a refused password | — | Step 16.3.1, then **Resume processing**. |
| A Fujitsu RACF test fails | The level named (host, launch, sign-on) | **Show details** for the screenshots and screen text. |

### 18.9 Console sign-in

| What you see | Check | Fix |
|---|---|---|
| "Invalid username or password" although the password is right | **Users** page: **Locked until**, **Active** | **Unlock** or **Activate**; or wait 15 minutes. |
| Nobody can sign in | — | Step 16.4.3 (break-glass). |
| "You were signed out after 30 minutes without activity." | — | Sign in again. |
| "This site can't be reached" | Step 14.1 | Start the service; use the port in `agent.json`. |
| The console looks old after an update | — | **Ctrl+F5**. |
| An Admin cannot see the **Users** page | **Users page for Administrators** | Off by default: a Developer manages accounts, or switches it on. |

**Before you go on**

- [ ] You know where `agent.log`, the service log and the diagnostics download are.

---

## 19. Removing the installation

> **In plain words.** Removal undoes each piece in reverse order: the service, the stored passwords, the tasks and shortcuts, the folders and the machine variable, and finally the databases once the retention period allows it.

**Who does this:** Server team, Database administrator; PAM team for the CyberArk accounts.

### Step 19.1 Stop the service

*As the bot account:*

```powershell
cd C:\FINESIII\app
.\.venv\Scripts\python.exe desktop\app.py --stop
```

`[OK]` ` Agent stopped.` or ` No AIG IAM Access RPA agent is running.`

### Step 19.2 Remove the stored credentials

*As the bot account, same folder:*

```powershell
.\.venv\Scripts\python.exe -c "from desktop import vault; [vault.delete_secret(k) for k in vault.SECRET_KEYS]; print('removed')"
.\.venv\Scripts\python.exe -c "from desktop import vault; print([k for k, v in vault.status().items() if v['set']])"
```

`[OK]` `removed`, then `[]`.

### Step 19.3 Remove the tasks, shortcuts and the machine variable

*Administrator window, signed in as the owner account.* With unattended operation set up (`-Remove` also deletes the **FINESIII RPA Agent** task that the set-up registered):

```powershell
cd C:\FINESIII\app
powershell -NoProfile -ExecutionPolicy Bypass -File .\unattended\Setup_Unattended.ps1 -Remove -Account '<bot account>'
```

**Sample (QA):**

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\unattended\Setup_Unattended.ps1 -Remove -Account 'R6-CORE\prvrnel'
```

Automatic sign-in (options C and D) is switched off with the Autologon tool. Then, in every case:

```powershell
Unregister-ScheduledTask -TaskPath '\AIG\' -TaskName 'FINESIII RPA Agent' -Confirm:$false -ErrorAction SilentlyContinue
Unregister-ScheduledTask -TaskPath '\AIG\' -TaskName 'FINESIII Bot Session Keeper' -Confirm:$false -ErrorAction SilentlyContinue
Remove-Item -LiteralPath 'C:\Users\Public\Desktop\AIG IAM Access RPA.url' -ErrorAction SilentlyContinue
[Environment]::SetEnvironmentVariable('FINESIII_DATA_DIR', $null, 'Machine')
```

`[OK]` **Task Scheduler › AIG** is empty; `[Environment]::GetEnvironmentVariable('FINESIII_DATA_DIR', 'Machine')` returns nothing.

### Step 19.4 Archive, then delete the folders

Archive `C:\FINESIII\data` first if the retention rules require it (evidence, logs, the local audit trail). Then, in the administrator window:

```powershell
cd C:\
Remove-Item -LiteralPath 'C:\FINESIII' -Recurse -Force
```

This removes the application folder, the data folder with its backups, the update backups `C:\FINESIII\backup-*` and certificate files kept in `C:\FINESIII\certs`.

### Step 19.5 Optional clean-up

Remove the bot account from the local Administrators group (`Remove-LocalGroupMember -SID 'S-1-5-32-544' -Member '<bot account>'`), uninstall Python 3.13 in **Settings › Apps** if nothing else uses it, and delete the download cache `finesiii-setup` in the administrator's temporary folder.

**Sample (QA):**

```powershell
Remove-LocalGroupMember -SID 'S-1-5-32-544' -Member 'R6-CORE\prvrnel'
```

### Step 19.6 Database and CyberArk

After the agreed retention of the history and the audit trail, the database administrator removes the databases `finesiii_v3` (and `<audit database>` when used) and the login `finesiii_app` in pgAdmin. The PAM team removes the Application ID's access for this server.

**Sample (QA):** databases `finesiii_v3` and `finesiii_audit`, login `finesiii_app` on `rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com`; Application ID `APP-10-SAILPOINT` (shared with SailPoint in QA: the PAM team removes only this server's access, not the Application ID).

**Before you go on**

- [ ] Nothing of the bot runs, is scheduled or is stored on the server.

---

## 20. Reference

### 20.1 Command sheet

Run from `C:\FINESIII\app`. "Bot" = PowerShell as the bot account; "Admin" = administrator window.

| Need | Window | Command |
|---|---|---|
| Start in the background | Bot or Admin | `Start-ScheduledTask -TaskPath '\AIG\' -TaskName 'FINESIII RPA Agent'` |
| Start the bot's own session (options B and D) | Bot or Admin | `Start-ScheduledTask -TaskPath '\AIG\' -TaskName 'FINESIII Bot Session Keeper'` |
| Stop (request in progress finishes) | Bot or Admin | `.\.venv\Scripts\python.exe desktop\app.py --stop` |
| Run in the foreground (troubleshooting) | Bot | `.\.venv\Scripts\python.exe desktop\app.py --agent` |
| Running? Address? | Bot or Admin | `Get-Content 'C:\FINESIII\data\agent.json'` |
| Answering? | Any | `Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:8000/api/v1/ping'` |
| Health with database | Any | `Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:8000/api/v1/health' -Headers @{ 'X-API-Key' = '<API key>' }` |
| Task state | Bot or Admin | `Get-ScheduledTask -TaskPath '\AIG\' -TaskName 'FINESIII RPA Agent' \| Get-ScheduledTaskInfo` |
| Start-up messages | Bot or Admin | `Get-Content 'C:\FINESIII\data\logs\agent.log' -Tail 50 -Encoding UTF8` |
| Follow the service log | Bot or Admin | `Get-Content 'C:\FINESIII\data\logs\finesiii_rpa_v3.log' -Tail 50 -Wait -Encoding UTF8` |
| Recent errors | Bot or Admin | `Select-String -Path 'C:\FINESIII\data\logs\finesiii_rpa_v3.log' -Pattern 'ERROR' \| Select-Object -Last 20` |
| Self-test | Bot | `.\.venv\Scripts\python.exe desktop\app.py --selftest` (add `--json` for a file) |
| Database check | Bot | `.\.venv\Scripts\python.exe desktop\app.py --check-db` (add `--json`) |
| Options of the program | Any | `.\.venv\Scripts\python.exe desktop\app.py --help` |
| Prerequisites still complete? | Admin | `powershell -NoProfile -ExecutionPolicy Bypass -File .\Setup_Prerequisites.ps1 -CheckOnly` |
| Unattended set-up check | Admin | `powershell -NoProfile -ExecutionPolicy Bypass -File .\unattended\Check_Unattended.ps1` |
| Database objects and rights (check only; not with the CyberArk copy on) | Bot | `.\.venv\Scripts\python.exe Setup_Database.py --rds --host <rds-endpoint> --admin-login <admin login> --check-only` |
| New password for `finesiii_app` | Bot | `.\.venv\Scripts\python.exe Setup_Database.py --rds --host <rds-endpoint> --admin-login <admin login> --set-password` |
| The same, guided (not with the CyberArk copy on) | Bot | `.\.venv\Scripts\python.exe scripts\setup_rds_database.py --set-password` |
| Database script with the CyberArk copy on | Bot | `.\.venv\Scripts\python.exe Setup_Database.py --rds --host <rds-endpoint> --admin-login <admin login> --admin-password-from-cyberark --set-password` |
| Reset a console password (break-glass) | Bot | `.\.venv\Scripts\python.exe desktop\app.py --reset-console-password <username>` |
| Lost one-time console password (no accounts yet) | Bot | `.\.venv\Scripts\python.exe Setup_Database.py --rds --host <rds-endpoint> --admin-login <admin login> --new-admin-password` |
| Stored credentials (names only) | Bot | `.\.venv\Scripts\python.exe -c "from desktop import vault; print([k for k, v in vault.status().items() if v['set']])"` |
| SQLite to PostgreSQL | Bot | `.\.venv\Scripts\python.exe scripts\transfer_sqlite_to_postgres.py --check-only`, then `--yes` |
| Clear test tickets | Bot | `.\.venv\Scripts\python.exe scripts\clear_ticket_data.py`, then `--apply --admin-url 'postgresql://<admin login>@<rds-endpoint>:5432/postgres'` |
| Developer accounts to Administrator (going back only) | Bot | `.\.venv\Scripts\python.exe scripts\developer_role_to_admin.py`, then `--apply` |
| Network path to RDS | Any | `Test-NetConnection -ComputerName <rds-endpoint> -Port 5432` |

**Sample (QA)** of the commands above that have placeholders (endpoint `rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com`, administrator login `dbadmin`, bot account `R6-CORE\prvrnel`). The machine API key and every password are never written here; the commands ask for them.

| Need | Sample (QA) command |
|---|---|
| Database objects and rights (check only; not with the CyberArk copy on) | `.\.venv\Scripts\python.exe Setup_Database.py --rds --host rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com --admin-login dbadmin --check-only` |
| New password for `finesiii_app` | `.\.venv\Scripts\python.exe Setup_Database.py --rds --host rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com --admin-login dbadmin --set-password` |
| The same, with the audit trail in PostgreSQL | `.\.venv\Scripts\python.exe Setup_Database.py --rds --host rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com --admin-login dbadmin --audit-database finesiii_audit --set-password` |
| Database script with the CyberArk copy on | `.\.venv\Scripts\python.exe Setup_Database.py --rds --host rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com --admin-login dbadmin --admin-password-from-cyberark --set-password` |
| Lost one-time console password (no accounts yet) | `.\.venv\Scripts\python.exe Setup_Database.py --rds --host rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com --admin-login dbadmin --new-admin-password` |
| Clear test tickets (second run) | `.\.venv\Scripts\python.exe scripts\clear_ticket_data.py --apply --admin-url 'postgresql://dbadmin@rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com:5432/postgres'` |
| Network path to RDS | `Test-NetConnection -ComputerName rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com -Port 5432` |
| Remove the unattended set-up (Step 19.3) | `powershell -NoProfile -ExecutionPolicy Bypass -File .\unattended\Setup_Unattended.ps1 -Remove -Account 'R6-CORE\prvrnel'` |

On the console (**System** page): **Pause processing** / **Resume processing**, **Check ServiceNow now**, **Refresh CyberArk now**, **Validate database password**, **Run self-test**, **Download diagnostics**, **Restart service**, **Stop the bot**. On the Settings pages: **Save and restart**, **Export configuration**, the **Tests** rows, **Check password age now**, **Change service-account password**, **Test CyberArk retrieval**, **Create from Windows certificates**.

### 20.2 Script options

**`desktop\app.py`**

| Option | What it does | Exit codes |
|---|---|---|
| `--agent` | Runs the bot in the background (no window); the scheduled task's launcher uses it | 0 clean stop; 1 failed start, failed restart or drain timed out; 3 another copy holds the lock |
| `--stop` | Asks the running bot to finish its request and stop; waits about 5.5 minutes | 0 stopped or none running; 1 still running at the deadline |
| `--headless` | The service in the foreground without the console pages (troubleshooting) | 0 after stop |
| `--check-db [URL] [--json]` | Database connection and tables; a password may be given in `DATABASE_PASSWORD` | 0 OK; 1 failed |
| `--selftest [--json]` | Verifies this installation | 0 all usable; 1 not |
| `--reset-console-password <username>` | Provisional console password from the server; `FINESIII_NEW_CONSOLE_PASSWORD` for a scripted run | 0 reset; 1 refused; 2 wrong usage |
| `--configure ...` | Installation step: writes `finesiii.env`, stores secrets, registers the bot (for example `--db-url`, `--db-engine`) | — |
| `-h`, `--help` | The options | 0 |
| an unknown option | Usage | 2 |

**`Setup_Database.py`** (exit 0 ready; 2 ready with warnings; 1 not ready)

| Option | Meaning |
|---|---|
| `--rds --host <endpoint>` | Amazon RDS / Aurora: addresses built from the endpoint; `--port` (5432), `--admin-login` (`dbadmin`), `--app-login` (`finesiii_app`), `--database` (`finesiii_v3`) |
| `--audit-database <name>` | Also prepare this audit database and switch the audit trail to PostgreSQL |
| `--tls verify-full\|require` | `verify-full` (default) checks the server certificate against `--ca-bundle` (default `certs\rds-global-bundle.pem`) |
| `--check-only` | Validate only; change nothing |
| `--set-password` | Give an existing application login a new (generated) password |
| `--admin-password-from-cyberark` | Read the administrator password from CyberArk (`CYBERARK_DB_*` settings) |
| `--app-password ask\|generate` | Password of a new application login (generated with `--rds`) |
| `--password-store auto\|vault\|env-file` | Where the application password is kept |
| `--console-admin generate\|ask\|skip`, `--new-admin-password` | The one-time password of the first console administrator |
| `--fix-ownership`, `--no-save`, `--env-file <path>`, `--timeout <s>`, `--no-prompt` | Ownership hand-over, do not write settings, other settings file, time limit, scripted run |
| `URL`, `--admin-url`, `--audit-url` | The address form instead of `--rds` |

**`scripts\setup_rds_database.py`** (exit 0, 2, 1): guided run of the above, check first then setup, stops and starts the service. Not usable while the database password comes from CyberArk (its first check fails on the stored password). `--cluster <address>`, `--port`, `--admin-login`, `--app-login`, `--database`, `--audit-database`, `--tls`, `--set-password`, `--check-only`, `--no-service`, `--admin-password <password>` (visible in the process list; avoid), `--admin-password-from-cyberark`, `--yes`.

**`Setup_Prerequisites.ps1`** (administrator; exit 0 ready, 2 ready with warnings, 1 not ready): `-CheckOnly`, `-SkipOcr`, `-DataDir <path>` (default `C:\FINESIII\data`), `-Proxy http://<proxy-host>:<port>`.

**`unattended\Setup_Unattended.ps1`** (administrator, as the owner account; exit 0 done, 2 done with warnings, 1 stopped): `-Option A|B|C|D`, `-Account '<bot account>'`, `-SeparateSessions`, `-AppDir`, `-DataDir`, `-Width`, `-Height` (1920 × 1080), `-Remove`.
**`unattended\Check_Unattended.ps1`** (reads only; exit 0 all OK, 2 warnings, 1 a FAIL): `-DataDir`.
**`unattended\Leave_Bot_Running.cmd`**: moves the remote session to the server's own screen (run as administrator).

**Other tools:** `scripts\transfer_sqlite_to_postgres.py` (exit 0 done, 1 stopped): `--check-only`, `--yes`, `--no-service`, `--source <path>`. `scripts\clear_ticket_data.py` (exit 0 done, 1 problem, 2 stopped for safety): `--apply`, `--keep`, `--admin-url`, `--data-dir`, `--reset-ticket-memory`, `--backup-dir`, `--no-backup`, `--yes`, `--force`, `--timeout`. `scripts\developer_role_to_admin.py` (exit 0 done, 1 database not usable): `--apply`, `--data-dir`.

Scheduled task result `267009` means the task is running; `0` that it ended normally.

### 20.3 Files and folders

| Path | Holds |
|---|---|
| `C:\FINESIII\app` | The application from the package and its updates; `.venv` (Python environment), `.env` (settings file), `certs\rds-global-bundle.pem`, `unattended\` (launcher and scripts) |
| `C:\FINESIII\data` (`FINESIII_DATA_DIR`) | `agent.json` (address while running), `agent.lock`, `finesiii.env` (machine settings), `logs\`, `evidence\`, `backups\`, `certs\cyberark-ca-bundle.pem`, the audit spool, `finesiii_audit.db` (local audit trail), outbox and state files |
| `C:\FINESIII\backup-*` | Update backups (section 15) |
| `C:\FINESIII\certs` | Certificate files made by hand (optional) |
| Bot account's Credential Manager | The stored passwords and keys (never in a file) |

### 20.4 Settings files and where a console save writes

| Saved on | Written to | Applies |
|---|---|---|
| Console settings (Settings pages, except This machine) | Table `app_settings` in `finesiii_v3` | At once ("hot") or after **Restart service**, as each row says |
| **Settings › This machine** (machine settings) | `C:\FINESIII\data\finesiii.env`, or the same line in `C:\FINESIII\app\.env` when that file already holds it | After **Save and restart**; **Service port** and **Refuse another port** only after a stop and start |
| **Settings › This machine › Credentials** | The bot account's Credential Manager | The Fujitsu Mainframe codes and password at once (when not from CyberArk), the ServiceNow secrets at once, others after a restart |
| The database lines (`DATABASE_ENGINE`, `DATABASE_URL`, audit lines) | `.env`, by `Setup_Database.py` | At the next start |
| Lines only in the settings file (for example `DESKTOP_SESSION_CHECK`, `CYBERARK_TSS_*`) | `.env`, by the server team | At the next start |

Order of priority, highest first: console settings, environment variables of the process, Credential Manager, `.env`, `finesiii.env`, built-in defaults. `FINESIII_DATA_DIR` is read from the environment only.

**Sample (QA)** of the database lines `Setup_Database.py --rds` writes to `.env` (no password; with `--audit-database finesiii_audit` the three audit lines are added):

```text
DATABASE_ENGINE=postgres
DATABASE_URL=postgresql://finesiii_app@rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com:5432/finesiii_v3?sslmode=verify-full&sslrootcert=C%3A%5CFINESIII%5Capp%5Ccerts%5Crds-global-bundle.pem&connect_timeout=10&keepalives=1&keepalives_idle=60&keepalives_interval=10&keepalives_count=5&application_name=finesiii-rpa
AUDIT_ENABLED=true
AUDIT_BACKEND=postgres
AUDIT_DATABASE_URL=postgresql://finesiii_app@rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com:5432/finesiii_audit?sslmode=verify-full&sslrootcert=C%3A%5CFINESIII%5Capp%5Ccerts%5Crds-global-bundle.pem&connect_timeout=10&keepalives=1&keepalives_idle=60&keepalives_interval=10&keepalives_count=5&application_name=finesiii-rpa
```

**Sample (QA)** of the CyberArk lines for the database password, as **Settings › This machine › Database** saves them in the machine settings file (no password):

```text
CYBERARK_DB_ENABLED=true
CYBERARK_DB_BASE_URL=https://pamccp.aig.net
CYBERARK_DB_APP_ID=APP-10-SAILPOINT
CYBERARK_DB_SAFE=BADM_DBADMIN-ISO-POSTGRESQL
CYBERARK_DB_OBJECT=Database---rds-clus-xuse1-qa-sailpoint002.cluster-cqywc4nwgapa.us-east-1.rds.amazonaws.com---sailpoin1002---5432--dbadmin
DATABASE_ADMIN_LOGIN=dbadmin
CYBERARK_CA_BUNDLE=C:/FINESIII/certs/aig-ca-bundle.pem
```

---

## 21. Points to note

- **Production needs CyberArk for Fujitsu Mainframe.** With **Service environment** `production` and the real terminal driver, Fujitsu Mainframe requests are not processed unless the service-account password comes from CyberArk; Fujitsu RACF requests wait until CyberArk has delivered the RACF password. In production the machine API key is required by default, but the starter `.env` line `AUTH_ENABLED=false` still wins: switch **Require the machine API key** on explicitly (with the keys saved under **Credentials**). Production keeps the password of a failed request for 0 days (a Retry of a provisioning request that brought its own password is then refused).
- **The database script reads the stored password.** While the database password comes from CyberArk, `Setup_Database.py` cannot verify the login with the password stored before; a check-only run reports a failure. Use `desktop\app.py --check-db` to check, and the order of Step 16.1.6 to run the script.
- **A pause survives restarts.** **Pause processing** stays in force after **Restart service**, a crash or a reboot until someone selects **Resume processing**.
- **The bot's Windows session must stay usable.** With the real terminal, a locked, disconnected or minimized session makes Windows refuse the bot's keystrokes; requests then wait and resume by themselves. The check has no console setting.
- **The console port** changes only with a stop and start, not with **Restart service**.
- **No settings import.** **Export configuration** is a masked record for change control; another server is configured on its own console.
- **Test settings must be cleared in production.** **Send every e-mail only to (testing)** must be empty, and **Mainframe environment** `production` (the value `development` adds `99` before the sign-in affiliation code).
- **The audit trail** is kept locally in SQLite (`finesiii_audit.db` in the data folder) unless an audit database was prepared with `--audit-database`; moving it to PostgreSQL is a decision for the organisation. The transfer tool of Step 17.5 does not move the audit trail.
- **The "Please verify" e-mail** of a result that could not be confirmed says that the ticket was closed, also on a server where **Close the ticket when the request failed** is Off and the ticket stays open; check the ticket's state in ServiceNow.
- **The clear-ticket-data tool** connects to the server, port and database of the database address but not with its certificate options; on RDS the connection is encrypted when the server offers it, without the certificate check. Use it on the server's own network only.
- **Fujitsu RACF passwords** cannot be changed by the bot; the RACF administrators change them, and a person saves the new value and the date.

---

## 22. What was checked for this document

**Checked against the current program and scripts:**

- the options, messages and exit codes of `desktop\app.py` (`--agent`, `--stop`, `--headless`, `--check-db`, `--selftest`, `--reset-console-password`, `--configure`, `--help`), the launcher and the scheduled task names;
- `RUN_COMMANDS.txt` (start, stop, logs, credentials) and the update procedure of the newest update folder's `PATCH_README.txt` (precheck, stop, backup, copy, verify, start, going back);
- `Setup_Database.py` and `scripts\setup_rds_database.py` (options, the generated password, `--set-password`, `--admin-password-from-cyberark`, the use of the stored password and the verification as the application login), `scripts\transfer_sqlite_to_postgres.py`, `scripts\clear_ticket_data.py`, `scripts\developer_role_to_admin.py`, and the break-glass reset;
- the database password from CyberArk: start, scheduled check, refused sign-in, change in process, failed and recovered copy, set back, **Validate database password** and its answers, the card lines, the restart from the console, the audit events and the e-mail subjects and recipients;
- the Fujitsu Mainframe password: CyberArk refresh, the console change on Task 0890 with its conditions and refusals, the automatic change, the age check and its e-mails; the Fujitsu RACF password and its reminders;
- the console sign-in rules and defaults, the Users page actions, the System page buttons and cards, the certificate file button, the unattended scripts' options and outputs, and the Windows session check.

**Needs the client's server:** the timing of starts and stops, the real terminal and host messages, CyberArk and RDS answers on the client's network, the certificate counts, and the e-mails as delivered by the client's mail relay. Run sections 14 to 16 once on a test window after each update and note any difference.
