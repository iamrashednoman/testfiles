=====================================================================
 AIG IAM ACCESS RPA - TOOL: DATABASE SETUP ON AMAZON RDS / AURORA
 One command: cluster address and administrator password, then setup
 Version of 2 November 2026 (replaces the tool of 19 October 2026)
=====================================================================
 Two files. No other file of the application is changed. The tool runs
 the database setup that is already in the application folder
 (Setup_Database.py --rds, from the update of 15 October 2026, which
 every later update contains).

     app\scripts\setup_rds_database.py
     app\tests\unit\test_setup_rds_database_tool.py   (automated tests)

 Copy the CONTENT of the "app" folder over the application folder
 (C:\FINESIII\app), keeping the folders.

 NEW IN THIS VERSION
   --admin-password '<password>'  the dbadmin password on the command
                                  line instead of being asked for it
   --yes                          answer yes to "Run the setup now?" and
                                  "Start the service now?" (one run, no
                                  questions)
   The check never waits for the keyboard.

=====================================================================
 WHAT IT DOES
=====================================================================
 1. Reads the cluster address (writer endpoint) and the dbadmin
    password.
 2. Runs the check of the database setup (nothing is created or
    changed). On a new cluster the check reports that the application
    login or database "does not exist": that is expected, the tool
    says so and goes on. Any other FAIL line stops the tool.
 3. Stops the service, runs the setup (login finesiii_app, database
    finesiii_v3, tables, rights, settings file) and shows its result.
 4. Starts the scheduled task "\AIG\FINESIII RPA Agent".

 The application login gets a generated password, kept in the Windows
 Credential Manager of the account that runs the tool. So run the
 tool as the BOT ACCOUNT (the account the service runs as).

 The dbadmin password is used for this run only and never written to a
 file or a log. With --admin-password it is visible in the process list
 while the tool runs and may stay in the PowerShell command history:
 clear the history after the run (step 5).

=====================================================================
 BEFORE
=====================================================================
   * From the client: the cluster's WRITER endpoint (it contains
     ".cluster-", not ".cluster-ro-"), the port, the current dbadmin
     password (CyberArk), the security group open for this server on
     the port, and the DBA's approval for the database finesiii_v3 and
     the login finesiii_app. Use the tool's own database finesiii_v3,
     never a database of another application on the same cluster.
   * The new database starts EMPTY: console accounts, settings saved
     on the console and the request history are not moved. As
     Developer: Settings > Export, keep configuration.csv, and note
     the console accounts.
   * Console > System > Pause processing; wait until nothing is
     queued or running; resolve tickets the bot left open.

=====================================================================
 STEPS
=====================================================================
 1. Sign in to the server by remote desktop AS THE BOT ACCOUNT and
    open a NEW PowerShell window.

 2. Copy the tool

Copy-Item "<folder of this tool>\app\*" C:\FINESIII\app -Recurse -Force
Get-ChildItem C:\FINESIII\app\scripts\setup_rds_database.py | Unblock-File

 3. Check only (nothing is changed)

cd C:\FINESIII\app
.\.venv\Scripts\python.exe scripts\setup_rds_database.py --cluster <writer endpoint> --admin-password '<dbadmin password>' --check-only

    [OK] "Check: READY", or "Check: the cluster, the administrator
         password and the encryption are in order" (new cluster). The
         setup's own "NOT READY" just above is then expected: it names
         only the login or database that the setup creates.
    [NG] "Correct the FAIL lines above": see PROBLEMS; nothing was
         changed.

    Put the password in single quotes. A single quote inside the
    password is written twice ('').

 4. The setup, in one run

.\.venv\Scripts\python.exe scripts\setup_rds_database.py --cluster <writer endpoint> --admin-password '<dbadmin password>' --yes

    [OK] "Setup: READY" or "Setup: READY, with warnings" (read the
         WARN lines).
    A box "Console administrator / Initial password" is shown once on
    a new database: WRITE IT DOWN NOW, it is not shown again.
    The service is stopped before the setup and started after it.

 5. Clear the command history (the password was on the command line)

Clear-History
Remove-Item (Get-PSReadLineOption).HistorySavePath -ErrorAction SilentlyContinue

    Close this PowerShell window.

 6. In the console
    - Sign in as admin with the one-time password; choose a new one.
    - System > Database shows PostgreSQL.
    - Create the other console accounts again.
    - Enter the settings again from configuration.csv (Accepted
      application IDs, Ticket checks, Accepted instances, e-mail).
    - Resume processing; run one test ticket.

 7. Unattended option A only: leave the server with
    unattended\Leave_Bot_Running.cmd (Run as administrator), so the
    bot's session stays signed in and unlocked.

 Without the password on the command line (the tool asks for it, not
 shown), and with the questions:
.\.venv\Scripts\python.exe scripts\setup_rds_database.py --cluster <writer endpoint>

=====================================================================
 OPTIONS
=====================================================================
 --cluster <address>       The writer endpoint (asked for when left
                           out).
 --admin-password <pw>     The dbadmin password (asked for when left
                           out).
 --yes                     Answer yes to the setup and the service
                           start. A stop the service does not confirm
                           still ends the run.
 --check-only              Run the check only; change nothing.
 --port <port>             Another port (default: from the address,
                           else 5432).
 --database <name>         Another database name (default finesiii_v3).
 --app-login <name>        Another application login (default
                           finesiii_app).
 --admin-login <name>      Another administrator login (default
                           dbadmin).
 --audit-database <name>   Also prepare an audit database on the
                           cluster (only with the DBA's approval).
 --tls require             Only when the cluster is reached through
                           another name than its AWS endpoint.
 --set-password            Give the application login a new generated
                           password.
 --no-service              Neither stop nor start the service.

 Exit code 0: ready. 2: ready, with warnings. 1: not ready or stopped.
 The setup's report is also written to the logs folder of the data
 folder (setup_database_<time>.log); it never contains a password.

=====================================================================
 PROBLEMS
=====================================================================
 "does not name a cluster endpoint"
     Paste the endpoint alone, as shown in the AWS console.
 "is not known on this machine" / "not reachable" / time-out
     Spelling of the endpoint, DNS, or the security group or a
     firewall blocks this server on the port.
 "password authentication failed" for dbadmin
     Copy the current password from CyberArk again (no space before or
     after it) and run again.
 "cannot execute ... in a read-only transaction"
     The reader endpoint (".cluster-ro-") was given: use the writer
     endpoint.
 Certificate or name check failed
     The address is an alias: use the AWS endpoint, or --tls require.
 "no credential store for this account"
     Not signed in by remote desktop as the bot account.
 "FINESIII_DATA_DIR is not set for this account"
     Sign in as the bot account and open a new PowerShell window.
 "DATABASE_PASSWORD is set in the environment of this account"
     Remove that variable from the account's environment variables,
     open a new window and run again.
 WARN "the environment of this window sets DATABASE_ENGINE / ..."
     Remove that variable from the bot account's (or the machine's)
     environment variables, otherwise the service keeps using it.
 dbadmin "may not create logins and databases"
     The DBA grants CREATEROLE and CREATEDB, or creates them.
 The setup failed after the check
     With --yes the service is started again on its current database.
     Run the tool again after the correction: what was created is
     kept and reused; nothing is dropped.
 "Not started"
     Start the task by hand (unattended options B and D: start the
     task "FINESIII Bot Session Keeper"), then check with
     unattended\Check_Unattended.ps1.

=====================================================================
 OPTIONAL - AUTOMATED TESTS
=====================================================================
.\.venv\Scripts\python.exe -m pytest tests\unit\test_setup_rds_database_tool.py -q
# [OK] no failure

=====================================================================
 GOING BACK
=====================================================================
 The tool changes only what the database setup changes. Back to
 SQLite: in the settings file the setup named (finesiii.env in the
 data folder, or .env), set DATABASE_ENGINE=sqlite, then:
.\.venv\Scripts\python.exe desktop\app.py --stop
Start-ScheduledTask -TaskPath '\AIG\' -TaskName 'FINESIII RPA Agent'
 Older tool: copy the tool of 19 October 2026 over these two files.
