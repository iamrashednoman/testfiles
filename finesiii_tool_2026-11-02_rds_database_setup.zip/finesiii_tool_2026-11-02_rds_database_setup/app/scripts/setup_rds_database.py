#!/usr/bin/env python3
"""
Set up the application database on an Amazon RDS or Aurora cluster.

Asks for the cluster address and the current password of the cluster
administrator (copied from CyberArk), then runs the database setup of
the application folder (Setup_Database.py --rds) twice: first a check
that changes nothing, then, after a confirmation, the setup itself.
The service is stopped before the setup and can be started afterwards.

Run it from the application folder, signed in as the bot account (the
account the service runs as), in a new PowerShell window:

  cd C:\\FINESIII\\app
  .\\.venv\\Scripts\\python.exe scripts\\setup_rds_database.py

  # Check only, change nothing:
  .\\.venv\\Scripts\\python.exe scripts\\setup_rds_database.py --check-only

  # In one run, without questions (password on the command line, the
  # setup and the service start answered with yes):
  .\\.venv\\Scripts\\python.exe scripts\\setup_rds_database.py --cluster <endpoint> --admin-password '<password>' --yes

  # Other names than the defaults (database finesiii_v3, application
  # login finesiii_app, administrator dbadmin):
  .\\.venv\\Scripts\\python.exe scripts\\setup_rds_database.py --database <name> --app-login <name> --admin-login <name>

The cluster address may be given as the endpoint alone, with a port
("<endpoint>:5432") or as a full address ("postgresql://...@<endpoint>:
5432/..."): only the endpoint and the port are used.

The password
  It is typed or pasted without being shown, or given with
  --admin-password, and is handed only to the setup it starts, for this
  run. It is never written to a file, the screen or a log, and it is not
  kept after the run, so it may be rotated in CyberArk afterwards. Given
  with --admin-password it is visible in the process list while the tool
  runs and may stay in the PowerShell command history: clear the
  history after the run.

Exit code 0: ready. 2: ready, with warnings. 1: not ready or stopped.
"""
from __future__ import annotations

import argparse
import getpass
import os
import re
import subprocess
import sys
from pathlib import Path
from urllib.parse import urlsplit

APP_DIR = Path(__file__).resolve().parent.parent
SETUP_SCRIPT = APP_DIR / "Setup_Database.py"
DATA_DIR_VARIABLE = "FINESIII_DATA_DIR"
# The variable the database setup reads the administrator password from.
ADMIN_PASSWORD_VARIABLE = "DATABASE_ADMIN_PASSWORD"
# Variables that would change what the setup does when this account
# has them: the application password is then taken as given instead of
# generated.
CONFLICTING_VARIABLES = ("DATABASE_PASSWORD", "AUDIT_DATABASE_PASSWORD")
SERVICE_TASK = r"\AIG\FINESIII RPA Agent"
DEFAULT_PORT = 5432
_HOST_RE = re.compile(r"^[A-Za-z0-9]([A-Za-z0-9-]*[A-Za-z0-9])?"
                      r"(\.[A-Za-z0-9]([A-Za-z0-9-]*[A-Za-z0-9])?)+$")


class Stop(Exception):
    """Raised to end the run with a message and an exit code."""

    def __init__(self, message: str, code: int = 1):
        """Keep the message and the exit code."""
        super().__init__(message)
        self.code = code


# ---------------------------------------------------------------------
#  Input
# ---------------------------------------------------------------------
def parse_cluster(text: str, port: int | None = None) -> tuple[str, int]:
    """Return the endpoint and the port named by a cluster address.

    Args:
        text: The endpoint, "<endpoint>:<port>" or a full address such
            as postgresql://login@<endpoint>:5432/database.
        port: A port given separately; it wins over one in the text.

    Returns:
        (endpoint, port).

    Raises:
        Stop: The text names no valid endpoint or port.
    """
    value = (text or "").strip().strip('"').strip("'").strip()
    if not value:
        raise Stop("No cluster address was given.")
    if "://" not in value:
        value = "//" + value
    try:
        parts = urlsplit(value)
        host = (parts.hostname or "").strip().rstrip(".")
        found_port = parts.port
    except ValueError as e:
        raise Stop(f"The cluster address is not valid ({e}).") from None
    if not host or not _HOST_RE.match(host):
        raise Stop(f"'{text.strip()}' does not name a cluster endpoint. "
                   f"Give it as shown in the AWS console, for example "
                   f"<name>.cluster-<id>.<region>.rds.amazonaws.com.")
    chosen = port if port is not None else (found_port or DEFAULT_PORT)
    if not 1 <= int(chosen) <= 65535:
        raise Stop(f"The port {chosen} is not valid.")
    return host.lower(), int(chosen)


def ask_cluster(given: str, port: int | None) -> tuple[str, int]:
    """Return the endpoint and port from --cluster or from the keyboard."""
    if given:
        return parse_cluster(given, port)
    print("  Cluster address (the writer endpoint in the AWS console),")
    print("  for example <name>.cluster-<id>.<region>.rds.amazonaws.com")
    return parse_cluster(input("  Cluster address: "), port)


def ask_password(admin_login: str, given: str = "") -> str:
    """Return the administrator password: given, else asked without showing it.

    Raises:
        Stop: Nothing was entered.
    """
    if given:
        print("")
        print(f"  Password of '{admin_login}': given on the command line "
              f"(not shown).")
        return given
    print("")
    print(f"  Current password of '{admin_login}', copied from CyberArk.")
    print("  It is not shown while it is typed or pasted.")
    password = getpass.getpass("  Password: ")
    if not password:
        raise Stop("No password was entered.")
    return password


def confirm(question: str, assume_yes: bool = False) -> bool:
    """Return True when the answer to a yes/no question is yes.

    With assume_yes the question is shown answered and not asked.
    """
    if assume_yes:
        print(f"  {question} [y/N]: y (--yes)")
        return True
    try:
        answer = input(f"  {question} [y/N]: ").strip().lower()
    except EOFError:
        return False
    return answer in ("y", "yes")


# ---------------------------------------------------------------------
#  Checks before the setup
# ---------------------------------------------------------------------
def _stored_data_dir() -> str:
    """Return FINESIII_DATA_DIR as Windows stores it for new windows.

    A window opened before the value was stored does not see it. '' when
    it is not stored or this is not Windows.
    """
    if os.name != "nt":
        return ""
    try:
        import winreg
    except ImportError:
        return ""
    # A value of the account takes precedence over the machine's, as in
    # a new window.
    places = ((winreg.HKEY_CURRENT_USER, "Environment"),
              (winreg.HKEY_LOCAL_MACHINE,
               r"SYSTEM\CurrentControlSet\Control\Session Manager"
               r"\Environment"))
    for hive, key in places:
        try:
            with winreg.OpenKey(hive, key) as handle:
                value, _ = winreg.QueryValueEx(handle, DATA_DIR_VARIABLE)
        except OSError:
            continue
        value = os.path.expandvars(str(value or "")).strip()
        if value:
            return value
    return ""


def data_folder(env: dict) -> str:
    """Make sure the setup sees the data folder; return where it is.

    Taken from this window, else from the value stored for the account
    or the machine (copied into the setup's environment).

    Raises:
        Stop: No data folder is known, or it does not exist.
    """
    folder = env.get(DATA_DIR_VARIABLE, "") or _stored_data_dir()
    if not folder and (APP_DIR / ".env").is_file():
        # The setup then writes to the .env of the application folder.
        return f"not set (the settings go to {APP_DIR / '.env'})"
    if not folder:
        raise Stop(f"{DATA_DIR_VARIABLE} is not set for this account. Sign "
                   f"in as the bot account and open a new PowerShell "
                   f"window.")
    if not Path(folder).is_dir():
        raise Stop(f"The data folder {folder} ({DATA_DIR_VARIABLE}) does "
                   f"not exist.")
    env[DATA_DIR_VARIABLE] = folder
    return folder


def check_environment(env: dict) -> None:
    """Stop when this account's environment would change the setup.

    Raises:
        Stop: A password variable of the application is set.
    """
    found = [name for name in CONFLICTING_VARIABLES if env.get(name)]
    if found:
        raise Stop(", ".join(found) + " is set in the environment of this "
                   "account, so the setup would use that value as the "
                   "application password instead of generating one. "
                   "Remove it (Windows: Edit environment variables for "
                   "your account), open a new window and run again.")


def application_python() -> str:
    """Return the application's Python, else the one running this script."""
    venv = APP_DIR / ".venv" / ("Scripts" if os.name == "nt" else "bin") \
        / ("python.exe" if os.name == "nt" else "python")
    return str(venv) if venv.is_file() else sys.executable


# ---------------------------------------------------------------------
#  Running the setup and the service
# ---------------------------------------------------------------------
def setup_command(python: str, args, host: str, port: int,
                  check_only: bool) -> list[str]:
    """Return the command line of one database setup run.

    The password is not part of it: it goes in the setup's environment.
    """
    command = [python, str(SETUP_SCRIPT), "--rds", "--host", host,
               "--port", str(port), "--database", args.database,
               "--app-login", args.app_login,
               "--admin-login", args.admin_login]
    if args.audit_database:
        command += ["--audit-database", args.audit_database]
    if args.tls != "verify-full":
        command += ["--tls", args.tls]
    if args.set_password and not check_only:
        command.append("--set-password")
    if check_only:
        # The check needs no answer; its output is read through a pipe,
        # where a question would not be seen.
        command += ["--no-prompt", "--check-only"]
    return command


def run_setup(command: list[str], env: dict, password: str) -> int:
    """Run the database setup with the password for this run only.

    Its output goes straight to this window, so the one-time console
    administrator password it may show is seen only here.

    Returns:
        The setup's exit code.
    """
    child = dict(env)
    child[ADMIN_PASSWORD_VARIABLE] = password
    sys.stdout.flush()
    try:
        return subprocess.run(command, cwd=str(APP_DIR), env=child).returncode
    finally:
        child.pop(ADMIN_PASSWORD_VARIABLE, None)


def run_check(command: list[str], env: dict, password: str
              ) -> tuple[int, list[str]]:
    """Run the check-only setup, showing its output and keeping its lines.

    The check never shows a password, so its output may be read here.

    Returns:
        (exit code, output lines).
    """
    child = dict(env)
    child[ADMIN_PASSWORD_VARIABLE] = password
    child["PYTHONIOENCODING"] = "utf-8"
    lines: list[str] = []
    sys.stdout.flush()
    try:
        with subprocess.Popen(command, cwd=str(APP_DIR), env=child,
                              stdout=subprocess.PIPE,
                              stderr=subprocess.STDOUT, text=True,
                              encoding="utf-8", errors="replace") as proc:
            for line in proc.stdout:
                print(line, end="", flush=True)
                lines.append(line.rstrip("\n"))
            code = proc.wait()
    finally:
        child.pop(ADMIN_PASSWORD_VARIABLE, None)
    return code, lines


# A check of a new cluster stops at the first missing item: the login,
# or the database when the login exists. Both are created by the setup.
_FAIL_RE = re.compile(r"^\s*\[FAIL\s*\]\s+(?P<item>.+?): (?P<detail>.*)$")


def check_verdict(code: int, lines: list[str], app_login: str,
                  database: str) -> str:
    """Return what the check means for the setup.

    Returns:
        "ready" when the check passed; "new" when the only problems are
        the application login or database that the setup creates (so the
        cluster, the administrator password and the encryption are in
        order); "fail" otherwise.
    """
    if code in (0, 2):
        return "ready"
    expected = {f"Login '{app_login}'", f"Database '{database}'"}
    fails = set()
    for line in lines:
        m = _FAIL_RE.match(line)
        if m:
            fails.add((m.group("item"), m.group("detail").strip()))
    if fails and all(item in expected and detail == "does not exist"
                     for item, detail in fails):
        return "new"
    return "fail"


def stop_service(python: str, env: dict) -> bool:
    """Ask the running service to finish its current work and stop.

    Returns:
        True when the stop was handled (also when it was not running).
    """
    sys.stdout.flush()
    result = subprocess.run([python, str(APP_DIR / "desktop" / "app.py"),
                             "--stop"], cwd=str(APP_DIR), env=env)
    return result.returncode == 0


def start_service() -> bool:
    """Start the service's scheduled task. True when it was started."""
    if os.name != "nt":
        print("  Not Windows: start the application by hand.")
        return False
    sys.stdout.flush()
    result = subprocess.run(["schtasks", "/Run", "/TN", SERVICE_TASK])
    return result.returncode == 0


def outcome(code: int) -> str:
    """Return the setup result in words."""
    return {0: "READY", 2: "READY, with warnings"}.get(code, "NOT READY")


# ---------------------------------------------------------------------
#  Main
# ---------------------------------------------------------------------
def parse_arguments(argv):
    """Read the command line."""
    p = argparse.ArgumentParser(
        description="Set up the application database on an Amazon RDS or "
                    "Aurora cluster with the database setup of the "
                    "application folder.")
    p.add_argument("--cluster", default="", metavar="ADDRESS",
                   help="cluster address (asked for when left out)")
    p.add_argument("--port", type=int, default=None,
                   help=f"port (default: from the address, else "
                        f"{DEFAULT_PORT})")
    p.add_argument("--admin-login", default="dbadmin", metavar="LOGIN",
                   help="administrator login (default dbadmin)")
    p.add_argument("--app-login", default="finesiii_app", metavar="LOGIN",
                   help="the application's own login (default "
                        "finesiii_app)")
    p.add_argument("--database", default="finesiii_v3", metavar="NAME",
                   help="the application's database (default finesiii_v3)")
    p.add_argument("--audit-database", default="", metavar="NAME",
                   help="also prepare this audit database and switch the "
                        "audit trail to it")
    p.add_argument("--tls", choices=["verify-full", "require"],
                   default="verify-full",
                   help="require only when the cluster is reached through "
                        "another name than its endpoint")
    p.add_argument("--set-password", action="store_true",
                   help="give the application login a new generated "
                        "password")
    p.add_argument("--check-only", action="store_true",
                   help="run the check only; change nothing")
    p.add_argument("--no-service", action="store_true",
                   help="neither stop nor start the service")
    p.add_argument("--admin-password", default="", metavar="PASSWORD",
                   help="the administrator password, instead of being "
                        "asked for it (visible in the process list while "
                        "the tool runs; clear the command history after "
                        "the run)")
    p.add_argument("--yes", action="store_true",
                   help="answer yes to running the setup and starting the "
                        "service (a stop the service does not confirm "
                        "still ends the run)")
    return p.parse_args(argv)


def run(args) -> int:
    """Run the check and, when confirmed, the setup.

    Returns:
        The exit code (see the module description).

    Raises:
        Stop: A problem that ends the run.
    """
    print("=" * 69)
    print(" AIG IAM Access RPA - database setup on Amazon RDS / Aurora")
    print("=" * 69)
    if not SETUP_SCRIPT.is_file():
        raise Stop(f"{SETUP_SCRIPT} was not found. Put this script in the "
                   f"scripts folder of the application folder.")
    env = dict(os.environ)
    env.pop(ADMIN_PASSWORD_VARIABLE, None)
    check_environment(env)
    folder = data_folder(env)
    account = (f"{env.get('USERDOMAIN', '')}\\" if env.get("USERDOMAIN")
               else "") + (env.get("USERNAME", "") or getpass.getuser())
    print(f"  Application folder : {APP_DIR}")
    print(f"  Data folder        : {folder}")
    print(f"  Signed in as       : {account}")
    print("  The application password is kept for this account: it must be")
    print("  the account the service runs as.")
    print("")
    host, port = ask_cluster(args.cluster, args.port)
    print(f"  Endpoint           : {host}")
    print(f"  Port               : {port}")
    print(f"  Database / logins  : {args.database} / application "
          f"{args.app_login}, administrator {args.admin_login}")
    password = ask_password(args.admin_login, args.admin_password)
    args.admin_password = ""
    python = application_python()

    try:
        print("")
        print("-" * 69)
        print(" 1. Check (nothing is created or changed)")
        print("-" * 69)
        code, lines = run_check(
            setup_command(python, args, host, port, True), env, password)
        verdict = check_verdict(code, lines, args.app_login, args.database)
        if verdict == "fail":
            print(f"\n  Check: {outcome(code)}")
            raise Stop("Correct the FAIL lines above and run this script "
                       "again. Nothing was changed.", 1)
        if verdict == "new":
            print("\n  Check: the cluster, the administrator password and "
                  "the encryption are in order.")
            print(f"  The login '{args.app_login}' and/or the database "
                  f"'{args.database}' do not exist yet: the setup creates "
                  f"them.")
        else:
            print(f"\n  Check: {outcome(code)}")
        if args.check_only:
            return 0 if verdict == "new" else code
        print("")
        if not confirm("Run the setup now? The service is stopped first.",
                       args.yes):
            raise Stop("Stopped before the setup. Nothing was changed.", 1)

        if not args.no_service:
            print("")
            print("-" * 69)
            print(" 2. Stopping the service")
            print("-" * 69)
            if not stop_service(python, env):
                if not confirm("The service did not confirm the stop. "
                               "Continue anyway?"):
                    raise Stop("Stopped before the setup. Nothing was "
                               "changed.", 1)

        print("")
        print("-" * 69)
        print(" 3. Setup")
        print("-" * 69)
        code = run_setup(setup_command(python, args, host, port, False),
                         env, password)
    finally:
        password = ""
    print(f"\n  Setup: {outcome(code)}")
    if code not in (0, 2):
        print("  Correct the FAIL lines above and run this script again; "
              "what was created is kept and reused.")
        if not args.no_service and confirm(
                "Start the service again on its current database?",
                args.yes):
            start_service()
        return 1
    print("  If a one-time console administrator password was shown above,")
    print("  keep it now: it is not shown again.")
    if not args.no_service and confirm("Start the service now?", args.yes):
        if start_service():
            print("  Started. Sign in to the console and check System > "
                  "Database.")
        else:
            print(f"  Not started: start the task '{SERVICE_TASK}' by hand.")
    return code


def main(argv=None) -> int:
    """Run the tool and return its exit code."""
    args = parse_arguments(sys.argv[1:] if argv is None else argv)
    try:
        return run(args)
    except Stop as e:
        print(f"\n  {e}")
        return e.code
    except KeyboardInterrupt:
        print("\n  Stopped at the keyboard.")
        return 1


if __name__ == "__main__":
    sys.exit(main())
