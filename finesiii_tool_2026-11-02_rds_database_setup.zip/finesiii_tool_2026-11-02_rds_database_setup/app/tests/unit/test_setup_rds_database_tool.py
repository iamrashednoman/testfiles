"""The RDS database setup tool (scripts/setup_rds_database.py).

Pins:
  - the cluster address is reduced to the endpoint and the port, in any
    of the forms it is copied in;
  - the administrator password never appears on the command line of
    the setup; it is handed over in the setup's environment only;
  - a check of a new cluster that fails only on the missing application
    login or database lets the setup go on; any other failure stops it;
  - a password variable of the application in the environment stops
    the run before anything is asked;
  - with --admin-password and --yes the whole run asks nothing, and the
    password still goes to the setup's environment only.
"""
import importlib.util
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest

ROOT = Path(__file__).resolve().parents[2]
_spec = importlib.util.spec_from_file_location(
    "setup_rds_database", ROOT / "scripts" / "setup_rds_database.py")
tool = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(tool)

ENDPOINT = "sample.cluster-abc123.us-east-1.rds.amazonaws.com"


def _args(**over):
    """Return the command-line values with the defaults."""
    base = dict(database="finesiii_v3", app_login="finesiii_app",
                admin_login="dbadmin", audit_database="",
                tls="verify-full", set_password=False)
    base.update(over)
    return SimpleNamespace(**base)


class TestClusterAddress:
    """Reading the cluster address."""

    @pytest.mark.parametrize("text,port", [
        (ENDPOINT, 5432),
        (f"  {ENDPOINT}  ", 5432),
        (f'"{ENDPOINT}"', 5432),
        (f"{ENDPOINT}:5433", 5433),
        (f"postgresql://dbadmin@{ENDPOINT}:5432/postgres", 5432),
        (f"https://{ENDPOINT}/", 5432),
        (ENDPOINT.upper(), 5432),
    ])
    def test_endpoint_and_port(self, text, port):
        """Every copied form of the address gives the endpoint and port."""
        assert tool.parse_cluster(text) == (ENDPOINT, port)

    def test_separate_port_wins(self):
        """A port given separately wins over the one in the address."""
        assert tool.parse_cluster(f"{ENDPOINT}:5433", 6000) == (ENDPOINT,
                                                                 6000)

    @pytest.mark.parametrize("text", ["", "   ", "bad host", "localhost",
                                      "https://bad host/", "a..b"])
    def test_refused(self, text):
        """A blank or malformed address is refused."""
        with pytest.raises(tool.Stop):
            tool.parse_cluster(text)


class TestSetupCommand:
    """The command line and environment of the setup run."""

    def test_password_never_on_the_command_line(self):
        """The password never appears on the setup command line."""
        command = tool.setup_command("python", _args(), ENDPOINT, 5432,
                                     False)
        assert "--rds" in command and ENDPOINT in command
        assert not any("password" in part.lower() and part != "--set-password"
                       for part in command)

    def test_check_only_and_options(self):
        """A check run carries its options and never sets a password."""
        command = tool.setup_command(
            "python", _args(audit_database="finesiii_audit", tls="require",
                            set_password=True), ENDPOINT, 5432, True)
        assert command[-1] == "--check-only"
        assert "--no-prompt" in command               # never waits for input
        assert "--set-password" not in command        # never in a check
        assert command[command.index("--audit-database") + 1] == \
            "finesiii_audit"
        assert command[command.index("--tls") + 1] == "require"

    def test_password_only_in_the_setup_environment(self, monkeypatch):
        """The password is handed over only in the setup's environment."""
        seen = {}

        def fake_run(command, cwd=None, env=None):
            """Record the command and environment; report success."""
            seen["command"], seen["env"] = command, dict(env)
            return SimpleNamespace(returncode=0)

        monkeypatch.setattr(tool.subprocess, "run", fake_run)
        env = {"PATH": "x"}
        assert tool.run_setup(["python", "setup"], env, "S3cret!") == 0
        assert seen["env"][tool.ADMIN_PASSWORD_VARIABLE] == "S3cret!"
        assert "S3cret!" not in " ".join(seen["command"])
        assert tool.ADMIN_PASSWORD_VARIABLE not in env


class TestCheckVerdict:
    """The verdict drawn from a check run."""

    def test_passed(self):
        """A check that passes gives a ready verdict."""
        assert tool.check_verdict(0, [], "finesiii_app",
                                  "finesiii_v3") == "ready"
        assert tool.check_verdict(2, [], "finesiii_app",
                                  "finesiii_v3") == "ready"

    @pytest.mark.parametrize("lines", [
        ["  [FAIL   ] Login 'finesiii_app': does not exist"],
        ["  [FAIL   ] Database 'finesiii_v3': does not exist",
         "  [FAIL   ] Database 'finesiii_v3': does not exist"],
    ])
    def test_new_cluster(self, lines):
        """Only a missing login or database gives a new-cluster verdict."""
        assert tool.check_verdict(1, ["=== 3/8 Sign-in"] + lines,
                                  "finesiii_app", "finesiii_v3") == "new"

    @pytest.mark.parametrize("lines", [
        [],
        ["  [FAIL   ] Sign-in as 'dbadmin': connection failed"],
        ["  [FAIL   ] Login 'finesiii_app': does not exist",
         "  [FAIL   ] Server check: certificate bundle missing"],
        ["  [FAIL   ] Login 'other_login': does not exist"],
        ["  [FAIL   ] Login 'finesiii_app': exists but is not allowed to "
         "sign in"],
    ])
    def test_stops(self, lines):
        """Any other failure stops the setup."""
        assert tool.check_verdict(1, lines, "finesiii_app",
                                  "finesiii_v3") == "fail"


class TestEnvironment:
    """The environment and data folder checks."""

    @pytest.mark.parametrize("name", ["DATABASE_PASSWORD",
                                      "AUDIT_DATABASE_PASSWORD"])
    def test_password_variable_stops(self, name):
        """A password variable of the application stops the run."""
        with pytest.raises(tool.Stop):
            tool.check_environment({name: "x"})

    def test_clean_environment(self):
        """A clean environment passes."""
        tool.check_environment({"PATH": "x"})

    def test_data_folder_from_the_window(self, tmp_path):
        """The data folder is taken from the environment."""
        env = {tool.DATA_DIR_VARIABLE: str(tmp_path)}
        assert tool.data_folder(env) == str(tmp_path)

    def test_missing_data_folder_stops(self, tmp_path):
        """A missing data folder stops the run."""
        with pytest.raises(tool.Stop):
            tool.data_folder({tool.DATA_DIR_VARIABLE: str(tmp_path / "no")})

    def test_run_stops_before_asking(self, monkeypatch):
        """A password variable stops the run before anything is asked."""
        monkeypatch.setenv("DATABASE_PASSWORD", "x")
        monkeypatch.setattr("builtins.input", lambda *a: pytest.fail(
            "asked for input"))
        assert tool.main(["--cluster", ENDPOINT]) == 1


class TestOneRun:
    """The whole run from the command line, without questions."""

    def test_password_and_yes_ask_nothing(self, monkeypatch, tmp_path):
        """With --admin-password and --yes nothing is asked."""
        monkeypatch.setenv(tool.DATA_DIR_VARIABLE, str(tmp_path))
        for name in tool.CONFLICTING_VARIABLES:
            monkeypatch.delenv(name, raising=False)
        monkeypatch.setattr("builtins.input", lambda *a: pytest.fail(
            "asked for input"))
        monkeypatch.setattr(tool.getpass, "getpass", lambda *a: pytest.fail(
            "asked for the password"))
        seen = {}

        def fake_check(command, env, password):
            """Record the check and report a new cluster."""
            seen["check"] = (command, password)
            return 1, ["  [FAIL   ] Login 'finesiii_app': does not exist"]

        def fake_setup(command, env, password):
            """Record the setup and report ready."""
            seen["setup"] = (command, password)
            return 0

        monkeypatch.setattr(tool, "run_check", fake_check)
        monkeypatch.setattr(tool, "run_setup", fake_setup)
        code = tool.main(["--cluster", ENDPOINT, "--admin-password", "S3cret!",
                          "--yes", "--no-service"])
        assert code == 0
        assert seen["check"][1] == seen["setup"][1] == "S3cret!"
        assert not any("S3cret!" in part for part in seen["setup"][0])
        assert "--check-only" not in seen["setup"][0]

    def test_without_yes_the_setup_is_asked_for(self, monkeypatch, tmp_path):
        """Without --yes the run still asks before the setup."""
        monkeypatch.setenv(tool.DATA_DIR_VARIABLE, str(tmp_path))
        for name in tool.CONFLICTING_VARIABLES:
            monkeypatch.delenv(name, raising=False)
        asked = []
        monkeypatch.setattr("builtins.input",
                            lambda q="": asked.append(q) or "n")
        monkeypatch.setattr(tool, "run_check", lambda c, e, p: (0, []))
        monkeypatch.setattr(tool, "run_setup", lambda c, e, p: pytest.fail(
            "the setup ran"))
        assert tool.main(["--cluster", ENDPOINT, "--admin-password", "x",
                          "--no-service"]) == 1
        assert any("Run the setup now" in q for q in asked)
