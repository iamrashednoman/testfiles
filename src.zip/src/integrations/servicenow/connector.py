"""
ServiceNow connector — the poll loop.

One cycle (poll_once):
  1. (optional) check the service is healthy — if not, skip this cycle
  2. fetch open tickets assigned to the bot (ServiceNow Table API)
  3. map each ticket → request payload (config-driven)
  4. submit to the service API: POST /api/v1/requests
       202 → queued      (the engine processes it FIFO)
       409 → duplicate    (idempotency already has this ticket)
       400 → invalid      (logged + skipped; optional write-back)
  5. (optional, OFF by default) write a work note back to the ticket

Ticket filters: the assignment group, the Bot account and Requested For
are each optional - a filled-in value is applied, an empty one skipped.
Every fetched ticket is checked against the group and Requested For by
the bot itself; one outside them is skipped without a note.

Assigning before queueing (group mode, and whenever the Bot account is
empty): before step 4 each new ticket is assigned to the bot account in
ServiceNow (re-checked as still free, the saved assignment verified). A
ticket that cannot be assigned is not queued and is tried again on the
next poll; one a person took in the meantime is left to them; one the
intake check refuses after it was assigned goes back to the group,
unassigned.

The connector never touches the queue/DB directly — it only uses the public
REST API, so the core service is completely unchanged and unaware of it.
"""

import re
import time
from typing import Optional

import httpx

from src.integrations.servicenow.config import ServiceNowSettings
from src.integrations.servicenow.client import ServiceNowClient, ServiceNowError
from src.integrations.servicenow.mapper import (
    map_ticket, reasons_skipped, enrich_ticket, generate_initial_password,
)
from src.integrations.servicenow.sailpoint import (
    for_application, parse_ticket as parse_sailpoint_ticket, task_text,
    variable as sailpoint_variable,
)
from src.integrations.servicenow.writeback import render

# "Matching fields" in the duplicate e-mail and audit record: a rule's
# own key shown as the ticket calls it (NB-021).
_FIELD_LABELS = {"tracking_id": "Access Request ID"}


class ReportMemory:
    """What has already been reported about tickets that STAY open.

    An unmappable, invalid or duplicate ticket remains open and assigned
    to the bot, so every poll meets it again. Without a memory each poll
    repeated the rejection email, the work note and the audit event
    (SN-03). One entry per ticket: {number: fingerprint}, where the
    fingerprint is the reason plus a hash of the ticket content — the
    same ticket is reported again only when its content or the reason
    changes. Entries of tickets that are no longer open are dropped.
    """

    def __init__(self, data=None):
        self.data = dict(data or {})

    def first_time(self, number: str, fingerprint: str) -> bool:
        """True when this is news (and remember it)."""
        if not number:
            return True
        if self.data.get(number) == fingerprint:
            return False
        self.data[number] = fingerprint
        return True

    def matches(self, number: str, fingerprint: str) -> bool:
        return bool(number) and self.data.get(number) == fingerprint

    def prune(self, open_numbers) -> None:
        keep = set(open_numbers)
        for number in list(self.data):
            if number not in keep:
                del self.data[number]


def content_hash(ticket: dict) -> str:
    """Stable hash of a ticket's content, ignoring fields that change
    without the request changing (timestamps, counters, notes)."""
    import hashlib
    import json
    volatile = ("sys_updated_on", "sys_updated_by", "sys_mod_count",
                "work_notes", "comments", "comments_and_work_notes",
                "parsed")
    source = ticket if isinstance(ticket, dict) else {}
    body = {}
    for key, value in source.items():
        if key not in volatile:
            body[key] = value
    text = json.dumps(body, sort_keys=True, default=str, ensure_ascii=False)
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]


class ServiceNowConnector:
    """Fetches ServiceNow tickets and feeds them to the service API."""

    def __init__(self, settings: ServiceNowSettings,
                 client: Optional[ServiceNowClient] = None, logger=None,
                 on_rejected=None):
        self.s = settings
        self.logger = logger
        self.client = client or ServiceNowClient(settings, logger=logger)
        # Optional Step-9 hook (rejection_type, reason, details) — fired when
        # a ticket cannot be mapped to a valid request, or the service
        # rejects it as invalid. A hook failure never breaks the poll loop.
        self.on_rejected = on_rejected
        # Optional (ticket_number) -> bool: True when the platform has
        # ALREADY seen this ticket in any status. Set by the in-agent
        # poller (backed by the request queue) so a ticket that is
        # queued, running, done OR failed is not resubmitted on every
        # poll — failed work is re-run by an operator's Retry. None (the
        # standalone script) keeps the original behaviour.
        self.known_ticket = None
        # Optional (payload, ticket) -> dict | None: the request the
        # platform already holds for the SAME operation/affiliation/
        # employee under ANOTHER ticket number (2026-09-26). A match is
        # a content duplicate: skipped, audited, alerted, and noted on
        # the ticket when write-back is on. The dict carries
        # request_id, ticket_id, status, matched_fields.
        self.duplicate_of = None
        # Optional (payload, ticket) -> dict | None: a request with the
        # same requester and description but a different business key.
        # Recorded only (possible duplicate) — never blocks.
        self.possible_duplicate_of = None
        # Optional (event: str, detail: dict) -> None: audit sink.
        self.audit_hook = None
        # Optional ReportMemory: report each stuck ticket ONCE (SN-03).
        # None (the standalone script) keeps the original behaviour.
        self.reported = None
        self._stop = False
        self._last_refusal = ""          # detail of the last intake 400
        self._bot_sys_id = None          # resolved once per connector

    # ── one cycle ──────────────────────────────────────────────────

    def poll_once(self, dry_run: bool = False) -> dict:
        """One poll. dry_run=True is READ-ONLY (2026-09-29, T3): nothing
        is claimed, noted, handed over, e-mailed, audited or remembered;
        instead stats["tickets"] lists what the bot WOULD do with each
        ticket (queue / reject / skip / defer, with the reason)."""
        stats = {"fetched": 0, "submitted": 0, "duplicate": 0,
                 "skipped": 0, "invalid": 0, "errors": 0, "known": 0,
                 "duplicate_content": 0, "possible_duplicate": 0,
                 "deferred": 0, "suppressed": 0, "not_assigned": 0,
                 "out_of_selection": 0}
        preview = [] if dry_run else None
        if dry_run:
            stats["tickets"] = preview
        # What this preview would queue, so a later ticket for the same
        # operation, code and employee shows as its duplicate, as the
        # real poll then finds it (E2E-L13). Real polls do not use it.
        would_queue = {} if dry_run else None

        def outcome(number, action, reason="", **extra):
            if preview is not None:
                preview.append({"ticket": number, "action": action,
                                "reason": reason, **extra})

        if self.s.respect_service_health and not dry_run:
            if not self._service_healthy():
                self._log("warning", "RPA service not healthy/reachable — skipping this poll cycle")
                stats["service_unavailable"] = True
                return stats

        # A Bot account entered as a name is matched by its sys_id.
        self._resolve_bot_for_query()
        try:
            tickets = self.client.fetch_assigned_open()
        except ServiceNowError as e:
            self._log("error", f"ServiceNow fetch failed: {e}")
            stats["errors"] += 1
            # ServiceNow itself did not answer: the only kind of error that
            # counts as an outage (SN-03, 2026-10-03). A single ticket that
            # could not be read or queued does not.
            stats["fetch_failed"] = True
            # Why, for the System page and the outage e-mail (2026-09-28).
            stats["error_detail"] = str(e)[:300]
            return stats

        stats["fetched"] = len(tickets)
        self._log("info", f"Fetched {len(tickets)} open ticket(s) from ServiceNow")

        # Each ticket's group and Requested For, read by sys_id, to check
        # it against the filters that are filled in before anything is
        # done with it. None when no such filter is set.
        try:
            selection = self._selection_values(tickets)
        except ServiceNowError as e:
            self._log("error", f"ServiceNow selection check failed: {e}")
            stats["errors"] += 1
            stats["fetch_failed"] = True
            stats["error_detail"] = str(e)[:300]
            return stats

        # Opt-in features (both default OFF → behavior identical to before):
        # description parsing feeds ticket["parsed"] for parsed.* mappings;
        # generate_password gives provision requests a random per-user password.
        password_gen = generate_initial_password if self.s.generate_password else None

        if self.reported is not None and not dry_run:
            open_numbers = []
            for t in tickets:
                if isinstance(t, dict):
                    open_numbers.append(str(t.get("number", "")))
            self.reported.prune(open_numbers)

        sailpoint = self.s.ticket_format == "sailpoint"
        for ticket in tickets:
            if not isinstance(ticket, dict):
                continue
            reasons = ""
            if sailpoint:
                # The variables are read only for tickets the platform
                # does not know yet (below), so mapping waits.
                fingerprint = content_hash(ticket)
                payload = None
                number = str(ticket.get("number", "") or "(unknown)")
            else:
                fingerprint = content_hash(ticket)
                ticket = enrich_ticket(ticket, self.s.description_parsing)
                payload = map_ticket(ticket, self.s.field_mapping,
                                     password_generator=password_gen,
                                     words=self.s.operation_words or None)
                number = payload["ticket_id"] if payload else ticket.get("number", "(unknown)")
            sys_id = ticket.get("sys_id", "")

            if selection is not None:
                why = self.s.selection_mismatch(
                    selection.get(self._ref(sys_id)) or {})
                if why:
                    self._out_of_selection(number, sys_id, why, dry_run,
                                           outcome, stats)
                    continue

            if self.known_ticket is not None and number:
                try:
                    already = bool(self.known_ticket(number))
                except Exception as e:      # a lookup fault must not stop the poll
                    self._log("warning", f"known-ticket lookup failed for {number}: {e}")
                    already = False
                if already:
                    stats["known"] += 1
                    outcome(number, "skip", "already known to the bot "
                                            "(queued or processed earlier)")
                    continue

            if sailpoint:
                # Found to be for another application on an earlier
                # poll (with the same application IDs): not read again.
                other_app = self._other_application_reason()
                if other_app and self._reported_before(
                        number, f"out_of_selection:{other_app}"):
                    stats["out_of_selection"] += 1
                    outcome(number, "skip", f"not in the selection: "
                                            f"{other_app}")
                    continue
                try:
                    variables = self.client.fetch_variables(ticket)
                except ServiceNowError as e:
                    # Not the ticket's fault: tried again next poll.
                    self._log("error", f"Ticket {number}: catalog variables "
                                       f"could not be read: {e}")
                    stats["errors"] += 1
                    stats["error_detail"] = str(e)[:300]
                    outcome(number, "defer", f"catalog variables could not "
                                             f"be read: {e}")
                    continue
                variables = self._with_task_text(ticket, variables, number)
                # A ticket for another application is not the bot's: no
                # note, no e-mail - said once in the log.
                if other_app and not for_application(ticket, variables,
                                                     self.s):
                    self._out_of_selection(number, sys_id, other_app,
                                           dry_run, outcome, stats)
                    continue
                fingerprint = content_hash(dict(ticket, variables=variables))
                payloads, reasons = parse_sailpoint_ticket(ticket, variables, self.s)
                if payloads:
                    self._enrich_people(ticket, payloads)
            else:
                payloads = [payload] if payload is not None else None

            if not payloads:
                stats["skipped"] += 1
                if reasons:
                    note_reason = reasons
                else:
                    reasons = reasons_skipped(ticket, self.s.field_mapping)
                    note_reason = f"the ticket is missing {reasons}"
                if dry_run:
                    outcome(number, "reject", note_reason,
                            already_reported=self._reported_before(
                                number, f"unmappable:{reasons}:{fingerprint}"))
                    continue
                if not self._news(number, f"unmappable:{reasons}:{fingerprint}"):
                    stats["suppressed"] += 1
                    continue
                self._log("warning",
                          f"Ticket {number} skipped — unmappable: {reasons}")
                self._notify_rejected(
                    "VALIDATION FAILED",
                    f"Ticket could not be mapped to a valid request: {reasons}",
                    {"ticket_id": number, "sys_id": sys_id,
                     "missing": reasons, "source": "servicenow"},
                )
                self._audit("servicenow_ticket_unmappable", {
                    "ticket_id": number, "sys_id": sys_id,
                    "missing": reasons})
                self._reject_on_ticket(sys_id, number, note_reason)
                continue

            payload = payloads[0]
            multi = len(payloads) > 1
            original = None
            for part in payloads:
                hit = self._call_hook(self.duplicate_of, part, ticket, number)
                if not hit:
                    continue
                # A ticket with several codes (certification, transfer,
                # termination) still runs a code that another ticket
                # already removed — the removal is simply confirmed. It
                # is blocked only as a repeat (same tracking ID) or when
                # a newer ticket would be undone (2026-09-28).
                if multi and not hit.get("superseded") and \
                        "tracking_id" not in (hit.get("matched_fields") or []):
                    continue
                original, payload = hit, part
                break
            if not original and would_queue and not multi and \
                    int(self.s.duplicate_window_days or 0) > 0:
                from src.integrations.servicenow.duplicates import business_key
                earlier = would_queue.get(business_key(payload))
                if earlier:
                    original = {"ticket_id": earlier,
                                "reason": "it is queued first by the same poll"}
            if original:
                stats["duplicate_content"] += 1
                orig = original.get("ticket_id", "") or \
                    original.get("request_id", "")
                if dry_run:
                    outcome(number, "skip",
                            (("superseded by" if original.get("superseded")
                              else "duplicate of") + f" {orig}"
                             + (f": {original.get('reason')}"
                                if original.get("reason") else "")),
                            already_reported=self._reported_before(
                                number, f"duplicate:{orig}:{fingerprint}"))
                    continue
                if self._news(number, f"duplicate:{orig}:{fingerprint}"):
                    self._handle_content_duplicate(number, sys_id, payload,
                                                   original)
                else:
                    stats["suppressed"] += 1
                continue

            # Rejected as invalid by the intake API on an earlier poll
            # and unchanged since: do not submit (and alert) again.
            if self.reported is not None and not dry_run and \
                    self.reported.matches(number, f"invalid:{fingerprint}"):
                stats["invalid"] += 1
                stats["suppressed"] += 1
                continue
            if dry_run and self._reported_before(number,
                                                 f"invalid:{fingerprint}"):
                outcome(number, "skip", "refused earlier by the intake "
                                        "check and unchanged since")
                continue

            # Every SailPoint task carries the same system requester and
            # task description, so this signal would flag them all; the
            # tracking-ID rule in duplicate_of covers them instead.
            possible = None if sailpoint else self._call_hook(
                self.possible_duplicate_of, payload, ticket, number)
            if possible and dry_run:
                stats["possible_duplicate"] += 1
            elif possible:
                stats["possible_duplicate"] += 1
                self._log("warning",
                          f"Ticket {number} looks like {possible.get('ticket_id')} "
                          f"(same requester and description, different codes) "
                          f"— queued, flagged for review")
                self._audit("servicenow_possible_duplicate", {
                    "ticket_id": number, "sys_id": sys_id,
                    "similar_ticket_id": possible.get("ticket_id", ""),
                    "similar_request_id": possible.get("request_id", ""),
                    "matched_fields": possible.get("matched_fields", [])})
                payload.setdefault("metadata", {})["possible_duplicate_of"] = {
                    "ticket_id": possible.get("ticket_id", ""),
                    "request_id": possible.get("request_id", "")}

            # Cap NEW work per poll; the rest is picked up next time. A
            # ticket's requests are submitted together, never split
            # across polls (unless one ticket alone exceeds the cap).
            if stats["submitted"] >= self.s.max_per_poll or (
                    stats["submitted"] and
                    stats["submitted"] + len(payloads) > self.s.max_per_poll):
                stats["deferred"] += 1
                outcome(number, "defer", f"more than {self.s.max_per_poll} "
                                         f"new request(s) in one poll; "
                                         f"picked up by the next poll")
                continue

            assign_first = self.s.assigns_before_queueing
            if dry_run:
                requests, refused = [], []
                for part in payloads:
                    self._log("info", f"[DRY-RUN] would submit "
                                      f"{part['ticket_id']}: {self._safe(part)}")
                    requests.append({
                        k: part.get(k, "") for k in
                        ("ticket_id", "operation", "affiliation_code",
                         "employee_code")})
                    refused += [f"{part.get('ticket_id', '')}: {p}"
                                for p in _format_problems(part)]
                if refused:
                    outcome(number, "reject", "the intake check would refuse "
                                              "it: " + "; ".join(refused),
                            requests=requests)
                elif assign_first:
                    bot, problem = self._bot_for_preview()
                    if problem:
                        outcome(number, "defer", problem, requests=requests)
                    else:
                        outcome(number, "queue", "", requests=requests,
                                assign_to=bot,
                                possible_duplicate_of=(
                                    possible.get("ticket_id", "")
                                    if possible else ""))
                else:
                    outcome(number, "queue", "", requests=requests,
                            possible_duplicate_of=(
                                possible.get("ticket_id", "")
                                if possible else ""))
                if preview and preview[-1]["action"] == "queue":
                    from src.integrations.servicenow.duplicates import (
                        business_key)
                    for part in payloads:
                        would_queue.setdefault(business_key(part), number)
                stats["submitted"] += len(payloads)
                continue

            taken = None
            if assign_first:
                # Group mode: the ticket becomes the bot's in ServiceNow
                # BEFORE it is queued (2026-09-30).
                taken = self._take(sys_id, number, fingerprint)
                if taken.get("result") != "taken":
                    stats["not_assigned"] += 1
                    if taken.get("result") == "failed":
                        stats["errors"] += 1
                        stats["error_detail"] = taken.get("error", "")[:300]
                    continue

            outcomes = [self._submit(part) for part in payloads]
            queued = outcomes.count("queued")
            stats["submitted"] += queued
            stats["duplicate"] += outcomes.count("duplicate")
            stats["errors"] += outcomes.count("error")
            if queued:
                if not assign_first:
                    self._claim(sys_id, number)
                self._writeback_on_submit(sys_id, number)
            if "invalid" in outcomes:
                stats["invalid"] += 1
                if self._news(number, f"invalid:{fingerprint}"):
                    # The intake check e-mailed and audited the refusal;
                    # the ticket gets the reason as well (2026-09-28).
                    reason = (f"the request was refused by the intake check "
                              f"({self._last_refusal or 'invalid values'})")
                    if assign_first and not queued:
                        # Assigned for nothing: back to the group.
                        self._release(sys_id, number, reason,
                                      taken.get("state", ""))
                    else:
                        self._reject_on_ticket(sys_id, number, reason)

        self._log("info",
                  f"Poll complete: {stats['submitted']} submitted, "
                  f"{stats['duplicate']} duplicate, {stats['known']} already known, "
                  f"{stats['duplicate_content']} duplicate by content, "
                  f"{stats['skipped']} skipped, "
                  f"{stats['invalid']} invalid, {stats['deferred']} deferred, "
                  f"{stats['errors']} errors")
        return stats

    # ── duplicate handling ─────────────────────────────────────────

    def _reported_before(self, number: str, fingerprint: str) -> bool:
        """Read-only: was this finding already reported (dry run)?"""
        if self.reported is None:
            return False
        try:
            return bool(self.reported.matches(number, fingerprint))
        except Exception:
            return False

    def _news(self, number: str, fingerprint: str) -> bool:
        """True when this finding has not been reported for this ticket
        in its current state (always True without a memory)."""
        if self.reported is None:
            return True
        try:
            return self.reported.first_time(number, fingerprint)
        except Exception:
            return True

    def _call_hook(self, hook, payload, ticket, number):
        if hook is None:
            return None
        try:
            return hook(payload, ticket)
        except Exception as e:      # a lookup fault must not stop the poll
            self._log("warning", f"duplicate lookup failed for {number}: {e}")
            return None

    def _handle_content_duplicate(self, number: str, sys_id: str,
                                  payload: dict, original: dict) -> None:
        orig_ticket = original.get("ticket_id", "") or original.get("request_id", "")
        matched = list(original.get("matched_fields", []) or [])
        superseded = bool(original.get("superseded"))
        reason = (f"{'Superseded by' if superseded else 'Duplicate of'} "
                  f"ticket {orig_ticket} "
                  f"(request {original.get('request_id', '')}, status "
                  f"{original.get('status', '')}): "
                  + (original.get("reason") or
                     "same operation, affiliation code and employee code"))
        self._log("warning", f"Ticket {number} not queued — {reason}")
        details = {
            "ticket_id": number, "sys_id": sys_id, "source": "servicenow",
            "operation": payload.get("operation", ""),
            "affiliation_code": payload.get("affiliation_code", ""),
            "employee_code": payload.get("employee_code", ""),
            "original_ticket_id": orig_ticket,
            "original_request_id": original.get("request_id", ""),
            "original_status": original.get("status", ""),
            # A newer ticket of the OPPOSITE operation holds a superseded
            # one, and the tracking-ID rule is shown by its ticket label
            # (NB-021). Display only — the rule reads matched_fields.
            "matching_fields": (
                "affiliation code, employee code (opposite operation)"
                if superseded else
                ", ".join(_FIELD_LABELS.get(f, f) for f in matched)
                if matched else
                "operation, affiliation code, employee code"),
        }
        self._notify_rejected("DUPLICATE REQUEST", reason, details)
        self._audit("servicenow_duplicate_ticket", details)
        if superseded:
            # The note must say WHY — "duplicate of" would mislead.
            self._reject_on_ticket(sys_id, number, original.get("reason", ""))
            return
        if not self._hand_over(
                sys_id, number,
                f"Not processed by the FINESIII RPA bot: duplicate of "
                f"{orig_ticket}."):
            self._writeback_on_duplicate(sys_id, number, orig_ticket)

    @staticmethod
    def _ref(value) -> str:
        """A reference field's sys_id, only when it is safe in a query."""
        if isinstance(value, dict):
            value = value.get("value", "")
        value = str(value or "").strip()
        return value if value and not any(c in value for c in "^=\n\r ,") else ""

    _USER_FIELDS = ["name", "employee_number", "email", "user_name"]

    def _enrich_people(self, ticket: dict, payloads: list) -> None:
        """Requester (申請者) and user details for the e-mails, looked up
        once per new ticket (2026-09-28): the requester from the request
        record (the person chosen on the e-mail settings page), the user's
        e-mail address from the ticket's Employee ID. A failed lookup is
        logged and leaves the detail out — it never blocks the ticket."""
        meta = payloads[0].get("metadata", {})
        people = {}
        source = (self.s.requester_source or "").strip().lower()
        if source in ("opened_by", "requested_for"):
            try:
                req = self._ref(ticket.get("request"))
                rows = self.client.get_records(
                    "sc_request", f"sys_id={req}", fields=[source],
                    limit=1) if req else []
                uid = self._ref(rows[0].get(source)) if rows else ""
                users = self.client.get_records(
                    "sys_user", f"sys_id={uid}", fields=self._USER_FIELDS,
                    limit=1) if uid else []
                if users:
                    u = users[0]
                    people["requester"] = {
                        "name": str(u.get("name", "") or ""),
                        "employee_number": str(u.get("employee_number", "") or ""),
                        "email": str(u.get("email", "") or "")}
            except Exception as e:
                self._log("warning", f"Requester lookup failed for "
                                     f"{ticket.get('number', '')}: {e}")
        employee_id = str(meta.get("employee_id", "") or "").strip()
        lookup_field = (self.s.user_lookup_field or "").strip()
        if employee_id and self._ref(employee_id) and \
                re.match(r"^[A-Za-z0-9_.]+$", lookup_field or ""):
            try:
                users = self.client.get_records(
                    "sys_user", f"{lookup_field}={employee_id}",
                    fields=self._USER_FIELDS, limit=1)
                if users:
                    people["user_email"] = str(users[0].get("email", "") or "")
                    people["user_display_name"] = str(users[0].get("name", "") or "")
            except Exception as e:
                self._log("warning", f"User lookup failed for "
                                     f"{ticket.get('number', '')}: {e}")
        for part in payloads:
            part.setdefault("metadata", {}).update(
                {k: v for k, v in people.items() if v})

    def _reject_on_ticket(self, sys_id: str, number: str, reason: str) -> None:
        """Tell the ticket why it was not processed (2026-09-28): hand it
        to the configured group with the note, or add the note. With the
        rejection note switched off, the earlier behaviour (hand-over
        only)."""
        if not self.s.reject_note_enabled:
            self._hand_over(sys_id, number,
                            f"Not processed by the FINESIII RPA bot: {reason}.")
            return
        note = render(self.s.reject_note or
                      "Not processed by the FINESIII RPA bot: {reason}. "
                      "Ticket left open for review.",
                      {"reason": reason, "ticket_id": number})
        if self._hand_over(sys_id, number, note) or not sys_id:
            return
        try:
            self.client.add_work_note(sys_id, note)
            self._audit("servicenow_ticket_rejection_noted", {
                "ticket_id": number, "sys_id": sys_id, "reason": reason})
        except ServiceNowError as e:
            self._log("warning", f"Rejection note failed for {number}: {e}")

    def _out_of_selection(self, number, sys_id, why, dry_run, outcome,
                          stats) -> None:
        """A fetched ticket that is not the bot's: no note, no hand-over,
        no assignment, no e-mail - only said once in the log."""
        stats["out_of_selection"] += 1
        outcome(number, "skip", f"not in the selection: {why}")
        if not dry_run and self._news(number, f"out_of_selection:{why}"):
            self._log("warning", f"Ticket {number} skipped — not in the "
                                 f"selection: {why}")
            self._audit("servicenow_ticket_out_of_selection", {
                "ticket_id": number, "sys_id": sys_id, "reason": why})

    def _other_application_reason(self) -> str:
        """The reason given for a ticket of another application ('' when
        no application ID is configured, so every ticket is in scope)."""
        ids = [str(i).strip() for i in (self.s.sp_application_ids or [])
               if str(i).strip()]
        if not ids:
            return ""
        return "it is not for application " + ", ".join(f"[{i}]" for i in ids)

    def _resolve_bot_for_query(self) -> None:
        """A Bot account entered as a user name or display name is looked
        up once per poll, so the query matches it by sys_id. A failed
        lookup leaves the query to the unassigned tickets (group mode)
        and is logged."""
        if not self.s.bot_filter or self.s.bot_ref:
            return
        try:
            self.s.bot_sys_id = self._bot()
        except Exception as e:
            self._log("warning", f"Bot account '{self.s.bot_filter}' could "
                                 f"not be looked up: {e}")
            return
        if not self.s.bot_sys_id:
            self._log("warning", f"Bot account '{self.s.bot_filter}' was "
                                 f"not found in ServiceNow")

    def _with_task_text(self, ticket: dict, variables: list,
                        number: str) -> list:
        """The variables, with the instruction text read from the task's
        own fields when the catalog variable that should hold it is
        empty or cannot be read. The text found is put first, under the
        variable's label, so the checks read it as that variable."""
        names = (self.s.sp_variables or {}).get("text") or []
        if sailpoint_variable(variables, names):
            return variables
        sys_id = self._ref(ticket.get("sys_id", ""))
        fields = [f for f in (self.s.task_text_fields or [])
                  if re.match(r"^[A-Za-z0-9_.]+$", str(f))]
        record = {}
        if sys_id:
            try:
                rows = self.client.get_records(
                    self.s.table, f"sys_id={sys_id}",
                    fields=fields or None, limit=1)
                record = rows[0] if rows else {}
            except ServiceNowError as e:
                self._log("warning", f"Ticket {number}: the task fields "
                                     f"could not be read: {e}")
        field, text = task_text(record, fields)
        readable = sum(1 for v in variables or []
                       if isinstance(v, dict) and str(v.get("value") or "").strip())
        if not text:
            self._log("info", f"Ticket {number}: {len(variables or [])} "
                              f"catalog variable(s), {readable} with a "
                              f"value; no instruction text in the variables "
                              f"or the task fields")
            return variables
        self._log("info", f"Ticket {number}: instruction text read from the "
                          f"task field '{field}' ({len(variables or [])} "
                          f"catalog variable(s), {readable} with a value)")
        label = str(names[0]) if names else "instruction text"
        return [{"name": field, "label": label, "value": text,
                 "source": "task"}] + list(variables or [])

    def _selection_values(self, tickets) -> dict | None:
        """{sys_id: the selection fields} for the fetched tickets, read
        again by sys_id (100 per request) with their display values;
        None when no group or Requested For is set."""
        fields = self.s.selection_fields()
        if not fields:
            return None
        ids = []
        for t in tickets:
            if isinstance(t, dict):
                sid = self._ref(t.get("sys_id", ""))
                if sid and re.match(r"^[0-9a-fA-F]{32}$", sid):
                    ids.append(sid)
        out = {}
        for i in range(0, len(ids), 100):
            chunk = ids[i:i + 100]
            rows = self.client.get_records(
                self.s.table, "sys_idIN" + ",".join(chunk),
                fields=["sys_id"] + fields, limit=len(chunk),
                display_value="all")
            for row in rows:
                out[self._ref(row.get("sys_id", ""))] = row
        return out

    def _bot(self) -> str:
        """The bot account's sys_id, looked up once per connector ('' when
        no user has that name). A failed lookup raises and is retried."""
        if self._bot_sys_id is None:
            self._bot_sys_id = self.client.user_sys_id(
                self.s.effective_assigned_to) \
                if self.s.effective_assigned_to else ""
        return self._bot_sys_id

    def _bot_for_preview(self):
        """(bot sys_id, problem) for the read-only preview: whether the
        tickets could be assigned to the bot account."""
        try:
            bot = self._bot()
        except Exception as e:
            return "", f"the bot account could not be looked up: {e}"[:300]
        if not bot:
            return "", (f"the bot account '{self.s.effective_assigned_to}' "
                        f"was not found in ServiceNow, so the ticket cannot "
                        f"be assigned to it")
        return bot, ""

    _TAKE_FIELDS = ["sys_id", "assigned_to", "state", "active"]

    def _take(self, sys_id: str, number: str, fingerprint: str) -> dict:
        """Group mode (2026-09-30): assign the task to the bot account
        before it is queued. The task is read again first — a person who
        took it since the fetch keeps it — and the saved assignment is
        checked. Returns {"result": "taken" | "busy" | "failed",
        "state": the state before, "error": why it failed}."""
        ident = self.s.effective_assigned_to
        try:
            if not sys_id or not self._ref(sys_id):
                raise ServiceNowError("the ticket has no usable sys_id")
            bot = self._bot()
            if not bot:
                raise ServiceNowError(f"bot account '{ident}' not found in "
                                      f"ServiceNow")
            rows = self.client.get_records(
                self.s.table, f"sys_id={sys_id}", fields=self._TAKE_FIELDS,
                limit=1)
            if not rows:
                return self._not_taken(number, sys_id, fingerprint,
                                       "it is no longer found")
            row = rows[0]
            state = str(row.get("state", "") or "")
            if str(row.get("active", "true")).lower() == "false":
                return self._not_taken(number, sys_id, fingerprint,
                                       "it was closed", state)
            current = self._ref(row.get("assigned_to"))
            if current and current != bot:
                return self._not_taken(number, sys_id, fingerprint,
                                       "a person took it", state)
            claim_state = self.s.claim_state if self.s.claim_on_pickup else ""
            saved = self.client.claim(sys_id, bot, claim_state) or {}
            kept = self._ref(saved.get("assigned_to")) \
                if "assigned_to" in saved else bot
            if kept != bot:
                if claim_state and state and claim_state != state:
                    # Not left in progress with nobody on it.
                    try:
                        self.client.claim(sys_id, "", state)
                    except Exception as e:
                        self._log("warning", f"Ticket {number}: state not "
                                             f"put back: {e}")
                raise ServiceNowError("ServiceNow did not keep the assignment "
                                      "(an instance rule may have changed "
                                      "it)")
        except Exception as e:
            error = (f"Could not assign ticket {number} to the bot "
                     f"account: {e}")
            first = self._news(number, f"claim_failed:{fingerprint}")
            # The first time per ticket an ERROR, so the ServiceNow
            # contacts are e-mailed; later polls a warning (E2E-M11).
            from src.integrations.servicenow.client import explain_error
            self._log("error" if first else "warning",
                      (f"Ticket {number} could not be assigned to the bot "
                       f"account: {explain_error(error) or e}. It waits in "
                       f"the group.") if first else error)
            if first:
                self._audit("servicenow_ticket_claim_failed", {
                    "ticket_id": number, "sys_id": sys_id,
                    "before_queue": True, "error": str(e)[:200]})
            return {"result": "failed", "error": error}
        self._log("info", f"Ticket {number} assigned to the bot account "
                          f"before queueing")
        self._audit("servicenow_ticket_claimed", {
            "ticket_id": number, "sys_id": sys_id, "assigned": True,
            "before_queue": True, "state": claim_state,
            "previous_state": state})
        return {"result": "taken", "state": state}

    def _not_taken(self, number, sys_id, fingerprint, why, state=""):
        """The task changed since the fetch: left alone, not an error."""
        self._log("info", f"Ticket {number} not taken: {why} since the poll "
                          f"read it")
        if self._news(number, f"not_taken:{why}:{fingerprint}"):
            self._audit("servicenow_ticket_not_taken", {
                "ticket_id": number, "sys_id": sys_id, "reason": why})
        return {"result": "busy", "state": state}

    def _release(self, sys_id: str, number: str, reason: str,
                 state: str = "") -> None:
        """Give back a task the bot assigned to itself but could not queue
        (2026-09-30): to the hand-over group when one is set, otherwise
        to the assignment group, unassigned, in its earlier state, with
        the rejection note."""
        note = render(self.s.reject_note or
                      "Not processed by the FINESIII RPA bot: {reason}. "
                      "Ticket left open for review.",
                      {"reason": reason, "ticket_id": number}) \
            if self.s.reject_note_enabled else \
            f"Not processed by the FINESIII RPA bot: {reason}."
        group = (self.s.reject_reassign_group or "").strip() or \
            (self.s.assignment_group or "").strip()
        if not group:
            self._reject_on_ticket(sys_id, number, reason)
            return
        try:
            self.client.reassign(sys_id, group, note, state=state)
        except Exception as e:
            self._log("warning", f"Ticket {number} could not be given back "
                                 f"to '{group}': {e}")
            self._audit("servicenow_ticket_release_failed", {
                "ticket_id": number, "sys_id": sys_id, "group": group,
                "error": str(e)[:200]})
            return
        self._log("info", f"Ticket {number} given back to group '{group}'")
        self._audit("servicenow_ticket_released", {
            "ticket_id": number, "sys_id": sys_id, "group": group,
            "reason": reason})

    def _claim(self, sys_id: str, number: str) -> None:
        """Take a queued task (2026-09-28): assign it to the bot account
        and move it to the claim state, so nobody in the group starts
        on it too. A failure is logged only — the request is queued.
        Bot-account mode; group mode assigns before queueing (_take)."""
        if not self.s.claim_on_pickup or not sys_id:
            return
        try:
            self.client.claim(sys_id, self._bot(), self.s.claim_state)
            self._audit("servicenow_ticket_claimed", {
                "ticket_id": number, "sys_id": sys_id,
                "assigned": bool(self._bot_sys_id),
                "state": self.s.claim_state})
        except Exception as e:
            self._log("warning", f"Ticket {number} could not be claimed: {e}")
            self._audit("servicenow_ticket_claim_failed", {
                "ticket_id": number, "sys_id": sys_id, "error": str(e)[:200]})

    def _hand_over(self, sys_id: str, number: str, note: str) -> bool:
        """Give a rejected ticket to the configured human group so it
        leaves the bot's queue (approved 2026-09-27, off unless a group
        is set). Returns True when the ticket was handed over."""
        group = (self.s.reject_reassign_group or "").strip()
        if not group or not sys_id:
            return False
        try:
            self.client.reassign(sys_id, group, note)
        except Exception as e:
            self._log("warning",
                      f"Ticket {number} could not be handed to '{group}': {e}")
            return False
        self._log("info", f"Ticket {number} handed to group '{group}'")
        self._audit("servicenow_ticket_reassigned", {
            "ticket_id": number, "sys_id": sys_id, "group": group})
        return True

    def _audit(self, event: str, detail: dict) -> None:
        if self.audit_hook is None:
            return
        try:
            self.audit_hook(event, detail)
        except Exception as e:
            self._log("warning", f"Audit hook failed: {e}")

    # ── continuous mode ────────────────────────────────────────────

    def run_forever(self, dry_run: bool = False):
        self._log("info",
                  f"ServiceNow connector started — polling every "
                  f"{self.s.poll_interval_seconds}s (dry_run={dry_run})")
        self._stop = False
        while not self._stop:
            try:
                self.poll_once(dry_run=dry_run)
            except Exception as e:  # never let the loop die
                self._log("error", f"Unexpected poll error: {e}")
            self._sleep_interruptible(self.s.poll_interval_seconds)

    def stop(self):
        self._stop = True

    # ── discovery ──────────────────────────────────────────────────

    def discover(self, limit: int = 2) -> list:
        """Read-only: return a few raw tickets so we can inspect the real schema."""
        return self.client.fetch_raw_sample(limit=limit)

    # ── submission via the service API ─────────────────────────────

    def _submit(self, payload: dict) -> str:
        url = self.s.service_base_url + self.s.submit_path
        headers = {"Content-Type": "application/json"}
        if self.s.service_token:
            # v3 auth reads X-API-Key; the Bearer header is kept for
            # compatibility with the v2-style token auth.
            headers["Authorization"] = f"Bearer {self.s.service_token}"
            headers["X-API-Key"] = self.s.service_token
        try:
            with httpx.Client(timeout=self.s.http_timeout_seconds,
                              verify=self.s.verify_tls) as c:
                resp = c.post(url, json=payload, headers=headers)
        except httpx.RequestError as e:
            self._log("error", f"Submit to RPA service failed (network): {e}")
            return "error"

        if resp.status_code == 202:
            body = resp.json()
            self._log("info",
                      f"Queued {payload['ticket_id']} → request_id={body.get('request_id')} "
                      f"(position {body.get('queue_position')})")
            return "queued"
        if resp.status_code == 409:
            self._log("info", f"Ticket {payload['ticket_id']} already known (idempotent skip)")
            return "duplicate"
        if resp.status_code == 400:
            self._log("warning", f"Ticket {payload['ticket_id']} rejected as invalid: {resp.text[:200]}")
            try:
                self._last_refusal = str(resp.json().get("detail", ""))[:200]
            except Exception:
                self._last_refusal = resp.text[:200]
            return "invalid"
        self._log("error",
                  f"Unexpected {resp.status_code} submitting {payload['ticket_id']}: {resp.text[:200]}")
        return "error"

    def _service_healthy(self) -> bool:
        url = self.s.service_base_url + self.s.health_path
        try:
            with httpx.Client(timeout=self.s.http_timeout_seconds,
                              verify=self.s.verify_tls) as c:
                resp = c.get(url)
            return resp.status_code == 200
        except httpx.RequestError:
            return False

    def _notify_rejected(self, rejection_type: str, reason: str, details: dict):
        if self.on_rejected is None:
            return
        try:
            self.on_rejected(rejection_type, reason, details)
        except Exception as e:   # alerting must never break the poll loop
            self._log("warning", f"Rejection hook failed: {e}")

    # ── write-back (OFF by default) ────────────────────────────────

    def _writeback_on_submit(self, sys_id: str, number: str):
        if not self.s.writeback_enabled or not sys_id:
            return
        tmpl = (self.s.writeback.get("on_submit", {}) or {}).get("add_work_note")
        if not tmpl:
            return
        try:
            self.client.add_work_note(sys_id, tmpl.format(ticket_id=number))
        except ServiceNowError as e:
            self._log("warning", f"Write-back note failed for {number}: {e}")

    def _writeback_on_duplicate(self, sys_id: str, number: str,
                                original_ticket: str):
        # A duplicate is a rejection: the note is written with either
        # switch on (2026-09-28).
        if not (self.s.writeback_enabled or self.s.reject_note_enabled) \
                or not sys_id:
            return
        tmpl = (self.s.writeback.get("on_duplicate", {}) or {}).get("add_work_note")
        if not tmpl:
            return
        try:
            self.client.add_work_note(
                sys_id, tmpl.format(ticket_id=number,
                                    original_ticket_id=original_ticket))
        except ServiceNowError as e:
            self._log("warning", f"Duplicate note failed for {number}: {e}")

    # ── helpers ────────────────────────────────────────────────────

    def _safe(self, payload: dict) -> dict:
        d = dict(payload)
        if d.get("password"):
            d["password"] = "****"
        return d

    def _sleep_interruptible(self, seconds: float):
        end = seconds
        step = 0.5
        while end > 0 and not self._stop:
            time.sleep(min(step, end))
            end -= step

    def _log(self, level: str, msg: str):
        if self.logger and hasattr(self.logger, level):
            getattr(self.logger, level)(msg)


def _format_problems(payload: dict) -> list:
    """The intake API's format check on one request, for the read-only
    preview (the same rules the intake applies when it is submitted)."""
    try:
        from src.modules.intake.schemas import (
            SubmitRequest, validate_request_format,
        )
        body = SubmitRequest(**{k: v for k, v in payload.items()
                                if k in SubmitRequest.model_fields})
        return validate_request_format(body)
    except Exception as e:
        return [f"not a valid request ({e})"]
