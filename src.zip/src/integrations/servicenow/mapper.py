"""
Ticket → request mapper.

Translates a raw ServiceNow ticket dict into the JSON payload accepted by
the service API (POST /api/v1/requests), using a config-driven field
mapping. Pure functions only — no network, no side effects — so the
business-critical mapping logic is fully unit-tested.

The field mapping (config/servicenow.yaml `field_mapping`) maps a request
field to a ServiceNow field PATH. Paths support dotted lookups for nested
structures (e.g. catalog variables: "variables.affiliation_code"); if the
nested lookup misses, the literal dotted key is also tried as a flat key.

NOTE: the default field paths are PLACEHOLDERS. The real schema is confirmed
via `scripts/run_servicenow_connector.py --discover` before go-live.
"""

import re
import secrets
import string
from typing import Callable, Optional

VALID_OPERATIONS = ("provision", "deprovision")

# Ticket keys whose VALUES must never leave the connector in clear text.
# Anything matching these markers is masked before the ticket is attached
# to the request metadata (client requirement: carry ALL ticket details —
# but secrets are carried in the dedicated `password` field, never in
# free-form metadata).
_SECRET_KEY_MARKERS = ("password", "passwd", "pwd", "secret", "token", "api_key")

# A password typed INTO free text ("Password: Abcd1234", "パスワード：…")
# is masked as well (2026-09-28). The request's own password is read from
# the raw ticket before anything is masked. Also without a colon
# (NB-022): "Password - X", "Password- X", "Password -X", "password is X"
# and a full-width space ("パスワード　X"). A hyphenated word
# ("password-protected") or a list on the next line is not a value.
_INLINE_SECRET_RE = re.compile(
    r"((?:\b(?:password|passwd|pwd)\b|パスワード)"
    r"(?:\s*[:=：]|[ \t　]+[-‐–—－]|[-‐–—－][ \t　]|[ \t　]+is\b|　)\s*)"
    r"(\S+)",
    re.IGNORECASE)


def mask_inline_secrets(text: str) -> str:
    """The text with every 'password: value' value replaced by ****."""
    if not isinstance(text, str) or not text:
        return text
    return _INLINE_SECRET_RE.sub(lambda m: m.group(1) + "****", text)


def _redact_ticket(obj):
    """Recursively mask secret-looking values in a raw ticket structure.
    Returns a new structure; the input is never mutated."""
    if isinstance(obj, dict):
        return {
            k: ("****" if any(m in str(k).lower() for m in _SECRET_KEY_MARKERS)
                and isinstance(v, (str, int, float)) and v not in ("", None)
                else _redact_ticket(v))
            for k, v in obj.items()
        }
    if isinstance(obj, list):
        return [_redact_ticket(v) for v in obj]
    if isinstance(obj, str):
        return mask_inline_secrets(obj)
    return obj


# ── Description parsing (opt-in) ────────────────────────────────
# Tickets on instances without custom u_* fields carry the request data as
# "Label: value" lines inside a free-text field (normally `description`).
# When `description_parsing.enabled` is true, those lines are extracted into
# ticket["parsed"] BEFORE mapping, so the existing dotted-path field mapping
# ("parsed.affiliation_code") resolves them with no special cases.

# Default label variants per request field — all matching is case-insensitive
# on the text left of the first ":" (half- or full-width, for Japanese tickets).
DEFAULT_DESCRIPTION_LABELS = {
    "operation": ["operation", "request type"],
    "affiliation_code": ["affiliation code"],
    "employee_code": ["ffm application id", "ffm id", "employee code"],
    "user_email": ["user email", "requester email", "email"],
    "user_name": ["user name", "requested for"],
}

_LABEL_SPLIT_RE = re.compile(r"[:：]")


def _normalize_label(label: str) -> str:
    return " ".join(str(label).lower().split())


def parse_description(text: str, labels: Optional[dict] = None) -> dict:
    """Extract 'Label: value' lines from free text into {request_field: value}.

    The first matching line wins per field; unrecognized lines are ignored.
    Pure function — safe to unit-test exhaustively.
    """
    if not text:
        return {}
    label_map = {}
    for req_field, variants in (labels or DEFAULT_DESCRIPTION_LABELS).items():
        for v in (variants if isinstance(variants, (list, tuple)) else [variants]):
            label_map[_normalize_label(v)] = req_field

    parsed: dict = {}
    for line in str(text).splitlines():
        parts = _LABEL_SPLIT_RE.split(line, maxsplit=1)
        if len(parts) != 2:
            continue
        req_field = label_map.get(_normalize_label(parts[0]))
        value = parts[1].strip()
        if req_field and value and req_field not in parsed:
            parsed[req_field] = value
    return parsed


def enrich_ticket(ticket: dict, description_parsing: Optional[dict] = None) -> dict:
    """Return the ticket with a `parsed` key added from its description text.

    No-op (returns the ticket unchanged) unless description_parsing.enabled
    is true — the default — so existing structured-field mapping behavior is
    byte-identical when the feature is off.
    """
    cfg = description_parsing or {}
    if not cfg.get("enabled", False) or not isinstance(ticket, dict):
        return ticket
    source_field = cfg.get("source_field", "description")
    text = _lookup(ticket, source_field) or ""
    enriched = dict(ticket)
    enriched["parsed"] = parse_description(text, cfg.get("labels") or None)
    return enriched


# ── Initial password generation (opt-in) ────────────────────────
# Client decision: passwords are NEVER carried in ticket descriptions. For
# provisioning, the bot generates a random per-user password. FINESIII
# rules (field-mapper FID 003 validation): exactly 8 characters, FIRST
# character must be a LETTER. Uppercase letters + digits keep it safe for
# the terminal's field entry.

_PASSWORD_ALPHABET = string.ascii_uppercase + string.digits
PASSWORD_LENGTH = 8


def generate_initial_password() -> str:
    """Cryptographically random 8-char password: first char a letter
    (FINESIII FID 003 rule), ≥1 digit, uppercase letters + digits only."""
    while True:
        pw = secrets.choice(string.ascii_uppercase) + "".join(
            secrets.choice(_PASSWORD_ALPHABET)
            for _ in range(PASSWORD_LENGTH - 1))
        if any(c.isdigit() for c in pw):
            return pw


def _lookup(ticket: dict, path: str):
    """Resolve a (possibly dotted) field path against a ticket dict.

    ServiceNow may return a field as a scalar, or as a {'value','display_value'}
    object when display values are requested — both are handled.
    """
    if not path:
        return None

    # 1) Try nested traversal: "variables.affiliation_code"
    cur = ticket
    ok = True
    for part in path.split("."):
        if isinstance(cur, dict) and part in cur:
            cur = cur[part]
        else:
            ok = False
            break
    if not ok:
        # 2) Fall back to the literal key (ServiceNow flat field like "u_operation")
        cur = ticket.get(path) if isinstance(ticket, dict) else None

    # Unwrap ServiceNow reference/display objects
    if isinstance(cur, dict):
        cur = cur.get("value", cur.get("display_value"))

    if cur is None:
        return None
    return cur.strip() if isinstance(cur, str) else cur


def _normalize_operation(raw, words: Optional[dict] = None) -> str:
    """Map a ticket's operation field to 'provision'/'deprovision' (or '').

    `words` (the console's operation word lists, 2026-09-28) extends the
    built-in synonyms; certification words always mean a removal."""
    if not raw:
        return ""
    v = str(raw).strip().lower()
    if v in VALID_OPERATIONS:
        return v
    # Common synonyms — tolerant but explicit
    if v in ("create", "add", "new", "provisioning"):
        return "provision"
    if v in ("delete", "remove", "deprovisioning", "disable", "terminate",
             "termination"):
        return "deprovision"
    for key, operation in (("provision", "provision"),
                           ("deprovision", "deprovision"),
                           ("certification", "deprovision")):
        if v in {str(w).strip().lower() for w in (words or {}).get(key, [])}:
            return operation
    return ""


def map_ticket(ticket: dict, field_mapping: dict,
               password_generator: Optional[Callable[[], str]] = None,
               words: Optional[dict] = None) -> Optional[dict]:
    """Map a raw ServiceNow ticket to a SubmitRequest payload.

    Returns None (caller logs + skips) if the ticket is missing the data
    required to act — this is a safe, non-crashing outcome.

    When `password_generator` is provided (opt-in via `generate_password`),
    a provision request whose ticket carries no password gets a random
    per-user password from it. Passwords never come from ticket text in
    this mode — client security decision.
    """
    operation = _normalize_operation(
        _lookup(ticket, field_mapping.get("operation", "")), words)
    affiliation = _lookup(ticket, field_mapping.get("affiliation_code", ""))
    employee = _lookup(ticket, field_mapping.get("employee_code", ""))
    number = _lookup(ticket, field_mapping.get("ticket_number", "")) or ""
    password = _lookup(ticket, field_mapping.get("password", "")) or ""
    # Optional: the requester's email (Step 11 account-created notification).
    user_email = _lookup(ticket, field_mapping.get("user_email", "")) or ""

    affiliation = str(affiliation).strip() if affiliation is not None else ""
    employee = str(employee).strip() if employee is not None else ""

    if operation not in VALID_OPERATIONS or not affiliation or not employee:
        return None

    # Normalize affiliation to 5 digits (matches existing CLI batch behavior)
    if affiliation.isdigit() and len(affiliation) < 5:
        affiliation = affiliation.zfill(5)

    password = str(password).strip() if password else ""
    if not password and operation == "provision" and password_generator:
        password = password_generator()

    # Safety net: if a password DID arrive via parsed description text, the
    # raw description inside metadata would leak it — mask it there. (The
    # `parsed` dict itself is masked by _redact_ticket via its key name.)
    metadata_ticket = ticket
    parsed_pw = (ticket.get("parsed") or {}).get("password") \
        if isinstance(ticket.get("parsed"), dict) else None
    if parsed_pw:
        def _mask_pw(obj):
            if isinstance(obj, str):
                return obj.replace(parsed_pw, "****")
            if isinstance(obj, dict):
                return {k: _mask_pw(v) for k, v in obj.items()}
            if isinstance(obj, list):
                return [_mask_pw(v) for v in obj]
            return obj
        metadata_ticket = _mask_pw(ticket)

    payload = {
        "operation": operation,
        "affiliation_code": affiliation,
        "employee_code": employee,
        "password": password,
        "source": "servicenow",
        "ticket_id": str(number).strip(),
        # Client requirement: no detail from the SNOW request may be lost.
        # The FULL raw ticket (secrets masked) travels with the bot request
        # and is persisted alongside it in the queue.
        "metadata": {"snow_details": _redact_ticket(metadata_ticket)},
    }
    if user_email:
        # Top-level for easy access by the user-notification path (Step 11).
        payload["metadata"]["user_email"] = str(user_email).strip()
    return payload


def reasons_skipped(ticket: dict, field_mapping: dict) -> str:
    """Human-readable explanation of why a ticket could not be mapped (for logs)."""
    missing = []
    if _normalize_operation(_lookup(ticket, field_mapping.get("operation", ""))) \
            not in VALID_OPERATIONS:
        missing.append("operation (not provision/deprovision)")
    if not _lookup(ticket, field_mapping.get("affiliation_code", "")):
        missing.append("affiliation_code")
    if not _lookup(ticket, field_mapping.get("employee_code", "")):
        missing.append("employee_code")
    return ", ".join(missing) if missing else "(mappable)"
