"""ServiceNow REST connector for the FINESIII RPA platform.

Pulls open tickets assigned to the bot's service account from ServiceNow
(Table API) and submits them to the v3 service via its public REST API
(POST /api/v1/requests). The queue → dispatcher → single-worker engine
then processes them one after another, unchanged.

Design principles:
  - Zero changes to existing files (decoupled sidecar process).
  - Reuses the existing idempotency (HTTP 409 on duplicate ticket_id),
    FIFO queue, conflict guard, availability window, and audit trail.
  - Secrets come from environment variables (mirrors FINESIII_* pattern).
  - Safe by default: dry-run supported, ticket write-back OFF by default.

Public entry points (import from the submodules, as in v2):
  - src.integrations.servicenow.config:    ServiceNowSettings, load_servicenow_config
  - src.integrations.servicenow.client:    ServiceNowClient, ServiceNowError
  - src.integrations.servicenow.mapper:    map_ticket, enrich_ticket,
                                           reasons_skipped, generate_initial_password
  - src.integrations.servicenow.connector: ServiceNowConnector
"""
