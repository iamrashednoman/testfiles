"""
ServiceNow Table API REST client.

Implements only what the connector needs, following the current ServiceNow
REST API guidance (Zurich/2026 docs):

  GET  /api/now/table/{table}   — fetch records
        sysparm_query           — encoded filter
        sysparm_fields          — return only mapped columns (perf + least-data)
        sysparm_limit           — page size (ALWAYS sent explicitly; default varies)
        sysparm_offset          — offset paging, bounded by max_per_poll
        sysparm_display_value   — raw values by default for deterministic matching
  PATCH /api/now/table/{table}/{sys_id} — write-back (work notes / state)

Authentication (2026-09-26):
  - basic                     — Authorization: Basic, sent by httpx via
                                auth=(user, password).
  - oauth_password            — POST <instance>/oauth_token.do with
                                grant_type=password (client id/secret +
                                the bot account). Token cached, refreshed
                                with the refresh token before it expires,
                                re-obtained once when the API answers 401.
  - oauth_client_credentials  — same endpoint, grant_type=client_credentials
                                (Washington DC or later, grant enabled on
                                the instance, application user mapped).

Resilience:
  - HTTP 429 → honor Retry-After header, then exponential backoff.
  - 5xx → exponential backoff. 4xx (non-429) → raise immediately.
  - TLS verification on, explicit timeout.

The HTTP transport and sleep function are injectable so the client is fully
unit-testable without network access.
"""

import re
import time
from typing import Callable, List, Optional

import httpx

from src.integrations.servicenow.config import ServiceNowSettings


class ServiceNowError(Exception):
    """Raised on an unrecoverable ServiceNow API error."""


# An HTTP status as the client reports it ("failed: 401 …", "(429)").
_STATUS_RE = re.compile(r"(?:^|[\s(])([45]\d\d)(?!\d)")


def explain_error(text) -> str:
    """Why a ServiceNow call failed, in plain words for the System page
    and the outage e-mail ('' when the text is not recognised). The raw
    error text stays in the log (2026-09-28)."""
    low = " ".join(str(text or "").lower().split())
    if not low:
        return ""
    m = _STATUS_RE.search(low)
    status = m.group(1) if m else ""
    # Group mode: the bot assigns each ticket to itself before queueing
    # (2026-09-30).
    if "bot account" in low and "not found" in low:
        return ("the bot account was not found in ServiceNow — check the "
                "Bot account setting (sys_id or user name)")
    if "could not assign" in low and (status or "did not keep" in low):
        return ("the bot could not assign tickets to itself"
                + (f" (HTTP {status})" if status else "")
                + " — check the bot account's role and its membership of "
                  "the assignment group")
    if "oauth token" in low and "network" in low:
        return ("not reachable — the OAuth token address could not be "
                "reached from this machine (check the instance URL, the "
                "token URL and the proxy)")
    if "oauth token" in low:
        return ("sign-in rejected — ServiceNow refused the OAuth token "
                "(check the client ID and secret, the grant type and the "
                "bot account)")
    if status in ("401", "403"):
        return (f"sign-in rejected — ServiceNow refused the bot account's "
                f"credentials (HTTP {status})")
    if "sign-in page" in low or "text/html" in low:
        return ("answered with a sign-in page — check the instance URL and "
                "whether single sign-on blocks API access for the bot "
                "account")
    if status == "404" or (status == "400" and "invalid table" in low):
        return "table not found — check the ticket table setting"
    if status == "429" or "rate limited" in low:
        return "rate limited — ServiceNow asked the bot to slow down"
    if "server error" in low or status.startswith("5"):
        return "server error — ServiceNow answered with an internal error"
    if any(w in low for w in ("network error", "timed out", "timeout",
                              "connecterror", "connection refused",
                              "name or service", "getaddrinfo",
                              "nodename", "unreachable")):
        return ("not reachable — the instance could not be reached from "
                "this machine (check the URL and the proxy)")
    return ""


class ServiceNowClient:
    """Minimal, resilient client for the ServiceNow Table API."""

    def __init__(self, settings: ServiceNowSettings, logger=None,
                 transport: Optional[httpx.BaseTransport] = None,
                 sleep_func: Callable[[float], None] = time.sleep):
        self.s = settings
        self.logger = logger
        self._transport = transport          # injected in tests (httpx.MockTransport)
        self._sleep = sleep_func
        self._clock = time.time
        # OAuth state (unused for basic): access token, its expiry and
        # the refresh token from the last grant.
        self._bearer_token = ""
        self._token_expires_at = 0.0
        self._refresh_token = ""

    # ── HTTP plumbing ──────────────────────────────────────────────

    def _new_client(self) -> httpx.Client:
        kwargs = dict(
            base_url=self.s.instance_url,
            timeout=httpx.Timeout(self.s.http_timeout_seconds),
            verify=self.s.verify_tls,
            headers={"Accept": "application/json"},
        )
        if self._transport is not None:
            kwargs["transport"] = self._transport
        if self.s.auth_method == "basic":
            kwargs["auth"] = (self.s.username, self.s.password)
        elif self.s.uses_oauth and self._bearer_token:
            kwargs["headers"]["Authorization"] = f"Bearer {self._bearer_token}"
        return httpx.Client(**kwargs)

    # ── OAuth ──────────────────────────────────────────────────────

    TOKEN_EXPIRY_MARGIN = 60.0          # refresh this many seconds early

    def _token_valid(self) -> bool:
        return bool(self._bearer_token) and \
            self._clock() < self._token_expires_at - self.TOKEN_EXPIRY_MARGIN

    def _ensure_token(self, force: bool = False) -> None:
        """Make sure a usable bearer token is cached (OAuth only)."""
        if not self.s.uses_oauth:
            return
        if self._token_valid() and not force:
            return
        if self._refresh_token:
            try:
                self._grant({"grant_type": "refresh_token",
                             "refresh_token": self._refresh_token})
                return
            except ServiceNowError as e:
                if self.logger:
                    self.logger.warning(
                        f"ServiceNow token refresh failed ({e}); "
                        "requesting a new token")
                self._refresh_token = ""
        grant = self.s.oauth_grant
        form = {"grant_type": grant}
        if grant == "password":
            form["username"] = self.s.username
            form["password"] = self.s.password
        self._grant(form)

    def _grant(self, form: dict) -> None:
        """One token request. Client id/secret go in the form body, which
        ServiceNow accepts for every grant type."""
        body = dict(form)
        body["client_id"] = self.s.client_id
        body["client_secret"] = self.s.client_secret
        kwargs = dict(timeout=httpx.Timeout(self.s.http_timeout_seconds),
                      verify=self.s.verify_tls,
                      headers={"Accept": "application/json"})
        if self._transport is not None:
            kwargs["transport"] = self._transport
        try:
            with httpx.Client(**kwargs) as client:
                resp = client.post(self.s.effective_token_url, data=body)
        except httpx.RequestError as e:
            raise ServiceNowError(f"OAuth token request failed (network): {e}")
        if resp.status_code != 200:
            raise ServiceNowError(
                f"OAuth token request failed: {resp.status_code} "
                f"{resp.text[:200]}")
        try:
            data = resp.json()
        except ValueError:
            raise ServiceNowError("OAuth token response is not JSON")
        token = str(data.get("access_token") or "")
        if not token:
            raise ServiceNowError(
                f"OAuth token response has no access_token: "
                f"{str(data)[:200]}")
        self._bearer_token = token
        try:
            lifetime = float(data.get("expires_in") or 1800)
        except (TypeError, ValueError):
            lifetime = 1800.0
        self._token_expires_at = self._clock() + lifetime
        self._refresh_token = str(data.get("refresh_token") or "")
        if self.logger:
            self.logger.info(
                f"ServiceNow OAuth token obtained ({form.get('grant_type')}), "
                f"valid {int(lifetime)}s")

    def invalidate_token(self) -> None:
        self._bearer_token = ""
        self._token_expires_at = 0.0

    def _request(self, method: str, url: str, **kwargs) -> httpx.Response:
        """Execute a request with 429/5xx retry + backoff. Raises on 4xx/exhaustion."""
        attempt = 0
        reauthed = False
        while True:
            attempt += 1
            self._ensure_token()
            with self._new_client() as client:
                try:
                    resp = client.request(method, url, **kwargs)
                except httpx.RequestError as e:
                    if attempt > self.s.max_retries:
                        raise ServiceNowError(f"Network error after {attempt} attempts: {e}")
                    self._backoff(attempt, reason=f"network error: {e}")
                    continue

            if resp.status_code == 401 and self.s.uses_oauth and not reauthed:
                # Token revoked or expired server-side: one fresh grant,
                # then the normal 4xx handling applies.
                reauthed = True
                if self.logger:
                    self.logger.warning(
                        "ServiceNow answered 401 with a bearer token — "
                        "requesting a new one")
                self.invalidate_token()
                self._ensure_token(force=True)
                attempt -= 1
                continue

            if resp.status_code == 429:
                if attempt > self.s.max_retries:
                    raise ServiceNowError("Rate limited (429): retries exhausted")
                self._backoff(attempt, retry_after=resp.headers.get("Retry-After"),
                              reason="429 rate limited")
                continue

            if 500 <= resp.status_code < 600:
                if attempt > self.s.max_retries:
                    raise ServiceNowError(
                        f"Server error {resp.status_code}: retries exhausted"
                    )
                self._backoff(attempt, reason=f"{resp.status_code} server error")
                continue

            if resp.status_code >= 400:
                raise ServiceNowError(
                    f"{method} {url} failed: {resp.status_code} {resp.text[:300]}"
                )
            return resp

    def _result(self, resp: httpx.Response, empty):
        """The "result" of a Table API answer. Anything that is not the
        expected JSON — typically a single sign-on login page returned
        with status 200 — becomes a clear ServiceNowError instead of a
        parsing error (2026-09-28)."""
        kind = resp.headers.get("content-type", "")
        try:
            data = resp.json()
        except ValueError:
            data = None
        if not isinstance(data, dict):
            hint = (" — it looks like a sign-in page: check the instance "
                    "URL and whether single sign-on blocks API access "
                    "for the bot account") if "html" in kind.lower() else ""
            raise ServiceNowError(
                f"ServiceNow answered {resp.request.method} "
                f"{resp.request.url.path} with something other than data "
                f"(HTTP {resp.status_code}, {kind or 'no content type'})"
                + hint)
        result = data.get("result", empty)
        return result if result is not None else empty

    # Absolute hard ceiling for a server-supplied Retry-After, so a huge value
    # can't hang the connector indefinitely (5 minutes is generous for ITSM).
    RETRY_AFTER_CEILING = 300.0

    def _backoff(self, attempt: int, retry_after: Optional[str] = None,
                 reason: str = ""):
        """Sleep before retrying.

        ServiceNow's Retry-After is AUTHORITATIVE on a 429 — honor it directly
        (only clamped by an absolute safety ceiling), since retrying earlier
        would just be rate-limited again. Without it, use exponential backoff
        capped by backoff_max_seconds.
        """
        server_delay = None
        if retry_after:
            try:
                server_delay = float(retry_after)
            except (TypeError, ValueError):
                server_delay = None

        if server_delay is not None:
            delay = min(server_delay, self.RETRY_AFTER_CEILING)
        else:
            exp = self.s.backoff_base_seconds * (2 ** (attempt - 1))
            delay = min(exp, self.s.backoff_max_seconds)

        if self.logger:
            self.logger.warning(
                f"ServiceNow {reason} — backing off {delay:.1f}s (attempt {attempt})"
            )
        self._sleep(delay)

    # ── Public API ─────────────────────────────────────────────────

    PAGE_SIZE = 200

    def fetch_assigned_open(self) -> List[dict]:
        """Fetch EVERY open ticket assigned to the bot, oldest first.

        Reads all pages up to `fetch_ceiling` rows (2026-09-26). It used
        to stop at max_per_poll rows, so once that many already-processed
        tickets stayed open at the head of the list, newer tickets were
        never seen. The connector now applies max_per_poll to the number
        of NEW submissions instead."""
        query = self.s.build_query()
        ceiling = max(1, int(self.s.fetch_ceiling or 1000))
        page_size = min(self.PAGE_SIZE, ceiling)
        collected: List[dict] = []
        offset = 0

        while len(collected) < ceiling:
            params = {
                "sysparm_query": query,
                "sysparm_limit": page_size,
                "sysparm_offset": offset,
                "sysparm_display_value": self.s.display_value,
                "sysparm_exclude_reference_link": "true",
                "sysparm_no_count": "true",
            }
            if self.s.fields:
                params["sysparm_fields"] = ",".join(self.s.fields)

            resp = self._request("GET", f"/api/now/table/{self.s.table}", params=params)
            page = self._result(resp, [])
            if not page:
                break
            collected.extend(page)

            if len(page) < page_size:
                break                        # last page
            offset += page_size

        if len(collected) >= ceiling and self.logger:
            self.logger.warning(
                f"ServiceNow returned {ceiling}+ open tickets for the bot; "
                "only the oldest are read this poll (fetch_ceiling)")
        return collected[:ceiling]

    def fetch_raw_sample(self, limit: int = 2) -> List[dict]:
        """Discovery helper: fetch a few tickets with ALL fields + display values,
        so we can inspect the real schema before finalizing the field mapping."""
        params = {
            "sysparm_query": self.s.build_query(),
            "sysparm_limit": limit,
            "sysparm_display_value": "all",
        }
        resp = self._request("GET", f"/api/now/table/{self.s.table}", params=params)
        return self._result(resp, [])

    def get_records(self, table: str, query: str = "",
                    fields: Optional[List[str]] = None,
                    limit: int = 10,
                    display_value: str = "false") -> List[dict]:
        """Generic fetch from any table (e.g. sys_user lookups, test tooling).

        Uses the same auth/retry plumbing as fetch_assigned_open but takes
        the table and query explicitly instead of the configured defaults.
        display_value: "false" (stored values), "true" (shown values) or
        "all" (each field as {"value", "display_value"}).
        """
        params = {
            "sysparm_query": query,
            "sysparm_limit": limit,
            "sysparm_display_value": display_value
            if display_value in ("true", "false", "all") else "false",
            "sysparm_exclude_reference_link": "true",
        }
        if fields:
            params["sysparm_fields"] = ",".join(fields)
        resp = self._request("GET", f"/api/now/table/{table}", params=params)
        return self._result(resp, [])

    COUNT_FALLBACK_LIMIT = 1000

    def count_records(self, table: str, query: str = "") -> int:
        """How many records match (Test connection, S-02, 2026-10-04):
        ServiceNow's X-Total-Count header of a one-row read. Without the
        header, the matching rows are counted up to COUNT_FALLBACK_LIMIT."""
        params = {"sysparm_query": query, "sysparm_limit": 1,
                  "sysparm_fields": "sys_id"}
        resp = self._request("GET", f"/api/now/table/{table}", params=params)
        self._result(resp, [])
        total = str(resp.headers.get("X-Total-Count", "") or "").strip()
        if total.isdigit():
            return int(total)
        return len(self.get_records(table, query, fields=["sys_id"],
                                    limit=self.COUNT_FALLBACK_LIMIT))

    def create_record(self, table: str, payload: dict) -> dict:
        """Create a record in any table (test-ticket seeding). Returns the
        created record as ServiceNow echoes it back."""
        resp = self._request(
            "POST", f"/api/now/table/{table}",
            json=payload, headers={"Content-Type": "application/json"},
        )
        return self._result(resp, {})

    # Standard catalog variable tables: one row per variable of a
    # requested item, with the variable's name, its label (question
    # text) and the stored value (2026-09-28, SailPoint tasks).
    VARIABLE_TABLE = "sc_item_option_mtom"
    _VAR_NAME = "sc_item_option.item_option_new.name"
    _VAR_LABEL = "sc_item_option.item_option_new.question_text"
    _VAR_VALUE = "sc_item_option.value"

    def fetch_variables(self, ticket: dict) -> List[dict]:
        """Catalog variables of the task's requested item as
        [{"name", "label", "value"}]. [] when the task has no requested
        item. Raises ServiceNowError when the read fails."""
        ritm = ticket.get("request_item", "") if isinstance(ticket, dict) else ""
        if isinstance(ritm, dict):
            ritm = ritm.get("value", "")
        ritm = str(ritm or "").strip()
        if not ritm or any(c in ritm for c in "^=\n\r ,"):
            return []
        rows = self.get_records(
            self.VARIABLE_TABLE, f"request_item={ritm}",
            fields=[self._VAR_NAME, self._VAR_LABEL, self._VAR_VALUE],
            limit=200)
        return [{"name": str(r.get(self._VAR_NAME, "") or ""),
                 "label": str(r.get(self._VAR_LABEL, "") or ""),
                 "value": r.get(self._VAR_VALUE, "")} for r in rows]

    def user_sys_id(self, user_name: str) -> str:
        """sys_id of a user by user name, else by display name when
        exactly one user has it ('' when not found). A value that
        already is a sys_id is returned as it is."""
        import re
        value = str(user_name or "").strip()
        if re.match(r"^[0-9a-fA-F]{32}$", value):
            return value
        if not value or any(c in value for c in "^=\n\r"):
            return ""
        rows = self.get_records("sys_user", f"user_name={value}",
                                fields=["sys_id"], limit=1)
        if not rows:
            # The name as shown on a form; two users with the same name
            # cannot be told apart, so neither is used.
            rows = self.get_records("sys_user", f"name={value}",
                                    fields=["sys_id"], limit=2)
            if len(rows) != 1:
                return ""
        return str(rows[0].get("sys_id", ""))

    def claim(self, sys_id: str, user_sys_id: str = "", state: str = "",
              table: str = "") -> dict:
        """Take a task: assign it to the bot account and/or move it to
        the given state (e.g. 2 = Work in Progress). Returns the task as
        ServiceNow saved it ({} when nothing was sent), so the caller can
        check the assignment was kept (2026-09-30)."""
        body = {}
        if user_sys_id:
            body["assigned_to"] = user_sys_id
        if state:
            body["state"] = str(state)
        if not body:
            return {}
        resp = self._request(
            "PATCH", f"/api/now/table/{table or self.s.table}/{sys_id}",
            json=body, params={"sysparm_exclude_reference_link": "true"},
            headers={"Content-Type": "application/json"},
        )
        try:
            record = self._result(resp, {})
        except ServiceNowError:
            return {}
        return record if isinstance(record, dict) else {}

    def add_work_note(self, sys_id: str, note: str, table: str = "") -> None:
        """Append a work note to a ticket (write-back; only called when enabled)."""
        self._request(
            "PATCH", f"/api/now/table/{table or self.s.table}/{sys_id}",
            json={"work_notes": note},
            headers={"Content-Type": "application/json"},
        )

    def reassign(self, sys_id: str, group: str, note: str = "",
                 table: str = "", state: str = "") -> None:
        """Hand a ticket to an assignment group and clear the assignee.
        `group` is a sys_id or a group NAME (then sent as a display
        value, which the Table API resolves). `state` puts the ticket
        back in that state (a release after the bot took it)."""
        import re
        body = {"assignment_group": group, "assigned_to": ""}
        if note:
            body["work_notes"] = note
        if state:
            body["state"] = str(state)
        params = {}
        if not re.match(r"^[0-9a-fA-F]{32}$", str(group)):
            params["sysparm_input_display_value"] = "true"
        self._request(
            "PATCH", f"/api/now/table/{table or self.s.table}/{sys_id}",
            json=body, params=params,
            headers={"Content-Type": "application/json"},
        )

    def set_state(self, sys_id: str, state: str, note: Optional[str] = None,
                  table: str = "", extra: Optional[dict] = None) -> None:
        """Update a ticket's state (write-back; only called when enabled).
        `note` goes to work_notes AND close_notes so a closing comment is
        visible in both places; `extra` adds fields (e.g. close_code)."""
        body = {"state": str(state)}
        if note:
            body["work_notes"] = note
            body["close_notes"] = note
        if extra:
            body.update(extra)
        self._request(
            "PATCH", f"/api/now/table/{table or self.s.table}/{sys_id}",
            json=body, headers={"Content-Type": "application/json"},
        )
