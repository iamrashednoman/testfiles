"""SailPoint catalog task → request(s) (2026-09-28).

SailPoint raises every FINES III access change as an "IAM Access Request"
catalog task (SCTASK) whose instruction text and account live in the
requested item's CATALOG VARIABLES. Two text formats occur:

  Access format (the "Description / Work notes" variable)
      Access Request ID in myAIGaccess for tracking purpose is: 0000537401
      Please provision/deprovision the below attributes for account: 4821KQT
      AttributeName=所属コード; Value=01634 | コンタクトセンター部スタッフ; Operation=Add
      (several entitlements: further AttributeName=…; Value=…; Operation=…
       groups, on the same line separated by ";" or on further lines)

  Certification format
      Request Type: Certification: (Identity Access Review for …)
      … please revoke the below user entitlements …
      01634 | コンタクトセンター部スタッフ Revoker: Reviewer, Sample
      (one line — or ";"-separated item — per entitlement; the account
       comes from the Account Name variable)

Six request types (process design, 2026-09-28):

  new_account                 register (the only type that adds)
  access_removal              remove the requested code(s)
  entitlement_certification   remove the requested codes
  account_certification       remove every code listed on the ticket
  transfer                    remove the requested codes
  termination                 remove every code listed on the ticket

A ticket with N affiliation codes becomes N requests — one per code,
each running the proven single-code terminal steps — with the ticket
numbers <task>/1 … <task>/N (a single code keeps the plain task number).

Every check that protects the mainframe happens here, BEFORE a request
exists: the application, the instance, the account, every affiliation
code, known operations, one direction only (no ticket both adds and
removes), and a Request Type that does not contradict it. A refusal
returns a reason in plain words; it is e-mailed, audited and written to
the ticket by the connector.

Pure functions only — no network, no side effects.
"""
from __future__ import annotations

import re
import unicodedata
from typing import Optional

from src.integrations.servicenow.mapper import _redact_ticket

# Request types
NEW_ACCOUNT = "new_account"
ACCESS_REMOVAL = "access_removal"
ENT_CERT = "entitlement_certification"
ACCOUNT_CERT = "account_certification"
TRANSFER = "transfer"
TERMINATION = "termination"
REMOVAL_ONLY = (ENT_CERT, ACCOUNT_CERT, TRANSFER, TERMINATION)
CERTIFICATIONS = (ENT_CERT, ACCOUNT_CERT)
TYPE_LABELS = {
    NEW_ACCOUNT: "New Account Provisioning",
    ACCESS_REMOVAL: "Access Removal",
    ENT_CERT: "Entitlement Certification",
    ACCOUNT_CERT: "Account Certification",
    TRANSFER: "Transfer",
    TERMINATION: "Termination",
}
# Kept for requests recorded before the six types existed.
CATEGORY_ACCESS = "access_request"
CATEGORY_CERTIFICATION = "certification"

_ATTR_RE = re.compile(
    r"attributename\s*=\s*(?P<name>[^;\n]+?)\s*;\s*value\s*=\s*"
    r"(?P<value>[^;\n]+?)\s*;\s*operation\s*=\s*(?P<op>[^;\s]+)",
    re.IGNORECASE)
# Only spaces after the colon: an empty account must not borrow the next
# line's first word (2026-09-28).
_ACCOUNT_RE = re.compile(
    r"\bfor\s+account\s*:[ \t]*(?P<account>[A-Za-z0-9]+)", re.IGNORECASE)
_TRACKING_RE = re.compile(
    r"access\s*request\s*id\b[^:\n]*:\s*(?P<id>[A-Za-z0-9-]+)", re.IGNORECASE)
# Certification entitlement item: "01634 | label  Revoker: …"
_ENTITLEMENT_RE = re.compile(r"^(?P<code>\d{1,6})\s*\|\s*(?P<label>.*)$")
_REVOKER_RE = re.compile(r"\s+(revoker|certifier)\s*:.*$", re.IGNORECASE)
_BULLETS = " \t*•・‐-–—"
_SYS_ID_RE = re.compile(r"^[0-9a-f]{32}$", re.IGNORECASE)


def _nfkc(text) -> str:
    """Half-width form, so full-width ；＝：｜ and digits match."""
    return unicodedata.normalize("NFKC", str(text or ""))


def _key(text) -> str:
    return " ".join(_nfkc(text).casefold().split())


def _lines(text: str) -> list[str]:
    return [line.strip(_BULLETS) for line in _nfkc(text).splitlines()]


def variables_by_label(variables) -> dict:
    """{label: value} for storage and display (labels as shown)."""
    out = {}
    for v in variables or []:
        label = str(v.get("label") or v.get("name") or "").strip()
        if label and label not in out:
            out[label] = v.get("value", "")
    return out


def variable(variables, names) -> str:
    """The value of the first variable whose label OR internal name
    matches one of `names` (case-insensitive). '' when absent."""
    wanted = {_key(n) for n in (names or []) if str(n).strip()}
    if not wanted:
        return ""
    for v in variables or []:
        if _key(v.get("label")) in wanted or _key(v.get("name")) in wanted:
            value = v.get("value", "")
            if isinstance(value, dict):
                value = value.get("display_value") or value.get("value") or ""
            return str(value or "").strip()
    return ""


def has_variable(variables, names) -> bool:
    """True when a variable whose label OR internal name matches one of
    `names` exists on the ticket, whatever its value (an empty value
    still counts as present)."""
    wanted = {_key(n) for n in (names or []) if str(n).strip()}
    if not wanted:
        return False
    return any(_key(v.get("label")) in wanted or _key(v.get("name")) in wanted
               for v in variables or [] if isinstance(v, dict))


def classify(word: str, words: dict) -> tuple[str, str]:
    """(operation, marker) for an operation word, ('', '') when unknown.
    Certification words are ALWAYS a removal."""
    w = _key(word)
    if not w:
        return "", ""
    if w in {_key(x) for x in words.get("certification", [])}:
        return "deprovision", CATEGORY_CERTIFICATION
    if w in {_key(x) for x in words.get("provision", [])}:
        return "provision", CATEGORY_ACCESS
    if w in {_key(x) for x in words.get("deprovision", [])}:
        return "deprovision", CATEGORY_ACCESS
    return "", ""


def _mentions(text: str, phrases) -> bool:
    low = " ".join(_nfkc(text).casefold().split())
    for phrase in phrases or []:
        p = _key(phrase)
        if p and re.search(r"(?<![a-z])" + re.escape(p) + r"(?![a-z])", low):
            return True
    return False


def detect_type(texts, s) -> str:
    """The request type named in the ticket ('' = decided by the
    operation). Checked in this order: Termination, Transfer, Account
    Certification, then any certification word (Entitlement
    Certification)."""
    joined = "\n".join(str(t or "") for t in texts)
    types = getattr(s, "request_type_words", {}) or {}
    for name in (TERMINATION, TRANSFER, ACCOUNT_CERT):
        if _mentions(joined, types.get(name, [])):
            return name
    if _mentions(joined, (s.operation_words or {}).get("certification", [])):
        return ENT_CERT
    return ""


def _affiliation(raw: str) -> tuple[str, str, str]:
    """(code, name, problem). The code is the part before '|'."""
    text = _nfkc(raw)
    code, _, name = text.partition("|")
    code, name = code.strip(), name.strip()
    # NFKC already turns full-width digits into ASCII; isascii() also
    # refuses the Unicode digits it keeps (Arabic-Indic and the like).
    if code.isascii() and code.isdigit() and len(code) < 5:
        code = code.zfill(5)
    if not (code.isascii() and code.isdigit() and len(code) == 5):
        return "", name, f"the affiliation code '{code or raw}' is not a 5-digit code"
    return code, name, ""


def _application_ok(ids, sources) -> bool:
    if not ids:
        return True
    text = "\n".join(_nfkc(s) for s in sources if s)
    return any(re.search(r"\[\s*" + re.escape(_nfkc(i).strip()) + r"\s*\]", text)
               for i in ids if str(i).strip())


def for_application(ticket: dict, variables: list, s) -> bool:
    """True when the ticket names one of the accepted application IDs
    (or none is configured). A ticket for another application is not
    the bot's: it is skipped without a note on the ticket."""
    names = s.sp_variables or {}
    return _application_ok(s.sp_application_ids, [
        variable(variables, names.get("application")),
        (ticket or {}).get("description"),
        (ticket or {}).get("short_description"),
        variable(variables, names.get("text"))])


# Text that marks an instruction: the access format, the account line,
# the tracking line, or a certification's revocation.
_TEXT_MARKERS = re.compile(
    r"attributename\s*=|for\s+account\s*:|access\s*request\s*id|\brevoke\b",
    re.IGNORECASE)
# Never the instruction: notes and journals, written by people and by
# the bot itself.
_NOT_TEXT_FIELDS = {"work_notes", "comments", "comments_and_work_notes",
                    "close_notes", "work_notes_list", "approval_history"}


def task_text(record: dict, fields=None) -> tuple[str, str]:
    """(field, text) of the task field that holds the instruction text,
    ('', '') when none does. `fields`: the fields to use, in order (the
    first that is filled in). Empty: the first field whose text carries
    an instruction, the description first, then by field name."""
    if not isinstance(record, dict):
        return "", ""

    def text_of(value) -> str:
        if isinstance(value, dict):
            value = value.get("display_value") or value.get("value") or ""
        return str(value).strip() if isinstance(value, str) else ""

    wanted = [str(f).strip() for f in (fields or []) if str(f).strip()]
    if wanted:
        for name in wanted:
            text = text_of(record.get(name))
            if text:
                return name, text
        return "", ""
    names = sorted(k for k in record
                   if k not in _NOT_TEXT_FIELDS and not k.startswith("sys_"))
    if "description" in names:
        names.remove("description")
        names.insert(0, "description")
    for name in names:
        text = text_of(record.get(name))
        if text and _TEXT_MARKERS.search(_nfkc(text)):
            return name, text
    return "", ""


def _variables_identified(variables) -> bool:
    """True when at least one catalog variable came back with its label
    or name AND a value. When none did, the variables could not be read
    (for example no read access to their values)."""
    for v in variables or []:
        if not isinstance(v, dict) or v.get("source") == "task":
            continue
        value = v.get("value", "")
        if isinstance(value, dict):
            value = value.get("display_value") or value.get("value") or ""
        if (v.get("label") or v.get("name")) and str(value or "").strip():
            return True
    return False


def _attribute_items(text: str) -> list[tuple[str, str, str]]:
    """Every AttributeName=…; Value=…; Operation=… group, in order,
    whether on one line (";"-separated) or on several."""
    items = []
    for m in _ATTR_RE.finditer(_nfkc(text)):
        item = (m.group("name").strip(_BULLETS), m.group("value").strip(),
                m.group("op").strip())
        if item not in items:
            items.append(item)
    return items


def _entitlement_items(text: str) -> list[tuple[str, str]]:
    """Certification-format items "code | name", one per line or per
    ";"-separated part."""
    found = []
    for line in _lines(text):
        for part in line.split(";"):
            m = _ENTITLEMENT_RE.match(part.strip(_BULLETS))
            if not m:
                continue
            label = _REVOKER_RE.sub("", m.group("label")).strip()
            if m.group("code") not in [f[0] for f in found]:
                found.append((m.group("code"), label))
    return found


def parse_ticket(ticket: dict, variables: list, s) -> tuple[Optional[list], str]:
    """([payload, …], '') or (None, reason). `s` is the ServiceNowSettings.
    One payload per affiliation code.

    Checks "minimal" (for testing) keeps only what a run needs - the
    application, the instruction, the attribute, a known operation, the
    affiliation code, the account and one direction - and skips the
    instance, the account variable cross-check, the Request Type and
    the removal-only rule of the request types."""
    names = s.sp_variables or {}
    words = s.operation_words or {}
    minimal = str(getattr(s, "sp_checks", "strict") or "strict"
                  ).strip().lower() == "minimal"
    text = variable(variables, names.get("text"))
    account_var = variable(variables, names.get("account"))
    instance = variable(variables, names.get("instance"))
    application = variable(variables, names.get("application"))
    request_type = variable(variables, names.get("request_type"))

    if not variables:
        return None, "the catalog variables of the requested item could not be read"

    # 1. The ticket must be for FINES III.
    if not _application_ok(s.sp_application_ids, [
            application, ticket.get("description"),
            ticket.get("short_description"), text]):
        ids = ", ".join(f"[{i}]" for i in s.sp_application_ids)
        return None, (f"the ticket is not for application {ids} "
                      f"(Application Name: '{application or '-'}')")

    # 2. A filled-in instance must be accepted on this server.
    accepted = {_key(i) for i in (s.sp_accepted_instances or [])}
    if not minimal and instance and accepted and \
            _key(instance) not in accepted \
            and not _SYS_ID_RE.match(instance):
        return None, (f"instance '{instance}' is not accepted on this "
                      f"server (accepted: "
                      f"{', '.join(s.sp_accepted_instances)})")

    if not text.strip():
        return None, "the instruction text (Description / Work notes) is empty"

    detected = detect_type([text, request_type, ticket.get("short_description")], s)

    # 3. The entitlements: access format first, then certification format.
    entitlements = []                      # [(code, name, operation)]
    attrs = _attribute_items(text)
    if attrs:
        allowed = {_key(a) for a in (s.sp_affiliation_attributes or [])}
        for name, value, op_word in attrs:
            if allowed and _key(name) not in allowed:
                return None, f"attribute '{name}' is not supported by the bot"
            operation, _ = classify(op_word, words)
            if not operation:
                return None, f"unknown operation '{op_word}'"
            code, label, problem = _affiliation(value)
            if problem:
                return None, problem
            entitlements.append((code, label, operation, op_word))
    elif detected in REMOVAL_ONLY:
        for code, label in _entitlement_items(text):
            code, label2, problem = _affiliation(f"{code} | {label}")
            if problem:
                return None, problem
            entitlements.append((code, label2, "deprovision", "revoke"))
        if not entitlements:
            return None, (f"no entitlement (affiliation code) was found in "
                          f"the {TYPE_LABELS[detected]} ticket")
    else:
        return None, "no provisioning or removal instruction was found in the ticket text"

    # The same code twice with the same operation counts once.
    unique = []
    for e in entitlements:
        if (e[0], e[2]) not in [(u[0], u[2]) for u in unique]:
            unique.append(e)
    entitlements = unique

    operations = {e[2] for e in entitlements}
    if len(operations) > 1:
        return None, ("the ticket both adds and removes affiliation codes; "
                      "it is left for manual handling")
    operation = operations.pop()
    if not minimal and detected in REMOVAL_ONLY and \
            operation != "deprovision":
        adds = next(e[3] for e in entitlements if e[2] == "provision")
        label = TYPE_LABELS[detected]
        article = "an" if label[:1].lower() in "aeiou" else "a"
        return None, (f"{article} {label} can only remove access, "
                      f"but the ticket asks to '{adds}'")
    if detected in REMOVAL_ONLY and operation != "deprovision":
        # Minimal checks: the operation in the text decides the type.
        detected = ""
    request_kind = detected or (NEW_ACCOUNT if operation == "provision"
                                else ACCESS_REMOVAL)

    # 4. The account. A configured account variable that is not on the
    # ticket at all (wrong label) would silently switch the cross-check
    # off, so the ticket is held instead. When no catalog variable could
    # be read at all, the account comes from the instruction text.
    account_names = [n for n in (names.get("account") or []) if str(n).strip()]
    if not minimal and account_names and \
            _variables_identified(variables) and \
            not has_variable(variables, account_names):
        return None, (f"the account variable ({', '.join(account_names)}) "
                      f"was not found on the ticket — check the "
                      f"'Variable: account' setting")
    m = _ACCOUNT_RE.search(_nfkc(text))
    text_account = m.group("account") if m else ""
    if not minimal and text_account and account_var and \
            _key(text_account) != _key(account_var):
        return None, (f"the account in the text ({text_account}) differs "
                      f"from the Account Name variable ({account_var})")
    account = (account_var or text_account).strip()
    if not account:
        return None, "the account name is missing"
    if len(account) != 7:
        return None, f"the account '{account}' is not 7 characters"
    # A space or tab inside the account is refused at intake as well (NB-007).
    if not re.fullmatch(r"[A-Za-z0-9]{7}", account):
        return None, (f"the account '{account}' must be 7 half-width "
                      f"letters or digits")

    # 5. Request Type must not contradict the operation (Modify is neutral).
    rt_op, _ = classify(request_type, {k: v for k, v in words.items()
                                       if k in ("provision", "deprovision")})
    if not minimal and rt_op and rt_op != operation:
        return None, (f"Request Type '{request_type}' contradicts the "
                      f"operation in the text ({operation})")

    tracking = ""
    m = _TRACKING_RE.search(_nfkc(text))
    if m:
        tracking = m.group("id")

    details = dict(ticket)
    details["variables"] = variables_by_label(variables)
    number = str(ticket.get("number", "") or "").strip()
    listed = [{"code": c, "name": n} for c, n, _, _ in entitlements]
    parts = len(entitlements)
    payloads = []
    for i, (code, label, _, _) in enumerate(entitlements, start=1):
        metadata = {
            "snow_details": _redact_ticket(details),
            "category": request_kind,
            "request_kind_label": TYPE_LABELS[request_kind],
            "tracking_id": tracking,
            "request_type": request_type,
            "employee_id": variable(variables, names.get("employee_id")),
            "employee_name": variable(variables, names.get("employee")),
            "entitlement": f"{code} | {label}".strip(" |"),
            "affiliation_name": label,
            "entitlements": listed,
            "parent_ticket": number,
            "part": i,
            "parts": parts,
            "requested_item": str(ticket.get("request_item.number", "") or ""),
            "request_number": str(ticket.get("request.number", "") or ""),
        }
        payloads.append({
            "operation": operation,
            "affiliation_code": code,
            "employee_code": account,
            # Never from a ticket: the platform generates it (client rule).
            "password": "",
            "source": "servicenow",
            "ticket_id": number if parts == 1 else f"{number}/{i}",
            "metadata": metadata,
        })
    return payloads, ""


def parent_of(ticket_id: str) -> str:
    """The ServiceNow task number of a request's ticket id
    (SCTASK123/2 → SCTASK123)."""
    return str(ticket_id or "").split("/", 1)[0]
