"""Ticket close-out after the mainframe step (2026-09-26).

Hangs on the dispatcher's completion hook (the same one the outcome
emails use) and, for requests that came from ServiceNow, writes the
result back to the ticket:

  done              close the ticket: configured state + comment
                    (SNOW_CLOSE_ON_SUCCESS, SNOW_CLOSE_STATE,
                     SNOW_CLOSE_COMMENT_PROVISION / _DEPROVISION)
  already_deleted   the account was already gone — the ticket STAYS
                    open with a review note (SNOW_REVIEW_NOTE)
  failed            retries exhausted — the ticket STAYS open with a
                    failure note (SNOW_FAILURE_NOTE)
  done/UNCONFIRMED  the change was submitted but the result could not be
                    read — the ticket STAYS open with a review note
                    (SNOW_UNCONFIRMED_NOTE, review switch)
  cancelled         cancelled by an operator — the ticket STAYS open
                    with a note (SNOW_CANCEL_NOTE)
  cancelled         not executed because a newer opposite ticket had
   (Superseded:)    already run — the held-ticket note (SNOW_REJECT_NOTE)

Durable (approved 2026-09-27): a delivered write-back is recorded in the
request's metadata (`snow_writeback`). On every poll the ServiceNow
poller calls reconcile() for tickets that are still open although their
request has finished; a write-back that was lost to a stop, a crash or
a ServiceNow outage is delivered then, and one already delivered is
never repeated.

Comment templates take {ticket_id} {operation} {affiliation_code}
{employee_code} {result_code} {completed_at} {request_id} {attempts}
{error} {status}. Unknown placeholders render blank. Passwords are
never available to a template.

Runs on a background thread, retries with back-off, never raises into
the dispatcher and never changes the mainframe outcome. A write that
still fails is logged at ERROR (so the email alert handler picks it up)
and recorded in the audit trail.
"""
from __future__ import annotations

import threading
import time
from typing import Callable, Optional

from src.integrations.servicenow.client import (ServiceNowClient,
                                                ServiceNowError, explain_error)
from src.integrations.servicenow.config import load_servicenow_config

SOURCE = "servicenow"

DEFAULT_TEMPLATES = {
    "provision": ("Provisioning completed by the FINESIII RPA bot. "
                  "Affiliation code {affiliation_code}, application ID "
                  "{employee_code}. Completed {completed_at}."),
    "deprovision": ("Deprovisioning completed by the FINESIII RPA bot. "
                    "Affiliation code {affiliation_code}, application ID "
                    "{employee_code}. Completed {completed_at}."),
    "review": ("Human review required: the FINESIII account for "
               "application ID {employee_code} (affiliation "
               "{affiliation_code}) was already deleted. No change was "
               "made by the bot. Ticket left open."),
    "failure": ("FINESIII RPA bot could not complete this request after "
                "{attempts} attempt(s). Error: {error}. Ticket left open "
                "for review."),
    "unconfirmed": ("Human review required: the FINESIII RPA bot submitted "
                    "the {operation} for application ID {employee_code} "
                    "(affiliation {affiliation_code}) but could not confirm "
                    "the result on screen. Please verify in FINESIII. "
                    "Ticket left open."),
    "cancel": ("Cancelled in the FINESIII RPA console by an operator. "
               "Nothing was changed in FINESIII. Ticket left open for "
               "review."),
    "certification": ("Certification revocation completed by the FINESIII "
                      "RPA bot. Affiliation code {affiliation_code}, "
                      "account {employee_code}. Completed {completed_at}."),
}

CATEGORY_LABELS = {"certification": "Certification",
                   "access_request": "Access request",
                   "new_account": "New Account Provisioning",
                   "access_removal": "Access Removal",
                   "entitlement_certification": "Entitlement Certification",
                   "account_certification": "Account Certification",
                   "transfer": "Transfer",
                   "termination": "Termination"}
# Closed with the certification comment.
_CERTIFICATION_KINDS = ("certification", "entitlement_certification",
                        "account_certification")

_SUCCESS = ("done", "success")
_REVIEW = ("already_deleted",)
_FAILED = ("failed", "error")
_CANCELLED = ("cancelled",)
# Statuses of a request that has not finished yet.
_NOT_FINAL = ("queued", "running")
UNCONFIRMED = "UNCONFIRMED"
MARKER = "snow_writeback"
# Error prefix of a request cancelled just before execution because a
# newer opposite ticket had already run (NB-001).
SUPERSEDED_PREFIX = "Superseded:"
# Statuses of a newer opposite request that make an older one stale.
_SUPERSEDING = ("running", "done", "already_deleted")
# The held-ticket note of the connector (reject_note unset).
DEFAULT_REJECT_NOTE = ("Not processed by the FINESIII RPA bot: {reason}. "
                       "Ticket left open for review.")


class _Blank(dict):
    def __missing__(self, key):
        return ""


PLACEHOLDERS = ("ticket_id", "request_id", "operation", "affiliation_code",
                "employee_code", "result_code", "completed_at", "attempts",
                "error", "status", "original_ticket_id",
                # 2026-09-28: SailPoint tasks and rejection notes
                "category", "tracking_id", "reason")


def template_problem(template: str) -> str:
    """Why a comment template cannot be used ('' = fine). Checked when
    the template is SAVED, so a stray brace never reaches a ticket."""
    import string
    try:
        fields = [f for _, f, _, _ in string.Formatter().parse(str(template))
                  if f is not None]
    except ValueError as e:
        return f"unbalanced braces ({e})"
    for name in fields:
        if name not in PLACEHOLDERS:
            return (f"unknown placeholder {{{name}}} — use one of: "
                    + ", ".join("{" + p + "}" for p in PLACEHOLDERS))
    return ""


def render(template: str, context: dict, fallback: str = "") -> str:
    """Render a template. A template that cannot be rendered (edited by
    hand in the YAML with a stray brace) falls back to the built-in
    text rather than posting raw placeholders to the ticket."""
    try:
        return str(template).format_map(_Blank(context))
    except (ValueError, IndexError, KeyError, AttributeError):
        if fallback and fallback != template:
            return render(fallback, context)
        return str(template).replace("{", "").replace("}", "")


class _RequestView:
    """A finished queue request seen as the transaction record the
    close-out expects (used by reconcile)."""

    def __init__(self, request):
        self.status = getattr(request, "status", "")
        self.ticket_id = getattr(request, "ticket_id", "")
        self.request_id = getattr(request, "request_id", "")
        self.operation = getattr(request, "operation", "")
        self.affiliation_code = getattr(
            request, "normalized_affiliation",
            getattr(request, "affiliation_code", ""))
        self.employee_code = getattr(request, "employee_code", "")
        self.result_code = getattr(request, "result_code", "")
        self.completed_at = getattr(request, "completed_at", "")
        self.attempt_count = getattr(request, "attempt_count", "")
        self.error_message = getattr(request, "error", "")


_TERMINAL = _SUCCESS + _REVIEW + _FAILED + _CANCELLED
_RESULT_WORDS = {"done": "completed", "already_deleted": "already removed",
                 "failed": "failed", "cancelled": "cancelled"}


class _TicketView:
    """All requests of a ticket that carried several affiliation codes,
    seen as ONE finished request (2026-09-28): the ticket is written to
    once, when every code has finished. Serves as both the transaction
    record and the request for the close-out."""

    def __init__(self, members, parent: str):
        lead = members[0]
        self.members = members
        self.member_ids = [m.request_id for m in members]
        self.source = getattr(lead, "source", "")
        self.metadata = lead.metadata if isinstance(lead.metadata, dict) else {}
        self.ticket_id = parent
        self.request_id = lead.request_id
        self.operation = lead.operation
        self.employee_code = lead.employee_code
        self.affiliation_code = ", ".join(
            getattr(m, "normalized_affiliation", m.affiliation_code)
            for m in members)
        statuses = [str(m.status).lower() for m in members]
        unconfirmed = any(str(m.result_code).upper() == UNCONFIRMED
                          for m in members if str(m.status).lower() in _SUCCESS)
        if any(st in _FAILED for st in statuses):
            self.status, self.result_code = "failed", ""
        elif any(st in _CANCELLED for st in statuses):
            self.status, self.result_code = "cancelled", ""
        elif unconfirmed:
            self.status, self.result_code = "done", UNCONFIRMED
        elif any(st in _REVIEW for st in statuses):
            self.status, self.result_code = "already_deleted", ""
        else:
            self.status, self.result_code = "done", "O-0000"
        self.completed_at = max(str(m.completed_at or "") for m in members)
        self.attempt_count = max(int(m.attempt_count or 0) for m in members)
        self.error_message = "; ".join(
            f"{m.affiliation_code}: {m.error}" for m in members
            if str(m.status).lower() in _FAILED + _CANCELLED and m.error)
        self.outcome_key = "|".join(
            f"{m.ticket_id}:{m.status}:{m.completed_at}" for m in members)
        lines = []
        for m in members:
            meta = m.metadata if isinstance(m.metadata, dict) else {}
            name = str(meta.get("affiliation_name", "") or "")
            word = _RESULT_WORDS.get(str(m.status).lower(), str(m.status))
            if str(m.result_code).upper() == UNCONFIRMED:
                word = "submitted, result not confirmed"
            lines.append(f"- {m.affiliation_code}"
                         + (f" {name}" if name else "") + f": {word}")
        self.results_text = "Result per affiliation code:\n" + "\n".join(lines)


class TicketCloseout:
    RETRY_DELAYS = (5.0, 15.0, 45.0)

    def __init__(self, logger=None, audit=None,
                 settings_loader: Callable = load_servicenow_config,
                 client_factory: Optional[Callable] = None,
                 async_send: bool = True,
                 sleep_func: Callable[[float], None] = time.sleep):
        self.logger = logger
        self.audit = audit
        self._load = settings_loader
        self._client_factory = client_factory or (
            lambda settings: ServiceNowClient(settings, logger=logger))
        self.async_send = async_send
        self._sleep = sleep_func
        self.last_result: dict = {}
        # Set by the application: where delivered write-backs are
        # recorded. None = not recorded (no reconciliation possible).
        self.queue_store = None
        self._inflight: set = set()
        self._inflight_lock = threading.Lock()
        self._bot_ids: dict = {}        # bot identity -> sys_id (cache)

    # ── dispatcher hook ──

    def handle_completion(self, txn, request, result) -> None:
        """Never raises. Only ServiceNow-sourced requests with a stored
        sys_id are considered."""
        try:
            view = self._ticket_view(request)
            if view is False:
                return          # other codes of this ticket still running
            if view is not None:
                txn = request = view
            sys_id = self._sys_id(request)
            if getattr(request, "source", "") != SOURCE or not sys_id:
                return
            # One key per ticket whichever path built the view (this
            # hook or reconcile), so two writers never run at once for a
            # ticket with several codes (E2E-H02).
            rid = (getattr(request, "ticket_id", "")
                   if isinstance(request, _TicketView)
                   else getattr(request, "request_id", "")) or id(request)
            with self._inflight_lock:
                if rid in self._inflight:
                    return                      # already being written
                self._inflight.add(rid)
            if self.async_send:
                threading.Thread(
                    target=self._run, args=(txn, request, result, sys_id, rid),
                    name="snow-ticket-closeout", daemon=True).start()
            else:
                self._run(txn, request, result, sys_id, rid)
        except Exception as e:
            self._log("warning", f"Ticket close-out could not start: {e}")

    def _run(self, txn, request, result, sys_id, rid) -> None:
        try:
            self._apply(txn, request, result, sys_id)
        except Exception as e:
            self._log("warning", f"Ticket close-out failed unexpectedly: {e}")
        finally:
            with self._inflight_lock:
                self._inflight.discard(rid)

    # ── reconciliation (called by the poller) ──

    GRACE_SECONDS = 120.0       # leave a fresh completion to its own thread
    MAX_ROUNDS = 6              # polls a failing write-back is retried on

    @staticmethod
    def _outcome_key(request) -> str:
        key = getattr(request, "outcome_key", None)
        if key:
            return key
        return (f"{getattr(request, 'status', '')}:"
                f"{getattr(request, 'completed_at', '')}")

    def _stored_key(self, request) -> str:
        """The outcome key of the request as the queue holds it. The
        dispatcher hands over the request object it ran, which still
        says "running"; the stored row carries the final status and
        time that reconcile compares with (2026-09-28)."""
        if not isinstance(request, _TicketView) and self.queue_store is not None:
            rid = getattr(request, "request_id", "")
            if rid:
                try:
                    fresh = self.queue_store.get(rid)
                except Exception:
                    fresh = None
                if fresh is not None and \
                        str(fresh.status).lower() in _TERMINAL:
                    return self._outcome_key(fresh)
        return self._outcome_key(request)

    @staticmethod
    def _legacy_mark(mark) -> bool:
        """A delivered mark written with the not-yet-final status of the
        request ("running:…", "queued:…") by an earlier version."""
        if not isinstance(mark, dict) or mark.get("pending"):
            return False
        outcome = str(mark.get("outcome", "") or "")
        return outcome.split(":", 1)[0].lower() in _NOT_FINAL

    def _ticket_view(self, request):
        """None for a single-code request; False while other codes of
        the same ticket are still open; else the whole ticket as one."""
        meta = getattr(request, "metadata", None)
        if isinstance(request, _TicketView) or not isinstance(meta, dict):
            return None
        parts = int(meta.get("parts", 1) or 1)
        if parts <= 1 or self.queue_store is None:
            return None
        parent = str(meta.get("parent_ticket") or
                     str(getattr(request, "ticket_id", "")).split("/")[0])
        members = self.queue_store.find_ticket_requests(parent)
        if len(members) < parts or any(
                str(m.status).lower() not in _TERMINAL for m in members):
            return False
        return _TicketView(members, parent)

    def reconcile(self, request) -> bool:
        """Deliver the write-back of a FINISHED request whose ticket is
        still open, unless it was already delivered. Returns True when a
        write-back was started. Never raises."""
        try:
            view = self._ticket_view(request)
            if view is False:
                return False
            if view is not None:
                request = view
            status = str(getattr(request, "status", "")).lower()
            if status not in _SUCCESS + _REVIEW + _FAILED + _CANCELLED:
                return False
            if getattr(request, "source", "") != SOURCE \
                    or not self._sys_id(request):
                return False
            meta = getattr(request, "metadata", None) or {}
            mark = meta.get(MARKER) if isinstance(meta, dict) else None
            key = self._outcome_key(request)
            if isinstance(mark, dict) and mark.get("outcome") == key:
                if not mark.get("pending"):
                    return False                # delivered (or refused)
                if int(mark.get("rounds", 0) or 0) >= self.MAX_ROUNDS:
                    return False                # given up, already alerted
            if self._legacy_mark(mark):
                # Delivered, but recorded under the running status: take
                # it as delivered and record the real outcome, so the
                # note is not written a second time (2026-09-28).
                self._mark(request, str(mark.get("action", "") or ""),
                           note=str(mark.get("note", "") or ""))
                return False
            completed = str(getattr(request, "completed_at", "") or "")
            if completed:
                from datetime import datetime
                try:
                    done_at = datetime.fromisoformat(completed)
                    now = datetime.now(done_at.tzinfo)
                    if (now - done_at).total_seconds() < self.GRACE_SECONDS:
                        return False
                except ValueError:
                    pass
            txn = request if view is not None else _RequestView(request)
            self.handle_completion(txn, request, {})
            return True
        except Exception as e:
            self._log("warning", f"Ticket reconciliation failed: {e}")
            return False

    def _mark(self, request, action: str, pending: bool = False,
              note: str = "") -> int:
        """Record the state of this request's write-back. Returns the
        number of rounds a pending write-back has now been tried."""
        rounds = 0
        try:
            meta = getattr(request, "metadata", None) or {}
            old = meta.get(MARKER) if isinstance(meta, dict) else None
            key = self._stored_key(request)
            if isinstance(old, dict) and old.get("outcome") == key:
                rounds = int(old.get("rounds", 0) or 0)
            if pending:
                rounds += 1
            mark = {"outcome": key, "action": action, "pending": pending,
                    "rounds": rounds, "note": note[:120]}
            if isinstance(meta, dict):
                meta[MARKER] = mark
            ids = getattr(request, "member_ids", None) or \
                [getattr(request, "request_id", "")]
            if self.queue_store is not None:
                for rid in ids:
                    if rid:
                        self.queue_store.set_metadata_value(rid, MARKER, mark)
        except Exception as e:
            self._log("warning", f"Write-back marker not saved: {e}")
        return rounds

    def _delivered(self, request) -> bool:
        """True when the stored mark says this outcome was already
        written to the ticket, by this or another writer (E2E-H02)."""
        if self.queue_store is None:
            return False
        ids = getattr(request, "member_ids", None) or \
            [getattr(request, "request_id", "")]
        try:
            fresh = self.queue_store.get(ids[0]) if ids[0] else None
        except Exception:
            return False
        meta = getattr(fresh, "metadata", None)
        mark = meta.get(MARKER) if isinstance(meta, dict) else None
        return (isinstance(mark, dict) and not mark.get("pending")
                and not str(mark.get("note", "")).startswith("refused")
                and mark.get("outcome") == self._stored_key(request))

    # ── internals ──

    @staticmethod
    def _sys_id(request) -> str:
        meta = getattr(request, "metadata", None) or {}
        details = meta.get("snow_details") if isinstance(meta, dict) else None
        if not isinstance(details, dict):
            return ""
        value = details.get("sys_id", "")
        if isinstance(value, dict):
            value = value.get("value", "")
        return str(value or "").strip()

    @staticmethod
    def _category(request) -> str:
        meta = getattr(request, "metadata", None) or {}
        return str(meta.get("category", "") or "") if isinstance(meta, dict) else ""

    def _context(self, txn, request, result) -> dict:
        meta = getattr(request, "metadata", None) or {}
        meta = meta if isinstance(meta, dict) else {}
        category = self._category(request)
        # In JST and labelled, as in the e-mails (E2E-L12).
        from src.modules.notifications.notifier import fmt_time
        done = fmt_time(getattr(txn, "completed_at", "") or "")
        return {
            "category": CATEGORY_LABELS.get(category, category),
            "tracking_id": str(meta.get("tracking_id", "") or ""),
            "ticket_id": getattr(txn, "ticket_id", "") or "",
            "request_id": getattr(txn, "request_id", "") or "",
            "operation": getattr(txn, "operation", "") or "",
            "affiliation_code": getattr(txn, "affiliation_code", "") or "",
            "employee_code": getattr(txn, "employee_code", "") or "",
            "result_code": getattr(txn, "result_code", "") or "",
            "completed_at": f"{done} JST" if done else "",
            "attempts": getattr(txn, "attempt_count", "") or "",
            "error": getattr(txn, "error_message", "") or "",
            "status": getattr(txn, "status", "") or "",
        }

    def _plan(self, settings, txn, request, result):
        """(action, note) or None when nothing is configured for this
        outcome. A ticket with several codes gets one line per code."""
        plan = self._plan_one(settings, txn, request, result)
        extra = getattr(txn, "results_text", "")
        if plan is not None and extra:
            return plan[0], plan[1] + "\n" + extra
        return plan

    def _plan_one(self, settings, txn, request, result):
        """(action, note) or None when nothing is configured for this
        outcome. action: close | review_note | failure_note."""
        status = str(getattr(txn, "status", "")).lower()
        ctx = self._context(txn, request, result)
        if status in _SUCCESS and \
                str(ctx["result_code"]).strip().upper() == UNCONFIRMED:
            # Submitted, but the result line could not be read: a person
            # confirms it. Never closed as complete (SN-07).
            if not settings.review_note_enabled:
                return None
            tmpl = settings.unconfirmed_note or DEFAULT_TEMPLATES["unconfirmed"]
            note = render(tmpl, ctx, DEFAULT_TEMPLATES["unconfirmed"])
            # What happened after the '70' (code read, step that failed)
            # so the person knows what to check (NB-013).
            if ctx["error"] and "{error}" not in str(tmpl):
                note += f" Detail: {ctx['error']}"
            return "review_note", note
        error = str(ctx["error"] or "")
        if status in _CANCELLED and SUPERSEDED_PREFIX in error:
            # Not executed because a newer opposite ticket had already
            # run (NB-001): the held-ticket note, not "cancelled by an
            # operator". Off with the rejection note, like at pickup.
            if not getattr(settings, "reject_note_enabled", False):
                return None
            ctx = dict(ctx, reason=error.split(SUPERSEDED_PREFIX, 1)[1]
                       .strip().rstrip("."))
            return "reject_note", render(
                getattr(settings, "reject_note", "") or DEFAULT_REJECT_NOTE,
                ctx, DEFAULT_REJECT_NOTE)
        if status in _CANCELLED:
            if not settings.cancel_note_enabled:
                return None
            return "cancel_note", render(
                settings.cancel_note or DEFAULT_TEMPLATES["cancel"], ctx,
                DEFAULT_TEMPLATES["cancel"])
        if status in _SUCCESS:
            if not settings.close_on_success:
                return None
            op = ctx["operation"]
            if self._category(request) in _CERTIFICATION_KINDS:
                default = DEFAULT_TEMPLATES["certification"]
                tmpl = getattr(settings, "close_comment_certification",
                               "") or default
                return "close", render(tmpl, ctx, default)
            default = DEFAULT_TEMPLATES.get(op, DEFAULT_TEMPLATES["provision"])
            tmpl = (settings.close_comment_provision if op == "provision"
                    else settings.close_comment_deprovision) or default
            return "close", render(tmpl, ctx, default)
        if status in _REVIEW:
            if not settings.review_note_enabled:
                return None
            return "review_note", render(
                settings.review_note or DEFAULT_TEMPLATES["review"], ctx,
                DEFAULT_TEMPLATES["review"])
        if status in _FAILED:
            if not settings.failure_note_enabled:
                return None
            return "failure_note", render(
                settings.failure_note or DEFAULT_TEMPLATES["failure"], ctx,
                DEFAULT_TEMPLATES["failure"])
        return None

    # ── ownership check (SN-02) ──

    @staticmethod
    def _safe_term(value: str) -> bool:
        """A value that can sit in an encoded query without changing it."""
        value = str(value or "")
        return bool(value) and not any(c in value for c in "^=\n\r ,")

    def _owned(self, client, settings, sys_id: str, ticket: str):
        """(ok, reason). The bot writes to a ticket only when ServiceNow
        itself confirms that THIS sys_id carries THIS ticket number and
        is assigned to the bot account/group in force. `source` and
        `snow_details` arrive through the intake API, so they are
        claims, not facts, until checked here."""
        if not (self._safe_term(sys_id) and self._safe_term(ticket)):
            return False, "sys_id or ticket number is missing or malformed"
        parts = [f"sys_id={sys_id}", f"number={ticket}"]
        clause = "" if settings.query_override else \
            self._ownership_clause(client, settings)
        if clause:
            parts.append(clause)
        elif not settings.query_override:
            return False, "no bot account is configured"
        # Never write to a ticket that is no longer active: a closed
        # ticket is never reopened (2026-09-28).
        parts.append("active=true")
        rows = client.get_records(settings.table, "^".join(parts),
                                  fields=["sys_id", "number"], limit=1)
        if not rows:
            return False, ("ServiceNow has no such active ticket assigned "
                           "to the bot (number and sys_id must match)")
        return True, ""

    def _bot_id(self, client, bot: str) -> str:
        """The bot account's sys_id, looked up once ('' when not found)."""
        bot_id = self._bot_ids.get(bot)
        if bot_id is None:
            try:
                bot_id = client.user_sys_id(bot)
            except Exception:
                bot_id = ""
            self._bot_ids[bot] = bot_id
        return bot_id

    def _ownership_clause(self, client, settings) -> str:
        """The ticket must be assigned to the bot account - every ticket
        is assigned to it before it is queued - and, when a group is
        set, be in that group. '' when no bot account is known."""
        bot = str(settings.effective_assigned_to or "").strip()
        if not bot or any(c in bot for c in "^=\n\r"):
            return ""
        bot_id = self._bot_id(client, bot)
        parts = []
        if settings.assignment_group:
            parts.append(f"{settings.assignment_field}="
                         f"{settings.assignment_group}")
        parts.append(f"assigned_to={bot_id}" if bot_id
                     else f"assigned_to.user_name={bot}")
        return "^".join(parts)

    # ── superseded? (NB-001, checked just before the terminal step) ──

    def superseding_request(self, request):
        """The NEWER request of the opposite operation for the same
        account and affiliation code that is running or has finished,
        or None. "Newer" is by ServiceNow ticket creation time; a request
        without one (manual, API) is never superseded. May raise."""
        if getattr(request, "source", "") != SOURCE or self.queue_store is None:
            return None
        from src.integrations.servicenow.duplicates import request_created_on
        mine = request_created_on(request)
        if not mine:
            return None
        op = str(getattr(request, "operation", "") or "")
        opposite = self.queue_store.find_content_duplicate(
            "deprovision" if op == "provision" else "provision",
            getattr(request, "affiliation_code", ""),
            getattr(request, "employee_code", ""),
            exclude_ticket_id=getattr(request, "ticket_id", ""),
            statuses=_SUPERSEDING)
        if opposite is None or request_created_on(opposite) <= mine:
            return None
        return opposite

    def superseded_reason(self, request) -> str:
        """'' when the request may run; otherwise why it must not: a
        newer ticket of the opposite operation for the same account and
        code already ran (the queue is FIFO, so this happens when the
        older request is retried after the newer one). Never raises."""
        try:
            opp = self.superseding_request(request)
            if opp is None:
                return ""
            return (f"a newer ticket {opp.ticket_id} ({opp.operation}) for "
                    f"the same account and affiliation code was already "
                    f"processed; this older ticket is not executed")
        except Exception as e:
            self._log("warning", f"Newer-ticket check before execution "
                                 f"failed: {e}")
            return ""

    # ── still open? (S12, checked just before the terminal step) ──

    def pre_execute_check(self, request) -> str:
        """'' when the request may run; otherwise why it must not: its
        ServiceNow task was closed, deleted or taken by someone else
        after pickup. ServiceNow unreachable → '' (it was verified at
        pickup; an outage must not stop processing). Never raises."""
        try:
            sys_id = self._sys_id(request)
            if getattr(request, "source", "") != SOURCE or not sys_id \
                    or not self._safe_term(sys_id):
                return ""
            settings = self._load()
            if not settings.instance_url:
                return ""
            # One quick try (2026-09-28): an unreachable ServiceNow must
            # not hold every request for the full retry cycle (~30 s).
            try:
                import dataclasses
                settings = dataclasses.replace(
                    settings, max_retries=0,
                    http_timeout_seconds=min(
                        10.0, float(settings.http_timeout_seconds or 10.0)))
            except Exception:
                pass
            client = self._client_factory(settings)
            try:
                rows = client.get_records(
                    settings.table, f"sys_id={sys_id}",
                    fields=["sys_id", "number", "active", "state",
                            "assigned_to"], limit=1)
            except Exception as e:
                self._log("warning", f"Ticket check before execution "
                                     f"skipped (ServiceNow unreachable): {e}")
                # The request still runs (it was checked at pickup); each
                # skipped check is evidenced in the audit trail (E2E-L33).
                self._audit("servicenow_ticket_check_skipped", "WARNING",
                            getattr(request, "ticket_id", "") or "",
                            {"request_id": getattr(request, "request_id", ""),
                             "reason": explain_error(e) or str(e)[:200]})
                return ""
            if not rows:
                return "the ServiceNow ticket no longer exists"
            row = rows[0]
            if str(row.get("active", "true")).strip().lower() in ("false", "0"):
                return (f"the ServiceNow ticket was closed before it ran "
                        f"(state {row.get('state', '')})")
            assigned = row.get("assigned_to", "")
            if isinstance(assigned, dict):
                assigned = assigned.get("value", "")
            assigned = str(assigned or "").strip()
            bot = settings.effective_assigned_to
            if assigned and bot:
                bot_id = self._bot_id(client, bot)
                if bot_id and assigned != bot_id:
                    return ("the ServiceNow ticket was assigned to someone "
                            "else before it ran")
            return ""
        except Exception as e:
            self._log("warning", f"Ticket check before execution failed: {e}")
            return ""

    def _apply(self, txn, request, result, sys_id: str) -> None:
        ticket = getattr(txn, "ticket_id", "") or sys_id
        try:
            settings = self._load()
        except Exception as e:
            self._log("warning", f"Ticket close-out skipped for {ticket}: "
                                 f"ServiceNow settings unavailable ({e})")
            return
        if not settings.instance_url:
            self._log("info", f"Ticket close-out skipped for {ticket}: "
                              "ServiceNow is not configured")
            return
        plan = self._plan(settings, txn, request, result)
        if plan is None:
            return
        action, note = plan
        client = self._client_factory(settings)
        attempts = 0
        last_error = ""
        verified = False
        while True:
            attempts += 1
            if attempts > 1 and self._delivered(request):
                # Written meanwhile (e.g. by the catch-up after an
                # outage): never record it again, nor as refused (E2E-H02).
                self._log("info", f"Ticket {ticket}: {action.replace('_', ' ')} "
                                  f"already written — retry stopped")
                return
            try:
                if not verified:
                    ok, reason = self._owned(
                        client, settings, sys_id,
                        getattr(txn, "ticket_id", "") or "")
                    if not ok:
                        # An error, so the ServiceNow audience is told by
                        # e-mail like a failed update (SN-02, 2026-10-03):
                        # the mainframe work is done, the ticket is not.
                        self._log("error",
                                  f"Ticket {ticket}: {action.replace('_', ' ')} "
                                  f"REFUSED — {reason}. The mainframe result "
                                  f"is recorded; update the ticket by hand.")
                        self._audit("servicenow_ticket_update_refused",
                                    "ERROR", ticket,
                                    {"action": action, "sys_id": sys_id,
                                     "reason": reason,
                                     "request_id": getattr(txn, "request_id", "")})
                        self.last_result = {"ticket_id": ticket,
                                            "action": action, "ok": False,
                                            "refused": True, "error": reason}
                        self._mark(request, action, note="refused: " + reason)
                        return
                    verified = True
                group = (settings.reject_reassign_group or "").strip()
                if action == "close":
                    client.set_state(sys_id, settings.close_state, note)
                elif action == "cancel_note" and group:
                    # A cancelled request needs a person, like a rejected
                    # ticket: handed to the hand-over group with the note
                    # (E2E-L14).
                    client.reassign(sys_id, group, note)
                else:
                    client.add_work_note(sys_id, note)
                self._log("info", f"Ticket {ticket}: {action.replace('_', ' ')} "
                                  f"written to ServiceNow"
                                  + (f" and handed to group '{group}'"
                                     if action == "cancel_note" and group
                                     else ""))
                self._audit("servicenow_ticket_updated", "INFO", ticket,
                            {"action": action, "sys_id": sys_id,
                             "state": settings.close_state
                             if action == "close" else "",
                             "attempts": attempts,
                             **({"group": group}
                                if action == "cancel_note" and group else {})})
                self.last_result = {"ticket_id": ticket, "action": action,
                                    "ok": True}
                self._mark(request, action)
                return
            except (ServiceNowError, Exception) as e:
                last_error = str(e)
                # A rejected sign-in is not tried again within the round:
                # repeated failures could lock the bot account (E2E-M10).
                if attempts > len(self.RETRY_DELAYS) or \
                        explain_error(last_error).startswith("sign-in rejected"):
                    break
                delay = self.RETRY_DELAYS[attempts - 1]
                self._log("warning", f"Ticket {ticket}: {action} failed "
                                     f"({e}); retrying in {delay:.0f}s")
                self._sleep(delay)
        # Exhausted for now. With a queue store the next poll tries
        # again (reconcile); alert on the first failure and when giving
        # up, not on every round.
        rounds = self._mark(request, action, pending=True, note=last_error)
        durable = self.queue_store is not None
        giving_up = (not durable) or rounds >= self.MAX_ROUNDS
        if rounds > 1 and not giving_up:
            self._log("warning",
                      f"ServiceNow ticket {ticket}: {action} still failing "
                      f"(round {rounds}): {last_error}")
            self.last_result = {"ticket_id": ticket, "action": action,
                                "ok": False, "error": last_error}
            return
        self._log("error", f"ServiceNow ticket {ticket} could not be updated "
                           f"({action}) after {attempts} attempts: {last_error}. "
                           f"The mainframe result is recorded; "
                           + ("update the ticket by hand." if giving_up else
                              "it will be tried again on the next polls."))
        self._audit("servicenow_ticket_update_failed", "ERROR", ticket,
                    {"action": action, "sys_id": sys_id,
                     "attempts": attempts, "error": last_error[:300]})
        self.last_result = {"ticket_id": ticket, "action": action,
                            "ok": False, "error": last_error}

    def _audit(self, event: str, severity: str, ticket: str, detail: dict):
        if self.audit is None:
            return
        try:
            self.audit.event("servicenow", event, severity=severity,
                             ticket_id=ticket, detail=detail)
        except Exception:
            pass

    def _log(self, level: str, msg: str):
        if self.logger and hasattr(self.logger, level):
            getattr(self.logger, level)(msg)
