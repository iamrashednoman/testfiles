"""Duplicate-ticket comparison (2026-09-26).

Two ServiceNow tickets with DIFFERENT numbers can ask for the same
thing. The ticket-number idempotency in the intake API cannot see that,
so the connector compares a new ticket against what the platform has
already accepted:

  business key   operation + affiliation code + employee code
                 A match against a request that is queued, running or
                 done (within the lookback window) BLOCKS the ticket:
                 the mainframe would perform the same step twice.
  other fields   requester email, short description, description and
                 every other mapped field are compared as well and the
                 matching ones are LISTED in the audit record and the
                 rejection email, so the reviewer sees exactly what was
                 identical.
  possible       same requester email AND same description but a
                 different business key is recorded as a possible
                 duplicate for a human to look at. It is never blocked:
                 a corrected employee code looks exactly like this.

Pure functions only — the queue lookups live in the queue store and the
wiring in the poller.
"""
from __future__ import annotations

from typing import Iterable, Optional

from src.integrations.servicenow.mapper import mask_inline_secrets

# ServiceNow bookkeeping fields that differ on every record and must not
# count as "matching content".
_IGNORED = {
    "sys_id", "number", "sys_created_on", "sys_updated_on", "sys_mod_count",
    "sys_created_by", "sys_updated_by", "opened_at", "closed_at",
    "sys_tags", "order", "state", "active", "work_notes", "comments",
    "comments_and_work_notes", "approval", "approval_set", "due_date",
    "expected_start", "sys_class_name", "parsed",
}

# Free-text fields used for the "possible duplicate" signal.
DESCRIPTION_FIELDS = ("description", "short_description")
REQUESTER_FIELDS = ("u_requester_email", "requested_for", "opened_by",
                    "caller_id", "u_user_email")


def _scalar(value):
    """Unwrap ServiceNow {'value','display_value'} objects."""
    if isinstance(value, dict):
        value = value.get("value", value.get("display_value"))
    if value is None:
        return ""
    # Masked the same way as the stored ticket, so a password in the
    # text neither leaks into a comparison nor breaks one (2026-09-28).
    return " ".join(mask_inline_secrets(str(value)).split()).strip().lower()


def ticket_created_on(ticket) -> str:
    """ServiceNow creation time of a ticket ('YYYY-MM-DD HH:MM:SS'), ''
    when the ticket does not carry it."""
    value = ticket.get("sys_created_on", "") if isinstance(ticket, dict) else ""
    if isinstance(value, dict):
        value = value.get("value", "")
    return str(value or "")


def request_created_on(request) -> str:
    """Creation time of the ServiceNow ticket a queued request came from
    (its stored snow_details), '' when unknown. Used by the poller's
    newer-ticket rule and by the check just before execution (NB-001)."""
    meta = getattr(request, "metadata", None)
    meta = meta if isinstance(meta, dict) else {}
    return ticket_created_on(meta.get("snow_details") or {})


def business_key(payload: dict) -> tuple:
    """(operation, affiliation, employee) as the queue would store it."""
    aff = str(payload.get("affiliation_code", "") or "").strip()
    if aff.isdigit() and len(aff) < 5:
        aff = aff.zfill(5)
    return (str(payload.get("operation", "") or "").strip().lower(), aff,
            str(payload.get("employee_code", "") or "").strip())


def matched_fields(original_details: Optional[dict], ticket: dict,
                   ignore: Iterable[str] = ()) -> list[str]:
    """Names of the ticket fields whose values are identical in the
    original request's stored ticket (metadata.snow_details) and the new
    ticket. Empty values never count as a match."""
    if not isinstance(original_details, dict) or not isinstance(ticket, dict):
        return []
    skip = _IGNORED | set(ignore)
    out = []
    for key, new_value in ticket.items():
        if key in skip:
            continue
        new_text = _scalar(new_value)
        if not new_text or new_text == "****":
            continue
        if _scalar(original_details.get(key)) == new_text:
            out.append(key)
    return sorted(out)


def requester_of(ticket: dict, user_email_field: str = "") -> str:
    for key in ((user_email_field,) if user_email_field else ()) + REQUESTER_FIELDS:
        if key and key in ticket:
            text = _scalar(ticket.get(key))
            if text:
                return text
    parsed = ticket.get("parsed") if isinstance(ticket.get("parsed"), dict) else {}
    return _scalar(parsed.get("user_email")) if parsed else ""


def description_of(ticket: dict) -> str:
    parts = [_scalar(ticket.get(k)) for k in DESCRIPTION_FIELDS if ticket.get(k)]
    return "\n".join(p for p in parts if p)


def is_possible_duplicate(original_details: Optional[dict], ticket: dict,
                          user_email_field: str = "") -> bool:
    """Same requester AND same description text as an earlier ticket."""
    if not isinstance(original_details, dict):
        return False
    req_new = requester_of(ticket, user_email_field)
    desc_new = description_of(ticket)
    if not req_new or not desc_new:
        return False
    return (req_new == requester_of(original_details, user_email_field)
            and desc_new == description_of(original_details))
