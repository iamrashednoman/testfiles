"""Outbound adapters to enterprise systems.

Inbound flow is API-first: upstream systems call the intake API. These
packages hold the OUTBOUND halves (credential retrieval, ticket
write-back) plus optional bridge daemons for systems that cannot call
the API directly.
"""
