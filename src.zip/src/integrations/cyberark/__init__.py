"""CyberArk vault integration — service-account password retrieval.

Pulls the FINESIII service-account password from CyberArk on a schedule,
caches it in the process environment, and keeps the shared credentials
object fresh. Disabled by default; the core service is unchanged and
unaware of it until `cyberark.enabled` is turned on.
"""

from src.integrations.cyberark.config import (
    CyberArkSettings, load_cyberark_config
)
from src.integrations.cyberark.client import (
    CyberArkClient, CyberArkError, CyberArkUnavailable
)
from src.integrations.cyberark.provider import (
    CyberArkPasswordProvider, maybe_start_cyberark
)

__all__ = [
    "CyberArkSettings",
    "load_cyberark_config",
    "CyberArkClient",
    "CyberArkError",
    "CyberArkUnavailable",
    "CyberArkPasswordProvider",
    "maybe_start_cyberark",
]
