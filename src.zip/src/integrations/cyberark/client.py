"""
CyberArk REST client — password retrieval + availability check.

Two API styles (selected in config/cyberark.yaml):

  ccp (default) — Central Credential Provider / AIM Web Service:
      GET {base}/AIMWebService/api/Accounts
          ?AppID=...&Safe=...&Object=... (or &UserName=...)
      → {"Content": "<password>", ...}
      Auth: allowed-machine / client certificate (agentless; the standard
      for unattended bots).

  pvwa — PVWA REST:
      POST {base}/PasswordVault/API/auth/{type}/Logon   → session token
      GET  {base}/PasswordVault/API/Accounts?...        → account id
      POST {base}/PasswordVault/API/Accounts/{id}/Password/Retrieve
      POST {base}/PasswordVault/API/auth/Logoff

Availability (client requirement): check_availability() is called BEFORE
any fetch — the vault must report Active first. "Active" means the service
answers HTTP at all (any status < 500); network errors and 5xx mean
Inactive.

Resilience mirrors the ServiceNow client: 429/5xx/network → exponential
backoff with cap; other 4xx → raise immediately. The HTTP transport and
sleep function are injectable so the client is fully unit-testable
without network access.
"""

import time
from typing import Callable, Optional

import httpx

from src.integrations.cyberark.config import CyberArkSettings


class CyberArkError(Exception):
    """Raised on an unrecoverable CyberArk API error."""


class CyberArkUnavailable(CyberArkError):
    """Raised when the vault reports Inactive (pre-fetch availability gate)."""


class CyberArkClient:
    """Minimal, resilient client for CyberArk password retrieval."""

    def __init__(self, settings: CyberArkSettings, logger=None,
                 transport: Optional[httpx.BaseTransport] = None,
                 sleep_func: Callable[[float], None] = time.sleep):
        self.s = settings
        self.logger = logger
        self._transport = transport          # injected in tests (httpx.MockTransport)
        self._sleep = sleep_func

    # ── HTTP plumbing ──────────────────────────────────────────────

    def _new_client(self) -> httpx.Client:
        kwargs = dict(
            base_url=self.s.base_url,
            timeout=httpx.Timeout(self.s.http_timeout_seconds),
            verify=self.s.verify_tls,
            headers={"Accept": "application/json"},
        )
        if self.s.client_cert_path:
            kwargs["cert"] = (
                (self.s.client_cert_path, self.s.client_key_path)
                if self.s.client_key_path else self.s.client_cert_path
            )
        if self._transport is not None:
            kwargs["transport"] = self._transport
        return httpx.Client(**kwargs)

    def _request(self, method: str, url: str, **kwargs) -> httpx.Response:
        """Execute a request with 429/5xx/network retry + backoff."""
        attempt = 0
        while True:
            attempt += 1
            with self._new_client() as client:
                try:
                    resp = client.request(method, url, **kwargs)
                except httpx.RequestError as e:
                    if attempt > self.s.max_retries:
                        raise CyberArkError(
                            f"Network error after {attempt} attempts: {e}"
                        )
                    self._backoff(attempt, reason=f"network error: {e}")
                    continue

            if resp.status_code == 429 or 500 <= resp.status_code < 600:
                if attempt > self.s.max_retries:
                    raise CyberArkError(
                        f"{resp.status_code} from CyberArk: retries exhausted"
                    )
                self._backoff(attempt, reason=f"{resp.status_code} response")
                continue

            if resp.status_code >= 400:
                # Body may describe the failure but must never be logged in
                # full (could echo query details) — truncate hard.
                raise CyberArkError(
                    f"{method} {url} failed: {resp.status_code} {resp.text[:200]}"
                )
            return resp

    def _backoff(self, attempt: int, reason: str = ""):
        exp = self.s.backoff_base_seconds * (2 ** (attempt - 1))
        delay = min(exp, self.s.backoff_max_seconds)
        if self.logger:
            self.logger.warning(
                f"CyberArk {reason} — backing off {delay:.1f}s (attempt {attempt})"
            )
        self._sleep(delay)

    # ── Availability gate (client requirement) ─────────────────────

    def check_availability(self) -> bool:
        """Is the vault Active right now? Called BEFORE any fetch.

        Active   → the service answered HTTP (any status < 500; a 4xx on the
                   bare probe path still proves the service is up).
        Inactive → network error, timeout, or 5xx.
        Single attempt, no retries — this is a fast gate, not a fetch."""
        try:
            with self._new_client() as client:
                resp = client.get(self.s.effective_health_path)
            return resp.status_code < 500
        except httpx.RequestError:
            return False

    # ── Password retrieval ─────────────────────────────────────────

    def fetch_password(self) -> str:
        """Retrieve the service-account password from the vault.

        Availability is validated FIRST (when enabled) — an Inactive vault
        raises CyberArkUnavailable so the caller can fall back to its
        last-known-good cache instead of hammering a down service."""
        if self.s.health_check_enabled and not self.check_availability():
            raise CyberArkUnavailable(
                "CyberArk availability check failed (Inactive) — fetch skipped"
            )
        if self.s.api_style == "pvwa":
            return self._fetch_pvwa()
        return self._fetch_ccp()

    def _fetch_ccp(self) -> str:
        params = {"AppID": self.s.app_id, "Safe": self.s.safe}
        if self.s.object_name:
            params["Object"] = self.s.object_name
        else:
            params["UserName"] = self.s.account_username

        resp = self._request("GET", "/AIMWebService/api/Accounts", params=params)
        body = resp.json()
        password = body.get("Content", "")
        if not password:
            raise CyberArkError(
                "CCP response contained no Content (check Safe/Object/AppID)"
            )
        return password

    def _fetch_pvwa(self) -> str:
        # 1) Logon → session token
        resp = self._request(
            "POST",
            f"/PasswordVault/API/auth/{self.s.pvwa_auth_type}/Logon",
            json={"username": self.s.pvwa_username,
                  "password": self.s.pvwa_password,
                  "concurrentSession": True},
            headers={"Content-Type": "application/json"},
        )
        token = resp.json() if isinstance(resp.json(), str) else str(resp.json())
        token = token.strip('"')
        auth = {"Authorization": token}

        try:
            # 2) Find the account
            search = self.s.object_name or self.s.account_username
            resp = self._request(
                "GET", "/PasswordVault/API/Accounts",
                params={"search": search,
                        "filter": f"safeName eq {self.s.safe}"},
                headers=auth,
            )
            accounts = resp.json().get("value", [])
            if not accounts:
                raise CyberArkError(
                    f"No account matching '{search}' in safe '{self.s.safe}'"
                )
            account_id = accounts[0].get("id", "")

            # 3) Retrieve the password
            resp = self._request(
                "POST",
                f"/PasswordVault/API/Accounts/{account_id}/Password/Retrieve",
                json={"reason": "FINESIII RPA scheduled credential refresh"},
                headers={**auth, "Content-Type": "application/json"},
            )
            password = resp.json() if isinstance(resp.json(), str) else ""
            password = password.strip('"')
            if not password:
                raise CyberArkError("PVWA retrieve returned an empty password")
            return password
        finally:
            # 4) Always log off — never leave sessions dangling
            try:
                self._request("POST", "/PasswordVault/API/auth/Logoff",
                              headers=auth)
            except CyberArkError:
                if self.logger:
                    self.logger.warning("CyberArk PVWA logoff failed (non-fatal)")
