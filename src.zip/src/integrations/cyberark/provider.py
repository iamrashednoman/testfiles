"""
CyberArk password provider — scheduled fetch + in-process cache.

Client requirements implemented here:
  - The password is pulled SEVERAL TIMES ACROSS THE DAY (configurable
    interval, default every 4h) and stored in the process ENVIRONMENT —
    it is NOT fetched per request, so the CyberArk API is never
    overloaded by queue traffic.
  - CyberArk availability (Active/Inactive) is validated BEFORE every
    fetch (inside CyberArkClient.fetch_password).
  - On a failed refresh the LAST-KNOWN-GOOD password stays in place;
    the failure is logged at ERROR on the down-transition (which the
    existing email log-handler already escalates when enabled) and at
    WARNING while the outage persists.

Integration seam (zero changes to the credential path):
  - The provider writes os.environ[FINESIII_PASSWORD] — the SAME variable
    the existing CredentialManager reads.
  - attach_credentials() lets the provider update the shared
    FINESIIICredentials object in place, so all workers see a rotated
    password immediately without any worker/workflow changes.
"""

import os
import threading
import time
from datetime import datetime, timezone, timedelta
from typing import Callable, Optional

from src.integrations.cyberark.config import (
    CyberArkSettings, load_cyberark_config
)
from src.integrations.cyberark.client import (
    CyberArkClient, CyberArkError, CyberArkUnavailable
)

JST = timezone(timedelta(hours=9))


def _now_iso() -> str:
    return datetime.now(JST).isoformat()


class CyberArkPasswordProvider:
    """Caches the vault password and keeps it fresh on a schedule."""

    def __init__(self, settings: CyberArkSettings,
                 client: Optional[CyberArkClient] = None, logger=None,
                 on_unavailable: Optional[Callable[[str], None]] = None,
                 on_recovered: Optional[Callable[[], None]] = None):
        self.s = settings
        self.logger = logger
        self.client = client or CyberArkClient(settings, logger=logger)
        # Outage hooks (used by the availability-notification wiring; both
        # optional and never allowed to break a refresh).
        self._on_unavailable = on_unavailable
        self._on_recovered = on_recovered

        self._password = ""              # last-known-good
        self._credentials = None         # shared FINESIIICredentials (optional)
        self._available = True           # vault reachable at last attempt
        # The outage notice went out (not held back by the re-alert
        # floor); a held-back one is sent on a later failure (E2E-M06).
        self._outage_notified = False
        self._last_refresh_at = ""       # last SUCCESSFUL fetch
        self._last_attempt_at = ""
        self._refresh_count = 0
        self._failure_count = 0
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._thread = None
        # Set to refresh NOW (a rejected login, a console request) instead
        # of waiting for the next scheduled tick.
        self._wake = threading.Event()
        self._last_error = ""
        # True while running on a password that did NOT come from the
        # vault (the environment fallback at start); cleared by the first
        # successful refresh. Where CyberArk is required, processing is
        # paused while this is set.
        self._using_fallback = False

    # After a FAILED refresh the next attempt comes sooner than the
    # regular interval: CPM may have rotated the password during the
    # outage, and every login with the stale one counts toward lockout.
    RETRY_AFTER_FAILURE_SECONDS = 300.0

    # ── lifecycle ──────────────────────────────────────────────────

    def start(self):
        """Initial fetch + background refresh thread.

        If the very first fetch fails but the target env var already holds
        a password (e.g. set by an operator), the provider starts DEGRADED
        on that value instead of blocking service startup; with no fallback
        at all it raises, because the bot cannot log in without a password."""
        try:
            self.refresh()
        except CyberArkError as e:
            fallback = os.environ.get(self.s.target_env_var, "")
            if fallback:
                with self._lock:
                    self._password = fallback
                    self._using_fallback = True
                self._log("warning",
                          f"Initial CyberArk fetch failed ({e}) — starting on the "
                          f"password already present in {self.s.target_env_var}")
            else:
                raise RuntimeError(
                    f"CyberArk initial fetch failed and {self.s.target_env_var} "
                    f"is not set — cannot start without a password: {e}"
                )

        self._thread = threading.Thread(
            target=self._refresh_loop, daemon=True, name="cyberark-refresh"
        )
        self._thread.start()
        self._log("info",
                  f"CyberArk provider started — refresh every "
                  f"{self.s.refresh_interval_hours}h into {self.s.target_env_var}")

    def stop(self):
        self._stop.set()
        self._wake.set()
        if self._thread:
            self._thread.join(timeout=5)

    def _refresh_loop(self):
        while True:
            wait = (self.RETRY_AFTER_FAILURE_SECONDS
                    if not self.is_available()
                    else self.s.refresh_interval_seconds)
            wait = min(wait, self.s.refresh_interval_seconds)
            # Wake early on request_refresh(); exit on stop().
            woke = self._wake.wait(wait)
            if self._stop.is_set():
                return
            self._wake.clear()
            self._refreshing = True
            try:
                self.refresh()
            except CyberArkError:
                pass    # already logged + last-known-good retained
            except Exception as e:
                # ANY other failure (a non-JSON 200 from an SSO proxy, a
                # TLS error, a bug) must not kill the thread: the next
                # tick tries again and the outage hook has fired.
                self._record_unexpected(e)
            finally:
                self._refreshing = False

    def request_refresh(self) -> bool:
        """Ask for an immediate refresh (thread-safe, never blocks).
        False when one is already asked for or running: ten quick clicks
        make one fetch, not ten (UAT-L23, 2026-10-04)."""
        if getattr(self, "_refreshing", False) or self._wake.is_set():
            return False
        self._wake.set()
        return True

    def _record_unexpected(self, e: Exception) -> None:
        with self._lock:
            was_available = self._available
            self._available = False
            self._failure_count += 1
            self._last_error = f"{type(e).__name__}: {e}"
        if was_available:
            self._log("error",
                      f"CyberArk refresh failed unexpectedly — "
                      f"{self._last_error}. Keeping last-known-good password")
        else:
            self._log("warning",
                      f"CyberArk refresh still failing — {self._last_error}")
        self._notify_outage(was_available, self._last_error)

    # ── the seam into the existing credential path ─────────────────

    def attach_credentials(self, credentials):
        """Attach the shared FINESIIICredentials object. Every successful
        refresh updates it in place, so all workers (which hold this same
        reference) use the rotated password on their next login."""
        with self._lock:
            self._credentials = credentials
            if self._password:
                credentials.password = self._password

    # ── fetch / cache ──────────────────────────────────────────────

    def refresh(self) -> str:
        """Fetch from the vault NOW; update env + attached credentials.
        On failure: keep last-known-good, log (ERROR on the down-transition,
        WARNING while down), fire the outage hook, re-raise."""
        self._last_attempt_at = _now_iso()
        try:
            password = self.client.fetch_password()
        except CyberArkError as e:
            with self._lock:
                was_available = self._available
                self._available = False
                self._failure_count += 1
                self._last_error = str(e)
            reason = ("vault Inactive" if isinstance(e, CyberArkUnavailable)
                      else str(e))
            if was_available:
                # Down-transition: ERROR (the email log-handler escalates
                # ERROR/CRITICAL when notifications are enabled).
                self._log("error",
                          f"CyberArk unavailable — {reason}. Keeping "
                          f"last-known-good password"
                          + (f" from {self._last_refresh_at}"
                             if self._last_refresh_at else " (none cached yet)"))
            else:
                self._log("warning", f"CyberArk still unavailable — {reason}")
            self._notify_outage(was_available, reason)
            raise

        with self._lock:
            was_available = self._available
            self._password = password
            self._available = True
            # The card no longer shows the error of a failure that a
            # successful fetch has since resolved (UAT-L23, 2026-10-04).
            self._last_error = ""
            self._using_fallback = False
            self._last_refresh_at = _now_iso()
            self._refresh_count += 1
            credentials = self._credentials

        os.environ[self.s.target_env_var] = password
        if credentials is not None:
            credentials.password = password

        if not was_available:
            self._log("info", "CyberArk recovered — password refreshed")
        if self._outage_notified:
            # "Recovered" only after an outage people were told about; a
            # notice held back by the floor is tried on the next refresh.
            self._outage_notified = self._fire(self._on_recovered) is False
        if was_available:
            self._log("info",
                      f"CyberArk password refreshed into {self.s.target_env_var} "
                      f"(refresh #{self._refresh_count})")
        return password

    def get_password(self) -> str:
        """Cached password (fetches on demand only if nothing is cached yet)."""
        with self._lock:
            cached = self._password
        if cached:
            return cached
        return self.refresh()

    # ── introspection ──────────────────────────────────────────────

    def is_available(self) -> bool:
        with self._lock:
            return self._available

    def status(self) -> dict:
        """Provider status, safe for logs/health endpoints (no secrets)."""
        with self._lock:
            return {
                "enabled": self.s.enabled,
                "api_style": self.s.api_style,
                "available": self._available,
                "cached": bool(self._password),
                "using_fallback": self._using_fallback,
                "last_refresh_at": self._last_refresh_at,
                "last_attempt_at": self._last_attempt_at,
                "refresh_count": self._refresh_count,
                "failure_count": self._failure_count,
                "last_error": self._last_error,
                "refresh_interval_hours": self.s.refresh_interval_hours,
                "target_env_var": self.s.target_env_var,
            }

    # ── helpers ────────────────────────────────────────────────────

    def _notify_outage(self, was_available: bool, reason: str) -> None:
        """Outage notice on the down-transition, and again on a later
        failure while the last one was held back (E2E-M06)."""
        if was_available or not self._outage_notified:
            self._outage_notified = \
                self._fire(self._on_unavailable, reason) is not False

    def _fire(self, hook, *args):
        """The hook's answer: False when the notice was held back."""
        if hook is None:
            return None
        try:
            return hook(*args)
        except Exception as e:   # an alerting hook must never break a refresh
            self._log("warning", f"CyberArk outage hook failed: {e}")
            return None

    def _log(self, level: str, msg: str):
        if self.logger and hasattr(self.logger, level):
            getattr(self.logger, level)(msg)


def maybe_start_cyberark(yaml_path: Optional[str] = None, logger=None,
                         require_verified_tls: bool = False,
                         **provider_kwargs) -> Optional[CyberArkPasswordProvider]:
    """Service-startup helper: returns a STARTED provider when the
    integration is enabled, None otherwise (zero behavior change while
    disabled). Mirrors attach_email_alerts()."""
    settings = load_cyberark_config(yaml_path)
    if not settings.enabled:
        if logger:
            logger.info("CyberArk integration disabled — using env credentials as-is")
        return None
    settings.validate(require_verified_tls=require_verified_tls)
    if logger:
        logger.info(f"CyberArk integration enabled: {settings.masked()}")
    provider = CyberArkPasswordProvider(settings, logger=logger, **provider_kwargs)
    provider.start()
    return provider
