"""
Configuration loader for the CyberArk vault integration.

Mirrors the existing FINESIII patterns (env-var credentials, the
ServiceNow connector, email notifications):
  - Structural settings (API style, refresh cadence, safety flags) live
    in config/cyberark.yaml.
  - Secrets and connection values come from ENVIRONMENT VARIABLES whose
    NAMES are declared in the YAML `env_vars` block.

NEVER hardcode CyberArk credentials in source or YAML.
"""

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from src.core.app_paths import config_path
import yaml


# Default location of the CyberArk YAML (<repo-root>/config/).
DEFAULT_CONFIG_PATH = (
    config_path("cyberark.yaml")
)


@dataclass
class CyberArkSettings:
    """Fully-resolved CyberArk settings (secrets already pulled from env)."""

    # ── Master switch (default OFF → zero behavior change) ──
    enabled: bool = False

    # ── API style ──
    #   ccp  — Central Credential Provider / AIM Web Service (agentless GET;
    #          the standard for unattended bots; supports client-cert auth)
    #   pvwa — PVWA REST (logon → search account → retrieve → logoff)
    api_style: str = "ccp"

    # ── Connection (from env) ──
    base_url: str = ""              # e.g. https://cyberark.corp.example.com
    app_id: str = ""                # CCP Application ID
    safe: str = ""                  # Safe holding the FINESIII account
    object_name: str = ""           # Object name of the account (CCP query)
    account_username: str = ""      # Alternative CCP query: UserName=
    # PVWA auth (only for api_style: pvwa)
    pvwa_username: str = ""
    pvwa_password: str = ""
    pvwa_auth_type: str = "CyberArk"   # CyberArk | LDAP | RADIUS
    # Mutual-TLS client certificate (recommended for CCP)
    client_cert_path: str = ""
    client_key_path: str = ""

    # ── Where the fetched password goes ──
    # The existing CredentialManager reads FINESIII_PASSWORD from the env;
    # the provider populates this SAME variable, so the credential path
    # needs no changes at all.
    target_env_var: str = "FINESIII_PASSWORD"

    # ── Refresh cadence (client requirement: several times a day, cached
    #    in env — NOT fetched per request, to avoid overloading CyberArk) ──
    refresh_interval_hours: float = 4.0

    # ── Availability check (client requirement: validate Active/Inactive
    #    BEFORE fetching from the vault) ──
    health_check_enabled: bool = True
    health_path: str = ""           # blank → derived from api_style

    # ── Networking / resilience ──
    http_timeout_seconds: float = 30.0
    max_retries: int = 3
    backoff_base_seconds: float = 1.0
    backoff_max_seconds: float = 30.0
    verify_tls: bool = True

    @property
    def refresh_interval_seconds(self) -> float:
        return max(self.refresh_interval_hours, 0.0) * 3600.0

    @property
    def effective_health_path(self) -> str:
        """Health probe path. CCP exposes no dedicated health endpoint, so we
        probe the AIM service route itself — ANY well-formed HTTP response
        (even 4xx) proves the service is up; only network errors / 5xx mean
        Inactive. PVWA ships a public verify endpoint."""
        if self.health_path:
            return self.health_path
        if self.api_style == "pvwa":
            return "/PasswordVault/API/Verify"
        return "/AIMWebService/api/Accounts"

    def validate(self, require_verified_tls: bool = False):
        """Validate that the minimum live-connection settings are present.
        Only enforced when the integration is enabled.

        require_verified_tls: where CyberArk is required (production), the
        mainframe password is never fetched over a connection whose
        certificate is not checked (CA-01, 2026-10-03)."""
        if not self.enabled:
            return True
        errors = []
        if not self.base_url:
            errors.append("base_url is empty (set CYBERARK_BASE_URL)")
        from src.core.urls import web_address_problem
        problem = web_address_problem(self.base_url)
        if problem:
            errors.append(f"base_url '{self.base_url}' {problem}")
        if require_verified_tls and not self.verify_tls:
            errors.append("verify_tls is off — the certificate must be "
                          "checked where CyberArk is required (set "
                          "CYBERARK_VERIFY_TLS=true)")
        if self.api_style == "ccp":
            if not self.app_id:
                errors.append("app_id is empty (set CYBERARK_APP_ID)")
            if not self.safe:
                errors.append("safe is empty (set CYBERARK_SAFE)")
            if not (self.object_name or self.account_username):
                errors.append(
                    "no account query set (set CYBERARK_OBJECT or "
                    "CYBERARK_ACCOUNT_USERNAME)"
                )
        elif self.api_style == "pvwa":
            if not (self.pvwa_username and self.pvwa_password):
                errors.append(
                    "pvwa selected but CYBERARK_PVWA_USER / "
                    "CYBERARK_PVWA_PASSWORD missing"
                )
            if not self.safe:
                errors.append("safe is empty (set CYBERARK_SAFE)")
            if not (self.object_name or self.account_username):
                errors.append(
                    "no account query set (set CYBERARK_OBJECT or "
                    "CYBERARK_ACCOUNT_USERNAME)"
                )
        else:
            errors.append(f"unknown api_style '{self.api_style}' (use ccp|pvwa)")
        if self.refresh_interval_hours <= 0:
            errors.append("refresh_interval_hours must be > 0")
        if errors:
            raise ValueError(
                "CyberArk configuration invalid:\n" +
                "\n".join(f"  - {e}" for e in errors)
            )
        return True

    def masked(self) -> dict:
        """Connection summary safe for logging (secrets never shown)."""
        return {
            "enabled": self.enabled,
            "api_style": self.api_style,
            "base_url": self.base_url,
            "app_id": self.app_id,
            "safe": self.safe,
            "object_name": self.object_name,
            "account_username": self.account_username,
            "pvwa_username": self.pvwa_username,
            "pvwa_password": "****" if self.pvwa_password else "(unset)",
            "client_cert": "set" if self.client_cert_path else "(unset)",
            "target_env_var": self.target_env_var,
            "refresh_interval_hours": self.refresh_interval_hours,
            "health_check_enabled": self.health_check_enabled,
        }


def _env(name: str, default: str = "") -> str:
    return os.environ.get(name, default) or default


def _env_bool(name: str, default: bool) -> bool:
    raw = os.environ.get(name, "")
    if not raw:
        return default
    return raw.strip().lower() in ("1", "true", "yes", "on")


def load_cyberark_config(yaml_path: Optional[str] = None) -> CyberArkSettings:
    """Load config/cyberark.yaml and resolve secrets from the environment.

    The YAML declares the env-var NAMES (mirroring the notifications and
    ServiceNow configs). Actual values are read from os.environ here,
    so secrets stay out of the repo.
    """
    if yaml_path is None:
        yaml_path = DEFAULT_CONFIG_PATH
    yaml_path = Path(yaml_path)
    if not yaml_path.exists():
        raise FileNotFoundError(f"CyberArk config not found: {yaml_path}")

    with open(yaml_path, "r", encoding="utf-8") as f:
        raw = yaml.safe_load(f) or {}

    ca = raw.get("cyberark", {})
    env_vars = ca.get("env_vars", {})
    fetch = ca.get("fetch", {})
    refresh = ca.get("refresh", {})
    health = ca.get("health", {})
    net = ca.get("network", {})

    return CyberArkSettings(
        enabled=_env_bool(
            env_vars.get("enabled", "CYBERARK_ENABLED"),
            bool(ca.get("enabled", False)),
        ),
        api_style=_env(env_vars.get("api_style", "CYBERARK_API_STYLE"),
                       str(ca.get("api_style", "ccp"))).strip().lower(),
        # connection (secrets from env)
        base_url=_env(env_vars.get("base_url", "CYBERARK_BASE_URL")).rstrip("/"),
        app_id=_env(env_vars.get("app_id", "CYBERARK_APP_ID")),
        safe=_env(env_vars.get("safe", "CYBERARK_SAFE")),
        object_name=_env(env_vars.get("object_name", "CYBERARK_OBJECT")),
        account_username=_env(
            env_vars.get("account_username", "CYBERARK_ACCOUNT_USERNAME")
        ),
        pvwa_username=_env(env_vars.get("pvwa_username", "CYBERARK_PVWA_USER")),
        pvwa_password=_env(env_vars.get("pvwa_password", "CYBERARK_PVWA_PASSWORD")),
        pvwa_auth_type=_env(
            env_vars.get("pvwa_auth_type", "CYBERARK_PVWA_AUTH_TYPE"),
            ca.get("pvwa_auth_type", "CyberArk")),
        client_cert_path=_env(env_vars.get("client_cert_path", "CYBERARK_CERT_PATH")),
        client_key_path=_env(env_vars.get("client_key_path", "CYBERARK_KEY_PATH")),
        # target
        target_env_var=fetch.get("target_env_var", "FINESIII_PASSWORD"),
        # refresh cadence
        refresh_interval_hours=_env_float(
            env_vars.get("refresh_hours", "CYBERARK_REFRESH_HOURS"),
            float(refresh.get("interval_hours", 4.0))),
        # health
        health_check_enabled=_env_bool(
            env_vars.get("health_check", "CYBERARK_HEALTH_CHECK"),
            bool(health.get("enabled", True))),
        health_path=health.get("path", ""),
        # network
        http_timeout_seconds=float(net.get("timeout_seconds", 30.0)),
        max_retries=int(net.get("max_retries", 3)),
        backoff_base_seconds=float(net.get("backoff_base_seconds", 1.0)),
        backoff_max_seconds=float(net.get("backoff_max_seconds", 30.0)),
        verify_tls=_env_bool(env_vars.get("verify_tls", "CYBERARK_VERIFY_TLS"),
                             bool(net.get("verify_tls", True))),
    )


def _env_float(name: str, default: float) -> float:
    raw = os.environ.get(name, "")
    if not raw:
        return default
    try:
        return float(raw)
    except ValueError:
        return default
