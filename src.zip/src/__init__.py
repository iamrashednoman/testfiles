"""Application factory for the orchestrator control plane.

Wires configuration → database → stores → dispatcher → routes.
Accepts an explicit config for tests; nothing at import time touches
the network or database. When no executor is available for the
configured terminal driver (e.g. the Linux control plane before the
rpa-layer port), the service runs API-only: requests queue up and a
worker processes them when attached.
"""
from __future__ import annotations

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI

from config import get_config
from src import extensions
from src.core.retry import RetryPolicy
from src.modules.audit.services import TransactionStore
from src.modules.auth.services import build_auth_dependency
from src.modules.intake.routes import build_router
from src.integrations.cyberark import maybe_start_cyberark
from src.modules.audit.trail import maybe_start_audit_trail
from src.modules.notifications import (
    attach_email_alerts, build_availability_alerter,
    build_rejection_alerter, build_transaction_alerter,
)
from src.modules.queue.availability import AvailabilityMonitor
from src.modules.queue.dispatcher import (
    Dispatcher, build_executor, installation_id, recover_on_startup,
)
from src.modules.queue.services import QueueStore

logger = logging.getLogger("finesiii_rpa_v3")


def _snow_intake_clients(cfg):
    """API client names allowed to submit ServiceNow ticket details.
    None (no restriction) when API-key auth is off."""
    if not getattr(cfg, "auth_enabled", False):
        return None
    configured = [c.strip() for c in
                  str(getattr(cfg, "snow_intake_clients", "") or "").split(",")
                  if c.strip()]
    if configured:
        return set(configured)
    import os
    for entry in os.environ.get("FINESIII_API_KEYS", "").split(","):
        entry = entry.strip()
        if entry:
            name = entry.split(":", 1)[0].strip() if ":" in entry else "default"
            return {name or "unnamed"}
    return None


def server_time_zone_warning() -> str:
    """'' when this server runs on Japan time (UTC+09:00, Tokyo Standard
    Time); otherwise what follows the server clock (E2E-L03)."""
    import time as _time
    try:
        offset = _time.localtime().tm_gmtoff
    except Exception:
        return ""
    if offset is None or offset == 9 * 3600:
        return ""
    hours = offset / 3600
    return (f"This server's clock is not on Japan time (it is UTC"
            f"{hours:+g}). Transaction IDs, screenshot names and the time "
            f"on evidence follow the server clock, while the console and "
            f"e-mails show JST. Set the server's time zone to (UTC+09:00) "
            f"Osaka, Sapporo, Tokyo.")


def create_app(cfg=None, restart_hook=None) -> FastAPI:
    """Build the service.

    restart_hook: supplied by the desktop shell so the console can
    rebuild the service after a settings change. None everywhere else —
    a service that cannot restart itself says so rather than pretending.
    """
    cfg = cfg or get_config()

    # The service log first, so warnings from the stored settings below
    # reach the log file and the console's log view (NB-024). The later
    # call after build_executor finds this handler and keeps it.
    from src.core.logging import attach_service_log
    from src.core.app_paths import resolve as _resolve_path
    attach_service_log(_resolve_path(cfg.log_dir, kind="data"),
                       level=getattr(cfg, "log_level", "INFO"),
                       retention_days=getattr(cfg, "log_retention_days", 30))

    # Settings that need the operator's attention although requests are
    # still processed — shown on the dashboard and the System page next
    # to the start-up problems.
    startup_warnings: list[str] = []

    # Production on SQLite is allowed (single-machine installs), but it
    # is not the recommended database there — say so in the log.
    from config.production import ProductionConfig
    if isinstance(cfg, ProductionConfig) and cfg.database_engine == "sqlite":
        logger.warning(
            "Production is running on SQLite. PostgreSQL is recommended "
            "for production (shared access, backups, audit); SQLite is "
            "suitable for a single machine only.")

    db = extensions.init_extensions(cfg)

    # Administrator overrides, layered on top of env/defaults BEFORE
    # anything reads the configuration. This is what makes a
    # "restart required" setting genuinely take effect on rebuild.
    settings_store = None
    # What the start summary (printed before the build) showed, to say
    # which of it the stored console settings change (UAT-L06).
    _summary = {k: getattr(cfg, k, None) for k in (
        "ocr_enabled", "dispatcher_enabled", "audit_enabled",
        "terminal_driver")}
    try:
        from src.modules.console.settings_store import (
            SettingsStore, SettingsUnavailableError, apply_overrides,
        )
        settings_store = SettingsStore(db)
        apply_overrides(cfg, settings_store, logger)
    except Exception as e:
        settings_store = None
        logger.warning(
            f"Administrator settings unavailable ({e}) — running on "
            f"environment configuration only.")
    # Stored values from an earlier version that no longer apply: a
    # STARTTLS + implicit SSL pair is resolved (NB-010), an invalid
    # value is ignored and reported (NB-024).
    tls_fix = None
    if settings_store is not None:
        from src.modules.console.settings_catalogue import BY_KEY as _SPECS
        from src.modules.console.settings_store import (
            invalid_at_build, resolve_tls_conflict,
        )
        try:
            tls_fix = resolve_tls_conflict(settings_store, logger)
        except Exception as e:
            logger.warning(f"Could not resolve the stored e-mail "
                           f"encryption settings: {e}")
        if tls_fix:
            startup_warnings.append(
                f"E-mail: {_SPECS[tls_fix['switched_off']]['label']} was "
                f"switched Off automatically (STARTTLS and implicit SSL "
                f"were both On; port {tls_fix['port']}).")
        for _key in invalid_at_build():
            _label = _SPECS.get(_key, {}).get("label", _key)
            startup_warnings.append(
                f"Stored setting '{_label}' ({_key}) is not valid and is "
                f"ignored; enter it again under Settings.")
    # Values stored before the cross-setting rules existed (UAT-07,
    # 2026-10-04), and APP_ENV set differently in the two settings files
    # (CFG-02).
    from src.modules.console.settings_store import startup_cross_checks
    startup_warnings.extend(startup_cross_checks(cfg, settings_store, logger))
    from config import app_env_conflict
    _conflict = app_env_conflict()
    if _conflict:
        startup_warnings.append(_conflict)
        logger.warning(_conflict)
    # Transaction IDs, screenshot names and the evidence "Captured" time
    # follow the server's clock; the console shows JST (E2E-L03).
    _tz_note = server_time_zone_warning()
    if _tz_note:
        startup_warnings.append(_tz_note)
        logger.warning(_tz_note)
    _changed = [f"{k.replace('_', ' ')}: {getattr(cfg, k, None)}"
                for k, v in _summary.items() if getattr(cfg, k, None) != v]
    if _changed:
        logger.info("Stored console settings change the start summary: "
                    + "; ".join(_changed))
    queue_store = QueueStore(db)
    queue_store.keep_failed_password = int(
        getattr(cfg, "failed_password_retention_days", 7) or 0) > 0
    transaction_store = TransactionStore(db)

    # Console sign-in for PEOPLE (Phase 2). Independent of the machine
    # API key — a console session never grants API-key scope (and vice
    # versa) unless auth_console_grants_api is on, the desktop-only mode
    # in which the intake routes also accept a permission-checked
    # console session. Inert unless auth_console_enabled.
    user_store = None
    auth_service = None
    if cfg.auth_console_enabled:
        from src.modules.auth.services import AuthService
        from src.modules.auth.store import SchemaUnavailableError, UserStore
        try:
            user_store = UserStore(db)
            # Built-in roles are code, not configuration: reseeded on
            # every start so a permission added in a release reaches
            # admin without a migration. Custom roles are untouched.
            user_store.ensure_builtin_roles()
            auth_service = AuthService(user_store, cfg, logger=logger)
            # Earlier password hashes live in the settings table (SEC-07).
            auth_service.settings = settings_store
            # Default administrator on a FRESH install only — never a
            # second one, and never a resurrected deleted account.
            auth_service.seed_default_admin()
            _pending = auth_service.initial_admin_pending()
            if _pending is not None:
                logger.warning(
                    f"The console administrator '{_pending.username}' "
                    f"has not chosen its own password yet. Sign in as "
                    f"'{_pending.username}' and choose a new password "
                    f"now.")
        except SchemaUnavailableError as e:
            # The console is an ADDITION. It must never stop the queue,
            # the dispatcher or the intake API from starting — those
            # are what actually process the client's tickets.
            user_store = auth_service = None
            logger.error(
                f"Admin console DISABLED — {e}. Apply the console "
                f"tables with:  psql -d finesiii_v3 -f "
                f"scripts/schema.sql   (or set "
                f"AUTH_CONSOLE_ENABLED=false to silence this). The "
                f"API, queue and dispatcher are unaffected.")

    # Built AFTER the console service so the desktop mode above can
    # verify Bearer sessions; with the flag off auth_service is unused.
    auth_dep = build_auth_dependency(cfg, auth_service)

    # Anything that stops the bot from PROCESSING but not from serving
    # the console. Empty on a healthy start; shown on the System page.
    startup_problems: list[str] = []

    try:
        executor = build_executor(cfg)
    except Exception as e:
        if not getattr(cfg, "startup_degraded_mode", False):
            raise                          # server: fail fast, as always
        executor = None
        startup_problems.append(
            f"Terminal executor could not be built — "
            f"{str(e).rstrip('.')}. Processing is "
            f"disabled until the FINESIII settings are completed and the "
            f"service is restarted.")
        logger.error(startup_problems[-1])

    # Email notifications — inert (None) unless config/notifications.yaml
    # + SMTP env vars enable them. Attached AFTER build_executor: the
    # executor's TransactionLogger clears handlers on the rpa logger.
    # The service's own messages go to the log file as well (SN-08).
    # After build_executor, which resets the RPA logger's handlers.
    from src.core.logging import attach_service_log
    from src.core.app_paths import resolve as _resolve_path
    attach_service_log(_resolve_path(cfg.log_dir, kind="data"),
                       level=getattr(cfg, "log_level", "INFO"),
                       retention_days=getattr(cfg, "log_retention_days", 30))

    alert_handler = attach_email_alerts(
        logger=logger, environment=cfg.mainframe_environment)
    # E-mail switched on but not usable: every e-mail is off, which used
    # to show only in the log (NB-010).
    if alert_handler is None:
        try:
            from src.modules.notifications.config import (
                load_notification_config,
            )
            _mail = load_notification_config()
            if _mail.enabled:
                _mail.validate()
        except ValueError as e:
            _reason = str(e).removeprefix("notifications: ").rstrip(".")
            startup_warnings.append(
                f"E-mail is switched off: {_reason}. Correct it under "
                f"Settings > E-mail and restart.")
        except Exception:
            pass

    # Audit event trail — inert (None) unless audit_enabled. Spools
    # locally and flushes to the separate audit database; also attached
    # after build_executor (same handler-clearing constraint).
    audit = maybe_start_audit_trail(cfg, logger)
    if tls_fix and audit is not None:
        try:
            audit.event("system", "settings_migrated", severity="WARNING",
                        actor="system", detail=tls_fix)
        except Exception:
            pass
    avail_alerter = build_availability_alerter(alert_handler, logger)
    txn_alerter = build_transaction_alerter(alert_handler, logger=logger)
    if alert_handler is not None and txn_alerter is not None and \
            getattr(txn_alerter.s, "notify_on_failure", False):
        # One e-mail per failed transaction (E2E-L10): the bot's own
        # step / transaction failure lines are not e-mailed as well,
        # nor on every attempt; they stay in the log and the digest.
        def _transaction_failure_line(record):
            if record.name != "finesiii_rpa_v3.rpa" or \
                    record.levelno >= logging.CRITICAL:
                return False
            text = record.getMessage()
            return "[NG] Failed: " in text or "=== Transaction FAILED: " in text
        alert_handler.suppress_checks.append(_transaction_failure_line)
    rejection_alerter = build_rejection_alerter(
        logger=logger, environment=cfg.mainframe_environment)

    # CyberArk scheduled credential refresh — None unless enabled in
    # config/cyberark.yaml (or CYBERARK_ENABLED). When active it rotates
    # the executor's in-memory credentials without a restart.
    # Fail SOFT (2026-09-26): a missing yaml, an invalid setting or a
    # failed first fetch used to abort the whole service. It is now
    # logged, alerted and reported; the bot runs on the vault/environment
    # credentials until the next restart.
    cyberark = None
    try:
        cyberark = maybe_start_cyberark(
            logger=logger,
            # Where CyberArk is required, its certificate must be
            # checked (CA-01, 2026-10-03).
            require_verified_tls=bool(getattr(cfg, "require_cyberark",
                                              False)),
            on_unavailable=(avail_alerter.cyberark_down
                            if avail_alerter else None),
            on_recovered=(avail_alerter.cyberark_recovered
                          if avail_alerter else None),
        )
    except Exception as e:
        logger.error(f"CyberArk integration failed to start — {e}. "
                     f"Running on the vault/environment credentials.")
        startup_problems.append(f"CyberArk integration failed to start: {e}")
        if avail_alerter is not None:
            try:
                avail_alerter.cyberark_down(str(e))
            except Exception:
                pass
    if cyberark is not None and hasattr(executor, "credentials"):
        cyberark.attach_credentials(executor.credentials)

    # ADR 7 / require_cyberark (enforced since 2026-09-26, D16): with a
    # real terminal driver in a fail-closed environment the mainframe
    # password MUST come from CyberArk. Degraded mode (desktop) blocks
    # processing and says so; a server refuses to start.
    if cfg.require_cyberark and cfg.terminal_driver in (
            "pywinauto", "pyautogui", "tn3270") and cyberark is None:
        problem = ("CyberArk is required here (require_cyberark with a "
                   "real terminal driver) but is not enabled or did not "
                   "start. Enable it under Settings → CyberArk and "
                   "restart; set REQUIRE_CYBERARK=false only outside "
                   "production.")
        if not getattr(cfg, "startup_degraded_mode", False):
            raise RuntimeError(problem)
        if executor is not None:
            executor = None
        startup_problems.append(problem)
        logger.error(problem)

    # CyberArk required and running, but the password in use is the
    # environment fallback (the first vault fetch failed): processing is
    # paused until CyberArk delivers, then resumes by itself. The problem
    # text is computed live, so it disappears once the vault answers.
    can_process = None
    live_problems: list = []
    # Live warnings: shown, but requests are still processed (E2E-L17).
    live_warnings: list = []
    if cfg.require_cyberark and cfg.terminal_driver in (
            "pywinauto", "pyautogui", "tn3270") and cyberark is not None:
        fallback_problem = (
            "CyberArk is required here but has not delivered the mainframe "
            "password yet — the bot is on the password from the "
            "environment. Processing is paused and resumes automatically "
            "once CyberArk delivers the password.")

        def can_process():
            try:
                return not cyberark.status().get("using_fallback", False)
            except Exception:
                return False

        def _cyberark_gate_problem():
            return "" if can_process() else fallback_problem
        live_problems.append(_cyberark_gate_problem)
        if not can_process():
            logger.error(fallback_problem)

    # Real-login probe only when configured AND a terminal executor
    # exists (it reuses the executor's driver config + credentials).
    login_probe = None
    if cfg.probe_method == "login" and hasattr(executor, "rpa_config"):
        from src.rpa.login_probe import build_login_probe
        login_probe = build_login_probe(
            executor.rpa_config, executor.credentials, logger)

    availability = AvailabilityMonitor(
        cfg, logger, login_probe_func=login_probe,
        on_unavailable=(avail_alerter.finesiii_down
                        if avail_alerter else None),
        on_recovered=(avail_alerter.finesiii_recovered
                      if avail_alerter else None))

    # Completion hooks: the outcome emails (existing) plus the ServiceNow
    # ticket close-out (2026-09-26). Each hook is isolated — one failing
    # never stops the others, and none can affect the dispatcher.
    completion_hooks = []
    if txn_alerter is not None:
        completion_hooks.append(txn_alerter.handle_completion)
    try:
        from src.integrations.servicenow.writeback import TicketCloseout
        ticket_closeout = TicketCloseout(logger=logger, audit=audit)
        ticket_closeout.queue_store = queue_store
        completion_hooks.append(ticket_closeout.handle_completion)
    except Exception as e:
        ticket_closeout = None
        logger.warning(f"ServiceNow ticket close-out unavailable: {e}")

    # SailPoint ticket e-mails (2026-09-28): the support report once per
    # ticket and the separate registration / password notices to the
    # user. Needs e-mail (SMTP) on; each switch is checked at send time.
    ticket_reporter = None
    # Every e-mail is audited — the rejection e-mails use their own
    # sender (2026-09-28).
    if rejection_alerter is not None:
        rejection_alerter.notifier.audit = audit
    # E-mail branding from the console Branding page (2026-09-28): every
    # sender reads it at send time, so a change applies to the next
    # e-mail without a restart.
    if settings_store is not None:
        from src.modules.console import branding as _branding

        def _email_branding():
            return _branding.load(settings_store)
        for _sender in {id(n): n for n in (
                getattr(alert_handler, "notifier", None),
                getattr(rejection_alerter, "notifier", None),
                getattr(avail_alerter, "notifier", None)) if n}.values():
            _sender.branding_source = _email_branding
    if alert_handler is not None:
        try:
            alert_handler.notifier.audit = audit      # every e-mail audited
            from src.modules.notifications.ticket_reports import (
                TicketReporter,
            )
            ticket_reporter = TicketReporter(alert_handler.notifier,
                                             logger=logger)
            ticket_reporter.queue_store = queue_store
            completion_hooks.append(ticket_reporter.handle_completion)
            if txn_alerter is not None:
                txn_alerter.ticket_reports_active = True
        except Exception as e:
            ticket_reporter = None
            logger.warning(f"SailPoint ticket e-mails unavailable: {e}")

    # Terminal check for the console (2026-09-29, T1): only with a
    # terminal executor.
    terminal_check = None
    if executor is not None:
        from src.rpa.terminal_check import TerminalCheck
        terminal_check = TerminalCheck(executor, logger=logger, audit=audit,
                                       store=settings_store)

    # E-mail services (2026-09-29): the outbox that resends failed
    # e-mails, the database outage notice, the console banner while
    # e-mail delivery fails, and the start / stop notices.
    email_services = None
    if alert_handler is not None:
        try:
            from src.modules.notifications.service import EmailServices
            email_services = EmailServices(
                alert_handler, avail_alerter, audit=audit,
                queue_store=queue_store, logger=logger)
            # Mail delivery failing does not stop processing (E2E-L17).
            live_warnings.append(email_services.delivery_problem)
        except Exception as e:
            email_services = None
            logger.warning(f"E-mail services unavailable: {e}")
    # E-mail switched off (or kept hours 0): e-mails kept earlier would
    # never be sent nor expire, and they hold names and codes (EM-05,
    # 2026-10-03). A configuration that is only wrong keeps them.
    try:
        from src.modules.notifications.config import (
            load_notification_config as _mail_config,
        )
        _mail = _mail_config()
        if not _mail.enabled or int(_mail.outbox_hours or 0) <= 0:
            from src.core.app_paths import data_path
            from src.modules.notifications.outbox import purge_outbox_folder
            _gone = purge_outbox_folder(data_path("mail_outbox"))
            if _gone:
                logger.warning(f"E-mail is switched off: {_gone} kept "
                               f"e-mail(s) removed from the outbox")
    except Exception:
        pass

    def _on_complete(txn, request, result):
        for hook in completion_hooks:
            try:
                hook(txn, request, result)
            except Exception as e:
                logger.warning(f"completion hook failed: {e}")

    def _on_superseded(request, reason):
        """An older ticket not executed because a newer opposite one
        already ran (NB-001): the same outputs as a ticket held as a
        duplicate at pickup — the rejection e-mail and the ticket note.
        Each on its own."""
        if rejection_alerter is not None:
            try:
                newer = ticket_closeout.superseding_request(request)
                orig = getattr(newer, "ticket_id", "") or ""
                rejection_alerter.request_rejected(
                    "DUPLICATE REQUEST",
                    f"Superseded by ticket {orig} (request "
                    f"{getattr(newer, 'request_id', '')}, status "
                    f"{getattr(newer, 'status', '')}): {reason}",
                    {"ticket_id": request.ticket_id,
                     "sys_id": ticket_closeout._sys_id(request),
                     "source": request.source,
                     "operation": request.operation,
                     "affiliation_code": request.affiliation_code,
                     "employee_code": request.employee_code,
                     "original_ticket_id": orig,
                     "original_request_id": getattr(newer, "request_id", ""),
                     "original_status": getattr(newer, "status", ""),
                     "matching_fields": "affiliation code, employee code "
                                        "(opposite operation)"})
            except Exception as e:
                logger.warning(f"Superseded-request e-mail failed: {e}")
        try:
            _note_ticket(request.request_id)
        except Exception as e:
            logger.warning(f"Superseded-request ticket note failed: {e}")

    def _note_ticket(request_id):
        """The ticket's write-back for a request that ended without
        running (superseded, or cancelled by an operator: E2E-L14)."""
        from src.integrations.servicenow.writeback import _RequestView
        fresh = queue_store.get(request_id)
        if fresh is not None:
            ticket_closeout.handle_completion(_RequestView(fresh), fresh, {})

    # This installation's id on every row it claims, so a second
    # installation sharing the database never recovers its work.
    worker_id = installation_id()

    dispatcher = None
    if executor is not None and cfg.dispatcher_enabled:
        dispatcher = Dispatcher(
            queue=queue_store,
            transactions=transaction_store,
            retry_policy=RetryPolicy(
                max_attempts=cfg.max_attempts,
                base_delay=cfg.retry_backoff_base_seconds,
                backoff_factor=cfg.retry_backoff_factor,
                max_delay=cfg.retry_max_delay_seconds,
            ),
            executor=executor,
            cfg=cfg,
            logger=logger,
            availability=availability,
            on_complete=_on_complete,
            audit=audit,
            # Lets the dispatcher sweep expired console sessions on its
            # existing loop (app_sessions would otherwise grow forever).
            user_store=user_store,
            # A rejected mainframe password → refresh from CyberArk NOW
            # (CPM may have rotated it) instead of at the next 4h tick.
            on_password_rejected=(cyberark.request_refresh
                                  if cyberark is not None else None),
            # A ServiceNow task closed or taken over after pickup is not
            # executed (2026-09-28). Other sources are not affected.
            pre_execute=(ticket_closeout.pre_execute_check
                         if ticket_closeout is not None else None),
            worker_id=worker_id,
            can_process=can_process,
            # An older ServiceNow ticket is not executed once a newer
            # opposite ticket for the same account has run (NB-001).
            superseded_check=(ticket_closeout.superseded_reason
                              if ticket_closeout is not None else None),
            on_superseded=(_on_superseded
                           if ticket_closeout is not None else None),
        )
        # A pause set on the System page outlives a restart, a crash or
        # a reboot (OPS-01, 2026-10-04): processing never resumes on its
        # own.
        if settings_store is not None:
            try:
                import json as _json
                _pause = settings_store.all().get("PROCESSING_PAUSED")
                if _pause:
                    _info = _json.loads(_pause) or {}
                    dispatcher.pause(by=str(_info.get("by", "")),
                                     at=str(_info.get("at", "")))
                    logger.warning(
                        f"Processing is paused (by {_info.get('by', '?')} "
                        f"since {_info.get('at', '?')}) — resume it on the "
                        f"System page.")
            except Exception as e:
                logger.warning(f"The stored pause could not be read: {e}")
        # The login probe shares the service account — defer it while
        # a transaction is in flight.
        availability.busy_check = lambda: (
            dispatcher.status()["busy"]
            or bool(terminal_check is not None and terminal_check.running))

    # The clean-up runs on its own timer, also while processing is off
    # or the service started without a terminal (SY-01, 2026-10-03).
    # Evidence is never removed while a transaction is on the terminal.
    from src.modules.queue.housekeeping import Housekeeper
    housekeeper = Housekeeper(
        queue_store, cfg, logger=logger, audit=audit, user_store=user_store,
        busy=lambda: bool(dispatcher is not None
                          and dispatcher.status()["busy"]))

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        # Journaled completions first, then orphaned running rows (own,
        # legacy or past the lease; "70" already sent → UNCONFIRMED).
        # Rows finished as UNCONFIRMED get their history record and the
        # unconfirmed e-mail / ticket note (NB-003).
        recover_on_startup(queue_store, cfg, worker_id, audit=audit,
                           logger=logger, transactions=transaction_store,
                           on_complete=_on_complete,
                           operator=getattr(executor, "operator", ""))
        availability.start()
        housekeeper.start()
        if dispatcher is not None:
            dispatcher.start()
            logger.info("Dispatcher started")
        else:
            logger.info("API-only mode — no executor for driver "
                        f"'{cfg.terminal_driver}'")
        if email_services is not None:
            try:
                problems = list(startup_problems)
                for check in live_problems:
                    try:
                        text = check()
                    except Exception:
                        text = ""
                    if text:
                        problems.append(text)
                email_services.start(problems)
            except Exception as e:
                logger.warning(f"E-mail services did not start: {e}")
        yield
        if dispatcher is not None:
            dispatcher.stop()
        housekeeper.stop()
        availability.stop()
        if cyberark is not None:
            cyberark.stop()
        if audit is not None:
            audit.close()           # drain the audit spool
        if email_services is not None:
            try:
                email_services.stop()
            except Exception:
                pass
        if alert_handler is not None:
            alert_handler.close()   # flush digest, drain send queue
        db.close()

    # The API description is served without sign-in, so only on a
    # development service that has no API key either — and never with
    # the real terminal (E2E-L32).
    expose_docs = (bool(cfg.debug) and not bool(cfg.auth_enabled)
                   and str(getattr(cfg, "terminal_driver", "")).lower()
                   not in ("pywinauto", "pyautogui", "tn3270"))
    app = FastAPI(
        title="FINESIII RPA Orchestrator",
        version="3.0.0",
        docs_url="/api/docs" if expose_docs else None,
        redoc_url="/redoc" if expose_docs else None,
        openapi_url="/openapi.json" if expose_docs else None,
        lifespan=lifespan,
    )
    # Request bodies are limited in size before anything reads them
    # (X-09, 2026-10-03): 2 MB for Branding images, 256 KB elsewhere.
    from src.core.body_limit import BodySizeLimit
    app.add_middleware(BodySizeLimit)
    # The console's session cookie becomes the usual Authorization
    # header, so every session check works unchanged (SES-01,
    # 2026-10-04). Callers that send their own header or an API key are
    # not touched.
    from src.modules.auth.cookie import ConsoleSessionCookie
    app.add_middleware(ConsoleSessionCookie)
    # Browser security headers on every answer, the console page and
    # the API alike (SEC-04, 2026-10-04). Added last, so it is the
    # outermost layer and also covers refusals from the layers above.
    from src.core.security_headers import SecurityHeaders
    app.add_middleware(SecurityHeaders)
    # Database not reachable → 503 with Retry-After, not a bare 500 (NB-015).
    from src.modules.intake.routes import database_errors, database_unavailable
    for _db_error in database_errors():
        app.add_exception_handler(_db_error, database_unavailable)
    app.state.config = cfg
    app.state.queue_store = queue_store
    app.state.transaction_store = transaction_store
    app.state.dispatcher = dispatcher
    app.state.housekeeper = housekeeper
    app.state.email_services = email_services
    # The console's terminal check (2026-09-29, T1): the same executor,
    # credentials and navigator as a request.
    app.state.executor = executor
    app.state.terminal_check = terminal_check
    app.state.availability = availability
    app.state.audit = audit
    app.state.cyberark = cyberark
    app.state.startup_problems = startup_problems
    app.state.startup_warnings = startup_warnings
    # Callables returning a current problem text ("" = none) — shown next
    # to the startup problems and gone as soon as the cause clears.
    app.state.live_problems = live_problems
    app.state.live_warnings = live_warnings
    app.state.worker_id = worker_id
    # Shared by the in-agent ServiceNow poller (rejection emails, polling
    # outage alerts) and available to the console.
    app.state.rejection_alerter = rejection_alerter
    app.state.availability_alerter = avail_alerter
    app.state.ticket_closeout = ticket_closeout
    app.state.ticket_reporter = ticket_reporter
    app.state.completion_hooks = completion_hooks

    # Console actions require the matching permission from a signed-in
    # PERSON — requests.retry for retry, requests.cancel for cancel (one
    # shared dependency used to guard both, which made the cancel
    # permission dead). The machine API key passes through unchanged.
    action_dep = cancel_dep = submit_dep = console_deps = None
    if auth_service is not None:
        from src.modules.auth.services import (
            build_action_dependency, build_permission_dependency,
        )
        action_dep = build_action_dependency(
            auth_service, cfg, "requests.retry")
        cancel_dep = build_action_dependency(
            auth_service, cfg, "requests.cancel")
        # Submitting from the console needs requests.submit (RQ-12).
        submit_dep = build_action_dependency(
            auth_service, cfg, "requests.submit")
        # The console's own routes, by permission only (RQ-01): they
        # work whether or not the machine API key is switched on.
        console_deps = {
            name: build_permission_dependency(auth_service, permission)
            for name, permission in (
                ("view", "requests.view"), ("audit", "audit.view"),
                ("submit", "requests.submit"), ("retry", "requests.retry"),
                ("cancel", "requests.cancel"))}

    app.include_router(build_router(
        queue_store, transaction_store, dispatcher, auth_dep, cfg,
        availability=availability,
        on_rejected=(rejection_alerter.request_rejected
                     if rejection_alerter else None),
        audit=audit, action_dep=action_dep, cancel_dep=cancel_dep,
        snow_clients=_snow_intake_clients(cfg), submit_dep=submit_dep,
        console_deps=console_deps,
        on_cancelled=_note_ticket if ticket_closeout is not None else None))

    # Console auth + user management. Added AFTER the intake router so
    # the existing contract keeps precedence; the paths do not overlap.
    if auth_service is not None:
        from src.modules.auth.routes import build_auth_router
        auth_service.audit = audit
        app.state.auth_service = auth_service
        app.state.user_store = user_store
        app.include_router(build_auth_router(
            auth_service, user_store, cfg, audit=audit))

        # Console-only read APIs (dashboard, evidence, error rules).
        from src.modules.console.routes import build_console_router
        console_router = build_console_router(
            queue_store, transaction_store, auth_service, cfg,
            dispatcher=dispatcher, availability=availability,
            audit=audit, settings_store=settings_store,
            restart_hook=restart_hook)
        app.include_router(console_router)
        # Export configuration reads the Settings page's data (CFG-03).
        app.state.settings_payload = console_router.settings_payload
        app.state.settings_store = settings_store
        app.state.user_store = user_store

        # Branding (public read, settings.edit write) — one JSON row in
        # app_settings; no configuration effect.
        from src.modules.console.branding import build_branding_router
        app.include_router(build_branding_router(
            settings_store, auth_service, audit=audit))

        # Metrics, reports and the audited data export (2026-09-28) —
        # read-only figures from the existing history and audit trail.
        from src.modules.console.metrics import build_metrics_router
        app.include_router(build_metrics_router(
            queue_store, transaction_store, auth_service, audit=audit))
        if auth_service.needs_bootstrap():
            logger.warning(
                "No console accounts exist — the first administrator "
                "must be created via POST /api/v1/auth/bootstrap")
    return app
