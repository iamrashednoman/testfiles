"""ObservedDriver — OCR screen reading + full action observation.

Wraps any BaseDriver (decorator pattern; the wrapped driver never
knows). Every workflow, screen check, and navigator call flows through
the SAME driver interface, so wrapping here upgrades the whole stack
at once, with zero changes to the proven workflow logic:

1. OCR enrichment — get_screen_text() returns the inner driver's text
   PLUS the OCR lines of a fresh window capture (and normalized copies,
   so identifier substring checks match despite OCR variance). On the
   real terminal, whose body is not machine-readable, this is what
   turns UNCONFIRMED results into confirmed O-0000/E-xxxx reads and
   makes 削除済み visible BEFORE the 70 commit. The workflows already
   contain the readable-body branches; richer text simply activates
   them.

2. Action trace — every interaction (keystrokes, commands, field
   entries, waits, screenshots, logout walks) is recorded in order
   with timing, outcome, and the screen it happened on. The dispatcher
   writes the trace to the audit DB per transaction. Password VALUES
   are masked before they enter the trace.

3. Screen trace + printed text files — every evidence screenshot is
   classified onto the success/failed path (PathClassifier) and gets a
   same-named .txt mirror in the evidence folder (compliance
   requirement, password masked).

Upgrade-only safety: with the Null engine this wrapper is a pure
pass-through observer — text, waits, and screen checks behave
byte-identically to the bare driver. OCR failures degrade to that same
behavior; they never fail a transaction.
"""
from __future__ import annotations

import hashlib
import os
import tempfile
import time
from datetime import datetime
from pathlib import Path

from src.core.exceptions import ScreenTimeoutError
from src.rpa.drivers.base import BaseDriver
from src.rpa.vision import keywords as kw
from src.rpa.vision import screen_text as st

_MAX_TRACE = 800          # runaway guard; real transactions use ~60-100
_IMAGE_EXTS = (".png", ".jpg", ".jpeg", ".bmp")


class ObservedDriver(BaseDriver):
    """Decorates a terminal driver with OCR reading + audit observation."""

    def __init__(self, inner, engine, classifier: kw.PathClassifier,
                 screens_cfg: dict, *, request_id: str = "",
                 secrets=(), capture_text: bool = True,
                 strict_screen_detection: bool = False, logger=None):
        self.inner = inner
        self.engine = engine
        self.classifier = classifier
        self.screens_cfg = screens_cfg or {}
        self.request_id = request_id
        raw_secrets = secrets or ()
        self.secrets = tuple(s for s in raw_secrets if s)
        self.capture_text = capture_text
        self.strict = strict_screen_detection
        self.logger = logger

        self.action_trace: list[dict] = []
        self.screen_trace: list[dict] = []
        self._last_capture_seq = 0    # input-section window boundary
        self._last_screen = ""
        self._dirty = True            # screen changed since last OCR
        self._ocr_cache: list | None = None
        self._cache_hash = ""
        # Confidence of the most recent get_screen_text() read. The
        # error catalogue's upgrade-only gate gates on this: a shaky
        # read may never assert an error.
        self._last_confidence = 0.0

    # ── Observation helpers ──

    def _record(self, action: str, detail: str = "", *, ok: bool = True,
                duration_ms: int = 0, **extra) -> dict | None:
        if len(self.action_trace) >= _MAX_TRACE:
            if len(self.action_trace) == _MAX_TRACE:
                self.action_trace.append({
                    "seq": _MAX_TRACE + 1, "action": "trace_truncated",
                    "detail": f"exceeded {_MAX_TRACE} actions"})
            return None
        entry = {
            "seq": len(self.action_trace) + 1,
            "at": datetime.now().isoformat(timespec="milliseconds"),
            "action": action,
            "detail": kw.mask_values(str(detail), self.secrets),
            "screen": self._last_screen,
            "ok": ok,
        }
        if duration_ms:
            entry["duration_ms"] = duration_ms
        entry.update(extra)
        self.action_trace.append(entry)
        return entry

    def _observed(self, action: str, detail, fn, *args, **fn_kwargs):
        """Run one driver call, recording outcome + duration. Failures
        are recorded, then re-raised untouched."""
        t0 = time.time()
        try:
            result = fn(*args, **fn_kwargs)
        except Exception as e:
            self._record(action, f"{detail} — {e}", ok=False,
                         duration_ms=int((time.time() - t0) * 1000))
            raise
        self._record(action, detail,
                     duration_ms=int((time.time() - t0) * 1000))
        return result

    def _note_screen(self, screen: str) -> None:
        """Track screen transitions as explicit before/after entries."""
        if screen and screen != self._last_screen:
            self._record("screen_transition", screen,
                         before=self._last_screen or "-", after=screen)
            self._last_screen = screen

    # ── Reading (OCR-enriched; never recorded — read-only probes) ──

    def _safe_inner_text(self) -> str:
        try:
            return self.inner.get_screen_text() or ""
        except Exception:
            return ""

    def _ocr_lines(self) -> list:
        """OCR the current window (temp capture), cached by image hash
        until an input action marks the screen dirty."""
        if not getattr(self.engine, "available", False):
            return []
        if not self._dirty and self._ocr_cache is not None:
            return self._ocr_cache
        fd, tmp = tempfile.mkstemp(suffix=".png")
        os.close(fd)
        try:
            self.inner.take_screenshot(tmp)
            digest = hashlib.sha256(Path(tmp).read_bytes()).hexdigest()
            if digest != self._cache_hash or self._ocr_cache is None:
                self._ocr_cache = self.engine.read_image(tmp)
                self._cache_hash = digest
            self._dirty = False
            return self._ocr_cache
        except Exception as e:
            if self.logger:
                self.logger.warning(f"OCR screen read skipped: {e}")
            return self._ocr_cache or []
        finally:
            try:
                os.remove(tmp)
            except OSError:
                pass

    def _ocr_from_lines(self, lines) -> str:
        """OCR lines → text block + normalized copies (identifier
        matching survives fullwidth/space/hyphen OCR variance)."""
        if not lines:
            return ""
        raw = "\n".join(ln.text for ln in lines)
        norm = "\n".join(kw.normalize_text(ln.text) for ln in lines)
        return raw + ("\n" + norm if norm.strip() else "")

    def get_screen_text(self) -> str:
        base = self._safe_inner_text()
        lines = self._ocr_lines()
        # Track how trustworthy THIS read was, so the error catalogue
        # can refuse to act on a weak one (no extra work: the lines are
        # already in hand).
        if lines:
            self._last_confidence = sum(
                ln.confidence for ln in lines) / len(lines)
        else:
            self._last_confidence = 1.0 if base.strip() else 0.0
        extra = self._ocr_from_lines(lines)
        return base + ("\n" + extra if extra else "")

    @property
    def last_read_confidence(self) -> float:
        """Mean OCR confidence of the last get_screen_text(). On the
        null-engine path a non-empty native read is exact (1.0) — the
        driver reported its own state, nothing was recognised."""
        return self._last_confidence

    def screen_contains(self, text: str) -> bool:
        merged = self.get_screen_text()
        return text in merged or \
            kw.normalize_text(text) in kw.normalize_text(merged)

    # ── Interface delegation (observed) ──

    def initialize(self, config: dict) -> None:
        self.inner.initialize(config)

    def launch_application(self) -> None:
        self._dirty = True
        self._observed("launch_application", "",
                       self.inner.launch_application)

    def type_text(self, text: str, delay: float = 0.05) -> None:
        self._dirty = True
        self._observed("type_text", text, self.inner.type_text, text,
                       delay)

    def press_key(self, key: str) -> None:
        self._dirty = True
        self._observed("press_key", key, self.inner.press_key, key)

    def send_field_value(self, field_id: str, value: str) -> None:
        self._dirty = True
        t0 = time.time()
        try:
            self.inner.send_field_value(field_id, value)
        except Exception as e:
            self._record("send_field_value", f"{field_id} — {e}",
                         ok=False, field=field_id)
            raise
        self._record("send_field_value", field_id, field=field_id,
                     before="", after=kw.mask_values(value, self.secrets),
                     duration_ms=int((time.time() - t0) * 1000))

    def submit_command(self, command: str, delay: float = 0.5,
                       before_enter=None) -> None:
        self._dirty = True
        # PRE-recorded (unlike the other actions): a before_enter
        # evidence capture fires INSIDE the inner call, and its INPUT
        # COMMANDS section must show the command being submitted at
        # that very moment — recording afterwards attributed the
        # command to the NEXT capture.
        entry = self._record("submit_command", command)
        t0 = time.time()
        try:
            self.inner.submit_command(command, delay,
                                      before_enter=before_enter)
        except Exception as e:
            if entry is not None:
                entry["ok"] = False
                entry["detail"] = kw.mask_values(f"{command} — {e}",
                                                 self.secrets)
            raise
        if entry is not None:
            entry["duration_ms"] = int((time.time() - t0) * 1000)

    def wait_for_screen(self, identifiers: list[str],
                        timeout: float = 15.0) -> bool:
        if not getattr(self.engine, "available", False):
            # Null engine: the inner driver's field-proven wait
            # semantics apply unchanged.
            return self._observed("wait_for_screen", str(identifiers),
                                  self.inner.wait_for_screen,
                                  identifiers, timeout)
        # OCR makes the screen genuinely readable — poll enriched text.
        t0 = time.time()
        while time.time() - t0 < timeout:
            self._dirty = True        # each poll re-reads the window
            text = self.get_screen_text()
            norm = kw.normalize_text(text)
            if any(i in text or kw.normalize_text(i) in norm
                   for i in identifiers):
                self._record("wait_for_screen", str(identifiers),
                             duration_ms=int((time.time() - t0) * 1000))
                return True
            time.sleep(0.5)
        self._record("wait_for_screen",
                     f"{identifiers} not seen in {timeout}s",
                     ok=not self.strict,
                     duration_ms=int((time.time() - t0) * 1000))
        if self.strict:
            raise ScreenTimeoutError(
                f"Screen with identifiers {identifiers} not detected "
                f"within {timeout}s (strict_screen_detection on)",
                step="wait_for_screen")
        return True

    def take_screenshot(self, filepath: str) -> None:
        """Save the evidence PNG (inner driver), then read THAT exact
        image: classify the path, append the screen trace entry, and
        write the printed-pattern .txt mirror beside it."""
        self._observed("take_screenshot", Path(filepath).name,
                       self.inner.take_screenshot, filepath)
        try:
            self._classify_capture(filepath)
        except Exception as e:
            # Compliance artifacts must never crash the bot.
            if self.logger:
                self.logger.warning(
                    f"screen classification/text failed for "
                    f"{filepath}: {e}")

    def close_application(self) -> None:
        self._observed("close_application", "",
                       self.inner.close_application)

    # ── Extra driver methods (clear_field, goto_first_field_and_exit,
    # reattach_to_*, …) — proxied so hasattr() checks in the navigator
    # keep selecting the same branches as the bare driver, with the
    # call still landing in the action trace. ──

    def __getattr__(self, name):
        if name == "inner":           # not set yet (mid-__init__)
            raise AttributeError(name)
        attr = getattr(self.inner, name)
        if callable(attr) and not name.startswith("_"):
            def proxied(*args, **kwargs):
                self._dirty = True
                detail = ", ".join(
                    [kw.mask_values(str(a), self.secrets) for a in args]
                    + [f"{k}={kw.mask_values(str(v), self.secrets)}"
                       for k, v in kwargs.items()])
                return self._observed(name, detail, attr, *args, **kwargs)
            return proxied
        return attr

    # ── Classification + printed text files ──

    def _driver_content(self) -> str:
        """The driver's FULL printed mirror (sim/mock expose one),
        falling back to its minimal identifier text."""
        text = ""
        content_fn = getattr(self.inner, "get_screen_content", None)
        if callable(content_fn):
            try:
                text = content_fn() or ""
            except Exception:
                text = ""
        return text if text.strip() else self._safe_inner_text()

    def _classify_capture(self, filepath: str) -> None:
        step = Path(filepath).stem
        lines = []
        if getattr(self.engine, "available", False):
            lines = self.engine.read_image(filepath)
            try:                      # capture doubles as cache refresh
                self._cache_hash = hashlib.sha256(
                    Path(filepath).read_bytes()).hexdigest()
                self._ocr_cache, self._dirty = lines, False
            except OSError:
                pass

        if lines:
            text = "\n".join(ln.text for ln in lines)
            confs = [ln.confidence for ln in lines] or [0.0]
            confidence = sum(confs) / len(confs)
            body: object = lines
        else:
            # No engine, OR the engine read NOTHING from this image —
            # an unreadable/corrupt capture, which is exactly when an
            # empty evidence file is least acceptable. Fall back to
            # whatever the driver can report about the screen rather
            # than writing a blank .txt beside the PNG.
            text = self._driver_content()
            confidence = 1.0 if text.strip() else 0.0
            body = text

        classification = self.classifier.classify(text, confidence)
        screen = kw.match_screen(self.screens_cfg,
                                 text + "\n" + self._safe_inner_text())
        self._note_screen(screen)

        entry = {
            "seq": len(self.screen_trace) + 1,
            "file": Path(filepath).name,
            "screen": screen or "-",
            "path": classification["path"],
            "code": classification["code"],
            "matched": classification["matched"],
            "confidence": round(float(classification["confidence"]), 3),
            "captured_at": datetime.now().isoformat(
                timespec="milliseconds"),
        }
        self.screen_trace.append(entry)

        # Inputs that produced THIS screen state (since the previous
        # capture) — appended as an INPUT VALUES footer for debugging.
        # Values were masked at record time.
        inputs = [e for e in self.action_trace
                  if e["seq"] > self._last_capture_seq
                  and e.get("action") in ("type_text",
                                          "send_field_value",
                                          "submit_command",
                                          "goto_first_field_and_exit")]
        if self.action_trace:
            self._last_capture_seq = self.action_trace[-1]["seq"]

        if self.capture_text and filepath.lower().endswith(_IMAGE_EXTS):
            header = st.build_header(
                request_id=self.request_id, step=step,
                screen=screen or "-", classification=classification,
                captured_at=entry["captured_at"],
                engine=getattr(self.engine, "name", "null"))
            st.write_screen_text(
                str(Path(filepath).with_suffix(".txt")), header,
                st.format_printed(body, self.secrets),
                footer=st.build_input_section(inputs))

    # ── Result summary (dispatcher attaches these to the audit DB) ──

    def traces(self) -> dict:
        return {"action_trace": self.action_trace,
                "screen_trace": self.screen_trace}
