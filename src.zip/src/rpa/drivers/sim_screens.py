"""Canvas renderers for the simulated FINESIII terminal.

Replicates the REAL application's screens from the client evidence
captures (2026-08 walkthrough photos):

  menu screens (端末業務選択メニュー, Z1966) — light Fujitsu menu window
      with 3D-bordered code/label rows, blue heading, 【処理選択】 input
      box bottom-right;
  FINESⅢ login — black screen, AIM system line, the FIN brand block
      with the asterisk "swoosh" logo, green-bordered credential fields
      with a block cursor and the (終了:99) hint;
  post-login screens — no reference photos exist, so they follow the
      same dark FINESⅢ terminal style consistently.

Pure drawing layer: no driver logic lives here. The driver passes a
state dict; these functions only paint it. Screen-text identifiers used
by ScreenState/tests are produced by the DRIVER, not by this module —
changing visuals here can never break the bot's logic.
"""
from __future__ import annotations

# ── Palette (sampled from the evidence photos) ──────────────────────
MENU_BG = "#e9e7e1"          # warm light gray of the menu window body
MENU_BOX_BG = "#f6f5f1"
MENU_BOX_EDGE = "#8a8a8a"
MENU_BOX_LIGHT = "#ffffff"
MENU_HEADING = "#2726c8"     # blue heading / 【処理選択】
MENU_TEXT = "#1a1a1a"

DARK_BG = "#000000"
DARK_TEXT = "#e8e8e0"
CYAN = "#3fd9c9"             # FIN brand cyan
BLUE = "#4f9fe8"             # lower swoosh blue
FIELD_GREEN = "#00a550"      # login field borders
CURSOR = "#e8e8e0"
STATUS_DIM = "#9a9a90"
YELLOW = "#e8cf3e"           # highlighted values / 【確認】 rows
GRID_GREEN = "#2fbf3f"       # DID:903 table grid

WINDOW_W, WINDOW_H = 940, 660

# The FIN "swoosh" logo, hand-encoded from the login photo: each entry
# is (indent_px, asterisk_run_lengths_with_gaps, color). Kept as plain
# text lines for simplicity; drawn with the mono font.
_LOGO_LINES = [
    (470, "**  **  **  ***", DARK_TEXT),
    (445, "**            **", DARK_TEXT),
    (420, "**             **", DARK_TEXT),
    (395, "***             *", DARK_TEXT),
    (370, "***     *     *     ***", DARK_TEXT),
    (345, "****   ***    **     ***", CYAN),
    (300, "***  *******   ****   *   ****", CYAN),
    (255, "**  ***********  ********  **  ****", CYAN),
    (210, "***  **************  *********  ******", CYAN),
    (150, "****************************************", BLUE),
    (110, "******************************************", BLUE),
    (75, "****************************   *********", BLUE),
    (40, "********************              **********", BLUE),
    (15, "***********************", BLUE),
]

# Menu rows exactly as photographed: code, label ('' = blank row).
MENU_ROWS = [
    ("10", "基幹業務メニュー"),
    ("20", "端末管理メニュー"),
    ("", ""),
    ("40", "補助機能"),
    ("", ""),
    ("", ""),
    ("", ""),
    ("", ""),
    ("", ""),
    ("XX", "システム終了"),
]


def pick_jp_font(tkfont) -> str:
    """Best available Japanese-capable font: MS Gothic on the Windows
    VMs, Hiragino on macOS dev machines."""
    families = set(tkfont.families())
    for candidate in ("MS Gothic", "MS ゴシック", "Osaka",
                      "Hiragino Sans", "Hiragino Kaku Gothic ProN"):
        if candidate in families:
            return candidate
    return "TkDefaultFont"


def _box3d(canvas, x, y, w, h, sunken=False):
    """Fake the Fujitsu 3D border: gray edge + white counter-edge."""
    canvas.create_rectangle(x, y, x + w, y + h,
                            fill=MENU_BOX_BG, outline=MENU_BOX_EDGE)
    if sunken:
        canvas.create_line(x, y, x + w, y, fill=MENU_BOX_EDGE, width=2)
        canvas.create_line(x, y, x, y + h, fill=MENU_BOX_EDGE, width=2)
        canvas.create_line(x, y + h, x + w, y + h, fill=MENU_BOX_LIGHT)
        canvas.create_line(x + w, y, x + w, y + h, fill=MENU_BOX_LIGHT)
    else:
        canvas.create_line(x, y, x + w, y, fill=MENU_BOX_LIGHT)
        canvas.create_line(x, y, x, y + h, fill=MENU_BOX_LIGHT)
        canvas.create_line(x, y + h, x + w, y + h,
                           fill=MENU_BOX_EDGE, width=2)
        canvas.create_line(x + w, y, x + w, y + h,
                           fill=MENU_BOX_EDGE, width=2)


def _cursor(canvas, x, y, h, color=MENU_TEXT):
    canvas.create_rectangle(x, y, x + 10, y + h, fill=color,
                            outline=color)


def draw_menu(canvas, state, jp):
    """端末業務選択メニュー — screens 7801/7802 (identical in the real
    app; the second appears after the first '10')."""
    canvas.configure(bg=MENU_BG)
    heading = (jp, 24, "bold")
    label_f = (jp, 18)
    code_f = (jp, 16)

    canvas.create_text(WINDOW_W / 2, 38, text="端末業務選択メニュー",
                       font=heading, fill=MENU_HEADING)
    canvas.create_text(WINDOW_W - 60, 40, text="Z1966",
                       font=(jp, 15), fill=MENU_TEXT)

    y = 80
    for code, label in MENU_ROWS:
        _box3d(canvas, 70, y, 92, 34)
        _box3d(canvas, 186, y, 664, 34)
        if code:
            canvas.create_text(116, y + 17, text=code, font=code_f,
                               fill=MENU_TEXT)
        if label:
            canvas.create_text(200, y + 17, text=label, font=label_f,
                               fill=MENU_TEXT, anchor="w")
        y += 48

    # 【処理選択】 + command echo box, bottom row
    canvas.create_text(70, y + 22, text="【処理選択】", font=(jp, 17),
                       fill=MENU_HEADING, anchor="w")
    _box3d(canvas, WINDOW_W - 190, y + 4, 116, 34, sunken=True)
    buf = state.get("input_buffer", "")
    canvas.create_text(WINDOW_W - 182, y + 21, text=buf,
                       font=code_f, fill=MENU_TEXT, anchor="w")
    _cursor(canvas, WINDOW_W - 180 + len(buf) * 13, y + 10, 22)


def _login_field(canvas, jp, label, x, y, value, focused,
                 masked=False):
    canvas.create_text(x, y + 15, text=label, font=(jp, 17),
                       fill=DARK_TEXT, anchor="e")
    canvas.create_rectangle(x + 18, y, x + 208, y + 32,
                            outline=FIELD_GREEN, width=2)
    shown = ("*" * len(value)) if masked else value
    canvas.create_text(x + 26, y + 16, text=shown, font=(jp, 15),
                       fill=DARK_TEXT, anchor="w")
    if focused:
        _cursor(canvas, x + 28 + len(shown) * 12, y + 5, 22, CURSOR)


def draw_login(canvas, state, jp):
    """FINESⅢ login — screen 7803."""
    canvas.configure(bg=DARK_BG)
    mono = ("Menlo", 13)

    canvas.create_text(40, 34, text="AIM1/V04/P200HXXPROC",
                       font=("Menlo", 15), fill=DARK_TEXT, anchor="w")

    # Brand block: big initials, small caps, cyan accents
    def brand(x, y, big, small, big_color, small_color):
        canvas.create_text(x, y, text=big, font=("Georgia", 30, "bold"),
                           fill=big_color, anchor="w")
        canvas.create_text(x + 30, y + 6, text=small, font=(jp, 15),
                           fill=small_color, anchor="w")
        return x + 30 + len(small) * 12

    x = brand(60, 110, "F", "UJI", DARK_TEXT, CYAN)
    x = brand(x + 24, 110, "I", "NFORMATION", DARK_TEXT, CYAN)
    brand(x + 24, 110, "N", "ETWORK", DARK_TEXT, CYAN)
    x = brand(110, 170, "E", "XTENSIBLE", DARK_TEXT, CYAN)
    x = brand(x + 24, 170, "S", "YSTEM", DARK_TEXT, CYAN)
    canvas.create_text(x + 40, 170, text="Ⅲ",
                       font=("Georgia", 30, "bold"), fill=DARK_TEXT,
                       anchor="w")

    # Asterisk swoosh, upper right sweeping to lower left
    y = 60
    for indent, line, color in _LOGO_LINES:
        canvas.create_text(335 + indent, y, text=line, font=mono,
                           fill=color, anchor="w")
        y += 26

    # Credential fields
    fields = state.get("login_fields", ["", "", ""])
    focus = state.get("login_focus", 0)
    _login_field(canvas, jp, "所　属コード", 400, 440, fields[0],
                 focus == 0)
    canvas.create_text(430, 486, text="(終了:99)", font=(jp, 13),
                       fill=DARK_TEXT, anchor="w")
    _login_field(canvas, jp, "担当者コード", 400, 512, fields[1],
                 focus == 1)
    _login_field(canvas, jp, "パスワード", 400, 557, fields[2],
                 focus == 2, masked=True)

    # Host rejection message, placed beside the staff-code field as on
    # the real terminal (client evidence, Case 2).
    login_error = state.get("login_error", "")
    if login_error:
        canvas.create_text(620, 512, text=login_error, font=(jp, 15),
                           fill=CYAN, anchor="w")


def _reiwa_date() -> str:
    """Header date as the real terminal shows it: 令和 year / M/ D."""
    from datetime import datetime, timedelta, timezone
    now = datetime.now(timezone(timedelta(hours=9)))
    return f"{now.year - 2018}/ {now.month}/{now.day:2d}"


def _header_00903(canvas, state, jp):
    """Common DID:903 header row: 業務No. 00903 エントリー
    パスワードＤＢの更新と追加 + session affiliation + date."""
    canvas.create_text(40, 30, text="業務No.", font=(jp, 15),
                       fill=CYAN, anchor="w")
    canvas.create_text(125, 30, text="00903", font=("Menlo", 16),
                       fill=CYAN, anchor="w")
    canvas.create_text(215, 30, text="エントリー", font=(jp, 12),
                       fill=CYAN, anchor="w")
    canvas.create_text(300, 30, text="パスワードＤＢの更新と追加",
                       font=(jp, 16, "bold"), fill=CYAN, anchor="w")
    canvas.create_text(700, 30, text=state.get("header_affiliation",
                                               "03325"),
                       font=("Menlo", 15), fill=CYAN, anchor="w")
    canvas.create_text(WINDOW_W - 40, 30, text=_reiwa_date(),
                       font=("Menlo", 15), fill=CYAN, anchor="e")


def _kakunin_bar(canvas, jp, left_yellow, cyan_mid, right_yellow):
    """Bottom 【確認】 status bar in the real color scheme. Fixed Y —
    the OS may clamp the window shorter than WINDOW_H on small
    screens, so anchoring to WINDOW_H can push the bar off-screen."""
    y = 578
    canvas.create_text(40, y, text=f"【確認】　{left_yellow}",
                       font=(jp, 14), fill=YELLOW, anchor="w")
    canvas.create_text(WINDOW_W / 2 + 80, y, text=cyan_mid,
                       font=(jp, 14), fill=CYAN, anchor="w")
    if right_yellow:
        canvas.create_text(WINDOW_W - 40, y, text=right_yellow,
                           font=(jp, 14), fill=YELLOW, anchor="e")


def draw_business_menu(canvas, state, jp):
    """業務MENU after login (photo 004): session lines + 業務ＮＯ box."""
    canvas.configure(bg=DARK_BG)
    fields = state.get("login_fields", ["", "", ""])
    affiliation = fields[0] or "9903325"
    staff = fields[1] or "12N3940"

    canvas.create_text(50, 34, text="ＦＩＮＥＳⅢ", font=(jp, 17),
                       fill=CYAN, anchor="w")
    canvas.create_text(WINDOW_W / 2, 34,
                       text="◇◇◇　業務　ＭＥＮＵ　◇◇◇",
                       font=(jp, 17), fill=CYAN)
    canvas.create_text(WINDOW_W - 40, 34, text=_reiwa_date(),
                       font=("Menlo", 15), fill=CYAN, anchor="e")

    # Session lines. The real screen shows the account holder's
    # registered name — the sim renders a neutral placeholder.
    canvas.create_text(60, 92, font=(jp, 15), fill=DARK_TEXT,
                       anchor="w",
                       text=f"所　属　{affiliation}　特殊コード（ヘルプデスク　特殊コード（ヘ")
    canvas.create_text(60, 124, font=(jp, 15), fill=DARK_TEXT,
                       anchor="w",
                       text=f"担当者　{staff}　テスト　担当者")

    # 業務ＮＯ input
    canvas.create_text(370, 190, text="業務　ＮＯ", font=(jp, 16),
                       fill=YELLOW, anchor="w")
    canvas.create_rectangle(500, 172, 616, 206, outline=FIELD_GREEN,
                            width=2)
    buf = state.get("input_buffer", "")
    canvas.create_text(510, 189, text=buf, font=("Menlo", 15),
                       fill=DARK_TEXT, anchor="w")
    _cursor(canvas, 512 + len(buf) * 11, 178, 22, CURSOR)

    canvas.create_text(WINDOW_W / 2, 330, font=(jp, 15),
                       fill=DARK_TEXT,
                       text="業務メニュー画面は、次画面以降に表示されます。")
    canvas.create_text(WINDOW_W / 2, 372, font=(jp, 15),
                       fill=DARK_TEXT,
                       text="（業務メニューが必要な場合は、次頁を選択して下さい！）")

    _kakunin_bar(canvas, jp, "次頁:60", "ＣＤ算出:00　終了:99",
                 "＊次頁有")


# DID:903 table rows exactly as photographed (photo 005/006):
# (row no, label, FID, value-key or None)
_TASK_ROWS = [
    ("101", "処理区分", "008", "101"),
    ("102", "　１：アカウントロックの解除", "", None),
    ("103", "　２：新規　３：更新　４：削除", "", None),
    ("104", "監査対象区分（１：監査対象）", "004", "104"),
    ("105", "所属コード（５桁）", "005", "105"),
    ("106", "社員コード　（７桁）", "002", "106"),
    ("107", "変更後（新）パスワード（８桁）", "003", "107"),
    ("108", "", "", None),
    ("109", "　※　パスワードの有効期限は３日間です", "", None),
    ("110", "", "", None),
    ("111", "西暦年月日", "006", "111"),
    ("112", "管理者区分（１：管理者）", "007", "112"),
    ("", "", "", None),
    ("", "", "", None),
    ("", "", "", None),
]


def draw_task_table(canvas, state, jp, confirm=False):
    """DID:903 entry / confirmation — the FID table (photos 005/006).
    The インプット内容 column fills in live as the bot types."""
    canvas.configure(bg=DARK_BG)
    _header_00903(canvas, state, jp)
    values = state.get("task_values", {})

    # "100 処理確認" box row with its small entry cell
    canvas.create_rectangle(40, 58, 240, 88, outline=GRID_GREEN)
    canvas.create_line(90, 58, 90, 88, fill=GRID_GREEN)
    canvas.create_text(65, 73, text="100", font=("Menlo", 14),
                       fill=DARK_TEXT)
    canvas.create_text(102, 73, text="処理確認", font=(jp, 14),
                       fill=DARK_TEXT, anchor="w")
    canvas.create_rectangle(240, 58, 300, 88, outline=GRID_GREEN)
    _cursor(canvas, 250, 63, 20, CURSOR)

    if confirm and state.get("scenario") == "already_deleted":
        canvas.create_text(WINDOW_W / 2, 105, font=(jp, 14),
                           fill=YELLOW,
                           text="エラーコメント：所属・社員コード誤り？削除済み")

    # Table geometry
    x0, x1 = 40, WINDOW_W - 40
    c_no, c_fid, c_in = 95, 640, 730     # column divider x positions
    top = 118
    row_h = 26
    rows = [("NO.", "項　目　名　称", "FID", None)] + _TASK_ROWS
    bottom = top + row_h * len(rows)

    canvas.create_rectangle(x0, top, x1, bottom, outline=GRID_GREEN)
    for i in range(1, len(rows)):
        canvas.create_line(x0, top + i * row_h, x1, top + i * row_h,
                           fill=GRID_GREEN)
    for cx in (c_no, c_fid, c_in):
        canvas.create_line(cx, top, cx, bottom, fill=GRID_GREEN)

    for i, (no, label, fid, key) in enumerate(rows):
        cy = top + i * row_h + row_h / 2
        header = i == 0
        f = (jp, 14, "bold") if header else (jp, 13)
        if header:
            canvas.create_text((x0 + c_no) / 2 + 8, cy, text=no,
                               font=f, fill=DARK_TEXT)
            canvas.create_text((c_no + c_fid) / 2, cy, text=label,
                               font=f, fill=DARK_TEXT)
            canvas.create_text((c_fid + c_in) / 2, cy, text=fid,
                               font=f, fill=DARK_TEXT)
            canvas.create_text((c_in + x1) / 2, cy,
                               text="インプット内容", font=f,
                               fill=DARK_TEXT)
            continue
        if no:
            canvas.create_text(x0 + 8, cy, text=no, font=("Menlo", 13),
                               fill=DARK_TEXT, anchor="w")
        if label:
            canvas.create_text(c_no + 10, cy, text=label, font=f,
                               fill=DARK_TEXT, anchor="w")
        if fid:
            canvas.create_text(c_fid + 12, cy, text=fid,
                               font=("Menlo", 13), fill=DARK_TEXT,
                               anchor="w")
        if key and key in values:
            # Row 107 (password) renders in CLEAR text — replicating
            # the real terminal exactly, per client screenshot and
            # approval 2026-08-17. Evidence captures therefore contain
            # the typed password, as the real app's captures do.
            canvas.create_text(c_in + 12, cy, text=values[key],
                               font=("Menlo", 13), fill=DARK_TEXT,
                               anchor="w")

    if confirm:
        _kakunin_bar(canvas, jp, "送信:70　取消:99", "終了:99",
                     "＊最終頁")
    else:
        _kakunin_bar(canvas, jp, "送信:00　訂正:ENTER", "終了:99",
                     "＊最終頁")


def draw_print_screen(canvas, state, jp, printed=False,
                      result_code=None):
    """Print screens (photos 007/009): paper-set box; プリント済 is
    appended once printing finished."""
    canvas.configure(bg=DARK_BG)
    _header_00903(canvas, state, jp)

    canvas.create_rectangle(60, 100, WINDOW_W - 60, 500,
                            outline=GRID_GREEN)
    canvas.create_text(180, 160, font=(jp, 16, "bold"), fill=DARK_TEXT,
                       anchor="w", text="下記の用紙をセットして下さい")
    canvas.create_text(560, 160, text="・・・・", font=(jp, 14),
                       fill=GRID_GREEN, anchor="w")
    if printed:
        canvas.create_text(660, 160, text="プリント済",
                           font=(jp, 16, "bold"), fill=YELLOW,
                           anchor="w")

    entries = [
        ("用紙コード", "A0001", YELLOW),
        ("帳票名称", "連続シート", DARK_TEXT),
        ("出力先プリンタ", "FX ApeosPort-V C4476", DARK_TEXT),
        ("印字枚数", "１枚", DARK_TEXT),
    ]
    y = 240
    for label, value, color in entries:
        canvas.create_text(140, y, text=label, font=(jp, 15),
                           fill=DARK_TEXT, anchor="w")
        canvas.create_text(320, y, text="：", font=(jp, 15),
                           fill=DARK_TEXT, anchor="w")
        canvas.create_text(350, y, text=value, font=("Menlo", 15),
                           fill=color, anchor="w")
        y += 55

    if result_code:
        canvas.create_text(60, 545, text=f"({result_code})",
                           font=("Menlo", 12), fill=STATUS_DIM,
                           anchor="w")
    _kakunin_bar(canvas, jp, "印字:10", "終了:99", "＊最終頁")


def draw_error_result(canvas, state, jp):
    """E-xxxx business error on the result screen."""
    canvas.configure(bg=DARK_BG)
    _header_00903(canvas, state, jp)
    canvas.create_rectangle(60, 100, WINDOW_W - 60, 300,
                            outline=GRID_GREEN)
    canvas.create_text(WINDOW_W / 2, 170, text="処理結果",
                       font=(jp, 18), fill=DARK_TEXT)
    canvas.create_text(WINDOW_W / 2, 230,
                       text="Ｅ−９９０１　所属コード誤り",
                       font=(jp, 17, "bold"), fill=YELLOW)
    _kakunin_bar(canvas, jp, "訂正:ENTER", "終了:99", "")


# ── Modal error dialog (client evidence, Case 1) ─────────────────────
DIALOG_BG = "#ffffff"          # dialog body
DIALOG_TITLE_BG = "#1a6fc4"    # Windows-style blue title bar
DIALOG_EDGE = "#cc0000"        # the red inner frame in the photo
DIALOG_TEXT = "#101010"

_DIALOG_BODY = {
    "center_not_ready": [
        (60, "\uff26 \uff29 \uff2e \uff25 \uff33", 13),
        (82, "WRT   0000 0151 0000 00000000", 12),
        (128, "NDSUB", 12),
        (168, "\u30bb\u30f3\u30bf\u30fc\u6e96\u5099\u4e2d", 12),
    ],
}


def draw_error_dialog(canvas, jp, kind: str = "center_not_ready"):
    """Overlay the modal 「エラーメッセージ」 dialog on the current screen.

    Drawn LAST so it covers whatever is underneath — the same thing the
    bot's OCR sees, and the reason the terminal stops responding until
    it is acknowledged."""
    x0, y0 = 300, 150
    x1, y1 = x0 + 405, y0 + 330

    # Title bar
    canvas.create_rectangle(x0, y0, x1, y0 + 22, fill=DIALOG_TITLE_BG,
                            outline=DIALOG_TITLE_BG)
    canvas.create_text(x0 + 8, y0 + 11, text="\u30a8\u30e9\u30fc\u30e1\u30c3\u30bb\u30fc\u30b8",
                       font=(jp, 9), fill="#ffffff", anchor="w")
    # Body + the red inner frame from the photo
    canvas.create_rectangle(x0, y0 + 22, x1, y1, fill=DIALOG_BG,
                            outline="#7f7f7f")
    canvas.create_rectangle(x0 + 16, y0 + 46, x1 - 16, y1 - 20,
                            outline=DIALOG_EDGE, width=2)

    for dy, text, size in _DIALOG_BODY.get(kind, []):
        canvas.create_text(x0 + 60, y0 + 46 + dy, text=text,
                           font=(jp, size), fill=DIALOG_TEXT, anchor="w")

    canvas.create_text(x1 - 60, y1 - 48,
                       text="\u78ba\u8a8d\uff1a\uff25\uff2e\uff34\uff25\uff32",
                       font=(jp, 12), fill=DIALOG_TEXT, anchor="e")


def render(canvas, state, jp):
    """Dispatch: paint the current screen onto the canvas."""
    canvas.delete("all")
    screen = state.get("screen", "blank")
    scenario = state.get("scenario", "success")
    dialog = state.get("dialog", "")

    if screen in ("core_menu", "menu_2"):
        draw_menu(canvas, state, jp)

    elif screen == "login":
        draw_login(canvas, state, jp)

    elif screen == "business_menu":
        draw_business_menu(canvas, state, jp)

    elif screen == "task_903":
        draw_task_table(canvas, state, jp, confirm=False)

    elif screen == "confirmation":
        draw_task_table(canvas, state, jp, confirm=True)

    elif screen == "result":
        if scenario == "error":
            draw_error_result(canvas, state, jp)
        else:
            draw_print_screen(canvas, state, jp, printed=False,
                              result_code="O-0000")

    elif screen == "print":
        draw_print_screen(canvas, state, jp, printed=False)

    elif screen == "print_done":
        draw_print_screen(canvas, state, jp, printed=True)

    elif screen == "logout":
        canvas.configure(bg=DARK_BG)
        canvas.create_text(WINDOW_W / 2, WINDOW_H / 2,
                           text="システム終了", font=(jp, 20),
                           fill=DARK_TEXT)
        canvas.create_text(WINDOW_W / 2, WINDOW_H / 2 + 50,
                           text="セッションを終了しました",
                           font=(jp, 14), fill=STATUS_DIM)

    else:  # blank / initializing
        canvas.configure(bg=DARK_BG)
        canvas.create_text(WINDOW_W / 2, WINDOW_H / 2,
                           text="Initializing session...",
                           font=(jp, 16), fill=STATUS_DIM)

    # Logout narration overlay — placed where each screen has free
    # space so it never collides with replicated content.
    caption = state.get("exit_caption", "")
    if caption and screen != "logout":
        if screen in ("core_menu", "menu_2"):
            canvas.create_text(WINDOW_W / 2, 62, text=caption,
                               font=(jp, 13, "bold"),
                               fill=MENU_HEADING)
        elif screen in ("login", "business_menu"):
            canvas.create_text(40, 62, text=caption,
                               font=(jp, 13, "bold"), fill=YELLOW,
                               anchor="w")
        else:
            canvas.create_text(WINDOW_W - 40, 62, text=caption,
                               font=(jp, 13, "bold"), fill=YELLOW,
                               anchor="e")

    # Modal error dialog LAST — it covers the screen underneath, which
    # is exactly why the terminal stops responding to the bot until it
    # is acknowledged.
    if dialog:
        draw_error_dialog(canvas, jp, dialog)
