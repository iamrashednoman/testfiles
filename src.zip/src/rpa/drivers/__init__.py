"""Terminal driver abstraction.

Ports from v2 drivers/: base_driver.py (interface), pywinauto_driver.py
(primary), pyautogui_driver.py (fallback), tn3270_driver.py (optional
protocol path), sim_terminal_driver.py + sim_subprocess_launcher.py
(local simulator), mock_driver.py (unit tests).

Driver selection is config-driven (terminal_driver setting) with an
ordered fallback chain: a failed pywinauto interaction can be retried
once through pyautogui before the job fails.
"""
