"""Sim Terminal Subprocess Launcher — one visible window per request.

Port of v2 drivers/sim_subprocess_launcher.py, adapted to the v3
package layout. Instead of running the workflow in-process, it launches
src/rpa/sim_terminal_app.py as a SEPARATE PROCESS for each request.
That process opens its own green-screen window, animates all the steps,
closes, and writes the result back.

This is the robust cross-platform approach (no macOS main-thread
conflict) and mirrors real RPA: each ticket triggers a fresh terminal
session that opens, works, and closes.
"""

import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

from src.core.app_paths import data_root, is_frozen, resource_root

PROJECT_ROOT = resource_root()

# Frozen re-entry marker. In a PyInstaller bundle sys.executable IS this
# application and there is no `-m`, so the worker cannot be started as a
# module — the app re-invokes ITSELF with this leading argument and
# desktop/app.py dispatches on it before anything else starts.
SIM_WORKER_ARG = "--sim-terminal-worker"


def _worker_command(req_path: str, res_path: str) -> list[str]:
    """How to start the sim-terminal worker for this runtime."""
    if is_frozen():
        return [sys.executable, SIM_WORKER_ARG, req_path, res_path]
    return [sys.executable, "-m", "src.rpa.sim_terminal_app",
            req_path, res_path]


class SimTerminalSubprocessLauncher:
    """Launches sim_terminal_app per request and collects the result."""

    # () -> None, set by the executor. The workflow runs in the worker
    # process, so the "70" moment is taken from the commit evidence the
    # worker writes, checked every POLL_SECONDS while it runs (NB-004).
    on_commit = None
    POLL_SECONDS = 0.5

    def __init__(self, rpa_config: dict):
        self.rpa_config = rpa_config
        app_config = rpa_config.get("application", {})
        self.scenario = app_config.get("mock_scenario", "success")
        self.action_delay = app_config.get("sim_action_delay", 0.4)

    def run_request(self, request, credentials) -> dict:
        """Launch the terminal app for one request, wait, return the
        result dict (v2 workflow shape)."""

        payload = {
            "operation": request.operation,
            "affiliation_code": request.affiliation_code,
            "employee_code": request.employee_code,
            "password": request.password or "",
            "scenario": self.scenario,
            "action_delay": self.action_delay,
            "login_affiliation": credentials.affiliation_code,
            "login_staff": credentials.application_id,
            "login_password": credentials.password,
            "environment": self.rpa_config.get("environment",
                                               "development"),
            "evidence": self.rpa_config.get("evidence", {}),
            "request_id": getattr(request, "request_id", ""),
            "ocr": self.rpa_config.get("ocr", {}),
            # The sim must run the SAME error catalogue as the real
            # terminal, or a rule proven in the sim would not exist in
            # production (and vice versa).
            "errors": self.rpa_config.get("errors", {}),
        }

        req_fd, req_path = tempfile.mkstemp(suffix="_req.json")
        res_fd, res_path = tempfile.mkstemp(suffix="_res.json")
        os.close(req_fd)
        os.close(res_fd)

        with open(req_path, "w", encoding="utf-8") as f:
            json.dump(payload, f)

        try:
            proc = subprocess.Popen(
                _worker_command(req_path, res_path),
                # From source: the repo root, so `-m` resolves. Frozen:
                # the writable data dir — the bundle is read-only and
                # the worker must not inherit an arbitrary CWD.
                cwd=str(data_root() if is_frozen() else PROJECT_ROOT),
            )
            # Wait until the window closes and the process exits, watching
            # for the commit evidence meanwhile.
            committed = False
            while True:
                try:
                    proc.wait(timeout=self.POLL_SECONDS)
                    break
                except subprocess.TimeoutExpired:
                    pass
                if not committed:
                    committed = self._check_commit(request)
            if not committed:
                committed = self._check_commit(request)

            try:
                with open(res_path, "r", encoding="utf-8") as f:
                    result = json.load(f)
            except (json.JSONDecodeError, FileNotFoundError):
                result = {
                    "status": "failed",
                    "result_code": "",
                    "error": "Sim terminal subprocess did not return "
                             "a result",
                    "evidence_path": "",
                }

            if committed and isinstance(result, dict) \
                    and "operation" not in result:
                # No workflow result (the worker died or failed outside
                # the workflow) although "70" was typed: finished as
                # unconfirmed and never run again (D1), like a request
                # interrupted after the commit.
                result.update({
                    "status": "success", "result_code": "UNCONFIRMED",
                    "error": (f"'70' sent; the terminal session ended "
                              f"without a result: "
                              f"{result.get('error') or 'no detail'} — "
                              f"manual check required"),
                    "commit_sent": True, "post_commit_error": True})
            return result

        finally:
            for p in (req_path, res_path):
                try:
                    os.remove(p)
                except OSError:
                    pass

    def _check_commit(self, request) -> bool:
        """True once the worker's evidence shows the "70" commit of this
        attempt; fires on_commit the first time. Never raises."""
        try:
            from src.modules.queue.dispatcher import commit_evidence
            evidence_dir = (self.rpa_config.get("evidence") or {}).get(
                "output_dir", "")
            if not commit_evidence(evidence_dir, request):
                return False
        except Exception:
            return False
        if self.on_commit is not None:
            try:
                self.on_commit()
            except Exception:
                pass
        return True
