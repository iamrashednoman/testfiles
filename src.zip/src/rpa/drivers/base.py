"""Abstract base driver — the interface every terminal driver implements.

Port of v2 drivers/base_driver.py, unchanged. Workflows and the screens
layer call only these methods, never driver-specific APIs, so the
underlying automation technology (pywinauto / pyautogui / tn3270 /
simulator / mock) can be swapped through configuration alone.
"""

from abc import ABC, abstractmethod


class BaseDriver(ABC):
    """Abstract interface for terminal automation drivers."""

    @abstractmethod
    def initialize(self, config: dict) -> None:
        """Initialize the driver with the 'application' config section."""

    @abstractmethod
    def launch_application(self) -> None:
        """Launch the FINESIII terminal emulator and wait until visible.

        Raises:
            ApplicationLaunchError: If the application fails to start.
        """

    @abstractmethod
    def type_text(self, text: str, delay: float = 0.05) -> None:
        """Type text into the currently focused field."""

    @abstractmethod
    def press_key(self, key: str) -> None:
        """Press a single key (Enter, Tab, F1-F12, etc.)."""

    @abstractmethod
    def send_field_value(self, field_id: str, value: str) -> None:
        """Navigate to a specific field and enter a value."""

    @abstractmethod
    def get_screen_text(self) -> str:
        """Read all visible text from the current terminal screen."""

    @abstractmethod
    def wait_for_screen(self, identifiers: list[str],
                        timeout: float = 15.0) -> bool:
        """Wait until the screen matches the given text identifiers.

        Raises:
            ScreenTimeoutError: If not detected within timeout (strict
            drivers / strict_screen_detection only — see each driver).
        """

    @abstractmethod
    def screen_contains(self, text: str) -> bool:
        """Check if the current screen contains specific text."""

    @abstractmethod
    def take_screenshot(self, filepath: str) -> None:
        """Capture a screenshot of the current application window."""

    @abstractmethod
    def close_application(self) -> None:
        """Gracefully close the terminal emulator application."""

    def submit_command(self, command: str, delay: float = 0.5,
                       before_enter=None) -> None:
        """Type a command code and press Enter.

        before_enter: optional callback fired AFTER the command is
        typed and BEFORE Enter is pressed — the evidence seam for
        capturing the typed-but-not-submitted screen state
        (compliance: before/after data-entry pairs). A hook failure
        never blocks the submit.

        Default implementation — drivers can override (overrides must
        honor the same hook timing)."""
        import time
        self.type_text(command)
        time.sleep(delay)
        if before_enter is not None:
            try:
                before_enter()
            except Exception:
                pass
        self.press_key("enter")
