"""Simulated Terminal Driver — a visible replica of the FINESIII app.

Runs as a standalone per-request process (launched by the executor via
src/rpa/sim_terminal_app.py): one window per request, animates the
steps, closes. The workflow runs on a background thread; its driver
calls push a state dict to a queue that the Tk mainloop (on the main
thread — required on macOS) renders via src/rpa/drivers/sim_screens.py.

The visuals replicate the client evidence captures of the REAL app:
launch shows 端末業務選択メニュー (7801), the first '10' shows it again
(7802, as the real double-window navigation does), the second '10'
opens the dark FINESⅢ login (7803) — the window title switches from
基幹業務メニュー to FINESⅢ at that transition, mirroring the real
two-window behavior. Post-login screens follow the same dark style.

take_screenshot() captures the actual rendered window (Pillow
ImageGrab, routed through the Tk main thread), so sim evidence folders
contain presentation-ready images; it falls back to a placeholder PNG
when capture is unavailable (headless, missing permission).

Driver contract is unchanged from v2: same interface, and
get_screen_text() returns the same identifier strings ScreenState and
the tests rely on. Scenarios: success | already_deleted | error |
unreadable | center_not_ready (a modal 「エラーメッセージ」 dialog that
blocks the FINESIII connection until acknowledged — the client's Case 1
evidence) | login_password_incorrect (パスワードが誤っています — Case 2)
| invalid_affiliation_code (オペレーターコード未登録です — Case 3; the
login screen rejects the affiliation/operator pairing and stays put).
All are replicated so the error catalogue can be proven on screen.
"""

import threading
import time
import queue as pyqueue

from src.rpa.drivers.base import BaseDriver
from src.rpa.drivers import sim_screens

SCREEN_BLANK = "blank"
SCREEN_CORE_MENU = "core_menu"
SCREEN_MENU_2 = "menu_2"          # real app shows the menu twice (7802)
SCREEN_LOGIN = "login"
SCREEN_BUSINESS_MENU = "business_menu"
SCREEN_TASK_903 = "task_903"
SCREEN_CONFIRMATION = "confirmation"
SCREEN_RESULT = "result"
SCREEN_PRINT = "print"
SCREEN_PRINT_DONE = "print_done"
SCREEN_LOGOUT = "logout"

# Login rejections, keyed by scenario. The screen stays put and shows
# the message beside 担当者コード; adding another one is a row here.
LOGIN_ERRORS = {
    "login_password_incorrect": "パスワードが誤っています",
    # Cases 3 and 4 are DIFFERENT root causes (wrong affiliation code vs
    # wrong staff code) that FINESIII reports with the SAME text. Two
    # scenario names so QA can drive each case by name; identical
    # output, because the real terminal gives the bot nothing to tell
    # them apart.
    "invalid_affiliation_code": "オペレーターコード未登録です",
    "invalid_staff_code": "オペレーターコード未登録です",
}

_MENU_SCREENS = (SCREEN_CORE_MENU, SCREEN_MENU_2)
_MENU_TITLE = "基幹業務メニュー"
_FINES_TITLE = "FINESⅢ"

# 1x1 transparent PNG — headless / capture-failure fallback
_PLACEHOLDER_PNG = bytes.fromhex(
    "89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c489"
    "0000000d49444154789c6360000002000100ffff00000002000100"
    "5c6f3b310000000049454e44ae426082"
)


class SimTerminalDriver(BaseDriver):
    """A visible Tk replica of the FINESIII terminal (one window per
    process)."""

    def __init__(self):
        self.scenario = "success"
        self.action_delay = 0.4
        self.screen = SCREEN_BLANK

        self.commands = []
        self.typed_values = []
        self.keys = []

        self._last_employee_code = ""
        self._last_affiliation = ""
        self._status_line = ""
        self._input_buffer = ""

        # Login-field focus: 0=所属コード 1=担当者コード 2=パスワード
        # 3=command line (after the three Enters, '00' submits)
        self._login_fields = ["", "", ""]
        self._login_focus = 0

        # DID:903 entry tracking: the field mapper presses Enter at
        # FID 100 first, then types+Enters through the FID rows in
        # order (empty rows are just an Enter). The typed values fill
        # the table's インプット内容 column live, as on the real screen.
        self._task_field_seq = ("101", "104", "105", "106", "107",
                                "111", "112")
        self._task_focus = -1          # -1 = still on the 100 box
        self._task_values = {}

        # Modal error dialog blocking the terminal (center_not_ready).
        # While it is up nothing the bot types advances the screen —
        # exactly the real failure mode. ENTER acknowledges it.
        self._dialog = ""

        # Login rejected by the host: the screen stays put and shows
        # the message beside the staff-code field, as on the real
        # terminal. Holds the message text (see LOGIN_ERRORS).
        self._login_error = ""

        # Logout narration shown on screen while the exit sequence
        # walks back through the screens (approved visibility fix).
        self._exit_caption = ""

        self._ui_queue = pyqueue.Queue()
        self._root = None
        self._canvas = None
        self._jp_font = "TkDefaultFont"
        self._title = _MENU_TITLE
        self._closed = False
        self._close_requested = False
        self._ui_ready = threading.Event()

    # ── Driver interface ──

    def initialize(self, config: dict) -> None:
        self.scenario = config.get("mock_scenario", "success")
        self.action_delay = config.get("sim_action_delay", 0.4)

    def launch_application(self) -> None:
        self.screen = SCREEN_CORE_MENU
        self._status_line = "Application launched"
        self._render()
        self._pause()

    def type_text(self, text: str, delay: float = 0.05) -> None:
        self.typed_values.append(text)
        stripped = text.strip()
        if len(stripped) == 7 and self.screen == SCREEN_TASK_903:
            self._last_employee_code = stripped
        elif len(stripped) == 5 and stripped.isdigit() \
                and self.screen == SCREEN_TASK_903:
            self._last_affiliation = stripped

        if self.screen == SCREEN_LOGIN and self._login_focus < 3:
            self._login_fields[self._login_focus] += text
        elif self.screen == SCREEN_TASK_903 \
                and 0 <= self._task_focus < len(self._task_field_seq):
            row = self._task_field_seq[self._task_focus]
            self._task_values[row] = \
                self._task_values.get(row, "") + text
        else:
            self._input_buffer = text
        self._status_line = f"Typing: {text}"
        self._render()
        self._pause()

    def press_key(self, key: str) -> None:
        self.keys.append(key)
        if self._dialog and key.lower() == "enter":
            # Acknowledge: the dialog clears and does not reappear
            # (client-confirmed for Case 1).
            self._dialog = ""
            self._status_line = "エラーメッセージ確認 [ENTER]"
            self._render()
            self._pause(1.0, minimum=0.6)
            return
        if key.lower() == "enter":
            if self.screen == SCREEN_LOGIN and self._login_focus < 3:
                self._login_focus += 1     # advance to the next field
            elif self.screen == SCREEN_TASK_903 \
                    and self._task_focus < len(self._task_field_seq):
                self._task_focus += 1      # next FID row (skip = Enter)
            self._input_buffer = ""
        self._status_line = f"Key: [{key.upper()}]"
        self._render()
        self._pause(0.5)

    def send_field_value(self, field_id: str, value: str) -> None:
        self.typed_values.append(value)
        self._input_buffer = value
        self._status_line = f"Field {field_id}: {value}"
        self._render()
        self._pause()

    def submit_command(self, command: str, delay: float = 0.5,
                       before_enter=None) -> None:
        self.commands.append(command)
        if self._dialog:
            # The modal has keyboard focus — the command is swallowed
            # and the screen does not advance.
            self._status_line = f"Command: {command} (blocked by dialog)"
            self._render()
            self._pause()
            if before_enter is not None:
                try:
                    before_enter()
                except Exception:
                    pass
            return
        if self.screen == SCREEN_LOGIN and self._login_focus < 3:
            # A command submitted while a credential field has focus is
            # typed there first (matches real cursor behavior)
            self._login_fields[self._login_focus] += command
        else:
            self._input_buffer = command
        self._status_line = f"Command: {command} [ENTER]"
        self._render()
        # Exit commands hold the echo on screen for a readable beat —
        # at low action delays the typed 99/XX was gone in a blink.
        if command in ("99", "XX"):
            self._pause(1.0, minimum=0.8)
        else:
            self._pause()
        # Evidence seam: the typed command is on screen right now —
        # fire the hook BEFORE the state machine advances.
        if before_enter is not None:
            try:
                before_enter()
            except Exception:
                pass
        self._advance_screen(command)
        self._input_buffer = ""
        self._render()
        self._pause(0.5)

    def get_screen_text(self) -> str:
        if self._dialog:
            return self._dialog_text() + "\n" + self._screen_text()
        return self._screen_text()

    def _dialog_text(self) -> str:
        """The modal error dialog, transcribed from the client evidence
        capture (Case 1)."""
        return ("エラーメッセージ\n"
                " Ｆ Ｉ Ｎ Ｅ Ｓ\n"
                "WRT   0000 0151 0000 00000000\n"
                "NDSUB\n"
                "センター準備中\n"
                "確認：ＥＮＴＥＲ")

    def wait_for_screen(self, identifiers, timeout: float = 15.0) -> bool:
        return True

    def screen_contains(self, text: str) -> bool:
        return text in self._screen_text()

    def take_screenshot(self, filepath: str) -> None:
        """Capture the real rendered window. Routed through the Tk main
        thread (Tk is not thread-safe); falls back to a placeholder PNG
        when there is no window or capture fails."""
        from pathlib import Path
        p = Path(filepath)
        p.parent.mkdir(parents=True, exist_ok=True)

        # Wait for the window to exist and be mapped (startup race)
        self._ui_ready.wait(timeout=5.0)
        if self._root is not None and not self._closed:
            done = threading.Event()
            self._ui_queue.put(("screenshot", (str(p), done)))
            if done.wait(timeout=3.0) and p.exists():
                return

        try:
            p.write_bytes(_PLACEHOLDER_PNG)
        except Exception:
            pass

    def goto_first_field_and_exit(self, exit_code: str = "99",
                                  field_width: int = 7,
                                  backtab_count: int = 4) -> None:
        """The real logout's most distinctive step, animated (approved
        fix A): Shift+Tab back to the affiliation field, visibly clear
        the leftover login code, type the exit code there, submit —
        the FINESⅢ window closes and the menu window returns.

        Implementing this method makes the navigator take its REAL
        driver branch, so the sim runs the same command sequence as
        the Windows terminal."""
        if self.screen != SCREEN_LOGIN:
            # Defensive: outside the login screen behave like a plain
            # exit command so the sequence never stalls.
            self.submit_command(exit_code)
            return

        self.keys.extend(["backtab"] * backtab_count)
        self._login_focus = 0
        self._exit_caption = \
            "ログアウト：Shift+Tab で所属コードへ移動"
        self._status_line = f"Key: [SHIFT+TAB] x{backtab_count}"
        self._render()
        self._pause(1.0, minimum=0.8)

        # Overtype-clear the leftover affiliation code (Backspace is
        # non-destructive on the real terminal — spaces overwrite it)
        self._exit_caption = "ログアウト：所属コードを消去 (スペースで上書き)"
        while self._login_fields[0]:
            self._login_fields[0] = self._login_fields[0][:-1]
            self._status_line = "Typing: [SPACE]"
            self._render()
            self._pause(0.35, minimum=0.12)
        self._pause(0.5, minimum=0.4)

        # Type the exit code into the emptied field and submit
        self.commands.append(exit_code)
        self._login_fields[0] = exit_code
        self._exit_caption = f"ログアウト：終了コード {exit_code} を入力"
        self._status_line = f"Command: {exit_code} [ENTER]"
        self._render()
        self._pause(1.0, minimum=0.8)

        self._advance_screen(exit_code)    # LOGIN + 99 → menu window
        self._render()
        self._pause(0.5)

    def close_application(self) -> None:
        self.screen = SCREEN_LOGOUT
        self._exit_caption = ""
        self._status_line = "Session terminated — logout complete"
        self._render()
        self._pause(1.0)

    # ── Standalone process control ──

    def request_close(self):
        """Called by the workflow thread when steps are done — closes
        the window."""
        self._close_requested = True
        time.sleep(1.2)  # let the operator see the final screen
        self._ui_queue.put(("close", None))

    def run_mainloop(self):
        """Run the Tk window on the MAIN thread (blocks until closed)."""
        try:
            import tkinter as tk
            import tkinter.font as tkfont
        except ImportError:
            self._root = None
            self._ui_ready.set()
            while not self._close_requested:
                time.sleep(0.1)
            return

        self._root = tk.Tk()
        self._root.title(self._title)
        self._jp_font = sim_screens.pick_jp_font(tkfont)

        # Size the toplevel via pack propagation from the canvas's
        # requested size — an explicit geometry() + early resizable()
        # freezes the window at Tk's 200x200 default on macOS.
        self._canvas = tk.Canvas(
            self._root, width=sim_screens.WINDOW_W,
            height=sim_screens.WINDOW_H, highlightthickness=0,
            bg=sim_screens.DARK_BG)
        self._canvas.pack(fill="both", expand=True)
        sim_screens.render(self._canvas, {"screen": SCREEN_BLANK},
                           self._jp_font)

        # Let layout happen, THEN lock the size and bring frontmost.
        # Keeping the window on top for its short life means the
        # operator always sees the animation and window captures
        # (which grab the screen REGION on macOS, regardless of
        # stacking) stay clean of overlapping windows.
        self._root.update_idletasks()
        self._root.resizable(False, False)
        self._root.lift()
        self._root.attributes("-topmost", True)
        try:
            self._root.wait_visibility(self._canvas)
        except Exception:
            pass

        self._ui_ready.set()
        self._root.after(50, self._poll_ui_queue)
        self._root.mainloop()
        self._closed = True

    def _poll_ui_queue(self):
        try:
            while True:
                cmd, payload = self._ui_queue.get_nowait()
                if cmd == "render":
                    if payload["title"] != self._title:
                        self._title = payload["title"]
                        self._root.title(self._title)
                    sim_screens.render(self._canvas, payload,
                                       self._jp_font)
                elif cmd == "screenshot":
                    self._capture_window(*payload)
                elif cmd == "close":
                    if self._root:
                        self._root.destroy()
                    return
        except pyqueue.Empty:
            pass
        if self._root and not self._closed:
            self._root.after(50, self._poll_ui_queue)

    def _capture_window(self, filepath: str, done: threading.Event):
        """Grab the rendered canvas region (main thread only).

        update() (not update_idletasks) forces pending geometry events
        through first — winfo otherwise reports the pre-map 200x200
        default and the grab crops the wrong region. The canvas's own
        mapped coordinates are used so the OS title bar is excluded."""
        try:
            from PIL import ImageGrab
            # NEVER call update() here — reentrant event pumping from
            # inside an after-callback deadlocks Tk. The window was
            # wait_visibility'd at startup, so winfo is trustworthy.
            x = self._canvas.winfo_rootx()
            y = self._canvas.winfo_rooty()
            w = self._canvas.winfo_width()
            h = self._canvas.winfo_height()
            if w < 100 or h < 100:      # not mapped — trust the config
                w, h = sim_screens.WINDOW_W, sim_screens.WINDOW_H
            ImageGrab.grab(bbox=(x, y, x + w, y + h)).save(filepath)
        except Exception:
            pass
        finally:
            done.set()

    # ── Screen state machine ──

    def _advance_screen(self, command: str):
        if self.screen == SCREEN_CORE_MENU and command == "10":
            # Real app: first '10' lands on the second menu (7802)
            self.screen = SCREEN_MENU_2
        elif self.screen == SCREEN_MENU_2 and command == "10":
            # Second '10' opens the separate FINESⅢ login window (7803)
            self.screen = SCREEN_LOGIN
            self._login_fields = ["", "", ""]
            self._login_focus = 0
            if self.scenario == "center_not_ready":
                # Connecting to FINESIII is where the centre-not-ready
                # dialog appears (client evidence, Case 1).
                self._dialog = "center_not_ready"
        elif self.screen == SCREEN_LOGIN and command == "00":
            if self.scenario in LOGIN_ERRORS:
                # Rejected: the app clears the password field and keeps
                # the login screen up. NO retry loop here — the
                # dispatcher's RetryPolicy re-runs the whole request.
                self._login_error = LOGIN_ERRORS[self.scenario]
                self._login_fields[2] = ""
                self._login_focus = 1        # cursor back on 担当者コード
                return
            self.screen = SCREEN_BUSINESS_MENU
        elif self.screen == SCREEN_BUSINESS_MENU and command == "903":
            self.screen = SCREEN_TASK_903
            self._task_focus = -1
            self._task_values = {}
        elif self.screen == SCREEN_TASK_903 and command == "00":
            self.screen = SCREEN_CONFIRMATION
        elif self.screen == SCREEN_CONFIRMATION and command == "70":
            self.screen = SCREEN_RESULT
        elif self.screen == SCREEN_CONFIRMATION and command == "99":
            # Cancel — and also the exit path when the workflow returns
            # from the confirmation screen (e.g. already-deleted)
            self.screen = SCREEN_TASK_903
            self._task_focus = -1
            self._task_values = {}
            self._exit_caption = "エントリー画面へ戻ります (99)"
        elif self.screen == SCREEN_RESULT and command == "10":
            # The real terminal prints and appends プリント済 by itself
            # after the single '10' — no separate intermediate screen.
            self.screen = SCREEN_PRINT_DONE
        elif self.screen == SCREEN_PRINT and command == "10":
            self.screen = SCREEN_PRINT_DONE

        # ── Exit sequence (navigator.exit_application) ──
        # Each '99' steps BACK through the real screens so the logout
        # is visible on the UI: print → fresh DID:903 entry → 業務MENU
        # → FINESⅢ login (leftover affiliation still shown, as on the
        # real terminal) → menu window returns → 'XX' shuts down.
        # Every step sets an on-screen caption (approved fix B).
        elif self.screen in (SCREEN_PRINT_DONE, SCREEN_PRINT,
                             SCREEN_RESULT) and command == "99":
            self.screen = SCREEN_TASK_903
            self._task_focus = -1
            self._task_values = {}
            self._exit_caption = "ログアウト：エントリー画面へ戻ります (99)"
        elif self.screen == SCREEN_TASK_903 and command == "99":
            self.screen = SCREEN_BUSINESS_MENU
            self._exit_caption = "ログアウト：業務MENUへ戻ります (99)"
        elif self.screen == SCREEN_BUSINESS_MENU and command == "99":
            self.screen = SCREEN_LOGIN
            self._exit_caption = "ログアウト：ログイン画面へ戻ります (99)"
        elif self.screen == SCREEN_LOGIN and command == "99":
            # (終了:99) — the FINESⅢ window closes; the original menu
            # window is back in front (title switches automatically)
            self.screen = SCREEN_MENU_2
            self._exit_caption = \
                "ログアウト：ＦＩＮＥＳⅢ画面を終了 → メニューへ (99)"
        elif self.screen == SCREEN_MENU_2 and command == "99":
            self.screen = SCREEN_CORE_MENU
            self._exit_caption = "ログアウト：メニューへ戻ります (99)"
        elif command == "XX" and self.screen in (SCREEN_CORE_MENU,
                                                 SCREEN_MENU_2):
            self.screen = SCREEN_LOGOUT     # システム終了
            self._exit_caption = ""

        elif command == "903":
            self.screen = SCREEN_TASK_903

        # Forward navigation clears any logout narration
        if command in ("10", "00", "903", "70"):
            self._exit_caption = ""

    def _screen_text(self) -> str:
        """Machine-readable screen text — the ScreenState / test
        contract. Unchanged from v2; the Canvas visuals are richer but
        these identifier strings are what the bot logic sees."""
        if self.screen in _MENU_SCREENS:
            return ("基幹業務メニュー\n端末業務選択メニュー\nZ1966\n"
                    "10 基幹業務メニュー\n20 端末管理メニュー\n"
                    "40 補助機能\nXX システム終了")
        if self.screen == SCREEN_LOGIN:
            text = ("FUJI INFORMATION NETWORK\nAIM2/V04/P200HAAPROC\n"
                    "所属コード\n担当者コード\nパスワード")
            if self._login_error:
                text += "\n" + self._login_error
            return text
        if self.screen == SCREEN_BUSINESS_MENU:
            return "FINESⅢ 業務MENU\n業務ＮＯ\n903 パスワードDBの更新と追加"
        if self.screen == SCREEN_TASK_903:
            return ("業務No. 00903 パスワードDBの更新と追加\n処理確認\n"
                    "FID 100 101 104 105 002 003 006")
        if self.screen == SCREEN_CONFIRMATION:
            if self.scenario == "already_deleted":
                return "確認画面\nエラーコメント\n所属・社員コード誤り？削除済み"
            return (f"確認画面 この内容で受け付けます\n"
                    f"所属コード {self._last_affiliation}\n"
                    f"社員コード {self._last_employee_code}\n"
                    f"OK:70 記憶:80 取消:99")
        if self.screen == SCREEN_PRINT:
            return "下記の用紙をセットして下さい\n用紙コード A0001\n帳票名称"
        if self.screen == SCREEN_PRINT_DONE:
            return "プリント済\n用紙コード A0001"
        if self.screen == SCREEN_RESULT:
            if self.scenario == "error":
                return "処理結果\n登録処理\nE-9901 所属コード誤り"
            return "処理結果\n登録処理が完了しました\nO-0000"
        return ""

    def get_screen_content(self) -> str:
        """FULL printed mirror of what the canvas currently shows —
        the evidence .txt twin must carry the same data as the PNG
        (compliance fix 2026-08-17: account data was missing from the
        text files on the no-OCR path). Values come from the same
        state the renderers draw: login fields, the live FID table,
        command echo. get_screen_text() above keeps the minimal
        identifier contract the bot logic and tests depend on.

        Passwords are NOT masked here — the observer masks secret
        VALUES when writing the .txt (single masking point)."""
        lines = [self._screen_text()]

        if self.screen == SCREEN_LOGIN:
            lines = ["ＦＵＪＩ　ＩＮＦＯＲＭＡＴＩＯＮ　ＮＥＴＷＯＲＫ",
                     "AIM1/V04/P200HXXPROC",
                     f"所属コード　　： {self._login_fields[0]}",
                     f"担当者コード　： {self._login_fields[1]}",
                     f"パスワード　　： {self._login_fields[2]}",
                     "(終了:99)"]
            if self._login_error:
                lines.append(self._login_error)
        elif self.screen == SCREEN_BUSINESS_MENU:
            lines = ["ＦＩＮＥＳⅢ　◇◇◇業務ＭＥＮＵ◇◇◇",
                     f"所属　　： {self._login_fields[0]}",
                     f"担当者　： {self._login_fields[1]}　テスト　担当者",
                     f"業務ＮＯ： {self._input_buffer}"]
        elif self.screen in (SCREEN_TASK_903, SCREEN_CONFIRMATION):
            lines = ["業務No.00903　エントリー"
                     "　パスワードＤＢの更新と追加",
                     f"所属 {self._login_fields[0]}", "",
                     "  NO.  項目名称                          "
                     "FID   インプット内容"]
            for no, label, fid, key in sim_screens._TASK_ROWS:
                if not no:
                    continue
                value = self._task_values.get(key, "") if key else ""
                lines.append(f"  {no:<5}{label:　<20}{fid:>4}   {value}")
            if self.screen == SCREEN_CONFIRMATION:
                if self.scenario == "already_deleted":
                    lines += ["", "エラーコメント",
                              "所属・社員コード誤り？削除済み"]
                else:
                    lines += ["", "この内容で受け付けます",
                              "【確認】 送信:70　取消:99　　終了:99"
                              "　　＊最終頁"]
            else:
                lines += ["", "【確認】 送信:00　訂正:ENTER　　終了:99"
                          "　　＊最終頁"]
        elif self.screen in (SCREEN_RESULT, SCREEN_PRINT,
                             SCREEN_PRINT_DONE):
            if self.scenario == "error" and self.screen == SCREEN_RESULT:
                lines = ["処理結果", "登録処理", "E-9901 所属コード誤り"]
            else:
                lines = ["業務No.00903　エントリー"
                         "　パスワードＤＢの更新と追加",
                         "下記の用紙をセットして下さい",
                         "用紙コード　　: A0001",
                         "帳票名称　　　：連続シート",
                         "出力先プリンタ : FX ApeosPort-V C4476",
                         "印字枚数　　　：１枚",
                         "(O-0000)"]
                if self.screen == SCREEN_PRINT_DONE:
                    lines.append("プリント済")
                lines.append("【確認】 印字:10　　終了:99　　＊最終頁")

        if self._dialog:
            lines = self._dialog_text().split("\n") + [""] + lines
        if self._input_buffer and self.screen not in \
                (SCREEN_BUSINESS_MENU,):
            lines.append(f"入力: {self._input_buffer}")
        if self._status_line:
            lines.append(self._status_line)
        if self._exit_caption:
            lines.append(self._exit_caption)
        return "\n".join(lines)

    # ── Rendering ──

    def _render(self):
        title = (_MENU_TITLE if self.screen in
                 (SCREEN_BLANK,) + _MENU_SCREENS else _FINES_TITLE)
        login_affiliation = self._login_fields[0]
        self._ui_queue.put(("render", {
            "screen": self.screen,
            "scenario": self.scenario,
            "title": title,
            "input_buffer": self._input_buffer,
            "status_line": self._status_line,
            "login_fields": list(self._login_fields),
            "login_focus": self._login_focus,
            "task_values": dict(self._task_values),
            "exit_caption": self._exit_caption,
            "dialog": self._dialog,
            "login_error": self._login_error,
            # Session affiliation shown in the DID:903 header — the
            # login value without the dev "99" prefix (photo: 03325)
            "header_affiliation": (login_affiliation[-5:]
                                   if login_affiliation else "03325"),
            "last_affiliation": self._last_affiliation,
            "last_employee": self._last_employee_code,
        }))

    def _pause(self, factor: float = 1.0, minimum: float = 0.0):
        time.sleep(max(self.action_delay * factor, minimum))
