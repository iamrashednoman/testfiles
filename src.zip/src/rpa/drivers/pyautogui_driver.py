"""PyAutoGUI driver for FINESIII terminal automation.

Port of v2 drivers/pyautogui_driver.py, unchanged. Cross-platform
fallback driver that uses screen coordinates and keyboard input.

Use this when:
  - pywinauto selectors don't work with the terminal emulator
  - Running inside Citrix/VDI where window handles aren't accessible
  - Need a platform-independent solution

Known limitation carried from v2 (flagged for the QA phase): typewrite()
cannot produce Japanese input; non-ASCII text falls back to write(),
which may not reach legacy terminals reliably. The clipboard-paste
approach is the candidate fix once it can be validated on the real
Windows terminal.

Platform: Windows, macOS, Linux
"""

import platform
import subprocess
import time
from pathlib import Path

from src.core.exceptions import (
    ApplicationLaunchError, DriverError, ScreenTimeoutError,
)
from src.rpa.drivers.base import BaseDriver


class PyAutoGUIDriver(BaseDriver):
    """Cross-platform GUI automation via pyautogui + OCR fallback."""

    def __init__(self):
        self.config = {}
        self._pyautogui = None

    def initialize(self, config: dict) -> None:
        """Initialize with application configuration."""
        self.config = config
        try:
            import pyautogui
            pyautogui.FAILSAFE = True   # Move mouse to corner to abort
            pyautogui.PAUSE = 0.1       # Small pause between actions
            self._pyautogui = pyautogui
        except ImportError:
            raise DriverError(
                "pyautogui is required. Install with: pip install pyautogui",
                step="driver_init"
            )

    def launch_application(self) -> None:
        """Launch the terminal emulator application."""
        exe_path = self.config.get("executable_path", "")
        shortcut = self.config.get("desktop_shortcut", "Online Work")
        timeout = self.config.get("launch_timeout", 30)

        try:
            system = platform.system()
            if exe_path and Path(exe_path).exists():
                if system == "Windows":
                    subprocess.Popen([exe_path])
                else:
                    subprocess.Popen(["open", exe_path]
                                     if system == "Darwin" else [exe_path])
            else:
                # Windows: try desktop shortcut
                if system == "Windows":
                    import os
                    desktop = (Path(os.environ.get("USERPROFILE", ""))
                               / "Desktop")
                    shortcut_path = desktop / f"{shortcut}.lnk"
                    if shortcut_path.exists():
                        os.startfile(str(shortcut_path))
                    else:
                        raise FileNotFoundError(
                            f"Cannot find executable or shortcut: {shortcut}"
                        )

            # Wait for application to appear
            time.sleep(timeout / 3)

        except Exception as e:
            raise ApplicationLaunchError(
                f"Failed to launch terminal: {e}",
                step="launch_application"
            )

    def type_text(self, text: str, delay: float = 0.05) -> None:
        """Type text character by character."""
        try:
            self._pyautogui.typewrite(
                text, interval=delay
            ) if text.isascii() else self._pyautogui.write(text)
        except Exception as e:
            raise DriverError(f"Failed to type text: {e}", step="type_text")

    def press_key(self, key: str) -> None:
        """Press a keyboard key."""
        key_map = {
            "enter": "return",
            "tab": "tab",
            "escape": "esc",
            "backspace": "backspace",
            "delete": "delete",
        }
        try:
            mapped_key = key_map.get(key.lower(), key.lower())
            self._pyautogui.press(mapped_key)
        except Exception as e:
            raise DriverError(
                f"Failed to press key '{key}': {e}", step="press_key"
            )

    def send_field_value(self, field_id: str, value: str) -> None:
        """Enter a value at the current cursor position."""
        self.type_text(value)

    def get_screen_text(self) -> str:
        """Read screen text using OCR.
        Requires pytesseract and Tesseract OCR installed."""
        try:
            import pytesseract

            screenshot = self._pyautogui.screenshot()
            text = pytesseract.image_to_string(screenshot, lang="jpn+eng")
            return text

        except ImportError:
            # If OCR not available, return empty.
            # The bot will rely on timing rather than screen detection.
            return ""

        except Exception as e:
            raise DriverError(
                f"Failed to read screen text via OCR: {e}",
                step="get_screen_text"
            )

    def wait_for_screen(self, identifiers: list[str],
                        timeout: float = 15.0) -> bool:
        """Wait for screen using OCR or timing-based fallback."""
        start = time.time()
        while time.time() - start < timeout:
            try:
                text = self.get_screen_text()
                if text and all(ident in text for ident in identifiers):
                    return True
            except Exception:
                pass
            time.sleep(2.0)  # OCR is slow — poll less frequently

        # If OCR isn't available, fall back to timing
        # (assumes the screen loaded after the timeout period)
        if not identifiers:
            return True

        raise ScreenTimeoutError(
            f"Screen with identifiers {identifiers} not detected "
            f"within {timeout}s",
            step="wait_for_screen"
        )

    def screen_contains(self, text: str) -> bool:
        """Check screen text via OCR."""
        try:
            screen_text = self.get_screen_text()
            return text in screen_text
        except Exception:
            return False

    def take_screenshot(self, filepath: str) -> None:
        """Capture full-screen screenshot."""
        try:
            screenshot = self._pyautogui.screenshot()
            screenshot.save(filepath)
        except Exception as e:
            raise DriverError(
                f"Failed to capture screenshot: {e}",
                step="take_screenshot"
            )

    def close_application(self) -> None:
        """Close the application via keyboard."""
        try:
            self.type_text("99")
            self.press_key("enter")
            time.sleep(2)
            # Alt+F4 as fallback
            self._pyautogui.hotkey("alt", "F4")
        except Exception:
            pass
