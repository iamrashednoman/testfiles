"""TN3270 driver for direct Fujitsu mainframe protocol access.

Port of v2 drivers/tn3270_driver.py, unchanged. Connects directly to
the mainframe via TN3270 protocol, bypassing the terminal emulator GUI
entirely. This is the MOST RELIABLE driver if the mainframe supports
TN3270/TN5250.

Platform: Any (pure protocol — no GUI dependency)
Requires: x3270 / s3270 installed on the system
"""

import time

from src.core.exceptions import (
    ApplicationLaunchError, DriverError, ScreenTimeoutError,
)
from src.rpa.drivers.base import BaseDriver


class TN3270Driver(BaseDriver):
    """Direct mainframe protocol automation via py3270."""

    def __init__(self):
        self.emulator = None
        self.config = {}

    def initialize(self, config: dict) -> None:
        """Initialize with connection configuration."""
        self.config = config
        try:
            from py3270 import Emulator
            self._Emulator = Emulator
        except ImportError:
            raise DriverError(
                "py3270 is required for TN3270 driver. "
                "Install with: pip install py3270. "
                "Also requires x3270 or s3270 installed on the system.",
                step="driver_init"
            )

    def launch_application(self) -> None:
        """Connect to the mainframe via TN3270 protocol.
        This replaces 'launching' the terminal emulator — we connect
        directly to the host."""
        host = self.config.get("tn3270_host", "")
        port = self.config.get("tn3270_port", 23)
        timeout = self.config.get("launch_timeout", 30)

        if not host:
            raise ApplicationLaunchError(
                "tn3270_host not configured. "
                "Add: application.tn3270_host: <mainframe_host>",
                step="launch_application"
            )

        try:
            # s3270 (scriptable, no GUI) for headless operation;
            # x3270 for visible GUI debugging
            visible = self.config.get("tn3270_visible", False)
            self.emulator = self._Emulator(visible=visible, timeout=timeout)
            self.emulator.connect(f"{host}:{port}")
            self.emulator.wait_for_field()
        except Exception as e:
            raise ApplicationLaunchError(
                f"Failed to connect to mainframe at {host}:{port}: {e}",
                step="launch_application"
            )

    def type_text(self, text: str, delay: float = 0.05) -> None:
        """Type text into the current field."""
        if not self.emulator:
            raise DriverError("Not connected to mainframe", step="type_text")
        try:
            self.emulator.send_string(text)
        except Exception as e:
            raise DriverError(f"Failed to type text: {e}", step="type_text")

    def press_key(self, key: str) -> None:
        """Press a mainframe key."""
        if not self.emulator:
            raise DriverError("Not connected", step="press_key")

        key_map = {
            "enter": "Enter",
            "tab": "Tab",
            "backtab": "BackTab",
            "f1": "PF(1)", "f2": "PF(2)", "f3": "PF(3)",
            "f4": "PF(4)", "f5": "PF(5)", "f6": "PF(6)",
            "f7": "PF(7)", "f8": "PF(8)", "f9": "PF(9)",
            "f10": "PF(10)", "f11": "PF(11)", "f12": "PF(12)",
            "clear": "Clear",
            "home": "Home",
            "delete": "Delete",
            "pa1": "PA(1)", "pa2": "PA(2)",
        }

        try:
            mapped = key_map.get(key.lower(), key)
            self.emulator.exec_command(f"{mapped}".encode())
            self.emulator.wait_for_field()
        except Exception as e:
            raise DriverError(
                f"Failed to press key '{key}': {e}", step="press_key"
            )

    def send_field_value(self, field_id: str, value: str) -> None:
        """Move to a specific field by row/col and enter a value.
        For TN3270, fields can be addressed by screen coordinates."""
        if "," in str(field_id):
            row, col = field_id.split(",")
            try:
                self.emulator.move_to(int(row), int(col))
            except Exception as e:
                raise DriverError(
                    f"Failed to move to field {field_id}: {e}",
                    step="send_field_value"
                )
        self.type_text(value)

    def get_screen_text(self) -> str:
        """Read the full mainframe screen buffer."""
        if not self.emulator:
            raise DriverError("Not connected", step="get_screen_text")
        try:
            # Read all 24 rows x 80 columns (standard 3270 screen)
            lines = []
            for row in range(1, 25):
                line = self.emulator.string_get(row, 1, 80)
                lines.append(line)
            return "\n".join(lines)
        except Exception as e:
            raise DriverError(
                f"Failed to read screen: {e}", step="get_screen_text"
            )

    def wait_for_screen(self, identifiers: list[str],
                        timeout: float = 15.0) -> bool:
        """Wait for screen content to match identifiers."""
        start = time.time()
        while time.time() - start < timeout:
            try:
                self.emulator.wait_for_field()
                text = self.get_screen_text()
                if all(ident in text for ident in identifiers):
                    return True
            except Exception:
                pass
            time.sleep(1.0)

        raise ScreenTimeoutError(
            f"Screen with identifiers {identifiers} not detected "
            f"within {timeout}s",
            step="wait_for_screen"
        )

    def screen_contains(self, text: str) -> bool:
        """Check if screen buffer contains text."""
        try:
            return text in self.get_screen_text()
        except Exception:
            return False

    def take_screenshot(self, filepath: str) -> None:
        """Save the screen buffer as text (TN3270 has no GUI to
        screenshot). For audit purposes, save the raw text content."""
        try:
            text = self.get_screen_text()
            # Save as text file alongside the expected image path
            text_path = filepath.rsplit(".", 1)[0] + ".txt"
            with open(text_path, "w", encoding="utf-8") as f:
                f.write(f"{'=' * 80}\n")
                f.write(f"Screen capture at "
                        f"{time.strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write(f"{'=' * 80}\n")
                f.write(text)
        except Exception as e:
            raise DriverError(
                f"Failed to save screen text: {e}", step="take_screenshot"
            )

    def close_application(self) -> None:
        """Disconnect from the mainframe."""
        if self.emulator:
            try:
                self.emulator.terminate()
            except Exception:
                pass
            self.emulator = None
