"""Mock Driver — simulates the FINESIII terminal for testing without
the mainframe. Port of v2 drivers/mock_driver.py, unchanged.

Instead of touching a terminal, it:
  1. Records every action (commands, keystrokes, field entries) in order
  2. Tracks an internal "screen state" that advances as the bot navigates
  3. Returns the correct Japanese screen text for each stage so the bot's
     screen-detection and validation logic passes naturally
  4. Echoes the actual employee code (from the request) into the
     confirmation screen, so confirmation validation works dynamically

Configurable scenarios (via app_config["mock_scenario"]):
  - "success"          → confirmation shows data, result O-0000
  - "already_deleted"  → confirmation shows 削除済み
  - "error"            → result E-9901 (invalid branch code)
  - "login_password_incorrect"
                       → the login screen rejects the credentials with
                         パスワードが誤っています and does NOT advance
                         (client evidence, Case 2)
  - "invalid_affiliation_code"
                       → the login screen rejects the affiliation /
                         operator pairing with オペレーターコード未登録です
                         (client evidence, Case 3)
  - "center_not_ready" → a modal 「エラーメッセージ」 dialog (センター準備中)
                         blocks the FINESIII connection, as in the client
                         evidence for Case 1: nothing the bot types
                         reaches the mainframe until it is acknowledged
                         with ENTER
  - "unreadable"       → get_screen_text() returns only the window TITLE,
                         mimicking the REAL client terminal where the body
                         is not machine-readable (exercises the
                         UNCONFIRMED-success path)
"""

import time

from src.rpa.drivers.base import BaseDriver

# Screen states the mock progresses through
SCREEN_CORE_MENU = "core_menu"
SCREEN_LOGIN = "login"
SCREEN_BUSINESS_MENU = "business_menu"
SCREEN_TASK_903 = "task_903"
SCREEN_CONFIRMATION = "confirmation"
SCREEN_RESULT = "result"
SCREEN_PRINT = "print"
SCREEN_PRINT_DONE = "print_done"

# Login rejections, keyed by scenario. The screen stays put and shows
# the message; adding another one is a row here, not new logic.
LOGIN_ERRORS = {
    "login_password_incorrect": "パスワードが誤っています",
    # Cases 3 and 4 are DIFFERENT root causes (wrong affiliation code vs
    # wrong staff code) that FINESIII reports with the SAME text. Two
    # scenario names so QA can drive each case by name; identical
    # output, because the real terminal gives the bot nothing to tell
    # them apart.
    "invalid_affiliation_code": "オペレーターコード未登録です",
    "invalid_staff_code": "オペレーターコード未登録です",
}


class MockDriver(BaseDriver):
    """Simulates the FINESIII terminal for off-mainframe testing."""

    def __init__(self):
        self.scenario = "success"
        self.action_log = []          # ordered list of every action
        self.typed_values = []        # everything typed (dynamic request data)
        self.commands = []            # every submit_command
        self.keys = []                # every press_key
        self.screen = SCREEN_CORE_MENU
        self.delay_factor = 0.0       # set >0 to simulate realistic timing

        self._last_employee_code = ""
        self._last_affiliation = ""
        self._field_entry_count = 0
        self._task_entries = []       # values typed on the DID:903 table
        # Modal error dialog currently blocking the terminal. Set when
        # the center_not_ready scenario reaches the login screen;
        # cleared by the acknowledge ENTER.
        self._dialog = ""
        # Login rejected by the host: the screen stays put and shows
        # the message, as the real one does. Holds the message text.
        self._login_error = ""

    # ── Driver interface ──

    def initialize(self, config: dict) -> None:
        self.scenario = config.get("mock_scenario", "success")
        self.delay_factor = config.get("mock_delay_factor", 0.0)
        self._record("initialize", f"scenario={self.scenario}")

    def launch_application(self) -> None:
        self._record("launch_application")
        self.screen = SCREEN_CORE_MENU
        self._sleep()

    def type_text(self, text: str, delay: float = 0.05) -> None:
        self.typed_values.append(text)
        self._record("type_text", text)

        # Capture dynamic field data for confirmation echo.
        # Employee codes are 7 chars; affiliation are 5 digits.
        stripped = text.strip()
        if stripped and self.screen == SCREEN_TASK_903:
            self._task_entries.append(stripped)
        if len(stripped) == 7 and self.screen == SCREEN_TASK_903:
            self._last_employee_code = stripped
        elif len(stripped) == 5 and stripped.isdigit() \
                and self.screen == SCREEN_TASK_903:
            self._last_affiliation = stripped

        self._sleep()

    def press_key(self, key: str) -> None:
        self.keys.append(key)
        self._record("press_key", key)
        # The acknowledge key dismisses a modal dialog. Client-confirmed
        # for Case 1: it clears and does not reappear.
        if self._dialog and key.lower() == "enter":
            self._record("dialog_dismissed", self._dialog)
            self._dialog = ""
        # Login rejected by the host: the screen stays put and shows
        # the message, as the real one does. Holds the message text.
        self._login_error = ""
        self._sleep()

    def send_field_value(self, field_id: str, value: str) -> None:
        self.typed_values.append(value)
        self._record("send_field_value", f"{field_id}={value}")
        self._sleep()

    def submit_command(self, command: str, delay: float = 0.5,
                       before_enter=None) -> None:
        self.commands.append(command)
        self._record("submit_command", command)
        # Evidence seam: hook fires before the screen advances, so a
        # capture here shows the pre-submit state.
        if before_enter is not None:
            try:
                before_enter()
            except Exception:
                pass
        self._advance_screen(command)
        self._sleep()

    def get_screen_text(self) -> str:
        # The "unreadable" scenario mimics the REAL client terminal, where
        # the screen BODY is not machine-readable and get_screen_text()
        # returns only the window TITLE. This is the exact condition the
        # body-marker validation and UNCONFIRMED-result logic were built
        # for. Use it to verify the bot PROCEEDS (does not false-cancel)
        # when it cannot read the confirmation/result screens.
        if self.scenario == "unreadable":
            return "FINESⅢ"
        # A modal dialog is what the bot actually sees — it covers the
        # screen underneath, so it leads the read.
        if self._dialog:
            return self._dialog_text() + "\n" + self._screen_text()
        return self._screen_text()

    def wait_for_screen(self, identifiers, timeout: float = 15.0) -> bool:
        # Mock always "finds" the screen instantly
        self._record("wait_for_screen", str(identifiers))
        return True

    def screen_contains(self, text: str) -> bool:
        return text in self._screen_text()

    def take_screenshot(self, filepath: str) -> None:
        # Write a tiny placeholder file so evidence paths exist
        try:
            from pathlib import Path
            p = Path(filepath)
            p.parent.mkdir(parents=True, exist_ok=True)
            # Minimal valid PNG (1x1 transparent)
            png_bytes = bytes.fromhex(
                "89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c489"
                "0000000d49444154789c6360000002000100ffff00000002000100"
                "5c6f3b310000000049454e44ae426082"
            )
            p.write_bytes(png_bytes)
        except Exception:
            pass
        self._record("take_screenshot", filepath)

    def close_application(self) -> None:
        self._record("close_application")
        self._sleep()

    def clear_field(self, count: int = 8) -> None:
        """Mock stub: record the field-clear that precedes the final
        FINESIII '99' during logout."""
        self._record("clear_field", f"spaces={count}")
        self._sleep()

    def goto_first_field_and_exit(self, exit_code: str = "99",
                                  field_width: int = 7,
                                  backtab_count: int = 4) -> None:
        """Mock stub: record the anchor-to-first-field exit performed
        during logout, then submit the exit code so the mock screen
        state advances correctly."""
        self._record("goto_first_field_and_exit",
                     f"code={exit_code} width={field_width} "
                     f"backtab={backtab_count}")
        self.submit_command(exit_code)

    def reattach_to_menu_window(self, menu_title: str = "基幹業務",
                                timeout: float = 15.0) -> bool:
        """Mock stub: record the re-attach to the Main Menu window during
        logout (real driver matches by window class + title marker)."""
        self._record("reattach_to_menu_window", f"title={menu_title}")
        self._sleep()
        return True

    # ── Screen state machine ──

    def _advance_screen(self, command: str):
        """Advance the simulated screen based on the command entered."""
        if self._dialog:
            # A modal swallows every keystroke — the screen cannot
            # advance until it is acknowledged (the real failure mode
            # this scenario reproduces).
            return
        if self.screen == SCREEN_CORE_MENU and command == "10":
            self.screen = SCREEN_LOGIN
            if self.scenario == "center_not_ready":
                self._dialog = "CENTER_NOT_READY"
        elif self.screen == SCREEN_LOGIN and command == "00":
            if self.scenario in LOGIN_ERRORS:
                # Rejected: the app clears the password field and stays
                # on the login screen. No retry loop here — the
                # dispatcher's RetryPolicy re-runs the whole request.
                self._login_error = LOGIN_ERRORS[self.scenario]
                return
            self.screen = SCREEN_BUSINESS_MENU
        elif self.screen == SCREEN_BUSINESS_MENU and command == "903":
            self.screen = SCREEN_TASK_903
            self._field_entry_count = 0
        elif self.screen == SCREEN_TASK_903 and command == "00":
            # "00" generates the confirmation screen (does NOT commit)
            self.screen = SCREEN_CONFIRMATION
        elif self.screen == SCREEN_CONFIRMATION and command == "70":
            # "70" commits → result screen
            self.screen = SCREEN_RESULT
        elif self.screen == SCREEN_CONFIRMATION and command == "99":
            # cancel
            self.screen = SCREEN_TASK_903
        elif self.screen == SCREEN_RESULT and command == "10":
            # print
            self.screen = SCREEN_PRINT
        elif self.screen == SCREEN_PRINT and command == "10":
            self.screen = SCREEN_PRINT_DONE
        elif command == "903":
            # re-navigation in batch
            self.screen = SCREEN_TASK_903
        # 99 / XX during logout: no screen text needed

    def _screen_text(self) -> str:
        """Return the Japanese screen text for the current state.
        Dynamic data (employee code) is injected where validated."""

        if self.screen == SCREEN_CORE_MENU:
            return "基幹業務メニュー\nZ1634\n10 FINESⅢ\n30 アウトプット配信システム"

        if self.screen == SCREEN_LOGIN:
            text = ("FUJI INFORMATION NETWORK\nAIM2/V04/P200HAAPROC\n"
                    "所属コード\n担当者コード\nパスワード")
            if self._login_error:
                text += "\n" + self._login_error
            return text

        if self.screen == SCREEN_BUSINESS_MENU:
            return "FINESⅢ 業務MENU\n業務ＮＯ\n903 パスワードDBの更新と追加"

        if self.screen == SCREEN_TASK_903:
            return ("業務No. 00903 パスワードDBの更新と追加\n処理確認\n"
                    "FID 100 101 104 105 002 003 006")

        if self.screen == SCREEN_CONFIRMATION:
            # Inject the ACTUAL employee code from the request (dynamic)
            if self.scenario == "already_deleted":
                return ("確認画面\nエラーコメント\n"
                        "所属・社員コード誤り？削除済み")
            return (f"確認画面 この内容で受け付けます\n"
                    f"所属コード {self._last_affiliation}\n"
                    f"社員コード {self._last_employee_code}\n"
                    f"OK:70 記憶:80 取消:99")

        if self.screen in (SCREEN_RESULT, SCREEN_PRINT, SCREEN_PRINT_DONE):
            if self.screen == SCREEN_PRINT:
                return "下記の用紙をセットして下さい\n用紙コード A0001\n帳票名称"
            if self.screen == SCREEN_PRINT_DONE:
                return "プリント済\n用紙コード A0001"
            # Result screen — bottom line has the code
            if self.scenario == "error":
                return "処理結果\n登録処理\nE-9901 所属コード誤り"
            return "処理結果\n登録処理が完了しました\nO-0000"

        return ""

    def _dialog_text(self) -> str:
        """The modal error dialog, transcribed from the client
        evidence capture (Case 1)."""
        return ("エラーメッセージ\n"
                " F I N E S\n"
                "WRT   0000 0151 0000 00000000\n"
                "NDSUB\n"
                "センター準備中\n"
                "確認：ＥＮＴＥＲ")

    def get_screen_content(self) -> str:
        """Printed mirror for the evidence .txt files: the identifier
        text PLUS the entered account data on the DID:903/confirmation
        screens (compliance: the text twin carries the same data as
        the screenshot). Secret values are masked by the observer."""
        content = self._screen_text()
        if self._dialog:
            content = self._dialog_text() + "\n" + content
        if self.screen in (SCREEN_TASK_903, SCREEN_CONFIRMATION) \
                and self._task_entries:
            content += ("\nインプット内容: "
                        + "　".join(self._task_entries))
        return content

    # ── Helpers ──

    def _record(self, action: str, detail: str = ""):
        self.action_log.append({
            "seq": len(self.action_log) + 1,
            "action": action,
            "detail": detail,
            "screen": self.screen,
        })

    def _sleep(self):
        if self.delay_factor > 0:
            time.sleep(self.delay_factor)

    # ── Inspection (for tests / trace output) ──

    def get_action_trace(self) -> list:
        return self.action_log
