"""Visual verification layer — screen reading, path classification,
printed evidence text.

Strategy, in order of preference:

1. Control/UIA text read (via driver) — fastest, used when exposed.
   On the real client terminal only the window TITLE is exposed.
2. OCR — PaddleOCR with the pinned PP-OCRv5 Japanese models
   (client-approved 2026-08-17, revising the earlier no-ML stance):
   reads the graphically-rendered screen body the driver cannot.
   Inference only — local, offline, stateless, nothing retained or
   transmitted; models pre-staged under models/paddleocr.
3. Deterministic navigation remains primary: OCR is UPGRADE-ONLY.
   It confirms results (O-0000/E-xxxx instead of UNCONFIRMED) and
   spots 削除済み before commit, but a low-confidence read can never
   turn a deterministic success path into a failure.

Modules:
  ocr.py         engine abstraction (PaddleOcrEngine / NullOcrEngine)
  keywords.py    normalization, keyword rules, PathClassifier
  screen_text.py printed-pattern .txt evidence files (passwords masked)
"""
