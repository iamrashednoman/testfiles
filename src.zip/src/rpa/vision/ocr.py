"""OCR engines — pluggable screen-text recognition.

PaddleOCR (Apache-2.0, PP-OCRv5 Japanese models) reads the terminal
screen body that the real client terminal never exposes through UIA —
the window renders its text graphically, so get_screen_text() returns
only the title. OCR runs on the SAME window captures the evidence
system already takes; inference is local, stateless, and offline (the
models are pre-staged under ocr.model_dir — no network at runtime, no
telemetry, nothing the model reads is retained or transmitted).

Engine contract: read_image(path) -> list[OcrLine], sorted in reading
order (top→bottom, left→right). NullOcrEngine returns [] and costs
nothing — with it, the observed driver is a pure pass-through, which is
how the py3.14 dev environment (no paddlepaddle wheels) and the CI
suite run. PaddleOCR requires Python 3.9–3.13.

OCR is MANDATORY on real terminal drivers (client requirement): if the
engine cannot load there, startup fails fast rather than silently
degrading. Sim/mock drivers fall back to the Null engine with a
warning so development keeps working without the OCR extra installed.
"""
from __future__ import annotations

import os
import threading
from dataclasses import dataclass, field
from pathlib import Path


class OcrUnavailableError(RuntimeError):
    """The configured OCR engine cannot be loaded on this host."""


@dataclass
class OcrLine:
    """One recognized text line with its position on screen."""
    text: str
    confidence: float = 1.0
    # Bounding box in pixels: x (left), y (top), w, h
    box: tuple = field(default=(0, 0, 0, 0))


class NullOcrEngine:
    """No-op engine: OCR disabled or unavailable (sim/mock fallback)."""

    name = "null"
    available = False

    def read_image(self, filepath: str) -> list[OcrLine]:
        return []


class PaddleOcrEngine:
    """PaddleOCR wrapper — one instance per process, lazily loaded.

    Model load costs seconds and a few hundred MB of RAM, so the
    pipeline is built once and reused; inference is serialized behind a
    lock (PaddleOCR pipelines are not thread-safe — irrelevant at
    max_concurrent_sessions=1 but required for Phase 2 workers).
    """

    name = "paddle"
    available = True

    def __init__(self, lang: str = "japan", model_dir: str = "",
                 allow_download: bool = False, logger=None):
        self.lang = lang
        self.model_dir = Path(model_dir) if model_dir else None
        self.allow_download = allow_download
        self.logger = logger
        self._pipeline = None
        self._lock = threading.Lock()

    # ── Loading ──

    def load(self) -> None:
        """Import paddleocr and build the pipeline. Raises
        OcrUnavailableError with an actionable message on failure."""
        if self._pipeline is not None:
            return

        # Offline / no-telemetry posture BEFORE the import.
        os.environ.setdefault("PADDLE_PDX_DISABLE_USAGE_LOGGING", "True")
        os.environ.setdefault("DISABLE_TELEMETRY", "True")
        if not self.allow_download:
            os.environ.setdefault("PADDLE_PDX_MODEL_SOURCE", "local")

        try:
            from paddleocr import PaddleOCR
        except ImportError as e:
            raise OcrUnavailableError(
                "paddleocr is not installed in this environment "
                f"({e}). Install the OCR extra into a Python 3.9-3.13 "
                "venv: pip install -r requirements-ocr.txt "
                "(paddlepaddle has no Python 3.14 wheels yet)."
            ) from e

        kwargs = {
            "lang": self.lang,
            # Fixed upright terminal screens: the document-preprocessing
            # stages add latency and nondeterminism for zero gain here.
            "use_doc_orientation_classify": False,
            "use_doc_unwarping": False,
            "use_textline_orientation": False,
        }
        det_dir, rec_dir = self._local_model_dirs()
        if det_dir and rec_dir:
            kwargs["text_detection_model_dir"] = str(det_dir)
            kwargs["text_recognition_model_dir"] = str(rec_dir)
        elif not self.allow_download:
            raise OcrUnavailableError(
                f"OCR models not found under '{self.model_dir}' and "
                "ocr_allow_download is off (offline posture). Pre-stage "
                "the pinned models with: python scripts/"
                "download_ocr_models.py"
            )

        try:
            self._pipeline = PaddleOCR(**kwargs)
        except TypeError:
            # Older 2.x constructor signature.
            self._pipeline = PaddleOCR(
                lang=self.lang, show_log=False, use_angle_cls=False)
        except Exception as e:
            raise OcrUnavailableError(
                f"PaddleOCR pipeline failed to initialize: {e}") from e

        if self.logger:
            self.logger.info(
                f"OCR engine ready: paddleocr lang={self.lang} "
                f"models={'local' if det_dir else 'downloaded'}")

    def _local_model_dirs(self):
        """Locate pre-staged det/rec model dirs under model_dir.
        Layout (written by scripts/download_ocr_models.py):
          <model_dir>/det/  <model_dir>/rec/"""
        if not self.model_dir:
            return None, None
        det, rec = self.model_dir / "det", self.model_dir / "rec"
        if det.is_dir() and rec.is_dir() and any(det.iterdir()) \
                and any(rec.iterdir()):
            return det, rec
        return None, None

    # ── Inference ──

    def read_image(self, filepath: str) -> list[OcrLine]:
        """OCR one screenshot file into positioned lines, reading order."""
        self.load()
        with self._lock:
            try:
                predict = getattr(self._pipeline, "predict", None)
                if predict is not None:
                    raw = predict(str(filepath))
                    lines = self._from_v3_result(raw)
                else:
                    raw = self._pipeline.ocr(str(filepath), cls=False)
                    lines = self._from_v2_result(raw)
            except Exception as e:
                # An OCR hiccup must never fail a transaction — the
                # UNCONFIRMED semantics remain the safety net.
                if self.logger:
                    self.logger.warning(f"OCR read failed: {e}")
                return []
        return _sort_reading_order(lines)

    @staticmethod
    def _from_v3_result(raw) -> list[OcrLine]:
        """PaddleOCR 3.x predict() → OcrLine list."""
        lines = []
        for page in raw or []:
            data = page if isinstance(page, dict) else getattr(
                page, "json", None) or {}
            if not isinstance(data, dict):
                data = {}
            res = data.get("res", data)
            # rec_* may be numpy arrays — never boolean-test them
            # directly ("truth value of an array is ambiguous").
            texts = res.get("rec_texts")
            texts = [] if texts is None else list(texts)
            scores = res.get("rec_scores")
            scores = [] if scores is None else list(scores)
            boxes = res.get("rec_boxes")
            if boxes is None:
                boxes = res.get("rec_polys")
            boxes = [] if boxes is None else list(boxes)
            for i, text in enumerate(texts):
                score = float(scores[i]) if i < len(scores) else 1.0
                box = _to_xywh(boxes[i]) if i < len(boxes) else (0, 0, 0, 0)
                if str(text).strip():
                    lines.append(OcrLine(str(text), score, box))
        return lines

    @staticmethod
    def _from_v2_result(raw) -> list[OcrLine]:
        """PaddleOCR 2.x .ocr() → OcrLine list."""
        lines = []
        for page in raw or []:
            for item in page or []:
                try:
                    poly, (text, score) = item
                except (TypeError, ValueError):
                    continue
                if str(text).strip():
                    lines.append(OcrLine(str(text), float(score),
                                         _to_xywh(poly)))
        return lines


def _to_xywh(box) -> tuple:
    """Normalize a polygon/rect from either API shape into (x, y, w, h).
    Handles numpy rows (float() works on numpy scalars; four POINTS
    raise TypeError and fall through to the polygon branch)."""
    try:
        pts = list(box)
        if len(pts) == 4:
            try:
                x1, y1, x2, y2 = (float(v) for v in pts)  # rect
                return (int(x1), int(y1), int(x2 - x1), int(y2 - y1))
            except (TypeError, ValueError):
                pass
        xs = [float(p[0]) for p in pts]   # polygon
        ys = [float(p[1]) for p in pts]
        return (int(min(xs)), int(min(ys)),
                int(max(xs) - min(xs)), int(max(ys) - min(ys)))
    except Exception:
        return (0, 0, 0, 0)


def _sort_reading_order(lines: list[OcrLine]) -> list[OcrLine]:
    """Sort into rows top→bottom, left→right inside a row. Rows are
    grouped by vertical overlap (tolerance = half the median height)."""
    if not lines:
        return []
    heights = sorted(ln.box[3] or 16 for ln in lines)
    tol = max(6, heights[len(heights) // 2] // 2)
    rows: list[list[OcrLine]] = []
    for ln in sorted(lines, key=lambda l: (l.box[1], l.box[0])):
        for row in rows:
            if abs(row[0].box[1] - ln.box[1]) <= tol:
                row.append(ln)
                break
        else:
            rows.append([ln])
    ordered = []
    for row in rows:
        ordered.extend(sorted(row, key=lambda l: l.box[0]))
    return ordered


REAL_DRIVERS = ("pywinauto", "pyautogui", "tn3270")


def ocr_problem(driver_name: str, enabled) -> str:
    """Why this driver and OCR switch may not be combined ('' = they may).
    Screen reading is a client-mandated control on the real terminal
    (TM-01, 2026-10-03): the same rule for the This machine page, the
    Settings page and the start of the service."""
    if str(driver_name or "").strip().lower() in REAL_DRIVERS \
            and not enabled:
        return ("Screen reading (OCR) is mandatory with the real terminal "
                f"driver '{driver_name}' — switch Settings > Screen "
                "reading > Read screens with OCR back on.")
    return ""


def build_ocr_engine(ocr_cfg: dict, driver_name: str, logger=None):
    """Engine factory with the mandatory-OCR startup semantics.

    Real drivers + OCR enabled: the engine MUST load — a failure aborts
    startup (fail-fast, no silent degradation of a mandatory control).
    Real drivers + OCR disabled: refused the same way (TM-01).
    Sim/mock drivers: fall back to NullOcrEngine with a warning so the
    dev/CI environments run without the OCR extra installed.
    """
    if not ocr_cfg.get("enabled", True):
        problem = ocr_problem(driver_name, False)
        if problem:
            raise OcrUnavailableError(problem)
        return NullOcrEngine()

    engine = PaddleOcrEngine(
        lang=ocr_cfg.get("lang", "japan"),
        model_dir=ocr_cfg.get("model_dir", ""),
        allow_download=ocr_cfg.get("allow_download", False),
        logger=logger,
    )
    try:
        engine.load()
        return engine
    except OcrUnavailableError as e:
        if driver_name in REAL_DRIVERS:
            raise
        if logger:
            logger.warning(
                f"OCR unavailable on driver '{driver_name}' — running "
                f"with the null engine (screen text still audited from "
                f"the driver's native reads). {e}")
        return NullOcrEngine()
