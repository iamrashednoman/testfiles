"""Keyword rules + path classification for screen reads.

Classifies every screen the bot sees onto the success or failed path
by matching keyword rules (config/ocr.yaml) against the recognized
text. OCR output is noisy — fullwidth digits, stray spaces, O/0
confusion in result codes — so matching runs over a normalized copy.

Safety contract (upgrade-only): classification may only ADD
information — confirm a success code the driver could not read, or
spot 削除済み before commit. A low-confidence or ambiguous read
classifies as "unknown", which changes nothing: the workflows keep
their deterministic UNCONFIRMED semantics.
"""
from __future__ import annotations

import re
import unicodedata
from pathlib import Path

MASK = "********"

# Success / failure paths a screen read can be classified onto.
PATH_SUCCESS = "success"
PATH_BUSINESS_ERROR = "business_error"
PATH_SYSTEM_ERROR = "system_error"
PATH_IN_PROGRESS = "in_progress"
PATH_UNKNOWN = "unknown"

_HYPHENS = "‐‑‒–—―−ー－"
_DEFAULT_RULES = {
    "success_markers": ["O-0000", "プリント済", "正常終了", "完了しました"],
    "business_error_markers": ["削除済み", "エラーコメント", "誤り"],
    # Environment/infrastructure failures — the request is fine, the
    # host or the session is not. Classified apart from business
    # errors because they are RETRYABLE (see config/errors.yaml).
    "system_error_markers": ["センター準備中", "通信エラー",
                             "パスワードが誤っています",
                             "オペレーターコード未登録です"],
    "error_code_pattern": r"E-\d{4}",
    "success_code": "O-0000",
}


def normalize_text(text: str) -> str:
    """Fold OCR variance: NFKC (fullwidth→ASCII), unify hyphen glyphs,
    drop spaces, uppercase. ー (long vowel mark) is preserved inside
    Japanese words; it only maps to '-' when between ASCII."""
    if not text:
        return ""
    out = unicodedata.normalize("NFKC", text)
    chars = []
    for i, ch in enumerate(out):
        if ch in _HYPHENS:
            prev_ascii = i > 0 and out[i - 1].isascii() \
                and out[i - 1].isalnum()
            next_ascii = i + 1 < len(out) and out[i + 1].isascii() \
                and out[i + 1].isalnum()
            chars.append("-" if (prev_ascii or next_ascii) else ch)
        elif ch.isspace():
            continue
        else:
            chars.append(ch)
    return "".join(chars).upper()


def canonical_result_code(text: str) -> str | None:
    """Extract a canonical result code from (possibly noisy) text.
    'Ｏ－００００', '0-0000' (zero misread) → 'O-0000';
    'Ｅ－９９０１' → 'E-9901'. None when no code is present."""
    norm = normalize_text(text)
    # Lookbehind blocks substring hits inside longer tokens
    # ("DE-9901", "10-0000").
    m = re.search(r"(?<![A-Z0-9])E-(\d{4})(?!\d)", norm)
    if m:
        return f"E-{m.group(1)}"
    if re.search(r"(?<![A-Z0-9])[O0]-0000(?!\d)", norm):
        return "O-0000"
    return None


def mask_values(text: str, secrets=()) -> str:
    """Replace every secret VALUE (password strings) with a mask —
    key-based redaction cannot catch a bare typed value."""
    if not text:
        return text
    for secret in secrets:
        if secret:
            text = text.replace(secret, MASK)
    return text


def load_rules(path: str | None = None) -> dict:
    """Load keyword rules from config/ocr.yaml, merged over defaults.
    A missing/broken file falls back to the built-in defaults — the
    classifier must always work."""
    rules = dict(_DEFAULT_RULES)
    if path and Path(path).is_file():
        try:
            import yaml
            with open(path, "r", encoding="utf-8") as f:
                data = yaml.safe_load(f) or {}
            rules.update({k: v for k, v in
                          (data.get("keywords") or {}).items()
                          if v not in (None, "", [])})
        except Exception:
            pass
    return rules


def match_screen(screens_cfg: dict, text: str) -> str:
    """Identify the screen by the layouts.yaml identifiers (same ≥50%
    scoring as ScreenState.detect_current_screen, but standalone so the
    observer needs no driver). Returns the screen key or ""."""
    if not text:
        return ""
    norm = normalize_text(text)
    best, best_score = "", 0.0
    screens = screens_cfg or {}
    for key, screen_def in screens.items():
        idents = screen_def.get("identifiers", [])
        if not idents:
            continue
        matches = sum(1 for ident in idents
                      if ident in text or normalize_text(ident) in norm)
        score = matches / len(idents)
        if score > best_score and score >= 0.5:
            best, best_score = key, score
    return best


class PathClassifier:
    """Classifies one screen read onto the success/failed path."""

    def __init__(self, rules: dict | None = None,
                 min_confidence: float = 0.75):
        self.rules = dict(_DEFAULT_RULES)
        self.rules.update(rules or {})
        self.min_confidence = min_confidence

    def classify(self, text: str, confidence: float = 1.0) -> dict:
        """Returns {"path", "code", "matched", "confidence"}.

        Below min_confidence the read cannot assert an ERROR path —
        a shaky read must never fail a deterministic flow. It may
        still report success markers it matched (upgrade-only)."""
        norm = normalize_text(text or "")
        matched: list[str] = []
        confident = confidence >= self.min_confidence

        code = canonical_result_code(text or "")
        if code and code.startswith("E-"):
            matched.append(code)
            if confident:
                return {"path": PATH_BUSINESS_ERROR, "code": code,
                        "matched": matched, "confidence": confidence}

        for marker in self.rules["business_error_markers"]:
            if marker in (text or "") or normalize_text(marker) in norm:
                matched.append(marker)
        if matched and confident and code is None:
            return {"path": PATH_BUSINESS_ERROR, "code": None,
                    "matched": matched, "confidence": confidence}

        # Environment failures (host not ready, comms down): an error
        # path, but a RETRYABLE one — kept distinct from business
        # errors so the evidence header and the catalogue agree.
        system_hits = [m for m in self.rules.get("system_error_markers",
                                                 [])
                       if m in (text or "") or normalize_text(m) in norm]
        if system_hits and confident:
            return {"path": PATH_SYSTEM_ERROR, "code": None,
                    "matched": matched + system_hits,
                    "confidence": confidence}

        success = []
        for marker in self.rules["success_markers"]:
            if marker in (text or "") or normalize_text(marker) in norm:
                success.append(marker)
        if code == self.rules["success_code"] or success:
            is_code = code == self.rules["success_code"]
            return {"path": PATH_SUCCESS,
                    "code": code if is_code else None,
                    "matched": (([code] if is_code else []) + success)
                    or matched,
                    "confidence": confidence}

        if norm:
            return {"path": PATH_IN_PROGRESS, "code": None,
                    "matched": matched, "confidence": confidence}
        return {"path": PATH_UNKNOWN, "code": None,
                "matched": matched, "confidence": confidence}
