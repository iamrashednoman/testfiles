"""Printed-pattern screen text files — the TXT twin of every evidence
PNG (audit & compliance requirement).

Each screenshot the bot takes gets a same-named .txt file in the same
evidence folder: a header block (request, step, screen, path
classification) followed by the screen content laid out as it appears
on screen. OCR boxes are reconstructed into columns; driver-native
text (sim/mock) is already line-shaped.

Secrets policy (approved 2026-08-17): password VALUES are masked in
the text files — the PNG remains the exact visual record, the TXT
stays safe to grep and share with auditors.
"""
from __future__ import annotations

from src.rpa.vision.keywords import mask_values
from src.rpa.vision.ocr import OcrLine

_RULE = "=" * 63


def format_printed(content, secrets=()) -> str:
    """Render screen content as printed text.

    content: either a plain string (driver-native reads) or a list of
    OcrLine (positioned OCR output, reconstructed into columns)."""
    if isinstance(content, str):
        body = content
    else:
        body = _layout_lines(list(content or []))
    return mask_values(body.rstrip() + "\n", secrets)


def _layout_lines(lines: list[OcrLine]) -> str:
    """Place OCR boxes on a character grid: rows by y, columns by x.
    Approximate but faithful enough to mirror the screen layout."""
    if not lines:
        return ""
    # Estimate one character cell from the boxes themselves.
    widths = [ln.box[2] / max(1, len(ln.text)) for ln in lines
              if ln.box[2] > 0 and ln.text]
    char_w = max(4.0, sorted(widths)[len(widths) // 2]) if widths else 8.0
    heights = sorted(ln.box[3] or 16 for ln in lines)
    tol = max(6, heights[len(heights) // 2] // 2)

    rows: list[list[OcrLine]] = []
    for ln in sorted(lines, key=lambda l: (l.box[1], l.box[0])):
        for row in rows:
            if abs(row[0].box[1] - ln.box[1]) <= tol:
                row.append(ln)
                break
        else:
            rows.append([ln])

    out = []
    for row in rows:
        text = ""
        for ln in sorted(row, key=lambda l: l.box[0]):
            col = int(round(ln.box[0] / char_w))
            if col > len(text):
                text += " " * (col - len(text))
            elif text:
                text += " "
            text += ln.text
        out.append(text.rstrip())
    return "\n".join(out)


def build_header(*, request_id: str, step: str, screen: str,
                 classification: dict, captured_at: str,
                 engine: str) -> str:
    cls = classification or {}
    matched = ", ".join(str(m) for m in cls.get("matched", [])) or "-"
    conf = cls.get("confidence")
    conf_s = f"{conf:.2f}" if isinstance(conf, (int, float)) else "-"
    return (
        f"{_RULE}\n"
        f"FINESIII SCREEN CAPTURE (text mirror of the PNG evidence)\n"
        f"{_RULE}\n"
        f"Request:  {request_id or '-'}\n"
        f"Step:     {step or '-'}\n"
        f"Screen:   {screen or '-'}\n"
        f"Path:     {str(cls.get('path', 'unknown')).upper()}"
        f"   Code: {cls.get('code') or '-'}"
        f"   Confidence: {conf_s}\n"
        f"Matched:  {matched}\n"
        f"Captured: {captured_at}   Reader: {engine}\n"
        f"{_RULE}\n"
    )


_INPUT_LABELS = {
    "type_text": "typed",
    "submit_command": "command",
    "goto_first_field_and_exit": "exit walk",
}


def build_input_section(entries: list[dict]) -> str:
    """INPUT COMMANDS footer: every command/value the bot entered
    since the previous capture — the inputs that produced this screen
    state (debugging aid; secret values arrive already masked)."""
    lines = ["", _RULE,
             "INPUT COMMANDS (entered by the bot since the previous "
             "capture)", _RULE]
    if not entries:
        lines.append("  (none — navigation/read only)")
    for e in entries:
        action = e.get("action", "")
        if action == "send_field_value":
            label = f"field {e.get('field', '?')}"
            value = e.get("after", "")
        else:
            label = _INPUT_LABELS.get(action, action)
            value = e.get("detail", "")
        lines.append(f"  {label:<16}: {value}")
    return "\n".join(lines) + "\n"


def write_screen_text(txt_path: str, header: str, body: str,
                      footer: str = "") -> None:
    with open(txt_path, "w", encoding="utf-8") as f:
        f.write(header)
        f.write(body if body.strip() else
                "(screen content not readable on this driver)\n")
        if footer:
            f.write(footer)
