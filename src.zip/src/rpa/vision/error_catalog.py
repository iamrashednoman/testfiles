"""Declarative error catalogue — matches a screen read to a rule.

The bot already reads and classifies every screen (vision/keywords.py).
This module turns a read into a DECISION: which known error is on the
screen, and what the bot must do about it.

Rules live in config/errors.yaml, so a new client error case is a data
row — no code change, no release. Matching reuses the OCR-variance
folding from keywords.py (NFKC fullwidth->ASCII, hyphen glyphs, spaces
stripped), so markers can be written naturally in the YAML.

Safety contract (same upgrade-only rule as PathClassifier): this module
only REPORTS a match. Whether the match may act is decided by the
caller against the confidence floor — a shaky read is recorded as
"suspected" and changes nothing. A screen matching no rule leaves
behaviour exactly as it was before the catalogue existed.
"""
from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass, field
from pathlib import Path

from src.rpa.vision.keywords import canonical_result_code, normalize_text

# Action verbs a rule may request.
ACTION_ACKNOWLEDGE = "acknowledge"           # dismiss a modal, then `then`
ACTION_CANCEL_AND_REPORT = "cancel_and_report"   # 99 out, report status
ACTION_RETRY_STEP = "retry_step"             # bounded in-session retry
ACTION_ABORT_EXIT = "abort_exit"             # exit sequence, fail ticket
ACTION_CONTINUE = "continue"                 # audit only, keep going

ACTIONS = (ACTION_ACKNOWLEDGE, ACTION_CANCEL_AND_REPORT,
           ACTION_RETRY_STEP, ACTION_ABORT_EXIT, ACTION_CONTINUE)

CLASSIFICATIONS = ("business", "system")

EXIT_FULL = "full"
EXIT_FROM_LOGIN = "login_screen"

SCOPE_ANY = "any"


class ErrorCatalogError(Exception):
    """Malformed catalogue. Raised only when strict validation is on —
    a typo must not silently disable error handling in production."""


@dataclass
class ErrorRule:
    """One catalogue row."""
    id: str
    name: str = ""
    enabled: bool = True
    scope: str = SCOPE_ANY
    priority: int = 100
    all_markers: tuple = ()
    any_markers: tuple = ()
    none_markers: tuple = ()
    code: str = ""
    captures: dict = field(default_factory=dict)
    action: str = ACTION_ABORT_EXIT
    acknowledge_key: str = "enter"
    focus_dialog: str = ""
    then: str = ACTION_ABORT_EXIT
    exit_from: str = EXIT_FULL
    classification: str = "system"
    exception: str = ""
    status: str = "failed"
    retry_whole_request: bool = False
    message: str = ""

    @property
    def is_business(self) -> bool:
        return self.classification == "business"

    def summary(self) -> dict:
        """Audit-friendly view of the rule that fired."""
        return {
            "error_id": self.id,
            "name": self.name,
            "action": self.action,
            "then": self.then if self.action == ACTION_ACKNOWLEDGE else "",
            "classification": self.classification,
            "status": self.status,
            "exit_from": self.exit_from,
        }


@dataclass
class ErrorMatch:
    """A rule that matched the current screen."""
    rule: ErrorRule
    matched: list
    captured: dict
    confidence: float
    screen: str = ""

    def audit_detail(self, step: str = "", acted: bool = True) -> dict:
        detail = self.rule.summary()
        detail.update({
            "step": step,
            "screen": self.screen or "-",
            "matched": self.matched,
            "confidence": round(float(self.confidence), 3),
            "acted": acted,
            "message": self.rule.message,
        })
        if self.captured:
            detail["captured"] = self.captured
        return detail


def _markers(raw) -> tuple:
    if not raw:
        return ()
    if isinstance(raw, str):
        return (raw,)
    return tuple(str(m) for m in raw if str(m).strip())


def _present(marker: str, text: str, norm: str) -> bool:
    """Match raw first, then the OCR-folded copy."""
    return marker in text or normalize_text(marker) in norm


class ErrorCatalog:
    """Ordered rule set, matched against one screen read."""

    def __init__(self, rules=(), *, source: str = "", digest: str = ""):
        self.rules = sorted(rules, key=lambda r: (r.priority, r.id))
        self.source = source
        self.digest = digest

    def __len__(self) -> int:
        return len(self.rules)

    @property
    def active_rules(self) -> list:
        return [r for r in self.rules if r.enabled]

    # ── Loading ──

    @classmethod
    def load(cls, path: str | None, *, strict: bool = True,
             logger=None) -> "ErrorCatalog":
        """Load config/errors.yaml.

        strict=True (production default): a missing or malformed file
        raises, so a typo cannot silently disable error handling.
        strict=False: degrade to an empty catalogue — behaviour is then
        exactly what it was before the catalogue existed.
        """
        if not path:
            return cls()
        p = Path(path)
        if not p.is_file():
            if strict:
                raise ErrorCatalogError(
                    f"Error catalogue not found: {path}")
            if logger:
                logger.warning(
                    f"Error catalogue not found ({path}) — error "
                    f"handling disabled for this run")
            return cls()

        try:
            import yaml
            raw = p.read_bytes()
            data = yaml.safe_load(raw.decode("utf-8")) or {}
        except Exception as e:
            if strict:
                raise ErrorCatalogError(
                    f"Error catalogue {path} is not readable YAML: {e}")
            if logger:
                logger.warning(f"Error catalogue {path} unreadable: {e}")
            return cls()

        defaults = data.get("settings") or {}
        rules, seen = [], set()
        for index, row in enumerate(data.get("errors") or []):
            try:
                rule = cls._build_rule(row, defaults)
            except ErrorCatalogError:
                if strict:
                    raise
                if logger:
                    logger.warning(
                        f"Skipping invalid error rule #{index} in {path}")
                continue
            if rule.id in seen:
                if strict:
                    raise ErrorCatalogError(
                        f"Duplicate error rule id '{rule.id}' in {path}")
                continue
            seen.add(rule.id)
            rules.append(rule)

        return cls(rules, source=str(p), digest=cls.version_of(data))

    @staticmethod
    def version_of(data: dict) -> str:
        """The catalogue version recorded with every recognised error
        (UR-06): a hash of the RULES, not of the file's bytes (UAT-12,
        2026-10-04). A rule without "enabled:" counts as enabled, so
        switching a rule off and on again gives the same version, and a
        comment or a blank line changes nothing. Any change to a rule
        gives a new version."""
        import json
        rows = []
        for row in (data or {}).get("errors") or []:
            if isinstance(row, dict):
                row = dict(row)
                row.setdefault("enabled", True)
            rows.append(row)
        canonical = json.dumps(
            {"settings": (data or {}).get("settings") or {}, "errors": rows},
            sort_keys=True, ensure_ascii=False, default=str)
        return hashlib.sha256(canonical.encode("utf-8")).hexdigest()[:12]

    @staticmethod
    def rule_enabled_in(text: str, rule_id: str):
        """Whether rule_id is enabled in catalogue TEXT (True when the
        flag is absent), or None when the rule or the text cannot be
        read."""
        import yaml
        try:
            data = yaml.safe_load(text) or {}
        except Exception:
            return None
        for row in data.get("errors") or []:
            if isinstance(row, dict) and str(row.get("id")) == rule_id:
                return bool(row.get("enabled", True))
        return None

    @classmethod
    def problem(cls, text: str) -> str:
        """Why `text` is not a valid catalogue, '' when it is (UR-10,
        2026-10-03): the same strict load the bot uses, run on text
        before it is written, so the console never saves a file that
        would stop every transaction."""
        import os
        import tempfile
        fd, tmp = tempfile.mkstemp(suffix=".yaml")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                fh.write(text)
            cls.load(tmp, strict=True)
            return ""
        except ErrorCatalogError as e:
            return str(e).replace(tmp, "errors.yaml")
        finally:
            try:
                os.unlink(tmp)
            except OSError:
                pass

    @staticmethod
    def _build_rule(row: dict, defaults: dict) -> ErrorRule:
        if not isinstance(row, dict) or not row.get("id"):
            raise ErrorCatalogError("Error rule needs an 'id'")
        match = row.get("match") or {}
        if not isinstance(match, dict):
            raise ErrorCatalogError(
                f"Rule '{row['id']}': 'match' must be a mapping")

        all_m = _markers(match.get("all"))
        any_m = _markers(match.get("any"))
        code = str(match.get("code") or "").strip()
        if not (all_m or any_m or code):
            raise ErrorCatalogError(
                f"Rule '{row['id']}': needs match.all, match.any, or "
                f"match.code")

        captures = {}
        capture_specs = match.get("capture") or {}
        for name, pattern in capture_specs.items():
            try:
                captures[str(name)] = re.compile(str(pattern))
            except re.error as e:
                raise ErrorCatalogError(
                    f"Rule '{row['id']}': bad capture regex "
                    f"'{name}': {e}")

        action = str(row.get("action")
                     or defaults.get("default_action")
                     or ACTION_ABORT_EXIT)
        if action not in ACTIONS:
            raise ErrorCatalogError(
                f"Rule '{row['id']}': unknown action '{action}' "
                f"(valid: {', '.join(ACTIONS)})")

        then = str(row.get("then") or ACTION_ABORT_EXIT)
        if then not in (ACTION_ABORT_EXIT, ACTION_CANCEL_AND_REPORT,
                        ACTION_RETRY_STEP, ACTION_CONTINUE):
            raise ErrorCatalogError(
                f"Rule '{row['id']}': unknown 'then' value '{then}'")

        classification = str(row.get("classification")
                             or defaults.get("default_classification")
                             or "system")
        if classification not in CLASSIFICATIONS:
            raise ErrorCatalogError(
                f"Rule '{row['id']}': classification must be "
                f"business or system, got '{classification}'")

        exit_from = str(row.get("exit_from") or EXIT_FULL)
        if exit_from not in (EXIT_FULL, EXIT_FROM_LOGIN):
            raise ErrorCatalogError(
                f"Rule '{row['id']}': exit_from must be "
                f"'{EXIT_FULL}' or '{EXIT_FROM_LOGIN}'")

        exception = str(row.get("exception") or "")
        if exception:
            from src.core import exceptions as exc_mod
            cls = getattr(exc_mod, exception, None)
            if not isinstance(cls, type):
                raise ErrorCatalogError(
                    f"Rule '{row['id']}': unknown exception class "
                    f"'{exception}'")
            # The exception CLASS is what RetryPolicy keys off, so a
            # rule declaring classification: business while raising a
            # SystemException would be retried against its own
            # declaration. Catch that at load time, not in production.
            is_business = issubclass(cls, exc_mod.BusinessException)
            is_system = issubclass(cls, exc_mod.SystemException)
            if (classification == "business" and not is_business) or \
                    (classification == "system" and not is_system):
                raise ErrorCatalogError(
                    f"Rule '{row['id']}': classification "
                    f"'{classification}' contradicts exception "
                    f"'{exception}' — a business rule needs a "
                    f"BusinessException subclass (and vice versa)")

        return ErrorRule(
            id=str(row["id"]),
            name=str(row.get("name") or row["id"]),
            enabled=bool(row.get("enabled", True)),
            scope=str(row.get("scope") or SCOPE_ANY),
            priority=int(row.get("priority", 100)),
            all_markers=all_m,
            any_markers=any_m,
            none_markers=_markers(match.get("none")),
            code=code,
            captures=captures,
            action=action,
            acknowledge_key=str(row.get("acknowledge_key") or "enter"),
            focus_dialog=str(row.get("focus_dialog") or ""),
            then=then,
            exit_from=exit_from,
            classification=classification,
            exception=exception,
            status=str(row.get("status") or "failed"),
            retry_whole_request=bool(
                (row.get("retry") or {}).get("whole_request", False)),
            message=str(row.get("message") or row.get("name")
                        or row["id"]),
        )

    # ── Matching ──

    def match(self, text: str, confidence: float = 1.0,
              screen: str = "") -> ErrorMatch | None:
        """First matching rule wins (rules are priority-ordered).

        Returns the match regardless of confidence — the CALLER gates
        acting on it against the confidence floor, so a low-confidence
        hit can still be audited as "suspected" without changing the
        bot's behaviour.
        """
        if not text or not self.rules:
            return None
        norm = normalize_text(text)
        code = canonical_result_code(text)

        for rule in self.rules:
            if not rule.enabled:
                continue
            if rule.scope != SCOPE_ANY and screen and \
                    rule.scope != screen:
                continue
            if rule.code and rule.code != code:
                continue
            if any(_present(m, text, norm) for m in rule.none_markers):
                continue
            if rule.all_markers and not all(
                    _present(m, text, norm) for m in rule.all_markers):
                continue
            if rule.any_markers and not any(
                    _present(m, text, norm) for m in rule.any_markers):
                continue

            matched = [m for m in rule.all_markers + rule.any_markers
                       if _present(m, text, norm)]
            if rule.code:
                matched.append(rule.code)
            return ErrorMatch(rule=rule, matched=matched,
                              captured=self._capture(rule, text, norm),
                              confidence=confidence, screen=screen)
        return None

    @staticmethod
    def _capture(rule: ErrorRule, text: str, norm: str) -> dict:
        """Pull diagnostic values (host codes, subsystem names) out of
        the screen for the audit trail. Never used for matching."""
        found = {}
        for name, pattern in rule.captures.items():
            for candidate in (text, norm):
                m = pattern.search(candidate)
                if m:
                    groups = [g for g in m.groups() if g]
                    found[name] = (" ".join(groups) if groups
                                   else m.group(0))
                    break
        return found
