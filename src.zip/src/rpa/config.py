"""Builds the rpa-layer runtime config from layouts.yaml + settings.

The ported v2 workflows/screens/drivers consume a plain dict with the
sections screens / navigation / fields / timing / defaults /
application / evidence / environment. That contract is preserved (the
proven logic is untouched); this module is the single place where v3's
pydantic settings and the versioned layouts data are merged into it.

Approved fix vs v2: timing.keystroke_delay is merged into the
application section handed to drivers — v2's pywinauto driver looked it
up there, where it never existed, so the field default always won and
the terminal dropped/transposed characters.
"""
from __future__ import annotations

from pathlib import Path

import yaml
from src.core.app_paths import resource_path

DEFAULT_LAYOUTS_PATH = resource_path("src", "rpa", "screens",
                                     "layouts.yaml")


def load_layouts(path: str | Path | None = None) -> dict:
    """Load the versioned screen/field/navigation data."""
    layouts_path = Path(path) if path else DEFAULT_LAYOUTS_PATH
    with open(layouts_path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


def effective_application(layouts: dict | None = None) -> dict:
    """The terminal application block in force: layouts.yaml with the
    per-install overrides from the console's FINESIII terminal page
    (layouts.yaml ships read-only inside the bundle). Unset variables
    leave the YAML value as is."""
    import os
    if layouts is None:
        layouts = load_layouts()
    application = dict(layouts.get("application", {}))
    for env_name, key in (("FINESIII_APP_SHORTCUT_PATH", "shortcut_path"),
                          ("FINESIII_APP_EXECUTABLE", "executable_path"),
                          ("FINESIII_APP_WINDOW_TITLE",
                           "window_title_pattern"),
                          ("FINESIII_APP_WINDOW_CLASS",
                           "terminal_window_class")):
        value = os.environ.get(env_name, "")
        if value:
            application[key] = value
    # Started as administrator or not (CFG-04, 2026-10-04); unset keeps
    # layouts.yaml, which defaults to yes.
    application.setdefault("run_as_admin", True)
    elevated = os.environ.get("FINESIII_APP_RUN_AS_ADMIN", "").strip().lower()
    if elevated in ("true", "1", "yes", "on"):
        application["run_as_admin"] = True
    elif elevated in ("false", "0", "no", "off"):
        application["run_as_admin"] = False
    return application


def build_rpa_config(*, driver: str, environment: str,
                     evidence_dir: str, scenario: str = "success",
                     action_delay: float = 0.4,
                     strict_screen_detection: bool = False,
                     ocr: dict | None = None,
                     errors: dict | None = None,
                     layouts_path: str | None = None,
                     require_readable_confirmation: bool = False) -> dict:
    """Assemble the v2-shape config dict the ported rpa layer consumes.

    Args:
        driver: terminal driver name (mock | sim_terminal | pywinauto |
            pyautogui | tn3270)
        environment: mainframe environment — "development" prepends "99"
            to the LOGIN affiliation code (FID 105 is never affected)
        evidence_dir: root folder for per-transaction evidence
        scenario: sim/mock scenario (success | error | already_deleted |
            unreadable)
        action_delay: seconds between visible sim actions
        strict_screen_detection: hard-fail on unmatched screens
            (lenient default is the field-proven behavior for the real
            terminal, whose screen body is unreadable)
        ocr: OCR/observation section (built from the cfg.ocr_* fields;
            None means disabled — bare-driver behavior)
        errors: screen error-handling section (built from the
            cfg.error_* fields; None means disabled — the workflows
            then behave exactly as they did before the catalogue)
        layouts_path: override for layouts.yaml (tests)
        require_readable_confirmation: cancel ("99") instead of
            committing when the confirmation body cannot be read
    """
    layouts = load_layouts(layouts_path)
    timing = dict(layouts.get("timing", {}))

    application = effective_application(layouts)
    application["mock_scenario"] = scenario
    application["sim_action_delay"] = action_delay
    application["strict_screen_detection"] = strict_screen_detection
    # Approved fix: expose the timing keystroke delay where the drivers
    # actually read it.
    application["keystroke_delay"] = timing.get("keystroke_delay", 0.15)

    evidence = {
        "enabled": True,
        "output_dir": evidence_dir,
        "capture_points": layouts.get("evidence", {}).get(
            "capture_points", []),
        "format": layouts.get("evidence", {}).get("format", "png"),
    }

    return {
        "driver": driver,
        "environment": environment,
        "application": application,
        "credentials": layouts.get("credentials", {}),
        "test_account": layouts.get("test_account", {}),
        "screens": layouts.get("screens", {}),
        "navigation": layouts.get("navigation", {}),
        "fields": layouts.get("fields", {}),
        "processing_types": layouts.get("processing_types", {}),
        "defaults": layouts.get("defaults", {}),
        "timing": timing,
        "evidence": evidence,
        "ocr": dict(ocr) if ocr else {"enabled": False},
        "errors": dict(errors) if errors else {"enabled": False},
        "require_readable_confirmation": bool(require_readable_confirmation),
    }
