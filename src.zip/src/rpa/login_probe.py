"""Real-login availability probe.

Port of v2 service/login_probe.py. Builds a zero-arg callable that
proves FINESIII is genuinely online by performing an actual login
(launch → core menu → login) and then logging straight back out.
A TCP probe only proves the port answers; the client requirement is
"can the bot actually get in", several times a day.

The probe uses the same service account as live transactions, so the
AvailabilityMonitor only schedules it while the dispatcher is idle
and inside the operating window.
"""
from __future__ import annotations

from src.rpa.credentials import FINESIIICredentials
from src.rpa.executor import create_driver
from src.rpa.screens.navigator import Navigator
from src.rpa.screens.state import ScreenState


def build_login_probe(rpa_config: dict,
                      credentials: FINESIIICredentials,
                      logger=None):
    """Return a callable () -> bool that performs one probe login."""

    def probe() -> bool:
        driver = create_driver(rpa_config)
        try:
            screen = ScreenState(rpa_config.get("screens", {}),
                                 driver, logger)
            navigator = Navigator(
                driver, screen,
                rpa_config.get("navigation", {}),
                rpa_config.get("timing", {}),
                rpa_config.get("environment", "development"),
                logger, None,          # no evidence for probes
            )
            navigator.step_1_launch_application()
            navigator.step_2_navigate_core_business_menu()
            navigator.step_3_login(credentials)

            # Logged in — FINESIII is online. Leave cleanly.
            try:
                navigator.exit_application()
            except Exception:
                if logger:
                    logger.warning(
                        "Login probe: logout sequence failed (non-fatal) "
                        "— closing session directly")
            return True

        except Exception as e:
            if logger:
                logger.warning(
                    f"Login probe FAILED — FINESIII not online: {e}")
            return False
        finally:
            # Never leak a terminal session, even on failure.
            try:
                driver.close_application()
            except Exception:
                pass

    return probe
