"""RPA execution-plane library — everything that touches the terminal.

Imported ONLY by the worker agent (src/agent), never by the
orchestrator. Layers:

    drivers/    HOW to poke the screen (pywinauto/pyautogui/tn3270/sim)
    screens/    WHAT the screens are (state machine, field maps)
    vision/     PROOF of what is on screen (template match, OCR fallback)
    workflows/  WHY — business operations composed from the above
"""
