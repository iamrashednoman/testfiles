"""Terminal executor — one request through the real rpa stack.

Port of v2 service/worker_pool.py Worker.process(), adapted to the v3
dispatcher's executor protocol: execute(request) -> result dict. The
result keeps the v2 shape ("success" / "failed" / "already_deleted",
result_code, evidence_path, error, error_type); the dispatcher
normalizes it at its completion seam, exactly as with MockExecutor.

Per request (single-worker Phase 1 semantics, matching v2):
  fresh driver → fresh evidence folder → ProvisionWorkflow /
  DeprovisionWorkflow → workflow handles navigation, entry, 00→70
  commit, print, logout in its own finally block.

Driver modes:
  sim_terminal          visible green-screen window per request
                        (separate process — no Tk main-thread conflict)
  mock                  headless full-stack (unit/integration tests)
  pywinauto/pyautogui/  real terminal on Windows workers
  tn3270

Credentials resolve once at startup (fail-fast, like v2 run_service):
environment variables via CredentialManager; sim/mock fall back to the
layouts test account so the simulator runs with zero setup. Real
drivers never fall back — missing credentials abort startup.
"""
from __future__ import annotations

from src.core.evidence import EvidenceCapture
from src.core.logging import TransactionLogger
from src.rpa.config import build_rpa_config
from src.rpa.credentials import CredentialManager, FINESIIICredentials

SIM_DRIVERS = ("sim_terminal", "mock")


def _ocr_section(cfg) -> dict:
    """Assemble the rpa-config OCR section from the flat cfg fields."""
    return {
        "enabled": cfg.ocr_enabled,
        "lang": cfg.ocr_lang,
        "model_dir": cfg.ocr_model_dir,
        "allow_download": cfg.ocr_allow_download,
        "min_confidence": cfg.ocr_min_confidence,
        "capture_text": cfg.ocr_capture_text,
        "keywords_path": cfg.ocr_keywords_path,
    }


def _errors_section(cfg) -> dict:
    """Screen error-handling section handed to the rpa layer."""
    if not getattr(cfg, "error_handling_enabled", True):
        return {"enabled": False}
    return {
        "enabled": True,
        "catalog_path": cfg.error_catalog_path,
        "strict": cfg.error_strict_catalog,
        "min_confidence": cfg.ocr_min_confidence,
        "acknowledge_wait": cfg.error_acknowledge_wait,
        "max_step_retries": cfg.error_max_step_retries,
        "retry_wait": cfg.error_retry_wait_seconds,
    }


def create_driver(rpa_config: dict):
    """Instantiate + initialize the configured terminal driver.
    Port of v2 main.create_driver()."""
    driver_name = rpa_config.get("driver", "pywinauto")
    app_config = rpa_config.get("application", {})

    if driver_name == "pywinauto":
        from src.rpa.drivers.pywinauto_driver import PywinautoDriver
        driver = PywinautoDriver()
    elif driver_name == "pyautogui":
        from src.rpa.drivers.pyautogui_driver import PyAutoGUIDriver
        driver = PyAutoGUIDriver()
    elif driver_name == "tn3270":
        from src.rpa.drivers.tn3270_driver import TN3270Driver
        driver = TN3270Driver()
    elif driver_name == "mock":
        from src.rpa.drivers.mock import MockDriver
        driver = MockDriver()
    elif driver_name == "sim_terminal":
        from src.rpa.drivers.sim_terminal import SimTerminalDriver
        driver = SimTerminalDriver()
    else:
        raise ValueError(
            f"Unknown terminal driver '{driver_name}'. Use: pywinauto, "
            f"pyautogui, tn3270, mock, or sim_terminal"
        )

    driver.initialize(app_config)
    return driver


def resolve_credentials(rpa_config: dict) -> FINESIIICredentials:
    """Resolve terminal login credentials.

    Environment variables first (FINESIII_AFFILIATION_CODE /
    _APPLICATION_ID / _PASSWORD). Sim/mock drivers fall back to the
    layouts test account; real drivers fail fast."""
    manager = CredentialManager(rpa_config.get("credentials", {}))
    try:
        return manager.get_credentials()
    except (ValueError, KeyError):
        if rpa_config.get("driver") in SIM_DRIVERS:
            test = rpa_config.get("test_account", {})
            creds = FINESIIICredentials(
                affiliation_code=test.get("affiliation_code", "03325"),
                application_id=test.get("staff_code", "12N3940"),
                password=test.get("password", "TEST0000"),
            )
            creds.validate()
            return creds
        raise


class TerminalExecutor:
    """Executes queued requests through the ported v2 workflows."""

    # (request) -> None, set by the dispatcher: called just before the
    # "70" commit is typed (NB-004). None = nothing recorded.
    on_commit = None

    def __init__(self, cfg, logger: TransactionLogger | None = None):
        self.cfg = cfg
        self.rpa_config = build_rpa_config(
            driver=cfg.terminal_driver,
            environment=cfg.mainframe_environment,
            evidence_dir=cfg.evidence_dir,
            scenario=cfg.sim_scenario,
            action_delay=cfg.sim_action_delay,
            strict_screen_detection=cfg.strict_screen_detection,
            ocr=_ocr_section(cfg),
            errors=_errors_section(cfg),
            require_readable_confirmation=bool(getattr(
                cfg, "require_readable_confirmation", False)),
        )
        # Fail-fast: bad/missing credentials abort startup, not the
        # first dequeued request (v2 run_service behavior).
        self.credentials = resolve_credentials(self.rpa_config)
        self.logger = logger or TransactionLogger({
            "log_dir": cfg.log_dir,
            "log_file": "finesiii_rpa_v3.log",
            "level": cfg.log_level,
            "console_output": cfg.debug,
        })
        # OCR engine loads ONCE per process (models are heavy). On real
        # drivers a load failure aborts startup — OCR is a mandatory
        # control there. The sim_terminal subprocess builds its own
        # engine per request process, so skip the redundant load here.
        from src.rpa.vision.keywords import PathClassifier, load_rules
        ocr_cfg = self.rpa_config.get("ocr", {})
        if cfg.terminal_driver == "sim_terminal":
            self.ocr_engine = None
        else:
            from src.rpa.vision.ocr import build_ocr_engine
            self.ocr_engine = build_ocr_engine(
                ocr_cfg, cfg.terminal_driver, self.logger)
        self.classifier = PathClassifier(
            load_rules(ocr_cfg.get("keywords_path")),
            ocr_cfg.get("min_confidence", 0.75))

        # Error catalogue: validated ONCE at startup so a malformed
        # config/errors.yaml aborts the service rather than silently
        # disabling error handling on the first real transaction. The
        # workflows load their own copy per transaction (the file is
        # tiny) so the sim subprocess gets identical rules.
        from src.rpa.vision.error_catalog import ErrorCatalog
        err_cfg = self.rpa_config.get("errors", {})
        self.error_catalog = ErrorCatalog.load(
            err_cfg.get("catalog_path") if err_cfg.get("enabled") else None,
            strict=bool(err_cfg.get("strict", True)), logger=self.logger)
        if self.error_catalog.rules:
            self.logger.info(
                f"Error catalogue loaded: {len(self.error_catalog)} "
                f"rules from {self.error_catalog.source} "
                f"(sha {self.error_catalog.digest})")

    @property
    def operator(self) -> str:
        """Service account that executes transactions (audit field)."""
        return self.credentials.application_id

    _SCENARIOS = ("success", "error", "already_deleted", "unreadable",
                  "center_not_ready", "login_password_incorrect",
                  "invalid_affiliation_code", "invalid_staff_code")

    def _request_rpa_config(self, request) -> dict:
        """Per-request sim scenario override: metadata.sim_scenario on
        the incoming request drives success/error/already_deleted for
        THIS request only, so testers can exercise failure paths
        through the API without restarting the service. Sim/mock
        drivers only — never affects real terminal drivers."""
        metadata = request.metadata if isinstance(request.metadata,
                                                  dict) else {}
        scenario = str(metadata.get("sim_scenario", "")).strip().lower()
        if not scenario or self.rpa_config.get("driver") not in \
                SIM_DRIVERS:
            return self.rpa_config
        if scenario not in self._SCENARIOS:
            self.logger.warning(
                f"Ignoring unknown sim_scenario '{scenario}' on "
                f"{request.request_id} (valid: {self._SCENARIOS})")
            return self.rpa_config
        cfg = dict(self.rpa_config)
        cfg["application"] = dict(cfg["application"],
                                  mock_scenario=scenario)
        return cfg

    def execute(self, request) -> dict:
        """Process one request. Returns the v2-shape workflow result."""
        rpa_config = self._request_rpa_config(request)

        # Visible simulation: launch the green-screen window as a
        # separate process per request (v2 sim_terminal_subprocess mode).
        if rpa_config.get("driver") == "sim_terminal":
            from src.rpa.drivers.sim_launcher import (
                SimTerminalSubprocessLauncher,
            )
            launcher = SimTerminalSubprocessLauncher(rpa_config)
            launcher.on_commit = self._commit_hook(request)
            return launcher.run_request(request, self.credentials)

        from src.rpa.workflows.deprovision import DeprovisionWorkflow
        from src.rpa.workflows.provision import ProvisionWorkflow

        # Keyed (and pinned) to the request id at construction — no
        # orphan timestamp folder, and the workflow's logger-txn
        # re-point cannot abandon it.
        evidence = EvidenceCapture(rpa_config.get("evidence", {}),
                                   transaction_id=request.request_id)

        # Fresh driver per transaction (single worker: one session at
        # a time), wrapped in the OCR/audit observer: every keystroke
        # lands in the action trace, every evidence PNG gets classified
        # and mirrored as a printed .txt (compliance requirement).
        driver = self._observe(create_driver(rpa_config), request,
                               rpa_config)

        if request.operation == "provision":
            workflow = ProvisionWorkflow(
                driver, rpa_config, self.logger, evidence)
            workflow.on_commit = self._commit_hook(request)
            result = workflow.execute(
                self.credentials,
                request.affiliation_code,
                request.employee_code,
                request.password or None,
            )
        else:
            workflow = DeprovisionWorkflow(
                driver, rpa_config, self.logger, evidence)
            workflow.on_commit = self._commit_hook(request)
            result = workflow.execute(
                self.credentials,
                request.affiliation_code,
                request.employee_code,
            )
        # A trace-collection problem must never turn a finished (possibly
        # committed) transaction into an exception — that would retry it.
        try:
            result.update(driver.traces())
        except Exception as e:
            self.logger.warning(
                f"Action/screen traces unavailable for "
                f"{request.request_id}: {e}")
        return result

    def _commit_hook(self, request):
        """The workflow's on_commit for this request (None when the
        dispatcher set no hook)."""
        if getattr(self, "on_commit", None) is None:
            return None
        return lambda: self.on_commit(request)

    def _observe(self, driver, request, rpa_config):
        """Wrap the bare driver in the ObservedDriver (OCR enrichment +
        per-action audit trace). Password VALUES are masked before
        anything reaches a trace or text file."""
        from src.rpa.drivers.ocr_wrapper import ObservedDriver
        from src.rpa.vision.ocr import NullOcrEngine
        ocr_cfg = rpa_config.get("ocr", {})
        return ObservedDriver(
            driver,
            self.ocr_engine or NullOcrEngine(),
            self.classifier,
            rpa_config.get("screens", {}),
            request_id=request.request_id,
            secrets=(self.credentials.password, request.password or ""),
            capture_text=ocr_cfg.get("capture_text", True),
            strict_screen_detection=rpa_config.get("application", {})
            .get("strict_screen_detection", False),
            logger=self.logger,
        )
