"""Provision workflow — Account Creation (Processing Type 2).

Port of v2 workflows/provision.py, unchanged.

Sequence (audio-confirmed June 3 walkthrough):
  1. Navigate to Task 0903
  2. Press Enter at FID 100 to start
  3. Enter fields: Type=2, Audit=1, Affiliation, Employee, Password, Date
  4. Skip Administrator field
  5. Type "00" at Execution field → confirmation screen (does NOT commit)
  6. Review confirmation screen — validate entered data
  7. Type "70" to commit to mainframe (or "99" to cancel on error)
  8. Handle mandatory print screen (10 → wait プリント済 → 99)

Returns the v2-shape result dict; the dispatcher normalizes 'success'
to the canonical DONE status at its completion seam.
"""

import threading
import time

from src.core.evidence import EvidenceCapture
from src.core.exceptions import (
    BusinessException, ConfirmationMismatchError,
    ConfirmationUnverifiableError,
)
from src.rpa.credentials import FINESIIICredentials
from src.rpa.drivers.base import BaseDriver
from src.rpa.screens.error_handler import build_guard
from src.rpa.screens.field_mapper import AccountData, FieldMapper
from src.rpa.screens.navigator import Navigator
from src.rpa.screens.state import ScreenState


class ProvisionWorkflow:

    # () -> None, set by the executor: called just before "70" is typed
    # so the queue row records that the commit may exist (NB-004). It
    # runs on a helper thread and never delays the commit by more than
    # COMMIT_HOOK_TIMEOUT seconds or raises into the workflow.
    on_commit = None
    COMMIT_HOOK_TIMEOUT = 2.0

    def __init__(self, driver: BaseDriver, config: dict,
                 logger=None, evidence: EvidenceCapture = None):
        self.driver = driver
        self.config = config
        self.logger = logger
        self.evidence = evidence

        self.screen = ScreenState(
            config.get("screens", {}), driver, logger
        )
        # Error catalogue (config/errors.yaml). Built HERE so both
        # execution paths — the in-process executor and the sim-terminal
        # subprocess — get an identical guard from one construction
        # site. Disabled config yields an inert guard.
        self.guard = build_guard(driver, config, evidence=evidence,
                                 logger=logger)
        self.navigator = Navigator(
            driver, self.screen,
            config.get("navigation", {}),
            config.get("timing", {}),
            config.get("environment", "development"),
            logger, evidence, guard=self.guard
        )
        # Set from a fired rule: a connection error never gets past
        # login, so the exit walk must start there (see
        # Navigator.exit_application).
        self._exit_from_login = False
        # Set immediately BEFORE the "70" commit is typed (safe side):
        # from then on the transaction may exist on the mainframe, so a
        # later failure must never lead to the request being run again.
        self._commit_sent = False
        self._confirmed_code = ""
        # The step after the commit that is running, named in the error
        # when it fails (NB-013).
        self._stage = ""
        self.field_mapper = FieldMapper(
            driver, config.get("fields", {}),
            config.get("timing", {}), logger
        )

    def execute(self, credentials: FINESIIICredentials,
                affiliation_code: str, employee_code: str,
                password: str = None) -> dict:
        operation = "provision"
        txn_id = None

        if self.logger:
            txn_id = self.logger.transaction_start(operation, {
                "employee_code": employee_code,
                "affiliation_code": affiliation_code
            })

        if self.evidence and txn_id:
            self.evidence.set_transaction(txn_id)

        # The service always supplies a password (one it generated, or
        # the requester's). Without one the account is not created: a
        # default password is never used (UAT-L27, 2026-10-04). Nothing
        # has been typed on the terminal at this point.
        if not password:
            from src.core.exceptions import ValidationError
            problem = ValidationError(
                "No initial password was given for the new account, and "
                "a default password is never used. Submit the request "
                "again: the service generates a password.")
            problem.retryable = False
            return self._build_failure(operation, employee_code,
                                       affiliation_code, str(problem),
                                       "business", step="initial_password",
                                       exc=problem)

        try:
            account_data = FieldMapper.build_create_data(
                affiliation_code, employee_code, password
            )
            account_data.validate()

            # Step 1-4: Navigate to Task 0903
            self.navigator.navigate_to_account_management(credentials)

            # Step 5-6: Enter data on DID:903
            self.field_mapper.enter_account_data(account_data)

            if self.evidence:
                self.evidence.capture("data_entered", self.driver)

            # Checkpoint: field-level validation errors are shown on
            # the entry screen itself, before any commit is possible.
            self.guard.check("data_entered")

            # Step 7: Press "00" → confirmation screen (does NOT commit)
            self._generate_confirmation()

            # Checkpoint: the confirmation screen is the last chance to
            # stop before the "70" commit reaches the mainframe.
            self.guard.check("confirmation_screen",
                             expect="account_management")

            # Step 7b: Validate confirmation screen
            self._validate_confirmation(account_data)

            # Step 8: Press "70" → commit to mainframe
            self._submit()

            # Step 8b: Check bottom line for result code
            self._stage = "check_result"
            result_info = self._check_result()
            if result_info["success"] and \
                    result_info["code"] != "UNCONFIRMED":
                self._confirmed_code = result_info["code"]

            if not result_info["success"]:
                return self._build_failure(
                    operation, employee_code, affiliation_code,
                    f"Transaction failed: {result_info['code']} — "
                    f"{result_info['raw_line']}",
                    "business", step="check_result",
                    result_code=result_info["code"],
                )

            # Step 9: Handle mandatory print screen
            self._stage = "print_screen"
            self.navigator.handle_print_screen()

            result = {
                "status": "success",
                "operation": operation,
                "employee_code": employee_code,
                "affiliation_code": account_data.affiliation_code,
                "result_code": result_info["code"],
                "evidence_path": (self.evidence.get_evidence_path()
                                  if self.evidence else None),
                "error": None,
                "error_trace": list(self.guard.trace),
            }
            if self.logger:
                self.logger.transaction_success(operation)
            return result

        except BusinessException as e:
            if self._commit_sent:
                return self._build_post_commit_result(
                    operation, employee_code, affiliation_code, e)
            return self._build_failure(operation, employee_code,
                                       affiliation_code, str(e), "business",
                                       step=getattr(e, "step", ""),
                                       exc=e)
        except Exception as e:
            if self._commit_sent:
                return self._build_post_commit_result(
                    operation, employee_code, affiliation_code, e)
            return self._build_failure(operation, employee_code,
                                       affiliation_code, str(e), "system",
                                       step=getattr(e, "step", ""),
                                       exc=e)
        finally:
            try:
                self.navigator.exit_application(
                    from_login_screen=self._exit_from_login)
            except Exception:
                pass

    def _generate_confirmation(self):
        """Press "00" at the Execution field to generate the confirmation
        screen. This does NOT commit — it shows the data for review."""
        if self.logger:
            self.logger.step_start("Generate confirmation screen (00)")

        confirm_cmd = self.config.get("navigation", {}).get(
            "confirm_command", "00")
        self.driver.submit_command(
            confirm_cmd, before_enter=self._capture_cb(
                "confirm_command_entered"))
        time.sleep(self.config.get("timing", {}).get(
            "post_entry_delay", 2.0))

        if self.evidence:
            self.evidence.capture("confirmation_screen", self.driver)

        if self.logger:
            self.logger.step_success("Generate confirmation screen (00)")

    def _validate_confirmation(self, data: AccountData):
        """Read the confirmation screen and validate the entered data.
        If invalid, press "99" to cancel and raise an error."""
        if self.logger:
            self.logger.step_start("Validate confirmation screen")

        screen_text = self.screen.read_screen_data()

        # IMPORTANT: on this terminal, read_screen_data() returns the
        # window TITLE (e.g. "FINESⅢ"), NOT the screen body — the body
        # text is not machine-readable. So a non-empty screen_text does
        # NOT mean the body (where the employee code appears) is
        # readable. We detect genuine body readability by looking for
        # known confirmation-screen body markers. Only when the body is
        # genuinely readable do we enforce the employee-code presence
        # check; otherwise we cannot verify and we proceed (data was
        # entered field-by-field, deterministically).
        body_markers = ["社員コード", "処理区分", "この内容", "確認画面"]
        body_readable = any(m in screen_text for m in body_markers)

        if not body_readable and self.config.get(
                "require_readable_confirmation"):
            self._refuse_unverifiable_confirmation(data)

        if body_readable and data.employee_code not in screen_text:
            if self.logger:
                self.logger.warning(
                    f"Employee code '{data.employee_code}' not found on "
                    f"confirmation. Cancelling."
                )
            if self.evidence:
                self.evidence.capture("confirmation_mismatch", self.driver)

            # Press "99" to cancel
            cancel_cmd = self.config.get("navigation", {}).get(
                "cancel_command", "99")
            self.driver.submit_command(cancel_cmd)
            time.sleep(1)

            raise ConfirmationMismatchError(
                f"Employee code '{data.employee_code}' not found on "
                f"confirmation screen.",
                step="validate_confirmation"
            )

        if self.logger:
            if body_readable:
                self.logger.info(
                    f"Confirmation validated — employee code "
                    f"'{data.employee_code}' found"
                )
            else:
                self.logger.info(
                    "Confirmation body not readable on this terminal — "
                    "proceeding (data entered deterministically)"
                )
            self.logger.step_success("Validate confirmation screen")

    def _refuse_unverifiable_confirmation(self, data: AccountData):
        """The body could not be read and a readable confirmation is
        required (require_readable_confirmation): cancel with "99" and
        stop before the commit. Nothing reached the mainframe, so the
        failure is a retryable system error."""
        if self.logger:
            self.logger.warning(
                "Confirmation body not readable and a readable "
                "confirmation is required — cancelling before commit.")
        if self.evidence:
            self.evidence.capture("confirmation_unverifiable", self.driver)
        cancel_cmd = self.config.get("navigation", {}).get(
            "cancel_command", "99")
        self.driver.submit_command(cancel_cmd)
        time.sleep(1)
        raise ConfirmationUnverifiableError(
            f"Confirmation screen not readable for employee code "
            f"'{data.employee_code}' — cancelled before commit "
            f"(readable confirmation required).",
            step="validate_confirmation")

    def _submit(self):
        """Press "70" to commit the transaction to the mainframe."""
        if self.logger:
            self.logger.step_start("Commit to mainframe (70)")

        submit_cmd = self.config.get("navigation", {}).get(
            "submit_command", "70")
        self._commit_sent = True
        self._notify_commit()
        self.driver.submit_command(
            submit_cmd, before_enter=self._capture_cb(
                "commit_command_entered"))
        time.sleep(self.config.get("timing", {}).get(
            "post_entry_delay", 2.0))

        if self.evidence:
            self.evidence.capture("submission_result", self.driver)

        if self.logger:
            self.logger.step_success("Commit to mainframe (70)")

    def _notify_commit(self):
        """Call on_commit on a helper thread, waiting at most
        COMMIT_HOOK_TIMEOUT seconds. Never raises: the keystrokes and
        their order are the same with or without the hook."""
        hook = self.on_commit
        if hook is None:
            return

        def run():
            try:
                hook()
            except Exception as e:
                if self.logger:
                    self.logger.warning(f"Commit flag not recorded: {e}")
        try:
            t = threading.Thread(target=run, name="commit-flag", daemon=True)
            t.start()
            t.join(timeout=self.COMMIT_HOOK_TIMEOUT)
            if t.is_alive() and self.logger:
                self.logger.warning("Commit flag still being recorded — "
                                    "continuing with the commit")
        except Exception as e:
            if self.logger:
                self.logger.warning(f"Commit flag not recorded: {e}")

    def _check_result(self) -> dict:
        """Read the bottom line for O-0000 (success) or E-XXXX (error)."""
        if self.logger:
            self.logger.step_start("Check transaction result")

        result = self.screen.check_transaction_result()

        if result["success"]:
            if self.logger:
                self.logger.info(f"Result: {result['code']} (SUCCESS)")
        else:
            if self.logger:
                self.logger.warning(
                    f"Result: {result['code']} — {result['raw_line']}")
            if self.evidence:
                self.evidence.capture("error_screen", self.driver)

        if self.logger:
            self.logger.step_success("Check transaction result")

        return result

    def _capture_cb(self, step_name):
        """before_enter hook: evidence of the typed command on screen
        just before submission (compliance pairs)."""
        if not self.evidence:
            return None
        return lambda: self.evidence.capture(step_name, self.driver)

    def _build_post_commit_result(self, operation, employee_code,
                                  affiliation_code, exc):
        """A step AFTER the "70" commit failed (print screen, result
        read, ...). The account change may already exist on the
        mainframe, so this is never reported as a retryable failure: it
        finishes as submitted-but-unconfirmed (the same shape as an
        unreadable result line), which sends the manual-verification
        e-mail and keeps the ticket open for review."""
        step = getattr(exc, "step", "") or self._stage
        code = self._confirmed_code
        # Names the code read after '70' and the step that failed, so
        # the e-mail and the ticket note say what to check (NB-013).
        error_msg = ("'70' sent"
                     + (f"; result {code} confirmed on screen" if code
                        else "; result not read")
                     + (f"; the later step '{step}' failed" if step
                        else "; a later step failed")
                     + f": {exc} — manual check required")
        if self.logger:
            self.logger.error(
                f"{operation}: commit sent, later step failed — {exc}")
        result = {
            "status": "success",
            "operation": operation,
            "employee_code": employee_code,
            "affiliation_code": affiliation_code,
            "result_code": "UNCONFIRMED",
            "evidence_path": (self.evidence.get_evidence_path()
                              if self.evidence else None),
            "error": error_msg,
            "error_id": getattr(exc, "rule_id", ""),
            "error_trace": list(self.guard.trace),
            "failed_step": step,
            "post_commit_error": True,
            "commit_sent": True,
        }
        if self._confirmed_code:
            result["confirmed_code"] = self._confirmed_code
        return result

    def _build_failure(self, operation, employee_code, affiliation_code,
                       error_msg, error_type, step="", result_code="",
                       exc=None):
        # A fired catalogue rule carries its own reporting status and
        # tells the exit walk where to start. Everything else keeps the
        # existing defaults, so untouched failure paths are unchanged.
        if exc is not None:
            self._exit_from_login = bool(
                getattr(exc, "exit_from_login", False))
        status = getattr(exc, "error_status", "failed") or "failed"
        result = {
            "status": status,
            "operation": operation,
            "employee_code": employee_code,
            "affiliation_code": affiliation_code,
            "error_id": getattr(exc, "rule_id", ""),
            "error_trace": list(self.guard.trace),
            # The mainframe code rides along when the failure carries
            # one (deprovision always reported it; provision now
            # matches — audit needs the code queryable, not buried in
            # the message string).
            "result_code": result_code,
            "evidence_path": (self.evidence.get_evidence_path()
                              if self.evidence else None),
            "error": error_msg,
            "error_type": error_type,
            # WHERE it failed — exceptions carry their step name; the
            # audit trail surfaces this for debugging without log-diving.
            "failed_step": step,
        }
        # A catalogue rule that says the whole request must not be run
        # again (retry.whole_request false).
        if getattr(exc, "retryable", None) is False:
            result["retryable"] = False
        if self.logger:
            self.logger.transaction_failed(operation, error_msg)
        return result
