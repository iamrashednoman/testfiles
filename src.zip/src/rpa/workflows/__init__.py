"""Business workflow plugins.

Ports from v2 workflows/: provision.py (ProvisionWorkflow — Type 2),
deprovision.py (DeprovisionWorkflow — Type 4); Unlock (Type 1) and
Password Reset (Type 3) become first-class plugin classes in v3.

Plugin contract: register(operation) -> Workflow with
validate(data) / execute(driver, screens, evidence) / verify_postcondition().
verify_postcondition() re-queries the mainframe (inquiry screen) after
execution so a crash between Enter and confirmation cannot produce a
false success or duplicate replay.
"""
