"""Deprovision workflow — Account Deletion (Processing Type 4).

Port of v2 workflows/deprovision.py, unchanged.

Same two-step submission as provision:
  "00" → confirmation screen → "70" → commit (or "99" → cancel)

Differences from provision:
  - FID 101 = "4" (Deletion)
  - FID 104 = blank (audit target EMPTY for delete)
  - FID 003 = blank (password NOT required)
  - Detects already-deleted accounts (削除済み) on the confirmation
    screen and reports status "already_deleted" instead of failing.
"""

import threading
import time

from src.core.evidence import EvidenceCapture
from src.core.exceptions import (
    BusinessException, ConfirmationMismatchError,
    ConfirmationUnverifiableError,
)
from src.rpa.credentials import FINESIIICredentials
from src.rpa.drivers.base import BaseDriver
from src.rpa.screens.error_handler import build_guard
from src.rpa.screens.field_mapper import AccountData, FieldMapper
from src.rpa.screens.navigator import Navigator
from src.rpa.screens.state import ScreenState


class DeprovisionWorkflow:

    # () -> None, set by the executor: called just before "70" is typed
    # so the queue row records that the commit may exist (NB-004). It
    # runs on a helper thread and never delays the commit by more than
    # COMMIT_HOOK_TIMEOUT seconds or raises into the workflow.
    on_commit = None
    COMMIT_HOOK_TIMEOUT = 2.0

    def __init__(self, driver: BaseDriver, config: dict,
                 logger=None, evidence: EvidenceCapture = None):
        self.driver = driver
        self.config = config
        self.logger = logger
        self.evidence = evidence

        self.screen = ScreenState(
            config.get("screens", {}), driver, logger
        )
        # Error catalogue (config/errors.yaml) — see ProvisionWorkflow
        # for why the guard is constructed here.
        self.guard = build_guard(driver, config, evidence=evidence,
                                 logger=logger)
        self.navigator = Navigator(
            driver, self.screen,
            config.get("navigation", {}),
            config.get("timing", {}),
            config.get("environment", "development"),
            logger, evidence, guard=self.guard
        )
        self._exit_from_login = False
        # "70" typed (see ProvisionWorkflow): a later failure must never
        # lead to the request being run again.
        self._commit_sent = False
        self._confirmed_code = ""
        # The step after the commit that is running, named in the error
        # when it fails (NB-013).
        self._stage = ""
        self.field_mapper = FieldMapper(
            driver, config.get("fields", {}),
            config.get("timing", {}), logger
        )

    def execute(self, credentials: FINESIIICredentials,
                affiliation_code: str, employee_code: str) -> dict:
        operation = "deprovision"
        txn_id = None

        if self.logger:
            txn_id = self.logger.transaction_start(operation, {
                "employee_code": employee_code,
                "affiliation_code": affiliation_code
            })

        if self.evidence and txn_id:
            self.evidence.set_transaction(txn_id)

        try:
            account_data = FieldMapper.build_delete_data(
                affiliation_code, employee_code
            )
            account_data.validate()

            # Navigate to Task 0903
            self.navigator.navigate_to_account_management(credentials)

            # Enter data (type=4, audit blank, affiliation, employee,
            # skip password, skip date)
            self.field_mapper.enter_account_data(account_data)

            if self.evidence:
                self.evidence.capture("data_entered", self.driver)

            # Checkpoint: field-level validation errors on the entry
            # screen, before any commit is possible.
            self.guard.check("data_entered")

            # Press "00" → confirmation screen (does NOT commit)
            self._generate_confirmation()

            # Checkpoint: last chance to stop before the "70" commit.
            # An error comment that is NOT 削除済み fires the catalogue
            # here and cancels, rather than being mislabelled below.
            self.guard.check("confirmation_screen",
                             expect="account_management")

            # Validate confirmation screen — check for already-deleted
            already_deleted = self._validate_confirmation(account_data)

            if already_deleted:
                return {
                    "status": "already_deleted",
                    "operation": operation,
                    "employee_code": employee_code,
                    "affiliation_code": account_data.affiliation_code,
                    "result_code": "",
                    "evidence_path": (self.evidence.get_evidence_path()
                                      if self.evidence else None),
                    "error": "Account already deleted (削除済み)",
                    "error_type": "business",
                    "error_trace": list(self.guard.trace),
                }

            # Press "70" → commit to mainframe
            self._submit()

            # Check bottom line for result code
            self._stage = "check_result"
            result_info = self._check_result()
            if result_info["success"] and \
                    result_info["code"] != "UNCONFIRMED":
                self._confirmed_code = result_info["code"]

            if not result_info["success"]:
                return {
                    "status": "failed",
                    "operation": operation,
                    "employee_code": employee_code,
                    "affiliation_code": account_data.affiliation_code,
                    "result_code": result_info["code"],
                    "evidence_path": (self.evidence.get_evidence_path()
                                      if self.evidence else None),
                    "error": f"Transaction failed: {result_info['code']} "
                             f"— {result_info['raw_line']}",
                    "error_type": "business",
                    "failed_step": "check_result",
                    "error_trace": list(self.guard.trace),
                }

            # Handle mandatory print screen
            self._stage = "print_screen"
            self.navigator.handle_print_screen()

            result = {
                "status": "success",
                "operation": operation,
                "employee_code": employee_code,
                "affiliation_code": account_data.affiliation_code,
                "result_code": result_info["code"],
                "evidence_path": (self.evidence.get_evidence_path()
                                  if self.evidence else None),
                "error": None,
                "error_trace": list(self.guard.trace),
            }
            if self.logger:
                self.logger.transaction_success(operation)
            return result

        except BusinessException as e:
            if self._commit_sent:
                return self._build_post_commit_result(
                    operation, employee_code, affiliation_code, e)
            return self._build_failure(operation, employee_code,
                                       affiliation_code, str(e), "business",
                                       step=getattr(e, "step", ""),
                                       exc=e)
        except Exception as e:
            if self._commit_sent:
                return self._build_post_commit_result(
                    operation, employee_code, affiliation_code, e)
            return self._build_failure(operation, employee_code,
                                       affiliation_code, str(e), "system",
                                       step=getattr(e, "step", ""),
                                       exc=e)
        finally:
            try:
                self.navigator.exit_application(
                    from_login_screen=self._exit_from_login)
            except Exception:
                pass

    def _generate_confirmation(self):
        """Press "00" → confirmation screen appears."""
        if self.logger:
            self.logger.step_start("Generate confirmation screen (00)")

        confirm_cmd = self.config.get("navigation", {}).get(
            "confirm_command", "00")
        self.driver.submit_command(
            confirm_cmd, before_enter=self._capture_cb(
                "confirm_command_entered"))
        time.sleep(self.config.get("timing", {}).get(
            "post_entry_delay", 2.0))

        if self.evidence:
            self.evidence.capture("confirmation_screen", self.driver)

        if self.logger:
            self.logger.step_success("Generate confirmation screen (00)")

    def _validate_confirmation(self, data: AccountData) -> bool:
        """Read confirmation screen. Check for already-deleted FIRST,
        then validate employee code.

        Returns:
            True if account is already deleted (削除済み).
            False if confirmation is valid and ready to submit.
            Raises ConfirmationMismatchError if data doesn't match.
        """
        if self.logger:
            self.logger.step_start("Validate confirmation screen")

        screen_text = self.screen.read_screen_data()

        # IMPORTANT: on this terminal, read_screen_data() returns the
        # window TITLE (e.g. "FINESⅢ"), NOT the screen body — the body
        # text is not machine-readable. A non-empty screen_text therefore
        # does NOT mean the body (employee code, 削除済み, error comments)
        # is readable. We detect genuine body readability via known
        # confirmation-screen body markers. Only when the body is
        # genuinely readable do the already-deleted and employee-code
        # checks apply; otherwise we proceed (data entered
        # deterministically). Any already-deleted state will be reported
        # by the mainframe after submit.
        body_markers = ["社員コード", "処理区分", "この内容", "確認画面",
                        "エラーコメント", "削除済み"]
        body_readable = any(m in screen_text for m in body_markers)

        if not body_readable and self.config.get(
                "require_readable_confirmation"):
            self._refuse_unverifiable_confirmation(data)

        # Check for already-deleted BEFORE checking employee code.
        #
        # NARROWED (defect fix): this used to also treat a bare
        # エラーコメント as already-deleted. "already_deleted" is a
        # NON-failure status — it closes the ticket and emails ops a
        # success notice — so ANY other error comment (wrong
        # affiliation, field error) was silently reported as
        # successfully handled. Only 削除済み means already-deleted;
        # every other error comment is matched by the
        # CONFIRMATION_ERROR_COMMENT catalogue rule at the checkpoint
        # above, which cancels before the 70 commit.
        if body_readable and "削除済み" in screen_text:
            if self.logger:
                self.logger.warning(
                    f"Account {data.employee_code} already deleted "
                    f"(削除済み detected on confirmation)"
                )
            if self.evidence:
                self.evidence.capture("already_deleted_screen",
                                      self.driver)
            return True

        # Normal validation: cancel only if body is readable AND code
        # absent
        if body_readable and data.employee_code not in screen_text:
            if self.logger:
                self.logger.warning(
                    f"Employee code '{data.employee_code}' not found on "
                    f"confirmation. Cancelling."
                )
            if self.evidence:
                self.evidence.capture("confirmation_mismatch", self.driver)

            cancel_cmd = self.config.get("navigation", {}).get(
                "cancel_command", "99")
            self.driver.submit_command(cancel_cmd)
            time.sleep(1)

            raise ConfirmationMismatchError(
                f"Employee code '{data.employee_code}' not found on "
                f"confirmation screen.",
                step="validate_confirmation"
            )

        if self.logger:
            if body_readable:
                self.logger.info(
                    f"Confirmation validated — employee code "
                    f"'{data.employee_code}' found")
            else:
                self.logger.info(
                    "Confirmation body not readable on this terminal — "
                    "proceeding (data entered deterministically). "
                    "Already-deleted state, if any, will be reported by "
                    "the mainframe after submit."
                )
            self.logger.step_success("Validate confirmation screen")

        return False

    def _refuse_unverifiable_confirmation(self, data: AccountData):
        """The body could not be read and a readable confirmation is
        required (require_readable_confirmation): cancel with "99" and
        stop before the commit. Nothing reached the mainframe, so the
        failure is a retryable system error."""
        if self.logger:
            self.logger.warning(
                "Confirmation body not readable and a readable "
                "confirmation is required — cancelling before commit.")
        if self.evidence:
            self.evidence.capture("confirmation_unverifiable", self.driver)
        cancel_cmd = self.config.get("navigation", {}).get(
            "cancel_command", "99")
        self.driver.submit_command(cancel_cmd)
        time.sleep(1)
        raise ConfirmationUnverifiableError(
            f"Confirmation screen not readable for employee code "
            f"'{data.employee_code}' — cancelled before commit "
            f"(readable confirmation required).",
            step="validate_confirmation")

    def _submit(self):
        """Press "70" to commit the deletion to the mainframe."""
        if self.logger:
            self.logger.step_start("Commit to mainframe (70)")

        submit_cmd = self.config.get("navigation", {}).get(
            "submit_command", "70")
        self._commit_sent = True
        self._notify_commit()
        self.driver.submit_command(
            submit_cmd, before_enter=self._capture_cb(
                "commit_command_entered"))
        time.sleep(self.config.get("timing", {}).get(
            "post_entry_delay", 2.0))

        if self.evidence:
            self.evidence.capture("submission_result", self.driver)

        if self.logger:
            self.logger.step_success("Commit to mainframe (70)")

    def _notify_commit(self):
        """Call on_commit on a helper thread, waiting at most
        COMMIT_HOOK_TIMEOUT seconds. Never raises: the keystrokes and
        their order are the same with or without the hook."""
        hook = self.on_commit
        if hook is None:
            return

        def run():
            try:
                hook()
            except Exception as e:
                if self.logger:
                    self.logger.warning(f"Commit flag not recorded: {e}")
        try:
            t = threading.Thread(target=run, name="commit-flag", daemon=True)
            t.start()
            t.join(timeout=self.COMMIT_HOOK_TIMEOUT)
            if t.is_alive() and self.logger:
                self.logger.warning("Commit flag still being recorded — "
                                    "continuing with the commit")
        except Exception as e:
            if self.logger:
                self.logger.warning(f"Commit flag not recorded: {e}")

    def _check_result(self) -> dict:
        """Read bottom line for O-0000 (success) or E-XXXX (error)."""
        if self.logger:
            self.logger.step_start("Check transaction result")

        result = self.screen.check_transaction_result()

        if result["success"]:
            if self.logger:
                self.logger.info(f"Result: {result['code']} (SUCCESS)")
        else:
            if self.logger:
                self.logger.warning(
                    f"Result: {result['code']} — {result['raw_line']}")
            if self.evidence:
                self.evidence.capture("error_screen", self.driver)

        if self.logger:
            self.logger.step_success("Check transaction result")

        return result

    def _capture_cb(self, step_name):
        """before_enter hook: evidence of the typed command on screen
        just before submission (compliance pairs)."""
        if not self.evidence:
            return None
        return lambda: self.evidence.capture(step_name, self.driver)

    def _build_post_commit_result(self, operation, employee_code,
                                  affiliation_code, exc):
        """A step AFTER the "70" commit failed — reported as
        submitted-but-unconfirmed, never as a retryable failure (see
        ProvisionWorkflow._build_post_commit_result)."""
        step = getattr(exc, "step", "") or self._stage
        code = self._confirmed_code
        # Names the code read after '70' and the step that failed, so
        # the e-mail and the ticket note say what to check (NB-013).
        error_msg = ("'70' sent"
                     + (f"; result {code} confirmed on screen" if code
                        else "; result not read")
                     + (f"; the later step '{step}' failed" if step
                        else "; a later step failed")
                     + f": {exc} — manual check required")
        if self.logger:
            self.logger.error(
                f"{operation}: commit sent, later step failed — {exc}")
        result = {
            "status": "success",
            "operation": operation,
            "employee_code": employee_code,
            "affiliation_code": affiliation_code,
            "result_code": "UNCONFIRMED",
            "evidence_path": (self.evidence.get_evidence_path()
                              if self.evidence else None),
            "error": error_msg,
            "error_id": getattr(exc, "rule_id", ""),
            "error_trace": list(self.guard.trace),
            "failed_step": step,
            "post_commit_error": True,
            "commit_sent": True,
        }
        if self._confirmed_code:
            result["confirmed_code"] = self._confirmed_code
        return result

    def _build_failure(self, operation, employee_code, affiliation_code,
                       error_msg, error_type, step="", exc=None):
        # A fired catalogue rule carries its own reporting status and
        # tells the exit walk where to start (see ProvisionWorkflow).
        if exc is not None:
            self._exit_from_login = bool(
                getattr(exc, "exit_from_login", False))
        result = {
            "status": getattr(exc, "error_status", "failed") or "failed",
            "operation": operation,
            "employee_code": employee_code,
            "affiliation_code": affiliation_code,
            "error_id": getattr(exc, "rule_id", ""),
            "error_trace": list(self.guard.trace),
            "result_code": "",
            "evidence_path": (self.evidence.get_evidence_path()
                              if self.evidence else None),
            "error": error_msg,
            "error_type": error_type,
            # WHERE it failed — exceptions carry their step name; the
            # audit trail surfaces this for debugging without log-diving.
            "failed_step": step,
        }
        # A catalogue rule that says the whole request must not be run
        # again (retry.whole_request false).
        if getattr(exc, "retryable", None) is False:
            result["retryable"] = False
        if self.logger:
            self.logger.transaction_failed(operation, error_msg)
        return result
