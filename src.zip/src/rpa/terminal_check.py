"""Terminal check for administrators (2026-09-29, T1/T2).

Proves on demand that the FINESIII terminal starts and that the bot can
move through it, without running a real request.

  launch    start the terminal, check for error dialogs (e.g. センター
            準備中), confirm the Core Business Menu, then close the menu
            ('99' + 'XX', as the normal sign-off does). Never signs in.
  navigate  launch, menu '10' to the FINESIII login window, sign in once
            with the service account, business menu → Task 903 (account
            management), then the same sign-off the workflows use after
            a failure before the commit. NEVER types data, never sends
            '00' at the execution field or '70'.

Every step is timed and evidenced (screenshots in the evidence folder
terminal-check-<date-time>); password values are masked in every trace,
as for requests. The same navigator steps, error-screen guard, driver
wrapper and credentials as a real request are used — the keystrokes of
real requests do not change.

Only one check runs at a time. The caller (the console API) makes sure
processing is paused and no request is running.
"""
from __future__ import annotations

import threading
import time
from datetime import datetime
from types import SimpleNamespace

from src.core.evidence import EvidenceCapture

LEVELS = ("launch", "navigate")
# Drivers that drive a real (or mock) terminal in this process.
SUPPORTED_DRIVERS = ("pywinauto", "pyautogui", "mock")


def _hint(error) -> str:
    """What to check, in plain words, for the usual failures."""
    from src.core.exceptions import (
        ApplicationLaunchError, LoginFailedError, ScreenNotRecognizedError,
        ScreenTimeoutError,
    )
    text = str(error)
    if getattr(error, "rule_id", ""):
        return (f"A recognised error screen ({error.rule_id}) appeared; see "
                f"the screenshot and the error rules. For the centre not "
                f"ready, try again once the host is up.")
    if isinstance(error, ApplicationLaunchError):
        return ("The terminal program could not be started. Check the "
                "shortcut path under Settings > FINESIII terminal (the "
                "paths searched are listed above) and that the program is "
                "installed for the account that runs the bot.")
    if isinstance(error, LoginFailedError):
        return ("The sign-in was not accepted. Check the service account "
                "(affiliation code, staff code and the password in "
                "CyberArk) and that it is not locked.")
    if isinstance(error, (ScreenTimeoutError, ScreenNotRecognizedError)) \
            or "timeout" in text.lower() or "not recognized" in text.lower():
        return ("The expected screen was not recognised in time. Compare "
                "the screenshot with the screen definitions (window title, "
                "window class and screen text) and check that the desktop "
                "session is unlocked.")
    return ""


class TerminalCheck:
    # After a check could not sign in, the next sign-in check waits this
    # long: a wrong password counts toward the account lock-out (TM-03,
    # 2026-10-03).
    SIGN_IN_BACKOFF_SECONDS = 600

    # Where the time of the last failed sign-in check is kept, so a
    # restart does not lift the wait (UAT-L20, 2026-10-04).
    STORE_KEY = "TERMINAL_SIGN_IN_FAILED_AT"

    def __init__(self, executor, logger=None, audit=None, store=None):
        self.executor = executor
        self.logger = logger
        self.audit = audit
        self.store = store
        self._lock = threading.Lock()
        self.last_result = None
        self._sign_in_failed_at = 0.0
        if store is not None:
            try:
                self._sign_in_failed_at = float(
                    store.all().get(self.STORE_KEY) or 0.0)
            except Exception:
                self._sign_in_failed_at = 0.0

    def _remember_sign_in_failure(self, when: float) -> None:
        self._sign_in_failed_at = when
        if self.store is None:
            return
        try:
            if when:
                self.store.set(self.STORE_KEY, str(when))
            else:
                self.store.clear(self.STORE_KEY)
        except Exception:
            pass

    def sign_in_wait_seconds(self) -> int:
        """Seconds until a sign-in check may run again (0 = now)."""
        if not self._sign_in_failed_at:
            return 0
        return max(0, int(self._sign_in_failed_at
                          + self.SIGN_IN_BACKOFF_SECONDS - time.time()))

    @property
    def running(self) -> bool:
        return self._lock.locked()

    def driver_name(self) -> str:
        return str((getattr(self.executor, "rpa_config", None) or {})
                   .get("driver", ""))

    def run(self, level: str) -> dict:
        """Run one check. Raises RuntimeError when one is running."""
        if level not in LEVELS:
            raise ValueError(f"level must be one of: {', '.join(LEVELS)}")
        if not self._lock.acquire(blocking=False):
            raise RuntimeError("A terminal check is already running.")
        try:
            result = self._run(level)
        finally:
            self._lock.release()
        if level == "navigate" and result.get("failed_step") == "sign_in":
            self._remember_sign_in_failure(time.time())
        elif result.get("ok") and level == "navigate":
            self._remember_sign_in_failure(0.0)
        self.last_result = result
        return result

    # ── the check ──

    def _run(self, level: str) -> dict:
        from src.rpa.executor import create_driver
        from src.rpa.screens.error_handler import build_guard
        from src.rpa.screens.navigator import Navigator
        from src.rpa.screens.state import ScreenState

        ex = self.executor
        rpa_config = ex.rpa_config
        check_id = "terminal-check-" + datetime.now().strftime(
            "%Y%m%d-%H%M%S")
        evidence = EvidenceCapture(rpa_config.get("evidence", {}),
                                   transaction_id=check_id)
        steps = []
        # The terminal program and window in force — the settings the
        # service started with, not the ones on the page (TM-02).
        app_cfg = rpa_config.get("application") or {}
        result = {"ok": False, "level": level, "driver": self.driver_name(),
                  "application": {
                      "shortcut": str(app_cfg.get("shortcut_path", "") or ""),
                      "executable": str(app_cfg.get("executable_path", "")
                                        or ""),
                      "window_title": str(
                          app_cfg.get("window_title_pattern", "") or "")},
                  "check_id": check_id, "steps": steps, "failed_step": "",
                  "error": "", "hint": "",
                  "sign_off": {"ok": None, "stopped_at": ""},
                  "evidence_folder": str(getattr(evidence, "txn_dir", ""))}
        logger = getattr(ex, "logger", None) or self.logger
        # The check's own ID on its log lines, not the last request's
        # (E2E-L29); cleared again when it ends.
        tagged = hasattr(logger, "set_transaction") and \
            hasattr(logger, "set_step")
        if tagged:
            logger.set_transaction(check_id)
            logger.set_step(None)
        driver = None
        navigator = None
        state = {"launched": False, "at_login": False, "signed_in": False,
                 "exit_from_login": False}

        def step(name, what, fn, screen=""):
            started = time.time()
            try:
                fn()
            except Exception as e:
                steps.append({"step": name, "what": what, "status": "failed",
                              "seconds": round(time.time() - started, 1),
                              "screen": "", "detail": str(e)[:300]})
                result.update(failed_step=name, error=str(e)[:300],
                              hint=_hint(e))
                state["exit_from_login"] = bool(
                    getattr(e, "exit_from_login", False))
                return False
            steps.append({"step": name, "what": what, "status": "ok",
                          "seconds": round(time.time() - started, 1),
                          "screen": screen, "detail": ""})
            return True

        try:
            # The same driver and wrapper as a request: every keystroke
            # traced, password values masked, screenshots classified.
            bare = create_driver(rpa_config)
            driver = ex._observe(bare, SimpleNamespace(
                request_id=check_id, password=""), rpa_config) \
                if hasattr(ex, "_observe") else bare
            screen = ScreenState(rpa_config.get("screens", {}), driver,
                                 logger)
            guard = build_guard(driver, rpa_config, evidence=evidence,
                                logger=logger)
            navigator = Navigator(
                driver, screen, rpa_config.get("navigation", {}),
                rpa_config.get("timing", {}),
                rpa_config.get("environment", "development"),
                logger, evidence, guard=guard)

            ok = step("launch", "Start the terminal; Core Business Menu",
                      navigator.step_1_launch_application,
                      "core_business_menu")
            state["launched"] = True
            if ok and level == "navigate":
                ok = step("open_login", "Menu 10 → FINESIII login window",
                          navigator.step_2_navigate_core_business_menu,
                          "finesiii_login")
                state["at_login"] = ok
                if ok:
                    ok = step("sign_in", "Sign in with the service account",
                              lambda: navigator.step_3_login(
                                  ex.credentials), "business_menu")
                    state["signed_in"] = ok
                    if not ok:
                        # A rejected sign-in leaves the login screen up.
                        state["exit_from_login"] = True
                if ok:
                    ok = step("task_903", "Business menu → Task 903",
                              navigator.step_4_navigate_to_903,
                              "account_management")
            result["ok"] = ok
        except Exception as e:
            # The driver could not even be created.
            steps.append({"step": "launch", "what": "Start the terminal",
                          "status": "failed", "seconds": 0, "screen": "",
                          "detail": str(e)[:300]})
            result.update(failed_step="launch", error=str(e)[:300],
                          hint=_hint(e))
        finally:
            result["sign_off"] = self._sign_off(level, driver, navigator,
                                                state, steps)
            if tagged:
                logger.set_transaction(None)
                logger.set_step(None)
        return result

    def _sign_off(self, level, driver, navigator, state, steps) -> dict:
        """Leave the terminal as a request does. Never raises."""
        if driver is None:
            return {"ok": True, "stopped_at": ""}
        started = time.time()
        stopped = ""
        try:
            if level == "navigate" and state["at_login"]:
                # The sign-off the workflows use after a failure before
                # the commit (from the login screen when never signed in).
                navigator.exit_application(
                    from_login_screen=state["exit_from_login"]
                    or not state["signed_in"])
                stopped = navigator.logout_failed_stage
            elif state["launched"] and navigator is not None:
                # Only the menu is open: '99' then 'XX' closes it.
                nav = navigator.nav
                try:
                    driver.submit_command(nav.get("exit_command", "99"))
                    time.sleep(1.5)
                    driver.submit_command(nav.get("system_shutdown", "XX"))
                    time.sleep(1.0)
                except Exception as e:
                    stopped = f"menu_exit: {e}"[:200]
                if navigator.evidence:
                    try:
                        navigator.evidence.capture("logout_complete", driver)
                    except Exception:
                        pass
        except Exception as e:
            stopped = str(e)[:200]
        try:
            driver.close_application()
        except Exception:
            pass
        steps.append({"step": "sign_off", "what": "Sign off and close",
                      "status": "failed" if stopped else "ok",
                      "seconds": round(time.time() - started, 1),
                      "screen": "", "detail": stopped})
        return {"ok": not stopped, "stopped_at": stopped}
