"""Secure credential management for the FINESIII terminal session.

Port of v2 utils/credential.py, unchanged. Supports three backends:
  - environment: OS environment variables (CI/CD friendly, the default)
  - keyring: OS-native credential store (most secure for desktops)
  - config: YAML config (NOT recommended — development only)

CyberArk CCP becomes the production backend when the integrations
adapter lands (Phase 4); until then production uses environment
variables injected by the platform, never files.

NEVER hardcode credentials in source code.
"""

import os
from dataclasses import dataclass


@dataclass
class FINESIIICredentials:
    """FINESIII login credentials."""
    affiliation_code: str   # 所属コード — 5 digits
    application_id: str     # 担当者コード — 7 digits (FFM Application ID)
    password: str           # パスワード — 8 digits

    def validate(self):
        """Validate credential format before use."""
        errors = []
        if not self.affiliation_code or len(self.affiliation_code) != 5:
            errors.append(
                f"Affiliation code must be 5 digits, got: "
                f"'{self.affiliation_code}' "
                f"({len(self.affiliation_code or '')} chars)"
            )
        if not self.application_id or len(self.application_id) != 7:
            errors.append(
                f"Application ID must be 7 characters, got: "
                f"'{self.application_id}' "
                f"({len(self.application_id or '')} chars)"
            )
        if not self.password or len(self.password) != 8:
            errors.append(
                f"Password must be 8 characters, got length: "
                f"{len(self.password or '')}"
            )
        if errors:
            # Mask actual values in error messages for security
            raise ValueError(
                "Credential validation failed:\n"
                + "\n".join(f"  - {e}" for e in errors)
            )
        return True

    def masked(self) -> dict:
        """Return credentials with password masked — safe for logging."""
        return {
            "affiliation_code": self.affiliation_code,
            "application_id": self.application_id,
            "password": ("****" + self.password[-2:]
                         if self.password else "****")
        }


class CredentialManager:
    """Retrieves credentials from the configured backend."""

    def __init__(self, config: dict):
        self.method = config.get("method", "environment")
        self.config = config

    def get_credentials(self) -> FINESIIICredentials:
        """Retrieve and validate credentials."""
        if self.method == "environment":
            return self._from_environment()
        elif self.method == "keyring":
            return self._from_keyring()
        elif self.method == "config":
            return self._from_config()
        else:
            raise ValueError(f"Unknown credential method: {self.method}")

    def _from_environment(self) -> FINESIIICredentials:
        """Retrieve from OS environment variables."""
        env_vars = self.config.get("env_vars", {})
        creds = FINESIIICredentials(
            affiliation_code=os.environ.get(
                env_vars.get("affiliation_code",
                             "FINESIII_AFFILIATION_CODE"), ""
            ),
            application_id=os.environ.get(
                env_vars.get("application_id",
                             "FINESIII_APPLICATION_ID"), ""
            ),
            password=os.environ.get(
                env_vars.get("password", "FINESIII_PASSWORD"), ""
            ),
        )
        creds.validate()
        return creds

    def _from_keyring(self) -> FINESIIICredentials:
        """Retrieve from OS-native credential store."""
        try:
            import keyring
        except ImportError:
            raise ImportError(
                "keyring package required for keyring credential method. "
                "Install with: pip install keyring"
            )

        service = self.config.get("keyring_service", "finesiii_rpa")
        creds = FINESIIICredentials(
            affiliation_code=keyring.get_password(
                service, "affiliation_code") or "",
            application_id=keyring.get_password(
                service, "application_id") or "",
            password=keyring.get_password(service, "password") or "",
        )
        creds.validate()
        return creds

    def _from_config(self) -> FINESIIICredentials:
        """Retrieve from config file — DEVELOPMENT ONLY."""
        import warnings
        warnings.warn(
            "Loading credentials from config file. "
            "This is NOT secure — use 'environment' or 'keyring' in "
            "production.",
            UserWarning,
            stacklevel=2
        )
        creds = FINESIIICredentials(
            affiliation_code=self.config.get("affiliation_code", ""),
            application_id=self.config.get("application_id", ""),
            password=self.config.get("password", ""),
        )
        creds.validate()
        return creds
