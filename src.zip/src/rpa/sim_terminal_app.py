"""FINESIII Simulated Terminal — standalone per-request window app.

Port of v2 sim_terminal_app.py, adapted to the v3 package layout.
Launched as a SEPARATE PROCESS by SimTerminalSubprocessLauncher for
each request. Opens its own green-screen Tkinter window on its OWN main
thread (the robust cross-platform approach — no macOS main-thread
conflict), animates all the steps for the one request, closes the
window, and writes the result back to a file.

This mirrors real RPA: each ticket triggers a fresh terminal session
that opens, does its work visibly, and closes.

Usage (invoked by the launcher, not run by hand):
  python -m src.rpa.sim_terminal_app <request_json> <result_json>

The request file contains:
  {"operation","affiliation_code","employee_code","password",
   "scenario","action_delay","login_affiliation","login_staff",
   "login_password","environment","evidence","request_id"}

The result file is written with the workflow result dict.
"""

import json
import sys
import threading


def main():
    if len(sys.argv) < 3:
        print("Usage: python -m src.rpa.sim_terminal_app "
              "<request_json> <result_json>")
        sys.exit(1)

    request_file = sys.argv[1]
    result_file = sys.argv[2]

    with open(request_file, "r", encoding="utf-8") as f:
        req = json.load(f)

    from src.rpa.config import build_rpa_config
    from src.rpa.credentials import FINESIIICredentials
    from src.rpa.drivers.ocr_wrapper import ObservedDriver
    from src.rpa.drivers.sim_terminal import SimTerminalDriver
    from src.rpa.vision.keywords import PathClassifier, load_rules
    from src.rpa.vision.ocr import build_ocr_engine
    from src.rpa.workflows.deprovision import DeprovisionWorkflow
    from src.rpa.workflows.provision import ProvisionWorkflow
    from src.core.evidence import EvidenceCapture

    evidence_cfg = req.get("evidence", {}) or {}
    config = build_rpa_config(
        driver="sim_terminal",
        environment=req.get("environment", "development"),
        evidence_dir=evidence_cfg.get("output_dir", "evidence"),
        scenario=req.get("scenario", "success"),
        action_delay=req.get("action_delay", 0.4),
        ocr=req.get("ocr") or None,
        errors=req.get("errors") or None,
    )

    # Build the green-screen window driver on THIS process's main thread
    driver = SimTerminalDriver()
    driver.initialize(config["application"])

    credentials = FINESIIICredentials(
        req.get("login_affiliation", "03325"),
        req.get("login_staff", "12N3940"),
        req.get("login_password", "TEST0000"),
    )
    evidence = EvidenceCapture(config.get("evidence", {}),
                               transaction_id=req.get("request_id")
                               or None)

    # OCR/audit observer — the workflow drives the observed driver
    # (per-action trace, screen classification, printed .txt evidence);
    # the Tk mainloop below keeps running on the RAW driver.
    ocr_cfg = config.get("ocr", {})
    observed = ObservedDriver(
        driver,
        build_ocr_engine(ocr_cfg, "sim_terminal", None),
        PathClassifier(load_rules(ocr_cfg.get("keywords_path")),
                       ocr_cfg.get("min_confidence", 0.75)),
        config.get("screens", {}),
        request_id=req.get("request_id", ""),
        secrets=(req.get("login_password", ""), req.get("password", "")),
        capture_text=ocr_cfg.get("capture_text", True),
    )

    result = {"status": "failed", "error": "not started"}

    # The workflow runs on a worker thread; the Tk window runs the
    # mainloop on this main thread. Close the window when it finishes.
    def run_workflow():
        nonlocal result
        try:
            if req["operation"] == "provision":
                wf = ProvisionWorkflow(observed, config, None, evidence)
                result = wf.execute(
                    credentials, req["affiliation_code"],
                    req["employee_code"], req.get("password") or None
                )
            else:
                wf = DeprovisionWorkflow(observed, config, None,
                                         evidence)
                result = wf.execute(
                    credentials, req["affiliation_code"],
                    req["employee_code"]
                )
        except Exception as e:
            result = {"status": "failed", "error": str(e),
                      "result_code": "", "evidence_path": ""}
        finally:
            # Traces ride back to the service through the result file
            # (the dispatcher writes them to the audit DB).
            try:
                result.update(observed.traces())
            except Exception:
                pass
            # Tell the window to close once steps are done
            driver.request_close()

    wf_thread = threading.Thread(target=run_workflow, daemon=True)
    wf_thread.start()

    # Run the Tk mainloop on the main thread (blocks until window closes)
    driver.run_mainloop()

    wf_thread.join(timeout=5)

    # Write the result back for the parent process
    with open(result_file, "w", encoding="utf-8") as f:
        json.dump(result, f, default=str)


if __name__ == "__main__":
    main()
