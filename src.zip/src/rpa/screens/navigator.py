"""Screen navigation engine for the FINESIII terminal.

Port of v2 core/navigator.py, unchanged.

Navigation path (from June 3 walkthrough):
  Desktop "Online Business" → Core Business Menu (appears directly)
    → [enter 10, twice] → FINESIII Login (separate KANRIP window)
    → [enter credentials + 00] → Business Menu
    → [enter 903] → Task 0903 (Account Management)

Login credential entry uses Enter between fields (not Tab).

Dev environment: login affiliation code must have "99" prepended.
The account affiliation code in FID 105 does NOT get the prefix.

Logout sequence crosses TWO windows (FINESIII/KANRIP then the
FGG1010 menu): 3 plain '99's, clear the leftover affiliation code,
final '99' closes FINESIII, re-attach to the menu window, '99' → 'XX'.
"""

import time

from src.core.evidence import EvidenceCapture
from src.core.exceptions import LoginFailedError
from src.rpa.credentials import FINESIIICredentials
from src.rpa.drivers.base import BaseDriver
from src.rpa.screens.state import ScreenState


class Navigator:

    def __init__(self, driver: BaseDriver, screen_state: ScreenState,
                 nav_config: dict, timing_config: dict,
                 environment: str = "development",
                 logger=None, evidence: EvidenceCapture = None,
                 guard=None):
        self.driver = driver
        self.screen = screen_state
        self.nav = nav_config
        self.timing = timing_config
        self.environment = environment
        self.logger = logger
        self.evidence = evidence
        # ScreenGuard (config/errors.yaml). None = no error catalogue,
        # in which case every _guard_check below is a no-op and this
        # navigator behaves exactly as it did before.
        self.guard = guard
        # Set when the logout walk stops early — read by the workflows
        # for the audit trail.
        self.logout_failed_stage = ""

    def _guard_check(self, step: str, expect: str = "") -> None:
        """Evaluate the error catalogue at a navigation checkpoint.
        Raises the rule's mapped exception when an error screen fires;
        returns silently on a clean (or untrustworthy) read."""
        if self.guard is not None:
            self.guard.check(step, expect=expect)

    def _capture_cb(self, step_name: str):
        """before_enter hook for submit_command: captures the
        typed-but-not-submitted screen (compliance requirement —
        evidence of what the bot entered, not only empty screens)."""
        if not self.evidence:
            return None
        return lambda: self.evidence.capture(step_name, self.driver)

    def _post_entry_wait(self):
        time.sleep(self.timing.get("post_entry_delay", 2.0))

    def navigate_to_account_management(self,
                                       credentials: FINESIIICredentials):
        """Execute full navigation from launch to Task 0903."""
        if self.logger:
            self.logger.step_start("Full navigation to Task 0903")

        self.step_1_launch_application()
        self.step_2_navigate_core_business_menu()
        self.step_3_login(credentials)
        self.step_4_navigate_to_903()

        if self.logger:
            self.logger.step_success("Full navigation to Task 0903")

    def step_1_launch_application(self):
        """Launch the FINESIII terminal (Online Business desktop
        shortcut). Core Business Menu appears directly after launch."""
        if self.logger:
            self.logger.step_start("Launch FINESIII terminal")

        self.driver.launch_application()
        self._post_entry_wait()

        if self.evidence:
            self.evidence.capture("application_launched", self.driver)

        # Checkpoint: a connection/startup error dialog (e.g.
        # センター準備中) lands here, before any screen the bot expects.
        # Without this check the modal swallows every later keystroke
        # and the failure only surfaces as a bogus login timeout.
        self._guard_check("launch_application")

        # Core Business Menu appears directly after launch
        self.screen.wait_for("core_business_menu")

        if self.evidence:
            self.evidence.capture("core_menu_loaded", self.driver)

        if self.logger:
            self.logger.step_success("Launch FINESIII terminal")

    def step_2_navigate_core_business_menu(self):
        """Core Business Menu → FINESIII Login.
        Enter "10" + Enter TWO TIMES to reach the login screen.

        The second "10" (FINESⅢ) opens a SEPARATE new window (process
        KANRIP, title 'FINESⅢ'). The bot must re-attach to that new
        window before continuing, or credentials would be typed into the
        old menu window."""
        if self.logger:
            self.logger.step_start("Core Business Menu → FINESIII Login")

        code = self.nav.get("core_menu_to_finesiii", "10")

        # First "10" + Enter  → enters 基幹業務メニュー (Core Business Menu)
        self.driver.submit_command(
            code, before_enter=self._capture_cb("menu_selection_entered"))
        self._post_entry_wait()

        # Second menu screen (7802) on arrival
        if self.evidence:
            self.evidence.capture("menu_2_loaded", self.driver)

        # Second "10" + Enter  → launches the separate FINESⅢ login window
        self.driver.submit_command(
            code, before_enter=self._capture_cb("menu_selection_entered"))
        self._post_entry_wait()

        # Re-attach to the newly-opened FINESⅢ login window.
        login_title = self.nav.get("login_window_title", "FINES")
        if hasattr(self.driver, "reattach_to_window"):
            self.driver.reattach_to_window(login_title)
            self._post_entry_wait()

        # Checkpoint: connecting to FINESIII is exactly where the
        # centre-not-ready dialog appears.
        self._guard_check("finesiii_connect", expect="finesiii_login")

        self.screen.wait_for("finesiii_login")

        if self.evidence:
            self.evidence.capture("login_screen_loaded", self.driver)

        if self.logger:
            self.logger.step_success("Core Business Menu → FINESIII Login")

    def step_3_login(self, credentials: FINESIIICredentials):
        """Login to FINESIII using Enter between credential fields.

        Dev environment: login affiliation gets "99" prepended.
        The account affiliation in FID 105 is NOT affected.
        """
        if self.logger:
            self.logger.step_start("Login to FINESIII")
            self.logger.info(f"Environment: {self.environment}")

        try:
            # Build login affiliation code (prepend "99" in dev)
            login_affiliation = credentials.affiliation_code
            if self.environment == "development":
                login_affiliation = "99" + credentials.affiliation_code
                if self.logger:
                    # The service account's code stays out of the log
                    # (D-09, 2026-10-05).
                    self.logger.info(
                        "Dev environment: '99' prepended to the login "
                        "affiliation code")

            # Enter Affiliation Code → press Enter
            self.driver.type_text(login_affiliation)
            time.sleep(self.timing.get("field_entry_delay", 0.3))
            self.driver.press_key("enter")
            time.sleep(0.2)

            # Enter Staff Code → press Enter
            self.driver.type_text(credentials.application_id)
            time.sleep(self.timing.get("field_entry_delay", 0.3))
            self.driver.press_key("enter")
            time.sleep(0.2)

            # Enter Password → press Enter
            self.driver.type_text(credentials.password)
            time.sleep(self.timing.get("field_entry_delay", 0.3))
            self.driver.press_key("enter")
            time.sleep(0.2)

            # All three credentials are on screen (password masked by
            # the terminal itself) — capture before submitting.
            if self.evidence:
                self.evidence.capture("login_credentials_entered",
                                      self.driver)

            # Submit login with "00" → press Enter
            login_command = self.nav.get("login_command", "00")
            self.driver.submit_command(login_command)
            self._post_entry_wait()

            # The codes just submitted, as SEPARATE data points for the
            # audit trail and the notification email. FINESIII answers
            # a bad staff code and a bad affiliation code with the same
            # 「オペレーターコード未登録です」, so the bot reports both
            # values and never claims which one is wrong. The password
            # is deliberately NOT included.
            if self.guard is not None:
                self.guard.set_context(
                    login_affiliation_code=login_affiliation,
                    login_staff_code=credentials.application_id)

            # Checkpoint: read the screen BEFORE concluding anything
            # from a wait timeout. A credential/session error names
            # itself here, so the catalogue can classify it correctly
            # instead of it surfacing as an opaque login timeout.
            self._guard_check("login_submitted", expect="business_menu")

            # Wait for Business Menu to confirm login success
            self.screen.wait_for("business_menu")

            if self.evidence:
                self.evidence.capture("login_successful", self.driver)

            if self.logger:
                self.logger.step_success("Login to FINESIII")

        except Exception as e:
            if self.evidence:
                self.evidence.capture("login_failed", self.driver)
            # A catalogue rule that fired here already carries its own
            # classification (business vs system) and reporting status.
            # Re-wrapping it as LoginFailedError — a SystemException —
            # would silently override that and hand a business failure
            # to the retry policy.
            if getattr(e, "rule_id", ""):
                raise
            raise LoginFailedError(
                f"FINESIII login failed: {e}",
                step="login",
                details=credentials.masked()
            )

    def step_4_navigate_to_903(self):
        """Business Menu → Task 0903. Enter "903"."""
        if self.logger:
            self.logger.step_start("Business Menu → Task 0903")

        code = self.nav.get("business_menu_to_903", "903")
        self.driver.submit_command(
            code, before_enter=self._capture_cb("task_number_entered"))
        self._post_entry_wait()

        # Checkpoint: invalid task number / permission denied surfaces
        # as an error line on the menu, not as a missing screen.
        self._guard_check("task_selected", expect="account_management")

        self.screen.wait_for("account_management")

        if self.evidence:
            self.evidence.capture("did903_loaded", self.driver)

        if self.logger:
            self.logger.step_success("Business Menu → Task 0903")

    def navigate_back_to_903(self):
        """Return to Task 0903 for next transaction (batch session
        reuse)."""
        if self.logger:
            self.logger.step_start("Return to Task 0903")

        exit_cmd = self.nav.get("exit_command", "99")
        self.driver.submit_command(exit_cmd)
        self._post_entry_wait()

        self.screen.wait_for("business_menu")

        code = self.nav.get("business_menu_to_903", "903")
        self.driver.submit_command(code)
        self._post_entry_wait()

        self.screen.wait_for("account_management")

        if self.logger:
            self.logger.step_success("Return to Task 0903")

    def handle_print_screen(self):
        """Handle the mandatory print screen after successful submission.
        This screen always appears after a "70" commit to save a PDF
        journal. Press "10" to print, wait for プリント済, press "99"."""
        if self.logger:
            self.logger.step_start("Handle print screen (mandatory)")

        # Checkpoint: an error dialog here blocks the mandatory journal
        # print, which otherwise fails silently (warning only, below).
        self._guard_check("print_screen")

        try:
            self.screen.wait_for("print_screen", timeout=20)
        except Exception:
            if self.logger:
                self.logger.warning(
                    "Print screen NOT detected within 20s — this is "
                    "unexpected. The print screen should always appear "
                    "after a successful submission. Continuing, but "
                    "evidence may be incomplete."
                )
            return

        if self.evidence:
            self.evidence.capture("print_screen_loaded", self.driver)

        print_cmd = self.nav.get("print_command", "10")
        self.driver.submit_command(print_cmd)
        self._post_entry_wait()

        try:
            self.screen.wait_for("print_complete", timeout=15)
        except Exception:
            if self.logger:
                self.logger.warning("Print complete screen not detected")

        if self.evidence:
            self.evidence.capture("print_complete", self.driver)

        # Press "99" to return after print (first step of the logout
        # walk — evidenced like every other navigation command)
        exit_cmd = self.nav.get("exit_command", "99")
        self.driver.submit_command(
            exit_cmd, before_enter=self._capture_cb("logout_step_entered"))
        self._post_entry_wait()

        if self.logger:
            self.logger.step_success("Handle print screen")

    def exit_application(self, from_login_screen: bool = False):
        """Logout — window-aware sequence per app-team confirmation.

        FINESIII window (process KANRIP):
            • 3 plain '99's step back through the FINESIII screens
            • then the affiliation code left over on the login screen is
              CLEARED, and a final '99' closes the FINESIII window
            (the print step already issued 1 '99', so FINESIII sees
            5 '99's)

        Main Menu window (process FGG1010):
            • re-attach to the original step-1 menu window
            • '99' navigates, then 'XX' closes the menu window

        Args:
            from_login_screen: skip the 3 plain '99's and start at the
                login-screen exit walk. Used when the bot never got
                past login — a connection error (センター準備中) leaves
                it ON the login screen, where the walk-back '99's have
                no screens to step through and would be typed into the
                credential fields. Client-confirmed behaviour for
                Case 1: acknowledge, then exit from the login screen
                through to closing the application.

        Counts/identifiers are config-driven:
            navigation.logout_plain_99_count   (default 3)
            navigation.logout_backtab_count    (default 4)
            navigation.affiliation_field_width (default 7)
            navigation.menu_window_title       (default '基幹業務')
        """
        step_label = ("Exit FINESIII (logout from login screen)"
                      if from_login_screen else "Exit FINESIII (logout)")
        if self.logger:
            self.logger.step_start(step_label)

        exit_cmd = self.nav.get("exit_command", "99")
        shutdown_cmd = self.nav.get("system_shutdown", "XX")
        plain_99_count = 0 if from_login_screen else \
            self.nav.get("logout_plain_99_count", 3)
        clear_count = self.nav.get("logout_field_clear_count", 8)
        # WHERE the logout broke, if it does — surfaced in the audit
        # trail instead of vanishing into a warning (C5).
        stage = "start"

        try:
            # --- FINESIII window: 3 plain '99's ---
            # Each step is evidenced (approved 2026-08-17): the typed
            # '99' with the screen it walks back FROM — the navigation
            # debugging trail for the logout sequence.
            stage = "plain_99_walk"
            for _ in range(plain_99_count):
                self.driver.submit_command(
                    exit_cmd,
                    before_enter=self._capture_cb("logout_step_entered"))
                time.sleep(1.5)

            # --- FINESIII window: anchor to the affiliation field
            #     (first field), clear it, submit the closing exit code ---
            # Cursor position on the login screen is not guaranteed, so we
            # use repeated Shift+Tab (which STAYS on the first field, no
            # wrap) to anchor reliably from any position, then
            # overtype-clear the leftover affiliation code and submit the
            # exit code.
            stage = "login_screen_exit"
            backtab_count = self.nav.get("logout_backtab_count", 4)
            field_width = self.nav.get("affiliation_field_width", 7)
            # State before the exit walk: back on the login screen with
            # the leftover affiliation code — the walk clears it.
            if self.evidence:
                self.evidence.capture("logout_login_screen", self.driver)
            if hasattr(self.driver, "goto_first_field_and_exit"):
                self.driver.goto_first_field_and_exit(
                    exit_cmd, field_width, backtab_count)
                if self.logger:
                    self.logger.info(
                        "Anchored to affiliation field (Shift+Tab), "
                        f"cleared leftover code, and submitted "
                        f"'{exit_cmd}'"
                    )
            else:
                # Fallback for drivers without the helper
                if hasattr(self.driver, "clear_field"):
                    self.driver.clear_field(clear_count)
                    time.sleep(0.3)
                self.driver.submit_command(
                    exit_cmd,
                    before_enter=self._capture_cb("logout_step_entered"))
            time.sleep(2.0)  # allow the FINESIII window to close

            # --- Re-attach to the Main Menu window (by class + title) ---
            stage = "menu_reattach"
            menu_title = self.nav.get("menu_window_title", "基幹業務")
            if hasattr(self.driver, "reattach_to_menu_window"):
                self.driver.reattach_to_menu_window(menu_title)
                time.sleep(1.0)
                if self.logger:
                    self.logger.info(
                        f"Re-attached to Main Menu window (title "
                        f"contains '{menu_title}')"
                    )

            # Menu window state after the FINESIII window closed
            if self.evidence:
                self.evidence.capture("logout_menu_returned", self.driver)

            # --- Main Menu window: '99' then 'XX' ---
            stage = "menu_exit"
            self.driver.submit_command(
                exit_cmd,
                before_enter=self._capture_cb("logout_step_entered"))
            time.sleep(1.5)
            stage = "system_shutdown"
            self.driver.submit_command(
                shutdown_cmd,
                before_enter=self._capture_cb("logout_shutdown_entered"))
            time.sleep(1)
            stage = "complete"

        except Exception as e:
            # A broken logout used to vanish into a warning, leaving no
            # trace of WHERE the walk stopped. Record the stage so the
            # audit trail can explain the terminal's end state.
            self.logout_failed_stage = stage
            if self.guard is not None:
                try:
                    self.guard.note(
                        "exit_application", "LOGOUT_INCOMPLETE",
                        f"Logout stopped at '{stage}': {e}",
                        screen=stage)
                except Exception:
                    pass
            if self.logger:
                self.logger.warning(
                    f"Logout sequence incomplete at stage '{stage}': {e}")

        try:
            self.driver.close_application()
        except Exception:
            pass

        if self.evidence:
            self.evidence.capture("logout_complete", self.driver)

        if self.logger:
            self.logger.step_success(step_label)
