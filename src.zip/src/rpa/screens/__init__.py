"""Screen definitions and deterministic navigation state machine.

Ports from v2 core/: screen_state.py (ScreenState), navigator.py
(Navigator), field_mapper.py (FieldMapper, AccountData).

v3 hardening: every state carries (verify_predicate, timeout,
recovery_action). Recovery ladder: re-anchor via PF-key -> return to
main menu -> restart emulator + re-login -> fail job with evidence.
Screen layouts live in versioned YAML so a mainframe screen change is a
data edit, not a code change.
"""
