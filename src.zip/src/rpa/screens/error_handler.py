"""ScreenGuard — turns a recognised error screen into an action.

The missing half of the vision layer. Until now the bot READ and
CLASSIFIED every screen (vision/keywords.py, ocr_wrapper.py) but never
ACTED on what it saw: the classification went to the audit trail and
nothing else. ScreenGuard closes that loop.

At each checkpoint the guard:
  1. reads the current screen (already OCR-enriched by ObservedDriver,
     so this costs no extra OCR — the image-hash cache serves it),
  2. matches it against the error catalogue (config/errors.yaml),
  3. captures evidence + records an audit entry,
  4. performs the rule's action: dismiss a modal dialog, cancel out,
     wait for a transient to clear, or raise so the workflow's exit
     sequence runs and the ticket is reported correctly.

Safety contract (upgrade-only, unchanged from the OCR classifier):
  • a read below the confidence floor may NEVER act — it is recorded
    as "suspected" and the bot carries on exactly as before;
  • a screen matching no rule behaves exactly as it did before this
    module existed;
  • evidence/audit failures never propagate — compliance artifacts
    must not crash the bot.
"""
from __future__ import annotations

import time

from src.core import exceptions as exc_mod
from src.rpa.vision import keywords as kw
from src.rpa.vision.error_catalog import (
    ACTION_ABORT_EXIT, ACTION_ACKNOWLEDGE, ACTION_CANCEL_AND_REPORT,
    ACTION_CONTINUE, ACTION_RETRY_STEP, EXIT_FROM_LOGIN, ErrorCatalog,
    ErrorMatch,
)

_MAX_TRACE = 200          # runaway guard; a real transaction sees 0-2


def build_exception(match: ErrorMatch, step: str) -> Exception:
    """Map a fired rule onto the platform exception taxonomy.

    The CLASS decides retry behaviour (BusinessException is never
    retried, SystemException is), so the catalogue's classification and
    its exception class are validated as consistent at load time.
    Rule metadata rides on the instance for the workflow result.
    """
    rule = match.rule
    cls = getattr(exc_mod, rule.exception, None) if rule.exception \
        else None
    if not isinstance(cls, type):
        cls = (exc_mod.BusinessException if rule.is_business
               else exc_mod.SystemException)

    error = cls(rule.message, step=step,
                details={"error_id": rule.id,
                         "matched": match.matched,
                         "screen": match.screen or "-",
                         **({"captured": match.captured}
                            if match.captured else {})})
    # Consumed by the workflows (status + which exit walk to run) and
    # by the dispatcher's failure-analysis event.
    error.rule_id = rule.id
    error.error_status = rule.status
    error.exit_from_login = rule.exit_from == EXIT_FROM_LOGIN
    error.matched = list(match.matched)
    error.captured = dict(match.captured)
    # retry.whole_request from the rule: False means running the whole
    # request again cannot help (the workflow result then carries
    # retryable=False and the dispatcher does not retry it).
    error.retryable = bool(rule.retry_whole_request)
    return error


class ScreenGuard:
    """Evaluates the error catalogue at a workflow checkpoint."""

    def __init__(self, driver, catalog: ErrorCatalog, *,
                 screens_cfg: dict | None = None,
                 nav_cfg: dict | None = None,
                 min_confidence: float = 0.75,
                 acknowledge_wait: float = 1.5,
                 max_step_retries: int = 2,
                 retry_wait: float = 5.0,
                 strict_screen_detection: bool = False,
                 enabled: bool = True,
                 evidence=None, logger=None):
        self.driver = driver
        self.catalog = catalog or ErrorCatalog()
        self.screens_cfg = screens_cfg or {}
        self.nav = nav_cfg or {}
        self.min_confidence = min_confidence
        self.acknowledge_wait = acknowledge_wait
        self.max_step_retries = max_step_retries
        self.retry_wait = retry_wait
        self.strict = strict_screen_detection
        self.enabled = enabled
        self.evidence = evidence
        self.logger = logger

        # Every detection (acted on or merely suspected) — attached to
        # the workflow result and persisted as rpa_error_detected.
        self.trace: list[dict] = []

        # Data points attached to detections from here on (see
        # set_context). Never holds a secret.
        self.context: dict = {}

    @property
    def active(self) -> bool:
        return bool(self.enabled and len(self.catalog.active_rules))

    def set_context(self, **values) -> None:
        """Attach labelled data points to later detections.

        Some FINESIII screens report one message for several distinct
        causes — 「オペレーターコード未登録です」 fires for a bad staff
        code AND for a bad affiliation code, with nothing on screen to
        separate them. The bot knows what it SUBMITTED, so it reports
        those values as separate labelled data points and lets a human
        judge which is wrong. It must never claim to know.

        NEVER pass a secret here: these values reach the audit trail
        and the notification email. Callers pass explicit fields only.
        """
        self.context.update({str(k): ("" if v is None else str(v))
                             for k, v in values.items()})

    def note(self, step: str, error_id: str, message: str,
             **extra) -> None:
        """Record a non-catalogue observation (e.g. a logout that broke
        mid-walk) in the same trace, so the audit trail carries one
        ordered story of everything that went wrong."""
        self._append({"step": step, "error_id": error_id,
                      "acted": False, "message": message, **extra})

    # ── Checkpoint entry point ──

    def check(self, step: str, expect: str = "") -> None:
        """Evaluate the current screen at `step`.

        Returns normally when the screen is clean (or the read is too
        weak to trust). Raises the rule's mapped exception when an
        error rule fires with a terminal action.
        """
        if not self.active:
            return
        try:
            text = self.driver.get_screen_text() or ""
        except Exception as e:
            self._log("warning", f"screen read failed at '{step}': {e}")
            return

        confidence = float(getattr(self.driver,
                                   "last_read_confidence", 1.0) or 0.0)
        screen = kw.match_screen(self.screens_cfg, text)
        match = self.catalog.match(text, confidence, screen=screen)

        if match is None:
            self._verify_expected(step, screen, expect)
            return

        # ── Upgrade-only gate ──
        # A read the OCR engine is not confident about may never abort
        # a transaction. Record it so the trail shows what was seen,
        # then behave exactly as before.
        if confidence < self.min_confidence:
            self._remember(match, step, acted=False)
            self._log("warning",
                      f"Suspected '{match.rule.id}' at '{step}' "
                      f"(confidence {confidence:.2f} < "
                      f"{self.min_confidence:.2f}) — not acting")
            return

        self._log("warning",
                  f"Error screen detected at '{step}': {match.rule.id} "
                  f"— {match.rule.message} (matched {match.matched})")
        self._remember(match, step, acted=True)
        self._capture("error_detected")
        self._act(match, step)

    # ── Actions ──

    def _act(self, match: ErrorMatch, step: str) -> None:
        rule = match.rule
        action = rule.action

        if action == ACTION_ACKNOWLEDGE:
            self._acknowledge(rule)
            self._capture("error_recovery_complete")
            action = rule.then

        if action == ACTION_CONTINUE:
            return

        if action == ACTION_RETRY_STEP:
            if self._wait_for_clear(match, step):
                return
            action = ACTION_ABORT_EXIT

        if action == ACTION_CANCEL_AND_REPORT:
            self._cancel()
            self._capture("error_recovery_complete")

        # CANCEL_AND_REPORT and ABORT_EXIT both stop the workflow; the
        # rule's status/classification decide how it is reported and
        # whether the dispatcher retries.
        raise build_exception(match, step)

    def _acknowledge(self, rule) -> None:
        """Dismiss a modal error dialog.

        The dialog is a separate owned window, so on the real terminal
        it must be FOCUSED before the key is sent — pywinauto's
        dismiss_dialog() does that and reports whether it found the
        dialog. Drivers without the helper (sim, mock, pyautogui) fall
        back to a plain key press, which is the correct behaviour for
        an in-window dialog.
        """
        key = rule.acknowledge_key or "enter"
        self._capture("error_recovery_entered")
        dismissed = False
        dismiss = getattr(self.driver, "dismiss_dialog", None)
        if callable(dismiss):
            try:
                dismissed = bool(dismiss(key=key,
                                         title_hint=rule.focus_dialog))
            except Exception as e:
                self._log("warning",
                          f"dismiss_dialog failed ({e}) — falling back "
                          f"to a plain '{key}'")
        if not dismissed:
            try:
                self.driver.press_key(key)
            except Exception as e:
                self._log("warning",
                          f"acknowledge key '{key}' failed: {e}")
                return
        self._log("info",
                  f"Acknowledged '{rule.id}' dialog with [{key.upper()}]")
        time.sleep(self.acknowledge_wait)

    def _cancel(self) -> None:
        """Back out of the current screen without committing."""
        cancel_cmd = self.nav.get("cancel_command", "99")
        try:
            self.driver.submit_command(cancel_cmd)
            time.sleep(1)
        except Exception as e:
            self._log("warning",
                      f"cancel '{cancel_cmd}' failed: {e}")

    def _wait_for_clear(self, match: ErrorMatch, step: str) -> bool:
        """Bounded wait for a transient condition to clear itself.
        True when the screen came back clean, False to escalate."""
        rule_id = match.rule.id
        for attempt in range(1, self.max_step_retries + 1):
            time.sleep(self.retry_wait)
            try:
                text = self.driver.get_screen_text() or ""
            except Exception:
                text = ""
            confidence = float(getattr(self.driver,
                                       "last_read_confidence", 1.0) or 0)
            again = self.catalog.match(
                text, confidence,
                screen=kw.match_screen(self.screens_cfg, text))
            if again is None or again.rule.id != rule_id:
                self._log("info",
                          f"'{rule_id}' cleared at '{step}' after "
                          f"attempt {attempt}/{self.max_step_retries}")
                return True
            self._log("warning",
                      f"'{rule_id}' still present at '{step}' "
                      f"({attempt}/{self.max_step_retries})")
        return False

    # ── Screen expectation (mechanism for strict mode) ──

    def _verify_expected(self, step: str, screen: str,
                         expect: str) -> None:
        """The real terminal's lenient wait proceeds on an unmatched
        screen, so a wrong screen is invisible today. Record the
        mismatch always; raise only under strict_screen_detection, so
        the default path is unchanged."""
        if not expect or not screen or screen == expect:
            return
        message = (f"Expected screen '{expect}' at '{step}' but "
                   f"detected '{screen}'")
        self._append({"step": step, "error_id": "SCREEN_MISMATCH",
                      "screen": screen, "expected": expect,
                      "acted": bool(self.strict), "message": message})
        self._log("warning", message)
        if self.strict:
            raise exc_mod.ScreenNotRecognizedError(message, step=step)

    # ── Bookkeeping ──

    def _remember(self, match: ErrorMatch, step: str,
                  acted: bool) -> None:
        entry = match.audit_detail(step=step, acted=acted)
        # The version of the rule set that recognised the error, so the
        # record proves which rules handled the transaction (UR-06,
        # 2026-10-03) — the same value the Error rules page shows.
        entry["catalog_digest"] = getattr(self.catalog, "digest", "") or ""
        if self.context:
            entry["context"] = dict(self.context)
        self._append(entry)

    def _append(self, entry: dict) -> None:
        if len(self.trace) >= _MAX_TRACE:
            return
        self.trace.append({"seq": len(self.trace) + 1, **entry})

    def _capture(self, point: str) -> None:
        if not self.evidence:
            return
        try:
            self.evidence.capture(point, self.driver)
        except Exception as e:      # compliance must never crash the bot
            self._log("warning", f"evidence '{point}' failed: {e}")

    def _log(self, level: str, message: str) -> None:
        if self.logger:
            getattr(self.logger, level, self.logger.info)(message)


def build_guard(driver, config: dict, *, evidence=None, logger=None,
                catalog: ErrorCatalog | None = None) -> ScreenGuard:
    """Construct the guard from the rpa config dict.

    Single construction site for BOTH execution paths (the in-process
    executor and the sim-terminal subprocess) — the workflows call this
    from __init__, so neither path can drift from the other.
    """
    section = config.get("errors") or {}
    enabled = bool(section.get("enabled", True))
    if catalog is None:
        catalog = ErrorCatalog.load(
            section.get("catalog_path") if enabled else None,
            strict=bool(section.get("strict", True)), logger=logger)
    return ScreenGuard(
        driver, catalog,
        screens_cfg=config.get("screens", {}),
        nav_cfg=config.get("navigation", {}),
        min_confidence=float(section.get("min_confidence", 0.75)),
        acknowledge_wait=float(section.get("acknowledge_wait", 1.5)),
        max_step_retries=int(section.get("max_step_retries", 2)),
        retry_wait=float(section.get("retry_wait", 5.0)),
        strict_screen_detection=bool(
            config.get("application", {}).get(
                "strict_screen_detection", False)),
        enabled=enabled, evidence=evidence, logger=logger)
