"""Screen state detection and validation.

Port of v2 core/screen_state.py, unchanged. Detects which screen the
bot is currently on by matching visible text against the screen
definitions in layouts.yaml. This is the bot's "eyes" — it must know
where it is before taking any action.

Carries the critical UNCONFIRMED-success semantics: on the real client
terminal the screen body is NOT machine-readable (reads return the
window title only), so an unreadable result line after a deterministic
"70" commit is reported as success with code UNCONFIRMED, never as a
false failure. Evidence screenshots capture the actual on-screen result
for audit.
"""

import time
from typing import Optional

from src.core.exceptions import (
    ScreenNotRecognizedError, ScreenTimeoutError,
)
from src.rpa.drivers.base import BaseDriver


class ScreenState:
    """Detects, validates, and waits for FINESIII screens."""

    def __init__(self, screens_config: dict, driver: BaseDriver,
                 logger=None):
        """
        Args:
            screens_config: The 'screens' section from layouts.yaml
            driver: The active automation driver
            logger: Optional TransactionLogger
        """
        self.screens = screens_config
        self.driver = driver
        self.logger = logger
        self._current_screen = None

    @property
    def current_screen(self) -> Optional[str]:
        """Return the name of the most recently detected screen."""
        return self._current_screen

    def detect_current_screen(self) -> Optional[str]:
        """Scan the screen text and determine which known screen is
        displayed. Returns the screen key from config or None."""
        try:
            screen_text = self.driver.get_screen_text()
        except Exception:
            return None

        best_match = None
        best_score = 0

        for screen_key, screen_def in self.screens.items():
            identifiers = screen_def.get("identifiers", [])
            if not identifiers:
                continue

            # Count how many identifiers match
            matches = sum(1 for ident in identifiers if ident in screen_text)
            score = matches / len(identifiers) if identifiers else 0

            # Require at least 50% match, prefer the highest match
            if score > best_score and score >= 0.5:
                best_match = screen_key
                best_score = score

        self._current_screen = best_match
        return best_match

    def wait_for(self, screen_key: str, timeout: float = None) -> bool:
        """Wait until the specified screen is displayed.

        Raises:
            ScreenTimeoutError: If the driver reports the screen did not
            appear within timeout (strict drivers / strict mode).
        """
        screen_def = self.screens.get(screen_key)
        if not screen_def:
            raise ValueError(f"Unknown screen: '{screen_key}'")

        identifiers = screen_def.get("identifiers", [])
        screen_name = screen_def.get("name", screen_key)
        wait_timeout = timeout or screen_def.get("timeout", 15)

        if self.logger:
            self.logger.debug(
                f"Waiting for screen: {screen_name} "
                f"(timeout: {wait_timeout}s, identifiers: {identifiers})"
            )

        if not identifiers:
            # No identifiers defined — use timing-based wait
            time.sleep(3)
            self._current_screen = screen_key
            return True

        try:
            self.driver.wait_for_screen(identifiers, timeout=wait_timeout)
            self._current_screen = screen_key
            if self.logger:
                self.logger.debug(f"Screen detected: {screen_name}")
            return True
        except ScreenTimeoutError:
            if self.logger:
                self.logger.warning(
                    f"Screen '{screen_name}' not detected within "
                    f"{wait_timeout}s"
                )
            raise ScreenTimeoutError(
                f"Expected screen '{screen_name}' did not appear "
                f"within {wait_timeout}s. Identifiers: {identifiers}",
                step=f"wait_for_{screen_key}"
            )

    def verify(self, screen_key: str) -> bool:
        """Verify the current screen matches the expected screen.
        Does NOT wait — just checks once."""
        detected = self.detect_current_screen()
        return detected == screen_key

    def assert_screen(self, screen_key: str):
        """Assert we're on the expected screen. Raise if not."""
        if not self.verify(screen_key):
            detected = self._current_screen or "unknown"
            expected_name = self.screens.get(screen_key, {}).get(
                "name", screen_key)
            raise ScreenNotRecognizedError(
                f"Expected screen '{expected_name}' but detected "
                f"'{detected}'",
                step=f"assert_{screen_key}"
            )

    def read_screen_data(self) -> str:
        """Read and return the full text content of the current screen."""
        return self.driver.get_screen_text()

    def read_bottom_line(self) -> str:
        """Read the bottom line of the terminal screen.
        This is where FINESIII displays O-0000 (success) or E-XXXX
        (error)."""
        screen_text = self.driver.get_screen_text()
        lines = screen_text.strip().split("\n")
        if lines:
            return lines[-1].strip()
        return ""

    def check_transaction_result(self) -> dict:
        """Check the bottom line of the terminal for the transaction
        result.

        Returns:
            dict with keys:
                "success": bool
                "code": str (e.g., "O-0000", "E-9901", or "UNCONFIRMED")
                "raw_line": str (the full bottom line text)
        """
        # The result code sits on the LAST line the terminal renders,
        # but an OCR-enriched read appends recognized lines after it
        # (and screens like the FID table end with the 【確認】 bar), so
        # scan bottom-up for the first line carrying a recognizable
        # code. Matching runs on a normalized copy too — OCR may render
        # Ｏ－００００ fullwidth or misread O as 0.
        from src.rpa.vision.keywords import canonical_result_code

        screen_text = self.driver.get_screen_text()
        lines = [ln.strip() for ln in screen_text.strip().split("\n")
                 if ln.strip()]

        for line in reversed(lines):
            code = canonical_result_code(line)
            if code == "O-0000":
                return {"success": True, "code": "O-0000",
                        "raw_line": line, "result_source": "screen"}
            if code:                     # E-xxxx — genuine, readable error
                return {"success": False, "code": code,
                        "raw_line": line, "result_source": "screen"}

        # IMPORTANT: on the real terminal (without OCR) the read returns
        # the window TITLE, not the result line — the body is not
        # machine-readable. Reaching here means no recognizable result
        # code was read: the "70" commit was issued deterministically,
        # so return a non-blocking "unconfirmed success" and let the
        # flow proceed to the mandatory print + logout rather than
        # falsely reporting failure. Evidence screenshots (and their
        # printed .txt mirrors) still capture the actual on-screen
        # result for audit.
        return {
            "success": True,
            "code": "UNCONFIRMED",
            "raw_line": "(result line not readable on this terminal)",
            "result_source": "unconfirmed",
        }
