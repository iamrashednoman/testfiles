"""Field mapping engine for Task 0903 account management screen.

Port of v2 core/field_mapper.py, unchanged.

Task 0903 — パスワードDBの更新と追加 (Password DB Update and Addition)

Cursor navigation: pressing Enter moves to the next input-capable
field. Display-only fields (FID 102, 103) are skipped automatically by
the terminal.

Field entry order:
  FID 100 (Processing Confirmation) → press Enter to start
  FID 101 (Processing Type) → Enter
  [102-103 skipped automatically]
  FID 104 (Management Target) → Enter
  FID 105 (Affiliation Code) → Enter
  FID 002 (Staff Code) → Enter
  FID 003 (Password) → Enter
  FID 006 (Processing Date) → Enter
  [Administrator field — skip] → Enter
  Execution field → type "00" → Enter (generates confirmation)
"""

import time
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone

from src.core.exceptions import InvalidInputError
from src.rpa.drivers.base import BaseDriver

# The mainframe works in Japan time. A fixed offset (Japan has no
# daylight saving) keeps the processing date right on a host set to
# another time zone, without depending on time-zone data being present.
JST = timezone(timedelta(hours=9))


@dataclass
class AccountData:
    """Data required for a Task 0903 operation."""
    processing_type: str        # "1"=Unlock, "2"=Create, "3"=Reset, "4"=Delete
    affiliation_code: str       # 5-digit code (will be zero-padded)
    employee_code: str          # 7-char staff code
    new_password: str = ""      # 8-char password (Create/Reset only)
    audit_target: str = "1"     # "1", but EMPTY for delete
    processing_date: str = ""   # YYMMDD format, auto-filled if empty

    def __post_init__(self):
        # Audit target is "1" for create/unlock/password-reset, but must
        # be EMPTY for delete (processing_type "4") per FINESIII
        # deprovision spec (FID 104 is left blank — the bot presses Enter
        # to advance past it).
        if not self.audit_target and self.processing_type != "4":
            self.audit_target = "1"

        # Zero-pad affiliation code to 5 digits
        if self.affiliation_code and len(self.affiliation_code) < 5:
            self.affiliation_code = self.affiliation_code.zfill(5)

        # Auto-fill processing date with today if not provided, EXCEPT
        # for delete (type "4") where the date field (FID 006) is
        # optional and left empty per spec.
        if not self.processing_date and self.processing_type != "4":
            self.processing_date = datetime.now(JST).strftime("%y%m%d")

    def validate(self):
        errors = []

        if self.processing_type not in ("1", "2", "3", "4"):
            errors.append(
                f"Processing type must be 1-4, got: "
                f"'{self.processing_type}'"
            )

        if not self.affiliation_code or len(self.affiliation_code) != 5:
            errors.append(
                f"Affiliation code must be 5 digits, got: "
                f"'{self.affiliation_code}'"
            )

        if not self.employee_code or len(self.employee_code) != 7:
            errors.append(
                f"Employee code must be 7 characters, got: "
                f"'{self.employee_code}'"
            )

        # Password required for Create (type 2) and Password Reset (3)
        if self.processing_type in ("2", "3"):
            if not self.new_password or len(self.new_password) != 8:
                errors.append(
                    f"Password must be 8 characters for Create/Reset, "
                    f"got length: {len(self.new_password or '')}"
                )
            if self.new_password and not self.new_password[0].isalpha():
                errors.append(
                    f"Password first character must be a letter, "
                    f"got: '{self.new_password[0]}'"
                )

        # Date (FID 006) is required for create/unlock/reset, but
        # OPTIONAL for delete (type "4"). If a date is provided for
        # delete, it must still be 6 digits (YYMMDD).
        if self.processing_type != "4":
            if not self.processing_date or len(self.processing_date) != 6:
                errors.append(
                    f"Processing date must be 6 digits (YYMMDD), "
                    f"got: '{self.processing_date}'"
                )
        elif self.processing_date and len(self.processing_date) != 6:
            errors.append(
                f"Processing date, if provided for delete, must be "
                f"6 digits (YYMMDD), got: '{self.processing_date}'"
            )

        if errors:
            raise InvalidInputError(
                "Account data validation failed:\n" +
                "\n".join(f"  - {e}" for e in errors),
                step="validate_account_data"
            )

    def to_log_safe_dict(self) -> dict:
        return {
            "processing_type": self.processing_type,
            "affiliation_code": self.affiliation_code,
            "employee_code": self.employee_code,
            "new_password": "****" if self.new_password else "(none)",
            "audit_target": self.audit_target,
            "processing_date": self.processing_date,
        }


# Field entry order on Task 0903 — Enter-based navigation.
# Cursor moves to the next input field when Enter is pressed.
# Display-only fields (102, 103) are skipped automatically.
FIELD_ORDER = [
    ("processing_type", 101, "008"),
    ("audit_target", 104, "004"),
    ("affiliation_code", 105, "005"),
    ("employee_code", 106, "002"),
    ("new_password", 107, "003"),
    ("processing_date", 108, "006"),
]


class FieldMapper:
    """Handles data entry on the Task 0903 account management screen."""

    def __init__(self, driver: BaseDriver, fields_config: dict,
                 timing_config: dict, logger=None):
        self.driver = driver
        self.fields = fields_config
        self.timing = timing_config
        self.logger = logger

    def enter_account_data(self, data: AccountData):
        """Enter all field values on Task 0903.
        Cursor starts at FID 100 — press Enter first to advance to
        FID 101. Then Enter between each subsequent field."""
        if self.logger:
            self.logger.step_start("Enter account data on Task 0903")
            self.logger.info(f"Data: {data.to_log_safe_dict()}")

        data.validate()

        field_delay = self.timing.get("field_entry_delay", 0.3)

        # FID 100: cursor starts here. Press Enter to advance to FID 101.
        if self.logger:
            self.logger.info(
                "FID 100 (Processing Confirmation) — pressing Enter "
                "to start")
        self.driver.press_key("enter")
        time.sleep(field_delay)

        for field_name, field_num, fid in FIELD_ORDER:
            value = getattr(data, field_name, "")

            if not value:
                # Skip empty fields — press Enter to advance past
                if self.logger:
                    self.logger.debug(
                        f"Skipping field {field_num} ({field_name}) — "
                        f"empty, pressing Enter"
                    )
                self.driver.press_key("enter")
                time.sleep(0.1)
                continue

            if self.logger:
                log_value = ("****" if field_name == "new_password"
                             else value)
                self.logger.info(
                    f"Entering field {field_num} ({field_name}): "
                    f"{log_value}"
                )

            self.driver.type_text(value)
            time.sleep(field_delay)

            self.driver.press_key("enter")
            time.sleep(0.1)

        # Skip Administrator field (optional) — press Enter to advance
        if self.logger:
            self.logger.info(
                "Skipping Administrator field (optional) — pressing Enter")
        self.driver.press_key("enter")
        time.sleep(field_delay)

        if self.logger:
            self.logger.step_success("Enter account data on Task 0903")

    @staticmethod
    def build_create_data(affiliation_code: str, employee_code: str,
                          password: str,
                          processing_date: str = "") -> AccountData:
        return AccountData(
            processing_type="2",
            affiliation_code=affiliation_code,
            employee_code=employee_code,
            new_password=password,
            audit_target="1",
            processing_date=processing_date
        )

    @staticmethod
    def build_delete_data(affiliation_code: str,
                          employee_code: str,
                          processing_date: str = "") -> AccountData:
        return AccountData(
            processing_type="4",
            affiliation_code=affiliation_code,
            employee_code=employee_code,
            new_password="",
            audit_target="",   # FID 104 must be EMPTY for delete per spec
            processing_date=processing_date
        )

    @staticmethod
    def build_unlock_data(affiliation_code: str,
                          employee_code: str,
                          processing_date: str = "") -> AccountData:
        return AccountData(
            processing_type="1",
            affiliation_code=affiliation_code,
            employee_code=employee_code,
            new_password="",
            audit_target="1",
            processing_date=processing_date
        )

    @staticmethod
    def build_password_reset_data(affiliation_code: str,
                                  employee_code: str,
                                  password: str,
                                  processing_date: str = "") -> AccountData:
        return AccountData(
            processing_type="3",
            affiliation_code=affiliation_code,
            employee_code=employee_code,
            new_password=password,
            audit_target="1",
            processing_date=processing_date
        )
