"""Dual-engine database access (SQLite / PostgreSQL).

Port of v2 service/db.py, kept deliberately ORM-free per the approved
data-layer decision (dataclasses + explicit SQL). SQLite is the
zero-dependency dev/test engine; PostgreSQL is the production engine
(connection pool, dict rows, FOR UPDATE SKIP LOCKED for job claiming).

Credentials are env-only: DATABASE_URL (or the config value, which
itself defaults from the environment). Never placed in YAML/code.
"""
from __future__ import annotations

import sqlite3
import threading
from contextlib import contextmanager


class Database:
    """Thin engine wrapper. All SQL uses '?' placeholders; they are
    translated to '%s' for postgres. Our queries never contain literal
    '?' characters — keep it that way."""

    def __init__(self, engine: str, sqlite_path: str = "",
                 pg_url: str = "", pool_size: int = 10):
        if engine not in ("sqlite", "postgres"):
            raise ValueError(f"Unknown database engine: {engine!r}")
        self.engine = engine
        self.sqlite_path = sqlite_path
        self._pg_url = pg_url
        self._pool = None
        self._lock = threading.Lock()
        if engine == "postgres":
            from psycopg_pool import ConnectionPool
            from psycopg.rows import dict_row
            self._pool = ConnectionPool(
                pg_url, min_size=1, max_size=pool_size,
                kwargs={"row_factory": dict_row}, open=True,
            )

    @classmethod
    def from_config(cls, cfg) -> "Database":
        return cls(
            engine=cfg.database_engine,
            sqlite_path=cfg.sqlite_path,
            pg_url=cfg.database_url,
            pool_size=cfg.db_pool_size,
        )

    @property
    def dequeue_lock_clause(self) -> str:
        """Row-claim clause for multi-process safety (postgres only)."""
        return " FOR UPDATE SKIP LOCKED" if self.engine == "postgres" else ""

    @contextmanager
    def connect(self):
        """Yield a connection wrapper with execute/fetchall/fetchone.
        Commits on success, rolls back on exception, always closes/returns."""
        if self.engine == "sqlite":
            conn = sqlite3.connect(self.sqlite_path, timeout=30)
            conn.row_factory = sqlite3.Row
            try:
                yield _SqliteConn(conn)
                conn.commit()
            except Exception:
                conn.rollback()
                raise
            finally:
                conn.close()
        else:
            with self._pool.connection() as conn:
                yield _PgConn(conn)

    # ── One-shot helpers ──

    def fetchall(self, sql: str, params: tuple = ()) -> list[dict]:
        with self.connect() as conn:
            return conn.fetchall(sql, params)

    def fetchone(self, sql: str, params: tuple = ()) -> dict | None:
        with self.connect() as conn:
            return conn.fetchone(sql, params)

    def execute(self, sql: str, params: tuple = ()) -> int:
        with self.connect() as conn:
            return conn.execute(sql, params)

    def table_exists(self, name: str) -> bool:
        """Engine-appropriate existence check. The stores use this to
        skip their bootstrap DDL when the schema was applied by the
        database admin (scripts/schema.sql) — in that deployment the
        service role deliberately does NOT own the tables (append-only
        enforcement), and even no-op CREATE ... IF NOT EXISTS statements
        fail Postgres's ownership check."""
        if self.engine == "postgres":
            row = self.fetchone(
                "SELECT to_regclass(?) AS t", (f"public.{name}",))
            return bool(row and row["t"])
        row = self.fetchone(
            "SELECT name FROM sqlite_master "
            "WHERE type='table' AND name=?", (name,))
        return row is not None

    def close(self) -> None:
        if self._pool is not None:
            self._pool.close()


class IntegrityError(Exception):
    """Engine-neutral uniqueness violation (idempotency race guard)."""


class _SqliteConn:
    def __init__(self, conn: sqlite3.Connection):
        self._conn = conn
        self._conn.execute("PRAGMA journal_mode=WAL")

    def execute(self, sql: str, params: tuple = ()) -> int:
        try:
            cur = self._conn.execute(sql, params)
        except sqlite3.IntegrityError as e:
            raise IntegrityError(str(e)) from e
        return cur.rowcount

    def fetchall(self, sql: str, params: tuple = ()) -> list[dict]:
        cur = self._conn.execute(sql, params)
        return [dict(r) for r in cur.fetchall()]

    def fetchone(self, sql: str, params: tuple = ()) -> dict | None:
        cur = self._conn.execute(sql, params)
        row = cur.fetchone()
        return dict(row) if row is not None else None


class _PgConn:
    def __init__(self, conn):
        self._conn = conn

    @staticmethod
    def _translate(sql: str) -> str:
        return sql.replace("?", "%s")

    def execute(self, sql: str, params: tuple = ()) -> int:
        import psycopg
        try:
            cur = self._conn.execute(self._translate(sql), params)
        except psycopg.errors.UniqueViolation as e:
            raise IntegrityError(str(e)) from e
        return cur.rowcount

    def fetchall(self, sql: str, params: tuple = ()) -> list[dict]:
        cur = self._conn.execute(self._translate(sql), params)
        return list(cur.fetchall())

    def fetchone(self, sql: str, params: tuple = ()) -> dict | None:
        cur = self._conn.execute(self._translate(sql), params)
        return cur.fetchone()
