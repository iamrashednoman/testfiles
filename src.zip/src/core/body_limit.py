"""Size limit on request bodies (X-09, 2026-10-03).

A request body is read before the sign-in of the caller is checked, so
without a limit anyone who can reach the service could make it read an
arbitrarily large upload. Branding images are the only large bodies the
console sends; everything else is small. The limits are well above what
the application itself accepts (request metadata, for example, is
refused above 64 KB with its own message).
"""
from __future__ import annotations

from starlette.exceptions import HTTPException
from starlette.responses import JSONResponse

DEFAULT_LIMIT = 256 * 1024
# Path prefix → limit. Branding images: about 1.2 MB in total, sent as
# base64 (one third larger).
PATH_LIMITS = {"/api/v1/console/branding": 2 * 1024 * 1024}


def _text(limit: int) -> str:
    size = (f"{limit // (1024 * 1024)} MB" if limit >= 1024 * 1024
            else f"{limit // 1024} KB")
    return f"The request is too large (at most {size} here)."


class BodySizeLimit:
    """Pure ASGI middleware: refuses a body over the limit with 413,
    from the declared length when there is one, else while it is read."""

    def __init__(self, app, default_limit: int = DEFAULT_LIMIT,
                 path_limits: dict | None = None):
        self.app = app
        self.default_limit = default_limit
        self.path_limits = dict(PATH_LIMITS if path_limits is None
                                else path_limits)

    def limit_for(self, path: str) -> int:
        for prefix, limit in self.path_limits.items():
            if path.startswith(prefix):
                return limit
        return self.default_limit

    async def __call__(self, scope, receive, send):
        if scope.get("type") != "http":
            return await self.app(scope, receive, send)
        limit = self.limit_for(scope.get("path", ""))
        for name, value in scope.get("headers") or []:
            if name == b"content-length":
                try:
                    declared = int(value)
                except ValueError:
                    declared = 0
                if declared > limit:
                    response = JSONResponse({"detail": _text(limit)},
                                            status_code=413)
                    return await response(scope, receive, send)
                break
        received = 0

        async def limited_receive():
            nonlocal received
            message = await receive()
            if message.get("type") == "http.request":
                received += len(message.get("body", b""))
                if received > limit:
                    # Turned into a 413 answer by the exception handling
                    # of the application, like any other HTTP error.
                    raise HTTPException(status_code=413,
                                        detail=_text(limit))
            return message

        return await self.app(scope, limited_receive, send)
