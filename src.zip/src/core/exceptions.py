"""Enterprise-wide exception taxonomy.

The central contract of the platform's fault tolerance: every failure is
classified as BUSINESS (the request is wrong — never retry, a human must
act) or SYSTEM (the environment failed — retry with backoff, then
dead-letter). src/core/retry.py consumes this classification; workflows
and integrations only raise, they never decide retry behavior.

Ports from v2: implicit error handling in workflows/ and service/
dispatcher.py, made explicit and typed.
"""
from __future__ import annotations


class FinesRpaError(Exception):
    """Root of all platform exceptions. Carries a stable machine code
    for the API problem-details payload and the audit trail.

    `step` and `details` are the v2 call convention used throughout the
    ported rpa layer (workflows/drivers raise with the failing workflow
    step attached); they fold into the same detail payload.
    """

    code: str = "RPA_ERROR"

    def __init__(self, message: str, *, detail: dict | None = None,
                 step: str = "", details: dict | None = None) -> None:
        super().__init__(message)
        self.detail = {**(detail or {}), **(details or {})}
        self.step = step
        if step:
            self.detail.setdefault("step", step)


# ── Business exceptions — terminal, never retried ──────────────────

class BusinessException(FinesRpaError):
    code = "BUSINESS_ERROR"


class ValidationError(BusinessException):
    """Request data malformed (agency code, employee id, operation)."""
    code = "VALIDATION_ERROR"


class DuplicateAccountError(BusinessException):
    """Create requested but the Application ID already exists (precondition
    check on the inquiry screen failed)."""
    code = "DUPLICATE_ACCOUNT"


class AccountNotFoundError(BusinessException):
    """Delete/Unlock/Reset requested but the Application ID does not exist."""
    code = "ACCOUNT_NOT_FOUND"


class DuplicateRequestError(BusinessException):
    """Idempotency-key replay of an already-processed request."""
    code = "DUPLICATE_REQUEST"


class InvalidInputError(BusinessException):
    """Account data failed field-level validation before entry
    (wrong length, missing field). Raised by AccountData.validate()."""
    code = "INVALID_INPUT"


class ConfirmationMismatchError(BusinessException):
    """Data on the confirmation screen doesn't match what was entered —
    the workflow cancels with '99' before any commit."""
    code = "CONFIRMATION_MISMATCH"


# ── System exceptions — retryable per policy ───────────────────────

class SystemException(FinesRpaError):
    code = "SYSTEM_ERROR"


class TerminalConnectionError(SystemException):
    """Emulator cannot reach the FINESIII mainframe."""
    code = "TERMINAL_CONNECTION"


class EmulatorError(SystemException):
    """Emulator process crashed, hung, or window not found."""
    code = "EMULATOR_FAILURE"


class ScreenDesyncError(SystemException):
    """Observed screen does not match the expected state within timeout —
    the state machine's recovery ladder handles this before it escapes."""
    code = "SCREEN_DESYNC"


class PostconditionUnverifiedError(SystemException):
    """Operation was submitted but the post-condition inquiry could not
    confirm the result. NEVER auto-retried blindly: the recovery path
    must re-inquire before any replay to avoid duplicate execution."""
    code = "POSTCONDITION_UNVERIFIED"


class ConfirmationUnverifiableError(SystemException):
    """The confirmation screen body could not be read while a readable
    confirmation is required — cancelled with '99' before any commit,
    so the request can safely be tried again."""
    code = "CONFIRMATION_UNVERIFIABLE"


class CredentialRetrievalError(SystemException):
    """CyberArk CCP unavailable or refused the request."""
    code = "CREDENTIAL_RETRIEVAL"


class IntegrationError(SystemException):
    """Outbound adapter failure (ServiceNow write-back, SMTP, SailPoint)."""
    code = "INTEGRATION_ERROR"


class ApplicationLaunchError(SystemException):
    """Failed to launch or attach to the terminal emulator."""
    code = "APPLICATION_LAUNCH"


class ScreenTimeoutError(SystemException):
    """Expected screen did not appear within timeout."""
    code = "SCREEN_TIMEOUT"


class ScreenNotRecognizedError(SystemException):
    """Current screen doesn't match any known screen definition."""
    code = "SCREEN_NOT_RECOGNIZED"


class LoginFailedError(SystemException):
    """FINESIII login failed (bad credentials or session issue)."""
    code = "LOGIN_FAILED"


class NavigationError(SystemException):
    """Failed to navigate to the expected screen."""
    code = "NAVIGATION_ERROR"


class EnvironmentUnavailableError(SystemException):
    """Development environment is down or was shut down externally."""
    code = "ENVIRONMENT_UNAVAILABLE"


class JournalFreezeError(SystemException):
    """Screen froze due to journal activation (too many rapid
    entries)."""
    code = "JOURNAL_FREEZE"


class DriverError(SystemException):
    """The automation driver encountered an error."""
    code = "DRIVER_ERROR"


# ── Security exceptions — terminal, alerting ───────────────────────

class SecurityException(FinesRpaError):
    """Auth failures, scope violations, tamper indications. Never retried,
    always audited, always alerted."""
    code = "SECURITY_ERROR"
