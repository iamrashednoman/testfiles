"""Browser security headers on every response (SEC-04, 2026-10-04).

Pure ASGI middleware, like BodySizeLimit and ConsoleSessionCookie: it
only adds headers to the response start, so no route changes.

  Content-Security-Policy   the console runs only its own scripts (no
                            inline script, no other site), cannot be
                            shown inside another site's frame, and
                            talks only to this service
  X-Frame-Options           the same for older browsers
  X-Content-Type-Options    a file is never read as another type
  Referrer-Policy           no address is passed on to another site
  Cache-Control: no-store   API answers (evidence images, settings,
                            exports) are not kept in the browser cache;
                            an answer that sets its own value keeps it

The API description pages (/api/docs, /redoc), served on a
development service only, load their page from a public CDN, so they
get no Content-Security-Policy.
"""
from __future__ import annotations

# Styles: the page sets a few style attributes, so inline styles are
# allowed; scripts are not. Images: the Branding page previews uploaded
# images (data:) and evidence images are shown from memory (blob:).
CONTENT_SECURITY_POLICY = (
    "default-src 'self'; "
    "script-src 'self'; "
    "style-src 'self' 'unsafe-inline'; "
    "img-src 'self' data: blob:; "
    "font-src 'self' data:; "
    "connect-src 'self'; "
    "object-src 'none'; "
    "base-uri 'self'; "
    "form-action 'self'; "
    "frame-ancestors 'none'"
)

_ALWAYS = (
    (b"x-content-type-options", b"nosniff"),
    (b"referrer-policy", b"no-referrer"),
    (b"x-frame-options", b"DENY"),
)
_DOCS_PATHS = ("/api/docs", "/redoc", "/openapi.json")


class SecurityHeaders:
    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            return await self.app(scope, receive, send)
        path = scope.get("path", "") or ""
        with_csp = not path.startswith(_DOCS_PATHS)
        api = path.startswith("/api/")

        async def send_with_headers(message):
            if message["type"] == "http.response.start":
                headers = list(message.get("headers") or [])
                present = {k.lower() for k, _ in headers}
                for name, value in _ALWAYS:
                    if name not in present:
                        headers.append((name, value))
                if with_csp and b"content-security-policy" not in present:
                    headers.append((b"content-security-policy",
                                    CONTENT_SECURITY_POLICY.encode()))
                if api and b"cache-control" not in present:
                    headers.append((b"cache-control", b"no-store"))
                message = dict(message, headers=headers)
            await send(message)

        return await self.app(scope, receive, send_with_headers)
