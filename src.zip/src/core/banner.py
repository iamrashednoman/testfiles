"""The console banner shown when the service starts.

One copy for every way of starting the service — run.py, the background
agent (--agent) and the headless mode (--headless) — so the operator
always sees the same welcome and the same summary of what is running.
"""
from __future__ import annotations

import os
import re

RULE = "=" * 61

WELCOME = r"""
 Welcome to
  _____  ___  _   _  _____  ____   ___  ___  ___     ____    ___   _____
 |  ___||_ _|| \ | || ____|/ ___| |_ _||_ _||_ _|   | __ )  / _ \ |_   _|
 | |_    | | |  \| ||  _|  \___ \  | |  | |  | |    |  _ \ | | | |  | |
 |  _|   | | | |\  || |___  ___) | | |  | |  | |    | |_) || |_| |  | |
 |_|    |___||_| \_||_____||____/ |___||___||___|   |____/  \___/   |_|
"""

DRIVER_LABELS = {
    "simulator": "simulator (canned executor, no UI — fastest)",
    "mock": "mock (full rpa stack, headless)",
    "sim_terminal": "sim_terminal (visible target-app window per request)",
    "pywinauto": "pywinauto (REAL terminal, Windows)",
    "pyautogui": "pyautogui (REAL terminal fallback, Windows)",
    "tn3270": "tn3270 (direct terminal protocol)",
}


def mask_db_url(url: str) -> str:
    """postgresql://user:secret@host/db -> postgresql://user:***@host/db"""
    return re.sub(r"(://[^:/@]+:)[^@]+@", r"\1***@", url or "")


def error_rules(cfg) -> str:
    """Which error catalogue is live, and its content hash — compliance
    must be able to prove WHICH rule set handled a given transaction."""
    if not getattr(cfg, "error_handling_enabled", True):
        return "disabled"
    try:
        from src.rpa.vision.error_catalog import ErrorCatalog
        # Strict here too: the banner should name the problem BEFORE
        # the [FATAL] that follows, not report a misleading "0 rules".
        catalog = ErrorCatalog.load(cfg.error_catalog_path, strict=True)
    except Exception as e:
        return f"INVALID — {e}"
    if not len(catalog):
        return f"none defined ({cfg.error_catalog_path})"
    return (f"{len(catalog)} from {cfg.error_catalog_path} "
            f"(sha {catalog.digest})")


def environment_name() -> str:
    """The environment in force (the deployment file may set it)."""
    try:
        from config import _app_env
        return _app_env() or "development"
    except Exception:
        return os.environ.get("APP_ENV", "development")


# ── One-line start-up errors (NB-005) ──
# A database that cannot be reached used to end every start with a long
# trace. The line names the address, the reason and where to correct it.

_DB_ERROR_TYPES = ("PoolTimeout", "OperationalError", "InterfaceError")


def is_database_error(exc) -> bool:
    """The database could not be reached or opened (the exception or one
    it was raised from)."""
    seen = 0
    while exc is not None and seen < 5:
        if type(exc).__name__ in _DB_ERROR_TYPES \
                or isinstance(exc, ConnectionError) \
                or "connection" in str(exc).lower():
            return True
        exc = exc.__cause__ or exc.__context__
        seen += 1
    return False


def _first_line(exc) -> str:
    text = str(exc).strip()
    return (text.splitlines()[0].strip() if text
            else type(exc).__name__).rstrip(".")


def _setting_location(key: str) -> str:
    """Where `key` is set: the process environment, a .env in the
    working directory (read before finesiii.env), or finesiii.env in the
    data folder."""
    if key in os.environ:
        return f"the {key} environment variable"
    try:
        from dotenv import dotenv_values
        if os.path.isfile(".env") and any(
                k.upper() == key for k in dotenv_values(".env")):
            return f"{key} in {os.path.abspath('.env')}"
    except Exception:
        pass
    try:
        from config.base import DEPLOYMENT_ENV_FILE
        from src.core.app_paths import data_path
        return f"{key} in {data_path(DEPLOYMENT_ENV_FILE)}"
    except Exception:
        return f"{key} in finesiii.env"


def database_unreachable_line(cfg, detail: str) -> str:
    """The database of `cfg` cannot be reached: one line with the
    address (password masked), the reason and how to correct it."""
    if getattr(cfg, "database_engine", "") == "sqlite":
        target, key = str(getattr(cfg, "sqlite_path", "")), "SQLITE_PATH"
    else:
        target = mask_db_url(getattr(cfg, "database_url", ""))
        key = "DATABASE_URL"
    where = _setting_location(key)
    example = ("" if where.startswith("the ") else
               " — for example with desktop\\app.py --configure --db-url "
               "postgresql://user@host:5432/database —")
    return (f"The database cannot be reached ({target}): "
            f"{mask_db_url(str(detail or '').rstrip('.'))}. Correct {where} "
            f"(or DATABASE_ENGINE){example or ','} then start again.")


def startup_error_line(exc, cfg) -> str:
    """A start-up failure as one line, without a trace: the database
    line above for a database that cannot be reached, otherwise the
    first line of the error."""
    if cfg is not None and is_database_error(exc):
        return database_unreachable_line(cfg, _first_line(exc))
    return _first_line(exc)


def print_banner(cfg, title: str = "service starting",
                 extra: list[tuple[str, str]] | None = None) -> None:
    """The welcome art and the summary of what this start will run."""
    db = (f"sqlite — {cfg.sqlite_path}"
          if cfg.database_engine == "sqlite"
          else f"postgres — {mask_db_url(cfg.database_url)}")
    print(WELCOME)
    print(RULE)
    print(f" FINESIII RPA v3 — {title}")
    print(RULE)
    print(f" Environment : {environment_name()} ({type(cfg).__name__})")
    print(f" Driver      : "
          f"{DRIVER_LABELS.get(cfg.terminal_driver, cfg.terminal_driver)}")
    print(f" Database    : {db}")
    print(f" Dispatcher  : "
          f"{'enabled' if cfg.dispatcher_enabled else 'DISABLED (API-only)'}")
    print(f" Audit trail : "
          f"{'enabled' if cfg.audit_enabled else 'disabled'}")
    print(f" OCR         : "
          f"{'enabled' if cfg.ocr_enabled else 'disabled'}")
    print(f" Error rules : {error_rules(cfg)}")
    for label, value in extra or []:
        print(f" {label:<12}: {value}")
    print(RULE, flush=True)
