"""Path resolution that works from source AND from a frozen bundle.

PyInstaller unpacks read-only assets into a temporary _MEIPASS folder
that is deleted when the process exits, and a double-clicked app has an
unpredictable working directory. Both facts break the same assumption:
that a relative path like "evidence" or a `__file__`-derived one points
somewhere stable and writable.

Three kinds of path, deliberately kept separate:

  resource_path()  read-only assets shipped INSIDE the bundle — screen
                   layouts, email templates, OCR models. Never written.
  data_path()      writable per-user state — evidence, logs, databases,
                   the audit spool.
  config_path()    admin-editable YAML. Frozen, these are SEEDED into
                   the data dir on first run so an upgrade cannot
                   clobber an operator's edits; from source they stay
                   in the repo's config/ exactly as before.

Contract: when NOT frozen, every helper resolves to the same location
the code used before this module existed (repo root for resources and
config, cwd for data). Running from source, in Docker, and under pytest
is therefore byte-for-byte unchanged.
"""
from __future__ import annotations

import os
import shutil
import sys
from pathlib import Path

APP_NAME = "FINESIII-RPA"

# Repo root when running from source: src/core/app_paths.py -> ../../
_REPO_ROOT = Path(__file__).resolve().parents[2]

# Editable configs seeded into the writable data dir on first run.
SEED_CONFIGS = ("errors.yaml", "ocr.yaml", "notifications.yaml",
                "email_messages.yaml",       # e-mail wording (2026-09-29)
                "cyberark.yaml", "servicenow.yaml", "servicenow_e2e.yaml",
                # client-owned e-mail templates (2026-09-28)
                "email_templates/support_report.txt",
                "email_templates/user_registration.txt",
                "email_templates/user_password.txt")


def is_frozen() -> bool:
    """True when running from a PyInstaller bundle."""
    return bool(getattr(sys, "frozen", False))


# ── Read-only bundled assets ──

def resource_root() -> Path:
    """Where read-only assets live. Frozen: the _MEIPASS unpack dir.
    From source: the repo root. Never write here."""
    if is_frozen():
        return Path(getattr(sys, "_MEIPASS", Path(sys.executable).parent))
    return _REPO_ROOT


def resource_path(*parts) -> Path:
    return resource_root().joinpath(*parts)


# ── Writable per-user data ──

def data_root() -> Path:
    """Writable state: evidence, logs, databases, the audit spool.

    FINESIII_DATA_DIR overrides everywhere (used by tests and by
    operators who want state on a specific volume).

    Windows  %LOCALAPPDATA%\\FINESIII-RPA
    macOS    ~/Library/Application Support/FINESIII-RPA
    Linux    $XDG_DATA_HOME/finesiii-rpa  (or ~/.local/share/...)

    From source this is the CURRENT WORKING DIRECTORY, which is what
    every relative default resolved against before — so behaviour is
    unchanged for `python run.py`, Docker, and pytest.
    """
    override = os.environ.get("FINESIII_DATA_DIR")
    if override:
        return Path(override).expanduser().resolve()
    if not is_frozen():
        return Path.cwd()
    if sys.platform == "win32":
        base = Path(os.environ.get("LOCALAPPDATA",
                                   Path.home() / "AppData" / "Local"))
        return base / APP_NAME
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / APP_NAME
    base = Path(os.environ.get("XDG_DATA_HOME",
                               Path.home() / ".local" / "share"))
    return base / APP_NAME.lower()


def data_path(*parts) -> Path:
    return data_root().joinpath(*parts)


# ── Admin-editable configuration ──

def config_root() -> Path:
    """Where the editable YAML configs are READ from.

    Frozen: the seeded copy under the data dir, so operator edits
    survive an upgrade. From source: the repo's config/ directory.
    """
    return data_path("config") if is_frozen() else _REPO_ROOT / "config"


def config_path(name: str) -> Path:
    return config_root() / name


def resolve(value: str | os.PathLike, *, kind: str = "data") -> str:
    """Make one configured path absolute against the right root.

    An absolute value is returned unchanged — an explicit setting from
    the environment always wins. kind: data | config | resource.

    For kind="config" a leading "config/" segment is dropped first, so
    the historical setting form ("config/errors.yaml") and the bare
    filename ("errors.yaml") both land in the config root instead of
    producing config/config/errors.yaml.
    """
    if not value:
        return str(value)
    path = Path(value).expanduser()
    if path.is_absolute():
        return str(path)
    if kind == "config" and path.parts and path.parts[0] == "config":
        path = Path(*path.parts[1:]) if len(path.parts) > 1 else path
    roots = {"data": data_root, "config": config_root,
             "resource": resource_root}
    return str(roots[kind]().joinpath(path))


# ── First-run bootstrap ──

def bootstrap_data_dir() -> Path:
    """Create the writable tree and seed the editable configs.

    Idempotent, and an existing config is NEVER overwritten, so an
    operator's edits survive upgrades. No-op from source: the repo
    already has both directories.
    """
    root = data_root()
    if not is_frozen():
        return root

    for sub in ("", "config", "evidence", "logs"):
        (root / sub).mkdir(parents=True, exist_ok=True)

    bundled = resource_path("config")
    if bundled.is_dir():
        for name in SEED_CONFIGS:
            src, dst = bundled / name, root / "config" / name
            if src.is_file() and not dst.exists():
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, dst)
    return root
