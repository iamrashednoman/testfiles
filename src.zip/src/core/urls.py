"""Web addresses the service signs in to (2026-10-03, X-07 / CA-01).

The ServiceNow instance, its OAuth token address and the CyberArk vault
receive stored passwords and secrets. They must be https and a plain
host: no user name or password inside the address, no query and no
fragment. Plain http is accepted for this machine only (127.0.0.1,
localhost, ::1), where the ServiceNow stand-in runs during testing.
"""
from __future__ import annotations

from urllib.parse import urlsplit

LOOPBACK_HOSTS = {"127.0.0.1", "localhost", "::1"}


def web_address_problem(url, *, path_allowed: bool = True) -> str:
    """Why `url` may not be used ('' when it may). A blank value is not
    a problem here: whether a value is required is checked elsewhere."""
    text = str(url or "").strip()
    if not text:
        return ""
    if any(c.isspace() for c in text):
        return "must not contain spaces"
    try:
        parts = urlsplit(text)
        host = (parts.hostname or "").lower()
        parts.port                          # a bad port raises here
    except ValueError:
        return "is not a valid address"
    if parts.scheme not in ("https", "http") or not host:
        return "must be an address such as https://host.example.com"
    if parts.scheme == "http" and host not in LOOPBACK_HOSTS:
        return ("must start with https:// (plain http:// is accepted only "
                "for this machine)")
    if "@" in parts.netloc:
        return "must not contain a user name or password"
    if "?" in text or "#" in text:
        return "must not contain ? or #"
    if not path_allowed and parts.path not in ("", "/"):
        return "must be the address of the instance only, without a path"
    return ""
