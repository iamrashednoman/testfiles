"""Transaction-aware structured logging.

Port of v2 utils/logger.py with one approved fix: step markers are
plain ASCII ("[OK]" / "[NG]" / ">>" / "===") instead of the ▶ ✓ ✗ ═
glyphs, which raised UnicodeEncodeError and crashed the bot on cp932
(Japanese Windows) consoles.

Tags every message with a transaction ID and step context for
enterprise monitoring and audit compliance.
"""

import logging
import logging.handlers
import sys
from datetime import datetime
from pathlib import Path


SERVICE_LOGGER = "finesiii_rpa_v3"
_SERVICE_HANDLER_TAG = "_finesiii_service_file"
# Days of service log kept (SY-02, 2026-10-03): one file per day, the
# older ones deleted. The log holds employee and affiliation codes.
DEFAULT_LOG_RETENTION_DAYS = 30


def attach_service_log(log_dir, log_file: str = "finesiii_rpa_v3.log",
                       level: str = "INFO",
                       retention_days: int = DEFAULT_LOG_RETENTION_DAYS):
    """Write the CONTROL PLANE's messages to the service log file too.

    The file handler used to sit only on the RPA logger
    ("finesiii_rpa_v3.rpa", propagate off), so everything the service
    itself reported — ServiceNow polls, OAuth grants, skipped tickets,
    close-out retries, CyberArk, settings — never reached the file or
    the diagnostics bundle (SN-08). Same file, same format.

    Idempotent: one handler per file, replaced when the path changes
    (a restart with another data directory). Never raises.
    """
    try:
        path = Path(log_dir)
        path.mkdir(parents=True, exist_ok=True)
        target = str((path / log_file).resolve())
        logger = logging.getLogger(SERVICE_LOGGER)
        for handler in list(logger.handlers):
            if getattr(handler, _SERVICE_HANDLER_TAG, False):
                if getattr(handler, "baseFilename", "") == target:
                    # The retention set on the console applies at the
                    # next rebuild of the service.
                    if hasattr(handler, "backupCount") and retention_days:
                        handler.backupCount = max(1, int(retention_days))
                    return handler
                logger.removeHandler(handler)
                handler.close()
        # A new file every midnight; the last `retention_days` days are
        # kept as finesiii_rpa_v3.log.YYYY-MM-DD (SY-02, 2026-10-03).
        handler = logging.handlers.TimedRotatingFileHandler(
            target, when="midnight", backupCount=max(1, int(
                retention_days or DEFAULT_LOG_RETENTION_DAYS)),
            encoding="utf-8")
        setattr(handler, _SERVICE_HANDLER_TAG, True)
        handler.setLevel(getattr(logging, str(level).upper(), logging.INFO))
        handler.setFormatter(logging.Formatter(
            "%(asctime)s | %(levelname)-8s | %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S"))
        logger.addHandler(handler)
        if logger.level == logging.NOTSET or logger.level > handler.level:
            logger.setLevel(handler.level)
        return handler
    except Exception:
        return None


class TransactionLogger:
    """Logger that tags every message with a transaction ID and step
    context."""

    def __init__(self, config: dict):
        self.log_dir = Path(config.get("log_dir", "logs"))
        self.log_dir.mkdir(parents=True, exist_ok=True)

        self.log_file = self.log_dir / config.get(
            "log_file", "finesiii_rpa_v3.log")
        self.level = getattr(logging,
                             config.get("level", "INFO").upper())
        self.console_output = config.get("console_output", True)

        self.transaction_id = None
        self.current_step = None

        self.logger = logging.getLogger("finesiii_rpa_v3.rpa")
        self.logger.setLevel(self.level)
        self.logger.handlers.clear()
        self.logger.propagate = False

        # File handler — always. The SAME handler as the service log
        # (2026-10-03, SY-02): one open file, so the daily rotation can
        # rename it (Windows refuses while a second handle is open).
        fh = attach_service_log(self.log_dir, self.log_file.name,
                                config.get("level", "INFO"),
                                config.get("retention_days",
                                           DEFAULT_LOG_RETENTION_DAYS))
        if fh is None:
            fh = logging.FileHandler(self.log_file, encoding="utf-8")
            fh.setFormatter(logging.Formatter(
                "%(asctime)s | %(levelname)-8s | %(message)s",
                datefmt="%Y-%m-%d %H:%M:%S"))
            fh.setLevel(self.level)
        self.logger.addHandler(fh)

        # Console handler — optional
        if self.console_output:
            console_fmt = logging.Formatter(
                "%(asctime)s | %(levelname)-8s | %(message)s",
                datefmt="%H:%M:%S"
            )
            ch = logging.StreamHandler(sys.stdout)
            ch.setLevel(self.level)
            ch.setFormatter(console_fmt)
            self.logger.addHandler(ch)

    def set_transaction(self, transaction_id: str):
        """Set the current transaction context."""
        self.transaction_id = transaction_id

    def set_step(self, step: str):
        """Set the current workflow step for log tagging."""
        self.current_step = step

    def _format(self, message: str) -> str:
        """Prefix message with transaction ID and step."""
        parts = []
        if self.transaction_id:
            parts.append(f"TXN={self.transaction_id}")
        if self.current_step:
            parts.append(f"STEP={self.current_step}")
        prefix = " | ".join(parts)
        return f"{prefix} | {message}" if prefix else message

    def info(self, message: str):
        self.logger.info(self._format(message))

    def debug(self, message: str):
        self.logger.debug(self._format(message))

    def warning(self, message: str):
        self.logger.warning(self._format(message))

    def error(self, message: str):
        self.logger.error(self._format(message))

    def critical(self, message: str):
        self.logger.critical(self._format(message))

    def step_start(self, step_name: str):
        """Log the beginning of a workflow step."""
        self.set_step(step_name)
        self.info(f">> Starting: {step_name}")

    def step_success(self, step_name: str = None):
        """Log successful completion of a workflow step."""
        name = step_name or self.current_step
        self.info(f"[OK] Completed: {name}")

    def step_failed(self, step_name: str = None, error: str = ""):
        """Log failure of a workflow step."""
        name = step_name or self.current_step
        self.error(f"[NG] Failed: {name} — {error}")

    def transaction_start(self, operation: str, details: dict = None):
        """Log the start of a transaction. Returns the transaction id."""
        txn_id = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.set_transaction(txn_id)
        detail_str = f" | {details}" if details else ""
        self.info(f"=== Transaction START: {operation}{detail_str} ===")
        return txn_id

    def transaction_success(self, operation: str):
        """Log successful transaction completion."""
        self.info(f"=== Transaction SUCCESS: {operation} ===")

    def transaction_failed(self, operation: str, error: str):
        """Log transaction failure."""
        self.error(f"=== Transaction FAILED: {operation} — {error} ===")
