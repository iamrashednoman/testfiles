"""Retry policy engine — port of v2 service/retry_policy.py.

Contract: business failures (the request data is wrong; a human must
act) are never retried. System failures retry with exponential backoff
and equal jitter up to max_attempts. The dispatcher applies decisions;
workflows only classify.
"""
from __future__ import annotations

import random
from dataclasses import dataclass

from src.modules.intake.models import RequestStatus, normalize_status

_NON_FAILURE_STATUSES = {
    RequestStatus.DONE.value,
    RequestStatus.ALREADY_DELETED.value,
    RequestStatus.CANCELLED.value,
}


@dataclass
class RetryDecision:
    should_retry: bool
    delay_seconds: float
    reason: str


class RetryPolicy:
    def __init__(self, max_attempts: int = 3, base_delay: float = 5.0,
                 backoff_factor: float = 2.0, max_delay: float = 60.0,
                 jitter: bool = True,
                 retry_on_business_failure: bool = False):
        self.max_attempts = max_attempts
        self.base_delay = base_delay
        self.backoff_factor = backoff_factor
        self.max_delay = max_delay
        self.jitter = jitter
        self.retry_on_business_failure = retry_on_business_failure

    @staticmethod
    def is_failure(result: dict | None) -> bool:
        if result is None:
            return True
        return normalize_status(result.get("status", "")) not in _NON_FAILURE_STATUSES

    @staticmethod
    def classify(result: dict | None, exception: Exception | None = None) -> str:
        if exception is not None:
            return "system"
        if result is not None and result.get("error_type") == "business":
            return "business"
        return "system"

    def compute_delay(self, attempt: int) -> float:
        delay = min(self.base_delay * self.backoff_factor ** (attempt - 1),
                    self.max_delay)
        if self.jitter:
            half = delay / 2
            delay = half + random.random() * half
        return delay

    def evaluate(self, attempt_count: int, result: dict | None = None,
                 exception: Exception | None = None) -> RetryDecision:
        if exception is None and not self.is_failure(result):
            return RetryDecision(False, 0.0, "not a failure")

        # The "70" commit reached the mainframe: running the request
        # again could create/delete the account twice.
        if result and result.get("commit_sent"):
            return RetryDecision(False, 0.0, "commit sent — never retried")
        # A catalogue rule that says the whole request must not be
        # repeated (retry_whole_request false on a system error).
        if result and result.get("retryable") is False:
            return RetryDecision(False, 0.0,
                                 "error rule — whole request not retried")

        kind = self.classify(result, exception)
        if kind == "business" and not self.retry_on_business_failure:
            return RetryDecision(False, 0.0, "business failure — never retried")

        if attempt_count >= self.max_attempts:
            return RetryDecision(
                False, 0.0,
                f"max attempts reached ({attempt_count}/{self.max_attempts})",
            )

        return RetryDecision(
            True, self.compute_delay(attempt_count),
            f"system failure — attempt {attempt_count}/{self.max_attempts}",
        )
