"""Screenshot / evidence capture store.

Port of v2 utils/evidence.py. Captures screenshots at defined workflow
checkpoints to create an audit trail for compliance and debugging.
Green-screen captures contain PII (employee IDs) — retention is
config-driven (evidence_retention_days) and enforced by the ops
cleanup job.

Approved fix vs v2: the capture-point list in layouts.yaml now includes
every capture() call site (v2 omitted confirmation_screen,
confirmation_mismatch, already_deleted_screen, and login_failed, so
those screens were silently never saved).
"""

from datetime import datetime
from pathlib import Path


class EvidenceCapture:
    """Captures and stores screenshots as audit evidence."""

    def __init__(self, config: dict, transaction_id: str = None):
        self.enabled = config.get("enabled", True)
        self.output_dir = Path(config.get("output_dir", "evidence"))
        self.capture_points = set(config.get("capture_points", []))
        self.img_format = config.get("format", "png")
        # An explicitly provided transaction_id PINS the folder: later
        # set_transaction() calls are ignored. The platform keys
        # evidence by request_id at construction; without the pin, the
        # workflows' logger-txn re-point abandoned that folder empty
        # and scattered captures into timestamp-named ones.
        self._pinned = transaction_id is not None
        self.transaction_id = (transaction_id
                               or datetime.now().strftime("%Y%m%d_%H%M%S"))

        # Create transaction-specific evidence folder
        self.txn_dir = self.output_dir / self.transaction_id
        if self.enabled:
            self.txn_dir.mkdir(parents=True, exist_ok=True)

        # Continue the numbering where a previous attempt left off.
        #
        # A retried request re-executes with the SAME request id, so it
        # lands in the SAME pinned folder with a fresh capture object.
        # Restarting the counter at 001 made every attempt reuse the
        # earlier filenames: when two attempts fell in the same second
        # (retry with little/no backoff) attempt 2 OVERWROTE attempt 1's
        # evidence outright, and even when it did not, the folder
        # interleaved two 001..NNN series with no chronological order.
        # Resuming the count keeps every attempt's evidence, in order.
        self._step_counter = self._existing_capture_count()

    def _existing_capture_count(self) -> int:
        """How many captures this transaction folder already holds."""
        if not self.enabled:
            return 0
        try:
            return len(list(self.txn_dir.glob(f"*.{self.img_format}")))
        except OSError:
            return 0

    def set_transaction(self, transaction_id: str):
        """Update transaction ID and create new evidence folder.
        No-op when the folder was pinned at construction."""
        if self._pinned:
            return
        self.transaction_id = transaction_id
        self.txn_dir = self.output_dir / transaction_id
        if self.enabled:
            self.txn_dir.mkdir(parents=True, exist_ok=True)
        self._step_counter = 0

    def capture(self, step_name: str, driver=None) -> str | None:
        """Capture a screenshot if this step is in the capture points.

        Returns the path to the saved screenshot, or None if skipped.
        """
        if not self.enabled:
            return None

        # Capture at all steps if no specific points defined, or if the
        # step is listed
        if self.capture_points and step_name not in self.capture_points:
            return None

        self._step_counter += 1
        timestamp = datetime.now().strftime("%H%M%S")
        filename = (f"{self._step_counter:03d}_{step_name}_{timestamp}"
                    f".{self.img_format}")
        filepath = self.txn_dir / filename

        try:
            if driver and hasattr(driver, "take_screenshot"):
                driver.take_screenshot(str(filepath))
            else:
                self._fallback_screenshot(str(filepath))
            return str(filepath)
        except Exception as e:
            # Screenshot failure should never crash the bot
            print(f"Warning: Failed to capture evidence at "
                  f"'{step_name}': {e}")
            return None

    def _fallback_screenshot(self, filepath: str):
        """Fallback screenshot using pyautogui, then PIL."""
        try:
            import pyautogui
            screenshot = pyautogui.screenshot()
            screenshot.save(filepath)
        except ImportError:
            try:
                from PIL import ImageGrab
                screenshot = ImageGrab.grab()
                screenshot.save(filepath)
            except Exception:
                raise RuntimeError(
                    "No screenshot capability available. "
                    "Install pyautogui or Pillow."
                )

    def get_evidence_path(self) -> str:
        """Return the path to the current transaction's evidence
        folder."""
        return str(self.txn_dir)


def purge_expired_evidence(evidence_dir, retention_days: int,
                           now: float | None = None) -> list[str]:
    """Delete evidence folders older than `retention_days` (2026-09-28).

    Evidence holds personal data, and a provisioning screenshot shows the
    initial password, so it is kept only as long as the retention setting
    says. One folder per request directly under the evidence root; a
    folder counts as old when nothing in it changed for the whole period
    (its newest file decides). Only real folders directly under the root
    are touched — never a link, never anything outside it. Returns the
    names of the folders removed. 0 or less keeps everything.
    """
    import shutil
    import time as _time

    days = int(retention_days or 0)
    root = Path(evidence_dir)
    if days <= 0 or not root.is_dir():
        return []
    cutoff = (now if now is not None else _time.time()) - days * 86400
    root_resolved = root.resolve()
    removed = []
    for folder in sorted(root.iterdir()):
        try:
            if folder.is_symlink() or not folder.is_dir():
                continue
            if folder.resolve().parent != root_resolved:
                continue
            newest = folder.stat().st_mtime
            for item in folder.rglob("*"):
                if not item.is_symlink():
                    newest = max(newest, item.stat().st_mtime)
            if newest >= cutoff:
                continue
            shutil.rmtree(folder)
            removed.append(folder.name)
        except OSError:
            continue                       # retried on the next run
    return removed
