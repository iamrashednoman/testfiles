"""Shared, bot-agnostic framework layer.

Nothing in this package may import from src/modules, src/rpa, or
src/integrations — dependencies point inward only. This is the layer
intended for reuse by future AIG bots beyond FINESIII.
"""
