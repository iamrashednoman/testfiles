"""The console's e-mail tests (2026-09-29).

  * Test connection: connects, secures and logs in exactly as a real
    e-mail would, then disconnects without sending (EmailNotifier
    .check_connection).
  * Send test e-mail: one e-mail, in the language and design in force,
    to one or more typed addresses.
  * explain(): a plain-language hint for the usual mail-server answers.
"""
from __future__ import annotations

import smtplib
import ssl

from src.modules.notifications import messages as _m
from src.modules.notifications.notifier import (
    EmailNotifier, EncryptionUnavailable, template,
)
from src.modules.notifications.render import rows_html, rows_text, text_to_html


def send_test_email(notifier: EmailNotifier, user: str, recipients) -> bool:
    s = notifier.s
    security = s.effective_security
    rows = [
        (_m.label("test.label.server"), f"{s.smtp_host}:{s.smtp_port}"),
        (_m.label("test.label.security"), _m.label(f"security.{security}")),
        (_m.label("test.label.auth"),
         _m.label("test.auth.login" if s.username else "test.auth.none")),
    ]
    intro = _m.text("test.body", user=user)
    subject = _m.subject("test.subject")
    context = {
        "severity": _m.label("sev.TEST"),
        "source": _m.label("source.console"),
        "message_html": text_to_html(intro),
        "t_badge": _m.label("sev.TEST"),
        "t_heading": subject,
        "t_meta": notifier.environment(),
        "rows_html": rows_html(rows),
    }
    body = "\n\n".join([intro, rows_text(rows), _m.text("footer.auto")])
    return notifier.send(subject, body, to=list(recipients), context=context,
                         template_path=template("alert.html"), kind="test",
                         persist=False)


def explain(error) -> str:
    """What an administrator should check, for the usual failures."""
    text = str(error)
    low = text.lower()
    code = int(getattr(error, "smtp_code", 0) or 0)
    if isinstance(error, EncryptionUnavailable):
        return ("The server offers no encryption, so the login was not sent. "
                "For a relay without login, clear the username; otherwise "
                "use STARTTLS or SSL/TLS.")
    if isinstance(error, ssl.SSLCertVerificationError) or \
            "certificate verify failed" in low:
        if "hostname" in low or "host name" in low or "match" in low:
            return ("The server's certificate is for a different name. Use "
                    "the host name on the certificate, not an IP address "
                    "or alias.")
        return ("The server's certificate is not trusted by this machine. "
                "Add the organisation's certificate authority to the "
                "machine's trusted certificates (or set 'Extra trusted "
                "certificate file'); 'Check the server certificate' Off "
                "only as a temporary measure.")
    if isinstance(error, smtplib.SMTPNotSupportedError) or \
            "starttls extension not supported" in low:
        return ("The server does not offer STARTTLS. Choose 'STARTTLS if the "
                "server offers it' (internal relay on port 25) or check the "
                "port.")
    if "not both" in low:
        return ("Choose STARTTLS (port 587) or implicit SSL (port 465), not "
                "both.")
    if "5.7.139" in low or "basic authentication is disabled" in low:
        return ("The mail service no longer accepts a password login "
                "(basic authentication disabled). Use the organisation's "
                "internal relay, or ask the messaging team for an allowed "
                "sign-in method.")
    if isinstance(error, smtplib.SMTPAuthenticationError) or \
            "5.7.57" in low or code == 535 or "authentication" in low:
        return ("Username or password rejected by the SMTP server. For a "
                "relay without login, leave the username blank.")
    if "5.7.60" in low or "send as" in low or "sendas" in low:
        return ("The account may not send as the From address. Ask the "
                "messaging team for send-as rights, or use the account's "
                "own mailbox as From.")
    if isinstance(error, smtplib.SMTPSenderRefused):
        return ("The server refused the From address. Use an address the "
                "relay allows for this server.")
    if isinstance(error, smtplib.SMTPRecipientsRefused) or \
            "relay" in low and ("denied" in low or "not permitted" in low):
        return ("The server refused the recipient (relaying denied). Check "
                "that this server's address is allowed on the relay and that "
                "the relay delivers to that domain.")
    if "wrong version" in low or "ssl" in low or "tls" in low:
        return ("TLS mismatch — use SSL/TLS for port 465, STARTTLS for 587 "
                "and 25.")
    if "refused" in low or "timed out" in low or "name" in low or \
            "unreachable" in low or "getaddrinfo" in low:
        return ("The SMTP host is unreachable from this machine. Check the "
                "host name, the port and the firewall (Test-NetConnection "
                "<host> -Port <port>).")
    return ""
