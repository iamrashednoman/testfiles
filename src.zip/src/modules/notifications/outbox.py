"""The e-mail outbox (2026-09-29).

An e-mail that could not be delivered after its retries is kept here and
resent automatically, so an outage of the mail server does not lose the
support report, a notice or an alert. The same approach as the
dispatcher's pending-completions journal: a folder in the data
directory, one file per e-mail, written atomically.

  * Resent oldest first, every `retry_seconds` (5 minutes). A round
    stops at the first failure (the server is still down); after a
    refused login the next round waits 30 minutes, so a wrong password
    cannot lock the mail account.
  * Kept for `keep_hours` (24 hours by default). After that the e-mail
    is given up: removed, and recorded as failed in the audit trail.
  * An e-mail the server refuses for its sender or recipients is given
    up at once; resending cannot help.
  * A password e-mail is never written here (EmailNotifier.SECRET_KINDS).
  * Survives a restart: the folder is read again when the service
    starts.
"""
from __future__ import annotations

import json
import os
import threading
import time
import uuid
from datetime import datetime, timedelta
from email import policy
from email.parser import BytesParser
from pathlib import Path
from typing import Callable, Optional

import smtplib

from src.modules.notifications import notifier as _notifier
from src.modules.notifications.notifier import (
    JST, message_specific, now_jst,
)


class Outbox:
    AUTH_WAIT_SECONDS = 1800.0

    def __init__(self, directory, transport, logger=None, audit=None,
                 keep_hours: float = 24.0, retry_seconds: float = 300.0,
                 clock: Callable[[], datetime] = now_jst):
        self.dir = Path(directory)
        self.transport = transport          # an EmailNotifier (its connection)
        self.logger = logger
        self.audit = audit
        self.keep_hours = float(keep_hours)
        self.retry_seconds = float(retry_seconds)
        self._clock = clock
        self._lock = threading.Lock()
        # One resend round at a time (the worker, or "retry now" from
        # the console): an e-mail is never sent twice.
        self._round = threading.Lock()
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._next_round_at = 0.0

    # ── storing ──

    def put(self, msg, recipients, kind: str = "", attempts: int = 0,
            last_error: str = "") -> bool:
        """Keep one e-mail for a later attempt. False when the outbox is
        switched off (keep_hours 0) or cannot be written."""
        if self.keep_hours <= 0:
            return False
        self.dir.mkdir(parents=True, exist_ok=True)
        now = self._clock()
        name = f"{now.strftime('%Y%m%d%H%M%S')}_{uuid.uuid4().hex[:12]}"
        meta = {"recipients": list(recipients), "kind": kind,
                "subject": str(msg["Subject"] or "")[:300],
                # The attempts already made and why they failed (E2E-L17).
                "created_at": now.isoformat(), "attempts": int(attempts or 0),
                "last_error": str(last_error or "")[:300]}
        with self._lock:
            self._write(self.dir / f"{name}.eml", msg.as_bytes())
            self._write(self.dir / f"{name}.json",
                        json.dumps(meta, ensure_ascii=False).encode("utf-8"))
        return True

    @staticmethod
    def _write(path: Path, data: bytes) -> None:
        tmp = path.with_suffix(path.suffix + ".tmp")
        with open(tmp, "wb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)

    def _entries(self):
        if not self.dir.is_dir():
            return []
        return sorted(p for p in self.dir.glob("*.json"))

    def pending(self) -> int:
        try:
            return len(self._entries())
        except OSError:
            return 0

    # ── resending ──

    def list(self) -> list:
        """What is waiting, oldest first (recipients masked)."""
        from src.modules.notifications.notifier import EmailNotifier
        out = []
        for meta_path in self._entries():
            try:
                meta = json.loads(meta_path.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                continue
            try:
                created = datetime.fromisoformat(meta["created_at"])
                if created.tzinfo is None:
                    created = created.replace(tzinfo=JST)
                expires = (created + timedelta(hours=self.keep_hours)
                           ).astimezone(JST).strftime("%Y-%m-%d %H:%M:%S")
                created = created.astimezone(JST).strftime("%Y-%m-%d %H:%M:%S")
            except (KeyError, ValueError):
                created = expires = ""
            out.append({"id": meta_path.stem,
                        "subject": meta.get("subject", ""),
                        "kind": meta.get("kind", ""),
                        "recipients": [EmailNotifier._mask_address(r)
                                       for r in meta.get("recipients", [])],
                        "attempts": int(meta.get("attempts", 0)),
                        "last_error": meta.get("last_error", ""),
                        "kept_since_jst": created,
                        "given_up_after_jst": expires})
        return out

    def delete(self, entry_id: str):
        """Remove one kept e-mail (EM-05, 2026-10-03). Returns its
        details ({} when there was none). Raises ValueError for a name
        that is not an outbox entry."""
        import re as _re
        if not _re.match(r"^\d{14}_[0-9a-f]{12}$", str(entry_id or "")):
            raise ValueError("Not an outbox entry.")
        meta_path = self.dir / f"{entry_id}.json"
        with self._lock:
            if not meta_path.is_file():
                return {}
            try:
                meta = json.loads(meta_path.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                meta = {}
            for path in (meta_path, meta_path.with_suffix(".eml")):
                try:
                    path.unlink()
                except FileNotFoundError:
                    pass
        return {"subject": str(meta.get("subject", "")),
                "kind": str(meta.get("kind", "")) or "e-mail"}

    def run_once(self) -> dict:
        """One round: resend what is due, oldest first. Returns counts;
        {"busy": True} when a round is already running. After the mail
        server refused the sign-in, "resend now" waits like the worker
        does (EM-05, 2026-10-03): resending at once would only add
        failed sign-ins."""
        if time.time() < self._next_round_at:
            return {"sent": 0, "given_up": 0, "waiting": self.pending(),
                    "paused_until_jst": datetime.fromtimestamp(
                        self._next_round_at, JST).strftime(
                            "%Y-%m-%d %H:%M:%S")}
        if not self._round.acquire(blocking=False):
            return {"busy": True, "sent": 0, "given_up": 0,
                    "waiting": self.pending()}
        try:
            return self._run_round()
        finally:
            self._round.release()

    def _run_round(self) -> dict:
        counts = {"sent": 0, "given_up": 0, "waiting": 0}
        with self._lock:
            entries = self._entries()
        for meta_path in entries:
            eml_path = meta_path.with_suffix(".eml")
            try:
                meta = json.loads(meta_path.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                self._remove(meta_path, eml_path)
                continue
            if not eml_path.is_file():
                self._remove(meta_path, eml_path)
                continue
            if self._expired(meta):
                self._give_up(meta_path, eml_path, meta,
                              f"not delivered within {self.keep_hours:g} "
                              f"hour(s): {meta.get('last_error', '')}")
                counts["given_up"] += 1
                continue
            try:
                msg = BytesParser(policy=policy.default).parsebytes(
                    eml_path.read_bytes())
                refused = self.transport.transmit(msg, meta["recipients"])
            except (smtplib.SMTPException, OSError) as e:
                if message_specific(e):
                    self._give_up(meta_path, eml_path, meta, str(e))
                    counts["given_up"] += 1
                    continue
                meta["attempts"] = int(meta.get("attempts", 0)) + 1
                meta["last_error"] = str(e)[:300]
                try:
                    self._write(meta_path, json.dumps(
                        meta, ensure_ascii=False).encode("utf-8"))
                except OSError:
                    pass
                _notifier.DELIVERY.failed(e)
                if isinstance(e, smtplib.SMTPAuthenticationError):
                    self._next_round_at = time.time() + self.AUTH_WAIT_SECONDS
                counts["waiting"] = len(self._entries())
                return counts            # the server is still failing
            self._remove(meta_path, eml_path)
            _notifier.DELIVERY.ok()
            counts["sent"] += 1
            self._audit(True, meta, refused=list(refused or {}))
            if self.logger:
                self.logger.info(f"E-mail from the outbox delivered: "
                                 f"'{meta.get('subject', '')}'")
        counts["waiting"] = len(self._entries())
        return counts

    def _expired(self, meta: dict) -> bool:
        try:
            created = datetime.fromisoformat(meta["created_at"])
        except (KeyError, ValueError):
            return True
        if created.tzinfo is None:
            created = created.replace(tzinfo=JST)
        return self._clock() - created > timedelta(hours=self.keep_hours)

    def _give_up(self, meta_path, eml_path, meta, reason: str) -> None:
        self._remove(meta_path, eml_path)
        self._audit(False, meta, error=reason)
        if self.logger:
            # WARNING: below the alert threshold, so no e-mail loop.
            self.logger.warning(
                f"E-mail given up: '{meta.get('subject', '')}' — {reason}")

    def _remove(self, *paths) -> None:
        with self._lock:
            for p in paths:
                try:
                    Path(p).unlink()
                except OSError:
                    pass

    def _audit(self, ok: bool, meta: dict, error: str = "",
               refused=None) -> None:
        if self.audit is None:
            return
        from src.modules.notifications.notifier import EmailNotifier
        try:
            detail = {"subject": meta.get("subject", "")[:200],
                      "kind": meta.get("kind", ""),
                      "recipients": [EmailNotifier._mask_address(r)
                                     for r in meta.get("recipients", [])][:50],
                      "recipient_count": len(meta.get("recipients", [])),
                      "from_outbox": True, "error": str(error)[:300]}
            if refused:
                detail["refused"] = [EmailNotifier._mask_address(r)
                                     for r in refused][:50]
            self.audit.event("notification",
                             "email_sent" if ok else "email_failed",
                             severity="INFO" if ok else "WARNING",
                             detail=detail)
        except Exception:
            pass

    # ── background worker ──

    def start(self) -> None:
        if self._thread is not None:
            return
        self._thread = threading.Thread(target=self._loop,
                                        name="email-outbox", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=5)

    def _loop(self) -> None:
        # First round soon after the start: e-mails kept before a restart.
        wait = 30.0
        while not self._stop.wait(wait):
            wait = self.retry_seconds
            if time.time() < self._next_round_at:
                continue
            try:
                if self.pending():
                    self.run_once()
            except Exception as e:
                if self.logger:
                    self.logger.warning(f"E-mail outbox round failed: {e}")


def purge_outbox_folder(folder) -> int:
    """Remove every kept e-mail from `folder` (EM-05, 2026-10-03). Used
    at start while e-mail is switched off, or kept hours is 0: the files
    hold names and codes in plain text, and nothing would ever send or
    expire them. Returns the number of e-mails removed. Never raises."""
    removed = 0
    try:
        path = Path(folder)
        if not path.is_dir():
            return 0
        for meta in path.glob("*.json"):
            for f in (meta, meta.with_suffix(".eml")):
                try:
                    f.unlink()
                except FileNotFoundError:
                    pass
            removed += 1
        for leftover in path.glob("*.eml"):
            leftover.unlink()
            removed += 1
    except OSError:
        pass
    return removed
