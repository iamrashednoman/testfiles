"""
Availability outage/recovery email alerts (client requirement #8).

When CyberArk or the FINESIII application becomes unavailable — and again
when it recovers — the configured teams receive a DEDICATED, branded HTML
email (templates/availability_outage.html), distinct from the generic
error-alert template.

Design:
  * Fired from the transition hooks that already exist on the CyberArk
    provider (on_unavailable/on_recovered) and on the AvailabilityMonitor
    (added alongside this module). Hooks fire on TRANSITIONS only, so a
    long outage produces one outage mail + one recovery mail — no storms.
    A per-component re-alert floor adds a second safety net.
  * Sends on a fire-and-forget daemon thread: an unreachable SMTP server
    must never stall the probe loop or the CyberArk refresh thread.
  * Reuses the existing EmailNotifier (throttling at the transport level,
    retry/backoff, redaction, dry-run) — no new transport code.
"""
from __future__ import annotations

import threading
import time
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Optional

from src.core.app_paths import resource_path
from src.modules.notifications import audiences as _audiences
from src.modules.notifications import messages as _m
from src.modules.notifications.notifier import (
    EmailNotifier, NotificationError, template,
)
from src.modules.notifications.render import rows_html, rows_text

JST = timezone(timedelta(hours=9))

AVAILABILITY_TEMPLATE_PATH = str(
    resource_path("src", "modules", "notifications", "templates",
                  "availability_outage.html")
)

# Component display names used by the callers (kept as they were).
COMPONENT_CYBERARK = "CyberArk Vault"
COMPONENT_FINESIII = "FINESIII Application"
COMPONENT_SERVICENOW = "ServiceNow Polling"
COMPONENT_DATABASE = "Database"
COMPONENT_SERVICE = "FINES III RPA service"

# name -> (wording key, audience) — the wording is in
# config/email_messages.yaml (component.*, avail.impact.*, avail.next.*).
_COMPONENTS = {
    COMPONENT_CYBERARK: ("cyberark", _audiences.CYBERARK),
    COMPONENT_FINESIII: ("finesiii", _audiences.FINESIII),
    COMPONENT_SERVICENOW: ("servicenow", _audiences.SERVICENOW),
    COMPONENT_DATABASE: ("database", _audiences.DATABASE),
    COMPONENT_SERVICE: ("service", _audiences.OPERATIONS),
}


class AvailabilityAlerter:
    """Sends dedicated outage/recovery emails on component transitions."""

    def __init__(self, notifier: EmailNotifier, logger=None,
                 min_realert_seconds: float = 300.0,
                 async_send: bool = True):
        self.notifier = notifier
        self.logger = logger
        self.min_realert_seconds = min_realert_seconds
        self.async_send = async_send
        # (component, state) -> epoch of last sent — floor against repeats
        # if a flapping component transitions rapidly.
        self._last_sent = {}
        self._lock = threading.Lock()

    # ── public API (wired to the transition hooks) ─────────────────

    # Both return False when the re-alert floor suppressed the notice and
    # True when it was sent (or handed to the sender thread), so a caller
    # can retry a suppressed notice later (NB-011).
    def component_down(self, component: str, reason: str) -> bool:
        return self._alert(component, down=True, reason=reason)

    def component_recovered(self, component: str) -> bool:
        return self._alert(component, down=False, reason=None)

    # Convenience partials for hook wiring.
    def cyberark_down(self, reason: str = ""):
        return self.component_down(COMPONENT_CYBERARK,
                                   reason or _m.pair("avail.reason.cyberark"))

    def cyberark_recovered(self):
        return self.component_recovered(COMPONENT_CYBERARK)

    def finesiii_down(self, reason: str = ""):
        self.component_down(COMPONENT_FINESIII,
                            reason or _m.pair("avail.reason.finesiii"))

    def finesiii_recovered(self):
        self.component_recovered(COMPONENT_FINESIII)

    def database_down(self, reason: str = ""):
        return self.component_down(COMPONENT_DATABASE, reason)

    def database_recovered(self):
        return self.component_recovered(COMPONENT_DATABASE)

    def service_notice(self, state: str, problems=()) -> None:
        """The service started with problems / started / is stopping
        (2026-09-29). Not subject to the re-alert floor; sent at once
        (the caller is starting or stopping the service)."""
        key = {"problems": "problems", "started": "started",
               "stopping": "stopping"}.get(state, "started")
        observation = ("\n".join(f"- {p}" for p in problems) if problems
                       else _m.pair(f"service.reason.{key}"))
        status = _m.pair(f"service.status.{key}")
        content = self._content(
            COMPONENT_SERVICE, status, observation,
            _m.pair(f"service.impact.{key}"), _m.pair(f"service.next.{key}"),
            down=(key != "started"),
            subject=_m.subject(f"service.subject.{key}"),
            severity=("OUTAGE" if key == "problems" else "NOTICE"))
        self._send(*content)

    # ── internals ──────────────────────────────────────────────────

    def _alert(self, component: str, down: bool, reason) -> bool:
        key = (component, down)
        now = time.time()
        with self._lock:
            last = self._last_sent.get(key, 0.0)
            if now - last < self.min_realert_seconds:
                if self.logger:
                    self.logger.info(
                        f"Availability alert for {component} suppressed "
                        f"(re-alert floor {self.min_realert_seconds:.0f}s)"
                    )
                return False
            self._last_sent[key] = now

        wkey = _COMPONENTS.get(component, ("", ""))[0]
        state = "down" if down else "up"
        if down:
            impact = _m.pair(f"avail.impact.{wkey}") if wkey else ""
            next_step = _m.pair(f"avail.next.{wkey}") if wkey else ""
        else:
            impact = _m.pair("avail.impact.recovered")
            next_step = _m.pair("avail.next.recovered")
            reason = reason or _m.pair("avail.reason.recovered")
        name = self._name(component)
        content = self._content(
            component, _m.pair(f"avail.status.{state}"), reason, impact,
            next_step, down=down,
            subject=_m.subject(f"avail.subject.{state}", component=name),
            severity="OUTAGE" if down else "RECOVERY")

        if self.async_send:
            threading.Thread(
                target=self._send, args=content,
                name="availability-alert", daemon=True,
            ).start()
        else:
            self._send(*content)
        return True

    @staticmethod
    def _name(component: str):
        wkey = _COMPONENTS.get(component, ("", ""))[0]
        return _m.pair(f"component.{wkey}") if wkey else component

    def _content(self, component, status, reason, impact, next_step,
                 down: bool, subject: str, severity: str):
        """(subject, body, context, audience) of one notice; every text
        from the wording file, in the language in force."""
        detected_at = datetime.now(JST).strftime("%Y-%m-%d %H:%M:%S JST")
        name = _m.value(self._name(component))
        status_text = _m.value(status)
        rows = [
            (_m.label("avail.label.component"), name),
            (_m.label("avail.label.status"), status_text),
            (_m.label("avail.label.detected"), detected_at),
            (_m.label("avail.label.observation"), _m.paragraph(reason)),
            (_m.label("avail.label.impact"), _m.paragraph(impact)),
            (_m.label("avail.label.next_step"), _m.paragraph(next_step)),
        ]
        body = f"{name}: {status_text}\n\n" + rows_text(rows)
        colour, background = (("#b0102f", "#fbe7eb") if down
                              else ("#047857", "#d1fae5"))
        context = {
            # The earlier design's placeholders (fallback).
            "component": name, "status_label": status_text,
            "status_color": colour, "status_bg": background,
            "reason": _m.paragraph(reason), "detected_at": detected_at,
            "impact": _m.paragraph(impact),
            "next_step": _m.paragraph(next_step),
            # The Japanese / English design.
            "t_status": status_text,
            "t_heading": f"{name} — {status_text}",
            "t_label_details": _m.label("label.details"),
            "rows_html": rows_html(rows),
            "severity": severity, "source": "availability-monitor",
        }
        audience = _COMPONENTS.get(component, ("", ""))[1]
        return subject, body, context, audience

    def _send(self, subject: str, body: str, context: dict,
              audience: str = ""):
        try:
            settings = getattr(self.notifier, "s", None)
            to, cc = _audiences.route(
                audience, getattr(settings, "recipients_to", []),
                getattr(settings, "recipients_cc", []))
            extra = {"to": to, "cc": cc} if to else {}
            self.notifier.send(subject, body, context=context,
                               template_path=template(
                                   "availability_outage.html"), **extra)
        except NotificationError as e:
            if self.logger:
                self.logger.warning(f"Availability alert email failed: {e}")
        except Exception as e:   # alerting must never take anything down
            if self.logger:
                self.logger.warning(f"Availability alert unexpected error: {e}")


class DatabaseWatch:
    """Outage and recovery notices for the database (2026-09-29, E-10).

    Checks the database every `interval` seconds with a light read (the
    queue depth). Two failed checks in a row send one outage notice; the
    first good check after it sends the recovery notice. While the
    database is down, the generic error alerts of the dispatcher are not
    e-mailed (the notice covers them).
    """

    def __init__(self, probe, alerter: AvailabilityAlerter, logger=None,
                 interval: float = 60.0, threshold: int = 2):
        self.probe = probe
        self.alerter = alerter
        self.logger = logger
        self.interval = float(interval)
        self.threshold = int(threshold)
        self.failures = 0
        self.down = False
        self.last_error = ""
        self._stop = threading.Event()
        self._thread = None

    def check_once(self) -> bool:
        """One check; True when the database answered."""
        try:
            self.probe()
        except Exception as e:
            self.failures += 1
            self.last_error = f"{type(e).__name__}: {e}"[:300]
            if self.failures >= self.threshold and not self.down:
                if self.alerter.database_down(self.last_error) is not False:
                    self.down = True
            return False
        self.failures = 0
        if self.down:
            if self.alerter.database_recovered() is not False:
                self.down = False
        return True

    def start(self) -> None:
        if self._thread is not None:
            return
        self._thread = threading.Thread(target=self._loop,
                                        name="database-watch", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=2)

    def _loop(self) -> None:
        while not self._stop.wait(self.interval):
            try:
                self.check_once()
            except Exception as e:
                if self.logger:
                    self.logger.warning(f"Database watch failed: {e}")


def build_availability_alerter(alert_handler, logger=None) -> Optional[AvailabilityAlerter]:
    """Service-startup helper. Reuses the EmailNotifier already built by
    attach_email_alerts(); returns None when notifications are inactive so
    callers can wire hooks conditionally (mirrors attach_email_alerts)."""
    if alert_handler is None:
        if logger:
            logger.info(
                "Availability alerts: inactive (email notifications disabled)"
            )
        return None
    return AvailabilityAlerter(alert_handler.notifier, logger=logger)
