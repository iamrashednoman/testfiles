"""E-mail checks for administrators (2026-09-29, ET1–ET5).

  status()        the e-mail settings in force (no passwords), the
                  delivery state and the outbox
  routing()       who WOULD receive each e-mail, with the settings in
                  force — nothing is sent
  preview()       one e-mail built with sample data — nothing is sent
  send_sample()   one e-mail with sample data, sent ONLY to the typed
                  addresses, "[TEST]" in the subject

Every e-mail is built by the application's own code (the same alerters,
wording file and designs as the real e-mails), with a stand-in mail
server that keeps the message instead of sending it. What the checks
show is therefore exactly what would be sent. The sample data is
fictional.
"""
from __future__ import annotations

import base64
import dataclasses
import logging
from types import SimpleNamespace
from typing import Callable, Optional

from src.modules.notifications import audiences as _audiences
from src.modules.notifications import messages as _m
from src.modules.notifications import notifier as _notifier
from src.modules.notifications.notifier import (
    BANNER_CID, LOGO_CID, EmailNotifier, _image,
)

# kind -> (what it is, when it is sent)
KINDS = {
    "provisioning_completed": ("Provisioning completed (operations)",
                               "An account was created and confirmed"),
    "deprovisioning_completed": ("Deprovisioning completed (operations)",
                                 "Access was removed"),
    "transaction_failed": ("Transaction failed (operations)",
                           "Every attempt failed"),
    "result_not_confirmed": ("Result not confirmed (operations)",
                             "Submitted, result not read: verify, do not "
                             "retry"),
    "request_rejected": ("Request rejected (operations)",
                         "Duplicate or invalid request"),
    "error_screen": ("Recognised error screen (owning team)",
                     "A known FINESIII error screen stopped the request"),
    "outage": ("System not available (system team)",
               "ServiceNow, CyberArk, FINESIII or the database went down"),
    "recovery": ("System recovered (system team)",
                 "The system is available again"),
    "service_started_with_problems": ("Service started with problems",
                                      "Always, when the service starts "
                                      "with a problem"),
    "service_started": ("Service started", "Only when switched on"),
    "service_stopping": ("Service stopping", "Only when switched on"),
    "operational_alert": ("Operational alert",
                          "An error the service logged"),
    "alert_summary": ("Alert summary", "Daily or hourly summary"),
    "account_ready": ("Account ready (new user)",
                      "A request not in SailPoint format was provisioned"),
    "registration_notice": ("Registration notice (new user, client "
                            "template)", "SailPoint new account"),
    "password_notice": ("Password notice (new user, client template)",
                        "SailPoint new account, when switched on"),
    "support_report": ("Support report (client template)",
                       "A SailPoint ticket is finished"),
    "test_email": ("Test e-mail (console)", "Send test e-mail"),
}
SYSTEMS = ("servicenow", "cyberark", "finesiii", "database")
RULES = tuple(_audiences.RULE_AUDIENCE)
NOT_SET = "default-recipients-not-set@example.invalid"
SAMPLE_USER = "new.user@example.com"


class _Capture:
    """A mail server that keeps the message instead of sending it."""

    def __init__(self):
        self.sent = []

    def factory(self):
        return self

    def send_message(self, msg, to_addrs=None):
        self.sent.append((msg, list(to_addrs or [])))
        return {}

    def quit(self):
        pass


def _settings(base=None):
    from src.modules.notifications.config import load_notification_config
    return base or load_notification_config()


def _capture_notifier(settings, branding_source):
    s = dataclasses.replace(
        settings, enabled=True, dry_run=False, max_retries=0,
        async_send=False, mode="both", digest_schedule="interval",
        digest_interval_seconds=0.0,
        mail_from=settings.mail_from or "finesiii-rpa@example.com",
        recipients_to=list(settings.recipients_to) or [NOT_SET])
    capture = _Capture()
    n = EmailNotifier(s, smtp_factory=capture.factory,
                      sleep_func=lambda d: None)
    n.track_delivery = False
    n.branding_source = branding_source
    # Bound to this sender only: whatever connection the application
    # uses, a preview can never reach a mail server.
    n._connect = lambda info=None: capture
    return n, capture


def _txn(**kw):
    base = dict(transaction_id="txn_sample01", request_id="req_sample01",
                ticket_id="SCTASK0000001", operation="provision",
                affiliation_code="05007", employee_code="5007AAA",
                source="servicenow", status="done", result_code="O-0000",
                error_message="", attempt_count=1,
                submitted_at="2026-09-29T09:00:00+09:00",
                started_at="2026-09-29T09:01:00+09:00",
                completed_at="2026-09-29T09:02:30+09:00",
                duration_seconds=90.0, worker_id=1, screenshot_count=9,
                operator="OPR0001")
    base.update(kw)
    return SimpleNamespace(**base)


def _sample_request(password="Sample#0000"):
    return SimpleNamespace(
        request_id="req_sample01", source="servicenow",
        operation="provision", affiliation_code="05007",
        employee_code="5007AAA", ticket_id="SCTASK0000001",
        password=password, status="done", result_code="O-0000", error="",
        completed_at="2026-09-29T09:02:30+09:00",
        metadata={"category": "new_account", "parts": 1,
                  "user_email": SAMPLE_USER,
                  "parent_ticket": "SCTASK0000001",
                  "affiliation_name": "Sample Department",
                  "employee_name": "Sample User", "tracking_id": "T-00001",
                  "requester": {"name": "Sample Requester",
                                "employee_number": "0000001",
                                "email": "requester@example.com"}})


def _log_path(system: str) -> str:
    return {"servicenow": "src/integrations/servicenow/writeback.py",
            "cyberark": "src/integrations/cyberark/provider.py",
            "finesiii": "src/modules/queue/availability.py",
            "database": "src/modules/queue/dispatcher.py"}.get(
        system, "src/modules/queue/dispatcher.py")


def _build(kind: str, n: EmailNotifier, capture: _Capture,
           system: str = "", rule: str = "", user: str = "admin"):
    """Run the real code for one e-mail; returns the captured messages."""
    from src.modules.notifications.availability_alerts import (
        COMPONENT_CYBERARK, COMPONENT_DATABASE, COMPONENT_FINESIII,
        COMPONENT_SERVICENOW, AvailabilityAlerter,
    )
    from src.modules.notifications.diagnostics import send_test_email
    from src.modules.notifications.log_handler import EmailAlertHandler
    from src.modules.notifications.rejection_alerts import RejectionAlerter
    from src.modules.notifications.ticket_reports import (
        TicketReporter, load_ticket_report_config,
    )
    from src.modules.notifications.transaction_alerts import (
        TransactionAlerter, load_transaction_notification_config,
    )
    txn_settings = dataclasses.replace(
        load_transaction_notification_config(), enabled=True,
        notify_on_success=True, notify_on_failure=True,
        include_password=False, send_user_credentials=True)
    components = {"servicenow": COMPONENT_SERVICENOW,
                  "cyberark": COMPONENT_CYBERARK,
                  "finesiii": COMPONENT_FINESIII,
                  "database": COMPONENT_DATABASE}
    start = len(capture.sent)
    ta = TransactionAlerter(n, txn_settings, async_send=False)
    if kind == "provisioning_completed":
        ta._send_provision_ops(_txn())
    elif kind == "deprovisioning_completed":
        ta._send_deprovision_ops(_txn(operation="deprovision"))
    elif kind == "transaction_failed":
        ta._send_failure(_txn(status="failed", attempt_count=3,
                              result_code="E-0000",
                              error_message="Sample error text shown on "
                                            "the FINESIII screen"))
    elif kind == "result_not_confirmed":
        ta._send_verification(_txn(result_code="UNCONFIRMED",
                                   error_message="'70' sent; result not "
                                                 "read (sample)"))
    elif kind == "request_rejected":
        RejectionAlerter(n, recipients_to=txn_settings.ops_recipients_to,
                         async_send=False).request_rejected(
            "VALIDATION FAILED", "Sample reason: the employee code must be "
                                 "7 letters or digits",
            {"ticket_id": "SCTASK0000001", "source": "servicenow",
             "operation": "provision", "affiliation_code": "05007",
             "employee_code": "57A"})
    elif kind == "error_screen":
        rule = rule or RULES[-1]
        rules = txn_settings.error_alerts.rules or {}
        ta._send_error_alert(
            _txn(status="failed", attempt_count=3, error_message=rule),
            rule, dict(rules.get(rule) or {}),
            {"error_trace": [{"error_id": rule, "screen": "LOGIN",
                              "step": "finesiii_connect",
                              "matched": ["(sample on-screen text)"],
                              "captured": {"diagnostic_code": "C-0000"},
                              "context": {"affiliation_code": "05007",
                                          "employee_code": "5007AAA"}}]})
    elif kind in ("outage", "recovery"):
        alerter = AvailabilityAlerter(n, async_send=False,
                                      min_realert_seconds=0)
        component = components[system or "servicenow"]
        if kind == "outage":
            alerter.component_down(component, "Sample observation: the "
                                              "check did not answer")
        else:
            alerter.component_recovered(component)
    elif kind.startswith("service_"):
        state = {"service_started_with_problems": "problems",
                 "service_started": "started",
                 "service_stopping": "stopping"}[kind]
        AvailabilityAlerter(n, async_send=False).service_notice(
            state, ["Sample problem: an integration did not start"]
            if state == "problems" else ())
    elif kind in ("operational_alert", "alert_summary"):
        handler = EmailAlertHandler(n, n.s)
        try:
            record = logging.LogRecord(
                "finesiii_rpa_v3", logging.ERROR, _log_path(system), 1,
                "Sample alert: something the service logged as an error",
                (), None)
            record.module = _log_path(system).rsplit("/", 1)[-1][:-3]
            if kind == "operational_alert":
                handler.emit(record)
            else:
                handler._digest[_notifier.__name__] = {
                    "count": 3, "level": "ERROR",
                    "sample": record.getMessage(), "last_ts": 0}
                handler.flush_digest()
        finally:
            handler._stop.set()
    elif kind == "account_ready":
        ta._send_user_credentials(_txn(), _sample_request(password=""))
    elif kind in ("registration_notice", "password_notice",
                  "support_report"):
        report = dataclasses.replace(
            load_ticket_report_config(), txn_enabled=True,
            report_enabled=True, send_registration=True,
            send_password=True)
        reporter = TicketReporter(n, settings_loader=lambda: report,
                                  async_send=False)
        reporter._handle(SimpleNamespace(status="done",
                                         result_code="O-0000",
                                         ticket_id="SCTASK0000001"),
                         _sample_request())
        # Registration, password, report — in that order.
        order = {"registration_notice": 0, "password_notice": 1,
                 "support_report": 2}
        made = capture.sent[start:]
        return [made[order[kind]]] if len(made) == 3 else made
    elif kind == "test_email":
        send_test_email(n, user, list(n.s.recipients_to))
    else:
        raise ValueError(kind)
    return capture.sent[start:]


def _describe(msg, envelope, with_html: bool) -> dict:
    out = {"subject": str(msg["Subject"] or ""),
           "from": str(msg["From"] or ""),
           "to": str(msg["To"] or ""),
           "cc": str(msg["Cc"] or ""),
           "recipients": list(envelope),
           "text": msg.get_body(("plain",)).get_content()}
    html_parts = [p for p in msg.walk()
                  if p.get_content_type() == "text/html"]
    out["html_design"] = bool(html_parts)
    if with_html and html_parts:
        html = html_parts[0].get_content()
        # The embedded images inline, so the preview shows as sent.
        for part in msg.walk():
            cid = str(part.get("Content-ID") or "").strip("<>")
            if cid in (LOGO_CID, BANNER_CID):
                data = base64.b64encode(part.get_payload(decode=True)).decode()
                html = html.replace(
                    f"cid:{cid}", f"data:{part.get_content_type()};base64,"
                                  f"{data}")
        out["html"] = html
    return out


def _check_kind(kind: str, system: str, rule: str):
    if kind not in KINDS:
        raise ValueError(f"Unknown e-mail kind '{kind}'. Known: "
                         + ", ".join(KINDS))
    if system and system not in SYSTEMS:
        raise ValueError(f"Unknown system '{system}'. Known: "
                         + ", ".join(SYSTEMS))
    if rule and rule not in RULES:
        raise ValueError(f"Unknown error rule '{rule}'. Known: "
                         + ", ".join(RULES))


def preview(kind: str, branding_source: Optional[Callable] = None,
            language: str = "", system: str = "", rule: str = "",
            settings=None, user: str = "admin") -> dict:
    """One e-mail built with sample data. Nothing is sent."""
    _check_kind(kind, system, rule)
    s = _settings(settings)
    n, capture = _capture_notifier(s, branding_source)
    with _m.use_language(language):
        made = _build(kind, n, capture, system=system, rule=rule, user=user)
    if not made:
        raise ValueError(f"No e-mail was produced for '{kind}'")
    msg, envelope = made[-1]
    out = {"kind": kind, "title": KINDS[kind][0], "when": KINDS[kind][1],
           "language": language or _m.language(),
           **_describe(msg, envelope, with_html=True)}
    if not s.recipients_to:
        out["warning"] = ("Default recipients are not set (Settings > "
                          "E-mail); shown as " + NOT_SET)
    return out


def send_sample(kind: str, recipients, branding_source=None,
                language: str = "", system: str = "", rule: str = "",
                settings=None, user: str = "admin") -> dict:
    """The sample e-mail, sent ONLY to `recipients`, "[TEST]" first in
    the subject. The real recipients never receive it."""
    s = _settings(settings)
    _check_kind(kind, system, rule)
    n, capture = _capture_notifier(s, branding_source)
    with _m.use_language(language):
        made = _build(kind, n, capture, system=system, rule=rule, user=user)
    msg, _ = made[-1]
    for header in ("To", "Cc"):
        del msg[header]
    msg["To"] = ", ".join(recipients)
    subject = str(msg["Subject"] or "")
    del msg["Subject"]
    msg["Subject"] = f"[TEST] {subject}"
    sender = EmailNotifier(dataclasses.replace(
        s, enabled=True, max_retries=0), sleep_func=lambda d: None)
    refused = sender.transmit(msg, list(recipients))
    return {"kind": kind, "subject": str(msg["Subject"]),
            "sent_to": list(recipients),
            "refused": [EmailNotifier._mask_address(r) for r in refused]}


def routing(branding_source=None, settings=None) -> list:
    """Who would receive each e-mail now, and whether it is switched on.
    Built by the real code; nothing is sent."""
    from src.modules.notifications.ticket_reports import (
        load_ticket_report_config,
    )
    from src.modules.notifications.transaction_alerts import (
        load_transaction_notification_config,
    )
    s = _settings(settings)
    txn = load_transaction_notification_config()
    report = load_ticket_report_config()
    on = s.enabled
    switched = {
        "provisioning_completed": on and txn.enabled and txn.notify_on_success,
        "deprovisioning_completed": on and txn.enabled and txn.notify_on_success,
        "transaction_failed": on and txn.enabled and txn.notify_on_failure,
        "result_not_confirmed": on and txn.enabled,
        "request_rejected": on and txn.enabled and txn.notify_on_rejection,
        "error_screen": on and txn.enabled and txn.error_alerts.enabled,
        "outage": on, "recovery": on, "service_started_with_problems": on,
        "service_started": on and s.service_notices,
        "service_stopping": on and s.service_notices,
        "operational_alert": on,
        "alert_summary": on and s.digest_schedule != "off",
        "account_ready": on and txn.enabled and txn.send_user_credentials,
        "registration_notice": on and report.txn_enabled
                               and report.send_registration,
        "password_notice": on and report.txn_enabled and report.send_password,
        "support_report": on and report.txn_enabled and report.report_enabled,
        "test_email": True,
    }
    rows = []
    variants = []
    for kind in KINDS:
        if kind in ("outage", "recovery", "operational_alert"):
            variants += [(kind, system, "") for system in SYSTEMS]
        elif kind == "error_screen":
            variants += [(kind, "", rule) for rule in RULES]
        else:
            variants.append((kind, "", ""))
    for kind, system, rule in variants:
        n, capture = _capture_notifier(s, branding_source)
        try:
            made = _build(kind, n, capture, system=system, rule=rule)
            msg, envelope = made[-1]
            to, cc = str(msg["To"] or ""), str(msg["Cc"] or "")
        except Exception as e:
            envelope, to, cc = [], "", f"(could not be built: {e})"
        if kind in ("account_ready", "registration_notice",
                    "password_notice"):
            to, envelope = "(the user's address from the ticket)", []
        row = {"kind": kind, "title": KINDS[kind][0],
               "system": system, "rule": rule,
               "switched_on": bool(switched.get(kind, on)),
               "when": KINDS[kind][1], "to": to, "cc": cc,
               "recipients": [r for r in envelope if r != NOT_SET]}
        if kind == "error_screen" and not row["switched_on"] and on:
            row["note"] = ("Per-error notices are off: the transaction "
                           "failed notice is sent instead")
        if NOT_SET in envelope:
            row["note"] = "Default recipients are not set (Settings > E-mail)"
        rows.append(row)
    return rows


def status(branding_source=None, settings=None) -> dict:
    """The e-mail settings in force (no passwords), delivery and outbox."""
    from src.modules.notifications.ticket_reports import (
        load_ticket_report_config,
    )
    from src.modules.notifications.transaction_alerts import (
        load_transaction_notification_config,
    )
    s = _settings(settings)
    txn = load_transaction_notification_config()
    report = load_ticket_report_config()
    n = EmailNotifier(s)
    n.branding_source = branding_source
    outbox = _notifier.get_outbox()
    brand = n._branding()
    return {
        "enabled": s.enabled,
        "problem": _config_problem(s),
        "server": {"host": s.smtp_host, "port": s.smtp_port,
                   "security": s.effective_security,
                   "check_certificate": s.verify_tls,
                   "extra_certificate_file": s.ca_file,
                   "timeout_seconds": s.timeout_seconds,
                   "name_given_to_server": s.local_hostname,
                   "login": bool(s.username),
                   "password_stored": bool(s.password)},
        "sender": s.mail_from,
        "default_recipients": list(s.recipients_to),
        "default_cc": list(s.recipients_cc),
        "recipients_by_system": {
            name: {"to": _audiences.lists(name)[0],
                   "cc": _audiences.lists(name)[1]}
            for name in _audiences.ENV},
        "content": {"language": _m.language(),
                    "environment_name": n.environment(),
                    "subject_prefix": n.subject_prefix(),
                    "html_design": n.html_enabled(),
                    "company_name": brand.get("email_company_name", "")},
        "switches": {"transaction_emails": txn.enabled,
                     "per_error_notices": txn.error_alerts.enabled,
                     "support_report": report.report_enabled,
                     "registration_notice": txn.send_user_credentials,
                     "password_notice": txn.include_password,
                     "service_start_stop_notices": s.service_notices},
        "summary": {"schedule": s.digest_schedule,
                    "time_jst": s.digest_time},
        "delivery": _notifier.DELIVERY.snapshot(),
        "outbox": {"active": outbox is not None,
                   "keep_hours": s.outbox_hours,
                   "waiting": outbox.pending() if outbox else 0},
    }


def _config_problem(s) -> str:
    if not s.enabled:
        return "E-mail is switched off (Send email alerts)."
    try:
        s.validate()
    except ValueError as e:
        return str(e).removeprefix("notifications: ")
    return ""
