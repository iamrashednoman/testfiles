"""
EmailAlertHandler — a standard logging.Handler that turns the bot's existing
error logs into email alerts, with zero changes to the error-producing code.

Why a logging handler?
  Every component already calls logger.error(...) / logger.critical(...) on
  the shared "finesiii_rpa_v3" logger (and the RPA layer logs through the
  non-propagating "finesiii_rpa_v3.rpa" logger). Attaching this handler to
  BOTH captures all of them centrally. The bot keeps logging exactly as
  before; we just fan errors out to email.

Enterprise safeguards:
  * NEVER blocks the bot      → sends on a background thread (async_send).
  * NEVER crashes the bot     → emit() can never raise; SMTP errors are swallowed.
  * NO alert storms           → identical alerts are throttled/deduped per window.
  * NO log recursion          → a thread-local guard suppresses any logging that
                                happens while we're sending an alert.
  * Real-time AND digest       → per-error emails plus a periodic summary email.
"""
from __future__ import annotations

import logging
import queue
import threading
import time
from typing import Callable, Dict, Optional

from datetime import datetime, timedelta

from src.modules.notifications import audiences as _audiences
from src.modules.notifications import messages as _m
from src.modules.notifications.config import (
    NotificationSettings, load_notification_config,
)
from src.modules.notifications.notifier import (
    JST, EmailNotifier, NotificationError, now_jst,
)
from src.modules.notifications.render import rows_html, rows_text, text_to_html


# The two logger streams alerts are captured from: the app logger and the
# RPA TransactionLogger stream (which sets propagate=False, so attaching to
# the app logger alone would miss it).
ALERT_LOGGER_NAMES = ("finesiii_rpa_v3", "finesiii_rpa_v3.rpa")


def _signature(record: logging.LogRecord) -> str:
    """Stable dedup key: logger + level + message shape (digits masked)."""
    try:
        msg = record.getMessage()
    except Exception:
        msg = str(record.msg)
    shaped = "".join("#" if c.isdigit() else c for c in msg)[:120]
    return f"{record.name}:{record.levelname}:{shaped}"


# Where an alert comes from: (part of the source path, wording key,
# audience). First match wins; anything else is the service itself and
# goes to the default recipients (2026-09-29).
_SOURCES = (
    ("cyberark", "cyberark", _audiences.CYBERARK),
    ("writeback", "writeback", _audiences.SERVICENOW),
    ("snow_poller", "snow_poller", _audiences.SERVICENOW),
    ("servicenow", "snow_poller", _audiences.SERVICENOW),
    ("availability", "availability", _audiences.FINESIII),
    ("login_probe", "availability", _audiences.FINESIII),
    ("dispatcher", "dispatcher", _audiences.OPERATIONS),
    ("audit", "audit", _audiences.OPERATIONS),
    ("console", "console", _audiences.OPERATIONS),
    ("intake", "intake", _audiences.OPERATIONS),
    ("/rpa/", "rpa", _audiences.OPERATIONS),
)

# Errors that also send their own dedicated notice (outage notices): the
# generic alert would repeat it (2026-09-29, E-13). (source, text start)
DEDICATED = (
    ("cyberark", "CyberArk unavailable"),
    ("cyberark", "CyberArk refresh failed unexpectedly"),
    ("snow_poller", "ServiceNow poll failed"),
)


def source_of(record: logging.LogRecord):
    """(wording key, audience) of the part that logged the record."""
    path = str(getattr(record, "pathname", "") or "").replace("\\", "/").lower()
    module = str(getattr(record, "module", "") or "").lower()
    where = f"{path} {module}"
    if record.name.endswith(".rpa"):
        where += " /rpa/"
    for part, key, audience in _SOURCES:
        if part in where:
            return key, audience
    return "service", _audiences.OPERATIONS


def summary_of(text: str) -> str:
    """A short subject from a log line: its first line, up to the detail
    (': …' or ' — …') when what comes before it reads on its own."""
    first = (text or "").strip().splitlines()[0] if (text or "").strip() \
        else "(no message)"
    for sep in (": ", " — ", " - "):
        head = first.split(sep, 1)[0].strip()
        if head != first and len(head) >= 8:
            first = head
            break
    return first[:100]


class EmailAlertHandler(logging.Handler):
    """Logging handler that emails ERROR/CRITICAL records (throttled + digest)."""

    def __init__(self, notifier: EmailNotifier, settings: NotificationSettings,
                 clock_func: Callable[[], float] = time.time):
        super().__init__(level=settings.level_no)
        self.notifier = notifier
        self.s = settings
        self._clock = clock_func

        # throttle/dedup state: signature -> {window_start, suppressed}
        self._throttle: Dict[str, dict] = {}
        # digest accumulator: signature -> {count, level, sample, last_ts}
        self._digest: Dict[str, dict] = {}
        self._lock = threading.Lock()

        # Recursion guard: True on any thread currently sending an alert, so
        # log lines emitted during a send don't re-enter emit().
        self._guard = threading.local()

        # Async send pipeline (only used when async_send is on).
        self._sendq: "queue.Queue" = queue.Queue()
        self._stop = threading.Event()
        self._sender_thread: Optional[threading.Thread] = None
        self._digest_thread: Optional[threading.Thread] = None
        # Set by the application once the outage notices are active: the
        # errors they cover are then not e-mailed twice (E-13).
        self.dedicated_notices = False
        # Further checks (record -> True = do not e-mail), e.g. the
        # dispatcher's errors while the database outage notice is out.
        self.suppress_checks = []

        if self.s.async_send:
            self._sender_thread = threading.Thread(
                target=self._sender_loop, name="email-alert-sender", daemon=True
            )
            self._sender_thread.start()

        if self._digest_active():
            self._digest_thread = threading.Thread(
                target=self._digest_loop, name="email-alert-digest", daemon=True
            )
            self._digest_thread.start()

    # ── logging.Handler API ──────────────────────────────────────────

    def emit(self, record: logging.LogRecord) -> None:
        # Never let alerting raise into the bot.
        if getattr(self._guard, "active", False):
            return  # we're inside a send; ignore our own log lines (no recursion)
        try:
            if record.levelno < self.s.level_no:
                return
            self._handle(record)
        except Exception:
            # Standard handler contract: report internally, never propagate.
            self.handleError(record)

    def _digest_active(self) -> bool:
        if self.s.mode not in ("digest", "both"):
            return False
        schedule = getattr(self.s, "digest_schedule", "interval")
        if schedule == "off":
            return False
        if schedule == "interval":
            return self.s.digest_interval_seconds > 0
        return True

    def _suppressed(self, record: logging.LogRecord, text: str) -> bool:
        try:
            if self.dedicated_notices:
                key, _ = source_of(record)
                if any(key == src and text.startswith(start)
                       for src, start in DEDICATED):
                    return True
            return any(check(record) for check in self.suppress_checks)
        except Exception:
            return False

    def _handle(self, record: logging.LogRecord) -> None:
        sig = _signature(record)
        try:
            text = record.getMessage()
        except Exception:
            text = str(record.msg)
        now = self._clock()
        suppressed = self._suppressed(record, text)
        feed_digest = getattr(self.s, "digest_schedule", "interval") != "off"

        with self._lock:
            # Feed the digest (summary of everything seen).
            d = self._digest.get(sig) if feed_digest else {"count": 0}
            if d is None and feed_digest:
                self._digest[sig] = {
                    "count": 1, "level": record.levelname,
                    "sample": text, "last_ts": now,
                }
            elif feed_digest:
                d["count"] += 1
                d["sample"] = text
                d["last_ts"] = now

            # Throttle decision for real-time alerts.
            send_realtime = False
            suppressed_prev = 0
            if self.s.mode in ("realtime", "both") and not suppressed:
                st = self._throttle.get(sig)
                if st and (now - st["window_start"]) < self.s.throttle_window_seconds:
                    st["suppressed"] += 1            # within window → coalesce
                else:
                    suppressed_prev = st["suppressed"] if st else 0
                    self._throttle[sig] = {"window_start": now, "suppressed": 0}
                    send_realtime = True

        if send_realtime:
            subject = self._subject_for(record, text)
            body = self._body_for(record, text, suppressed_prev)
            context = self._context_for(record, text, suppressed_prev)
            self._dispatch(subject, body, context=context,
                           audience=source_of(record)[1])

    # ── email assembly ───────────────────────────────────────────────

    # Every text comes from config/email_messages.yaml (2026-09-29): a
    # readable subject and source instead of the raw log line and the
    # program's internal names (E-12).

    def _environment(self) -> str:
        env = getattr(self.notifier, "environment", None)
        return env() if callable(env) else str(self.s.environment_label or "")

    @staticmethod
    def _severity(record: logging.LogRecord):
        key = f"sev.{record.levelname}"
        return _m.pair(key) if _m.entry(key) else record.levelname

    def _subject_for(self, record: logging.LogRecord, text: str) -> str:
        return _m.subject("alert.subject", severity=self._severity(record),
                          summary=summary_of(text))

    @staticmethod
    def _time_of(record: logging.LogRecord) -> str:
        return datetime.fromtimestamp(record.created, JST).strftime(
            "%Y-%m-%d %H:%M:%S")

    def _rows(self, record: logging.LogRecord):
        key, _ = source_of(record)
        return [(_m.label("label.source"), _m.label(f"source.{key}")),
                (_m.label("label.time"), self._time_of(record))]

    def _body_for(self, record: logging.LogRecord, text: str,
                  suppressed_prev: int) -> str:
        parts = [f"{_m.value(self._severity(record))}: {summary_of(text)}",
                 rows_text(self._rows(record)),
                 f"{_m.label('label.message')}:\n{text}"]
        if suppressed_prev:
            parts.append(_m.text("alert.suppressed", count=suppressed_prev))
        parts.append(_m.text("footer.auto"))
        return "\n\n".join(parts)

    def _context_for(self, record: logging.LogRecord, text: str,
                     suppressed_prev: int) -> dict:
        """Structured fields for the branded HTML template (ignored when HTML off)."""
        msg_text = text
        if suppressed_prev:
            msg_text += "\n\n" + _m.text("alert.suppressed",
                                          count=suppressed_prev)
        ts = self._time_of(record)
        key, _ = source_of(record)
        severity = _m.value(self._severity(record))
        return {
            "severity": severity,
            "source": _m.label(f"source.{key}"),
            "timestamp": ts,
            "message_html": text_to_html(msg_text),
            "t_badge": severity,
            "t_heading": summary_of(text),
            "t_meta": f"{self._environment()} · {ts}",
            "rows_html": rows_html(self._rows(record)),
        }

    def _dispatch(self, subject: str, body: str, context: Optional[dict] = None,
                  is_digest: bool = False, audience: str = "") -> None:
        """Queue (async) or perform (sync) the actual send."""
        if self.s.async_send and self._sender_thread is not None:
            self._sendq.put((subject, body, context, is_digest, audience))
        else:
            self._do_send(subject, body, context, is_digest, audience)

    def _do_send(self, subject: str, body: str, context: Optional[dict] = None,
                 is_digest: bool = False, audience: str = "") -> None:
        """Actually transmit; swallow all failures (never affect the bot)."""
        self._guard.active = True
        try:
            # The team that owns the system is added to the default
            # recipients (Settings > E-mail > Recipients by system).
            to, cc = _audiences.route(audience, self.s.recipients_to,
                                      self.s.recipients_cc)
            extra = {"to": to, "cc": cc} if to else {}
            self.notifier.send(subject, body, context=context,
                               is_digest=is_digest, **extra)
        except NotificationError as e:
            # Log at WARNING (below the ERROR threshold) so this can never
            # re-trigger an alert. The guard above is a second line of defense.
            if self.notifier.logger:
                self.notifier.logger.warning(f"Email alert delivery failed: {e}")
        except Exception as e:
            if self.notifier.logger:
                self.notifier.logger.warning(f"Email alert unexpected error: {e}")
        finally:
            self._guard.active = False

    # ── background loops ─────────────────────────────────────────────

    def _sender_loop(self) -> None:
        # Drains the queue before it stops: alerts queued before close()
        # and the final digest are still sent (2026-09-28). The None
        # sentinel from close() comes after them.
        while True:
            try:
                item = self._sendq.get(timeout=0.5)
            except queue.Empty:
                if self._stop.is_set():
                    break
                continue
            if item is None:
                break
            self._do_send(*item)

    def _digest_wait(self) -> float:
        """Seconds until the next summary: hourly, daily at the set JST
        time, or the fixed interval (the earlier behaviour)."""
        schedule = getattr(self.s, "digest_schedule", "interval")
        if schedule == "hourly":
            return 3600.0
        if schedule == "daily":
            hour, minute = (int(x) for x in str(
                getattr(self.s, "digest_time", "09:00")).split(":"))
            now = now_jst()
            due = now.replace(hour=hour, minute=minute, second=0,
                              microsecond=0)
            if due <= now:
                due += timedelta(days=1)
            return max(1.0, (due - now).total_seconds())
        return float(self.s.digest_interval_seconds)

    def _digest_loop(self) -> None:
        while not self._stop.wait(self._digest_wait()):
            try:
                self.flush_digest()
            except Exception:
                pass

    def flush_digest(self) -> bool:
        """Send one summary email of everything accumulated since the last flush.

        Returns True if a digest was sent. Safe to call manually (e.g. on
        shutdown or in tests). No-op when nothing has accumulated.
        """
        with self._lock:
            if not self._digest:
                return False
            items = sorted(self._digest.values(), key=lambda d: d["count"], reverse=True)
            self._digest = {}

        total = sum(d["count"] for d in items)
        summary = _m.text("digest.summary", issues=len(items), total=total)

        issue_lines = []
        for d in items[: self.s.max_alerts_per_digest]:
            sample = d["sample"].strip().splitlines()[0] if d["sample"].strip() else ""
            issue_lines.append(f"  [{d['level']}] ×{d['count']}  {sample[:140]}")
        if len(items) > self.s.max_alerts_per_digest:
            issue_lines.append("  " + _m.text(
                "digest.more",
                count=len(items) - self.s.max_alerts_per_digest))

        stamp = datetime.fromtimestamp(self._clock(), JST).strftime(
            "%Y-%m-%d %H:%M:%S")
        as_of = _m.text("digest.as_of", timestamp=stamp)
        # Plain-text body (always the fallback).
        lines = [as_of, summary, ""]
        lines.extend(issue_lines)
        lines.append("\n" + _m.text("footer.auto"))

        # Structured fields for the branded HTML template (ignored when HTML off).
        subject = _m.subject("digest.subject", issues=len(items), total=total)
        context = {
            "timestamp": stamp,
            "message_html": text_to_html(summary + "\n" + "\n".join(issue_lines)),
            "t_badge": _m.label("sev.SUMMARY"),
            "t_heading": subject,
            "t_meta": f"{as_of.replace(chr(10), ' / ')} · "
                      f"{self._environment()}",
        }
        self._dispatch(subject, "\n".join(lines), context=context, is_digest=True)
        return True

    # ── shutdown ─────────────────────────────────────────────────────

    def close(self) -> None:
        try:
            # Final digest flush so nothing is lost on shutdown.
            # Final summary of what is left, whenever summaries are on.
            if self.s.mode in ("digest", "both") and getattr(
                    self.s, "digest_schedule", "interval") != "off":
                try:
                    self.flush_digest()
                except Exception:
                    pass
            self._stop.set()
            if self._sender_thread is not None:
                # Drain: one send timeout per queued e-mail, at most 60 s.
                budget = min(60.0, (self.s.timeout_seconds + 5)
                             * (self._sendq.qsize() + 1))
                self._sendq.put(None)
                self._sender_thread.join(timeout=budget)
            if self._digest_thread is not None:
                self._digest_thread.join(timeout=2)
        finally:
            super().close()


def attach_email_alerts(logger=None, config_path: Optional[str] = None,
                        environment: str = "") -> Optional[EmailAlertHandler]:
    """Wire email alerts onto the shared 'finesiii_rpa_v3' loggers.

    The SAME handler instance is attached to both "finesiii_rpa_v3" (app)
    and "finesiii_rpa_v3.rpa" (TransactionLogger; propagate=False), so
    ERROR lines from either stream reach email alerts.

    This is the SINGLE activation point. It is a safe no-op when notifications
    are disabled or misconfigured — so adding the call costs nothing until the
    operator sets the SMTP env vars and flips `enabled: true`.

    `environment` (optional; the caller passes cfg.mainframe_environment)
    overrides the YAML environment_label so alert subjects carry the real
    deployment environment.

    Returns the attached handler (so callers may flush/close it on shutdown), or
    None if alerts are not active.
    """
    try:
        settings = load_notification_config(config_path)
    except Exception as e:
        if logger:
            logger.warning(f"Email alerts: could not load config ({e}); alerts disabled.")
        return None

    # Allow the main config's environment to label alert subjects.
    if environment:
        settings.environment_label = str(environment)

    if not settings.enabled:
        if logger:
            logger.info("Email alerts: disabled (notifications.enabled is false).")
        return None

    try:
        settings.validate()
    except ValueError as e:
        if logger:
            logger.warning(f"Email alerts: {e} Alerts NOT activated.")
        return None

    notifier = EmailNotifier(settings, logger=logger)
    handler = EmailAlertHandler(notifier, settings)
    handler.setFormatter(logging.Formatter("%(message)s"))

    # Attach to BOTH named loggers the app and the RPA layer already use.
    for name in ALERT_LOGGER_NAMES:
        logging.getLogger(name).addHandler(handler)

    if logger:
        logger.info(f"Email alerts ACTIVE — {settings.masked()}")
    return handler
