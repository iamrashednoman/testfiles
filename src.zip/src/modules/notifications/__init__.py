"""Email notification integration for the FINESIII RPA service.

Port of v2 integrations/notifications. Decoupled, additive design —
mirrors the ServiceNow connector pattern:

  * The service code is NOT modified to "know about" email. Instead,
    an `EmailAlertHandler` (a standard logging.Handler) attaches to
    the existing shared loggers ("finesiii_rpa_v3" and the
    non-propagating "finesiii_rpa_v3.rpa"). Every component already
    calls logger.error(...) / logger.critical(...) on errors, so
    those events are fanned out to email automatically.

  * Secrets (SMTP password) come from environment variables, declared
    by name in config/notifications.yaml — exactly like the FINESIII_*
    and SNOW_* credentials.

  * Fail-safe by construction: a broken mail server can never block
    or crash the bot. Sends happen on a background thread and every
    failure is swallowed (logged locally on a separate,
    non-propagating logger to avoid recursion).

Nothing here runs unless `notifications.enabled` is true AND the SMTP
env vars are set. Disabled = zero behavior change.
"""
from src.modules.notifications.availability_alerts import (
    build_availability_alerter,
)
from src.modules.notifications.log_handler import attach_email_alerts
from src.modules.notifications.rejection_alerts import build_rejection_alerter
from src.modules.notifications.transaction_alerts import (
    build_transaction_alerter,
)

__all__ = [
    "attach_email_alerts",
    "build_availability_alerter",
    "build_rejection_alerter",
    "build_transaction_alerter",
]
