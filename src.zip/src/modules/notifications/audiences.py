"""Who receives the e-mails about each system (2026-09-29).

Each system has its own recipient lists, set on the console
(Settings > E-mail > Recipients by system), To and CC, any number of
addresses. A blank list means the default recipients only, so nothing
changes until a list is filled in.

The default recipients (operations / RPA support) always stay on the
e-mail as well: the team running the bot hears about every outage, and
the team that owns the system is added to it.

The lists are read when an e-mail is sent, so a change applies to the
next e-mail without a restart.
"""
from __future__ import annotations

import os
from typing import List, Optional, Tuple

OPERATIONS = "operations"
SERVICENOW = "servicenow"
CYBERARK = "cyberark"
FINESIII = "finesiii"
ACCOUNTS = "accounts"
DATABASE = "database"

# audience -> (To variable, CC variable)
ENV = {
    SERVICENOW: ("AUDIENCE_SERVICENOW_TO", "AUDIENCE_SERVICENOW_CC"),
    CYBERARK: ("AUDIENCE_CYBERARK_TO", "AUDIENCE_CYBERARK_CC"),
    FINESIII: ("AUDIENCE_FINESIII_TO", "AUDIENCE_FINESIII_CC"),
    ACCOUNTS: ("AUDIENCE_ACCOUNTS_TO", "AUDIENCE_ACCOUNTS_CC"),
    DATABASE: ("AUDIENCE_DATABASE_TO", "AUDIENCE_DATABASE_CC"),
}

# The team that owns each recognised error screen (config/errors.yaml
# rule id). A rule in notifications.yaml may name its own `audience`.
RULE_AUDIENCE = {
    "LOGIN_PASSWORD_INCORRECT": CYBERARK,
    "LOGIN_OPERATOR_NOT_REGISTERED": ACCOUNTS,
    "CENTER_NOT_READY": FINESIII,
}


def split_addresses(value) -> List[str]:
    """A list from 'a@x, b@x; c@x' (Outlook style) or a list."""
    if isinstance(value, (list, tuple)):
        items = value
    else:
        items = str(value or "").replace(";", ",").split(",")
    out = []
    for item in items:
        text = str(item).strip()
        if text and text not in out:
            out.append(text)
    return out


def lists(audience: str) -> Tuple[List[str], List[str]]:
    """(To, CC) set for this audience; both empty when not set."""
    names = ENV.get(audience)
    if not names:
        return [], []
    return (split_addresses(os.environ.get(names[0], "")),
            split_addresses(os.environ.get(names[1], "")))


def merge(first_to, first_cc, then_to, then_cc):
    """To and CC of two groups together, each address once (To wins)."""
    to = split_addresses(list(first_to or []) + list(then_to or []))
    cc = [a for a in split_addresses(list(first_cc or []) + list(then_cc or []))
          if a not in to]
    return to, cc


def route(audience: Optional[str], default_to, default_cc):
    """(to, cc) for EmailNotifier.send. (None, None) = the default
    recipients exactly as before (no list set for this audience)."""
    a_to, a_cc = lists(audience or "")
    if not a_to and not a_cc:
        return None, None
    to, cc = merge(a_to, a_cc, default_to, default_cc)
    return to, (cc or None)
