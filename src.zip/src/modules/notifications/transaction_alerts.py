"""
Transaction outcome notifications (Part B, Steps 11 / 12 / 13).

On every TERMINAL transaction outcome (fired from the dispatcher's
on_complete hook, after the audit record is written):

  provision success    → (a) the END USER receives an account-created email
                             with their login credentials — dedicated
                             template provision_user_credentials.html;
                         (b) SUPPORT TEAMS receive a success notice with the
                             full audit record — provision_success_ops.html.
  deprovision success  → SUPPORT TEAMS receive a confirmation with the full
                         tracking/audit record — deprovision_success_ops.html.
  failure (retries
  exhausted)           → SUPPORT TEAMS receive a failure notice with complete
                         error + compliance details — transaction_failure.html.

Design (mirrors availability_alerts):
  * DISABLED by default (transaction_notifications.enabled) → zero change.
  * Fire-and-forget send threads — SMTP can never stall the dispatcher.
  * Reuses EmailNotifier (retry/backoff, dry-run, redaction). Only the user
    credentials email uses redact_body=False, and only when
    include_password is true.
  * The user's address comes from request.metadata["user_email"], mapped
    from the ServiceNow ticket (field_mapping.user_email).
"""
from __future__ import annotations

import html as _html
import threading
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

import yaml

from src.core.app_paths import config_path, resource_path
from src.modules.notifications import audiences as _audiences
from src.modules.notifications import messages as _m
from src.modules.notifications.notifier import (
    EmailNotifier, NotificationDeferred, NotificationError, fmt_time,
    template, valid_address,
)
from src.modules.notifications.render import (
    rows_html, rows_text, text_to_html,
)

_TEMPLATES = resource_path("src", "modules", "notifications",
                           "templates")
PROVISION_USER_TEMPLATE = str(_TEMPLATES / "provision_user_credentials.html")
PROVISION_OPS_TEMPLATE = str(_TEMPLATES / "provision_success_ops.html")
DEPROVISION_OPS_TEMPLATE = str(_TEMPLATES / "deprovision_success_ops.html")
FAILURE_TEMPLATE = str(_TEMPLATES / "transaction_failure.html")

# Default location of the notifications YAML (<repo-root>/config/).
_DEFAULT_YAML_PATH = config_path("notifications.yaml")

# Terminal statuses that count as a completed (successful) operation.
# "already_deleted" is a successful deprovision outcome in FINESIII terms.
_SUCCESS_STATUSES = ("done", "already_deleted")

# Audit fields shown in the ops emails, in order: (label, TransactionRecord attr)
_AUDIT_FIELDS = [
    ("Transaction ID", "transaction_id"),
    ("Request ID", "request_id"),
    ("Ticket", "ticket_id"),
    ("Operation", "operation"),
    ("Affiliation code", "affiliation_code"),
    ("Employee code", "employee_code"),
    ("Source", "source"),
    ("Status", "status"),
    ("Result code", "result_code"),
    ("Attempts", "attempt_count"),
    ("Submitted (JST)", "submitted_at"),
    ("Started (JST)", "started_at"),
    ("Completed (JST)", "completed_at"),
    ("Duration (s)", "duration_seconds"),
    ("Worker", "worker_id"),
    # The evidence folder is a location on the bot machine, not for
    # e-mail readers (2026-09-28); it stays in the audit trail.
    ("Screenshots", "screenshot_count"),
    ("Operator", "operator"),
]


@dataclass
class ErrorAlertSettings:
    """The error_alerts block — per-error routing for FAILED requests.

    Keyed by the id of the config/errors.yaml rule that fired, so the
    team that owns an error hears about it directly instead of it
    landing in the one generic failure notice.
    """
    enabled: bool = False
    default_to: List[str] = field(default_factory=list)
    default_cc: List[str] = field(default_factory=list)
    rules: dict = field(default_factory=dict)

    def rule_for(self, error_id: str) -> Optional[dict]:
        """The routing rule for this error id, or None (→ the generic
        failure notice keeps its existing behaviour)."""
        if not self.enabled or not error_id:
            return None
        return self.rules.get(error_id)

    def recipients(self, rule: dict):
        """(to, cc) for a rule: its own lists, else the block defaults,
        else None → the notifier's main ALERT_TO list."""
        to = list(rule.get("to") or []) or list(self.default_to)
        cc = list(rule.get("cc") or []) or list(self.default_cc)
        return (to or None), (cc or None)


@dataclass
class TransactionNotificationSettings:
    """The transaction_notifications block of config/notifications.yaml."""
    enabled: bool = False
    notify_on_success: bool = True
    notify_on_failure: bool = True
    notify_on_rejection: bool = True     # Step 9 (used by rejection_alerts)
    send_user_credentials: bool = True
    include_password: bool = True
    user_email_metadata_key: str = "user_email"
    # Optional dedicated ops recipients; empty → the notifier's main list.
    ops_recipients_to: List[str] = field(default_factory=list)
    # Per-error routing (error_alerts block).
    error_alerts: ErrorAlertSettings = field(
        default_factory=ErrorAlertSettings)


def _env_list(var_name: Optional[str]) -> List[str]:
    """Comma-separated recipient list from the environment (same
    convention as ALERT_TO). Empty/unset → []."""
    import os
    if not var_name:
        return []
    return [a.strip() for a in
            os.environ.get(var_name, "").split(",") if a.strip()]


def load_transaction_notification_config(
        yaml_path: Optional[str] = None) -> TransactionNotificationSettings:
    """Read the transaction_notifications block (safe defaults if absent)."""
    if yaml_path is None:
        yaml_path = _DEFAULT_YAML_PATH
    yaml_path = Path(yaml_path)
    if not yaml_path.exists():
        return TransactionNotificationSettings()
    with open(yaml_path, "r", encoding="utf-8") as f:
        raw = yaml.safe_load(f) or {}
    notifications = raw.get("notifications", {}) or {}
    tn = notifications.get("transaction_notifications", {}) or {}

    # Console-managed switches (env names declared in notifications.env_vars,
    # 2026-09-26): an unset/blank variable leaves the YAML value in force.
    import os as _os
    top_env = notifications.get("env_vars", {}) or {}

    def _flag(env_key: str, default: bool) -> bool:
        raw = _os.environ.get(top_env.get(env_key, "") or "", "")
        if raw.strip() == "":
            return default
        return raw.strip().lower() in ("1", "true", "yes", "on")

    ea = notifications.get("error_alerts", {}) or {}
    env_names = ea.get("env_vars", {}) or {}
    error_alerts = ErrorAlertSettings(
        enabled=_flag("error_alerts_enabled", bool(ea.get("enabled", False))),
        # Env vars win over the YAML lists, exactly like ALERT_TO —
        # addresses are deployment data, never committed config.
        default_to=(_env_list(env_names.get("recipients_to"))
                    or list(ea.get("default_to", []) or [])),
        default_cc=(_env_list(env_names.get("recipients_cc"))
                    or list(ea.get("default_cc", []) or [])),
        rules={str(k): (v or {}) for k, v in
               (ea.get("rules", {}) or {}).items()},
    )

    return TransactionNotificationSettings(
        error_alerts=error_alerts,
        enabled=_flag("txn_enabled", bool(tn.get("enabled", False))),
        notify_on_success=bool(tn.get("notify_on_success", True)),
        notify_on_failure=bool(tn.get("notify_on_failure", True)),
        notify_on_rejection=bool(tn.get("notify_on_rejection", True)),
        send_user_credentials=_flag(
            "txn_send_user_credentials",
            bool(tn.get("send_user_credentials", True))),
        # Default OFF (D15, 2026-09-26) — the YAML ships false; the env
        # switch is the console's "include the initial password" toggle.
        include_password=_flag("txn_include_password",
                               bool(tn.get("include_password", False))),
        user_email_metadata_key=tn.get("user_email_metadata_key", "user_email"),
        ops_recipients_to=list(tn.get("ops_recipients_to", []) or []),
    )


def _esc(value) -> str:
    return _html.escape(str(value if value is not None else ""))


_TIME_FIELDS = ("submitted_at", "started_at", "completed_at")


def audit_rows(txn) -> list:
    """The transaction record as (label, value) rows, in the language in
    force; times in JST. An empty field shows "-" (the record is shown
    complete)."""
    rows = []
    for _label, attr in _AUDIT_FIELDS:
        value = getattr(txn, attr, "")
        if attr in _TIME_FIELDS:
            value = fmt_time(value)
        elif attr == "duration_seconds" and value not in (None, ""):
            try:
                value = f"{float(value):.1f}"     # 28.8, not 28.847848 (E2E-L10)
            except (TypeError, ValueError):
                pass
        text = "" if value is None else str(value)
        rows.append((_m.field_label(attr), text or "-"))
    return rows


def build_audit_rows_html(txn) -> str:
    """Render the FULL audit record as table rows (all compliance fields)."""
    return rows_html(audit_rows(txn), mono=True)


def build_audit_text(txn) -> str:
    """Plain-text audit record (the always-present text/plain part)."""
    return rows_text(audit_rows(txn))


# Fingerprints of the rule texts shipped in notifications.yaml before the
# wording file (2026-09-29). Such a text is replaced by the wording file
# (Japanese / English); a text the client wrote is used as written.
_SHIPPED_RULE_TEXTS = {
    "a80f4a580da732d2", "ed3f1a44a63fd64f", "f5939e9f6e29f094",
    "c889d625e592b148", "e52883e91685e45a", "a85859d807341e07",
}


def _own_text(value) -> str:
    """A rule's subject / action as the client wrote it, or "" when it
    is blank or the text shipped earlier."""
    import hashlib
    text = " ".join(str(value or "").split())
    if not text:
        return ""
    digest = hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]
    return "" if digest in _SHIPPED_RULE_TEXTS else text


def compose_text(*parts) -> str:
    """Plain-text body from headings, paragraphs and blocks (blank parts
    skipped), separated by empty lines."""
    return "\n\n".join(str(p).strip("\n") for p in parts
                        if p not in (None, "") and str(p).strip())


class TransactionAlerter:
    """Routes terminal transaction outcomes to the dedicated emails."""

    def __init__(self, notifier: EmailNotifier,
                 settings: TransactionNotificationSettings,
                 bot_config: Optional[dict] = None, logger=None,
                 async_send: bool = True):
        self.notifier = notifier
        self.s = settings
        self.bot_config = bot_config or {}
        self.logger = logger
        self.async_send = async_send

    # ── dispatcher hook (single entry point) ───────────────────────

    def handle_completion(self, txn, request, result):
        """Called by the dispatcher AFTER the audit record is written.
        Never raises — a notification problem must never affect dispatch."""
        try:
            self._route(txn, request, result)
        except Exception as e:
            if self.logger:
                self.logger.warning(f"Transaction notification failed to route: {e}")

    # Set by the application when the SailPoint ticket e-mails are active
    # (2026-09-28): their support report and user notices then replace
    # the success e-mails below for SailPoint tickets.
    ticket_reports_active = False

    def _route(self, txn, request, result):
        success = str(txn.status).lower() in _SUCCESS_STATUSES

        if success and not self.s.notify_on_success:
            return
        if not success and not self.s.notify_on_failure:
            return

        # Submitted but the result could not be read: never "completed",
        # never "your account is ready" — a person must verify
        # (2026-09-28, all sources).
        if success and str(getattr(txn, "result_code", "")).upper() == "UNCONFIRMED":
            self._send_verification(txn)
            return

        meta = getattr(request, "metadata", None) if request is not None else None
        sailpoint = isinstance(meta, dict) and meta.get("category") in (
            "new_account", "access_removal", "entitlement_certification",
            "account_certification", "transfer", "termination",
            "access_request", "certification")
        if success and sailpoint and self.ticket_reports_active:
            return

        if not success:
            # A recognised error screen routes to the team that owns it
            # (config/notifications.yaml -> error_alerts). That email
            # REPLACES the generic failure notice — no duplicate mail.
            # Errors with no routing rule keep the generic notice.
            error_id = str((result or {}).get("error_id") or "")
            rule = self.s.error_alerts.rule_for(error_id)
            if rule is not None:
                self._send_error_alert(txn, error_id, rule, result or {})
            else:
                self._send_failure(txn)
        elif txn.operation == "provision":
            self._send_provision_ops(txn)
            if self.s.send_user_credentials:
                self._send_user_credentials(txn, request)
        else:
            self._send_deprovision_ops(txn)

    # ── the e-mails ────────────────────────────────────────────────
    # Every text comes from config/email_messages.yaml (2026-09-29); the
    # designs are the Japanese / English ones (templates/i18n).

    def _ops_to(self) -> Optional[List[str]]:
        """Dedicated ops recipients, or None → the notifier's main list."""
        return self.s.ops_recipients_to or None

    @staticmethod
    def _ref(txn) -> str:
        return txn.ticket_id or txn.request_id

    def _record_context(self, txn) -> dict:
        return {"ticket_id": self._ref(txn),
                "audit_rows_html": build_audit_rows_html(txn),
                "t_label_record": _m.label("label.record")}

    def _send_provision_ops(self, txn):
        ref = self._ref(txn)
        heading = _m.label("txn.prov.heading", ref=ref)
        intro = _m.text("txn.prov.intro")
        note = _m.text("txn.note.history")
        self._dispatch(
            subject=_m.subject("txn.prov.subject", ref=ref),
            body=compose_text(heading, intro, _m.label("label.record"),
                              build_audit_text(txn), note),
            to=self._ops_to(),
            context=dict(self._record_context(txn),
                         t_badge=_m.label("txn.prov.badge"),
                         t_heading=heading,
                         t_intro_html=text_to_html(intro),
                         t_note_html=text_to_html(note),
                         severity="SUCCESS", source="dispatcher"),
            template_path=template("provision_success_ops.html"),
            kind="provision_ops",
        )

    def _send_deprovision_ops(self, txn):
        ref = self._ref(txn)
        note_key = ("txn.deprov.already"
                    if str(txn.status).lower() == "already_deleted"
                    else "txn.deprov.deleted")
        status_note = _m.text(note_key)
        heading = _m.label("txn.deprov.heading", ref=ref)
        history = _m.text("txn.note.history")
        self._dispatch(
            subject=_m.subject("txn.deprov.subject", ref=ref),
            body=compose_text(heading, status_note, _m.label("label.record"),
                              build_audit_text(txn), history),
            to=self._ops_to(),
            context=dict(self._record_context(txn),
                         status_note=status_note,
                         t_badge=_m.label("txn.deprov.badge"),
                         t_heading=heading,
                         t_intro_html=text_to_html(status_note),
                         t_note_html=text_to_html(history),
                         severity="SUCCESS", source="dispatcher"),
            template_path=template("deprovision_success_ops.html"),
            kind="deprovision_ops",
        )

    def _send_verification(self, txn):
        # What happened after the '70' (code read, step that failed), so
        # the operator knows what to check (NB-013). Its own design: the
        # request must NOT be retried (2026-09-29, E-02).
        ref = self._ref(txn)
        recorded = str(getattr(txn, "error_message", "") or "").strip()
        detail = recorded or _m.text("txn.unconf.default_detail")
        heading = _m.label("txn.unconf.heading", ref=ref)
        intro = _m.text("txn.unconf.intro")
        note = _m.text("txn.note.evidence")
        self._dispatch(
            subject=_m.subject("txn.unconf.subject", ref=ref),
            body=compose_text(heading, intro,
                              (f"{_m.label('label.detail')}: {recorded}"
                               if recorded else ""),
                              _m.label("label.record"),
                              build_audit_text(txn), note),
            to=self._ops_to(),
            context=dict(self._record_context(txn),
                         attempts=str(txn.attempt_count),
                         error_html=text_to_html(detail),
                         t_badge=_m.label("sev.REVIEW"),
                         t_heading=heading,
                         t_intro_html=text_to_html(intro),
                         t_label_detail=_m.label("label.detail"),
                         t_note_html=text_to_html(note),
                         severity="REVIEW", source="dispatcher"),
            template_path=template("result_unconfirmed.html"),
            kind="result_unconfirmed",
        )

    def _send_failure(self, txn):
        ref = self._ref(txn)
        error_text = txn.error_message or _m.text("txn.no_error")
        heading = _m.label("txn.fail.heading", ref=ref,
                           attempts=txn.attempt_count)
        intro = _m.text("txn.fail.intro")
        note = _m.text("txn.note.evidence")
        self._dispatch(
            subject=_m.subject("txn.fail.subject", ref=ref),
            body=compose_text(heading, intro,
                              f"{_m.label('label.error')}: {error_text}",
                              _m.label("label.record"),
                              build_audit_text(txn), note),
            to=self._ops_to(),
            context=dict(self._record_context(txn),
                         attempts=str(txn.attempt_count),
                         error_html=text_to_html(error_text),
                         t_badge=_m.label("sev.ACTION"),
                         t_heading=heading,
                         t_intro_html=text_to_html(intro),
                         t_label_error=_m.label("label.error"),
                         t_note_html=text_to_html(note),
                         severity="FAILURE", source="dispatcher"),
            template_path=template("transaction_failure.html"),
            kind="transaction_failure",
        )

    def _error_recipients(self, error_id: str, rule: dict):
        """The rule's own lists (notifications.yaml) first; else the team
        that owns the error (Settings > E-mail > Recipients by system)
        together with the error-alert or default recipients; else the
        error-alert recipients as before."""
        ea = self.s.error_alerts
        if rule.get("to") or rule.get("cc"):
            return ea.recipients(rule)
        audience = str(rule.get("audience") or
                       _audiences.RULE_AUDIENCE.get(error_id, ""))
        a_to, a_cc = _audiences.lists(audience)
        if a_to or a_cc:
            base_to = list(ea.default_to) or list(self.notifier.s.recipients_to)
            base_cc = (list(ea.default_cc) if ea.default_to or ea.default_cc
                       else list(self.notifier.s.recipients_cc))
            to, cc = _audiences.merge(a_to, a_cc, base_to, base_cc)
            return (to or None), (cc or None)
        return ea.recipients(rule)

    def _send_error_alert(self, txn, error_id: str, rule: dict,
                          result: dict):
        """Dedicated notice for a recognised error screen (Case 1/2 …).

        Carries WHAT the bot saw, WHERE, how many attempts it made, and
        what the receiving team is expected to do — so the mail is
        actionable on its own, without an audit-trail dive.
        """
        to, cc = self._error_recipients(error_id, rule)
        ref = self._ref(txn)
        own_subject = _own_text(rule.get("subject"))
        own_action = _own_text(rule.get("action_required"))
        if own_subject:
            subject = own_subject
        elif _m.entry(f"rule.{error_id}.subject"):
            subject = _m.subject(f"rule.{error_id}.subject")
        else:
            subject = _m.subject("txn.err.default_subject", error_id=error_id)
        if own_action:
            action = own_action
        elif _m.entry(f"rule.{error_id}.action"):
            action = _m.text(f"rule.{error_id}.action")
        else:
            action = ""

        detections = [e for e in (result.get("error_trace") or [])
                      if e.get("error_id") == error_id]
        seen = detections[0] if detections else {}
        screen = seen.get("screen") or "-"
        step = seen.get("step") or result.get("failed_step") or "-"
        matched = ", ".join(seen.get("matched") or []) or "-"
        captured = seen.get("captured") or {}

        rows = [
            (_m.label("txn.err.label.error"), error_id),
            (_m.label("txn.err.label.step"), step),
            (_m.label("txn.err.label.screen"), screen),
            (_m.label("txn.err.label.matched"), matched),
            (_m.label("txn.err.label.attempts"), str(txn.attempt_count)),
        ]
        for key, value in captured.items():
            rows.append((_m.label("txn.err.label.diagnostic", name=key),
                         value))
        # Values the bot SUBMITTED, as separate labelled data points.
        # Several FINESIII screens report one message for more than one
        # cause (a bad staff code and a bad affiliation code both give
        # オペレーターコード未登録です), so the team needs every value to
        # judge which is wrong — the bot never guesses. Secrets are
        # never placed in the context by the callers.
        context = seen.get("context") or {}
        if context:
            rows.append((_m.label("txn.err.label.submitted"),
                         "\n".join(f"{_m.field_label(k)}: {v}"
                                   for k, v in context.items())))
        details = rows_text(rows)

        heading = _m.label("txn.err.heading", ref=ref)
        intro = _m.text("txn.err.intro", attempts=txn.attempt_count)
        note = _m.text("txn.err.note")
        body = compose_text(
            heading, intro, _m.label("label.what_bot_saw"), details,
            (f"{_m.label('label.action_required')}: {action}"
             if action else ""),
            _m.label("label.record"), build_audit_text(txn), note)

        self._dispatch(
            subject=f"{subject} — {ref}",
            body=body,
            to=to,
            context=dict(self._record_context(txn),
                         error_id=error_id, error_screen=screen,
                         error_step=step, error_matched=matched,
                         attempts=str(txn.attempt_count),
                         action_required=action,
                         action_html=text_to_html(action),
                         error_html=text_to_html(txn.error_message or error_id),
                         detail_html=text_to_html(details),
                         rows_html=rows_html(rows, mono=True),
                         t_badge=error_id,
                         t_heading=heading,
                         t_intro_html=text_to_html(intro),
                         t_label_seen=_m.label("label.what_bot_saw"),
                         t_label_action=_m.label("label.action_required"),
                         t_note_html=text_to_html(note),
                         severity="FAILURE", source="screen-error",
                         cc=", ".join(cc or [])),
            template_path=(str(_TEMPLATES / str(rule["template"]))
                           if rule.get("template")
                           else template("error_screen_alert.html")),
            # The rule's CC is delivered, not only printed (2026-09-28).
            cc=cc,
            kind="error_alert",
        )
        if self.logger:
            self.logger.info(
                f"Error alert routed for {error_id} "
                f"({ref}) to {to or 'default recipients'}")

    def _send_user_credentials(self, txn, request):
        """Account-created email to the end user (Step 11). The initial
        password never travels in it: when it is sent, it goes in a
        SEPARATE e-mail with the client's password notice (2026-09-29,
        same rule as the SailPoint tickets)."""
        user_email = ""
        if request is not None and isinstance(request.metadata, dict):
            user_email = str(
                request.metadata.get(self.s.user_email_metadata_key, "") or ""
            ).strip()
        if not user_email:
            if self.logger:
                self.logger.info(
                    f"User credentials email skipped for {txn.ticket_id or txn.request_id}: "
                    f"no user email on the request (metadata key "
                    f"'{self.s.user_email_metadata_key}')"
                )
            return
        if not valid_address(user_email):
            # An address from a ticket is data, not trusted (2026-09-28).
            if self.logger:
                self.logger.warning(
                    f"User credentials email skipped for "
                    f"{txn.ticket_id or txn.request_id}: the user e-mail "
                    f"address {EmailNotifier._mask_address(user_email)!r} is "
                    f"not valid")
            return

        password = ""
        if self.s.include_password:
            password = (request.password or "").strip() if request else ""
            if not password:
                password = str(
                    self.bot_config.get("defaults", {}).get("initial_password", "")
                )
        ref = txn.ticket_id or "-"
        note = _m.label("user.password.separate" if password
                        else "user.password.later")
        rows = [(_m.label("user.label.affiliation"), txn.affiliation_code),
                (_m.label("user.label.application"), txn.employee_code),
                (_m.label("user.label.password"), note),
                (_m.label("user.label.completed"), fmt_time(txn.completed_at))]
        heading = _m.label("user.heading")
        intro = _m.text("user.intro", ref=ref)
        note_text = _m.text("user.note.text")
        body = compose_text(heading, intro, rows_text(rows),
                            f"{_m.label('user.note.title')}: {note_text}")
        border = "border-bottom:1px solid #e6e6e6;"
        self._dispatch(
            subject=_m.subject("user.subject", ref=txn.ticket_id or "").strip(" —"),
            body=body,
            to=[user_email],
            context={"ticket_id": ref,
                     "affiliation_code": txn.affiliation_code,
                     "employee_code": txn.employee_code,
                     # The earlier design's password row (fallback).
                     "password_row_html": (
                         f'<tr><td style="padding:10px 14px;background:#f5f7f9;'
                         f'color:#5d738d;{border}"><strong>'
                         f'{_esc(_m.label("user.label.password"))}</strong></td>'
                         f'<td style="padding:10px 14px;{border}">{_esc(note)}'
                         f'</td></tr>'),
                     "completed_at": fmt_time(txn.completed_at),
                     "rows_html": rows_html(rows),
                     "t_badge": _m.label("user.badge"),
                     "t_heading": heading,
                     "t_intro_html": text_to_html(intro),
                     "t_note_title": _m.label("user.note.title"),
                     "t_note_html": text_to_html(note_text),
                     "severity": "INFO", "source": "dispatcher"},
            template_path=template("provision_user_credentials.html"),
            # The body carries no secret; the generic masking would garble
            # the "Initial password: …" line (2026-09-28). The request's
            # password is masked should it ever appear.
            redact_body=False,
            kind="user_account_ready",
            mask=[password],
        )
        if password:
            self._send_password_notice(txn, request, user_email, password)

    def _send_password_notice(self, txn, request, user_email, password):
        """The initial password alone, in the client's password notice
        (config/email_templates/user_password.txt). Never kept in the
        outbox: when it cannot be sent, the failure is logged."""
        from src.modules.notifications.ticket_reports import (
            NOTICE_TEMPLATE, load_template, load_ticket_report_config,
            render,
        )
        settings = load_ticket_report_config()
        subject, body = load_template(settings, "user_password")
        ctx = {"ffm_id": txn.employee_code, "password": password,
               "contact_email": settings.contact_email,
               "affiliation_code": txn.affiliation_code,
               "ticket_id": txn.ticket_id or ""}
        self._dispatch(
            subject=render(subject, ctx), body=render(body, ctx),
            to=[user_email], context={},
            template_path=NOTICE_TEMPLATE, redact_body=False,
            kind="user_password", raw_subject=True, persist=False,
        )

    # ── transport ──────────────────────────────────────────────────

    def _dispatch(self, subject, body, to, context, template_path,
                  redact_body: bool = True, cc=None, kind: str = "",
                  mask=(), raw_subject: bool = False, persist: bool = True):
        for secret in mask or ():
            if secret:
                subject = subject.replace(secret, "***")
                body = body.replace(secret, "***")
        args = (subject, body, to, context, template_path, redact_body, cc,
                kind, raw_subject, persist)
        if self.async_send:
            threading.Thread(target=self._send, args=args,
                             name="transaction-alert", daemon=True).start()
        else:
            self._send(*args)

    def _send(self, subject, body, to, context, template_path, redact_body,
              cc=None, kind="", raw_subject=False, persist=True):
        # Optional arguments only when used: any sender with the earlier
        # signature keeps working.
        extra = {}
        if cc:
            extra["cc"] = list(cc)
        if kind:
            extra["kind"] = kind
        if raw_subject:
            extra["raw_subject"] = True
        if not persist:
            extra["persist"] = False
        try:
            self.notifier.send(subject, body, to=to, context=context,
                               template_path=template_path,
                               redact_body=redact_body, **extra)
        except NotificationDeferred as e:
            if self.logger:
                self.logger.warning(f"Transaction email deferred: {e}")
        except NotificationError as e:
            if self.logger:
                self.logger.warning(f"Transaction email failed: {e}")
        except Exception as e:   # never take the dispatcher down
            if self.logger:
                self.logger.warning(f"Transaction email unexpected error: {e}")


def build_transaction_alerter(alert_handler, bot_config=None, logger=None,
                              yaml_path=None) -> Optional[TransactionAlerter]:
    """Service-startup helper (mirrors build_availability_alerter).
    Returns None unless BOTH email notifications and
    transaction_notifications.enabled are active."""
    if alert_handler is None:
        if logger:
            logger.info(
                "Transaction notifications: inactive (email notifications disabled)"
            )
        return None
    settings = load_transaction_notification_config(yaml_path)
    if not settings.enabled:
        if logger:
            logger.info(
                "Transaction notifications: disabled "
                "(transaction_notifications.enabled is false)"
            )
        return None
    if logger:
        logger.info(
            f"Transaction notifications: ACTIVE (user credentials email: "
            f"{settings.send_user_credentials}, include password: "
            f"{settings.include_password})"
        )
    return TransactionAlerter(alert_handler.notifier, settings,
                              bot_config=bot_config, logger=logger)
