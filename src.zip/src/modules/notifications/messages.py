"""E-mail wording in Japanese and English (2026-09-29).

Every subject, heading, label and sentence of the e-mails the service
writes itself comes from config/email_messages.yaml, so the wording is
edited there and never in code. The client's own .txt templates are not
affected.

The language comes from the console setting EMAIL_LANGUAGE:
  ja_en  both, in the same e-mail (default)
  ja     Japanese only
  en     English only

With ja_en a label reads "ja / en" and a sentence is the Japanese line
followed by the English line; an entry may give its own "ja_en" text.
Context values may themselves be {"ja": …, "en": …} (a system name, a
badge); each language then takes its own.

The file is re-read when it changes (no restart). When the edited copy
lacks an entry, the copy shipped with the application is used, so an
e-mail is never sent without wording.
"""
from __future__ import annotations

import os
import threading
from pathlib import Path
from typing import Optional

import yaml

from src.core.app_paths import config_path, resource_path

LANGUAGES = ("ja_en", "ja", "en")
DEFAULT_LANGUAGE = "ja_en"
FILE_NAME = "email_messages.yaml"

_lock = threading.Lock()
_cache: dict = {}          # path -> (mtime, messages, language)
# A language for the current thread only (the console's e-mail preview),
# so a preview never changes the language of the e-mails being sent.
_local = threading.local()


class use_language:
    """with use_language("ja"): … — this thread only."""

    def __init__(self, lang: Optional[str]):
        self.lang = (lang or "").strip().lower()

    def __enter__(self):
        self.previous = getattr(_local, "lang", "")
        if self.lang in LANGUAGES:
            _local.lang = self.lang
        return self

    def __exit__(self, *exc):
        _local.lang = self.previous
        return False


class _Blank(dict):
    def __missing__(self, key):
        return ""


def _read(path: Path):
    try:
        mtime = path.stat().st_mtime
    except OSError:
        return {}, ""
    with _lock:
        hit = _cache.get(str(path))
        if hit and hit[0] == mtime:
            return hit[1], hit[2]
    try:
        with open(path, "r", encoding="utf-8") as f:
            raw = (yaml.safe_load(f) or {}).get("email_messages", {}) or {}
        messages = {str(k): v for k, v in (raw.get("messages") or {}).items()
                    if isinstance(v, dict)}
        language = str(raw.get("language") or "").strip().lower()
    except Exception:
        messages, language = {}, ""
    with _lock:
        _cache[str(path)] = (mtime, messages, language)
    return messages, language


def _sources():
    """The edited copy first, then the copy shipped with the application."""
    edited = config_path(FILE_NAME)
    shipped = resource_path("config", FILE_NAME)
    return [edited] if edited == shipped else [edited, shipped]


def entry(key: str) -> dict:
    for path in _sources():
        messages, _ = _read(Path(path))
        if key in messages:
            return messages[key]
    return {}


def language() -> str:
    """The language in force: the console setting, else the file's
    default, else Japanese and English."""
    value = getattr(_local, "lang", "")
    if value in LANGUAGES:
        return value
    value = os.environ.get("EMAIL_LANGUAGE", "").strip().lower()
    if value in LANGUAGES:
        return value
    for path in _sources():
        _, lang = _read(Path(path))
        if lang in LANGUAGES:
            return lang
    return DEFAULT_LANGUAGE


def _fill(text: str, lang: str, ctx: dict) -> str:
    values = _Blank()
    for k, v in (ctx or {}).items():
        if isinstance(v, dict) and ("ja" in v or "en" in v):
            v = v.get(lang) or v.get("en") or v.get("ja") or ""
        values[k] = "" if v is None else v
    try:
        return str(text).format_map(values)
    except (ValueError, IndexError, KeyError, AttributeError):
        return str(text).replace("{", "").replace("}", "")


def one(key: str, lang: str, **ctx) -> str:
    """The text of one language ('ja' or 'en'), filled."""
    e = entry(key)
    text = e.get(lang) or e.get("en") or e.get("ja") or ""
    return _fill(text, lang, ctx)


def pair(key: str, **ctx) -> dict:
    """{"ja": …, "en": …} — for use as a context value elsewhere."""
    return {"ja": one(key, "ja", **ctx), "en": one(key, "en", **ctx)}


def _combine(key: str, joiner: str, lang: Optional[str], ctx: dict) -> str:
    lang = lang or language()
    if lang in ("ja", "en"):
        return one(key, lang, **ctx)
    e = entry(key)
    if e.get("ja_en"):
        # Context values show both languages inside an explicit ja_en text.
        both = {k: (_both_inline(v) if isinstance(v, dict)
                    and ("ja" in v or "en" in v) else v)
                for k, v in (ctx or {}).items()}
        return _fill(e["ja_en"], "ja", both)
    ja, en = one(key, "ja", **ctx), one(key, "en", **ctx)
    if not ja or ja == en:
        return en
    if not en:
        return ja
    return f"{ja}{joiner}{en}"


def _both_inline(value: dict) -> str:
    ja, en = value.get("ja") or "", value.get("en") or ""
    if not ja or ja == en:
        return en
    return f"{ja} / {en}" if en else ja


def label(key: str, lang: Optional[str] = None, **ctx) -> str:
    """A label or short phrase: 'ja / en' when both are sent."""
    return _combine(key, " / ", lang, ctx)


def subject(key: str, lang: Optional[str] = None, **ctx) -> str:
    return _combine(key, " / ", lang, ctx)


def text(key: str, lang: Optional[str] = None, **ctx) -> str:
    """A sentence or paragraph: the Japanese line, then the English one."""
    return _combine(key, "\n", lang, ctx)


def value(v, lang: Optional[str] = None) -> str:
    """A {"ja","en"} context value shown in the language in force."""
    if not (isinstance(v, dict) and ("ja" in v or "en" in v)):
        return "" if v is None else str(v)
    lang = lang or language()
    if lang in ("ja", "en"):
        return v.get(lang) or v.get("en") or v.get("ja") or ""
    return _both_inline(v)


def paragraph(v, lang: Optional[str] = None) -> str:
    """A {"ja","en"} sentence in the language in force; both languages
    on separate lines (Japanese first)."""
    if not (isinstance(v, dict) and ("ja" in v or "en" in v)):
        return "" if v is None else str(v)
    lang = lang or language()
    if lang in ("ja", "en"):
        return v.get(lang) or v.get("en") or v.get("ja") or ""
    ja, en = v.get("ja") or "", v.get("en") or ""
    if not ja or ja == en:
        return en
    return f"{ja}\n{en}" if en else ja


def field_label(name: str, lang: Optional[str] = None) -> str:
    """Label of a data field; unknown fields read as their name."""
    if entry(f"field.{name}"):
        return label(f"field.{name}", lang)
    return str(name).replace("_", " ").capitalize()
