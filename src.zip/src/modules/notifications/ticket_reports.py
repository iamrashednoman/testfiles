"""E-mails for SailPoint tickets (process design, 2026-09-28).

  Support report   Template 1 ("FINESIIIアカウント登録報告"), ONCE per
                   ticket, when every affiliation code of the ticket has
                   finished: the action (登録 / 削除), the requester
                   (申請者), the target person with each code and name,
                   and the result of each code (success, already
                   removed, needs verification, failed, cancelled).
  Registration     Template 2 without the password, to the new user,
  notice           after each successful registration.
  Password notice  The initial password in a SEPARATE e-mail to the same
                   user (credentials and password never travel together).

The templates are client-owned plain-text files (first line "Subject: …",
sent exactly as written). Recipients and switches come from the Email
settings page. A user without an e-mail address receives nothing — no
password is ever sent elsewhere — and the support report says so.

Runs from the dispatcher's completion hook on a background thread, never
raises into the dispatcher and never changes an outcome. Every e-mail is
recorded in the audit trail by the notifier. What was sent is recorded
on the request, so nothing is sent twice.
"""
from __future__ import annotations

import os
import threading
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Callable, List, Optional

import yaml

from src.core.app_paths import config_path
from src.core.app_paths import resource_path
from src.modules.notifications import messages as _m
from src.modules.notifications.notifier import (
    EmailNotifier, NotificationDeferred, NotificationError, valid_address,
)

# The branded frame the client's plain-text wording is shown in when HTML
# e-mail is on (2026-09-28). The wording itself stays in the client's
# .txt templates; the plain-text part is sent exactly as written.
NOTICE_TEMPLATE = str(resource_path("src", "modules", "notifications",
                                    "templates", "notice.html"))

SAILPOINT_KINDS = ("new_account", "access_removal",
                   "entitlement_certification", "account_certification",
                   "transfer", "termination",
                   # recorded before the six request types existed
                   "access_request", "certification")
KIND_LABELS = {
    "new_account": "New Account Provisioning",
    "access_removal": "Access Removal",
    "entitlement_certification": "Entitlement Certification",
    "account_certification": "Account Certification",
    "transfer": "Transfer",
    "termination": "Termination",
    "access_request": "Access Request",
    "certification": "Certification",
}
_TERMINAL = ("done", "already_deleted", "failed", "cancelled")
NO_ADDRESS = "no e-mail address found for the user"
INVALID_ADDRESS = "invalid e-mail address"
REPORT_MARK = "support_report_sent"
NOTICE_MARK = "user_notices_sent"
_JST = timezone(timedelta(hours=9))

_FALLBACK = {
    "support_report": ("FINESIIIアカウント登録報告({date})",
                       "以下のFINESIIIアカウントの{action}を行いました。\n\n"
                       "＜申請対象者＞\n{targets}\n\n＜処理結果＞\n{results}\n"),
    "user_registration": ("[Notice] New Registration of FINES III Account",
                          "Department Code: {affiliation_code} "
                          "{affiliation_name}\nFFM Application ID: {ffm_id}\n"
                          "Password: sent to you in a separate e-mail.\n"),
    "user_password": ("[Notice] Initial Password of FINES III Account",
                      "FFM Application ID: {ffm_id}\nPassword: {password}\n"
                      "The password is valid for three (3) days.\n"),
}


class _Blank(dict):
    def __missing__(self, key):
        return ""


def render(text: str, context: dict) -> str:
    try:
        return str(text).format_map(_Blank(context))
    except (ValueError, IndexError, KeyError, AttributeError):
        return str(text).replace("{", "").replace("}", "")


@dataclass
class TicketReportSettings:
    txn_enabled: bool = False              # "Transaction outcome e-mails"
    report_enabled: bool = True            # support report
    recipients_to: List[str] = field(default_factory=list)
    recipients_cc: List[str] = field(default_factory=list)
    contact_email: str = ""
    send_registration: bool = True         # TXN_SEND_USER_CREDENTIALS
    send_password: bool = False            # TXN_INCLUDE_PASSWORD
    templates: dict = field(default_factory=dict)


def _csv(value) -> List[str]:
    if isinstance(value, (list, tuple)):
        return [str(v).strip() for v in value if str(v).strip()]
    return [p.strip() for p in str(value or "").split(",") if p.strip()]


def _flag(name: str, default: bool) -> bool:
    raw = os.environ.get(name, "")
    if raw.strip() == "":
        return default
    return raw.strip().lower() in ("1", "true", "yes", "on")


def load_ticket_report_config(yaml_path: Optional[str] = None) -> TicketReportSettings:
    """The ticket e-mail settings: YAML defaults, overridden by the
    values saved on the Email settings page (environment)."""
    path = Path(yaml_path) if yaml_path else config_path("notifications.yaml")
    raw = {}
    if path.is_file():
        with open(path, "r", encoding="utf-8") as f:
            raw = (yaml.safe_load(f) or {}).get("notifications", {}) or {}
    tr = raw.get("ticket_reports", {}) or {}
    from src.modules.notifications.transaction_alerts import (
        load_transaction_notification_config,
    )
    txn = load_transaction_notification_config(str(path) if path.is_file() else None)
    return TicketReportSettings(
        txn_enabled=txn.enabled,
        report_enabled=_flag("SUPPORT_REPORT_ENABLED",
                             bool(tr.get("enabled", True))),
        recipients_to=(_csv(os.environ.get("SUPPORT_REPORT_TO", ""))
                       or _csv(tr.get("recipients_to", []))),
        recipients_cc=(_csv(os.environ.get("SUPPORT_REPORT_CC", ""))
                       or _csv(tr.get("recipients_cc", []))),
        contact_email=(os.environ.get("EMAIL_CONTACT_ADDRESS", "").strip()
                       or str(tr.get("contact_email", "") or "")),
        send_registration=txn.send_user_credentials,
        send_password=txn.include_password,
        templates=dict(tr.get("templates", {}) or {}),
    )


def load_template(settings: TicketReportSettings, name: str) -> tuple[str, str]:
    """(subject, body) of a template file; the built-in text when the
    file is missing or unreadable (never raises)."""
    rel = (settings.templates or {}).get(name, f"email_templates/{name}.txt")
    try:
        path = Path(rel) if os.path.isabs(rel) else config_path(rel)
        text = path.read_text(encoding="utf-8").replace("\r\n", "\n")
    except (OSError, TypeError):
        return _FALLBACK[name]
    first, _, rest = text.partition("\n")
    if first.lower().startswith("subject:"):
        return first.split(":", 1)[1].strip(), rest.lstrip("\n")
    return _FALLBACK[name][0], text


def _meta(request) -> dict:
    meta = getattr(request, "metadata", None)
    return meta if isinstance(meta, dict) else {}


class TicketReporter:
    def __init__(self, notifier: EmailNotifier, logger=None,
                 settings_loader: Callable = load_ticket_report_config,
                 async_send: bool = True):
        self.notifier = notifier
        self.logger = logger
        self._load = settings_loader
        self.async_send = async_send
        # Set by the application: where the requests and marks live.
        self.queue_store = None
        self._lock = threading.Lock()

    # ── dispatcher hook ──

    def handle_completion(self, txn, request, result) -> None:
        """Never raises."""
        try:
            if getattr(request, "source", "") != "servicenow" or \
                    _meta(request).get("category") not in SAILPOINT_KINDS:
                return
            if self.async_send:
                threading.Thread(target=self._handle, args=(txn, request),
                                 name="ticket-report", daemon=True).start()
            else:
                self._handle(txn, request)
        except Exception as e:
            self._log("warning", f"Ticket e-mail could not start: {e}")

    def _handle(self, txn, request) -> None:
        try:
            settings = self._load()
            if not settings.txn_enabled:
                return
            # One ticket at a time: two codes finishing close together
            # must not both send the report.
            with self._lock:
                if str(getattr(request, "operation", "")) == "provision" and \
                        str(getattr(txn, "status", "")).lower() == "done" and \
                        str(getattr(txn, "result_code", "")).upper() != "UNCONFIRMED":
                    self._user_notices(settings, txn, request)
                if settings.report_enabled:
                    self._support_report(settings, request)
        except Exception as e:
            self._log("warning", f"Ticket e-mail failed unexpectedly: {e}")

    # ── user notices ──

    def _user_notices(self, s: TicketReportSettings, txn, request) -> None:
        meta = _meta(request)
        if meta.get(NOTICE_MARK):
            return
        email = str(meta.get("user_email", "") or "").strip()
        sent = {"registration": False, "password": False,
                "reason": ""}
        ticket = getattr(txn, "ticket_id", "") or ""
        password = str(getattr(request, "password", "") or "")
        if not email:
            sent["reason"] = NO_ADDRESS
            self._log("warning", f"User notices not sent for {ticket}: the "
                                 f"user's e-mail address was not found — the "
                                 f"password was NOT sent anywhere")
        elif not valid_address(email):
            # An address from a ticket is data, not trusted (2026-09-28).
            sent["reason"] = INVALID_ADDRESS
            self._log("warning", f"User notices not sent for {ticket}: the "
                                 f"user's e-mail address "
                                 f"{EmailNotifier._mask_address(email)!r} is "
                                 f"not valid — the password was NOT sent "
                                 f"anywhere")
        else:
            ctx = self._person_context(s, request)
            # Each notice records what happened: True (sent), "queued"
            # (in the outbox, resent automatically) or "failed" — a
            # failed notice is named in the support report (E-16).
            if s.send_registration:
                # The client's wording ("Password: sent to you in a
                # separate e-mail.") must arrive as written, so the generic
                # masking is off; the request's own password is masked
                # instead should it ever appear (2026-09-28).
                sent["registration"] = self._send(
                    s, "user_registration", ctx, to=[email],
                    kind="user_registration", redact_body=False,
                    mask=[password], outcome=True)
            if s.send_password and password:
                ctx = dict(ctx, password=password)
                # NARROW bypass of the body redaction: this e-mail exists
                # to deliver the password to its owner only. Never kept
                # in the outbox (it carries the password).
                sent["password"] = self._send(
                    s, "user_password", ctx, to=[email],
                    kind="user_password", redact_body=False,
                    outcome=True)
        self._mark([request], NOTICE_MARK, sent)

    def _person_context(self, s, request) -> dict:
        meta = _meta(request)
        return {
            "affiliation_code": getattr(request, "affiliation_code", ""),
            "affiliation_name": meta.get("affiliation_name", ""),
            "ffm_id": getattr(request, "employee_code", ""),
            "person_name": (meta.get("employee_name")
                            or meta.get("user_display_name") or ""),
            "contact_email": s.contact_email,
            "ticket_id": meta.get("parent_ticket")
                         or getattr(request, "ticket_id", ""),
        }

    # ── support report ──

    # The result words come from config/email_messages.yaml (report.*).
    _RESULTS = ("done", "already_deleted", "failed", "cancelled")

    def _members(self, request) -> list:
        meta = _meta(request)
        parent = str(meta.get("parent_ticket") or
                     str(getattr(request, "ticket_id", "")).split("/")[0])
        if self.queue_store is None:
            return [request]
        found = self.queue_store.find_ticket_requests(parent)
        return found or [request]

    def _support_report(self, s: TicketReportSettings, request) -> None:
        members = self._members(request)
        parts = int(_meta(request).get("parts", 1) or 1)
        if len(members) < parts or any(
                str(m.status).lower() not in _TERMINAL for m in members):
            return                     # the last code sends the report
        key = "|".join(f"{m.ticket_id}:{m.status}:{m.completed_at}"
                       for m in members)
        if _meta(members[0]).get(REPORT_MARK) == key:
            return                     # already sent for this outcome
        lead = _meta(members[0])
        kind = lead.get("category", "")
        requester = lead.get("requester") or {}
        person = lead.get("employee_name") or lead.get("user_display_name") or ""
        targets, results = [], []
        for m in members:
            mm = _meta(m)
            name = mm.get("affiliation_name", "")
            targets.append(f"所属コード {m.affiliation_code}：{name}\n"
                           f"担当者コード {m.employee_code}：{person}")
            status = str(m.status).lower()
            # The client's report is written in Japanese: its inserted
            # words keep the Japanese (English) form whatever language
            # the service's own e-mails use.
            word = (_m.label(f"report.result.{status}", "ja_en")
                    if status in self._RESULTS else str(m.status))
            if str(m.result_code).upper() == "UNCONFIRMED":
                word = _m.label("report.result.unconfirmed", "ja_en")
            elif str(m.status).lower() in ("failed", "cancelled") and m.error:
                word += f" — {str(m.error)[:200]}"
            results.append(f"{m.affiliation_code} {name}：{word}")
            notices = mm.get(NOTICE_MARK) or {}
            if notices.get("reason") == INVALID_ADDRESS:
                results.append("  " + _m.label("report.note.invalid_address",
                                                "ja_en"))
            elif notices.get("reason"):
                results.append("  " + _m.label("report.note.no_address",
                                                "ja_en"))
            else:
                if notices.get("registration") == "failed":
                    results.append("  " + _m.label(
                        "report.note.registration_failed", "ja_en"))
                if notices.get("password") == "failed":
                    results.append("  " + _m.label(
                        "report.note.password_failed", "ja_en"))
        ctx = {
            "date": datetime.now(_JST).strftime("%Y/%m/%d"),
            "action": "登録" if kind == "new_account" else "削除",
            "requester_name": requester.get("name") or "-",
            "requester_employee_number": requester.get("employee_number") or "-",
            "requester_email": requester.get("email") or "-",
            "targets": "\n\n".join(targets),
            "results": "\n".join(results),
            "ticket_id": lead.get("parent_ticket") or members[0].ticket_id,
            "request_kind": KIND_LABELS.get(kind, kind),
            "tracking_id": lead.get("tracking_id") or "-",
        }
        if self._send(s, "support_report", ctx,
                      to=s.recipients_to or None, cc=s.recipients_cc,
                      kind="support_report"):
            self._mark(members, REPORT_MARK, key)

    # ── transport ──

    def _send(self, s, name, ctx, to=None, cc=None, kind="",
              redact_body=True, mask=(), outcome=False):
        """True when sent. With outcome=True: True, "queued" (kept in the
        outbox, resent automatically) or "failed". A queued support
        report counts as sent: it is delivered from the outbox."""
        subject, body = load_template(s, name)
        subject, body = render(subject, ctx), render(body, ctx)
        # Known secret values are masked before sending (used when the
        # generic masking is off for an e-mail).
        for secret in mask or ():
            if secret:
                subject = subject.replace(secret, "***")
                body = body.replace(secret, "***")
        try:
            ok = bool(self.notifier.send(
                subject, body, to=to, cc=cc or None,
                raw_subject=True, redact_body=redact_body, kind=kind,
                template_path=NOTICE_TEMPLATE))
            return (True if ok else "failed") if outcome else ok
        except NotificationDeferred as e:
            self._log("warning", f"{kind} e-mail deferred: {e}")
            return "queued" if outcome else True
        except NotificationError as e:
            self._log("warning", f"{kind} e-mail failed: {e}")
        except Exception as e:
            self._log("warning", f"{kind} e-mail unexpected error: {e}")
        return "failed" if outcome else False

    def _mark(self, members, key, value) -> None:
        for m in members:
            meta = _meta(m)
            meta[key] = value
            rid = getattr(m, "request_id", "")
            if self.queue_store is not None and rid:
                try:
                    self.queue_store.set_metadata_value(rid, key, value)
                except Exception as e:
                    self._log("warning", f"E-mail mark not saved: {e}")

    def _log(self, level: str, msg: str):
        if self.logger and hasattr(self.logger, level):
            getattr(self.logger, level)(msg)
