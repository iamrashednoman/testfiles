"""
SMTP email sender — built on the Python standard library (smtplib +
email.message). No third-party dependency is added.

Design notes:
  * The SMTP connection factory is INJECTABLE (smtp_factory) so the notifier is
    fully unit-testable with no real network — tests pass a fake SMTP object.
  * Secrets are scrubbed from outgoing bodies (redact()) so a FINESIII or SMTP
    password can never leak into an alert.
  * Sends are resilient: transient SMTP failures are retried with bounded
    exponential backoff; a final failure RAISES NotificationError, which the
    caller (the log handler) swallows so the bot is never affected.
"""
from __future__ import annotations

import base64
import html as _html
import os
import re
import smtplib
import ssl
import threading
import time
from datetime import datetime, timedelta, timezone
from email.message import EmailMessage
from email.utils import formatdate, make_msgid, parseaddr
from pathlib import Path
from typing import Callable, Dict, Iterable, List, Optional

from src.modules.notifications.config import NotificationSettings
from src.core.app_paths import resource_path
from src.modules.notifications.render import (
    load_template, render_template, text_to_html,
)

_TEMPLATES_DIR = resource_path("src", "modules", "notifications",
                               "templates")
DEFAULT_ALERT_TEMPLATE_PATH = str(_TEMPLATES_DIR / "alert.html")
DEFAULT_DIGEST_TEMPLATE_PATH = str(_TEMPLATES_DIR / "digest.html")
# The Japanese / English designs (2026-09-29). Every text in them is a
# placeholder filled from config/email_messages.yaml. The designs above
# stay as the fallback when one of these files is missing.
I18N_DIR = _TEMPLATES_DIR / "i18n"
JST = timezone(timedelta(hours=9))
# The subject prefix shipped before the Branding page named the product.
_LEGACY_PREFIX = "[FINESIII RPA]"


def template(name: str) -> str:
    """Path of a design: the Japanese / English one, else the earlier one."""
    path = I18N_DIR / name
    return str(path if path.is_file() else _TEMPLATES_DIR / name)


def now_jst() -> datetime:
    return datetime.now(JST)


def fmt_time(value) -> str:
    """A stored time as 'YYYY-MM-DD HH:MM:SS' in JST; other text as is."""
    if value in (None, ""):
        return ""
    if isinstance(value, datetime):
        dt = value
    else:
        try:
            dt = datetime.fromisoformat(str(value).strip())
        except ValueError:
            return str(value)
    if dt.tzinfo is not None:
        dt = dt.astimezone(JST)
    return dt.strftime("%Y-%m-%d %H:%M:%S")

# Ultimate fallback if a template file is missing/unreadable — keeps HTML email
# working out of the box without shipping files.
_BUILTIN_FALLBACK = (
    "<html><body style='margin:0;padding:24px 0;background:#f5f7f9;"
    "font-family:Meiryo,\"Yu Gothic\",\"Segoe UI\",Arial,sans-serif;"
    "color:#343741;'><table role='presentation' width='600' align='center'"
    " cellpadding='0' cellspacing='0'"
    " style='width:100%;max-width:600px;background:#ffffff;'>"
    "{{header_html}}"
    "<tr><td style='padding:24px 28px 8px 28px;'>"
    "<h1 style='margin:0;font-size:18px;color:{{brand_color}};'>"
    "{{subject}}</h1><p style='margin:8px 0 0 0;font-size:12px;"
    "color:#5d738d;'>{{severity}} &middot; {{environment}} &middot; "
    "{{timestamp}}</p></td></tr><tr><td style='padding:12px 28px;'>"
    "<div style='background:#f5f7f9;border:1px solid #e6e6e6;padding:12px;"
    "font-size:13px;line-height:1.6;'>{{message_html}}</div></td></tr>"
    "{{footer_html}}</table></body></html>"
)

# Content-IDs of the branding images embedded in HTML e-mail. Embedded
# (not linked) because Outlook blocks remote images by default.
BANNER_CID = "finesiii-email-banner"
LOGO_CID = "finesiii-email-logo"
_HEX_COLOUR = re.compile(r"^#[0-9a-fA-F]{6}$")
_NOTE_COMMENT = re.compile(r"<!--(?!\[if)(?!<!\[endif).*?-->\s*", re.S)
_IMAGE_DATA = re.compile(
    r"^data:image/(png|jpeg|gif);base64,([A-Za-z0-9+/=\s]+)$")


def _colour(value: str, fallback: str) -> str:
    value = str(value or "").strip()
    return value if _HEX_COLOUR.match(value) else fallback


# The AIG logo used when no e-mail logo has been uploaded (white mark,
# drawn on the header colour). PNG because Outlook does not show SVG.
DEFAULT_LOGO_PATH = _TEMPLATES_DIR / "brand" / "aig-mark-white.png"


def _default_logo():
    try:
        return "png", DEFAULT_LOGO_PATH.read_bytes()
    except OSError:
        return None


def _image(data_url: str):
    """(subtype, bytes) of a validated data: URL, or None."""
    m = _IMAGE_DATA.match(str(data_url or ""))
    if not m:
        return None
    try:
        return m.group(1), base64.b64decode(re.sub(r"\s", "", m.group(2)),
                                            validate=True)
    except Exception:
        return None


class NotificationError(Exception):
    """Raised when an email could not be delivered after all retries."""


class NotificationDeferred(NotificationError):
    """Not delivered now, but kept in the outbox and resent automatically
    (2026-09-29). Callers that only log a failure treat it as one."""


class EncryptionUnavailable(smtplib.SMTPException):
    """The server did not offer encryption, and a login was configured."""


# At most this many mail-server sessions at once (2026-09-29): a burst of
# finished tickets must not open dozens of connections to the relay.
_SEND_SLOTS = threading.BoundedSemaphore(2)

# E-mail kinds that are never written to disk (the outbox): they carry a
# password. When they cannot be sent now, the failure is reported.
SECRET_KINDS = ("user_password",)


class DeliveryState:
    """Whether e-mail delivery works, for the console (2026-09-29)."""

    def __init__(self):
        self._lock = threading.Lock()
        self.last_ok_at = None
        self.last_fail_at = None
        self.last_error = ""

    def ok(self):
        with self._lock:
            self.last_ok_at = now_jst()

    def failed(self, error):
        with self._lock:
            self.last_fail_at = now_jst()
            self.last_error = str(error or "")[:200]

    def snapshot(self) -> dict:
        with self._lock:
            fmt = (lambda d: d.strftime("%Y-%m-%d %H:%M:%S") if d else "")
            failing = self.last_fail_at is not None and (
                self.last_ok_at is None or self.last_fail_at > self.last_ok_at)
            return {"failing": failing,
                    "last_success_jst": fmt(self.last_ok_at),
                    "last_failure_jst": fmt(self.last_fail_at),
                    "last_error": self.last_error if failing else ""}

    def failing(self) -> bool:
        with self._lock:
            return self.last_fail_at is not None and (
                self.last_ok_at is None or self.last_fail_at > self.last_ok_at)

    def problem(self) -> str:
        """The console text while delivery fails, else ""."""
        with self._lock:
            if self.last_fail_at is None or (
                    self.last_ok_at is not None
                    and self.last_ok_at >= self.last_fail_at):
                return ""
            since = self.last_fail_at.strftime("%Y-%m-%d %H:%M")
            error = self.last_error
        waiting = _OUTBOX.pending() if _OUTBOX is not None else 0
        text = (f"E-mail delivery is failing (last failure {since} JST: "
                f"{error}).")
        if waiting:
            text += (f" {waiting} e-mail(s) are waiting in the outbox and "
                     f"are resent automatically.")
        return text + " Check the mail server under Settings > E-mail."


DELIVERY = DeliveryState()
_OUTBOX = None


def set_outbox(outbox) -> None:
    """Set by the application: where failed e-mails wait to be resent."""
    global _OUTBOX
    _OUTBOX = outbox


def get_outbox():
    return _OUTBOX


def is_permanent(error) -> bool:
    """A failure that retrying the same message cannot fix."""
    if isinstance(error, (smtplib.SMTPRecipientsRefused,
                          smtplib.SMTPSenderRefused,
                          smtplib.SMTPAuthenticationError,
                          smtplib.SMTPNotSupportedError,
                          EncryptionUnavailable,
                          ssl.SSLCertVerificationError)):
        return True
    if isinstance(error, smtplib.SMTPResponseException):
        return 500 <= int(getattr(error, "smtp_code", 0) or 0) < 600
    return False


def message_specific(error) -> bool:
    """Refused because of THIS message (its sender or recipients):
    resending it later cannot help, so it is not kept in the outbox."""
    if isinstance(error, (smtplib.SMTPRecipientsRefused,
                          smtplib.SMTPSenderRefused)):
        return True
    if isinstance(error, smtplib.SMTPDataError):
        return 500 <= int(getattr(error, "smtp_code", 0) or 0) < 600
    return False


# Patterns whose VALUES we redact from alert bodies, regardless of config.
# Catches "password: secret", "password=secret", "pwd = secret", etc.
_SECRET_PATTERN = re.compile(
    r"(?i)\b(pass(?:word)?|pwd|secret|token|api[_-]?key)\b\s*[:=]\s*\S+"
)


def redact(text: str, extra_secrets: Iterable[str] = ()) -> str:
    """Mask secret-looking values and any explicitly-provided secret strings."""
    if not text:
        return text
    out = _SECRET_PATTERN.sub(lambda m: f"{m.group(1)}: ***", text)
    for secret in extra_secrets:
        if secret:
            out = out.replace(secret, "***")
    return out


_DOMAIN_LABEL = re.compile(r"^[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?$")


def valid_address(addr) -> bool:
    """A single plain e-mail address: no line breaks, no list or header
    separators (, ; < >) and no spaces, exactly one @, and a dotted
    domain (2026-09-28). Used for addresses taken from a ticket and for
    the address settings, so nothing can smuggle a header or a second
    recipient in."""
    text = str(addr or "")
    if not text or text != text.strip():
        return False
    if any(c in text for c in "\r\n,;<> \t") or text.count("@") != 1:
        return False
    local, _, domain = text.partition("@")
    if not local or "." not in domain:
        return False
    return all(_DOMAIN_LABEL.match(label) for label in domain.split("."))


class EmailNotifier:
    """Sends plain-text emails via SMTP with retry/backoff and dry-run support."""

    def __init__(self, settings: NotificationSettings, logger=None,
                 smtp_factory: Optional[Callable[[], "smtplib.SMTP"]] = None,
                 sleep_func: Callable[[float], None] = time.sleep):
        self.s = settings
        # IMPORTANT: a SEPARATE logger that does NOT propagate into the
        # "finesiii_rpa_v3" logger, so failures here can never re-trigger the
        # email alert handler (no recursion / mail storms on outages).
        self.logger = logger
        self._smtp_factory = smtp_factory
        self._sleep = sleep_func

    # ── connection ───────────────────────────────────────────────────

    def _tls_context(self) -> ssl.SSLContext:
        """The system's trusted certificates (on Windows, the machine
        certificate store), plus an optional CA bundle; certificate
        checking can be switched off only on purpose."""
        context = ssl.create_default_context()
        if self.s.ca_file:
            context.load_verify_locations(cafile=self.s.ca_file)
        if not self.s.verify_tls:
            context.check_hostname = False
            context.verify_mode = ssl.CERT_NONE
        return context

    def _connect(self, info: Optional[dict] = None) -> "smtplib.SMTP":
        """Open a connection with the configured security and login (or
        return the injected fake). `info` receives what the server
        offered (for the console's connection test)."""
        if self._smtp_factory is not None:
            return self._smtp_factory()

        security = self.s.effective_security
        context = self._tls_context() if security != "none" else None
        name = self.s.local_hostname or None
        if security == "ssl":
            client = smtplib.SMTP_SSL(
                self.s.smtp_host, self.s.smtp_port, local_hostname=name,
                timeout=self.s.timeout_seconds, context=context,
            )
            encrypted = True
        else:
            client = smtplib.SMTP(
                self.s.smtp_host, self.s.smtp_port, local_hostname=name,
                timeout=self.s.timeout_seconds,
            )
            encrypted = False
        try:
            client.ehlo_or_helo_if_needed()
            offered = bool(client.has_extn("starttls"))
            if security == "starttls" or (
                    security == "starttls_if_offered" and offered):
                # Required: a server without STARTTLS fails here.
                client.starttls(context=context)
                client.ehlo()
                encrypted = True
            if info is not None:
                features = getattr(client, "esmtp_features", {}) or {}
                info.update({
                    "starttls_offered": offered,
                    "encrypted": encrypted,
                    "tls_version": (client.sock.version()
                                    if encrypted and hasattr(
                                        client.sock, "version") else ""),
                    "auth_methods": str(features.get("auth", "")).strip(),
                    "max_size": str(features.get("size", "")).strip(),
                })
            if self.s.username:
                if not encrypted:
                    raise EncryptionUnavailable(
                        "the mail server did not offer encryption "
                        "(STARTTLS); the login is not sent unencrypted")
                try:
                    client.login(self.s.username, self.s.password)
                except smtplib.SMTPAuthenticationError:
                    raise
                except (smtplib.SMTPException, OSError) as e:
                    # Some servers drop the connection on a wrong
                    # password: a failed login is never retried at once
                    # (account lockout).
                    raise smtplib.SMTPAuthenticationError(
                        535, f"login failed: {e}".encode("utf-8",
                                                          "replace")) from e
        except Exception:
            try:
                client.close()
            except Exception:
                pass
            raise
        return client

    def check_connection(self) -> dict:
        """Connect, secure and log in exactly as a real e-mail would,
        then disconnect without sending anything (console test)."""
        info = {"security": self.s.effective_security,
                "login": bool(self.s.username)}
        with _SEND_SLOTS:
            client = self._connect(info)
            try:
                client.noop()
            finally:
                try:
                    client.quit()
                except Exception:
                    pass
        return info

    # ── message building ─────────────────────────────────────────────

    def _scrub(self, text: str, redact_body: bool = True) -> str:
        """Apply outgoing-body redaction.

        redact_body=False is a NARROW bypass for the credential-delivery
        email ONLY (client requirement: the user receives their initial
        password). Even then the SMTP password itself is always masked."""
        if redact_body:
            return redact(text, extra_secrets=[self.s.password])
        if self.s.password:
            return text.replace(self.s.password, "***")
        return text

    def build_message(self, subject: str, body: str,
                      to: Optional[List[str]] = None,
                      context: Optional[Dict[str, str]] = None,
                      is_digest: bool = False,
                      template_path: Optional[str] = None,
                      redact_body: bool = True,
                      cc: Optional[List[str]] = None,
                      raw_subject: bool = False) -> EmailMessage:
        recipients = to if to is not None else self.s.recipients_to
        msg = EmailMessage()
        if raw_subject:
            # Client-owned templates carry their exact subject (2026-09-28).
            full_subject = subject.strip()
        else:
            prefix = self.subject_prefix()
            env = self.environment()
            full_subject = (f"{prefix} [{env}] {subject}" if env
                            else f"{prefix} {subject}").strip()
        msg["Subject"] = full_subject
        msg["From"] = self.s.mail_from
        msg["To"] = ", ".join(recipients)
        # The default CC list belongs to the default recipients only. A
        # message sent to someone else (a user) never shows the internal
        # distribution list — it did not receive the message either
        # (2026-09-28). An explicit cc is shown AND delivered.
        if cc:
            msg["Cc"] = ", ".join(cc)
        elif to is None and self.s.recipients_cc:
            msg["Cc"] = ", ".join(self.s.recipients_cc)
        msg["Date"] = formatdate(localtime=True)
        # The sender's own domain (a ".local" domain scores as spam).
        msg["Message-ID"] = make_msgid(domain=self._msgid_domain())
        # Automatic message (RFC 3834): no out-of-office or auto replies
        # back to the bot mailbox (2026-09-29).
        msg["Auto-Submitted"] = "auto-generated"
        msg["X-Auto-Response-Suppress"] = "All"

        # Plain text is ALWAYS set (fallback for any client / when HTML is off).
        msg.set_content(self._scrub(body, redact_body))

        # Optional branded HTML alternative.
        html_body = self._render_html(subject, body, context, is_digest,
                                      template_path=template_path,
                                      redact_body=redact_body)
        if html_body:
            html_body = self._scrub(html_body, redact_body)
            msg.add_alternative(html_body, subtype="html")
            # The branding images travel inside the message, referenced
            # by Content-ID — only those the HTML actually uses.
            brand = self._branding()
            html_part = msg.get_payload()[-1]
            for cid, image in ((BANNER_CID, _image(brand.get("email_banner"))),
                               (LOGO_CID, self._logo_image(brand))):
                if f"cid:{cid}" not in html_body:
                    continue
                if image:
                    html_part.add_related(image[1], maintype="image",
                                          subtype=image[0], cid=f"<{cid}>",
                                          disposition="inline")
        return msg

    def _msgid_domain(self) -> str:
        _, address = parseaddr(self.s.mail_from or "")
        domain = address.rpartition("@")[2].strip().lower()
        return domain if re.match(r"^[a-z0-9.-]+\.[a-z]{2,}$", domain) \
            else "finesiii-rpa.local"

    def environment(self) -> str:
        """The environment named in subjects and headers: the console
        setting "Environment name shown in e-mails", else the service's
        environment."""
        label = os.environ.get("EMAIL_ENVIRONMENT_LABEL", "").strip()
        if label:
            return label
        return str(self.s.environment_label or "").strip().upper()

    def subject_prefix(self) -> str:
        """[product] from the Branding page, unless notifications.yaml
        names its own prefix."""
        prefix = str(self.s.subject_prefix or "").strip()
        if prefix and prefix != _LEGACY_PREFIX:
            return prefix
        product = str(self._branding().get("product_name") or "").strip()
        return f"[{product or 'FINES III RPA'}]"

    def _render_html(self, subject: str, body: str,
                     context: Optional[Dict[str, str]], is_digest: bool,
                     template_path: Optional[str] = None,
                     redact_body: bool = True) -> Optional[str]:
        """Render the client-branded HTML body, or None when HTML is disabled.

        template_path (optional) selects a DEDICATED template for this one
        message (e.g. the availability-outage template) without touching the
        configured defaults."""
        if not self.html_enabled():
            return None

        path = template_path
        if not path:
            path = self.s.digest_template_path if is_digest else self.s.template_path
        if not path:
            path = template("digest.html" if is_digest else "alert.html")
        design = load_template(path, _BUILTIN_FALLBACK)
        # The maintainer notes at the top of a template are not part of
        # the e-mail (Outlook conditional comments are kept).
        design = _NOTE_COMMENT.sub("", design)

        ctx = self._base_context(subject)
        if context:
            ctx.update({k: v for k, v in context.items() if v is not None})
        # If the caller didn't supply pre-formatted HTML, derive it from the body.
        if "message_html" not in ctx or not ctx.get("message_html"):
            ctx["message_html"] = text_to_html(self._scrub(body, redact_body))
        return render_template(design, ctx)

    # Set by the application: returns the console Branding document
    # (2026-09-28). None = the notifications.yaml branding only.
    branding_source = None

    def _branding(self) -> dict:
        if self.branding_source is None:
            return {}
        try:
            return dict(self.branding_source() or {})
        except Exception:
            return {}

    def _logo_image(self, brand: dict):
        """The uploaded e-mail logo; else the built-in AIG logo, unless
        notifications.yaml names its own logo URL."""
        uploaded = _image(brand.get("email_logo"))
        if uploaded:
            return uploaded
        if self.s.logo_url:
            return None
        return _default_logo()

    def html_enabled(self) -> bool:
        """The console Branding page decides when it is in use; else
        notifications.yaml (UR-16, 2026-10-03: switching HTML off on the
        Branding page used to be overruled by the file)."""
        brand = self._branding()
        if "email_html_enabled" in brand:
            return bool(brand.get("email_html_enabled"))
        return bool(self.s.html_enabled)

    def _base_context(self, subject: str) -> Dict[str, str]:
        now = now_jst()
        brand = self._branding()
        header = _colour(brand.get("email_header_color"),
                         _colour(self.s.brand_color, "#001871"))
        accent = _colour(brand.get("email_accent_color"), "#00a4e4")
        company = (brand.get("email_company_name")
                   or self.s.company_name or "")
        footer = brand.get("email_footer_text") or self.s.footer_text or ""
        # Branding first, like the company name and the footer (UR-16).
        support = brand.get("support_contact") or self.s.support_contact or ""
        product = brand.get("product_name") or "FINES III RPA"
        has_logo = self._logo_image(brand) is not None
        ctx = {
            "company_name": company,
            "logo_url": f"cid:{LOGO_CID}" if has_logo else self.s.logo_url,
            "brand_color": header,
            "accent_color": accent,
            "product_name": product,
            "support_contact": support,
            "footer_text": footer,
            "environment": self.environment(),
            "subject": subject,
            "timestamp": now.strftime("%Y-%m-%d %H:%M:%S"),
            "year": str(now.year),
            "severity": "",
            "source": "",
        }
        ctx["header_html"] = self._header_html(
            brand, header, accent, company, product, has_logo)
        ctx["footer_html"] = self._footer_html(footer, support, company,
                                               header, now.year)
        return ctx

    def _header_html(self, brand: dict, header: str, accent: str,
                     company: str, product: str, has_logo: bool) -> str:
        """The shared top of every HTML e-mail: the banner when one is
        set, otherwise a coloured bar with the logo (or the name)."""
        esc = _html.escape
        env = esc(self.environment())
        if _image(brand.get("email_banner")) is not None:
            return (
                f'<tr><td style="padding:0;line-height:0;">'
                f'<img src="cid:{BANNER_CID}" width="600" '
                f'alt="{esc(company or product)}" style="display:block;'
                f'width:100%;max-width:600px;height:auto;border:0;"></td>'
                f'</tr><tr><td style="background:{accent};height:4px;'
                f'line-height:4px;font-size:0;">&nbsp;</td></tr>')
        if has_logo:
            mark = (f'<img src="cid:{LOGO_CID}" alt="{esc(company or product)}"'
                    f' height="32" style="display:block;border:0;'
                    f'max-height:32px;">')
        elif self.s.logo_url:
            mark = (f'<img src="{esc(self.s.logo_url)}" '
                    f'alt="{esc(company or product)}" height="32" '
                    f'style="display:block;border:0;max-height:32px;">')
        else:
            mark = (f'<span style="color:#ffffff;font-size:17px;'
                    f'font-weight:bold;letter-spacing:0.5px;">'
                    f'{esc(company or product)}</span>')
        return (
            f'<tr><td style="background:{header};padding:18px 28px;">'
            f'<table role="presentation" width="100%" cellpadding="0" '
            f'cellspacing="0"><tr><td style="vertical-align:middle;">{mark}'
            f'</td><td align="right" style="vertical-align:middle;'
            f'color:#ffffff;font-size:12px;">{esc(product)}'
            + (f' &middot; {env}' if env else '') +
            f'</td></tr></table></td></tr>'
            f'<tr><td style="background:{accent};height:4px;'
            f'line-height:4px;font-size:0;">&nbsp;</td></tr>')

    @staticmethod
    def _footer_html(footer: str, support: str, company: str,
                     header: str, year: int) -> str:
        from src.modules.notifications import messages as _m
        esc = _html.escape
        lines = []
        if footer:
            lines.append(esc(footer).replace("\n", "<br>"))
        if support:
            contact = esc(support)
            link = (f'<a href="mailto:{contact}" style="color:{header};">'
                    f'{contact}</a>' if "@" in support else contact)
            lines.append(f"{esc(_m.label('footer.contact'))}: {link}")
        lines.append(esc(_m.text("footer.auto")).replace("\n", "<br>"))
        if company:
            lines.append(f"&copy; {year} {esc(company)}")
        return (
            f'<tr><td style="padding:18px 28px 22px 28px;border-top:1px '
            f'solid #e6e6e6;background:#f5f7f9;font-size:11px;'
            f'line-height:1.6;color:#5d738d;">'
            + "<br>".join(lines) + '</td></tr>')

    # ── sending ──────────────────────────────────────────────────────

    # Set by the application: the audit trail every sent or failed e-mail
    # is recorded in (2026-09-28). None = not recorded.
    audit = None
    # False for the console's previews: they never change the delivery
    # state shown on the dashboard.
    track_delivery = True

    @staticmethod
    def _mask_address(address: str) -> str:
        """k***@example.com — who was notified, without the full address
        of a person in the audit detail."""
        name, _, domain = str(address or "").partition("@")
        # Only the domain itself: a malformed address from a ticket must
        # not carry a second line or recipient into a log (2026-09-28).
        domain = re.split(r"[\s,;<>@]", domain, maxsplit=1)[0]
        return f"{name[:1]}***@{domain}" if domain else "***"

    def _audit_email(self, ok: bool, subject: str, recipients: List[str],
                     kind: str = "", error: str = "", action: str = "",
                     refused=None) -> None:
        if self.audit is None:
            return
        try:
            detail = {"subject": str(subject)[:200], "kind": kind,
                      "recipients": [self._mask_address(r)
                                     for r in recipients][:50],
                      "recipient_count": len(recipients),
                      "error": str(error)[:300]}
            if refused:
                detail["refused"] = [self._mask_address(r)
                                     for r in refused][:50]
            self.audit.event(
                "notification",
                action or ("email_sent" if ok else "email_failed"),
                severity="INFO" if ok else "WARNING", detail=detail)
        except Exception:
            pass

    def transmit(self, msg: EmailMessage, recipients: List[str]) -> dict:
        """One delivery attempt. Returns the recipients the server refused
        while accepting the others ({} = all accepted)."""
        with _SEND_SLOTS:
            client = self._connect()
            try:
                refused = client.send_message(msg, to_addrs=recipients)
            finally:
                try:
                    client.quit()
                except Exception:
                    pass
        return dict(refused or {})

    def send(self, subject: str, body: str,
             to: Optional[List[str]] = None,
             context: Optional[Dict[str, str]] = None,
             is_digest: bool = False,
             template_path: Optional[str] = None,
             redact_body: bool = True,
             cc: Optional[List[str]] = None,
             raw_subject: bool = False,
             kind: str = "",
             persist: bool = True) -> bool:
        """Send one email. Returns True on success.

        Raises NotificationError after exhausting retries. Honors dry_run
        (builds + logs the message but does not transmit). `cc` is
        delivered as well as shown; `raw_subject` sends the subject
        exactly as given (client templates).

        A failure that retrying cannot fix (login refused, recipient or
        sender refused, certificate not trusted) is not retried. When
        the e-mail still fails it goes to the outbox and is resent
        automatically (NotificationDeferred) — never an e-mail of a
        SECRET_KIND or with persist=False (2026-09-29).
        """
        recipients = to if to is not None else self.s.all_recipients
        if cc:
            recipients = list(recipients) + [c for c in cc
                                             if c not in recipients]
        if not recipients:
            if self.logger:
                self.logger.warning("Email notifier: no recipients configured; skipping send.")
            return False

        msg = self.build_message(subject, body, to=to, context=context,
                                 is_digest=is_digest, template_path=template_path,
                                 redact_body=redact_body, cc=cc,
                                 raw_subject=raw_subject)

        if self.s.dry_run:
            if self.logger:
                self.logger.info(
                    f"[DRY-RUN] Would email '{msg['Subject']}' to {recipients}"
                )
            self._audit_email(True, msg["Subject"], recipients,
                              kind or "dry-run")
            return True

        attempt = 0
        last_err: Optional[Exception] = None
        while attempt <= self.s.max_retries:
            attempt += 1
            try:
                refused = self.transmit(msg, recipients)
                if refused and self.logger:
                    self.logger.warning(
                        f"Email '{msg['Subject']}': the mail server refused "
                        f"{len(refused)} of {len(recipients)} recipient(s): "
                        + ", ".join(self._mask_address(r) for r in refused))
                if self.logger:
                    self.logger.info(
                        f"Alert email sent: '{msg['Subject']}' → {len(recipients)} recipient(s)"
                    )
                if self.track_delivery:
                    DELIVERY.ok()
                self._audit_email(True, msg["Subject"], recipients, kind,
                                  refused=list(refused))
                return True
            except (smtplib.SMTPException, OSError) as e:
                last_err = e
                if is_permanent(e) or attempt > self.s.max_retries:
                    break
                self._backoff(attempt, reason=str(e))

        if self.track_delivery:
            DELIVERY.failed(last_err)
        outbox = _OUTBOX
        if outbox is not None and persist and kind not in SECRET_KINDS \
                and not message_specific(last_err):
            try:
                if outbox.put(msg, recipients, kind=kind, attempts=attempt,
                              last_error=str(last_err)):
                    self._audit_email(False, msg["Subject"], recipients,
                                      kind, str(last_err),
                                      action="email_deferred")
                    raise NotificationDeferred(
                        f"E-mail not delivered after {attempt} attempt(s): "
                        f"{last_err}. Kept in the outbox; it is resent "
                        f"automatically.") from last_err
            except NotificationDeferred:
                raise
            except Exception as e:
                if self.logger:
                    self.logger.warning(f"E-mail outbox not written: {e}")
        self._audit_email(False, msg["Subject"], recipients, kind,
                          str(last_err))
        raise NotificationError(
            f"Failed to send alert email after {attempt} attempt(s): {last_err}"
        ) from last_err

    def _backoff(self, attempt: int, reason: str = "") -> None:
        delay = min(
            self.s.backoff_base_seconds * (2 ** (attempt - 1)),
            self.s.backoff_max_seconds,
        )
        if self.logger:
            self.logger.warning(
                f"Email send failed ({reason}); retrying in {delay:.1f}s (attempt {attempt})"
            )
        self._sleep(delay)
