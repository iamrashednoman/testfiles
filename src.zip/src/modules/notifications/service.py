"""The e-mail parts that run with the service (2026-09-29).

  * the outbox: failed e-mails kept and resent (E-15);
  * the database watch: outage and recovery notices for the database
    (E-10), and no repeated generic alerts while it is down;
  * the console banner while e-mail delivery fails (E-18);
  * the start notice — always when the service starts with problems
    (E-11), and start / stop when switched on (EMAIL_SERVICE_NOTICES).

Everything is optional and fail-safe: a part that cannot start is
logged and the service runs without it.
"""
from __future__ import annotations

import logging
import threading

from src.modules.notifications import notifier as _notifier
from src.modules.notifications.availability_alerts import DatabaseWatch
from src.modules.notifications.log_handler import source_of


class EmailServices:
    def __init__(self, alert_handler, availability_alerter=None, audit=None,
                 queue_store=None, logger=None, outbox_dir=None):
        self.handler = alert_handler
        self.alerter = availability_alerter
        self.logger = logger
        self.settings = alert_handler.s
        self.outbox = None
        self.db_watch = None

        # The errors the outage notices already cover are not e-mailed
        # twice (E-13).
        alert_handler.dedicated_notices = availability_alerter is not None

        if self.settings.outbox_hours > 0:
            try:
                from src.core.app_paths import data_path
                from src.modules.notifications.outbox import Outbox
                self.outbox = Outbox(
                    outbox_dir or data_path("mail_outbox"),
                    transport=alert_handler.notifier, logger=logger,
                    audit=audit, keep_hours=self.settings.outbox_hours)
                _notifier.set_outbox(self.outbox)
            except Exception as e:
                self._log(f"E-mail outbox unavailable: {e}")

        if availability_alerter is not None and queue_store is not None:
            self.db_watch = DatabaseWatch(queue_store.queue_depth,
                                          availability_alerter, logger=logger)
            watch = self.db_watch

            def dispatcher_error_while_db_down(record) -> bool:
                return (watch.down and record.levelno < logging.CRITICAL
                        and source_of(record)[0] == "dispatcher")
            alert_handler.suppress_checks.append(
                dispatcher_error_while_db_down)

    @staticmethod
    def delivery_problem() -> str:
        """For the console's live problems: "" while e-mail works."""
        try:
            return _notifier.DELIVERY.problem()
        except Exception:
            return ""

    def start(self, problems=()) -> None:
        if self.outbox is not None:
            self.outbox.start()
        if self.db_watch is not None:
            self.db_watch.start()
        if self.alerter is None:
            return
        problems = [str(p) for p in problems if p]
        if problems:
            self._notice("problems", problems)
        elif self.settings.service_notices:
            self._notice("started")

    def stop(self) -> None:
        if self.alerter is not None and self.settings.service_notices:
            # Bounded: a mail server that does not answer must not hold
            # the shutdown (the notice then goes to the outbox).
            t = self._notice("stopping")
            if t is not None:
                t.join(timeout=15)
        if self.db_watch is not None:
            self.db_watch.stop()
        if self.outbox is not None:
            self.outbox.stop()
            if _notifier.get_outbox() is self.outbox:
                _notifier.set_outbox(None)

    def _notice(self, state: str, problems=()):
        def run():
            try:
                self.alerter.service_notice(state, problems)
            except Exception as e:
                self._log(f"Service notice e-mail failed: {e}")
        t = threading.Thread(target=run, name="service-notice", daemon=True)
        t.start()
        return t

    def _log(self, text: str) -> None:
        if self.logger:
            self.logger.warning(text)
