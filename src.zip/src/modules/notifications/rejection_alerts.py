"""
Request rejection notifications (Part B, Step 9).

When a request is rejected BEFORE execution — duplicate detection or data
validation — the configured support teams receive a dedicated, branded
email (templates/request_rejected.html).

Fired from two places:
  * the service API submit path (409 duplicate / 400 invalid), and
  * the ServiceNow connector when a ticket cannot be mapped to a valid
    request (skipped tickets).

Same design rules as the other alerters: disabled by default (rides the
transaction_notifications block + notify_on_rejection), fire-and-forget
threads, reuses EmailNotifier, never raises into the caller.

Unlike the transaction alerter (which reuses the log-handler's notifier),
this module can BUILD its own EmailNotifier from config/notifications.yaml
— the connector runs as a separate process with no log handler attached.
"""
from __future__ import annotations

import html as _html
import threading
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Optional

from src.core.app_paths import resource_path
from src.modules.notifications import messages as _m
from src.modules.notifications.notifier import (
    EmailNotifier, NotificationError, template,
)
from src.modules.notifications.render import (
    rows_html, rows_text, text_to_html,
)

JST = timezone(timedelta(hours=9))

REJECTION_TEMPLATE_PATH = str(
    resource_path("src", "modules", "notifications", "templates",
                  "request_rejected.html")
)

REJECTION_DUPLICATE = "DUPLICATE REQUEST"
REJECTION_VALIDATION = "VALIDATION FAILED"

# Keys whose values are masked in the details table (defense in depth —
# callers should not pass secrets at all).
_SECRET_MARKERS = ("password", "passwd", "pwd", "secret", "token", "api_key")


def _detail_rows(details: dict) -> list:
    """(label, value) rows of the submitted data; secrets masked."""
    rows = []
    for key, value in (details or {}).items():
        if value in (None, ""):
            continue
        if any(m in str(key).lower() for m in _SECRET_MARKERS):
            value = "****"
        rows.append((_m.field_label(str(key)), str(value)))
    return rows


def build_details_rows_html(details: dict) -> str:
    """Render the submitted-data/rejection-specifics dict as table rows."""
    return rows_html(_detail_rows(details), mono=True)


_TYPES = {REJECTION_DUPLICATE: "reject.type.duplicate",
          REJECTION_VALIDATION: "reject.type.validation"}


class RejectionAlerter:
    """Sends the dedicated rejection email to support teams."""

    def __init__(self, notifier: EmailNotifier, logger=None,
                 recipients_to=None, async_send: bool = True):
        self.notifier = notifier
        self.logger = logger
        self.recipients_to = list(recipients_to or []) or None
        self.async_send = async_send

    def request_rejected(self, rejection_type: str, reason: str,
                         details: Optional[dict] = None):
        """Notify support that a request was rejected before execution.
        Never raises into the caller (API route / connector poll loop).
        Every text comes from config/email_messages.yaml (2026-09-29)."""
        try:
            detected = datetime.now(JST).strftime("%Y-%m-%d %H:%M:%S JST")
            details = details or {}
            ref = (details.get("ticket_id") or details.get("request_id")
                   or details.get("employee_code") or "")
            type_key = _TYPES.get(str(rejection_type).upper())
            type_text = (_m.pair(type_key) if type_key
                         else str(rejection_type).title())
            subject = _m.subject("reject.subject", type=type_text,
                                 ref=(f" — {ref}" if ref else ""))
            heading = _m.label("reject.heading")
            note = _m.text("reject.note", detected_at=detected)
            rows = _detail_rows(details)
            body = "\n\n".join(p for p in (
                f"{heading}: {_m.value(type_text)}",
                f"{_m.label('label.reason')}: {reason}",
                f"{_m.label('label.detected')}: {detected}",
                rows_text(rows), note) if p)
            context = {
                "rejection_type": rejection_type,
                "reason": reason,
                "detected_at": detected,
                "details_rows_html": build_details_rows_html(details),
                "rows_html": rows_html(rows, mono=True),
                "t_badge": _m.value(type_text),
                "t_heading": heading,
                "t_intro_html": text_to_html(reason),
                "t_label_submitted": _m.label("label.submitted_data"),
                "t_note_html": text_to_html(note),
                "severity": "REJECTED",
                "source": "request-validation",
            }
            self._dispatch(subject, body, context)
        except Exception as e:
            if self.logger:
                self.logger.warning(f"Rejection notification failed to build: {e}")

    def _dispatch(self, subject, body, context):
        if self.async_send:
            threading.Thread(
                target=self._send, args=(subject, body, context),
                name="rejection-alert", daemon=True,
            ).start()
        else:
            self._send(subject, body, context)

    def _send(self, subject, body, context):
        try:
            self.notifier.send(subject, body, to=self.recipients_to,
                               context=context,
                               template_path=template("request_rejected.html"),
                               kind="rejection")
        except NotificationError as e:
            if self.logger:
                self.logger.warning(f"Rejection email failed: {e}")
        except Exception as e:
            if self.logger:
                self.logger.warning(f"Rejection email unexpected error: {e}")


def build_rejection_alerter(logger=None, notifications_yaml=None,
                            environment: str = "") -> Optional[RejectionAlerter]:
    """Standalone builder (works in BOTH the service and the connector
    process). Active only when: notifications are enabled AND valid, AND
    transaction_notifications.enabled AND notify_on_rejection are true.
    Returns None otherwise — callers wire hooks conditionally."""
    from src.modules.notifications.config import load_notification_config
    from src.modules.notifications.transaction_alerts import (
        load_transaction_notification_config,
    )

    try:
        settings = load_notification_config(notifications_yaml)
        if not settings.enabled:
            return None
        # Same label as every other email of this install (MAIL-TAG):
        # rejection mails said [development] on a production install.
        if environment:
            settings.environment_label = str(environment)
        settings.validate()
    except Exception as e:
        if logger:
            logger.info(f"Rejection notifications: inactive ({e})")
        return None

    txn_settings = load_transaction_notification_config(notifications_yaml)
    if not (txn_settings.enabled and txn_settings.notify_on_rejection):
        if logger:
            logger.info("Rejection notifications: disabled by configuration")
        return None

    notifier = EmailNotifier(settings, logger=logger)
    if logger:
        logger.info("Rejection notifications: ACTIVE")
    return RejectionAlerter(
        notifier, logger=logger,
        recipients_to=txn_settings.ops_recipients_to,
    )
