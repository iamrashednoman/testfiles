"""
Configuration for the email notification feature.

Structure comes from config/notifications.yaml; secrets come from
environment variables whose NAMES are declared in that YAML's
`env_vars:` block — the exact same pattern used for FINESIII_*
credentials and the ServiceNow connector.

Nothing here imports the bot/service internals, so it stays fully
decoupled and unit-testable without network or filesystem coupling.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

from src.core.app_paths import config_path
import yaml


# Default location of the notifications YAML (<repo-root>/config/).
DEFAULT_CONFIG_PATH = str(
    config_path("notifications.yaml")
)


def _split_csv(value: str) -> List[str]:
    """Parse a comma/semicolon-separated recipient list into a clean list."""
    if not value:
        return []
    parts = []
    for chunk in str(value).replace(";", ",").split(","):
        addr = chunk.strip()
        if addr:
            parts.append(addr)
    return parts


@dataclass
class NotificationSettings:
    """Resolved, validated settings for the email notifier."""

    enabled: bool = False

    # ── SMTP transport ──
    smtp_host: str = ""
    smtp_port: int = 587
    use_starttls: bool = True          # STARTTLS on a plain port (587). Mutually
    use_ssl: bool = False              # exclusive with implicit SSL (465).
    username: str = ""                 # optional (some relays allow anonymous)
    password: str = ""
    timeout_seconds: float = 30.0
    # Connection security (2026-09-29): "starttls_if_offered" | "starttls"
    # | "ssl" | "none". Blank = decided by use_ssl / use_starttls (the
    # earlier switches), so a caller that sets only those is unchanged.
    security: str = ""
    verify_tls: bool = True            # check the server certificate
    ca_file: str = ""                  # extra trusted CA bundle (PEM)
    local_hostname: str = ""           # name given in EHLO (blank = this machine)

    # ── Addressing ──
    mail_from: str = ""
    recipients_to: List[str] = field(default_factory=list)
    recipients_cc: List[str] = field(default_factory=list)
    subject_prefix: str = "[FINESIII RPA]"
    environment_label: str = "development"

    # ── Behavior ──
    level: str = "ERROR"               # threshold: ERROR or CRITICAL
    mode: str = "both"                 # "realtime" | "digest" | "both"
    async_send: bool = True            # send on a background thread (never block)
    throttle_window_seconds: float = 300.0   # dedup identical alerts within window
    digest_interval_seconds: float = 900.0   # periodic summary cadence (0 = off)
    max_alerts_per_digest: int = 200
    dry_run: bool = False              # build + log emails but do not transmit
    # Summary e-mail (2026-09-29): "interval" (digest_interval_seconds,
    # the earlier behaviour), "hourly", "daily" (at digest_time, JST) or
    # "off".
    digest_schedule: str = "interval"
    digest_time: str = "09:00"
    # E-mail when the service starts or stops (a start WITH problems is
    # always e-mailed).
    service_notices: bool = False

    # ── Resilience ──
    max_retries: int = 3
    backoff_base_seconds: float = 1.0
    backoff_max_seconds: float = 30.0
    # A failed e-mail is kept in the outbox and resent for this long
    # (hours); 0 = not kept.
    outbox_hours: float = 24.0

    # ── Branding / HTML template (optional; plain-text is always the fallback) ──
    html_enabled: bool = False
    template_path: str = ""            # client-owned HTML for per-error alerts
    digest_template_path: str = ""     # client-owned HTML for the digest summary
    logo_url: str = ""
    brand_color: str = "#003a70"
    company_name: str = ""
    support_contact: str = ""
    footer_text: str = ""

    # A configured value that could not be used (e.g. SMTP_PORT=abc); the
    # fallback is in the fields above, validate() reports it (BUG-043).
    config_error: str = ""

    @property
    def level_no(self) -> int:
        import logging
        return getattr(logging, str(self.level).upper(), logging.ERROR)

    @property
    def all_recipients(self) -> List[str]:
        return list(self.recipients_to) + list(self.recipients_cc)

    def validate(self) -> None:
        """Raise ValueError if required values for an ENABLED notifier are missing.

        A disabled notifier never validates (it's an inert no-op), so the bot can
        run with notifications off and no SMTP configured at all.
        """
        if not self.enabled:
            return
        if self.config_error:
            raise ValueError(f"notifications: {self.config_error}")
        missing = []
        if not self.smtp_host:
            missing.append("smtp_host")
        if not self.mail_from:
            missing.append("mail_from")
        if not self.recipients_to:
            missing.append("recipients_to")
        if self.use_ssl and self.use_starttls:
            raise ValueError(
                "notifications: choose either use_ssl (465) OR use_starttls (587), not both"
            )
        if self.security and self.security not in SECURITY_MODES:
            raise ValueError(
                f"notifications: invalid connection security "
                f"'{self.security}'")
        if self.username and self.effective_security == "none":
            raise ValueError(
                "notifications: a mail server login is never sent "
                "unencrypted — choose STARTTLS or SSL/TLS, or clear the "
                "username for a relay without login")
        if self.digest_schedule not in DIGEST_SCHEDULES:
            raise ValueError(
                f"notifications: invalid summary schedule "
                f"'{self.digest_schedule}'")
        if self.mode not in ("realtime", "digest", "both"):
            raise ValueError(f"notifications: invalid mode '{self.mode}'")
        if missing:
            raise ValueError(
                "notifications enabled but missing required setting(s): "
                + ", ".join(missing)
                + " — set the corresponding environment variables "
                "(see .env.notifications.example)."
            )

    @property
    def effective_security(self) -> str:
        """The connection security in force."""
        if self.security in SECURITY_MODES:
            return self.security
        if self.use_ssl:
            return "ssl"
        return "starttls" if self.use_starttls else "none"

    def masked(self) -> str:
        """One-line, secret-free summary for logs."""
        user = self.username or "(anonymous)"
        pw = "***" if self.password else "(none)"
        sec = self.effective_security
        to = ", ".join(self.recipients_to) or "(none)"
        return (
            f"enabled={self.enabled} host={self.smtp_host}:{self.smtp_port} "
            f"{sec} user={user} pw={pw} from={self.mail_from or '(none)'} "
            f"to=[{to}] mode={self.mode} level={self.level} dry_run={self.dry_run}"
        )


SECURITY_MODES = ("starttls_if_offered", "starttls", "ssl", "none")
DIGEST_SCHEDULES = ("interval", "hourly", "daily", "off")


def _env(name: Optional[str], default: str = "") -> str:
    """Read an environment variable by name, tolerating a missing/blank name."""
    if not name:
        return default
    return os.environ.get(name, default)


def _env_bool(name: Optional[str], default: bool) -> bool:
    """Boolean env override: unset/blank → default."""
    raw = _env(name, "")
    if raw.strip() == "":
        return default
    return raw.strip().lower() in ("1", "true", "yes", "on")


def load_notification_config(yaml_path: Optional[str] = None) -> NotificationSettings:
    """Load notification settings from YAML + environment variables.

    The YAML declares structure and the NAMES of env vars holding secrets/targets.
    Real values are resolved from os.environ at load time. Missing YAML simply
    yields a disabled (inert) settings object, so callers never crash.
    """
    path = yaml_path or DEFAULT_CONFIG_PATH
    raw = {}
    if path and Path(path).exists():
        with open(path, "r", encoding="utf-8") as f:
            raw = (yaml.safe_load(f) or {}).get("notifications", {}) or {}

    env_vars = raw.get("env_vars", {}) or {}
    smtp = raw.get("smtp", {}) or {}
    addressing = raw.get("addressing", {}) or {}
    behavior = raw.get("behavior", {}) or {}
    resilience = raw.get("resilience", {}) or {}
    branding = raw.get("branding", {}) or {}

    # ── enabled: env override wins, else YAML, else False ──
    enabled_env = _env(env_vars.get("enabled"))
    if enabled_env != "":
        enabled = enabled_env.strip().lower() in ("1", "true", "yes", "on")
    else:
        enabled = bool(raw.get("enabled", False))

    # ── SMTP ──
    host = _env(env_vars.get("smtp_host"), smtp.get("host", ""))
    port_raw = _env(env_vars.get("smtp_port"), str(smtp.get("port", 587)))
    config_error = ""
    try:
        port = int(str(port_raw).strip())
        if not 1 <= port <= 65535:
            raise ValueError(port_raw)
    except (TypeError, ValueError):
        port = 587
        source = (env_vars.get("smtp_port")
                  if _env(env_vars.get("smtp_port")) else "smtp.port")
        config_error = (f"{source} '{port_raw}' is not a valid port "
                        f"(1-65535)")
    username = _env(env_vars.get("username"), smtp.get("username", ""))
    password = _env(env_vars.get("password"), "")
    # Transport security: env overrides (console SMTP page) win; else the
    # YAML; else inferred from the port (465 = implicit SSL).
    use_ssl = _env_bool(env_vars.get("use_ssl"),
                        bool(smtp.get("use_ssl", port == 465)))
    use_starttls = _env_bool(env_vars.get("use_starttls"),
                             bool(smtp.get("use_starttls", not use_ssl)))
    # Connection security (2026-09-29). The console setting wins; else
    # the earlier switches. Port 25 with STARTTLS only from the file
    # (not switched on explicitly) uses STARTTLS when the relay offers
    # it — an internal relay on port 25 often does not.
    security = _env(env_vars.get("security", "SMTP_SECURITY")).strip().lower()
    if security not in SECURITY_MODES:
        security = str(smtp.get("security", "") or "").strip().lower()
    if security not in SECURITY_MODES and use_ssl and use_starttls:
        # Both earlier switches on: left as it is, so the conflict is
        # reported (validate) instead of silently resolved (NB-010).
        security = ""
    elif security not in SECURITY_MODES:
        # Neither switch set on the console: the port decides (465 is
        # SSL/TLS from the start, 25 STARTTLS when offered); the file's
        # switches are the defaults for any other port.
        explicit = (_env(env_vars.get("use_starttls")).strip() != ""
                    or _env(env_vars.get("use_ssl")).strip() != "")
        if not explicit and port == 465:
            security = "ssl"
        elif use_ssl:
            security = "ssl"
        elif use_starttls:
            security = ("starttls_if_offered"
                        if port == 25 and not explicit else "starttls")
        else:
            security = "none"
    if security:
        use_ssl = security == "ssl"
        use_starttls = security in ("starttls", "starttls_if_offered")
    verify_tls = _env_bool(env_vars.get("verify_tls", "SMTP_VERIFY_CERT"),
                           bool(smtp.get("verify_tls", True)))
    ca_file = _env(env_vars.get("ca_file", "SMTP_CA_FILE"),
                   str(smtp.get("ca_file", "") or "")).strip()
    local_hostname = _env(env_vars.get("local_hostname", "SMTP_EHLO_NAME"),
                          str(smtp.get("local_hostname", "") or "")).strip()
    timeout = _number(_env(env_vars.get("timeout", "SMTP_TIMEOUT")),
                      smtp.get("timeout_seconds", 30.0), 5.0, 300.0)

    # ── Addressing ──
    mail_from = _env(env_vars.get("mail_from"), addressing.get("mail_from", ""))
    to = _split_csv(_env(env_vars.get("recipients_to")))
    if not to:
        to = _split_csv_list(addressing.get("recipients_to"))
    cc = _split_csv(_env(env_vars.get("recipients_cc")))
    if not cc:
        cc = _split_csv_list(addressing.get("recipients_cc"))

    return NotificationSettings(
        enabled=enabled,
        smtp_host=host.strip(),
        smtp_port=port,
        use_starttls=use_starttls,
        use_ssl=use_ssl,
        username=username,
        password=password,
        timeout_seconds=timeout,
        security=security,
        verify_tls=verify_tls,
        ca_file=ca_file,
        local_hostname=local_hostname,
        mail_from=mail_from.strip(),
        recipients_to=to,
        recipients_cc=cc,
        subject_prefix=addressing.get("subject_prefix", "[FINESIII RPA]"),
        environment_label=str(addressing.get("environment_label", "development")),
        level=str(behavior.get("level", "ERROR")).upper(),
        mode=str(behavior.get("mode", "both")).lower(),
        async_send=bool(behavior.get("async_send", True)),
        throttle_window_seconds=float(behavior.get("throttle_window_seconds", 300.0)),
        digest_interval_seconds=float(behavior.get("digest_interval_seconds", 900.0)),
        max_alerts_per_digest=int(behavior.get("max_alerts_per_digest", 200)),
        dry_run=bool(behavior.get("dry_run", False)),
        digest_schedule=_choice(
            _env(env_vars.get("digest_schedule", "EMAIL_DIGEST")),
            behavior.get("digest_schedule", "daily"), DIGEST_SCHEDULES,
            "daily"),
        digest_time=_clock(_env(env_vars.get("digest_time",
                                             "EMAIL_DIGEST_TIME")),
                           behavior.get("digest_time", "09:00")),
        service_notices=_env_bool(
            env_vars.get("service_notices", "EMAIL_SERVICE_NOTICES"),
            bool(behavior.get("service_notices", False))),
        max_retries=int(resilience.get("max_retries", 3)),
        backoff_base_seconds=float(resilience.get("backoff_base_seconds", 1.0)),
        backoff_max_seconds=float(resilience.get("backoff_max_seconds", 30.0)),
        outbox_hours=_number(_env(env_vars.get("outbox_hours",
                                               "EMAIL_OUTBOX_HOURS")),
                             resilience.get("outbox_hours", 24), 0.0, 168.0),
        html_enabled=bool(branding.get("html_enabled", False)),
        template_path=str(branding.get("template_path", "") or ""),
        digest_template_path=str(branding.get("digest_template_path", "") or ""),
        logo_url=str(branding.get("logo_url", "") or ""),
        brand_color=str(branding.get("brand_color", "#003a70") or "#003a70"),
        company_name=str(branding.get("company_name", "") or ""),
        support_contact=str(branding.get("support_contact", "") or ""),
        footer_text=str(branding.get("footer_text", "") or ""),
        config_error=config_error,
    )


def _number(raw, default, low: float, high: float) -> float:
    """A number from the environment (else the file), kept in range."""
    for candidate in (raw, default):
        try:
            if str(candidate).strip() == "":
                continue
            return min(max(float(candidate), low), high)
        except (TypeError, ValueError):
            continue
    return low


def _choice(raw, default, allowed, fallback: str) -> str:
    for candidate in (raw, default):
        text = str(candidate or "").strip().lower()
        if text in allowed:
            return text
    return fallback


def _clock(raw, default) -> str:
    """HH:MM, else 09:00."""
    for candidate in (raw, default):
        parts = str(candidate or "").strip().split(":")
        if len(parts) == 2 and all(p.isdigit() for p in parts) \
                and 0 <= int(parts[0]) <= 23 and 0 <= int(parts[1]) <= 59:
            return f"{int(parts[0]):02d}:{int(parts[1]):02d}"
    return "09:00"


def _split_csv_list(value) -> List[str]:
    """Accept either a YAML list or a CSV string for recipients."""
    if value is None:
        return []
    if isinstance(value, list):
        return [str(v).strip() for v in value if str(v).strip()]
    return _split_csv(str(value))
