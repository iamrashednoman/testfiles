"""
Tiny, dependency-free HTML template renderer for branded alert emails.

Deliberately minimal (no Jinja/templating dependency): the client owns a plain
HTML file containing ``{{placeholder}}`` tokens; we substitute values, escaping
every dynamic value to prevent HTML/script injection from log content.

Unknown placeholders render as empty strings, so a client can trim the template
freely without breaking rendering.
"""
from __future__ import annotations

import html
import re
from pathlib import Path
from typing import Dict, Optional

_TOKEN = re.compile(r"\{\{\s*([a-zA-Z0-9_]+)\s*\}\}")


def text_to_html(text: str) -> str:
    """Escape plain text and preserve line breaks for safe HTML embedding."""
    if not text:
        return ""
    return html.escape(text).replace("\n", "<br>\n")


def render_template(template: str, context: Dict[str, str]) -> str:
    """Replace ``{{key}}`` tokens with HTML-escaped context values.

    Values already containing intentional markup (e.g. the pre-formatted
    ``message_html`` block) should be passed via a key ending in ``_html`` and
    are inserted verbatim; all other values are escaped.
    """
    def _sub(match: "re.Match") -> str:
        key = match.group(1)
        if key not in context:
            return ""
        value = context[key]
        if value is None:
            return ""
        value = str(value)
        # Keys ending in _html are trusted (already escaped/whitelisted upstream).
        return value if key.endswith("_html") else html.escape(value)

    return _TOKEN.sub(_sub, template)


def load_template(path: Optional[str], fallback: str) -> str:
    """Load an HTML template file; fall back to the built-in default if the
    path is blank/missing/unreadable (never raises)."""
    if path:
        try:
            p = Path(path)
            if p.exists():
                return p.read_text(encoding="utf-8")
        except OSError:
            pass
    return fallback


# ── Data tables (2026-09-29) ───────────────────────────────────────
# One (label, value) list gives both the HTML table rows of a template
# and the lines of the plain-text part, so the two always carry the
# same data.

_LABEL_CELL = ('<td width="170" style="padding:9px 14px;background:#f5f7f9;'
               'color:#5d738d;{border}font-size:12px;"><strong>{label}'
               '</strong></td>')
_VALUE_CELL = '<td style="padding:9px 14px;{border}font-size:13px;{font}">{value}</td>'
_MONO = "font-family:Consolas,'Courier New',monospace;"


def rows_html(rows, mono: bool = False) -> str:
    """HTML table rows from [(label, value), …]; every value escaped.
    A value given as ("html", markup) is inserted as trusted markup."""
    out = []
    items = [(k, v) for k, v in rows if v not in (None, "")]
    for i, (label, value) in enumerate(items):
        border = ("border-bottom:1px solid #e6e6e6;"
                  if i < len(items) - 1 else "")
        if isinstance(value, tuple) and value and value[0] == "html":
            shown = value[1]
        else:
            shown = html.escape(str(value)).replace("\n", "<br>")
        out.append("<tr>" + _LABEL_CELL.format(
            border=border, label=html.escape(str(label)))
            + _VALUE_CELL.format(border=border, value=shown,
                                 font=_MONO if mono else "") + "</tr>")
    return "".join(out)


def rows_text(rows) -> str:
    """The same rows as plain-text lines ("label: value")."""
    lines = []
    for label, value in rows:
        if value in (None, ""):
            continue
        if isinstance(value, tuple) and value and value[0] == "html":
            continue
        lines.append(f"{label}: {value}")
    return "\n".join(lines)
