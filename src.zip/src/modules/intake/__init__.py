"""Public API-first intake — THE formal contract for all upstream systems.

Ports from v2: service/api.py (SubmitRequest + validation),
service/models.py (ProcessingRequest, Operation, RequestStatus,
request/transaction id generation, JST timestamps).
"""
