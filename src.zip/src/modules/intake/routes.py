"""Intake API routes — the public CRUD contract.

Endpoints (all under /api/v1):
  POST   /requests               Submit (202; 400 invalid; 409 duplicate)
  GET    /requests               List (status filter validated, paginated)
  GET    /requests/{id}          Status detail
  DELETE /requests/{id}          Cancel (queued only) — soft delete
  POST   /requests/{id}/retry    Re-queue a failed request (approved #2)
  GET    /transactions           Audit history (read-only)
  GET    /transactions/export    CSV export (formula-safe)
  GET    /transactions/{id}      Transaction detail
  GET    /queue                  Queue depth + dispatcher state
  GET    /health                 Liveness incl. database reachability

Transactions are read-only by design (IAM compliance): there is no
update or delete verb for history, and there never should be.
"""
from __future__ import annotations

import json
import logging

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import JSONResponse, Response

from src.modules.intake.models import (
    ACTIVE_STATUSES, ProcessingRequest, RequestStatus, now_jst,
)
from src.modules.intake import passwords
from src.modules.intake.schemas import (
    SubmitRequest, validate_iso_date, validate_request_format,
)

_VALID_STATUSES = {s.value for s in RequestStatus}
# metadata is stored with the request and copied into audit and e-mail;
# an unbounded blob would bloat all three (approved D15).
_MAX_METADATA_BYTES = 64 * 1024
# The text fields are bounded as well (NB-014): each is stored with the
# request and copied into every audit event. Passwords are 8 characters;
# the limit only stops an oversized value before it is checked.
_FIELD_LIMITS = (("ticket_id", 80), ("source", 40), ("operation", 40),
                 ("affiliation_code", 40), ("employee_code", 40),
                 ("password", 128))
_REQUESTS_PATH = "/api/v1/requests"

_log = logging.getLogger(__name__)


def database_errors() -> tuple:
    """Exception types that mean the database cannot be reached (NB-015).
    psycopg_pool.PoolTimeout is a psycopg.OperationalError."""
    import sqlite3
    errors = [sqlite3.OperationalError]
    try:
        import psycopg
        errors += [psycopg.OperationalError, psycopg.InterfaceError]
    except ImportError:
        pass
    return tuple(errors)


async def database_unavailable(request, exc) -> JSONResponse:
    """503 with Retry-After for a request that failed because the
    database cannot be reached — instead of a bare 500 and a stack trace
    (NB-015). Registered for database_errors() in create_app."""
    path = request.url.path
    _log.warning(f"Database not reachable — {request.method} {path}: "
                 f"{type(exc).__name__}: {' '.join(str(exc).split())[:300]}")
    not_queued = (request.method == "POST"
                  and path.rstrip("/") == _REQUESTS_PATH)
    return JSONResponse(
        status_code=503, headers={"Retry-After": "30"},
        content={"detail": {
            "status": "database_unavailable",
            "message": ("Database not reachable — "
                        + ("the request was not queued; " if not_queued
                           else "")
                        + "try again later"),
        }})


def checked_dates(date_from, date_to) -> tuple:
    """(date_from, date_to) validated as ISO dates — 400 otherwise.
    Returned unchanged (an empty value stays empty: no filter, and the
    paged/unpaged choice made on it is exactly as before)."""
    try:
        validate_iso_date("date_from", date_from)
        validate_iso_date("date_to", date_to)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    # Reversed dates are refused, not answered with nothing (UAT-L03,
    # 2026-10-04).
    if date_from and date_to and str(date_to)[:10] < str(date_from)[:10]:
        raise HTTPException(status_code=400,
                            detail="The end date is before the start date")
    return date_from, date_to


def audit_unavailable(audit, error: Exception) -> HTTPException:
    """503 for an audit read that failed because the audit database is
    unreachable. Events are not lost — they wait in the local spool —
    so the answer says how many are waiting instead of a bare 500."""
    try:
        waiting = int(audit.pending())
    except Exception:
        waiting = 0
    # Debug only: a console polling the audit page would otherwise
    # write a warning per request while the database is down.
    _log.debug(f"Audit query failed: {type(error).__name__}: {error}")
    return HTTPException(status_code=503, detail={
        "status": "audit_unavailable",
        "message": (f"Audit database not reachable — {waiting} event(s) "
                    f"waiting to be written"),
        "pending_delivery": waiting,
    })


def build_router(queue_store, transaction_store, dispatcher,
                 auth_dep, cfg, availability=None,
                 on_rejected=None, audit=None,
                 action_dep=None, cancel_dep=None,
                 snow_clients=None, submit_dep=None,
                 console_deps=None, on_cancelled=None) -> APIRouter:
    """action_dep / cancel_dep guard the two routes that CHANGE queued
    work (retry and cancel respectively); submit_dep guards submission
    the same way (requests.submit for a person, 2026-10-03).

    console_deps (2026-10-03, RQ-01): permission dependencies for the
    console's own routes under /console — "view" (requests.view),
    "audit" (audit.view), "submit", "retry", "cancel". They answer the
    signed-in console whether or not the machine API key is switched
    on, with the same handlers as the API routes. None = not added.

    Machines (the API key) pass through unchanged; a person signed into
    the console must hold the matching permission. None = no console, so
    the behaviour is exactly what it was before roles existed. A missing
    cancel_dep falls back to action_dep (the pre-split behaviour).
    """
    router = APIRouter(prefix="/api/v1")

    async def _no_action_check() -> str:
        return "service"

    action_dep = action_dep or _no_action_check
    cancel_dep = cancel_dep or action_dep
    submit_dep = submit_dep or _no_action_check

    def _audit_event(action: str, severity: str = "INFO", **fields):
        """Emit an api-category audit event. event() never raises."""
        if audit is not None:
            audit.event("api", action, severity=severity, **fields)

    def _notify_rejected(rejection_type: str, reason: str, details: dict):
        """Fire the optional rejection hook (email alert). A hook
        failure never affects the API response."""
        if on_rejected is None:
            return
        try:
            on_rejected(rejection_type, reason, details)
        except Exception:
            pass

    def _generate_password() -> tuple[str, str]:
        return passwords.generate_unique(
            queue_store.password_fingerprint_used,
            symbols=getattr(cfg, "password_symbols", "@"),
            exclude_lookalikes=bool(
                getattr(cfg, "password_exclude_lookalikes", True)))

    def _bounded_fields(body: SubmitRequest) -> dict:
        """The request's identifying fields for an audit record, each cut
        to its limit (NB-014)."""
        limits = dict(_FIELD_LIMITS)
        return {name: str(getattr(body, name) or "")[:limits[name]]
                for name in ("operation", "affiliation_code",
                             "employee_code", "ticket_id", "source")}

    def _request_details(body: SubmitRequest, **extra) -> dict:
        return {
            "operation": body.operation,
            "affiliation_code": body.affiliation_code,
            "employee_code": body.employee_code,
            "ticket_id": body.ticket_id or "",
            "source": body.source,
            **extra,
        }

    @router.post("/requests", status_code=202)
    def submit_request(body: SubmitRequest, client=Depends(auth_dep),
                       submitter=Depends(submit_dep)):
        # A person signed into the console needs requests.submit; the
        # machine API key passes as before (RQ-12, 2026-10-03).
        return _submit(body, client)

    def _submit(body: SubmitRequest, client) -> dict:
        def _submit_event(action: str, severity: str = "INFO", **fields):
            # Who submitted — the machine client or the console user —
            # on every submission and rejection (DR-06, 2026-10-03).
            _audit_event(action, severity=severity,
                         actor=str(client or "anonymous"), **fields)

        for name, limit in _FIELD_LIMITS:
            if len(str(getattr(body, name) or "")) > limit:
                reason = f"{name} exceeds {limit} characters"
                _submit_event("request_rejected", severity="WARNING",
                             **_bounded_fields(body), status="too_large",
                             error_message=reason)
                raise HTTPException(status_code=413, detail=reason)
        try:
            metadata_bytes = len(json.dumps(
                body.metadata or {}, ensure_ascii=False,
                default=str).encode("utf-8"))
        except Exception:
            metadata_bytes = _MAX_METADATA_BYTES + 1
        if metadata_bytes > _MAX_METADATA_BYTES:
            reason = (f"metadata exceeds {_MAX_METADATA_BYTES // 1024} KB "
                      f"({metadata_bytes} bytes)")
            _submit_event("request_rejected", severity="WARNING",
                         **_bounded_fields(body), status="too_large",
                         error_message=reason)
            raise HTTPException(status_code=413, detail=reason)

        problems = validate_request_format(body)
        if problems and (cfg.strict_validation or
                         "operation must be" in problems[0]):
            reason = "; ".join(problems)
            # A person on the console sees the answer at once; only a
            # program's rejected request is e-mailed (E2E-L10).
            if not str(client or "").startswith("user:"):
                _notify_rejected("VALIDATION FAILED", reason,
                                 _request_details(body))
            _submit_event("request_rejected", severity="WARNING",
                         operation=body.operation,
                         affiliation_code=body.affiliation_code,
                         employee_code=body.employee_code,
                         ticket_id=body.ticket_id or "",
                         source=body.source, status="validation_failed",
                         error_message=reason)
            raise HTTPException(status_code=400, detail=reason)

        metadata = dict(body.metadata or {})
        # Ticket details make the bot WRITE to that ServiceNow ticket
        # after the mainframe step. Only the ServiceNow connector's own
        # key may supply them (SN-02 hardening, approved 2026-09-27);
        # the close-out verifies the ticket with ServiceNow as well.
        if snow_clients and "snow_details" in metadata \
                and str(client) not in snow_clients:
            _submit_event("request_rejected", severity="WARNING",
                         operation=body.operation,
                         affiliation_code=body.affiliation_code,
                         employee_code=body.employee_code,
                         ticket_id=body.ticket_id or "",
                         source=body.source, status="forbidden",
                         error_message="ServiceNow ticket details from a "
                                       "client that is not the connector",
                         detail={"client": str(client)})
            raise HTTPException(
                status_code=403,
                detail=("ServiceNow ticket details (metadata.snow_details) "
                        "are accepted only from the ServiceNow connector"))
        # These markers are the platform's own; a caller cannot preset them.
        for reserved in ("password_supplied", "snow_writeback",
                         "password_generated", "password_fp",
                         "submitted_by"):
            metadata.pop(reserved, None)
        # Who submitted it, for the history export (E2E-L15).
        metadata["submitted_by"] = str(client or "anonymous")
        password = body.password or ""
        if body.operation != "provision":
            # A removal never uses a password; never store one sent
            # along with it.
            password = ""
        if body.operation == "provision":
            if password:
                metadata["password_supplied"] = True
                try:
                    # Recorded so a generated password never equals one
                    # already used (e.g. typed for a test).
                    metadata["password_fp"] = passwords.fingerprint(password)
                except Exception:
                    pass
            else:
                # Client rule (2026-09-28): the bot generates a random,
                # never-reused password — no fixed default any more.
                try:
                    password, fp = _generate_password()
                except database_errors():
                    raise       # answered 503 by database_unavailable (NB-015)
                except Exception as e:
                    raise HTTPException(
                        status_code=503,
                        detail=f"No initial password could be generated: {e}")
                metadata["password_generated"] = True
                metadata["password_fp"] = fp

        request = ProcessingRequest(
            operation=body.operation,
            affiliation_code=(body.affiliation_code or "").strip(),
            employee_code=(body.employee_code or "").strip(),
            password=password,
            source=body.source,
            ticket_id=body.ticket_id or "",
            metadata=metadata,
        )

        duplicate = queue_store.find_duplicate(request)
        if duplicate is None and not (request.source == "servicenow"
                                      and "snow_details" in metadata):
            # The same account and operation already queued or running
            # under another (or no) ticket number (E2E-M01, D-03). The
            # ServiceNow connector has its own rules for its tickets.
            duplicate = queue_store.find_content_duplicate(
                request.operation, request.affiliation_code,
                request.employee_code, statuses=ACTIVE_STATUSES)
        if duplicate is not None:
            _notify_rejected(
                "DUPLICATE REQUEST",
                f"Duplicate of {duplicate.request_id} "
                f"(status: {duplicate.status})",
                _request_details(
                    body, original_request_id=duplicate.request_id,
                    original_status=duplicate.status))
            _submit_event("request_rejected", severity="WARNING",
                         operation=body.operation,
                         affiliation_code=body.affiliation_code,
                         employee_code=body.employee_code,
                         ticket_id=body.ticket_id or "",
                         source=body.source, status="duplicate",
                         detail={"original_request_id":
                                 duplicate.request_id})
            raise HTTPException(status_code=409, detail={
                "status": "duplicate",
                "original_request_id": duplicate.request_id,
                "original_status": duplicate.status,
                "message": f"Duplicate of {duplicate.request_id} "
                           f"(status: {duplicate.status})",
            })

        if not queue_store.enqueue(request):
            # Lost the race against a concurrent identical submit —
            # the partial unique index rejected us (approved fix #4).
            racer = queue_store.find_duplicate(request)
            raise HTTPException(status_code=409, detail={
                "status": "duplicate",
                "original_request_id": racer.request_id if racer else "",
                "original_status": racer.status if racer else "",
                "message": "Duplicate request (concurrent submission)",
            })

        mainframe_available = (availability.can_start_new_work()
                               if availability is not None else None)
        # Processing paused on the System page (UAT-L11, 2026-10-04):
        # said first, whatever the mainframe's state.
        paused = bool(dispatcher is not None
                      and dispatcher.status().get("paused"))
        if paused:
            message = ("Request queued. Processing is paused on the "
                       "System page; it starts when processing is "
                       "resumed.")
        elif mainframe_available is False and \
                availability.is_within_time_window(check_buffer=True):
            # Inside the operating window: the health probe failed.
            message = ("Request queued. Mainframe not reachable at the "
                       "moment. Will process when available.")
        elif mainframe_available is False and \
                availability.is_within_time_window(check_buffer=False):
            # The stop-accepting buffer before the window closes: inside
            # the window, so not "offline (outside …)" (NB-017).
            message = (f"Request queued. The operating window closes at "
                       f"{availability.window_end.strftime('%H:%M')} JST; "
                       f"new work starts again when it reopens at "
                       f"{availability.window_start.strftime('%H:%M')} JST.")
        elif mainframe_available is False:
            window = availability.status()["window"]
            message = (f"Request queued. Mainframe offline (outside "
                       f"{window}). Will process when available.")
        elif mainframe_available:
            message = ("Request queued. Mainframe available — "
                       "processing shortly.")
        else:
            message = "Request queued."

        try:
            queue_position = queue_store.queue_position(request.request_id)
        except database_errors():
            # Already queued: never answer "not queued" now (NB-015).
            queue_position = None
        _submit_event("request_submitted",
                     request_id=request.request_id,
                     ticket_id=request.ticket_id,
                     operation=request.operation,
                     affiliation_code=request.affiliation_code,
                     employee_code=request.employee_code,
                     source=request.source,
                     detail={"queue_position": queue_position,
                             "mainframe_available": mainframe_available})
        return {
            "request_id": request.request_id,
            "status": request.status,
            "queue_position": queue_position,
            "mainframe_available": mainframe_available,
            "message": message,
        }

    @router.get("/requests")
    def list_requests(
        status: str | None = Query(None),
        limit: int = Query(100, ge=1, le=500),
        # Console data tables (2026-09-28) — all optional. Without them
        # the answer is exactly as before.
        offset: int | None = Query(None, ge=0),
        sort: str | None = Query(None, max_length=40),
        order: str | None = Query(None, pattern="^(asc|desc)$"),
        q: str | None = Query(None, max_length=100),
        operation: str | None = Query(None, max_length=40),
        source: str | None = Query(None, max_length=40),
        date_from: str | None = Query(None, max_length=40),
        date_to: str | None = Query(None, max_length=40),
        result_code: str | None = Query(None, max_length=40),
        client=Depends(auth_dep),
    ):
        if status is not None and status not in _VALID_STATUSES:
            raise HTTPException(
                status_code=400,
                detail=f"Invalid status '{status}'. "
                       f"Valid: {sorted(_VALID_STATUSES)}",
            )
        date_from, date_to = checked_dates(date_from, date_to)
        if any(v is not None for v in (offset, sort, order, q, operation,
                                       source, date_from, date_to,
                                       result_code)):
            page, total = queue_store.list_page(
                offset=offset or 0, limit=limit, sort=sort, order=order,
                q=q, status=status, operation=operation, source=source,
                date_from=date_from, date_to=date_to,
                result_code=result_code)
            return {"count": len(page), "total": total,
                    "offset": offset or 0, "limit": limit,
                    "requests": [r.to_public_dict() for r in page]}
        requests = queue_store.list_requests(status=status, limit=limit)
        return {"count": len(requests),
                "requests": [r.to_public_dict() for r in requests]}

    @router.get("/requests/{request_id}")
    def get_request(request_id: str, client=Depends(auth_dep)):
        req = queue_store.get(request_id)
        if req is None:
            raise HTTPException(status_code=404, detail="Request not found")
        response = req.to_public_dict()
        if req.status == RequestStatus.QUEUED.value:
            response["queue_position"] = queue_store.queue_position(request_id)
        return response

    @router.delete("/requests/{request_id}")
    def cancel_request(request_id: str,
                       client=Depends(auth_dep),
                       actor=Depends(cancel_dep)):
        return _cancel(request_id, actor)

    def _cancel(request_id: str, actor) -> dict:
        req = queue_store.get(request_id)
        if req is None:
            raise HTTPException(status_code=404, detail="Request not found")
        if queue_store.cancel(request_id):
            _audit_event("request_cancelled",
                         request_id=request_id, ticket_id=req.ticket_id,
                         operation=req.operation,
                         employee_code=req.employee_code,
                         actor=actor)
            if on_cancelled is not None:
                # The ticket note is written now, not by the next polls
                # (E2E-L14); it never fails the cancel.
                try:
                    on_cancelled(request_id)
                except Exception:
                    pass
            return {"request_id": request_id, "status": "cancelled"}
        raise HTTPException(
            status_code=409,
            detail=f"Cannot cancel — request is '{req.status}' "
                   "(only queued requests can be cancelled)",
        )

    @router.post("/requests/{request_id}/retry", status_code=202)
    def retry_request(request_id: str,
                      client=Depends(auth_dep),
                      actor=Depends(action_dep)):
        return _retry(request_id, actor)

    def _retry(request_id: str, actor) -> dict:
        req = queue_store.get(request_id)
        if req is None:
            raise HTTPException(status_code=404, detail="Request not found")
        from src.modules.queue.services import RetrySuperseded
        # The ticket carried a password and it is no longer held (erased
        # after the retention period): never provision with a different
        # password than the one requested (DATA-01).
        if (req.status == RequestStatus.FAILED.value
                and req.operation == "provision" and not req.password
                and isinstance(req.metadata, dict)
                and req.metadata.get("password_supplied")):
            raise HTTPException(status_code=409, detail={
                "status": "password_expired",
                "message": ("Cannot retry — the password supplied with "
                            "this request is no longer held. Submit the "
                            "request again with its password."),
            })
        # A provision with no password held and no record of where its
        # password came from (a request from before 2026-09-28): never
        # run again with a guessed password (SY-06, 2026-10-03).
        if (req.status == RequestStatus.FAILED.value
                and req.operation == "provision" and not req.password
                and not (isinstance(req.metadata, dict)
                         and (req.metadata.get("password_supplied")
                              or req.metadata.get("password_generated")))):
            raise HTTPException(status_code=409, detail={
                "status": "password_expired",
                "message": ("Cannot retry — no password is held for this "
                            "provisioning request. Submit the request "
                            "again with its password."),
            })
        # A generated password erased after the retention period: the
        # user was never told it (only a success announces it), so the
        # retry gets a new, never-used one (2026-09-28).
        if (req.status == RequestStatus.FAILED.value
                and req.operation == "provision" and not req.password
                and isinstance(req.metadata, dict)
                and req.metadata.get("password_generated")):
            try:
                new_password, fp = _generate_password()
            except database_errors():
                raise           # answered 503 by database_unavailable (NB-015)
            except Exception as e:
                raise HTTPException(
                    status_code=503,
                    detail=f"No initial password could be generated: {e}")
            queue_store.set_password(request_id, new_password, fp)
        try:
            requeued = queue_store.retry(request_id)
        except RetrySuperseded:
            newer = queue_store.find_duplicate(req)
            raise HTTPException(status_code=409, detail={
                "status": "superseded",
                "newer_request_id": newer.request_id if newer else "",
                "newer_status": newer.status if newer else "",
                "message": ("Cannot retry — this request was submitted "
                            "again after it failed"
                            + (f" (request {newer.request_id}, status "
                               f"{newer.status})" if newer else "")
                            + ". Use the newer request."),
            })
        if requeued:
            # Who re-ran what (AUD-01).
            _audit_event("request_retried", severity="WARNING",
                         request_id=request_id, ticket_id=req.ticket_id,
                         operation=req.operation,
                         employee_code=req.employee_code,
                         actor=actor,
                         detail={"previous_error": (req.error or "")[:200],
                                 "previous_attempts": req.attempt_count})
            return {
                "request_id": request_id,
                "status": RequestStatus.QUEUED.value,
                "queue_position": queue_store.queue_position(request_id),
                "message": "Request re-queued for retry.",
            }
        raise HTTPException(
            status_code=409,
            detail=f"Cannot retry — request is '{req.status}' "
                   "(only failed requests can be retried)",
        )

    # ── Transactions (read-only) ──

    @router.get("/transactions")
    def list_transactions(
        status: str | None = Query(None),
        employee_code: str | None = Query(None),
        date_from: str | None = Query(None),
        date_to: str | None = Query(None),
        limit: int = Query(200, ge=1, le=1000),
        # Console data tables (2026-09-28) — all optional.
        offset: int | None = Query(None, ge=0),
        sort: str | None = Query(None, max_length=40),
        order: str | None = Query(None, pattern="^(asc|desc)$"),
        q: str | None = Query(None, max_length=100),
        operation: str | None = Query(None, max_length=40),
        source: str | None = Query(None, max_length=40),
        # "Needs verification" = done + UNCONFIRMED (RQ-06, 2026-10-03).
        result_code: str | None = Query(None, max_length=40),
        client=Depends(auth_dep),
    ):
        if status is not None and status not in _VALID_STATUSES:
            raise HTTPException(
                status_code=400,
                detail=f"Invalid status '{status}'. "
                       f"Valid: {sorted(_VALID_STATUSES)}",
            )
        date_from, date_to = checked_dates(date_from, date_to)
        if any(v is not None for v in (offset, sort, order, q, operation,
                                       source, result_code)):
            page, total = transaction_store.list_page(
                offset=offset or 0, limit=limit, sort=sort, order=order,
                q=q, status=status, employee_code=employee_code,
                operation=operation, source=source, result_code=result_code,
                date_from=date_from, date_to=date_to)
            return {"count": len(page), "total": total,
                    "offset": offset or 0, "limit": limit,
                    "transactions": page,
                    "statistics": transaction_store.statistics()}
        records = transaction_store.list_transactions(
            status=status, employee_code=employee_code,
            date_from=date_from, date_to=date_to, limit=limit)
        return {"count": len(records), "transactions": records,
                "statistics": transaction_store.statistics()}

    # Registered before /{transaction_id} — route order is load-bearing.
    @router.get("/transactions/export")
    def export_transactions(
        date_from: str | None = Query(None),
        date_to: str | None = Query(None),
        client=Depends(auth_dep),
    ):
        """The earlier history export (kept for existing callers). Since
        2026-10-03 (X-04) it uses the console's export writer: UTF-8
        with a byte-order mark, every spreadsheet formula neutralised,
        no server folder, the same row limit, and it is audited."""
        from src.modules.console.metrics import (
            EXPORT_MAX_ROWS, TRANSACTION_EXPORT_COLUMNS, to_csv,
        )
        date_from, date_to = checked_dates(date_from, date_to)
        rows, total = transaction_store.list_page(
            offset=0, limit=EXPORT_MAX_ROWS, date_from=date_from,
            date_to=date_to)
        _audit_event("data_exported", severity="WARNING", actor=str(client),
                     detail={"table": "transactions", "route": "api",
                             "rows": len(rows), "total": total,
                             "truncated": total > len(rows),
                             "filters": {k: v for k, v in (
                                 ("date_from", date_from),
                                 ("date_to", date_to)) if v}})
        filename = f"finesiii_audit_{now_jst().strftime('%Y%m%d_%H%M%S')}.csv"
        return Response(
            content=to_csv(rows, TRANSACTION_EXPORT_COLUMNS).encode("utf-8"),
            media_type="text/csv",
            headers={"Content-Disposition":
                     f'attachment; filename="{filename}"',
                     "Cache-Control": "no-store",
                     "X-Export-Rows": str(len(rows)),
                     "X-Export-Total": str(total),
                     "X-Export-Truncated": str(total > len(rows)).lower()},
        )

    @router.get("/transactions/{transaction_id}")
    def get_transaction(transaction_id: str, client=Depends(auth_dep)):
        txn = transaction_store.get(transaction_id)
        if txn is None:
            raise HTTPException(status_code=404,
                                detail="Transaction not found")
        return txn

    # ── Operational ──

    @router.get("/queue")
    def queue_status(client=Depends(auth_dep)):
        return {
            "queue": queue_store.queue_depth(),
            "dispatcher": (dispatcher.status() if dispatcher is not None
                           else {"running": False,
                                 "mode": "api-only (no executor)"}),
            "availability": (availability.status()
                             if availability is not None else None),
        }

    @router.get("/audit/events")
    def audit_events(
        category: str | None = Query(None),
        action: str | None = Query(None),
        severity: str | None = Query(None),
        request_id: str | None = Query(None),
        date_from: str | None = Query(None),
        date_to: str | None = Query(None),
        limit: int = Query(200, ge=1, le=1000),
        # Console data tables (2026-09-28) — all optional.
        offset: int | None = Query(None, ge=0),
        sort: str | None = Query(None, max_length=40),
        order: str | None = Query(None, pattern="^(asc|desc)$"),
        q: str | None = Query(None, max_length=100),
        ticket_id: str | None = Query(None, max_length=80),
        operation: str | None = Query(None, max_length=40),
        client=Depends(auth_dep),
    ):
        if audit is None:
            raise HTTPException(
                status_code=503,
                detail="Audit trail is disabled (audit_enabled: false)")
        date_from, date_to = checked_dates(date_from, date_to)
        if any(v is not None for v in (offset, sort, order, q, ticket_id,
                                       operation)):
            try:
                page, total = audit.query_page(
                    offset=offset or 0, limit=limit, sort=sort, order=order,
                    q=q, category=category, action=action,
                    severity=severity, request_id=request_id,
                    ticket_id=ticket_id, operation=operation,
                    date_from=date_from, date_to=date_to)
            except Exception as e:
                raise audit_unavailable(audit, e)
            return {"count": len(page), "total": total,
                    "offset": offset or 0, "limit": limit, "events": page,
                    "pending_delivery": audit.pending()}
        try:
            events = audit.query(
                category=category, action=action, severity=severity,
                request_id=request_id, date_from=date_from, date_to=date_to,
                limit=limit)
        except Exception as e:
            raise audit_unavailable(audit, e)
        return {"count": len(events), "events": events,
                "pending_delivery": audit.pending()}

    @router.get("/ping")
    async def ping():
        """Unauthenticated liveness probe: "is the process answering?"
        and nothing else — no database state, no queue depth, no
        configuration. The desktop shell polls this while the service
        starts, because /health (below) correctly requires the API key
        and the shell holds none. Safe to expose: the response carries
        no information an attacker could use."""
        return {"status": "ok"}

    @router.get("/health")
    def health(client=Depends(auth_dep)):
        db_ok = True
        try:
            queue_store.db.fetchone("SELECT 1 AS ok")
        except Exception:
            db_ok = False
        body = {
            "service": "up",
            "database": "up" if db_ok else "down",
            "engine": queue_store.db.engine,
            "timestamp": now_jst().isoformat(),
            "queue": queue_store.queue_depth() if db_ok else None,
            "availability": (availability.status()
                             if availability is not None else None),
        }
        # A monitor reading only the status code must see the outage.
        from fastapi.encoders import jsonable_encoder
        return JSONResponse(content=jsonable_encoder(body),
                            status_code=200 if db_ok else 503)

    if console_deps:
        _add_console_routes(router, console_deps, list_requests,
                            list_transactions, audit_events, _submit,
                            _retry, _cancel, audit_event=_audit_event)
    return router


def _add_console_routes(router, deps, list_requests, list_transactions,
                        audit_events, submit, retry, cancel,
                        audit_event=None) -> None:
    """The console's own request, history and audit routes (RQ-01,
    2026-10-03). Same handlers and answers as /requests, /transactions
    and /audit/events, but guarded by the signed-in person's permission
    only: the console keeps working when the machine API key is switched
    on (AUTH_ENABLED) without the console grant."""

    @router.get("/console/requests")
    def console_requests(
        status: str | None = Query(None),
        limit: int = Query(100, ge=1, le=500),
        offset: int = Query(0, ge=0),
        sort: str | None = Query(None, max_length=40),
        order: str | None = Query(None, pattern="^(asc|desc)$"),
        q: str | None = Query(None, max_length=100),
        operation: str | None = Query(None, max_length=40),
        source: str | None = Query(None, max_length=40),
        date_from: str | None = Query(None, max_length=40),
        date_to: str | None = Query(None, max_length=40),
        result_code: str | None = Query(None, max_length=40),
        user=Depends(deps["view"]),
    ):
        return list_requests(status=status, limit=limit, offset=offset,
                             sort=sort, order=order, q=q,
                             operation=operation, source=source,
                             date_from=date_from, date_to=date_to,
                             result_code=result_code, client=None)

    @router.get("/console/transactions")
    def console_transactions(
        status: str | None = Query(None),
        employee_code: str | None = Query(None),
        date_from: str | None = Query(None),
        date_to: str | None = Query(None),
        limit: int = Query(200, ge=1, le=1000),
        offset: int = Query(0, ge=0),
        sort: str | None = Query(None, max_length=40),
        order: str | None = Query(None, pattern="^(asc|desc)$"),
        q: str | None = Query(None, max_length=100),
        operation: str | None = Query(None, max_length=40),
        source: str | None = Query(None, max_length=40),
        result_code: str | None = Query(None, max_length=40),
        user=Depends(deps["view"]),
    ):
        return list_transactions(
            status=status, employee_code=employee_code, date_from=date_from,
            date_to=date_to, limit=limit, offset=offset, sort=sort,
            order=order, q=q, operation=operation, source=source,
            result_code=result_code, client=None)

    @router.get("/console/audit/events")
    def console_audit_events(
        category: str | None = Query(None),
        action: str | None = Query(None),
        severity: str | None = Query(None),
        request_id: str | None = Query(None),
        date_from: str | None = Query(None),
        date_to: str | None = Query(None),
        limit: int = Query(200, ge=1, le=1000),
        offset: int = Query(0, ge=0),
        sort: str | None = Query(None, max_length=40),
        order: str | None = Query(None, pattern="^(asc|desc)$"),
        q: str | None = Query(None, max_length=100),
        ticket_id: str | None = Query(None, max_length=80),
        operation: str | None = Query(None, max_length=40),
        user=Depends(deps["audit"]),
    ):
        return audit_events(
            category=category, action=action, severity=severity,
            request_id=request_id, date_from=date_from, date_to=date_to,
            limit=limit, offset=offset, sort=sort, order=order, q=q,
            ticket_id=ticket_id, operation=operation, client=None)

    @router.post("/console/requests", status_code=202)
    def console_submit(body: SubmitRequest, user=Depends(deps["submit"])):
        """A request entered on the console (RQ-12): the same checks as
        any submission — validation, duplicates, passwords.

        It is always recorded as entered by hand, and never carries a
        ServiceNow ticket's details (UAT-04 / UAT-L07, 2026-10-04): a
        request typed on the console must not appear as a ServiceNow or
        SailPoint request, nor make the bot update somebody's ticket.
        What was changed is noted in the audit trail."""
        metadata = dict(body.metadata or {})
        claimed = str(body.source or "").strip()
        dropped = "snow_details" in metadata
        metadata.pop("snow_details", None)
        if (claimed and claimed != "manual") or dropped:
            if audit_event is not None:
                try:
                    audit_event(
                        "console_request_adjusted", severity="WARNING",
                        actor=f"user:{user.username}",
                        ticket_id=body.ticket_id or "",
                        operation=body.operation,
                        detail={"source_sent": claimed,
                                "source_recorded": "manual",
                                "ticket_details_removed": dropped})
                except Exception:
                    pass
        # Every request entered by hand names its ticket (E2E-L08); the
        # machine API is unchanged.
        if not str(body.ticket_id or "").strip():
            raise HTTPException(status_code=400,
                                detail="Enter the ticket number of the request.")
        body = body.model_copy(update={"source": "manual",
                                       "metadata": metadata})
        return submit(body, f"user:{user.username}")

    @router.post("/console/requests/{request_id}/retry", status_code=202)
    def console_retry(request_id: str, user=Depends(deps["retry"])):
        return retry(request_id, f"user:{user.username}")

    @router.delete("/console/requests/{request_id}")
    def console_cancel(request_id: str, user=Depends(deps["cancel"])):
        return cancel(request_id, f"user:{user.username}")
