"""Request/response contracts for the intake API.

v3 is a new contract, so format validation is strict by default
(config.strict_validation relaxes it for legacy compatibility). The
rules mirror what the workflows enforce at execution time — bad data is
rejected before it can ever consume a terminal session.
"""
from __future__ import annotations

import re
from datetime import date, datetime
from typing import Optional

from pydantic import BaseModel, Field

from src.modules.intake.models import Operation


class SubmitRequest(BaseModel):
    operation: str = Field(..., description="provision or deprovision")
    affiliation_code: str = Field(..., description="5-digit affiliation code")
    employee_code: str = Field(..., description="7-character employee code")
    password: Optional[str] = Field("", description="Password (provision only)")
    source: str = Field("manual", description="manual / servicenow / sailpoint / api / cli")
    ticket_id: Optional[str] = Field("", description="Ticket number")
    metadata: Optional[dict] = Field(
        default_factory=dict,
        description="Source details carried with the request. Never include secrets.",
    )


# Where a request may come from (NB-014).
KNOWN_SOURCES = ("manual", "servicenow", "sailpoint", "api", "cli")

_EMPLOYEE_CODE_RE = re.compile(r"[A-Za-z0-9]{7}")


def _ascii_digits(value: str) -> bool:
    return value.isascii() and value.isdigit()


_ISO_DATE_RE = re.compile(r"^[0-9]{4}-[0-9]{2}-[0-9]{2}([T ].*)?$")


def validate_iso_date(name: str, value: Optional[str]) -> Optional[str]:
    """A date_from/date_to query value, checked.

    Returns the value unchanged when it is an ISO date (YYYY-MM-DD) or
    an ISO date-time, None when empty. Anything else raises ValueError:
    a filter like '26/09/2026' otherwise compares as text and silently
    returns an empty list, which reads as "nothing happened".
    """
    value = (value or "").strip()
    if not value:
        return None
    ok = bool(_ISO_DATE_RE.match(value))
    if ok:
        try:
            if len(value) == 10:
                date.fromisoformat(value)
            else:
                datetime.fromisoformat(value)
        except ValueError:
            ok = False
    if not ok:
        raise ValueError(f"{name} must be an ISO date YYYY-MM-DD")
    return value


def validate_request_format(body: SubmitRequest) -> list[str]:
    """Format validation matching the workflow-level rules.
    Returns a list of problems; empty means valid."""
    problems = []

    if body.operation not in (Operation.PROVISION.value,
                              Operation.DEPROVISION.value):
        problems.append(
            f"operation must be 'provision' or 'deprovision' "
            f"(got '{body.operation}')"
        )

    # str.isdigit() also accepts full-width and other Unicode digits
    # ('１２３４５', '²'), which the terminal field cannot take — only
    # ASCII 0-9 count.
    affiliation = (body.affiliation_code or "").strip()
    if _ascii_digits(affiliation) and len(affiliation) < 5:
        affiliation = affiliation.zfill(5)
    if not (_ascii_digits(affiliation) and len(affiliation) == 5):
        problems.append(
            f"Affiliation code must be 5 half-width (ASCII) digits 0-9 "
            f"(got '{body.affiliation_code}')"
        )

    employee = (body.employee_code or "").strip()
    if len(employee) != 7:
        problems.append(
            f"Employee code must be 7 characters (got {len(employee)})"
        )
    elif not employee.isascii():
        problems.append(
            "Employee code must use half-width (ASCII) characters only")
    # A space, tab or '-' inside the code is ASCII too, but a tab moves
    # the terminal to the next field (NB-007).
    elif not _EMPLOYEE_CODE_RE.fullmatch(employee):
        problems.append(
            "Employee code must be 7 half-width letters or digits "
            "(A-Z, a-z, 0-9)")

    # The documented sources only (NB-014).
    if body.source not in KNOWN_SOURCES:
        problems.append(
            f"source must be one of {', '.join(KNOWN_SOURCES)} "
            f"(got '{body.source}')")

    if body.operation == Operation.PROVISION.value and body.password:
        if len(body.password) != 8:
            problems.append("password must be 8 characters when provided")
        # The terminal field rejects these later, after the request has
        # been accepted and queued (VAL-01) — refuse them at the door.
        elif not body.password.isascii():
            problems.append(
                "password must use half-width (ASCII) characters only")
        elif not body.password[0].isalpha():
            problems.append("password must start with a letter")

    return problems
