"""Domain models for request intake and transaction history.

Port of v2 service/models.py with the approved status fix: the enum is
the single source of truth, and workflow-reported statuses ("success")
are normalized through normalize_status() at the dispatcher seam so
RequestStatus.DONE is what gets persisted, queried, and notified on —
closing the v2 defect where stats and success emails keyed on 'done'
but rows said 'success'.
"""
from __future__ import annotations

import hashlib
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timedelta, timezone
from enum import Enum

JST = timezone(timedelta(hours=9))


def now_jst() -> datetime:
    return datetime.now(JST)


def generate_request_id() -> str:
    return f"req_{uuid.uuid4().hex[:12]}"


def generate_transaction_id() -> str:
    return f"txn_{uuid.uuid4().hex[:12]}"


class RequestStatus(str, Enum):
    QUEUED = "queued"
    RUNNING = "running"
    DONE = "done"
    FAILED = "failed"
    ALREADY_DELETED = "already_deleted"
    CANCELLED = "cancelled"


# Requests in these statuses block duplicate submission…
ACTIVE_STATUSES = (RequestStatus.QUEUED.value, RequestStatus.RUNNING.value)
# …and successful outcomes also block resubmission of the same work.
DUPLICATE_BLOCKING_STATUSES = ACTIVE_STATUSES + (
    RequestStatus.DONE.value, RequestStatus.ALREADY_DELETED.value,
)
# Approved fix: failed / cancelled requests may be legitimately
# resubmitted or retried — they never 409.
RETRYABLE_STATUSES = (RequestStatus.FAILED.value,)
TERMINAL_STATUSES = (
    RequestStatus.DONE.value, RequestStatus.FAILED.value,
    RequestStatus.ALREADY_DELETED.value, RequestStatus.CANCELLED.value,
)

_STATUS_ALIASES = {
    "success": RequestStatus.DONE.value,   # v2 workflows report "success"
    "done": RequestStatus.DONE.value,
    "failed": RequestStatus.FAILED.value,
    "already_deleted": RequestStatus.ALREADY_DELETED.value,
    "cancelled": RequestStatus.CANCELLED.value,
}


def normalize_status(raw: str) -> str:
    """Map a workflow-reported status onto the canonical enum.
    Unknown values are treated as failure — never invent a status."""
    return _STATUS_ALIASES.get((raw or "").strip().lower(),
                               RequestStatus.FAILED.value)


class Operation(str, Enum):
    PROVISION = "provision"
    DEPROVISION = "deprovision"


@dataclass
class ProcessingRequest:
    """A unit of work accepted by the intake API."""
    operation: str
    affiliation_code: str
    employee_code: str
    password: str = ""
    source: str = "manual"
    ticket_id: str = ""
    request_id: str = field(default_factory=generate_request_id)
    status: str = RequestStatus.QUEUED.value
    result_code: str = ""
    error: str = ""
    enqueued_at: str = ""
    started_at: str = ""
    completed_at: str = ""
    worker_id: int = 0
    attempt_count: int = 0
    evidence_path: str = ""
    next_attempt_at: str = ""
    metadata: dict = field(default_factory=dict)

    def __post_init__(self):
        if not self.enqueued_at:
            self.enqueued_at = now_jst().isoformat()

    @property
    def normalized_affiliation(self) -> str:
        return self.affiliation_code.zfill(5)

    @property
    def user_key(self) -> str:
        return f"{self.normalized_affiliation}_{self.employee_code}"

    def idempotency_key(self) -> str:
        if self.ticket_id:
            return f"ticket:{self.ticket_id}"
        content = f"{self.operation}:{self.normalized_affiliation}:{self.employee_code}"
        return f"hash:{hashlib.sha256(content.encode()).hexdigest()[:16]}"

    def to_dict(self) -> dict:
        return asdict(self)

    def to_public_dict(self) -> dict:
        d = asdict(self)
        d["password"] = "****" if self.password else ""
        if d.get("metadata"):
            d["metadata"] = redact_secrets(d["metadata"])
        return d


_SECRET_KEY_MARKERS = ("password", "passwd", "pwd", "secret", "token", "api_key")


def redact_secrets(obj):
    """Recursively mask values whose key looks like a secret.

    A Yes/No flag is not a secret: "password_generated: true" says THAT
    a password was made, not what it is, and stays readable (RQ-07,
    2026-10-03). In Python a bool is also an int, hence the check."""
    if isinstance(obj, dict):
        return {
            k: ("****" if any(m in str(k).lower() for m in _SECRET_KEY_MARKERS)
                and isinstance(v, (str, int, float))
                and not isinstance(v, bool)
                else redact_secrets(v))
            for k, v in obj.items()
        }
    if isinstance(obj, list):
        return [redact_secrets(v) for v in obj]
    return obj


@dataclass
class TransactionRecord:
    """Write-once compliance record of a completed request."""
    request_id: str
    ticket_id: str
    operation: str
    affiliation_code: str        # always the normalized (zfilled) value
    employee_code: str
    source: str
    status: str                  # canonical RequestStatus value
    result_code: str
    error_message: str
    submitted_at: str
    started_at: str
    completed_at: str
    duration_seconds: float
    worker_id: int
    evidence_path: str
    screenshot_count: int = 0    # PNGs in the evidence folder
    operator: str = ""           # service account that executed
    attempt_count: int = 0
    metadata: dict = field(default_factory=dict)
    transaction_id: str = field(default_factory=generate_transaction_id)

    def to_dict(self) -> dict:
        return asdict(self)
