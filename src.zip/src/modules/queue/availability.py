"""Availability Monitor — can workers run right now?

Port of v2 service/availability.py, unchanged in behavior; reads the
v3 pydantic config instead of a YAML dict.

Two checks, both must pass:
  1. Time window — mainframe available 06:00-22:00 JST (configurable)
     with a graceful cutoff buffer before close (new work only).
  2. Health probe — mainframe is actually reachable. Two probe methods:
       tcp   — TCP connection test (default)
       login — a REAL FINESIII login several times a day (client
               requirement: proves the app is online, not just the
               port). Probes run only inside the time window and defer
               while the dispatcher is busy (the probe uses the same
               service account as live transactions).

Transition hooks (on_unavailable / on_recovered) fire on health
TRANSITIONS only — they feed the availability outage/recovery emails.
"""
from __future__ import annotations

import socket
import threading
import time
from datetime import datetime, time as dtime

from src.modules.intake.models import JST, now_jst


class AvailabilityMonitor:
    """Monitors mainframe availability (time window + health)."""

    def __init__(self, cfg, logger=None,
                 login_probe_func=None, busy_check=None,
                 on_unavailable=None, on_recovered=None):
        # Optional transition hooks (e.g. the dedicated availability-
        # outage email). Fired on health TRANSITIONS only.
        self._on_unavailable = on_unavailable    # (reason: str) -> None
        self._on_recovered = on_recovered        # () -> None

        # Time window (JST)
        self.window_start = self._parse_time(cfg.availability_window_start)
        self.window_end = self._parse_time(cfg.availability_window_end)
        self.shutdown_buffer_minutes = cfg.shutdown_buffer_minutes

        # Health probe
        self.host = cfg.mainframe_host
        self.port = cfg.mainframe_port
        self.probe_interval = cfg.probe_interval_seconds
        self.probe_timeout = cfg.probe_timeout_seconds
        self.health_check_enabled = cfg.health_check_enabled

        # Probe method: "tcp" (default) or "login".
        # login mode needs login_probe_func (src/rpa/login_probe.py);
        # without one it falls back to tcp so the service still runs.
        self.probe_method = str(cfg.probe_method or "tcp").strip().lower()
        self.login_probe_interval = \
            float(cfg.login_probe_interval_hours) * 3600.0
        self.login_probe_func = login_probe_func
        self.busy_check = busy_check   # () -> bool: worker busy right now?
        self._last_login_probe = 0.0   # epoch of last login ATTEMPT
        # True while the sign-in health check uses the service account;
        # the console's terminal check waits for it (TM-03, 2026-10-03).
        self.login_probe_running = False
        self._last_login_result = None  # True/False/None(=never ran)

        self.logger = logger

        self._health_ok = False
        self._last_probe = 0
        self._probed_once = False  # first-ever probe: a failure must
                                   # alert even though it isn't a transition
        self._outage_open = False  # recovery fires only after an outage
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._monitor_thread = None

    @staticmethod
    def _parse_time(time_str: str) -> dtime:
        text = str(time_str or "").strip()
        try:
            hours, minutes = text.split(":")
            return dtime(int(hours), int(minutes))
        except (ValueError, TypeError):
            raise ValueError(
                f"Operating window time {text!r} is not a valid HH:MM "
                f"time (24-hour, e.g. 06:00) — check "
                f"AVAILABILITY_WINDOW_START / AVAILABILITY_WINDOW_END"
            ) from None

    def start(self):
        """Start the background health probe thread."""
        if not self.health_check_enabled:
            if self.logger:
                self.logger.info(
                    "Health check disabled — relying on time window only")
            self._health_ok = True
            return

        if self.probe_method == "login" and self.login_probe_func is None:
            if self.logger:
                self.logger.warning(
                    "probe_method is 'login' but no login probe was "
                    "provided — falling back to TCP probing"
                )
            self.probe_method = "tcp"

        self._monitor_thread = threading.Thread(
            target=self._probe_loop, daemon=True,
            name="availability-monitor"
        )
        self._monitor_thread.start()
        if self.logger:
            if self.probe_method == "login":
                self.logger.info(
                    f"Availability monitor started "
                    f"(window {self.window_start}-{self.window_end} JST, "
                    f"LOGIN probe every "
                    f"{self.login_probe_interval / 3600.0:g}h)"
                )
            else:
                self.logger.info(
                    f"Availability monitor started "
                    f"(window {self.window_start}-{self.window_end} JST, "
                    f"probe every {self.probe_interval}s)"
                )

    def stop(self):
        self._stop.set()
        if self._monitor_thread:
            self._monitor_thread.join(timeout=5)

    def _probe_loop(self):
        while not self._stop.is_set():
            self._run_probe()
            self._stop.wait(self.probe_interval)

    def _run_probe(self):
        """Run the configured health probe (tcp or login)."""
        if self.probe_method == "login" and self.login_probe_func is not None:
            self._run_login_probe_if_due()
            return
        self._run_tcp_probe()

    def _login_probe_due(self) -> bool:
        """Is a login probe due right now?

        Due when: inside the time window, the worker is idle (the probe
        shares the service account with live transactions), and the
        configured interval has elapsed since the last attempt (or none
        was ever attempted). A deferral does NOT consume the schedule —
        the probe fires on the next tick once the blocker clears."""
        if not self.is_within_time_window():
            return False
        if self.busy_check is not None:
            try:
                if self.busy_check():
                    return False           # defer — retry next tick
            except Exception:
                pass                # a broken check never blocks probing
        if not self._last_login_probe:
            return True             # never probed → probe at startup
        return (time.time() - self._last_login_probe) \
            >= self.login_probe_interval

    def _run_login_probe_if_due(self, force: bool = False):
        """Attempt a REAL FINESIII login when the schedule says so."""
        if not force and not self._login_probe_due():
            return

        self._last_login_probe = time.time()
        self.login_probe_running = True
        try:
            ok = bool(self.login_probe_func())
        except Exception as e:         # a probe crash means "not online"
            if self.logger:
                self.logger.warning(f"Login probe raised unexpectedly: {e}")
            ok = False
        finally:
            self.login_probe_running = False

        with self._lock:
            was_ok = self._health_ok
            first = not self._probed_once
            self._probed_once = True
            self._health_ok = ok
            self._last_probe = time.time()
            self._last_login_result = ok

        if not ok and (was_ok or first):
            if self.logger:
                self.logger.warning(
                    "FINESIII login probe: application NOT AVAILABLE")
            self._fire_unavailable(
                "Login probe failed — could not log into FINESIII"
            )
        elif ok and not was_ok:
            if self.logger:
                self.logger.info(
                    "FINESIII login probe: application ONLINE")
            self._fire_recovered()

    def _run_tcp_probe(self):
        """Test TCP reachability of the mainframe."""
        if not self.host:
            # No host configured — assume available (POC/test mode)
            with self._lock:
                self._health_ok = True
                self._last_probe = time.time()
            return

        ok = False
        try:
            with socket.create_connection(
                (self.host, self.port), timeout=self.probe_timeout
            ):
                ok = True
        except (socket.timeout, socket.error, OSError):
            ok = False

        with self._lock:
            was_ok = self._health_ok
            first = not self._probed_once
            self._probed_once = True
            self._health_ok = ok
            self._last_probe = time.time()

        if not ok and (was_ok or first):
            if self.logger:
                self.logger.warning(
                    "Mainframe health probe: now UNREACHABLE")
            self._fire_unavailable(
                f"TCP probe to {self.host}:{self.port} failed"
            )
        elif ok and not was_ok:
            if self.logger:
                self.logger.info("Mainframe health probe: now REACHABLE")
            self._fire_recovered()

    def _fire_unavailable(self, reason: str):
        """Fire the outage hook. Marks the outage open so the recovery
        hook fires exactly once when health returns. Hook failures never
        break the probe loop."""
        self._outage_open = True
        if self._on_unavailable is None:
            return
        try:
            self._on_unavailable(reason)
        except Exception as e:
            if self.logger:
                self.logger.warning(f"Availability outage hook failed: {e}")

    def _fire_recovered(self):
        """Fire the recovery hook — only if an outage was actually open
        (a healthy first probe at startup is NOT a recovery)."""
        if not self._outage_open:
            return
        self._outage_open = False
        if self._on_recovered is None:
            return
        try:
            self._on_recovered()
        except Exception as e:
            if self.logger:
                self.logger.warning(
                    f"Availability recovery hook failed: {e}")

    def is_within_time_window(self, check_buffer: bool = False) -> bool:
        """Check if current JST time is within the availability window.

        If check_buffer is True, applies the shutdown buffer — returns
        False in the buffer period before window_end (so no NEW work
        starts)."""
        now = now_jst().time()

        end = self.window_end
        if check_buffer:
            # Subtract buffer minutes from window_end
            total_minutes = (end.hour * 60 + end.minute
                             - self.shutdown_buffer_minutes)
            if total_minutes < 0:
                total_minutes = 0
            end = dtime(total_minutes // 60, total_minutes % 60)

        return self.window_start <= now <= end

    def is_health_ok(self) -> bool:
        with self._lock:
            return self._health_ok

    def can_start_new_work(self) -> bool:
        """Can the dispatcher claim a NEW request right now?
        Applies the shutdown buffer to avoid starting work too close
        to close."""
        return (self.is_within_time_window(check_buffer=True)
                and self.is_health_ok())

    def can_continue_work(self) -> bool:
        """Can an in-flight transaction continue?
        No buffer — allows finishing work already started."""
        return (self.is_within_time_window(check_buffer=False)
                and self.is_health_ok())

    def status(self) -> dict:
        """Current availability status for the API."""
        now = now_jst()
        out = {
            "current_time_jst": now.isoformat(),
            "within_time_window":
                self.is_within_time_window(check_buffer=False),
            "accepting_new_work":
                self.is_within_time_window(check_buffer=True),
            "health_probe_ok": self.is_health_ok(),
            "available": self.can_start_new_work(),
            "window": (f"{self.window_start.strftime('%H:%M')}-"
                       f"{self.window_end.strftime('%H:%M')} JST"),
            "shutdown_buffer_minutes": self.shutdown_buffer_minutes,
            "probe_method": self.probe_method,
        }
        if self.probe_method == "login":
            out["login_probe_interval_hours"] = \
                self.login_probe_interval / 3600.0
            out["last_login_probe_result"] = self._last_login_result
            out["last_login_probe_at"] = (
                datetime.fromtimestamp(self._last_login_probe, JST)
                .isoformat(timespec="seconds")      # JST (E2E-L03)
                if self._last_login_probe else ""
            )
        return out
