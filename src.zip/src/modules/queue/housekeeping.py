"""Housekeeping: the clean-up that must run whatever the bot is doing.

Expired console sessions, the stored passwords of failed requests nobody
retried, and evidence screenshots past their retention period (they
contain personal data, and a provision capture shows the new password).

Until 2026-10-03 (SY-01) this ran only inside the dispatcher's loop, so
it stopped whenever "Process queued work" was off or the service started
without a terminal. The Housekeeper runs it on its own timer; the
dispatcher keeps the same methods (HousekeepingMixin) for callers that
use them directly.
"""
from __future__ import annotations

import threading
import time
from datetime import timedelta

from src.modules.intake.models import now_jst


class HousekeepingMixin:
    """The three clean-up steps. Each runs at most at its own cadence and
    never raises. Expects: queue, cfg, logger, audit, user_store and a
    _busy flag with is_set() (a transaction live on the terminal)."""

    # Expired sessions and failed-request passwords: at most hourly.
    _SESSION_PURGE_EVERY_SECONDS = 3600

    def _maybe_purge_failed_passwords(self) -> None:
        """Erase the passwords of failed requests nobody retried within
        the retention period, at most hourly. With 0 days ("erased when
        the request fails"), the passwords still kept from before are
        erased too (UAT-06, 2026-10-04). Never raises."""
        days = max(0, int(getattr(self.cfg, "failed_password_retention_days",
                                  7) or 0))
        now = time.time()
        if now - getattr(self, "_last_password_purge", 0.0) < \
                self._SESSION_PURGE_EVERY_SECONDS:
            return
        self._last_password_purge = now
        try:
            cutoff = (now_jst() - timedelta(days=days)).isoformat()
            removed = self.queue.purge_failed_passwords(cutoff)
            if removed:
                if self.logger:
                    self.logger.info(
                        f"Erased the stored password of {removed} failed "
                        f"request(s) older than {days} day(s)")
                if getattr(self, "audit", None):
                    self.audit.event(
                        "system", "failed_passwords_erased",
                        severity="INFO",
                        detail={"requests": removed,
                                "retention_days": days})
        except Exception as e:
            if self.logger:
                self.logger.warning(f"Failed-password purge failed: {e}")

    _EVIDENCE_PURGE_EVERY_SECONDS = 86400

    def _maybe_purge_evidence(self) -> None:
        """Apply the evidence retention setting once a day (2026-09-28:
        the setting existed but nothing deleted old evidence). Never
        while a transaction is live on the terminal. Never raises."""
        days = int(getattr(self.cfg, "evidence_retention_days", 0) or 0)
        if days <= 0 or self._busy.is_set():
            return
        now = time.time()
        if now - getattr(self, "_last_evidence_purge", 0.0) < \
                self._EVIDENCE_PURGE_EVERY_SECONDS:
            return
        self._last_evidence_purge = now
        try:
            from src.core.evidence import purge_expired_evidence
            removed = purge_expired_evidence(self.cfg.evidence_dir, days)
        except Exception as e:
            if self.logger:
                self.logger.warning(f"Evidence retention run failed: {e}")
            return
        if removed:
            if self.logger:
                self.logger.info(
                    f"Evidence retention: removed {len(removed)} evidence "
                    f"folder(s) older than {days} day(s)")
            if self.audit:
                self.audit.event(
                    "evidence", "evidence_purged", severity="INFO",
                    detail={"retention_days": days, "count": len(removed),
                            "folders": removed[:500]})

    def _maybe_purge_sessions(self) -> None:
        """Delete expired console sessions, at most hourly.

        Piggy-backs on the loop that is already running rather than
        adding a timer thread for one DELETE. Never raises: housekeeping
        must not stop the dispatcher from processing work.
        """
        if self.user_store is None:
            return
        now = time.time()
        if now - self._last_session_purge < \
                self._SESSION_PURGE_EVERY_SECONDS:
            return
        self._last_session_purge = now
        try:
            removed = self.user_store.purge_expired_sessions()
            if removed and self.logger:
                self.logger.info(
                    f"Purged {removed} expired console session(s)")
        except Exception as e:
            if self.logger:
                self.logger.warning(f"Session purge failed: {e}")


class _BusyFlag:
    """is_set() from a callable: the dispatcher's "transaction in
    progress" while there is one, never busy otherwise."""

    def __init__(self, busy=None):
        self._busy = busy

    def is_set(self) -> bool:
        if self._busy is None:
            return False
        try:
            return bool(self._busy())
        except Exception:
            return False


class Housekeeper(HousekeepingMixin):
    """Runs the clean-up on its own thread, every minute (each step keeps
    its own cadence: hourly or daily). Started and stopped with the
    service, whether or not requests are processed."""

    TICK_SECONDS = 60.0

    def __init__(self, queue, cfg, logger=None, audit=None,
                 user_store=None, busy=None):
        self.queue = queue
        self.cfg = cfg
        self.logger = logger
        self.audit = audit
        self.user_store = user_store
        self._busy = _BusyFlag(busy)
        self._last_session_purge = 0.0
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def run_once(self) -> None:
        self._maybe_purge_sessions()
        self._maybe_purge_failed_passwords()
        self._maybe_purge_evidence()

    def start(self) -> None:
        if self._thread is not None and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop,
                                        name="housekeeping", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=5)

    def _loop(self) -> None:
        while not self._stop.is_set():
            try:
                self.run_once()
            except Exception as e:          # never stops the service
                if self.logger:
                    self.logger.warning(f"Housekeeping failed: {e}")
            self._stop.wait(self.TICK_SECONDS)
