"""PostgreSQL-backed work queue with leasing, idempotency and conflict control.

Ports from v2: service/queue_store.py (QueueStore),
service/dispatcher.py (Dispatcher), service/idempotency.py
(IdempotencyChecker), service/conflict_guard.py (ConflictGuard).
Leasing uses SELECT ... FOR UPDATE SKIP LOCKED with a visibility
timeout; expired leases return to the queue automatically.
"""
