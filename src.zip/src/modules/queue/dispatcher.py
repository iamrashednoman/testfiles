"""Background dispatcher — claims queued requests and executes them.

Port of v2 service/dispatcher.py (single-worker semantics preserved for
Phase 1; the distributed lease model arrives in Phase 2) with fixes:

- statuses normalized through normalize_status() at the completion seam
  (approved fix #3) so DONE is what persists;
- transaction records store the normalized affiliation code (v2 stored
  the raw value while the mainframe received the zfilled one);
- graceful drain: stop() waits config.drain_seconds for an in-flight
  transaction instead of v2's 10s join that closed the DB pool under a
  live mainframe session.

The executor is pluggable: MockExecutor for dev/e2e now; the terminal
executor (ported v2 workflows + drivers) lands with the rpa-layer port.
"""
from __future__ import annotations

import hashlib
import json
import os
import random
import threading
import time
from datetime import datetime, timedelta
from pathlib import Path

from src.core.retry import RetryPolicy
from src.modules.audit.services import TransactionStore
from src.modules.intake.models import (
    JST, ProcessingRequest, RequestStatus, TransactionRecord,
    normalize_status, now_jst, redact_secrets,
)
from src.modules.queue.housekeeping import HousekeepingMixin
from src.modules.queue.services import QueueStore


def _step_time(value) -> dict:
    """occurred_at of a bot step: when the driver recorded it, not when
    the result was filed after the run (E2E-L04). The trace holds the
    server's local time; turned into JST like every other event. The
    audit row still records when it was written."""
    if not value:
        return {}
    try:
        return {"occurred_at": datetime.fromisoformat(str(value))
                .astimezone(JST).isoformat()}
    except (TypeError, ValueError):
        return {}


class ConflictGuard:
    """Serializes work per target user (single-process scope)."""

    def __init__(self):
        self._locked: set[str] = set()
        self._lock = threading.Lock()

    def acquire(self, user_key: str) -> bool:
        with self._lock:
            if user_key in self._locked:
                return False
            self._locked.add(user_key)
            return True

    def release(self, user_key: str) -> None:
        with self._lock:
            self._locked.discard(user_key)


class MockExecutor:
    """Deterministic executor for development and E2E tests.
    Reports v2-style raw statuses on purpose — the dispatcher seam must
    normalize them, and tests assert that it does."""

    def __init__(self, delay_seconds: float = 0.1, scenario: str = "success"):
        self.delay_seconds = delay_seconds
        self.scenario = scenario

    def execute(self, request: ProcessingRequest) -> dict:
        time.sleep(self.delay_seconds)
        if self.scenario == "error":
            return {"status": "failed", "error_type": "business",
                    "result_code": "E-9901",
                    "error": "simulated business error"}
        if self.scenario == "system_error":
            raise RuntimeError("simulated system failure")
        if self.scenario == "already_deleted" \
                and request.operation == "deprovision":
            return {"status": "already_deleted", "result_code": "",
                    "error": "Account already deleted"}
        return {"status": "success", "result_code": "O-0000", "error": ""}


def build_executor(cfg):
    """Executor factory keyed on the configured terminal driver.

    simulator      → MockExecutor (canned results, no rpa stack —
                     fastest dev/test loop)
    mock           → TerminalExecutor + MockDriver (full ported rpa
                     stack, headless)
    sim_terminal   → TerminalExecutor + visible green-screen window
                     per request (subprocess)
    pywinauto /    → TerminalExecutor + real terminal (Windows
    pyautogui /      workers)
    tn3270

    Returns None when this process cannot execute (API-only mode) —
    requests queue up and a worker processes them when attached."""
    if cfg.terminal_driver == "simulator":
        return MockExecutor(delay_seconds=cfg.mock_executor_delay_seconds)
    if cfg.terminal_driver in ("mock", "sim_terminal", "pywinauto",
                               "pyautogui", "tn3270"):
        from src.rpa.executor import TerminalExecutor
        return TerminalExecutor(cfg)
    return None


# ── Installation identity, pending completions, startup recovery ──

INSTANCE_ID_FILE = "instance.id"
PENDING_COMPLETIONS_FILE = "pending_completions.jsonl"
# Evidence captured when the "70" commit is typed / right after it: an
# interrupted request with either of these in its folder may exist on
# the mainframe already, so it is never simply run again.
COMMIT_EVIDENCE_MARKERS = ("commit_command_entered", "submission_result")


def installation_id(path: str | os.PathLike | None = None) -> int:
    """This installation's worker id: a random integer created once in
    the data folder and reused on every start. Two installations sharing
    one queue database therefore never claim or recover each other's
    running requests. Ids 0 and 1 are left to rows written before the
    id existed. Falls back to 1 (the old fixed id) when the file cannot
    be written."""
    if path is None:
        from src.core.app_paths import data_path
        path = data_path(INSTANCE_ID_FILE)
    path = Path(path)
    try:
        value = int(path.read_text(encoding="utf-8").strip())
        if 1000 <= value <= 2 ** 31 - 1:
            return value
    except (OSError, ValueError):
        pass
    value = random.SystemRandom().randint(1000, 2 ** 31 - 1)
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(str(value), encoding="utf-8")
    except OSError:
        return 1
    return value


def recovery_lease_seconds(cfg) -> float:
    """How long another installation's running request is left alone
    before it counts as abandoned: 2 hours, or four drain periods when
    that is longer."""
    drain = float(getattr(cfg, "drain_seconds", 0) or 0)
    return max(2 * 3600.0, 4 * drain)


def commit_evidence(evidence_dir, request) -> str:
    """The request's evidence folder when it shows that the "70" commit
    was typed during the current attempt, else "". Files older than the
    attempt's start (an earlier attempt of the same request) do not
    count."""
    if not evidence_dir:
        return ""
    folder = Path(evidence_dir) / str(request.request_id)
    try:
        if not folder.is_dir():
            return ""
        since = None
        if request.started_at:
            try:
                since = datetime.fromisoformat(
                    request.started_at).timestamp() - 5
            except (TypeError, ValueError):
                since = None
        for f in folder.iterdir():
            if not any(m in f.name for m in COMMIT_EVIDENCE_MARKERS):
                continue
            if since is None or f.stat().st_mtime >= since:
                return str(folder)
    except OSError:
        return ""
    return ""


def commit_flag(request) -> bool:
    """True when the request's row records that the "70" commit was sent
    during the current attempt (metadata commit_sent_at, written just
    before the commit — NB-004). Unlike the evidence folder, the row is
    visible to every installation sharing the database. A flag older
    than the attempt's start (an earlier attempt) does not count."""
    meta = getattr(request, "metadata", None)
    value = (meta.get(QueueStore.COMMIT_SENT_KEY)
             if isinstance(meta, dict) else None)
    if not value:
        return False
    try:
        sent = datetime.fromisoformat(str(value)).timestamp()
    except (TypeError, ValueError):
        return False
    started = getattr(request, "started_at", "")
    if not started:
        return True
    try:
        return sent >= datetime.fromisoformat(started).timestamp() - 5
    except (TypeError, ValueError):
        return True


def build_transaction_record(request: ProcessingRequest, status: str,
                             result_code: str, error: str,
                             evidence_path: str, completed_at: datetime,
                             operator: str = "") -> TransactionRecord:
    """The transaction-history record of a finished request (used by the
    dispatcher and by start-up recovery, NB-003)."""
    started = request.started_at or completed_at.isoformat()
    duration = 0.0
    try:
        duration = max(0.0, (completed_at - datetime.fromisoformat(
            started)).total_seconds())
    except (TypeError, ValueError):
        pass
    return TransactionRecord(
        request_id=request.request_id,
        ticket_id=request.ticket_id,
        operation=request.operation,
        affiliation_code=request.normalized_affiliation,
        employee_code=request.employee_code,
        source=request.source,
        status=status,
        result_code=result_code,
        error_message=error,
        submitted_at=request.enqueued_at,
        started_at=request.started_at,
        completed_at=completed_at.isoformat(),
        duration_seconds=duration,
        worker_id=request.worker_id,
        evidence_path=evidence_path,
        screenshot_count=Dispatcher._count_screenshots(evidence_path),
        operator=operator,
        attempt_count=request.attempt_count,
        metadata=request.metadata,
    )


def _append_pending(path: Path, entry: dict) -> None:
    """Append one entry to the pending-completions journal (fsync'd)."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(entry, ensure_ascii=False) + "\n")
        f.flush()
        os.fsync(f.fileno())


def history_entry(txn: TransactionRecord) -> dict:
    """A transaction record as journaled: secrets in the metadata
    redacted, as the transaction store stores it."""
    data = txn.to_dict()
    data["metadata"] = redact_secrets(data.get("metadata") or {})
    return data


def _apply_history(transactions: TransactionStore, entry: dict) -> bool:
    """Write a journaled history record unless it is already stored.
    Returns True when it was written."""
    data = entry["history"]
    if not isinstance(data, dict):
        raise ValueError("history entry is not a record")
    tid = data.get("transaction_id", "")
    if tid and transactions.get(tid) is not None:
        return False
    transactions.record(TransactionRecord(**data))
    return True


def _read_pending(path: Path) -> list[dict]:
    entries = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            entries.append(json.loads(line))
        except ValueError:
            continue            # a torn last line is dropped
    return entries


def _write_pending(path: Path, entries: list[dict]) -> None:
    if not entries:
        path.unlink(missing_ok=True)
        return
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        for e in entries:
            f.write(json.dumps(e, ensure_ascii=False) + "\n")
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


def apply_pending_completions(queue: QueueStore, path, logger=None,
                              transactions: TransactionStore | None = None
                              ) -> bool:
    """Write completions that could not be stored at the time (database
    unavailable) to the queue. Each is applied only while its row is
    still 'running'. Journaled transaction-history records ("history"
    entries, NB-003) are written to `transactions` once — never twice;
    without a transaction store they stay in the journal. Completion
    hooks are not repeated (they ran at the time). Returns True when
    nothing is left pending."""
    path = Path(path)
    try:
        if not path.exists():
            return True
        entries = _read_pending(path)
    except OSError as e:
        if logger:
            logger.error(f"Pending completions unreadable ({path}): {e}")
        return False
    remaining = list(entries)
    kept: list[dict] = []           # history entries not written yet
    for entry in entries:
        if "history" in entry:
            remaining.pop(0)
            if transactions is None:
                kept.append(entry)
                continue
            try:
                written = _apply_history(transactions, entry)
            except (KeyError, TypeError, ValueError) as e:
                if logger:
                    logger.error(f"Pending history record discarded for "
                                 f"{entry.get('request_id')}: {e}")
                continue
            except Exception as e:
                # Kept, but it does not hold up the entries after it.
                if logger:
                    logger.warning(
                        f"Pending history record for "
                        f"{entry.get('request_id')} still cannot be "
                        f"written: {e}")
                kept.append(entry)
                continue
            if logger:
                logger.info(
                    f"Pending history record written for "
                    f"{entry.get('request_id')}" if written else
                    f"Pending history record for {entry.get('request_id')} "
                    f"skipped — already stored")
            continue
        try:
            applied = queue.complete_if_running(
                entry["request_id"], entry["status"],
                result_code=entry.get("result_code", "") or "",
                error=entry.get("error", "") or "",
                evidence_path=entry.get("evidence_path", "") or "",
                completed_at=entry.get("completed_at", "") or "")
        except (KeyError, ValueError) as e:
            if logger:
                logger.error(f"Pending completion discarded ({entry}): {e}")
            remaining.pop(0)
            continue
        except Exception as e:
            if logger:
                logger.warning(
                    f"Pending completion for {entry.get('request_id')} "
                    f"still cannot be written: {e}")
            break
        remaining.pop(0)
        if logger:
            logger.info(
                f"Pending completion applied for {entry['request_id']} "
                f"({entry['status']})" if applied else
                f"Pending completion for {entry['request_id']} skipped — "
                f"the request is no longer running")
    remaining = kept + remaining
    if remaining and remaining == entries:
        return False                   # nothing applied; file unchanged
    try:
        _write_pending(path, remaining)
    except OSError as e:
        if logger:
            logger.error(f"Pending completions could not be updated: {e}")
        return False
    return not remaining


def _finish_recovered(queue: QueueStore, rid: str, transactions, audit,
                      on_complete, operator: str, logger) -> None:
    """History record, audit record and completion hooks of a row that
    start-up recovery finished as done/UNCONFIRMED (NB-003). Each step
    on its own; none raises."""
    try:
        req = queue.get(rid)
    except Exception as e:
        if logger:
            logger.warning(f"Recovered request {rid} could not be read: {e}")
        return
    if req is None:
        return
    txn = None
    try:
        try:
            completed = datetime.fromisoformat(req.completed_at)
        except (TypeError, ValueError):
            completed = now_jst()
        txn = build_transaction_record(
            req, RequestStatus.DONE.value, "UNCONFIRMED", req.error,
            req.evidence_path, completed, operator)
    except Exception as e:
        if logger:
            logger.error(f"Transaction record failed for {rid}: {e}")
        return
    if transactions is not None:
        try:
            transactions.record(txn)
        except Exception as e:
            if logger:
                logger.error(f"Transaction record failed for {rid}: {e}")
    if audit:
        try:
            audit.transaction(txn)
        except Exception as e:
            if logger:
                logger.warning(f"Audit record failed for {rid}: {e}")
    if on_complete is not None:
        try:
            on_complete(txn, req, {
                "status": RequestStatus.DONE.value,
                "result_code": "UNCONFIRMED", "error": req.error,
                "commit_sent": True, "post_commit_error": True})
        except Exception as e:
            if logger:
                logger.warning(f"on_complete hook failed for {rid}: {e}")


def recover_on_startup(queue: QueueStore, cfg, worker_id: int,
                       pending_path=None, audit=None, logger=None,
                       transactions: TransactionStore | None = None,
                       on_complete=None, operator: str = "") -> dict:
    """Startup order: apply the pending-completions journal FIRST (a
    completion that was journaled must not be re-run), then recover
    orphaned running rows — this installation's own, legacy rows and
    rows past the lease. A row whose evidence (or, for a row of any
    installation, the commit flag in the row — NB-004) shows the "70"
    commit is finished as done/UNCONFIRMED instead of being re-queued;
    it gets its transaction-history record and the unconfirmed
    completion hooks (e-mail, ticket note — NB-003). Re-queued rows get
    neither: they run again."""
    if pending_path is None:
        from src.core.app_paths import data_path
        pending_path = data_path(PENDING_COMPLETIONS_FILE)
    apply_pending_completions(queue, pending_path, logger,
                              transactions=transactions)
    outcome = queue.recover_orphans(
        worker_id=worker_id, lease_seconds=recovery_lease_seconds(cfg),
        committed=lambda r: commit_evidence(
            getattr(cfg, "evidence_dir", ""), r) or commit_flag(r))
    if outcome["requeued"] and logger:
        logger.warning(f"Recovered {len(outcome['requeued'])} orphaned "
                       "running request(s) back to queued")
    for rid in outcome["unconfirmed"]:
        if logger:
            # With the completion hooks wired the dedicated unconfirmed
            # e-mail reports it — a WARNING avoids a second e-mail.
            (logger.warning if on_complete is not None else logger.error)(
                f"Request {rid} was interrupted after the '70' "
                "commit — recorded as done/UNCONFIRMED; manual "
                "check required")
        if audit:
            audit.event("dispatch", "orphan_interrupted_after_commit",
                        severity="ERROR", request_id=rid,
                        error_message=QueueStore.INTERRUPTED_AFTER_COMMIT,
                        detail={"result_code": "UNCONFIRMED"})
        _finish_recovered(queue, rid, transactions, audit, on_complete,
                          operator, logger)
    for row in outcome["skipped"]:
        if logger:
            logger.warning(
                f"Request {row['request_id']} is running on another "
                f"installation (worker {row['worker_id']}, started "
                f"{row['started_at']}) — left alone")
        if audit:
            audit.event("dispatch", "orphan_recovery_skipped",
                        severity="WARNING", request_id=row["request_id"],
                        worker_id=row["worker_id"],
                        detail={"started_at": row["started_at"],
                                "own_worker_id": worker_id})
    return outcome


class Dispatcher(HousekeepingMixin):
    # The clean-up (expired sessions, stored passwords of failed
    # requests, evidence past its retention) lives in HousekeepingMixin
    # and runs on the Housekeeper's own timer since 2026-10-03 (SY-01):
    # it used to run only inside this loop, so it stopped whenever
    # processing was switched off.

    def __init__(self, queue: QueueStore, transactions: TransactionStore,
                 retry_policy: RetryPolicy, executor, cfg, logger=None,
                 availability=None, on_complete=None, audit=None,
                 user_store=None, on_password_rejected=None,
                 pre_execute=None, worker_id: int = 1, can_process=None,
                 pending_path=None, sleep=None, superseded_check=None,
                 on_superseded=None):
        self.queue = queue
        # (request) -> str: a non-empty reason means a NEWER ticket of the
        # opposite operation for the same account already ran, so this
        # older one is not executed (NB-001). None = no check. Never
        # raises. on_superseded(request, reason) sends the held-ticket
        # outputs (rejection e-mail, ticket note).
        self.superseded_check = superseded_check
        self.on_superseded = on_superseded
        # This installation's id, written to every claimed row (see
        # installation_id()). 1 = the historical fixed id.
        self.worker_id = int(worker_id or 1)
        # () -> bool: an extra processing gate (e.g. CyberArk required
        # but still on the fallback password). None = no gate.
        self.can_process = can_process
        self._gate_open = True
        # Journal of completions the database refused (see
        # _complete_durably). None = the data folder default.
        self.pending_path = pending_path
        self._sleep = sleep or time.sleep
        # (request) -> str: a non-empty reason cancels the request just
        # before the terminal step (e.g. its ServiceNow ticket was closed
        # after pickup, 2026-09-28). None = no check. Never raises.
        self.pre_execute = pre_execute
        # Fired (no arguments) when a transaction failed because the
        # mainframe rejected the service-account password — the CyberArk
        # provider uses it to refresh immediately. Never raises.
        self.on_password_rejected = on_password_rejected
        self.transactions = transactions
        self.retry_policy = retry_policy
        self.executor = executor
        self.cfg = cfg
        self.logger = logger
        # request_id -> (fingerprint of the service-account password the
        # mainframe rejected, that attempt's evidence folder); in memory
        # only, never stored (D-04).
        self._rejected_password: dict = {}
        # The terminal executor reports the moment just before "70" is
        # typed; the row records it so every installation's recovery
        # knows the commit may exist (NB-004). Executors without the
        # hook (simulator) are left as they are.
        if executor is not None and hasattr(executor, "on_commit"):
            executor.on_commit = self._record_commit_sent
        # Gate 1 (v2 parity): no NEW work outside the mainframe
        # operating window or while the health probe reports down.
        self.availability = availability
        # Terminal-outcome hook (txn, request, result) — e.g. the
        # transaction email notifications. Called AFTER the audit record
        # is written; a hook failure never affects dispatch.
        self.on_complete = on_complete
        # Optional audit event trail (src/modules/audit/trail.py).
        # None = feature off, byte-identical behavior. event() never
        # raises.
        self.audit = audit
        # Console session store — only used to sweep expired sessions.
        # None = console disabled, nothing to sweep.
        self.user_store = user_store
        self._last_session_purge = 0.0
        self.conflicts = ConflictGuard()
        self._stop = threading.Event()
        self._busy = threading.Event()
        # Operator pause (desktop System page): no NEW work is claimed
        # while set; a transaction already in flight always finishes.
        # Not persisted — a restart resumes, like a fresh start does.
        self._paused = threading.Event()
        self._thread: threading.Thread | None = None

    def start(self) -> None:
        self._thread = threading.Thread(target=self._loop,
                                        name="dispatcher", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        """Graceful drain: block until the in-flight transaction (if any)
        finishes, up to drain_seconds — never yank the DB out from under
        a live mainframe session."""
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=self.cfg.drain_seconds)
            if self._thread.is_alive() and self.logger:
                self.logger.error(
                    "Dispatcher did not drain within "
                    f"{self.cfg.drain_seconds}s — a transaction may be "
                    "interrupted; it will be recovered on next startup."
                )

    def pause(self, by: str = "", at: str = "") -> None:
        """Hold new work. `by` / `at`: who paused it and when, shown on
        the Dashboard and the System page (OPS-01, 2026-10-04)."""
        self.paused_by, self.paused_at = by, at
        self._paused.set()

    def resume(self) -> None:
        self.paused_by = self.paused_at = ""
        self._paused.clear()

    def status(self) -> dict:
        accepting = True
        if getattr(self, "availability", None) is not None:
            try:
                accepting = bool(self.availability.can_start_new_work())
            except Exception:
                accepting = False
        return {
            "running": self._thread is not None and self._thread.is_alive(),
            "busy": self._busy.is_set(),
            "paused": self._paused.is_set(),
            "paused_by": getattr(self, "paused_by", "") or "",
            "paused_at": getattr(self, "paused_at", "") or "",
            # What else holds new work back (SY-04, 2026-10-03): the
            # processing gate (CyberArk password not delivered yet) and
            # the operating window / mainframe health.
            "gate_open": bool(getattr(self, "_gate_open", True)),
            "accepting": accepting,
        }

    def _loop(self) -> None:
        while not self._stop.is_set():
            worked = False
            try:
                worked = self._tick()
            except Exception as e:
                if self.logger:
                    self.logger.error(f"Dispatcher tick failed: {e}")
            interval = (self.cfg.dispatch_poll_seconds if worked
                        else self.cfg.idle_poll_seconds)
            self._stop.wait(interval)

    def _tick(self) -> bool:
        # A completion the database refused earlier is written first; no
        # new work is claimed while one is still pending.
        if not self._flush_pending_completions():
            return False
        if self._paused.is_set():
            return False
        if self.availability is not None \
                and not self.availability.can_start_new_work():
            return False
        if not self._processing_allowed():
            return False

        request = self.queue.dequeue_oldest(worker_id=self.worker_id)
        if request is None:
            return False

        if not self.conflicts.acquire(request.user_key):
            # Same user already in flight — put it back for later.
            self.queue.schedule_retry(
                request.request_id,
                (now_jst() + timedelta(seconds=self.cfg.idle_poll_seconds))
                .isoformat(),
                error="",
            )
            return False

        if self.audit:
            self.audit.event(
                "dispatch", "request_dispatched",
                request_id=request.request_id, ticket_id=request.ticket_id,
                operation=request.operation,
                affiliation_code=request.affiliation_code,
                employee_code=request.employee_code, source=request.source,
                worker_id=request.worker_id,
                detail={"attempt": request.attempt_count},
            )

        self._busy.set()
        try:
            reason = self._superseded_reason(request)
            if reason:
                # An older ticket must never undo a newer one (NB-001):
                # nothing reaches the terminal; recorded as cancelled and
                # the ticket is held like a duplicate at pickup.
                if self.logger:
                    self.logger.warning(
                        f"Request {request.request_id} "
                        f"({request.ticket_id}) not executed: {reason}")
                if self.audit:
                    self.audit.event(
                        "dispatch", "request_superseded_before_execution",
                        severity="WARNING", request_id=request.request_id,
                        ticket_id=request.ticket_id,
                        operation=request.operation,
                        affiliation_code=request.affiliation_code,
                        employee_code=request.employee_code,
                        error_message=reason)
                self._complete(request, {"status": "cancelled",
                                         "error": f"Superseded: {reason}"},
                               None, "cancelled", notify=False)
                if self.on_superseded is not None:
                    try:
                        self.on_superseded(request, reason)
                    except Exception as e:
                        if self.logger:
                            self.logger.warning(
                                f"on_superseded hook failed: {e}")
                return True

            reason = self._pre_execute_reason(request)
            if reason:
                # Nothing reaches the terminal; recorded as cancelled with
                # the reason. No outcome e-mail and no ticket note — the
                # ticket was closed or taken over in ServiceNow.
                if self.logger:
                    self.logger.warning(
                        f"Request {request.request_id} "
                        f"({request.ticket_id}) cancelled: {reason}")
                if self.audit:
                    self.audit.event(
                        "dispatch", "request_cancelled_before_execution",
                        severity="WARNING", request_id=request.request_id,
                        ticket_id=request.ticket_id,
                        operation=request.operation,
                        affiliation_code=request.affiliation_code,
                        employee_code=request.employee_code,
                        error_message=reason)
                self._complete(request, {"status": "cancelled",
                                         "error": f"Cancelled: {reason}"},
                               None, "cancelled", notify=False)
                return True

            # The mainframe rejected the service-account password on the
            # last attempt and no different password has arrived since
            # (CyberArk refresh failed or returned the same one): not
            # tried again, so the account is not locked (D-04).
            refused, evidence = self._rejected_password.pop(
                request.request_id, ("", ""))
            if refused and refused == self._service_password_fp():
                if self.logger:
                    self.logger.warning(
                        f"Request {request.request_id} ({request.ticket_id}) "
                        f"not retried: the service-account password was "
                        f"rejected and has not changed")
                self._complete(request, {
                    "status": "failed",
                    "error_id": "LOGIN_PASSWORD_INCORRECT",
                    "evidence_path": evidence,
                    "error": ("Not retried: the mainframe rejected the "
                              "service-account password and no different "
                              "password has been supplied (the CyberArk "
                              "refresh failed or returned the same one). "
                              "Retry once the password is updated.")},
                    None, "password rejected — not retried")
                return True

            result, exception = None, None
            try:
                result = self.executor.execute(request)
            except Exception as e:
                exception = e

            decision = self.retry_policy.evaluate(
                request.attempt_count, result=result, exception=exception)

            if decision.should_retry:
                error = (str(exception) if exception
                         else (result or {}).get("error", ""))
                delay = decision.delay_seconds
                # A rejected password asks CyberArk for a fresh one now;
                # the refresh runs in the background, so the next attempt
                # waits long enough for it to land. The rejected one is
                # remembered to compare with then (D-04).
                if (result or {}).get("error_id") == "LOGIN_PASSWORD_INCORRECT":
                    self._rejected_password[request.request_id] = (
                        self._service_password_fp(),
                        str((result or {}).get("evidence_path", "") or ""))
                if self._notify_password_rejected(result):
                    delay = max(delay, self._PASSWORD_REFRESH_DELAY_SECONDS)
                next_attempt = (
                    now_jst() + timedelta(seconds=delay)
                ).isoformat()
                self._write_durably(
                    "retry scheduling", request.request_id,
                    lambda: self.queue.schedule_retry(
                        request.request_id, next_attempt,
                        error=f"{decision.reason}: {error}"))
                if self.audit:
                    self.audit.event(
                        "dispatch", "retry_scheduled", severity="WARNING",
                        request_id=request.request_id,
                        ticket_id=request.ticket_id,
                        operation=request.operation,
                        affiliation_code=request.affiliation_code,
                        employee_code=request.employee_code,
                        error_message=error or None,
                        detail={"attempt": request.attempt_count,
                                "next_attempt_at": next_attempt,
                                "reason": decision.reason},
                    )
                # The error screens this attempt recognised, with the
                # catalogue version, are recorded now: the final attempt
                # alone used to be (UAT-12, 2026-10-04).
                self._audit_error_trace(request, result)
            else:
                self._complete(request, result, exception, decision.reason)
            return True
        finally:
            self.conflicts.release(request.user_key)
            self._busy.clear()

    # Minimum wait before retrying after a rejected password, so the
    # background CyberArk refresh can finish first.
    _PASSWORD_REFRESH_DELAY_SECONDS = 20.0

    def _service_password_fp(self) -> str:
        """A fingerprint of the service-account password in use now ('' =
        unknown). Compared only, never stored or logged (D-04)."""
        creds = getattr(self.executor, "credentials", None)
        pw = str(getattr(creds, "password", "") or "")
        return hashlib.sha256(pw.encode("utf-8")).hexdigest() if pw else ""

    def _notify_password_rejected(self, result: dict | None) -> bool:
        """Fire the password-rejected hook when the mainframe refused the
        service-account password. Returns True when it fired. Never
        raises."""
        if not (self.on_password_rejected is not None and result
                and result.get("error_id") == "LOGIN_PASSWORD_INCORRECT"):
            return False
        try:
            self.on_password_rejected()
        except Exception as e:
            if self.logger:
                self.logger.warning(f"password-rejected hook failed: {e}")
        return True

    def _processing_allowed(self) -> bool:
        """The optional can_process gate; a state change is logged once.
        A failing gate check counts as closed."""
        if self.can_process is None:
            return True
        try:
            allowed = bool(self.can_process())
        except Exception as e:
            if self.logger:
                self.logger.warning(f"processing gate check failed: {e}")
            allowed = False
        if allowed != self._gate_open:
            self._gate_open = allowed
            if self.logger:
                if allowed:
                    self.logger.info("Processing gate open — resuming "
                                     "queued work")
                else:
                    self.logger.warning(
                        "Processing paused — a required condition is not "
                        "met (see the System page); queued work waits")
        return allowed

    # Waits between attempts to store an outcome (seconds).
    _WRITE_BACKOFF = (0.0, 0.5, 2.0, 5.0)

    def _write_durably(self, what: str, request_id: str, write) -> bool:
        """Run one queue write, retrying a transient database error with
        back-off. Returns False when every attempt failed."""
        last = None
        for wait in self._WRITE_BACKOFF:
            if wait:
                self._sleep(wait)
            try:
                write()
                return True
            except Exception as e:
                last = e
                if self.logger:
                    self.logger.warning(
                        f"{what} for {request_id} failed: {e}")
        if self.logger:
            self.logger.error(
                f"{what} for {request_id} failed after "
                f"{len(self._WRITE_BACKOFF)} attempts: {last}")
        return False

    def _pending_file(self) -> Path:
        if self.pending_path is not None:
            return Path(self.pending_path)
        from src.core.app_paths import data_path
        return data_path(PENDING_COMPLETIONS_FILE)

    def _complete_durably(self, request_id: str, status: str,
                          result_code: str, error: str,
                          evidence_path: str) -> None:
        """Store the terminal outcome. When the database refuses it
        every time, the outcome goes to the pending-completions journal
        (no password in it) so the row is completed later — at the next
        tick or the next start — and never run again as an orphan."""
        if self._write_durably(
                "completion write", request_id,
                lambda: self.queue.mark_complete(
                    request_id, status, result_code=result_code,
                    error=error, evidence_path=evidence_path)):
            return
        entry = {"request_id": request_id, "status": status,
                 "result_code": result_code, "error": error,
                 "evidence_path": evidence_path,
                 "completed_at": now_jst().isoformat()}
        path = self._pending_file()
        try:
            _append_pending(path, entry)
            if self.logger:
                self.logger.error(
                    f"Completion of {request_id} ({status}) journaled — it "
                    f"is written once the database accepts it; no new "
                    f"work is taken until then")
        except OSError as e:
            if self.logger:
                self.logger.critical(
                    f"Completion of {request_id} ({status}) could not be "
                    f"stored or journaled: {e}")

    def _record_durably(self, txn: TransactionRecord) -> None:
        """Store the transaction-history record, retried like the
        completion; when the database refuses it every time it goes to
        the same journal and is written later, once (NB-003)."""
        rid = txn.request_id
        if self._write_durably("history write", rid,
                               lambda: self.transactions.record(txn)):
            return
        try:
            _append_pending(self._pending_file(),
                            {"request_id": rid, "history": history_entry(txn)})
            if self.logger:
                self.logger.error(
                    f"Transaction history of {rid} journaled — it is "
                    f"written once the database accepts it")
        except (OSError, TypeError, ValueError) as e:
            if self.logger:
                self.logger.critical(
                    f"Transaction history of {rid} could not be stored "
                    f"or journaled: {e}")

    def _flush_pending_completions(self) -> bool:
        """Apply journaled completions. True when none are pending. A
        history record still waiting for the database does not hold up
        new work — only a completion does (a request must never run
        twice; a late history record is written on a later tick)."""
        path = self._pending_file()
        try:
            if not path.exists():
                return True
        except OSError:
            return True
        if apply_pending_completions(self.queue, path, self.logger,
                                     transactions=self.transactions):
            return True
        try:
            return all("history" in e for e in _read_pending(path))
        except OSError:
            return False

    def _superseded_reason(self, request: ProcessingRequest) -> str:
        if self.superseded_check is None:
            return ""
        try:
            return str(self.superseded_check(request) or "")
        except Exception as e:
            if self.logger:
                self.logger.warning(f"newer-ticket check failed: {e}")
            return ""

    def _record_commit_sent(self, request: ProcessingRequest) -> None:
        """Executor hook, called just before "70" is typed: the row
        records the time (NB-004). Never raises."""
        try:
            self.queue.set_metadata_value(
                request.request_id, QueueStore.COMMIT_SENT_KEY,
                now_jst().isoformat())
        except Exception as e:
            if self.logger:
                self.logger.warning(
                    f"Commit flag for {request.request_id} not recorded: {e}")

    def _pre_execute_reason(self, request: ProcessingRequest) -> str:
        if self.pre_execute is None:
            return ""
        try:
            return str(self.pre_execute(request) or "")
        except Exception as e:
            if self.logger:
                self.logger.warning(f"pre-execution check failed: {e}")
            return ""

    def _complete(self, request: ProcessingRequest, result: dict | None,
                  exception: Exception | None, reason: str,
                  notify: bool = True) -> None:
        if exception is not None:
            status = RequestStatus.FAILED.value
            result_code, error = "", f"{reason}: {exception}"
            evidence_path = ""
        else:
            result = result or {}
            status = normalize_status(result.get("status", ""))
            result_code = result.get("result_code", "")
            error = result.get("error", "") or ""
            evidence_path = result.get("evidence_path", "") or ""

        self._complete_durably(request.request_id, status, result_code,
                               error, evidence_path)

        # The mainframe rejected the service-account password: tell the
        # credential provider so it refreshes now (a rotated password),
        # instead of retrying with the stale one until the next tick.
        self._notify_password_rejected(result)

        completed = now_jst()
        txn = None
        try:
            txn = build_transaction_record(
                request, status, result_code, error, evidence_path,
                completed, getattr(self.executor, "operator", ""))
        except Exception as e:
            if self.logger:
                self.logger.error(
                    f"Transaction record failed for {request.request_id}: {e}")
        if txn is not None:
            # Retried; journaled when the database refuses it (NB-003).
            self._record_durably(txn)

        if self.audit and txn is not None:
            self.audit.transaction(txn)

        self._audit_rpa_traces(request, result, status)

        if notify and self.on_complete is not None and txn is not None:
            try:
                self.on_complete(txn, request, result or {})
            except Exception as e:
                if self.logger:
                    self.logger.warning(f"on_complete hook failed: {e}")

    def _audit_rpa_traces(self, request: ProcessingRequest,
                          result: dict | None, status: str) -> None:
        """Persist the bot's observed traces to the audit DB (client
        requirement: every action the bot performs is auditable per
        transaction, and a failure states what went wrong and WHERE).

        - one `rpa_action` event per driver interaction (keystrokes,
          commands, waits, screenshots, logout walks — passwords masked
          at the source);
        - one `rpa_screen` event per evidence capture with its
          success/failed-path classification;
        - on failure, a `transaction_failure_analysis` event pointing a
          developer straight at the failing step, the screen the bot
          was on, and the last actions before the failure.
        """
        if not self.audit or not result:
            return
        common = dict(request_id=request.request_id,
                      ticket_id=request.ticket_id,
                      operation=request.operation,
                      employee_code=request.employee_code)

        for entry in result.get("action_trace") or []:
            self.audit.event(
                "rpa_action", str(entry.get("action", "action")),
                severity="INFO" if entry.get("ok", True) else "WARNING",
                detail=entry, **common, **_step_time(entry.get("at")))

        self._audit_error_trace(request, result)

        screen_trace = result.get("screen_trace") or []
        for entry in screen_trace:
            on_error_path = entry.get("path") in ("business_error",
                                                  "system_error")
            self.audit.event(
                "rpa_screen", "screen_classified",
                severity="WARNING" if on_error_path else "INFO",
                detail=entry, **common, **_step_time(entry.get("captured_at")))

        # "70" was sent and a later step failed: the request is finished
        # as unconfirmed (never retried) and a person must check it.
        if result.get("post_commit_error"):
            self.audit.event(
                "rpa", "post_commit_error", severity="ERROR",
                error_message=(result.get("error") or "")[:500],
                detail={
                    "failed_step": result.get("failed_step", ""),
                    "result_code": result.get("result_code", ""),
                    "confirmed_code": result.get("confirmed_code", ""),
                    "error_id": result.get("error_id", ""),
                    "evidence_path": result.get("evidence_path", ""),
                }, **common)

        if status == RequestStatus.FAILED.value:
            actions = result.get("action_trace") or []
            self.audit.event(
                "rpa", "transaction_failure_analysis", severity="ERROR",
                error_message=(result.get("error") or "")[:500],
                detail={
                    "failed_step": result.get("failed_step", ""),
                    "error_type": result.get("error_type", ""),
                    "result_code": result.get("result_code", ""),
                    # Which catalogue rule explains this failure (empty
                    # when the failure was not a recognised error
                    # screen) — a developer starts here.
                    "error_id": result.get("error_id", ""),
                    "errors_detected": result.get("error_trace") or [],
                    "last_screen": (screen_trace[-1]
                                    if screen_trace else None),
                    "last_actions": actions[-5:],
                    "evidence_path": result.get("evidence_path", ""),
                }, **common)

    def _audit_error_trace(self, request: ProcessingRequest,
                           result: dict | None) -> None:
        """Every error the catalogue recognised — what was on screen,
        which rule fired, what the bot did about it, and whether it
        acted at all (a low-confidence read is recorded but never acted
        on). This is the debugging entry point for a failed transaction:
        one event naming the rule and the evidence. Recorded for every
        attempt, with its number (UAT-12, 2026-10-04)."""
        if not self.audit or not result:
            return
        for entry in result.get("error_trace") or []:
            self.audit.event(
                "rpa_error", "rpa_error_detected",
                severity="ERROR" if entry.get("acted") else "WARNING",
                error_message=(entry.get("message") or "")[:500],
                detail=dict(entry, attempt=request.attempt_count),
                request_id=request.request_id,
                ticket_id=request.ticket_id,
                operation=request.operation,
                employee_code=request.employee_code)

    @staticmethod
    def _count_screenshots(evidence_path: str) -> int:
        if not evidence_path:
            return 0
        try:
            from pathlib import Path
            p = Path(evidence_path)
            return len(list(p.glob("*.png"))) if p.exists() else 0
        except Exception:
            return 0
