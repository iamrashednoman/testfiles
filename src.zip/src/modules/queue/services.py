"""PostgreSQL/SQLite-backed work queue.

Port of v2 service/queue_store.py with the approved fixes:

1. Idempotency status filter — duplicate detection only considers
   requests whose status blocks resubmission (queued/running/done/
   already_deleted). Failed and cancelled requests no longer block a
   legitimate resubmission forever.
2. Race-proof uniqueness — a partial UNIQUE index on idempotency_key
   over active statuses backs the application-level check, so two
   concurrent identical submissions cannot both enqueue (the loser gets
   IntegrityError and the API returns 409, not a duplicate mainframe
   transaction).
3. Credential hygiene — the password column is cleared the moment a
   request reaches a terminal status.
4. Operator retry — retry() re-queues a failed request as a guarded
   state transition (fresh attempt budget, error cleared).
"""
from __future__ import annotations

import json
import threading

from src.core.db import Database, IntegrityError
from src.modules.intake.models import (
    ACTIVE_STATUSES, DUPLICATE_BLOCKING_STATUSES, RETRYABLE_STATUSES,
    TERMINAL_STATUSES, ProcessingRequest, RequestStatus, now_jst,
)

_COLUMNS = (
    "request_id, operation, affiliation_code, employee_code, password, "
    "source, ticket_id, idempotency_key, status, result_code, error, "
    "enqueued_at, started_at, completed_at, worker_id, attempt_count, "
    "evidence_path, next_attempt_at, metadata"
)


class RetrySuperseded(Exception):
    """A failed request cannot be retried because a newer request with
    the same idempotency key is already active or completed."""


class QueueStore:
    def __init__(self, db: Database):
        self.db = db
        self._lock = threading.Lock()
        self._ensure_schema()

    def _ensure_schema(self) -> None:
        # Admin-provisioned schema (scripts/schema.sql): the service
        # role doesn't own the tables, so skip bootstrap DDL entirely.
        if self.db.table_exists("request_queue"):
            return
        with self.db.connect() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS request_queue (
                    request_id TEXT PRIMARY KEY,
                    operation TEXT NOT NULL,
                    affiliation_code TEXT NOT NULL,
                    employee_code TEXT NOT NULL,
                    password TEXT DEFAULT '',
                    source TEXT DEFAULT 'manual',
                    ticket_id TEXT DEFAULT '',
                    idempotency_key TEXT NOT NULL,
                    status TEXT NOT NULL,
                    result_code TEXT DEFAULT '',
                    error TEXT DEFAULT '',
                    enqueued_at TEXT NOT NULL,
                    started_at TEXT DEFAULT '',
                    completed_at TEXT DEFAULT '',
                    worker_id INTEGER DEFAULT 0,
                    attempt_count INTEGER DEFAULT 0,
                    evidence_path TEXT DEFAULT '',
                    next_attempt_at TEXT DEFAULT '',
                    metadata TEXT DEFAULT '{}'
                )
            """)
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_status_enqueued "
                "ON request_queue(status, enqueued_at)"
            )
            # Approved fix #2: DB-enforced idempotency for in-flight work.
            conn.execute(
                "CREATE UNIQUE INDEX IF NOT EXISTS idx_idempotency_active "
                "ON request_queue(idempotency_key) "
                "WHERE status IN ('queued', 'running')"
            )

    # ── Write paths ──

    def enqueue(self, request: ProcessingRequest) -> bool:
        """Insert a new queued request. Returns False when the partial
        unique index rejects a concurrent duplicate (caller maps to 409)."""
        row = request.to_dict()
        row["metadata"] = json.dumps(row.get("metadata") or {})
        try:
            with self._lock, self.db.connect() as conn:
                conn.execute(
                    f"INSERT INTO request_queue ({_COLUMNS}) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (row["request_id"], row["operation"],
                     row["affiliation_code"], row["employee_code"],
                     row["password"], row["source"], row["ticket_id"],
                     request.idempotency_key(), row["status"],
                     row["result_code"], row["error"], row["enqueued_at"],
                     row["started_at"], row["completed_at"], row["worker_id"],
                     row["attempt_count"], row["evidence_path"],
                     row["next_attempt_at"], row["metadata"]),
                )
            return True
        except IntegrityError:
            return False

    def dequeue_oldest(self, worker_id: int) -> ProcessingRequest | None:
        """Atomically claim the oldest eligible queued request."""
        now = now_jst().isoformat()
        with self._lock, self.db.connect() as conn:
            row = conn.fetchone(
                "SELECT request_id FROM request_queue "
                "WHERE status = ? AND (next_attempt_at = '' OR "
                "next_attempt_at IS NULL OR next_attempt_at <= ?) "
                "ORDER BY enqueued_at ASC LIMIT 1"
                + self.db.dequeue_lock_clause,
                (RequestStatus.QUEUED.value, now),
            )
            if row is None:
                return None
            updated = conn.execute(
                "UPDATE request_queue SET status = ?, started_at = ?, "
                "worker_id = ?, attempt_count = attempt_count + 1, "
                "next_attempt_at = '' "
                "WHERE request_id = ? AND status = ?",
                (RequestStatus.RUNNING.value, now, worker_id,
                 row["request_id"], RequestStatus.QUEUED.value),
            )
            if updated == 0:
                return None
        return self.get(row["request_id"])

    def mark_complete(self, request_id: str, status: str,
                      result_code: str = "", error: str = "",
                      evidence_path: str = "") -> None:
        """Record a terminal outcome. Approved fix #3: the stored
        password is cleared here — plaintext credentials never persist
        past completion.

        Exception (approved 2026-09-27, DATA-01): a FAILED request keeps
        its password while `keep_failed_password` is on, so an operator
        Retry uses the ticket's password instead of silently falling
        back to the default. It is erased when the retry succeeds, on
        cancel, and by purge_failed_passwords() after the retention
        period."""
        if status not in TERMINAL_STATUSES:
            raise ValueError(f"Not a terminal status: {status!r}")
        keep = (status == RequestStatus.FAILED.value
                and self.keep_failed_password
                and not self._password_generated(request_id))
        with self._lock, self.db.connect() as conn:
            conn.execute(
                "UPDATE request_queue SET status = ?, result_code = ?, "
                "error = ?, evidence_path = ?, completed_at = ?"
                + ("" if keep else ", password = ''")
                + " WHERE request_id = ?",
                (status, result_code, error, evidence_path,
                 now_jst().isoformat(), request_id),
            )

    def complete_if_running(self, request_id: str, status: str,
                            result_code: str = "", error: str = "",
                            evidence_path: str = "",
                            completed_at: str = "") -> bool:
        """mark_complete() guarded on the row still being 'running'.
        Used to apply a completion that could not be written at the time
        (pending-completions journal) and by startup recovery: a row that
        has moved on since (retried, cancelled, completed) is left alone.
        Returns True when the row was updated."""
        if status not in TERMINAL_STATUSES:
            raise ValueError(f"Not a terminal status: {status!r}")
        keep = (status == RequestStatus.FAILED.value
                and self.keep_failed_password
                and not self._password_generated(request_id))
        with self._lock, self.db.connect() as conn:
            updated = conn.execute(
                "UPDATE request_queue SET status = ?, result_code = ?, "
                "error = ?, evidence_path = ?, completed_at = ?"
                + ("" if keep else ", password = ''")
                + " WHERE request_id = ? AND status = ?",
                (status, result_code, error, evidence_path,
                 completed_at or now_jst().isoformat(), request_id,
                 RequestStatus.RUNNING.value),
            )
        return updated > 0

    # Set by the application from failed_password_retention_days.
    keep_failed_password = True

    def _password_generated(self, request_id: str) -> bool:
        """The bot generated this request's password. It is not kept
        after a failure: a retry issues a new one, and the user was never
        told the first (L26, 2026-10-05)."""
        try:
            row = self.db.fetchone(
                "SELECT metadata FROM request_queue WHERE request_id = ?",
                (request_id,))
            meta = json.loads((row or {}).get("metadata") or "{}")
            return bool(isinstance(meta, dict) and meta.get("password_generated"))
        except Exception:
            return False

    def purge_failed_passwords(self, older_than: str) -> int:
        """Erase passwords still held by FAILED requests completed before
        `older_than` (ISO). Returns the number of rows changed."""
        with self._lock, self.db.connect() as conn:
            return conn.execute(
                "UPDATE request_queue SET password = '' "
                "WHERE status = ? AND password != '' AND completed_at != '' "
                "AND completed_at < ?",
                (RequestStatus.FAILED.value, older_than),
            )

    def writeback_backlog(self, max_rounds: int) -> dict:
        """ServiceNow ticket updates not delivered yet (SN-02, 2026-10-03):
        "pending" are still tried on the next polls, "given_up" need the
        ticket updated by hand, and so do "refused" ones: the ticket was
        no longer the bot's to update (UAT-L18, 2026-10-04). Reads only
        rows that carry a marker."""
        rows = self.db.fetchall(
            "SELECT metadata FROM request_queue WHERE source = ? "
            "AND metadata LIKE ?", ("servicenow", '%"snow_writeback"%'))
        pending = given_up = refused = 0
        for row in rows:
            try:
                mark = (json.loads(row["metadata"] or "{}") or {}).get(
                    "snow_writeback")
            except (TypeError, ValueError):
                continue
            if isinstance(mark, dict) and mark.get("pending"):
                if int(mark.get("rounds", 0) or 0) >= max_rounds:
                    given_up += 1
                else:
                    pending += 1
            elif isinstance(mark, dict) and \
                    str(mark.get("note", "")).startswith("refused"):
                refused += 1
        return {"pending": pending, "given_up": given_up,
                "refused": refused}

    def set_metadata_value(self, request_id: str, key: str, value) -> bool:
        """Set one key in a request's metadata (read-modify-write under
        the store lock). Used to record that a ticket write-back was
        delivered, so it is neither lost nor repeated."""
        with self._lock:
            row = self.db.fetchone(
                "SELECT metadata FROM request_queue WHERE request_id = ?",
                (request_id,))
            if not row:
                return False
            try:
                meta = json.loads(row["metadata"] or "{}")
            except (TypeError, ValueError):
                meta = {}
            if not isinstance(meta, dict):
                meta = {}
            meta[key] = value
            with self.db.connect() as conn:
                conn.execute(
                    "UPDATE request_queue SET metadata = ? "
                    "WHERE request_id = ?",
                    (json.dumps(meta, ensure_ascii=False), request_id))
        return True

    # Metadata key of the keyed password fingerprint (2026-09-28).
    PASSWORD_FP_KEY = "password_fp"
    # Metadata key written just before the "70" commit is typed (NB-004):
    # every installation's start-up recovery can see that the commit may
    # exist on the mainframe, even when the evidence folder is elsewhere.
    COMMIT_SENT_KEY = "commit_sent_at"

    def password_fingerprint_used(self, fingerprint: str) -> bool:
        """True when any request (any status, any age) was recorded with
        this password fingerprint. Metadata is stored as JSON text, so a
        text match finds it without a schema change; the fingerprint is
        hex, so no escaping is needed."""
        fp = str(fingerprint or "")
        if not fp or not all(c in "0123456789abcdef" for c in fp):
            return False
        row = self.db.fetchone(
            "SELECT request_id FROM request_queue WHERE metadata LIKE ? "
            "LIMIT 1", (f'%"{self.PASSWORD_FP_KEY}": "{fp}"%',))
        return row is not None

    def set_password(self, request_id: str, password: str,
                     fingerprint: str) -> bool:
        """Give a FAILED request a new generated password (its stored one
        was erased after the retention period) before a retry."""
        with self._lock, self.db.connect() as conn:
            updated = conn.execute(
                "UPDATE request_queue SET password = ? "
                "WHERE request_id = ? AND status = ?",
                (password, request_id, RequestStatus.FAILED.value))
        if updated:
            self.set_metadata_value(request_id, self.PASSWORD_FP_KEY,
                                    fingerprint)
        return updated > 0

    def schedule_retry(self, request_id: str, next_attempt_at: str,
                       error: str = "") -> None:
        with self._lock, self.db.connect() as conn:
            conn.execute(
                "UPDATE request_queue SET status = ?, next_attempt_at = ?, "
                "error = ? WHERE request_id = ?",
                (RequestStatus.QUEUED.value, next_attempt_at, error,
                 request_id),
            )

    def cancel(self, request_id: str) -> bool:
        """Cancel a request — queued only (running work is not preemptable)."""
        with self._lock, self.db.connect() as conn:
            updated = conn.execute(
                "UPDATE request_queue SET status = ?, completed_at = ?, "
                "password = '' "
                "WHERE request_id = ? AND status = ?",
                (RequestStatus.CANCELLED.value, now_jst().isoformat(),
                 request_id, RequestStatus.QUEUED.value),
            )
        return updated > 0

    def retry(self, request_id: str) -> bool:
        """Approved fix #4: operator-initiated re-queue of a FAILED
        request. Fresh attempt budget; guarded transition (failed only).

        Raises RetrySuperseded when the same ticket/request was submitted
        again after the failure and that newer request is queued, running
        or done: re-queuing the old one would run the work twice, and the
        unique index on active work refuses it (it used to surface as an
        HTTP 500 — DATA-02)."""
        try:
            with self._lock, self.db.connect() as conn:
                updated = conn.execute(
                    "UPDATE request_queue SET status = ?, error = '', "
                    "result_code = '', next_attempt_at = '', "
                    "attempt_count = 0, completed_at = '', enqueued_at = ? "
                    "WHERE request_id = ? AND status IN "
                    f"({','.join('?' * len(RETRYABLE_STATUSES))})",
                    (RequestStatus.QUEUED.value, now_jst().isoformat(),
                     request_id, *RETRYABLE_STATUSES),
                )
        except IntegrityError:
            raise RetrySuperseded(request_id)
        return updated > 0

    # Error recorded on a row that was interrupted after the "70" commit.
    INTERRUPTED_AFTER_COMMIT = ("interrupted after commit — manual check "
                                "required")

    def recover_orphaned(self, worker_id: int | None = None,
                         lease_seconds: float | None = None,
                         committed=None) -> int:
        """Startup recovery: re-queue rows left 'running' by a crash.
        Returns the number of rows re-queued.

        Without arguments every running row is re-queued (single
        installation). With `worker_id` only this installation's rows,
        legacy rows (worker 0/1) and rows whose lease has expired are
        recovered — another installation's in-flight work is left alone.
        `committed(request)` marks rows whose "70" was already sent as
        done/UNCONFIRMED instead of re-queuing them (truthy = committed;
        a string is taken as the row's evidence path). Details in
        recover_orphans()."""
        return len(self.recover_orphans(worker_id, lease_seconds,
                                        committed)["requeued"])

    def recover_orphans(self, worker_id: int | None = None,
                        lease_seconds: float | None = None,
                        committed=None) -> dict:
        """recover_orphaned() with the per-row outcome:
        {"requeued": [ids], "unconfirmed": [ids],
         "skipped": [{"request_id", "worker_id", "started_at"}]}."""
        from datetime import datetime, timedelta
        out: dict = {"requeued": [], "unconfirmed": [], "skipped": []}
        rows = self.db.fetchall(
            "SELECT * FROM request_queue WHERE status = ?",
            (RequestStatus.RUNNING.value,))
        cutoff = None
        if worker_id is not None and lease_seconds:
            cutoff = now_jst() - timedelta(seconds=float(lease_seconds))
        for row in rows:
            req = self._hydrate(row)
            if worker_id is not None and int(req.worker_id or 0) not in (
                    int(worker_id), 0, 1):
                expired = cutoff is not None
                if cutoff is not None and req.started_at:
                    try:
                        expired = datetime.fromisoformat(
                            req.started_at) < cutoff
                    except (TypeError, ValueError):
                        expired = True
                if not expired:
                    out["skipped"].append({
                        "request_id": req.request_id,
                        "worker_id": req.worker_id,
                        "started_at": req.started_at})
                    continue
            is_committed = False
            if committed is not None:
                try:
                    is_committed = committed(req)
                except Exception:
                    is_committed = False
            if is_committed:
                # The check may return the evidence folder it found.
                evidence = (is_committed if isinstance(is_committed, str)
                            else req.evidence_path)
                if self.complete_if_running(
                        req.request_id, RequestStatus.DONE.value,
                        result_code="UNCONFIRMED",
                        error=self.INTERRUPTED_AFTER_COMMIT,
                        evidence_path=evidence):
                    out["unconfirmed"].append(req.request_id)
                continue
            with self._lock, self.db.connect() as conn:
                updated = conn.execute(
                    "UPDATE request_queue SET status = ? "
                    "WHERE request_id = ? AND status = ?",
                    (RequestStatus.QUEUED.value, req.request_id,
                     RequestStatus.RUNNING.value))
            if updated:
                out["requeued"].append(req.request_id)
        return out

    # ── Read paths ──

    def get(self, request_id: str) -> ProcessingRequest | None:
        row = self.db.fetchone(
            "SELECT * FROM request_queue WHERE request_id = ?", (request_id,)
        )
        return self._hydrate(row) if row else None

    def find_by_ticket(self, ticket_id: str) -> ProcessingRequest | None:
        """The most recent request carrying this ticket number, in ANY
        status. Used by the in-agent ServiceNow poller to skip tickets
        the platform has already seen — including failed ones, which an
        operator re-runs with Retry rather than by re-polling."""
        if not ticket_id:
            return None
        row = self.db.fetchone(
            "SELECT * FROM request_queue WHERE ticket_id = ? "
            "ORDER BY enqueued_at DESC LIMIT 1", (ticket_id,))
        return self._hydrate(row) if row else None

    def find_ticket_requests(self, ticket_id: str) -> list[ProcessingRequest]:
        """Every request of one ServiceNow task: the task number itself,
        and <task>/1 … <task>/N when the ticket carried several
        affiliation codes (2026-09-28). The latest row per ticket id,
        oldest part first."""
        if not ticket_id:
            return []
        escaped = (ticket_id.replace("\\", "\\\\").replace("%", "\\%")
                   .replace("_", "\\_"))
        rows = self.db.fetchall(
            "SELECT * FROM request_queue WHERE ticket_id = ? "
            "OR ticket_id LIKE ? ESCAPE '\\' ORDER BY enqueued_at DESC",
            (ticket_id, f"{escaped}/%"))
        latest: dict[str, ProcessingRequest] = {}
        for row in rows:
            req = self._hydrate(row)
            latest.setdefault(req.ticket_id, req)
        return sorted(latest.values(), key=lambda r: (
            int((r.metadata or {}).get("part", 0) or 0)
            if isinstance(r.metadata, dict) else 0, r.ticket_id))

    def find_content_duplicate(self, operation: str, affiliation_code: str,
                               employee_code: str, exclude_ticket_id: str = "",
                               since: str = "",
                               statuses=DUPLICATE_BLOCKING_STATUSES,
                               ) -> ProcessingRequest | None:
        """The most recent request for the SAME operation, affiliation and
        employee under a DIFFERENT ticket number, in a duplicate-blocking
        status, enqueued at or after `since` (ISO; blank = any time).
        Used by the ServiceNow poller's content-duplicate check
        (2026-09-26); the intake API's own idempotency is untouched.
        `statuses` narrows the match (the check before execution looks
        only at running or finished requests, NB-001)."""
        aff = (affiliation_code or "").strip()
        variants = {aff, aff.zfill(5) if aff.isdigit() else aff}
        statuses = tuple(statuses)
        placeholders = ",".join("?" * len(statuses))
        aff_ph = ",".join("?" * len(variants))
        sql = ("SELECT * FROM request_queue WHERE operation = ? "
               f"AND affiliation_code IN ({aff_ph}) AND employee_code = ? "
               f"AND status IN ({placeholders}) ")
        params: list = [operation, *variants, (employee_code or "").strip(),
                        *statuses]
        if exclude_ticket_id:
            sql += "AND ticket_id != ? "
            params.append(exclude_ticket_id)
        if since:
            sql += "AND enqueued_at >= ? "
            params.append(since)
        sql += "ORDER BY enqueued_at DESC LIMIT 1"
        row = self.db.fetchone(sql, tuple(params))
        return self._hydrate(row) if row else None

    def list_recent_by_source(self, source: str, since: str = "",
                              limit: int = 500) -> list[ProcessingRequest]:
        """Recent requests from one source (newest first), for the
        possible-duplicate comparison on requester + description."""
        sql = "SELECT * FROM request_queue WHERE source = ? "
        params: list = [source]
        if since:
            sql += "AND enqueued_at >= ? "
            params.append(since)
        sql += "ORDER BY enqueued_at DESC LIMIT ?"
        params.append(limit)
        return [self._hydrate(r) for r in self.db.fetchall(sql, tuple(params))]

    def find_duplicate(self, request: ProcessingRequest) -> ProcessingRequest | None:
        """Approved fix #1: only duplicate-blocking statuses match —
        failed/cancelled history never blocks a resubmission."""
        placeholders = ",".join("?" * len(DUPLICATE_BLOCKING_STATUSES))
        row = self.db.fetchone(
            "SELECT * FROM request_queue WHERE idempotency_key = ? "
            f"AND status IN ({placeholders}) "
            "ORDER BY enqueued_at DESC LIMIT 1",
            (request.idempotency_key(), *DUPLICATE_BLOCKING_STATUSES),
        )
        return self._hydrate(row) if row else None

    def list_requests(self, status: str | None = None,
                      limit: int = 100) -> list[ProcessingRequest]:
        if status:
            rows = self.db.fetchall(
                "SELECT * FROM request_queue WHERE status = ? "
                "ORDER BY enqueued_at DESC LIMIT ?", (status, limit),
            )
        else:
            rows = self.db.fetchall(
                "SELECT * FROM request_queue "
                "ORDER BY enqueued_at DESC LIMIT ?", (limit,),
            )
        return [self._hydrate(r) for r in rows]

    # Console data tables (2026-09-28). Fixed lists: a sort column or a
    # search term never reaches the SQL text itself. The password column
    # is never searched.
    SORTABLE = ("enqueued_at", "started_at", "completed_at", "request_id",
                "operation", "affiliation_code", "employee_code", "source",
                "ticket_id", "status", "result_code", "attempt_count",
                "worker_id", "next_attempt_at")
    _SEARCH = ("request_id", "operation", "affiliation_code",
               "employee_code", "source", "ticket_id", "status",
               "result_code", "error")

    def list_page(self, offset: int = 0, limit: int = 50,
                  sort: str | None = None, order: str | None = None,
                  q: str | None = None, date_from: str | None = None,
                  date_to: str | None = None,
                  **filters) -> tuple[list[ProcessingRequest], int]:
        """One page of requests plus the total matching."""
        clauses, params = [], []
        # result_code: "Needs verification" = done + UNCONFIRMED (E2E-L07).
        for field in ("status", "operation", "source", "employee_code",
                      "affiliation_code", "ticket_id", "result_code"):
            if filters.get(field):
                clauses.append(f"{field} = ?")
                params.append(filters[field])
        if date_from:
            clauses.append("enqueued_at >= ?")
            params.append(date_from)
        if date_to:
            clauses.append("enqueued_at <= ?")
            params.append(f"{date_to}T23:59:59.999999+09:00"
                          if len(date_to) == 10 else date_to)
        term = (q or "").strip().lower()
        if term:
            clauses.append("(" + " OR ".join(
                f"LOWER(COALESCE({c}, '')) LIKE ?" for c in self._SEARCH)
                + ")")
            params.extend([f"%{term}%"] * len(self._SEARCH))
        where = f"WHERE {' AND '.join(clauses)} " if clauses else ""
        column = sort if sort in self.SORTABLE else "enqueued_at"
        direction = "ASC" if str(order or "").lower() == "asc" else "DESC"
        tail = ", enqueued_at DESC" if column != "enqueued_at" else ""
        total = self.db.fetchone(
            f"SELECT COUNT(*) AS n FROM request_queue {where}",
            tuple(params))["n"]
        rows = self.db.fetchall(
            f"SELECT * FROM request_queue {where}"
            f"ORDER BY {column} {direction}{tail} LIMIT ? OFFSET ?",
            (*params, int(limit), int(offset)))
        return [self._hydrate(r) for r in rows], int(total)

    def status_counts(self) -> dict:
        """Requests per status — the backlog chart."""
        return {r["status"]: r["n"] for r in self.db.fetchall(
            "SELECT status, COUNT(*) AS n FROM request_queue "
            "GROUP BY status")}

    def queue_depth(self) -> dict:
        """Actionable depth vs cooling-down retries, reported separately
        (v2 conflated them and overstated the backlog)."""
        now = now_jst().isoformat()
        eligible = self.db.fetchone(
            "SELECT COUNT(*) AS n FROM request_queue WHERE status = ? "
            "AND (next_attempt_at = '' OR next_attempt_at IS NULL "
            "OR next_attempt_at <= ?)",
            (RequestStatus.QUEUED.value, now),
        )["n"]
        cooling = self.db.fetchone(
            "SELECT COUNT(*) AS n FROM request_queue WHERE status = ? "
            "AND next_attempt_at > ?",
            (RequestStatus.QUEUED.value, now),
        )["n"]
        running = self.db.fetchone(
            "SELECT COUNT(*) AS n FROM request_queue WHERE status = ?",
            (RequestStatus.RUNNING.value,),
        )["n"]
        # Since when the oldest request has been waiting (DR-04,
        # 2026-10-03): a queue that does not move shows here first.
        oldest = self.db.fetchone(
            "SELECT MIN(enqueued_at) AS t FROM request_queue "
            "WHERE status = ?", (RequestStatus.QUEUED.value,))
        return {"eligible": eligible, "cooling_down": cooling,
                "running": running,
                "oldest_queued_at": (oldest or {}).get("t") or ""}

    def queue_position(self, request_id: str) -> int:
        req = self.get(request_id)
        if req is None or req.status != RequestStatus.QUEUED.value:
            return 0
        row = self.db.fetchone(
            "SELECT COUNT(*) AS n FROM request_queue "
            "WHERE status = ? AND enqueued_at <= ?",
            (RequestStatus.QUEUED.value, req.enqueued_at),
        )
        return row["n"]

    @staticmethod
    def _hydrate(row: dict) -> ProcessingRequest:
        data = dict(row)
        data.pop("idempotency_key", None)
        raw_meta = data.get("metadata") or "{}"
        try:
            data["metadata"] = json.loads(raw_meta)
        except (TypeError, ValueError):
            data["metadata"] = {}
        for key in ("started_at", "completed_at", "next_attempt_at",
                    "result_code", "error", "evidence_path", "password",
                    "ticket_id"):
            if data.get(key) is None:
                data[key] = ""
        return ProcessingRequest(**data)
