"""Append-only audit trail and transaction history (compliance).

Ports from v2: service/audit_db.py (PostgresAuditBackend,
SQLiteAuditBackend), service/audit_trail.py (AuditTrail,
AuditLogHandler), service/transaction_store.py (TransactionStore).
"""
