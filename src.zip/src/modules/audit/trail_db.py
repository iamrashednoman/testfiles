"""Audit-database backends for the FINESIII v3 audit trail.

Port of v2 service/audit_db.py. One interface, two engines:

  PostgresAuditBackend — the enterprise deployment target: the dedicated
      `finesiii_audit` database (schema `audit`, append-only
      `audit_events` — provisioned by scripts/audit_schema.sql, or
      self-provisioned by ensure_schema on a fresh dev database).
      DEVIATION from v2: v2 assembled the connection from
      AUDIT_DB_USER / AUDIT_DB_PASSWORD / host / port pieces via
      service.db.Database; v3 takes the single full DSN
      cfg.audit_database_url and speaks psycopg 3 directly, one
      short-lived connection per batch — an audit-DB restart can never
      wedge a stale pooled connection.

  SQLiteAuditBackend — zero-setup fallback for unit tests and machines
      without a database service. Same event shape, local file, stdlib.

Both inserts are IDEMPOTENT on event_id (the spool delivers
at-least-once; ON CONFLICT DO NOTHING / INSERT OR IGNORE makes it
effectively exactly-once).
"""
from __future__ import annotations

import json
import sqlite3
import threading
from datetime import datetime

from src.modules.intake.models import JST, now_jst

# Canonical event columns, in insert order. Anything else the caller adds
# travels inside the JSON `detail` payload.
EVENT_COLUMNS = [
    "event_id", "occurred_at", "category", "action", "severity",
    "request_id", "transaction_id", "ticket_id", "operation",
    "affiliation_code", "employee_code", "worker_id", "source",
    "status", "result_code", "error_message", "detail", "service_instance",
]


def _parse_ts(value) -> datetime:
    """occurred_at arrives as an ISO-8601 JST string; PostgreSQL's
    TIMESTAMPTZ column needs a real datetime."""
    if isinstance(value, datetime):
        return value
    try:
        return datetime.fromisoformat(str(value))
    except (ValueError, TypeError):
        return now_jst()


def _bound_ts(value) -> datetime:
    """A date filter bound for the TIMESTAMPTZ column. A date or time
    without an offset means Japan time (NB-008): left naive, PostgreSQL
    would read it in its own session timezone."""
    dt = _parse_ts(value)
    return dt if dt.tzinfo else dt.replace(tzinfo=JST)


# Console data tables (2026-09-28): the columns a page may be sorted by
# and the columns the free-text search looks in. Fixed lists — a sort
# or search term never reaches the SQL text itself.
SORTABLE_COLUMNS = ("occurred_at", "category", "action", "severity",
                    "request_id", "ticket_id", "operation",
                    "employee_code", "affiliation_code", "status",
                    "result_code", "source")
_SEARCH_COLUMNS = ("category", "action", "request_id", "ticket_id",
                   "operation", "employee_code", "affiliation_code",
                   "status", "result_code", "error_message", "source")


def _page_where(mark: str, filters: dict, q: str | None,
                detail_text: str, to_ts=lambda v: v,
                end_of_day=lambda v: v) -> tuple[str, list]:
    """WHERE clause shared by the paged audit query and its count.
    `mark` is the engine's placeholder; values always travel as
    parameters."""
    clauses, params = [], []
    for field in ("category", "action", "severity", "request_id",
                  "ticket_id", "operation", "employee_code", "source"):
        value = filters.get(field)
        if not value:
            continue
        if field == "category" and value == "evidence":
            # Evidence: the retention purge and every look at evidence,
            # which the console records under its own category (UAT-L28,
            # 2026-10-04).
            clauses.append(f"(category = {mark} OR action IN "
                           f"({mark}, {mark}))")
            params.extend(["evidence", "evidence_listed",
                           "evidence_viewed"])
            continue
        clauses.append(f"{field} = {mark}")
        params.append(value)
    if filters.get("date_from"):
        clauses.append(f"occurred_at >= {mark}")
        params.append(to_ts(filters["date_from"]))
    if filters.get("date_to"):
        clauses.append(f"occurred_at <= {mark}")
        params.append(to_ts(end_of_day(filters["date_to"])))
    term = (q or "").strip().lower()
    if term:
        parts = [f"LOWER(COALESCE({c}, ''))" for c in _SEARCH_COLUMNS]
        parts.append(f"LOWER(COALESCE({detail_text}, ''))")
        # The page shows "Evidence purged" for evidence_purged: words
        # typed as shown find the event too (UAT-L28, 2026-10-04).
        terms = [term]
        if " " in term:
            terms.append(term.replace(" ", "_"))
        clauses.append("(" + " OR ".join(f"{p} LIKE {mark}"
                                          for _t in terms
                                          for p in parts) + ")")
        for t in terms:
            params.extend([f"%{t}%"] * len(parts))
    where = (" WHERE " + " AND ".join(clauses)) if clauses else ""
    return where, params


def _order_by(sort: str | None, order: str | None) -> str:
    column = sort if sort in SORTABLE_COLUMNS else "occurred_at"
    direction = "ASC" if str(order or "").lower() == "asc" else "DESC"
    # The time as a tie-breaker keeps pages stable.
    tail = ", occurred_at DESC" if column != "occurred_at" else ""
    return f" ORDER BY {column} {direction}{tail}"


def _end_of_day(value: str) -> str:
    """A plain date as the end bound means the whole of that day."""
    v = str(value)
    return f"{v}T23:59:59.999999+09:00" if len(v) == 10 else v


# Seconds to wait for the audit database to accept a connection.
CONNECT_TIMEOUT_SECONDS = 5


class PostgresAuditBackend:
    """Writes to the dedicated finesiii_audit PostgreSQL database."""

    def __init__(self, dsn: str):
        self.dsn = dsn

    def _connect(self):
        import psycopg
        from psycopg.rows import dict_row
        # A connection time-out (X-01, 2026-10-03): an audit server that
        # does not answer must not hold the console for the operating
        # system's TCP time-out on every refresh.
        return psycopg.connect(self.dsn, row_factory=dict_row,
                               connect_timeout=CONNECT_TIMEOUT_SECONDS)

    def protection(self) -> dict:
        """Whether the database itself stops the service from changing or
        deleting audit events (DR-05, 2026-10-03): the service's login
        holds neither UPDATE nor DELETE on the table."""
        with self._connect() as conn:
            row = conn.execute(
                "SELECT has_table_privilege(current_user, "
                "'audit.audit_events', 'UPDATE') AS u, "
                "has_table_privilege(current_user, 'audit.audit_events', "
                "'DELETE') AS d").fetchone()
        can_change = bool(row["u"]) or bool(row["d"])
        return {"protected": not can_change,
                "detail": ("The service can add and read audit events but "
                           "cannot change or delete them."
                           if not can_change else
                           "The service's database login can change or "
                           "delete audit events. Have the database "
                           "administrator apply the audit rights "
                           "(Setup_Database.py --audit-url).")}

    def ensure_schema(self):
        """Idempotent. When the DBA has already run audit_schema.sql the
        role only needs USAGE plus INSERT/SELECT on the table, so the
        DDL is skipped entirely: PostgreSQL checks CREATE rights and
        ownership even for a CREATE ... IF NOT EXISTS that would do
        nothing, and a least-privilege role would be refused. On a fresh
        local database (dev superuser) it self-provisions."""
        with self._connect() as conn:
            row = conn.execute(
                "SELECT to_regclass('audit.audit_events') AS t").fetchone()
            if row and row["t"]:
                return
            conn.execute("CREATE SCHEMA IF NOT EXISTS audit")
            conn.execute("""
                CREATE TABLE IF NOT EXISTS audit.audit_events (
                    event_id         UUID PRIMARY KEY,
                    occurred_at      TIMESTAMPTZ NOT NULL,
                    recorded_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
                    category         TEXT NOT NULL,
                    action           TEXT NOT NULL,
                    severity         TEXT NOT NULL DEFAULT 'INFO',
                    request_id       TEXT,
                    transaction_id   TEXT,
                    ticket_id        TEXT,
                    operation        TEXT,
                    affiliation_code TEXT,
                    employee_code    TEXT,
                    worker_id        INTEGER,
                    source           TEXT,
                    status           TEXT,
                    result_code      TEXT,
                    error_message    TEXT,
                    detail           JSONB,
                    service_instance TEXT
                )
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_audit_occurred
                ON audit.audit_events (occurred_at)
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_audit_request
                ON audit.audit_events (request_id)
            """)

    def insert_events(self, events: list[dict]):
        if not events:
            return
        from psycopg.types.json import Jsonb
        cols = ", ".join(EVENT_COLUMNS)
        marks = ", ".join(["%s"] * len(EVENT_COLUMNS))
        sql = (f"INSERT INTO audit.audit_events ({cols}) VALUES ({marks}) "
               f"ON CONFLICT (event_id) DO NOTHING")
        with self._connect() as conn:            # commits on clean exit
            for ev in events:
                row = []
                for col in EVENT_COLUMNS:
                    val = ev.get(col)
                    if col == "occurred_at":
                        val = _parse_ts(val)
                    elif col == "detail":
                        val = Jsonb(val) if val else None
                    row.append(val)
                conn.execute(sql, tuple(row))

    def query_events(self, category: str | None = None,
                     action: str | None = None,
                     severity: str | None = None,
                     request_id: str | None = None,
                     date_from: str | None = None,
                     date_to: str | None = None,
                     limit: int = 200) -> list[dict]:
        clauses, params = [], []
        for field, value in (("category", category), ("action", action),
                             ("severity", severity), ("request_id", request_id)):
            if value:
                clauses.append(f"{field} = %s")
                params.append(value)
        if date_from:
            clauses.append("occurred_at >= %s")
            params.append(_bound_ts(date_from))
        if date_to:
            clauses.append("occurred_at <= %s")
            # A plain date means the whole day, as in the paged query.
            params.append(_bound_ts(_end_of_day(date_to)))
        where = (" WHERE " + " AND ".join(clauses)) if clauses else ""
        params.append(limit)
        with self._connect() as conn:
            rows = conn.execute(
                f"SELECT * FROM audit.audit_events{where} "
                f"ORDER BY occurred_at DESC LIMIT %s", params
            ).fetchall()
        out = []
        for r in rows:
            d = dict(r)
            # TIMESTAMPTZ comes back in the server's session timezone —
            # render in JST, the business timezone used everywhere else.
            for ts_col in ("occurred_at", "recorded_at"):
                if isinstance(d.get(ts_col), datetime):
                    d[ts_col] = d[ts_col].astimezone(JST).isoformat()
            out.append(d)
        return out

    def query_page(self, offset: int = 0, limit: int = 50,
                   sort: str | None = None, order: str | None = None,
                   q: str | None = None, **filters) -> tuple[list, int]:
        """One page of events plus the total matching (console tables)."""
        where, params = _page_where("%s", filters, q, "detail::text",
                                    to_ts=_bound_ts, end_of_day=_end_of_day)
        with self._connect() as conn:
            total = conn.execute(
                f"SELECT COUNT(*) AS c FROM audit.audit_events{where}",
                tuple(params)).fetchone()["c"]
            rows = conn.execute(
                f"SELECT * FROM audit.audit_events{where}"
                f"{_order_by(sort, order)} LIMIT %s OFFSET %s",
                (*params, int(limit), int(offset))).fetchall()
        out = []
        for r in rows:
            d = dict(r)
            for ts_col in ("occurred_at", "recorded_at"):
                if isinstance(d.get(ts_col), datetime):
                    d[ts_col] = d[ts_col].astimezone(JST).isoformat()
            out.append(d)
        return out, int(total)

    def aggregate(self, date_from: str | None = None,
                  date_to: str | None = None) -> list[dict]:
        """Event counts per JST day, category, action and severity."""
        where, params = _page_where("%s", {"date_from": date_from,
                                           "date_to": date_to}, None,
                                    "detail::text", to_ts=_bound_ts,
                                    end_of_day=_end_of_day)
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT to_char(occurred_at AT TIME ZONE 'Asia/Tokyo', "
                "'YYYY-MM-DD') AS day, category, action, severity, "
                f"COUNT(*) AS n FROM audit.audit_events{where} "
                "GROUP BY 1, 2, 3, 4", tuple(params)).fetchall()
        return [dict(r) for r in rows]

    def count(self) -> int:
        with self._connect() as conn:
            return conn.execute(
                "SELECT COUNT(*) AS c FROM audit.audit_events"
            ).fetchone()["c"]

    def close(self):
        pass                                     # no persistent connection


class SQLiteAuditBackend:
    def protection(self) -> dict:
        """A local database file can always be changed by whoever can
        write the file: not protected (DR-05, 2026-10-03)."""
        return {"protected": False,
                "detail": "The audit trail is kept in a local database "
                          "file, which the service account can change. "
                          "Use the PostgreSQL audit database with the "
                          "protective rights for a protected trail."}

    """Local-file backend with the identical event shape (dev/tests)."""

    def __init__(self, path: str = "finesiii_audit.db"):
        self.path = path
        self._lock = threading.Lock()

    def _connect(self):
        conn = sqlite3.connect(self.path, timeout=30)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        return conn

    def ensure_schema(self):
        with self._lock, self._connect() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS audit_events (
                    event_id         TEXT PRIMARY KEY,
                    occurred_at      TEXT NOT NULL,
                    recorded_at      TEXT NOT NULL,
                    category         TEXT NOT NULL,
                    action           TEXT NOT NULL,
                    severity         TEXT NOT NULL DEFAULT 'INFO',
                    request_id       TEXT,
                    transaction_id   TEXT,
                    ticket_id        TEXT,
                    operation        TEXT,
                    affiliation_code TEXT,
                    employee_code    TEXT,
                    worker_id        INTEGER,
                    source           TEXT,
                    status           TEXT,
                    result_code      TEXT,
                    error_message    TEXT,
                    detail           TEXT,
                    service_instance TEXT
                )
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_audit_occurred
                ON audit_events (occurred_at)
            """)
            conn.commit()

    def insert_events(self, events: list[dict]):
        if not events:
            return
        cols = ", ".join(EVENT_COLUMNS + ["recorded_at"])
        marks = ", ".join(["?"] * (len(EVENT_COLUMNS) + 1))
        sql = f"INSERT OR IGNORE INTO audit_events ({cols}) VALUES ({marks})"
        recorded = now_jst().isoformat()
        with self._lock, self._connect() as conn:
            for ev in events:
                row = []
                for col in EVENT_COLUMNS:
                    val = ev.get(col)
                    if col == "detail":
                        val = (json.dumps(val, ensure_ascii=False)
                               if val else None)
                    elif col == "occurred_at":
                        val = _parse_ts(val).isoformat()
                    row.append(val)
                row.append(recorded)
                conn.execute(sql, tuple(row))
            conn.commit()

    def query_events(self, category: str | None = None,
                     action: str | None = None,
                     severity: str | None = None,
                     request_id: str | None = None,
                     date_from: str | None = None,
                     date_to: str | None = None,
                     limit: int = 200) -> list[dict]:
        clauses, params = [], []
        for field, value in (("category", category), ("action", action),
                             ("severity", severity), ("request_id", request_id)):
            if value:
                clauses.append(f"{field} = ?")
                params.append(value)
        if date_from:
            clauses.append("occurred_at >= ?")
            params.append(date_from)
        if date_to:
            clauses.append("occurred_at <= ?")
            # A plain date means the whole day, as in the paged query.
            params.append(_end_of_day(date_to))
        where = (" WHERE " + " AND ".join(clauses)) if clauses else ""
        params.append(limit)
        with self._connect() as conn:
            rows = conn.execute(
                f"SELECT * FROM audit_events{where} "
                f"ORDER BY occurred_at DESC LIMIT ?", params
            ).fetchall()
        out = []
        for r in rows:
            d = dict(r)
            if d.get("detail"):
                try:
                    d["detail"] = json.loads(d["detail"])
                except (ValueError, TypeError):
                    d["detail"] = {}
            out.append(d)
        return out

    def query_page(self, offset: int = 0, limit: int = 50,
                   sort: str | None = None, order: str | None = None,
                   q: str | None = None, **filters) -> tuple[list, int]:
        """One page of events plus the total matching (console tables)."""
        where, params = _page_where("?", filters, q, "detail",
                                    end_of_day=_end_of_day)
        with self._connect() as conn:
            total = conn.execute(
                f"SELECT COUNT(*) AS c FROM audit_events{where}",
                params).fetchone()["c"]
            rows = conn.execute(
                f"SELECT * FROM audit_events{where}"
                f"{_order_by(sort, order)} LIMIT ? OFFSET ?",
                (*params, int(limit), int(offset))).fetchall()
        out = []
        for r in rows:
            d = dict(r)
            if d.get("detail"):
                try:
                    d["detail"] = json.loads(d["detail"])
                except (ValueError, TypeError):
                    d["detail"] = {}
            out.append(d)
        return out, int(total)

    def aggregate(self, date_from: str | None = None,
                  date_to: str | None = None) -> list[dict]:
        """Event counts per day, category, action and severity. Times
        are stored in JST, so the first ten characters are the JST day."""
        where, params = _page_where("?", {"date_from": date_from,
                                          "date_to": date_to}, None,
                                    "detail", end_of_day=_end_of_day)
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT substr(occurred_at, 1, 10) AS day, category, "
                f"action, severity, COUNT(*) AS n FROM audit_events{where} "
                "GROUP BY 1, 2, 3, 4", params).fetchall()
        return [dict(r) for r in rows]

    def count(self) -> int:
        with self._connect() as conn:
            return conn.execute(
                "SELECT COUNT(*) AS c FROM audit_events"
            ).fetchone()["c"]

    def close(self):
        pass


def build_backend(cfg):
    """Backend factory from the v3 settings object:
    cfg.audit_backend = postgres (default) | sqlite."""
    backend = getattr(cfg, "audit_backend", "postgres")
    if backend == "postgres":
        return PostgresAuditBackend(cfg.audit_database_url)
    if backend == "sqlite":
        return SQLiteAuditBackend(cfg.audit_sqlite_path)
    raise ValueError(f"Unsupported audit backend '{backend}'")
