"""Write-once transaction history (compliance record).

Port of v2 service/transaction_store.py with fixes baked in:
- statistics() keys on the canonical DONE status (v2 queried 'done'
  while rows said 'success', so averages were always zero);
- CSV export escapes spreadsheet-formula characters and uses the csv
  module (v2 wrote raw strings — formula injection on Excel open);
- date_to filtering is inclusive for date-only inputs (v2's raw string
  compare excluded the entire end day).

Append-only by design: this store exposes record/get/list only. In
PostgreSQL, revoke UPDATE/DELETE on transaction_history from the
service role as defense in depth.
"""
from __future__ import annotations

import csv
import io
import json
import threading

from src.core.db import Database
from src.modules.intake.models import (
    RequestStatus, TransactionRecord, now_jst, redact_secrets,
)


def _inclusive_end(date_to: str) -> str:
    """Make a date-only upper bound cover the whole day."""
    if date_to and len(date_to) == 10:
        return f"{date_to}T23:59:59.999999+09:00"
    return date_to


class TransactionStore:
    def __init__(self, db: Database):
        self.db = db
        self._lock = threading.Lock()
        self._ensure_schema()

    def _ensure_schema(self) -> None:
        # Admin-provisioned schema (scripts/schema.sql): the service
        # role doesn't own the tables, so skip bootstrap DDL entirely.
        if self.db.table_exists("transaction_history"):
            return
        with self.db.connect() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS transaction_history (
                    transaction_id TEXT PRIMARY KEY,
                    request_id TEXT NOT NULL,
                    ticket_id TEXT DEFAULT '',
                    operation TEXT NOT NULL,
                    affiliation_code TEXT NOT NULL,
                    employee_code TEXT NOT NULL,
                    source TEXT DEFAULT '',
                    status TEXT NOT NULL,
                    result_code TEXT DEFAULT '',
                    error_message TEXT DEFAULT '',
                    submitted_at TEXT DEFAULT '',
                    started_at TEXT DEFAULT '',
                    completed_at TEXT DEFAULT '',
                    duration_seconds REAL DEFAULT 0,
                    worker_id INTEGER DEFAULT 0,
                    evidence_path TEXT DEFAULT '',
                    screenshot_count INTEGER DEFAULT 0,
                    operator TEXT DEFAULT '',
                    attempt_count INTEGER DEFAULT 0,
                    metadata TEXT DEFAULT '{}',
                    recorded_at TEXT NOT NULL
                )
            """)
            conn.execute("CREATE INDEX IF NOT EXISTS idx_txn_completed "
                         "ON transaction_history(completed_at)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_txn_employee "
                         "ON transaction_history(employee_code)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_txn_ticket "
                         "ON transaction_history(ticket_id)")

    def record(self, txn: TransactionRecord) -> None:
        data = txn.to_dict()
        data["metadata"] = json.dumps(redact_secrets(data.get("metadata") or {}))
        with self._lock, self.db.connect() as conn:
            conn.execute(
                "INSERT INTO transaction_history (transaction_id, request_id, "
                "ticket_id, operation, affiliation_code, employee_code, "
                "source, status, result_code, error_message, submitted_at, "
                "started_at, completed_at, duration_seconds, worker_id, "
                "evidence_path, screenshot_count, operator, attempt_count, "
                "metadata, recorded_at) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "
                "?, ?, ?, ?, ?)",
                (data["transaction_id"], data["request_id"],
                 data["ticket_id"], data["operation"],
                 data["affiliation_code"], data["employee_code"],
                 data["source"], data["status"], data["result_code"],
                 data["error_message"], data["submitted_at"],
                 data["started_at"], data["completed_at"],
                 data["duration_seconds"], data["worker_id"],
                 data["evidence_path"], data["screenshot_count"],
                 data["operator"], data["attempt_count"],
                 data["metadata"], now_jst().isoformat()),
            )

    def get(self, transaction_id: str) -> dict | None:
        row = self.db.fetchone(
            "SELECT * FROM transaction_history WHERE transaction_id = ?",
            (transaction_id,),
        )
        return self._hydrate(row) if row else None

    def find_by_ticket(self, ticket_id: str) -> dict | None:
        if not ticket_id:
            return None
        row = self.db.fetchone(
            "SELECT * FROM transaction_history WHERE ticket_id = ? "
            "ORDER BY completed_at DESC LIMIT 1", (ticket_id,),
        )
        return self._hydrate(row) if row else None

    def list_transactions(self, status: str | None = None,
                          employee_code: str | None = None,
                          date_from: str | None = None,
                          date_to: str | None = None,
                          limit: int = 200) -> list[dict]:
        clauses, params = [], []
        if status:
            clauses.append("status = ?")
            params.append(status)
        if employee_code:
            clauses.append("employee_code = ?")
            params.append(employee_code)
        if date_from:
            clauses.append("completed_at >= ?")
            params.append(date_from)
        if date_to:
            clauses.append("completed_at <= ?")
            params.append(_inclusive_end(date_to))
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        rows = self.db.fetchall(
            f"SELECT * FROM transaction_history {where} "
            "ORDER BY completed_at DESC LIMIT ?", (*params, limit),
        )
        return [self._hydrate(r) for r in rows]

    # Console data tables (2026-09-28). Fixed lists: a sort column or a
    # search term never reaches the SQL text itself.
    SORTABLE = ("completed_at", "submitted_at", "started_at",
                "transaction_id", "request_id", "ticket_id", "operation",
                "affiliation_code", "employee_code", "source", "status",
                "result_code", "duration_seconds", "attempt_count",
                "operator", "worker_id")
    _SEARCH = ("transaction_id", "request_id", "ticket_id", "operation",
               "affiliation_code", "employee_code", "source", "status",
               "result_code", "error_message", "operator")

    def _page_where(self, filters: dict, q: str | None) -> tuple[str, list]:
        clauses, params = [], []
        for field in ("status", "employee_code", "operation", "source",
                      "affiliation_code", "ticket_id", "result_code"):
            if filters.get(field):
                clauses.append(f"{field} = ?")
                params.append(filters[field])
        if filters.get("date_from"):
            clauses.append("completed_at >= ?")
            params.append(filters["date_from"])
        if filters.get("date_to"):
            clauses.append("completed_at <= ?")
            params.append(_inclusive_end(filters["date_to"]))
        term = (q or "").strip().lower()
        if term:
            clauses.append("(" + " OR ".join(
                f"LOWER(COALESCE({c}, '')) LIKE ?" for c in self._SEARCH)
                + ")")
            params.extend([f"%{term}%"] * len(self._SEARCH))
        return (f"WHERE {' AND '.join(clauses)}" if clauses else ""), params

    def list_page(self, offset: int = 0, limit: int = 50,
                  sort: str | None = None, order: str | None = None,
                  q: str | None = None, **filters) -> tuple[list, int]:
        """One page of history plus the total matching."""
        where, params = self._page_where(filters, q)
        column = sort if sort in self.SORTABLE else "completed_at"
        direction = "ASC" if str(order or "").lower() == "asc" else "DESC"
        tail = ", completed_at DESC" if column != "completed_at" else ""
        total = self.db.fetchone(
            f"SELECT COUNT(*) AS n FROM transaction_history {where}",
            tuple(params))["n"]
        rows = self.db.fetchall(
            f"SELECT * FROM transaction_history {where} "
            f"ORDER BY {column} {direction}{tail} LIMIT ? OFFSET ?",
            (*params, int(limit), int(offset)))
        return [self._hydrate(r) for r in rows], int(total)

    def metrics_rows(self, date_from: str | None = None,
                     date_to: str | None = None) -> list[dict]:
        """The columns the metrics need for a period — no personal
        fields (employee / affiliation codes are not read)."""
        where, params = self._page_where(
            {"date_from": date_from, "date_to": date_to}, None)
        return self.db.fetchall(
            "SELECT operation, source, status, result_code, "
            "error_message, submitted_at, started_at, completed_at, "
            "duration_seconds, attempt_count, metadata "
            f"FROM transaction_history {where}", tuple(params))

    def statistics(self) -> dict:
        totals = {r["status"]: r["n"] for r in self.db.fetchall(
            "SELECT status, COUNT(*) AS n FROM transaction_history "
            "GROUP BY status")}
        avg_row = self.db.fetchone(
            "SELECT AVG(duration_seconds) AS avg_s "
            "FROM transaction_history WHERE status = ?",
            (RequestStatus.DONE.value,),
        )
        return {
            "by_status": totals,
            "total": sum(totals.values()),
            "avg_duration_seconds": round(avg_row["avg_s"] or 0.0, 2),
        }

    _EXPORT_COLUMNS = (
        "transaction_id", "request_id", "ticket_id", "operation",
        "affiliation_code", "employee_code", "source", "status",
        "result_code", "error_message", "submitted_at", "started_at",
        "completed_at", "duration_seconds", "worker_id", "evidence_path",
        "screenshot_count", "operator", "attempt_count",
    )

    @staticmethod
    def _formula_guard(value):
        """Prefix spreadsheet-executable cells so audit exports cannot
        carry formula injection into Excel."""
        if isinstance(value, str) and value[:1] in ("=", "+", "-", "@"):
            return f"'{value}"
        return value

    def export_csv(self, date_from: str | None = None,
                   date_to: str | None = None, limit: int = 100_000) -> str:
        rows = self.list_transactions(date_from=date_from, date_to=date_to,
                                      limit=limit)
        buf = io.StringIO()
        writer = csv.DictWriter(buf, fieldnames=self._EXPORT_COLUMNS,
                                extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({k: self._formula_guard(row.get(k, ""))
                             for k in self._EXPORT_COLUMNS})
        return buf.getvalue()

    @staticmethod
    def _hydrate(row: dict) -> dict:
        data = dict(row)
        try:
            data["metadata"] = json.loads(data.get("metadata") or "{}")
        except (TypeError, ValueError):
            data["metadata"] = {}
        return data
