"""Audit trail for the FINESIII v3 RPA service.

Port of v2 service/audit_trail.py. Captures EVERY operation/action the
bot performs — including errors — into the dedicated audit database
(client requirement). Two capture paths:

  1. AuditLogHandler attached to the app and RPA loggers
     ("finesiii_rpa_v3" and "finesiii_rpa_v3.rpa" — v2 used
     "finesiii_rpa"): every log record (worker steps, workflow
     progress, availability changes, notifications, connector activity,
     all errors) becomes an audit event with ZERO changes to any
     existing call site — the same extension pattern as
     modules/notifications/log_handler.py.
  2. Explicit structured events at the few operational choke points
     (submit / reject / dispatch / retry / completion), carrying the
     request identifiers as first-class queryable columns.

Delivery is write-behind with a DURABLE LOCAL SPOOL (SQLite WAL file):
events are persisted locally first, then a background flusher batches
them into the audit database. If PostgreSQL is unreachable the bot keeps
running, events accumulate in the spool, and everything is delivered
when the database recovers — at-least-once, deduplicated by event UUID,
so effectively exactly-once. An audit-sink outage can never take down or
block bot operations, and no event is ever lost.

Secrets are redacted (intake.models.redact_secrets) before an event is
spooled — clear-text credentials can never reach the audit database.

DEVIATION from v2: configuration is the flat pydantic settings object
(cfg.audit_* attributes), not a nested config dict — see
maybe_start_audit_trail.
"""
from __future__ import annotations

import json
import logging
import socket
import sqlite3
import threading
import uuid

from src.modules.audit.trail_db import EVENT_COLUMNS, build_backend
from src.modules.intake.models import now_jst, redact_secrets

# The two named loggers every v3 component logs through (same pair the
# email-alert handler uses).
AUDIT_LOGGER_NAMES = ("finesiii_rpa_v3", "finesiii_rpa_v3.rpa")

# Reentrancy guard: the log handler must never audit the audit trail's own
# internal logging (that would loop).
_tls = threading.local()


class AuditTrail:
    """Facade: event capture + durable spool + background delivery."""

    def __init__(self, backend, spool_path: str = "audit_spool.db",
                 logger=None, flush_interval: float = 2.0,
                 batch_size: int = 200, service_instance: str = ""):
        self.backend = backend
        self.spool_path = spool_path
        self.logger = logger
        self.flush_interval = flush_interval
        self.batch_size = batch_size
        self.service_instance = service_instance or socket.gethostname()

        self._spool_lock = threading.Lock()
        self._init_spool()

        self._handlers: list[tuple[logging.Logger, "AuditLogHandler"]] = []
        self._sink_up = True          # last known state, for transition logs
        self._schema_ok = False
        self._stop = threading.Event()
        self._wake = threading.Event()
        self._thread = threading.Thread(
            target=self._flush_loop, daemon=True, name="audit-flusher")
        self._thread.start()

    # ── Spool (durable local buffer) ──

    def _spool_conn(self):
        conn = sqlite3.connect(self.spool_path, timeout=30)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        return conn

    def _init_spool(self):
        with self._spool_lock, self._spool_conn() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS spool (
                    seq      INTEGER PRIMARY KEY AUTOINCREMENT,
                    event_id TEXT NOT NULL,
                    payload  TEXT NOT NULL
                )
            """)
            conn.commit()

    # ── Event capture ──

    def event(self, category: str, action: str, severity: str = "INFO",
              detail: dict | None = None, **fields):
        """Record one audit event. Known event columns are lifted out of
        `fields`; anything else rides in the JSON detail payload. Never
        raises — an audit problem must not break the operation it records."""
        try:
            ev = {
                "event_id": str(uuid.uuid4()),
                "occurred_at": now_jst().isoformat(),
                "category": category,
                "action": action,
                "severity": severity,
                "service_instance": self.service_instance,
            }
            extra = {}
            for key, value in fields.items():
                if key in EVENT_COLUMNS:
                    ev[key] = value
                elif value not in (None, ""):
                    extra[key] = value
            merged_detail = dict(detail or {})
            merged_detail.update(extra)
            ev["detail"] = redact_secrets(merged_detail) if merged_detail else None

            with self._spool_lock, self._spool_conn() as conn:
                conn.execute(
                    "INSERT INTO spool (event_id, payload) VALUES (?, ?)",
                    (ev["event_id"], json.dumps(ev, ensure_ascii=False)))
                conn.commit()
            self._wake.set()
        except Exception as e:
            self._internal_warn(f"audit event dropped: {e}")

    def transaction(self, txn):
        """Structured event for a terminal transaction outcome (immutable
        audit record's queryable twin in the event stream). `txn` is the
        v3 intake.models.TransactionRecord dataclass."""
        failed = str(txn.status).lower() in ("failed", "error")
        self.event(
            category="dispatch",
            action="transaction_completed",
            severity="ERROR" if failed else "INFO",
            request_id=txn.request_id,
            transaction_id=txn.transaction_id,
            ticket_id=txn.ticket_id,
            operation=txn.operation,
            affiliation_code=txn.affiliation_code,
            employee_code=txn.employee_code,
            worker_id=txn.worker_id,
            source=txn.source,
            status=txn.status,
            result_code=txn.result_code,
            error_message=txn.error_message or None,
            detail={
                "duration_seconds": txn.duration_seconds,
                "attempt_count": txn.attempt_count,
                "evidence_path": txn.evidence_path,
                "screenshot_count": txn.screenshot_count,
                "operator": txn.operator,
            },
        )

    def log_record(self, record: logging.LogRecord):
        """Turn a log record into an audit event (AuditLogHandler path).
        TransactionLogger prefixes 'TXN=… | STEP=… | ' — parsed out so the
        step context is queryable."""
        message = record.getMessage()
        txn_tag = step = None
        rest = message
        while True:
            head, sep, tail = rest.partition(" | ")
            if sep and head.startswith("TXN="):
                txn_tag, rest = head[4:], tail
            elif sep and head.startswith("STEP="):
                step, rest = head[5:], tail
            else:
                break
        severity = record.levelname
        self.event(
            category="log",
            action=record.levelname.lower(),
            severity=severity,
            error_message=rest if severity in ("ERROR", "CRITICAL") else None,
            detail={"message": rest,
                    **({"logger_txn": txn_tag} if txn_tag else {}),
                    **({"step": step} if step else {})},
        )

    # ── Log-handler attachment (pattern: notifications/log_handler.py) ──

    def attach_log_handler(self, min_level: str = "INFO"):
        """Attach ONE AuditLogHandler to both named loggers the app and
        the RPA layer already use (v2 attached to the single
        TransactionLogger; v3's control plane and rpa layer log through
        two named loggers)."""
        handler = AuditLogHandler(self)
        handler.setLevel(getattr(logging, str(min_level).upper(), logging.INFO))
        for name in AUDIT_LOGGER_NAMES:
            target = logging.getLogger(name)
            target.addHandler(handler)
            self._handlers.append((target, handler))
        return handler

    # ── Background delivery ──

    def _flush_loop(self):
        while not self._stop.is_set():
            self._wake.wait(timeout=self.flush_interval)
            self._wake.clear()
            try:
                self._flush_once()
            except Exception as e:
                self._sink_transition(False, e)
                self._stop.wait(self.flush_interval)

    def _flush_once(self) -> int:
        """Deliver up to batch_size spooled events. Returns rows delivered."""
        with self._spool_lock, self._spool_conn() as conn:
            rows = conn.execute(
                "SELECT seq, payload FROM spool ORDER BY seq LIMIT ?",
                (self.batch_size,)).fetchall()
        if not rows:
            return 0

        events = [json.loads(r["payload"]) for r in rows]
        if not self._schema_ok:
            self.backend.ensure_schema()
            self._schema_ok = True
        self.backend.insert_events(events)      # idempotent on event_id
        with self._spool_lock, self._spool_conn() as conn:
            conn.execute(
                "DELETE FROM spool WHERE seq <= ?", (rows[-1]["seq"],))
            conn.commit()
        self._sink_transition(True)
        if len(rows) == self.batch_size:
            self._wake.set()                    # more waiting — keep going
        return len(rows)

    def _sink_transition(self, up: bool, error: Exception | None = None):
        """Log audit-sink state CHANGES only (never a per-event log storm)."""
        if up and not self._sink_up:
            self._sink_up = True
            self._internal_warn("audit database recovered — spool draining")
        elif not up and self._sink_up:
            self._sink_up = False
            self._internal_warn(
                f"audit database unreachable — events spooling locally: {error}")

    def _internal_warn(self, message: str):
        if self.logger is None:
            return
        _tls.guard = True                        # never audit our own logs
        try:
            self.logger.warning(f"[audit] {message}")
        except Exception:
            pass
        finally:
            _tls.guard = False

    # ── Introspection / lifecycle ──

    def pending(self) -> int:
        """Events waiting in the local spool (0 = fully delivered)."""
        with self._spool_lock, self._spool_conn() as conn:
            return conn.execute("SELECT COUNT(*) AS c FROM spool").fetchone()["c"]

    def query(self, **filters):
        return self.backend.query_events(**filters)

    def query_page(self, **options) -> tuple[list, int]:
        """A page of events and the total matching — console tables
        (2026-09-28). A backend without paging falls back to the plain
        query, so a custom backend keeps working."""
        if hasattr(self.backend, "query_page"):
            return self.backend.query_page(**options)
        filters = {k: options.get(k) for k in (
            "category", "action", "severity", "request_id",
            "date_from", "date_to") if options.get(k)}
        rows = self.backend.query_events(limit=1000, **filters)
        offset = int(options.get("offset") or 0)
        limit = int(options.get("limit") or 50)
        return rows[offset:offset + limit], len(rows)

    def protection(self) -> dict:
        """{"protected": bool|None, "detail": text} — None when it could
        not be checked (DR-05, 2026-10-03). Never raises."""
        if not hasattr(self.backend, "protection"):
            return {"protected": None,
                    "detail": "The protection of this audit store cannot "
                              "be checked."}
        try:
            return self.backend.protection()
        except Exception as e:
            return {"protected": None,
                    "detail": f"The audit database could not be checked: "
                              f"{type(e).__name__}"}

    def aggregate(self, date_from=None, date_to=None) -> list[dict]:
        """Event counts per day / category / action / severity."""
        if hasattr(self.backend, "aggregate"):
            return self.backend.aggregate(date_from=date_from,
                                          date_to=date_to)
        return []

    def flush(self, timeout: float = 10.0) -> bool:
        """Block until the spool is empty (or timeout). For shutdown/tests."""
        import time
        deadline = time.time() + timeout
        self._wake.set()
        while time.time() < deadline:
            if self.pending() == 0:
                return True
            time.sleep(0.05)
            self._wake.set()
        return self.pending() == 0

    def close(self, drain_timeout: float = 10.0):
        try:
            self.flush(timeout=drain_timeout)
        except Exception:
            pass
        self._stop.set()
        self._wake.set()
        self._thread.join(timeout=5)
        for target, handler in self._handlers:
            target.removeHandler(handler)
        self._handlers.clear()
        try:
            self.backend.close()
        except Exception:
            pass


class AuditLogHandler(logging.Handler):
    """Bridges the existing loggers into the audit trail. Failures are
    swallowed — logging must never break, and neither must the operation
    being logged."""

    def __init__(self, trail: AuditTrail):
        super().__init__()
        self.trail = trail

    def emit(self, record: logging.LogRecord):
        if getattr(_tls, "guard", False):
            return
        _tls.guard = True
        try:
            self.trail.log_record(record)
        except Exception:
            pass
        finally:
            _tls.guard = False


def maybe_start_audit_trail(cfg, logger=None) -> AuditTrail | None:
    """Build the audit trail from the v3 settings object. Returns None
    unless cfg.audit_enabled is true — the default — so existing
    deployments are byte-identical until the operator opts in.

    A failure to reach the audit database at startup does NOT prevent the
    service from starting: events spool locally and deliver on recovery.

    DEVIATION from v2: `cfg` is the flat pydantic settings object
    (config/base.py audit_* fields), not a nested dict, and the postgres
    backend receives the single full DSN cfg.audit_database_url instead
    of v2's AUDIT_DB_USER / AUDIT_DB_PASSWORD / host / port assembly.
    Log capture attaches to the two v3 named loggers directly, so it no
    longer requires the `logger` argument (that is only the sink for the
    trail's own internal warnings)."""
    if cfg is None or not getattr(cfg, "audit_enabled", False):
        return None

    backend = build_backend(cfg)
    instance = f"{socket.gethostname()}:{getattr(cfg, 'api_port', 8000)}"
    trail = AuditTrail(
        backend,
        spool_path=cfg.audit_spool_path,
        logger=logger,
        flush_interval=float(cfg.audit_flush_interval_seconds),
        batch_size=int(cfg.audit_batch_size),
        service_instance=instance,
    )
    if cfg.audit_capture_log_events:
        trail.attach_log_handler(min_level=cfg.audit_min_log_level)
    if logger:
        logger.info(
            f"Audit trail started (backend={cfg.audit_backend}, "
            f"spool={trail.spool_path})")
    trail.event("system", "audit_started",
                detail={"backend": cfg.audit_backend})
    return trail
