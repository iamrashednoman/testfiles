"""Domain modules of the orchestrator control plane.

Each module is a FastAPI APIRouter package (the FastAPI equivalent of a
Flask Blueprint) with the same internal shape as the enterprise
template: routes.py (HTTP), services.py (business logic), models.py
(persistence), schemas.py (Pydantic request/response contracts).
Modules are registered by src.create_app().
"""
