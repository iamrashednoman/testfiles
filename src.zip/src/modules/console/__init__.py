"""Read APIs the admin console needs that the public contract lacks.

Kept apart from src/modules/intake so the client-facing CRUD contract
stays exactly what it is. Everything here is console-only, requires a
signed-in user, and is read-only.
"""
