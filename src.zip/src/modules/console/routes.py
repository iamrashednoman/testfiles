"""Console-only read APIs: evidence, error catalogue, dashboard.

  GET /console/summary                       dashboard in one call
  GET /console/error-rules                   the live catalogue + SHA
  GET /console/evidence/{request_id}         the capture list
  GET /console/evidence/{request_id}/{file}  one PNG or TXT

EVIDENCE IS SENSITIVE. A provision screenshot shows the new account's
password in CLEAR TEXT — the sim replicates the real terminal, which
renders FID row 107 unmasked. So these routes require a signed-in
console user and every file read is written to the audit trail: who
looked at which transaction's evidence, and when.
"""
from __future__ import annotations

import os
import threading
import time
from pathlib import Path

from fastapi import (
    APIRouter, Body, Depends, Header, HTTPException, Query, Request,
)
from fastapi.responses import FileResponse

from src.modules.auth.models import AppUser

# A request ID as the service issues it (req_…), or a legacy plain one:
# letters, digits, "_" and "-" only (UAT-11, 2026-10-04).
import re as _re
_PLAIN_ID = _re.compile(r"^[A-Za-z0-9_-]{1,80}$")

# Only what the evidence pipeline produces.
_ALLOWED_SUFFIXES = {".png", ".txt"}
# A 76-byte file is the simulator's placeholder: the window capture
# failed and nothing real was recorded. Surfaced explicitly so a blank
# capture is visible in the UI instead of looking like a black screen.
_PLACEHOLDER_MAX_BYTES = 2048
# A thumbnail fetched by the evidence page right after it listed the
# folder is covered by that (audited) listing; only this long, and only
# this many listings are remembered (approved D16).
_LISTING_TTL_SECONDS = 15 * 60
_LISTING_MAX_ENTRIES = 1000


def build_console_router(queue_store, transaction_store, auth_service,
                         cfg, dispatcher=None, availability=None,
                         audit=None, settings_store=None,
                         restart_hook=None) -> APIRouter:
    router = APIRouter(prefix="/api/v1/console")

    def _not_processing_reason() -> str:
        if not getattr(cfg, "dispatcher_enabled", True):
            return "Process queued work is Off (Settings > Dispatcher)"
        return ("No terminal to run requests on (the service accepts "
                "requests only)")

    def _service_environment() -> str:
        """development or production: the configuration in force."""
        try:
            from config import _app_env
            return _app_env() or "development"
        except Exception:
            return "development"
    # Each route asks for the PERMISSION it needs, so a custom role
    # can be granted exactly one of these without inheriting the rest.
    from src.modules.auth.services import build_permission_dependency
    require_dashboard = build_permission_dependency(auth_service,
                                                    "dashboard.view")
    require_rules_view = build_permission_dependency(auth_service,
                                                     "rules.view")
    require_rules_edit = build_permission_dependency(auth_service,
                                                     "rules.edit")
    require_evidence = build_permission_dependency(auth_service,
                                                   "evidence.view")
    require_settings_view = build_permission_dependency(auth_service,
                                                        "settings.view")
    require_settings_edit = build_permission_dependency(auth_service,
                                                        "settings.edit")

    def _audit(action: str, user: AppUser, severity: str = "INFO",
               **fields):
        if audit is not None:
            try:
                audit.event("console", action, severity=severity,
                            actor=user.username, **fields)
            except Exception:
                pass

    # ── Dashboard ──

    # Whole-history figures of the summary, computed at most once a
    # minute (DR-01): the dashboard refreshes every 5 seconds.
    figures = {"at": 0.0, "stats": None, "codes": None}
    figures_lock = threading.Lock()
    FIGURES_SECONDS = 60.0

    def _summary_figures():
        """(statistics, result-code counts), recomputed when older than a
        minute; (None, None) when they could not be read."""
        with figures_lock:
            if figures["stats"] is not None \
                    and time.monotonic() - figures["at"] < FIGURES_SECONDS:
                return figures["stats"], figures["codes"]
        try:
            stats = transaction_store.statistics()
            codes = {}
            for t in transaction_store.list_transactions(limit=200):
                code = str(t.get("result_code") or "")
                if code:
                    codes[code] = codes.get(code, 0) + 1
        except Exception:
            return None, None
        with figures_lock:
            figures.update(at=time.monotonic(), stats=stats, codes=codes)
        return stats, codes

    # The Dashboard during a database outage (UAT-L01, 2026-10-04): the
    # sign-in check reads the database too, so the whole summary used to
    # fail. A session that passed the full check in the last few minutes,
    # with a token that still verifies, may read the summary meanwhile -
    # this route only, read-only, and the answer says what is unavailable.
    seen_sessions: dict = {}
    SEEN_SECONDS = 600.0

    def require_dashboard_in_outage(
            authorization: str = Header(default="")) -> AppUser:
        import hashlib
        from src.modules.intake.routes import database_errors
        token = (authorization[7:].strip()
                 if authorization.lower().startswith("bearer ") else "")
        key = hashlib.sha256(token.encode()).hexdigest() if token else ""
        try:
            user = require_dashboard(authorization=authorization)
        except database_errors():
            entry = seen_sessions.get(key)
            if not key or entry is None \
                    or time.monotonic() - entry[1] > SEEN_SECONDS \
                    or not auth_service.claims(token):
                raise
            return entry[0]
        if key:
            if len(seen_sessions) > 500:
                seen_sessions.clear()
            seen_sessions[key] = (user, time.monotonic())
        return user

    def _queue_depth():
        try:
            return queue_store.queue_depth()
        except Exception:
            return None

    @router.get("/summary")
    def summary(user: AppUser = Depends(require_dashboard_in_outage)):
        """Everything the dashboard shows, in ONE round trip.

        A window polling five endpoints every few seconds against a
        service that is also driving a terminal is wasteful; this keeps
        the UI to a single request per refresh.
        """
        from src.modules.intake.models import now_jst

        db_ok = True
        try:
            queue_store.db.fetchone("SELECT 1 AS ok")
        except Exception:
            db_ok = False

        # The ten rows shown are read on every refresh; the whole-history
        # figures once a minute (DR-01, 2026-10-03). A value that could
        # not be read is None — "unavailable", never an empty list that
        # looks like "no transactions yet" (DR-02).
        recent = None
        try:
            recent = [_txn_row(t) for t in
                      transaction_store.list_transactions(limit=10)]
        except Exception:
            pass
        stats, codes = _summary_figures()
        try:
            sees_codes = auth_service is None or auth_service.require(
                user, "requests.view")
        except Exception:
            sees_codes = False          # not known now: the safe answer
        if recent is not None and not sees_codes:
            # Monitoring-only roles see the dashboard, not who the
            # transactions were for (DR-12).
            recent = [dict(r, employee_code="") for r in recent]

        # Which error rules actually fired today, from the audit trail
        # (DR-08: the day, not the last 500 events of any age). The
        # result-code counts cannot show this: one rule can fire with no
        # mainframe code at all (a modal dialog, a rejected login),
        # which is exactly the failure worth watching.
        by_rule = {}
        if audit is not None:
            try:
                for e in audit.query(
                        category="rpa_error",
                        date_from=now_jst().date().isoformat(), limit=500):
                    detail = e.get("detail") or {}
                    if detail.get("acted"):
                        rid = detail.get("error_id") or "unknown"
                        by_rule[rid] = by_rule.get(rid, 0) + 1
            except Exception:
                by_rule = None          # "Unavailable", not "none" (L01)

        audit_card = None
        if audit is not None:
            # Events waiting to be written to the audit database: an
            # outage of the audit database shows here (DR-07).
            try:
                audit_card = {"enabled": True,
                              "pending": int(audit.pending())}
            except Exception:
                audit_card = {"enabled": True, "pending": None}
        return {
            "audit": audit_card or {"enabled": False, "pending": 0},
            # When this answer was made, for the "Last updated" line.
            "generated_at": now_jst().isoformat(timespec="seconds"),
            "errors_by_rule": by_rule,
            "service": "up",
            "database": "up" if db_ok else "down",
            "engine": queue_store.db.engine,
            "driver": cfg.terminal_driver,
            "environment": cfg.mainframe_environment,
            # The service's own posture, shown beside the mainframe's
            # (OPS-03, 2026-10-04).
            "service_environment": _service_environment(),
            "ocr_enabled": bool(getattr(cfg, "ocr_enabled", False)),
            "dispatcher": (dispatcher.status() if dispatcher is not None
                           else {"running": False,
                                 # Why nothing is processed (UAT-L23).
                                 "reason": _not_processing_reason()}),
            "availability": (availability.status()
                             if availability is not None else None),
            "queue": _queue_depth() if db_ok else None,
            "statistics": stats,
            "result_codes": codes,
            "recent": recent,
            "user": user.to_public_dict(),
        }

    # ── Error catalogue ──

    @router.get("/error-rules")
    def error_rules(user: AppUser = Depends(require_rules_view)):
        """The rule set that is actually live, with its content hash.

        Compliance needs to prove WHICH rules handled a transaction;
        the SHA here is the same one the startup banner prints.
        """
        from src.rpa.vision.error_catalog import ErrorCatalog

        try:
            catalog = ErrorCatalog.load(cfg.error_catalog_path,
                                        strict=False)
        except Exception as e:
            raise HTTPException(status_code=500,
                                detail=f"Error catalogue unreadable: {e}")
        # The page reads leniently; the bot does not. A file the bot
        # would refuse is said so here (UR-10, 2026-10-03), instead of
        # showing "0 rules" while every transaction would fail.
        problems = []
        try:
            problem = ErrorCatalog.problem(
                Path(cfg.error_catalog_path).read_text(encoding="utf-8"))
            if problem:
                problems.append(problem)
        except OSError as e:
            problems.append(f"The catalogue file cannot be read: "
                            f"{e.strerror or e}")
        return {
            "problems": problems,
            # The file name only: the folder layout of the server is not
            # shown to read-only users (UR-15, 2026-10-03).
            "source": Path(str(catalog.source or "")).name,
            "digest": catalog.digest,
            "count": len(catalog),
            "rules": [{
                "id": r.id, "name": r.name, "enabled": r.enabled,
                "scope": r.scope, "priority": r.priority,
                "action": r.action, "then": r.then,
                "classification": r.classification,
                "exception": r.exception, "status": r.status,
                "exit_from": r.exit_from,
                "retry_whole_request": r.retry_whole_request,
                "markers": list(r.all_markers) + list(r.any_markers),
                "message": r.message,
            } for r in catalog.rules],
        }

    @router.patch("/error-rules/{rule_id}")
    def set_rule_enabled(
            rule_id: str, enabled: bool = Body(embed=True),
            reason: str = Body(default="", embed=True, max_length=300),
            user: AppUser = Depends(require_rules_edit)):
        """Turn one catalogue rule on or off without a deploy.

        Writes the `enabled:` flag in config/errors.yaml — the same
        file the bot reads per transaction, so the change takes effect
        on the NEXT transaction with no restart. Only that one field is
        touched; comments and every other rule are left exactly as
        they are, because this file is the reviewed record of what the
        bot does.
        """
        from src.modules.console.yaml_edit import (
            CatalogInvalid, RuleNotFound, toggle_rule_file,
        )
        from src.rpa.vision.error_catalog import ErrorCatalog

        reason_text = " ".join(str(reason or "").split())
        path = Path(cfg.error_catalog_path)
        before = ErrorCatalog.load(str(path), strict=False)
        current = next((r for r in before.rules if r.id == rule_id), None)
        if current is None:
            raise HTTPException(status_code=404,
                                detail=f"No rule '{rule_id}'")
        # Turning a rule off changes what the bot does on the mainframe:
        # the reason is required by the service, not only by the page
        # (UAT-05, 2026-10-04).
        if not enabled and not reason_text:
            raise HTTPException(
                status_code=400,
                detail="A reason is required to turn a rule off")
        # The state before the change, read under the same lock as the
        # change itself, so two toggles at once record what each one
        # really changed (UAT-12, 2026-10-04).
        seen = {"was": current.enabled}

        def _note_before(text: str) -> None:
            found = ErrorCatalog.rule_enabled_in(text, rule_id)
            if found is not None:
                seen["was"] = found
        try:
            # Locked and atomic: the bot reading the file mid-write, or
            # two toggles at once, must never see a half-written file.
            # Checked like the bot loads it before it is written (UR-10).
            toggle_rule_file(path, rule_id, bool(enabled),
                             validate=ErrorCatalog.problem,
                             on_original=_note_before)
        except RuleNotFound:
            raise HTTPException(status_code=404,
                                detail=f"No rule '{rule_id}'")
        except CatalogInvalid as e:
            raise HTTPException(
                status_code=409,
                detail=(f"Not saved: the catalogue would not load — {e}. "
                        f"Correct config/errors.yaml first."))
        except OSError as e:
            raise HTTPException(status_code=500,
                                detail=f"Cannot write the catalogue: {e}")

        catalog = ErrorCatalog.load(str(path), strict=False)
        # The reason is part of the record (UR-07, 2026-10-03).
        _audit("error_rule_toggled", user, "WARNING",
               detail={"rule": rule_id, "before": seen["was"],
                       "after": bool(enabled), "digest": catalog.digest,
                       "reason": reason_text})
        return {"rule": rule_id, "enabled": bool(enabled),
                "digest": catalog.digest,
                "note": "Applies from the next transaction — the bot "
                        "reloads the catalogue per transaction."}

    # ── Evidence ──

    # (username, request_id) -> when that user last listed that folder.
    # In memory only: after a restart every thumbnail is audited again
    # until the folder is listed — the fail-safe direction.
    listings: dict[tuple[str, str], float] = {}
    listings_lock = threading.Lock()

    def _remember_listing(username: str, request_id: str) -> None:
        now = time.monotonic()
        with listings_lock:
            for key in [k for k, t in listings.items()
                        if now - t > _LISTING_TTL_SECONDS]:
                del listings[key]
            listings.pop((username, request_id), None)
            while len(listings) >= _LISTING_MAX_ENTRIES:
                del listings[next(iter(listings))]      # oldest first
            listings[(username, request_id)] = now

    def _listed_recently(username: str, request_id: str) -> bool:
        with listings_lock:
            when = listings.get((username, request_id))
        return (when is not None
                and time.monotonic() - when <= _LISTING_TTL_SECONDS)

    def _evidence_dir(request_id: str) -> Path:
        """The pinned folder for this request, or 404.

        Resolved from the RECORDED path, never from user input, and
        confirmed to sit under the configured evidence root — a
        request_id is a URL segment and must not be able to walk out.
        """
        # A NUL is never part of an ID or a file name: no evidence, not a
        # database or file system error (E2E-L24).
        if "\x00" in (request_id or ""):
            raise HTTPException(status_code=404, detail="No evidence available")
        row = queue_store.get(request_id)
        recorded = getattr(row, "evidence_path", "") if row else ""
        root = Path(cfg.evidence_dir).resolve()
        if not recorded and not _PLAIN_ID.match(request_id or ""):
            # Only a plain request ID names a folder under the root:
            # "..", "." or a path never reach the folder check (UAT-11,
            # 2026-10-04).
            raise HTTPException(
                status_code=404,
                detail=f"No evidence available for {request_id}")
        # Resolved BEFORE the containment check, so a ".." can never
        # slip through as a literal folder name (UAT-11).
        folder = (Path(recorded) if recorded
                  else (root / request_id)).resolve()
        if not folder.is_dir():
            raise HTTPException(
                status_code=404,
                detail=(f"No evidence available for {request_id} (none "
                        f"was recorded, or it was removed after the "
                        f"evidence retention period)"))
        # Strictly inside the evidence root: the root itself, or anything
        # above it, is never a request's folder (UAT-11).
        if root not in folder.parents:
            raise HTTPException(status_code=403,
                                detail="Evidence path is out of bounds")
        return folder

    def _resolve_request_id(value: str) -> str:
        """A request ID, or a ticket number (RQ-09, 2026-10-03): the
        evidence page takes either. A ticket split into several
        requests (one per affiliation code) names them to choose from."""
        if queue_store.get(value) is not None:
            return value
        matches = []
        try:
            matches = queue_store.find_ticket_requests(value)
        except Exception:
            pass
        if len(matches) == 1:
            return matches[0].request_id
        if len(matches) > 1:
            raise HTTPException(status_code=409, detail=(
                f"Ticket {value} has {len(matches)} requests: " + ", ".join(
                    f"{m.request_id} ({m.ticket_id})" for m in matches)
                + " — enter one of these request IDs."))
        return value

    @router.get("/evidence")
    def list_evidence_by_reference(
            ref: str = Query(..., min_length=1, max_length=120),
            user: AppUser = Depends(require_evidence)):
        """The same listing, with the request ID or ticket number as a
        query value: a split ticket's number ("SCTASK…/1") holds a "/",
        which cannot travel in the address path (UAT-L08, 2026-10-04)."""
        return list_evidence(ref.strip(), user)

    @router.get("/evidence/{request_id}")
    def list_evidence(request_id: str,
                      user: AppUser = Depends(require_evidence)):
        request_id = _resolve_request_id(request_id)
        folder = _evidence_dir(request_id)
        captures = []
        from src.modules.intake.models import JST
        from datetime import datetime as _dt
        for png in sorted(folder.glob("*.png")):
            txt = png.with_suffix(".txt")
            stat = png.stat()
            size = stat.st_size
            captures.append({
                "name": png.name,
                "step": png.stem[4:].rsplit("_", 1)[0],
                "sequence": png.stem[:3],
                "bytes": size,
                # When the screen was taken (JST): a retry adds to the
                # same folder, the times tell the attempts apart.
                "taken_at": _dt.fromtimestamp(stat.st_mtime, JST)
                .isoformat(timespec="seconds"),
                # The capture failed and a placeholder was written —
                # the folder LOOKS complete otherwise.
                "placeholder": size <= _PLACEHOLDER_MAX_BYTES,
                "text": txt.name if txt.is_file() else None,
            })
        # WARNING, with the file names: the page shows every capture as
        # a thumbnail, so this listing is the record of what was seen.
        _audit("evidence_listed", user, "WARNING", request_id=request_id,
               detail={"captures": len(captures),
                       "files": [c["name"] for c in captures][:200]})
        _remember_listing(user.username, request_id)
        # The folder on the server is not returned (RQ-09).
        row = queue_store.get(request_id)
        return {"request_id": request_id,
                "ticket_id": getattr(row, "ticket_id", "") or "",
                "count": len(captures),
                "placeholders": sum(1 for c in captures
                                    if c["placeholder"]),
                "captures": captures}

    @router.get("/evidence/{request_id}/{filename}")
    def get_evidence_file(request_id: str, filename: str,
                          purpose: str | None = Query(
                                    None, pattern="^thumbnail$"),
                          user: AppUser = Depends(require_evidence)):
        folder = _evidence_dir(request_id)
        # Never join user input directly: take the NAME only, so
        # "../../etc/passwd" collapses to "passwd" and then fails the
        # containment check below.
        # A name the file system refuses (e.g. with a NUL) is no file:
        # 404, not a server error (E2E-L24).
        try:
            candidate = (folder / Path(filename).name).resolve()
        except (OSError, ValueError):
            raise HTTPException(status_code=404, detail="No such file")
        if folder not in candidate.parents:
            raise HTTPException(status_code=403, detail="Out of bounds")
        if candidate.suffix.lower() not in _ALLOWED_SUFFIXES:
            raise HTTPException(
                status_code=415,
                detail=f"Only {', '.join(sorted(_ALLOWED_SUFFIXES))} "
                       f"may be served")
        if not candidate.is_file():
            raise HTTPException(status_code=404, detail="No such file")

        # A provision screenshot shows the account password in clear —
        # record who read it. A thumbnail of a folder this user has just
        # listed is already covered by the audited listing (which names
        # every file); anything else is audited per file.
        covered = (purpose == "thumbnail"
                   and candidate.suffix.lower() == ".png"
                   and _listed_recently(user.username, request_id))
        if not covered:
            _audit("evidence_viewed", user, "WARNING",
                   request_id=request_id, detail={"file": candidate.name})
        media = ("image/png" if candidate.suffix.lower() == ".png"
                 else "text/plain; charset=utf-8")
        return FileResponse(str(candidate), media_type=media)

    # ── Settings ──

    @router.get("/settings")
    def get_settings(user: AppUser = Depends(require_settings_view)):
        """The editable settings, their current EFFECTIVE values, and
        whether each is currently overridden.

        A secret is never returned — only whether one is set.
        """
        return _settings_payload()

    def _settings_payload() -> dict:
        """The Settings page's data, also used by Export configuration
        (CFG-03, 2026-10-04)."""
        from src.modules.console import settings_help
        from src.modules.console.settings_catalogue import (
            GROUPS, SETTINGS, MASK, UI_FIELDS, coerce, defaults_in_force,
        )
        from src.modules.console.settings_store import (
            applied_at_build, env_before_override,
            env_default_before_override, original_value,
        )

        from src.modules.console.settings_store import read_revision
        overrides = settings_store.all() if settings_store else {}
        at_build = applied_at_build(cfg)
        # Who changed each setting last, and when (CFG-03): the revision
        # record knows saves and clears since 4 October 2026; the table
        # row knows the latest save before that.
        revision = read_revision(settings_store, "console")
        row_info = {}
        if settings_store is not None:
            try:
                row_info = {r["key"]: (r.get("updated_by") or "",
                                       r.get("updated_at") or "")
                            for r in settings_store.rows()}
            except Exception:
                row_info = {}

        def cleared_pending(spec) -> bool:
            """A restart-type setting whose override was cleared after
            the service was built: the old value is still in force until
            the restart (BUG-054)."""
            key = spec["key"]
            if spec["apply"] != "restart" or key in overrides:
                return False
            if spec["target"] == "env":
                return env_before_override(key)[0]
            return key in at_build

        def env_after_restart(key: str) -> str:
            """The environment value a setting falls back to: what the
            environment held before the console changed it."""
            changed, before = env_before_override(key)
            return str(before or "") if changed else \
                os.environ.get(key, "")

        def set_pending(spec) -> bool:
            """A restart-type override saved (or changed) after the
            service was built: not yet in force."""
            key = spec["key"]
            if spec["apply"] != "restart" or key not in overrides:
                return False
            try:
                value = coerce(spec, overrides[key])
            except ValueError:
                return False
            if spec["target"] == "env":
                text = ("true" if value is True else "false"
                        if value is False else str(value))
                return os.environ.get(key) != text
            return key not in at_build or at_build[key] != value

        # What is in force for settings nobody has set (YAML/class
        # defaults) — shown instead of a blank that reads as Off.
        defaults = defaults_in_force(
            s["key"] for s in SETTINGS
            if s["target"] == "env" and not s["secret"]
            and s["key"] not in overrides
            and not (env_after_restart(s["key"]) if cleared_pending(s)
                     else os.environ.get(s["key"], "")))
        # A cleared restart-type environment setting: the environment
        # still holds the old override until the restart, so the default
        # read above would only repeat it. Use the default recorded before
        # the overrides were applied (NB-023).
        for s in SETTINGS:
            if s["target"] == "env" and not s["secret"] \
                    and cleared_pending(s):
                recorded = env_default_before_override(s["key"])
                if recorded is not None:
                    defaults[s["key"]] = recorded
        items = []
        for spec in SETTINGS:
            key = spec["key"]
            pending = cleared_pending(spec)
            # Show the value that WILL be in force: a stored override
            # wins even before the restart that loads it, or the field
            # would still read the old value right after saving. A
            # cleared one shows what it falls back to (BUG-054).
            if key in overrides:
                effective = overrides[key]
            elif spec["target"] == "env":
                effective = (env_after_restart(key) if pending
                             else os.environ.get(key, ""))
            elif pending:
                effective = original_value(cfg, key)
            else:
                effective = getattr(cfg, key, "")
            pending = pending or (not spec["secret"] and set_pending(spec))
            is_default = False
            if spec["secret"]:
                effective = MASK if effective else ""
            elif effective in ("", None) and key in defaults:
                effective, is_default = defaults[key], True
            # A stored value that fails its check is ignored at start
            # (NB-024): shown as it was stored, marked not valid, and not
            # as "Changed here" — it is not in force.
            invalid = False
            if key in overrides and not spec["secret"]:
                try:
                    coerce(spec, overrides[key])
                except ValueError:
                    invalid = True
            items.append({
                **{k: spec.get(k) for k in UI_FIELDS},
                "value": effective,
                "overridden": key in overrides and not invalid,
                "invalid": invalid,
                "is_default": is_default,
                # The value shown is not in force yet: it applies after
                # the service restarts (BUG-054).
                "pending_restart": pending,
                # Presentation (2026-09-28): where the setting sits on the
                # page and what it does, in plain language.
                "section": settings_help.section(key),
                "tooltip": settings_help.tooltip(key, spec.get("help")),
                **_last_change(key, revision, row_info),
            })
        return {"groups": GROUPS, "settings": items,
                "editable": bool(settings_store),
                "restartable": restart_hook is not None,
                # Where these settings are kept, and the revision a save
                # from this page refers to (CFG-03 / CFG-06).
                "stored_in": "application database",
                "revision": {k: revision[k] for k in ("rev", "by", "at")}}

    def _last_change(key: str, revision: dict, row_info: dict) -> dict:
        entry = revision["keys"].get(key)
        if entry:
            return {"changed_by": entry[1], "changed_at": entry[2]}
        by, at = row_info.get(key, ("", ""))
        return {"changed_by": by, "changed_at": at}

    @router.put("/settings")
    def put_settings(request: Request, changes: dict = Body(...),
                     user: AppUser = Depends(require_settings_edit),
                     x_settings_revision: str | None = Header(None)):
        """Store one or more overrides.

        Validated server-side against the catalogue's own bounds — the
        UI renders the same limits, but a UI is not a control. An empty
        string CLEARS an override, so a setting can be handed back to
        the environment.
        """
        from src.modules.console.settings_catalogue import (
            BLANK_IS_NO_CHECK, BY_KEY, NO_CHECK, coerce,
        )
        from src.modules.console.settings_store import FORBIDDEN

        if settings_store is None:
            raise HTTPException(
                status_code=503,
                detail="Settings storage is unavailable on this service")

        applied, cleared, needs_restart = {}, [], False
        submitted = dict(changes or {})
        # Pass 1 — validate EVERYTHING; nothing is stored until the whole
        # request is valid (CFG-01: a bad key used to leave the earlier
        # keys of the same request saved).
        to_clear, to_set = [], []
        for key, raw in submitted.items():
            spec = BY_KEY.get(key)
            if spec is None or key in FORBIDDEN:
                raise HTTPException(
                    status_code=400,
                    detail=f"'{key}' is not an editable setting")
            if spec["secret"] and isinstance(raw, str) and not raw.strip():
                continue                  # blank secret = "no change"
            if key in BLANK_IS_NO_CHECK and isinstance(raw, str) \
                    and not raw.strip():
                # An emptied check is switched off, not set back to the
                # shipped value.
                to_set.append((key, spec, NO_CHECK))
                continue
            if raw is None or (isinstance(raw, str) and raw == ""
                               and not spec["secret"]):
                to_clear.append((key, spec))
                continue
            try:
                to_set.append((key, spec, coerce(spec, raw)))
            except ValueError as e:
                raise HTTPException(status_code=400, detail=str(e))

        # The operating window cannot cross midnight (CFG-03): the
        # window that results from this request must open before it
        # closes. The stop-accepting time before the close must leave
        # some of it (SY-05, 2026-10-03), or no new work would ever start.
        window_keys = ("availability_window_start", "availability_window_end",
                       "shutdown_buffer_minutes")
        if any(k in submitted for k in window_keys):
            stored = settings_store.all()
            result = {}
            for k in window_keys:
                result[k] = str(stored.get(k) or getattr(cfg, k, "") or "")
            for key, _spec in to_clear:
                if key in result:
                    result[key] = str(getattr(cfg, key, "") or "")
            for key, _spec, value in to_set:
                if key in result:
                    result[key] = str(value)
            start, end = (result[k][:5] for k in window_keys[:2])
            if start and end and start >= end:
                raise HTTPException(
                    status_code=400,
                    detail=(f"The operating window must open before it "
                            f"closes on the same day (got {start} to "
                            f"{end}); a window across midnight is not "
                            f"supported"))
            if start and end:
                def _minutes(hhmm: str) -> int:
                    hours, mins = hhmm.split(":")
                    return int(hours) * 60 + int(mins)
                try:
                    buffer = int(float(result["shutdown_buffer_minutes"]
                                       or 0))
                except ValueError:
                    buffer = 0
                span = _minutes(end) - _minutes(start)
                if buffer >= span:
                    raise HTTPException(
                        status_code=400,
                        detail=(f"Stop accepting before close ({buffer} "
                                f"min) must be shorter than the operating "
                                f"window ({start} to {end}, {span} min), "
                                f"or no new work would ever start"))

        # Values checked against the rest of this machine's set-up
        # (2026-10-03), on what WILL be in force after this request.
        set_now = {k: value for k, _spec, value in to_set}
        # Screen reading is mandatory with the real terminal (TM-01).
        if set_now.get("ocr_enabled") is False:
            from src.rpa.vision.ocr import ocr_problem
            problem = ocr_problem(getattr(cfg, "terminal_driver", ""), False)
            if problem:
                raise HTTPException(status_code=400, detail=problem)
        # The CyberArk certificate is checked wherever CyberArk is
        # required (CA-01).
        if set_now.get("CYBERARK_VERIFY_TLS") is False \
                and getattr(cfg, "require_cyberark", False):
            raise HTTPException(
                status_code=400,
                detail=("Verify TLS certificate cannot be switched off "
                        "here: CyberArk is required on this service, and "
                        "the mainframe password must only be fetched over "
                        "a checked connection."))
        # Certificate and key files must exist on this machine (CA-01).
        from src.modules.console.settings_catalogue import FILE_KEYS
        for key in FILE_KEYS:
            value = str(set_now.get(key) or "")
            if value and not Path(value).is_file():
                raise HTTPException(
                    status_code=400,
                    detail=(f"{BY_KEY[key]['label']}: the file '{value}' "
                            f"was not found on this machine"))

        # STARTTLS and implicit SSL exclude each other (2026-09-28): the
        # pair that results from this request is checked, like the
        # window above, so e-mail is never left switched off by it.
        tls_keys = ("SMTP_USE_STARTTLS", "SMTP_USE_SSL")
        if any(k in submitted for k in tls_keys):
            if all(_tls_in_force(k, settings_store.all(), to_set, to_clear)
                   for k in tls_keys):
                raise HTTPException(
                    status_code=400,
                    detail=("Choose STARTTLS (port 587) or implicit SSL "
                            "(port 465), not both."))

        # Pass 2 — store, unless one of these settings was changed by
        # someone else after the page was loaded (CFG-06, 2026-10-04).
        from src.modules.console.settings_store import (
            parse_revision, record_revision, revision_lock, stale_changes,
            stale_message,
        )
        touched = [k for k, _ in to_clear] + [k for k, _s, _v in to_set]
        with revision_lock():
            stale = stale_changes(settings_store, "console",
                                  parse_revision(x_settings_revision),
                                  touched)
            if stale:
                raise HTTPException(status_code=409, detail=stale_message(
                    stale, {k: BY_KEY[k]["label"] for k in touched}))
            # The values before this save, so a change can be put back
            # from Recent changes (CFG-07). Secrets are never recorded.
            stored_before = settings_store.all()
            before = {k: stored_before.get(k) for k in touched
                      if not BY_KEY[k]["secret"]}
            for key, spec in to_clear:
                if settings_store.clear(key):
                    cleared.append(key)
                    needs_restart |= spec["apply"] == "restart"
            for key, spec, value in to_set:
                settings_store.set(key, str(value), actor=user.username)
                applied[key] = "(set)" if spec["secret"] else value
                needs_restart |= spec["apply"] == "restart"
            revision = record_revision(settings_store, "console",
                                       list(applied) + cleared,
                                       user.username) \
                if (applied or cleared) else None

        _audit("settings_changed", user, "WARNING",
               detail={"changed": applied, "cleared": cleared,
                       "before": {k: v for k, v in before.items()
                                  if k in applied or k in cleared}})
        # Live ("hot") environment settings take effect now — set AND
        # cleared (2026-09-28) — not only when the poller next runs.
        try:
            from src.modules.console.settings_store import apply_hot_env
            apply_hot_env(settings_store)
        except Exception:
            pass
        # A ServiceNow change applies on the NEXT poll; wake the poller so
        # "next" is now rather than at the end of the old interval.
        if any(k.startswith("SNOW_") for k in list(applied) + cleared):
            poller = getattr(request.app.state, "snow_poller", None)
            if poller is not None:
                try:
                    poller.poll_now()
                except Exception:
                    pass
        return {"changed": applied, "cleared": cleared,
                "restart_required": needs_restart,
                "revision": revision,
                "note": ("Restart the service to apply these."
                         if needs_restart else "Applied.")}

    @router.get("/settings/changes")
    def settings_changes(limit: int = Query(30, ge=1, le=200),
                         user: AppUser = Depends(require_settings_view)):
        """Recent changes to the Settings pages, from the audit trail,
        one row per setting, newest first (CFG-07, 2026-10-04). A row
        recorded with the value before the change can be put back."""
        from src.modules.console.settings_catalogue import BY_KEY
        if audit is None:
            return {"enabled": False, "changes": []}
        try:
            events, _total = audit.query_page(
                offset=0, limit=limit, sort="occurred_at", order="desc",
                category="console", action="settings_changed")
        except Exception:
            return {"enabled": True, "available": False, "changes": []}
        out = []
        for e in events:
            detail = e.get("detail") if isinstance(e.get("detail"),
                                                   dict) else {}
            before = detail.get("before")
            rows = [(k, v, True) for k, v in
                    (detail.get("changed") or {}).items()]
            rows += [(k, None, False) for k in detail.get("cleared") or []]
            for key, after, is_set in rows:
                spec = BY_KEY.get(key)
                if spec is None:
                    continue
                secret = bool(spec["secret"])
                known = isinstance(before, dict) and key in before
                out.append({
                    "at": e.get("occurred_at"),
                    "by": detail.get("actor") or "",
                    "key": key, "label": spec["label"],
                    "group": spec["group"], "secret": secret,
                    "after": None if secret else after,
                    "after_set": is_set,
                    "before": (before.get(key) if known and not secret
                               else None),
                    "before_known": known and not secret,
                })
        return {"enabled": True, "available": True, "changes": out}

    @router.post("/restart", status_code=202)
    def restart(request: Request,
                user: AppUser = Depends(require_settings_edit)):
        """Rebuild the service so restart-scoped settings take effect.

        Only the desktop shell can do this — it owns the server object.
        Running headless there is nothing to call, so the API says so
        rather than pretending.
        """
        if restart_hook is None:
            raise HTTPException(
                status_code=501,
                detail=("This service cannot restart itself — it is not "
                        "running inside the desktop app. Restart it the "
                        "way you started it."))
        # Never in the middle of a terminal check (TM-03, 2026-10-03).
        check = getattr(request.app.state, "terminal_check", None)
        if check is not None and getattr(check, "running", False):
            raise HTTPException(
                status_code=409,
                detail="A terminal check is running. Wait until it has "
                       "finished (it signs off the terminal), then "
                       "restart.")
        _audit("service_restart_requested", user, "WARNING")
        restart_hook()
        return {"status": "restarting",
                "note": "Any transaction in flight finishes first."}

    # Export configuration (CFG-03) reads the same data as the page.
    router.settings_payload = _settings_payload
    return router


def _tls_default(key: str) -> bool:
    """The value an e-mail transport switch falls back to when the
    console does not set it: the environment the service was started
    with, else notifications.yaml (the same rules as the loader)."""
    from src.modules.console.settings_store import _ENV_APPLIED
    original = (_ENV_APPLIED[key] if key in _ENV_APPLIED
                else os.environ.get(key))
    if str(original or "").strip():
        return str(original).strip().lower() in ("1", "true", "yes", "on")
    smtp = {}
    try:
        import yaml
        from src.modules.notifications.config import DEFAULT_CONFIG_PATH
        with open(DEFAULT_CONFIG_PATH, "r", encoding="utf-8") as f:
            smtp = ((yaml.safe_load(f) or {}).get("notifications", {})
                    or {}).get("smtp", {}) or {}
    except Exception:
        pass
    try:
        port = int(smtp.get("port", 587))
    except (TypeError, ValueError):
        port = 587
    use_ssl = bool(smtp.get("use_ssl", port == 465))
    if key == "SMTP_USE_SSL":
        return use_ssl
    return bool(smtp.get("use_starttls", not use_ssl))


def _tls_in_force(key: str, stored: dict, to_set, to_clear) -> bool:
    """SMTP_USE_STARTTLS / SMTP_USE_SSL as they will be after a settings
    request: the submitted value, else (cleared) the fallback, else the
    stored override, else the fallback."""
    from src.modules.console.settings_catalogue import BY_KEY, coerce
    for k, _spec, value in to_set:
        if k == key:
            return value is True
    if any(k == key for k, _spec in to_clear):
        return _tls_default(key)
    if key in stored:
        try:
            return coerce(BY_KEY[key], stored[key]) is True
        except ValueError:
            pass
    return _tls_default(key)


def _txn_row(t: dict) -> dict:
    """list_transactions() yields dicts, not TransactionRecords."""
    return {k: t.get(k, "") for k in (
        "transaction_id", "request_id", "ticket_id", "operation",
        "employee_code", "status", "result_code", "completed_at",
        "screenshot_count")} | {
        "error_message": (t.get("error_message") or "")[:200]}
