"""Console metrics and reports — read-only figures for the dashboard,
the Reports page and the audited data export (2026-09-28).

  GET /console/metrics            dashboard.view   processing figures
  GET /console/reports            audit.view       audit-trail figures
  GET /console/export/{table}     requests.view (requests, transactions)
                                  audit.view    (audit)  — CSV, audited

Everything here READS: no table, setting or queue entry is changed.
The figures are computed from the existing transaction history, request
queue and audit trail; no new storage and no schema change.

Personal fields (employee and affiliation codes, names) are never part of
the metrics; only the export — a deliberate, permission-checked and
audited action — carries them, exactly as the existing history export.
"""
from __future__ import annotations

import csv
import io
import json
import math
from collections import Counter, defaultdict
from datetime import date, datetime, timedelta

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import Response

from src.modules.auth.models import AppUser
from src.modules.intake.models import JST, now_jst
from src.modules.intake.routes import audit_unavailable, checked_dates

PERIODS = {"today": 1, "7d": 7, "30d": 30, "90d": 90}
MAX_CUSTOM_DAYS = 366
EXPORT_MAX_ROWS = 50_000

# Request kinds as the business names them (SailPoint process).
KIND_LABELS = {
    "new_account": "New account",
    "access_removal": "Access removal",
    "entitlement_certification": "Entitlement certification",
    "account_certification": "Account certification",
    "transfer": "Transfer",
    "termination": "Termination",
}
OPERATION_LABELS = {"provision": "Provision", "deprovision": "Deprovision"}


def resolve_period(period: str | None, date_from: str | None,
                   date_to: str | None) -> tuple[date, date]:
    """The first and last JST day of the requested period."""
    today = now_jst().date()
    if period in (None, "", "custom") and (date_from or date_to):
        try:
            start = date.fromisoformat(str(date_from or date_to)[:10])
            end = date.fromisoformat(str(date_to or date_from)[:10])
        except ValueError:
            raise ValueError("Dates must be written as YYYY-MM-DD")
        if end < start:
            raise ValueError("The end date is before the start date")
        # A range ending after today is a range ending today, compared
        # like one (UAT-L02, 2026-10-04): there is nothing after today.
        if start > today:
            raise ValueError("The period starts after today")
        end = min(end, today)
        if (end - start).days + 1 > MAX_CUSTOM_DAYS:
            raise ValueError(
                f"A period can cover at most {MAX_CUSTOM_DAYS} days")
        return start, end
    days = PERIODS.get(period or "7d")
    if days is None:
        raise ValueError("Period must be today, 7d, 30d, 90d or custom")
    return today - timedelta(days=days - 1), today


def _day(value) -> str:
    return str(value or "")[:10]


def _hour(value) -> int | None:
    try:
        return datetime.fromisoformat(str(value)).astimezone(JST).hour
    except (TypeError, ValueError):
        return None


def _seconds_between(start, end):
    """Seconds from one ISO time to another; None when either is missing
    or unreadable."""
    try:
        a = datetime.fromisoformat(str(start))
        b = datetime.fromisoformat(str(end))
    except (TypeError, ValueError):
        return None
    if (a.tzinfo is None) != (b.tzinfo is None):
        a, b = a.replace(tzinfo=None), b.replace(tzinfo=None)
    return (b - a).total_seconds()


def _percentile(values: list, pct: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    k = max(0, math.ceil(pct / 100 * len(ordered)) - 1)
    return round(float(ordered[k]), 1)


def _kind(row: dict) -> str:
    meta = row.get("metadata")
    if isinstance(meta, str):
        try:
            meta = json.loads(meta or "{}")
        except ValueError:
            meta = {}
    meta = meta if isinstance(meta, dict) else {}
    kind = meta.get("category")
    if kind in KIND_LABELS:
        return KIND_LABELS[kind]
    op = str(row.get("operation") or "")
    return OPERATION_LABELS.get(op, op.title() or "Other")


def _outcome(row: dict) -> str:
    status = str(row.get("status") or "")
    if str(row.get("result_code") or "").upper() == "UNCONFIRMED":
        return "unconfirmed"
    if status in ("done", "already_deleted"):
        return "succeeded"
    if status == "failed":
        return "failed"
    return "other"


def compute_metrics(rows: list[dict], start: date, end: date,
                    previous_rows: list[dict] | None = None) -> dict:
    """Processing figures for one period. Pure: rows in, figures out."""
    days = [(start + timedelta(days=i)).isoformat()
            for i in range((end - start).days + 1)]
    daily = {d: Counter() for d in days}
    durations_by_day = defaultdict(list)
    durations, by_kind, by_source = [], defaultdict(Counter), Counter()
    lead_times = []         # received → finished, succeeded only (DR-04)
    by_hour, failures, outcomes = Counter(), Counter(), Counter()
    retried = 0
    for r in rows:
        outcome = _outcome(r)
        outcomes[outcome] += 1
        d = _day(r.get("completed_at"))
        if d in daily:
            daily[d][outcome] += 1
        by_kind[_kind(r)][outcome] += 1
        by_source[str(r.get("source") or "other")] += 1
        h = _hour(r.get("completed_at"))
        if h is not None:
            by_hour[h] += 1
        try:
            if int(r.get("attempt_count") or 0) > 1:
                retried += 1
        except (TypeError, ValueError):
            pass
        if outcome == "succeeded":
            try:
                secs = float(r.get("duration_seconds") or 0)
            except (TypeError, ValueError):
                secs = 0
            if secs > 0:
                durations.append(secs)
                durations_by_day[d].append(secs)
            lead = _seconds_between(r.get("submitted_at"),
                                    r.get("completed_at"))
            if lead is not None and lead >= 0:
                lead_times.append(lead)
        if outcome in ("failed", "unconfirmed"):
            code = str(r.get("result_code") or "").strip()
            reason = " ".join(str(r.get("error_message") or "").split())
            label = code or (reason[:70] or "Not recorded")
            failures[label] += 1
    total = sum(outcomes.values())
    finished = outcomes["succeeded"] + outcomes["failed"] \
        + outcomes["unconfirmed"]
    kpis = {
        "total": total,
        "succeeded": outcomes["succeeded"],
        "failed": outcomes["failed"],
        "unconfirmed": outcomes["unconfirmed"],
        "success_rate": (round(100 * outcomes["succeeded"] / finished, 1)
                         if finished else None),
        "avg_duration_seconds": (round(sum(durations) / len(durations), 1)
                                 if durations else None),
        "p95_duration_seconds": (_percentile(durations, 95)
                                 if durations else None),
        # Lead time: from receipt to the finished change (DR-04,
        # 2026-10-03). A retried request counts from its retry.
        "avg_lead_time_seconds": (round(sum(lead_times) / len(lead_times), 1)
                                  if lead_times else None),
        "p95_lead_time_seconds": (_percentile(lead_times, 95)
                                  if lead_times else None),
        "retried": retried,
    }
    if previous_rows is not None:
        prev = Counter(_outcome(r) for r in previous_rows)
        prev_finished = prev["succeeded"] + prev["failed"] \
            + prev["unconfirmed"]
        kpis["previous"] = {
            "total": sum(prev.values()),
            "failed": prev["failed"],
            "success_rate": (round(100 * prev["succeeded"] / prev_finished,
                                   1) if prev_finished else None),
        }
    return {
        "period": {"from": start.isoformat(), "to": end.isoformat(),
                   "days": len(days)},
        "kpis": kpis,
        "daily": [{"day": d, "succeeded": daily[d]["succeeded"],
                   "failed": daily[d]["failed"],
                   "unconfirmed": daily[d]["unconfirmed"],
                   "other": daily[d]["other"]} for d in days],
        "duration_trend": [{
            "day": d,
            "avg": (round(sum(durations_by_day[d])
                          / len(durations_by_day[d]), 1)
                    if durations_by_day[d] else None),
            "p95": (_percentile(durations_by_day[d], 95)
                    if durations_by_day[d] else None)} for d in days],
        "by_request_type": [{"label": k, "succeeded": c["succeeded"],
                             "failed": c["failed"],
                             "unconfirmed": c["unconfirmed"],
                             "total": sum(c.values())}
                            for k, c in sorted(by_kind.items(),
                                               key=lambda i: -sum(
                                                   i[1].values()))],
        "by_source": dict(by_source.most_common()),
        "by_hour": [{"hour": h, "count": by_hour.get(h, 0)}
                    for h in range(24)],
        "top_failures": [{"label": k, "count": n}
                         for k, n in failures.most_common(10)],
    }


def compute_reports(aggregate_rows: list[dict], start: date,
                    end: date) -> dict:
    """Audit-trail figures for one period. Pure."""
    days = [(start + timedelta(days=i)).isoformat()
            for i in range((end - start).days + 1)]
    daily = {d: Counter() for d in days}
    by_category, by_action, by_severity = Counter(), Counter(), Counter()
    for r in aggregate_rows:
        n = int(r.get("n") or 0)
        d = _day(r.get("day"))
        sev = str(r.get("severity") or "INFO").upper()
        if d in daily:
            daily[d][sev] += n
        by_category[str(r.get("category") or "")] += n
        by_action[(str(r.get("category") or ""),
                   str(r.get("action") or ""))] += n
        by_severity[sev] += n

    def count(category, *actions: str) -> int:
        """Events of these actions in one category, or in several (a
        tuple): an action is counted in the category it is recorded
        under (2026-09-28 — user and role events are 'auth', machine
        settings and credentials 'system')."""
        categories = (category,) if isinstance(category, str) else category
        return sum(by_action.get((c, a), 0)
                   for c in categories for a in actions)

    return {
        "period": {"from": start.isoformat(), "to": end.isoformat(),
                   "days": len(days)},
        "kpis": {
            "events": sum(by_severity.values()),
            "warnings": by_severity.get("WARNING", 0),
            "errors": (by_severity.get("ERROR", 0)
                       + by_severity.get("CRITICAL", 0)),
            "sign_ins": count("auth", "login_succeeded"),
            "failed_sign_ins": count("auth", "login_failed",
                                     "login_blocked"),
            "emails_sent": count("notification", "email_sent"),
            "emails_failed": count("notification", "email_failed"),
            "evidence_views": count("console", "evidence_viewed"),
            "configuration_changes": count(
                ("console", "system"), "settings_changed",
                "deployment_changed", "branding_changed", "branding_reset",
                "secret_changed", "error_rule_toggled"),
            "account_changes": count(
                ("auth", "console"), "user_created", "user_updated",
                "user_deleted", "role_created", "role_updated",
                "role_deleted"),
            # Console, users (access review) and the API export (2026-10-03).
            "exports": count(("console", "auth", "api"), "data_exported"),
        },
        "daily": [{"day": d, "info": daily[d]["INFO"],
                   "warning": daily[d]["WARNING"],
                   "error": daily[d]["ERROR"] + daily[d]["CRITICAL"]}
                  for d in days],
        "by_category": [{"label": k, "count": n}
                        for k, n in by_category.most_common()],
        "by_severity": dict(by_severity.most_common()),
        "top_actions": [{"category": c, "action": a, "count": n}
                        for (c, a), n in by_action.most_common(15)],
    }


# ── Export ────────────────────────────────────────────────────────────

REQUEST_EXPORT_COLUMNS = (
    "request_id", "operation", "affiliation_code", "employee_code",
    "source", "ticket_id", "status", "result_code", "error",
    "enqueued_at", "started_at", "completed_at", "attempt_count",
    "worker_id")
# The existing history export's columns, minus the evidence folder
# (a server location, not business data).
TRANSACTION_EXPORT_COLUMNS = (
    "transaction_id", "request_id", "ticket_id", "operation",
    "affiliation_code", "employee_code", "source", "status",
    "result_code", "error_message", "submitted_at", "started_at",
    "completed_at", "duration_seconds", "worker_id", "screenshot_count",
    "operator", "attempt_count",
    # Who submitted the request; "operator" is the mainframe account
    # that ran it (E2E-L15).
    "submitted_by")
AUDIT_EXPORT_COLUMNS = (
    "occurred_at", "category", "action", "severity", "actor",
    "request_id", "ticket_id", "operation", "affiliation_code",
    "employee_code", "status", "result_code", "error_message", "source",
    "detail",
    # Identifiers for following an event elsewhere (DR-06, 2026-10-03).
    "event_id", "transaction_id", "worker_id", "service_instance")


def _guard(value):
    """Spreadsheet-executable cells are neutralised (formula injection)."""
    if isinstance(value, (dict, list)):
        value = json.dumps(value, ensure_ascii=False)
    if isinstance(value, str) and value[:1] in ("=", "+", "-", "@",
                                                 "\t", "\r"):
        return f"'{value}"
    return value


def to_csv(rows: list[dict], columns: tuple) -> str:
    """UTF-8 with a byte-order mark, so Excel shows Japanese correctly."""
    buf = io.StringIO()
    buf.write("﻿")
    writer = csv.DictWriter(buf, fieldnames=columns, extrasaction="ignore")
    writer.writeheader()
    for row in rows:
        writer.writerow({k: _guard(row.get(k, "")) for k in columns})
    return buf.getvalue()


def build_metrics_router(queue_store, transaction_store, auth_service,
                         audit=None) -> APIRouter:
    from src.modules.auth.services import build_permission_dependency
    require_dashboard = build_permission_dependency(auth_service,
                                                    "dashboard.view")
    require_audit = build_permission_dependency(auth_service, "audit.view")
    require_requests = build_permission_dependency(auth_service,
                                                   "requests.view")
    router = APIRouter(prefix="/api/v1/console")

    def _period(period, date_from, date_to):
        try:
            return resolve_period(period, date_from, date_to)
        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e))

    @router.get("/metrics")
    def metrics(period: str | None = Query(None, max_length=10),
                date_from: str | None = Query(None, max_length=10),
                date_to: str | None = Query(None, max_length=10),
                user: AppUser = Depends(require_dashboard)):
        start, end = _period(period, date_from, date_to)
        rows = transaction_store.metrics_rows(start.isoformat(),
                                              end.isoformat())
        span = (end - start).days + 1
        prev_end = start - timedelta(days=1)
        prev_start = prev_end - timedelta(days=span - 1)
        # A period that runs until now is compared with the same elapsed
        # time of the period before (DR-03, 2026-10-03): this morning
        # with yesterday morning, not with the whole of yesterday.
        now = now_jst()
        prev_to = ((now - timedelta(days=span)).isoformat()
                   if end == now.date() else prev_end.isoformat())
        previous = transaction_store.metrics_rows(prev_start.isoformat(),
                                                  prev_to)
        out = compute_metrics(rows, start, end, previous)
        out["compared_until"] = prev_to
        try:
            out["backlog"] = {"by_status": queue_store.status_counts(),
                              "queue": queue_store.queue_depth()}
        except Exception:
            out["backlog"] = None
        out["generated_at"] = now_jst().isoformat()
        return out

    @router.get("/reports")
    def reports(period: str | None = Query(None, max_length=10),
                date_from: str | None = Query(None, max_length=10),
                date_to: str | None = Query(None, max_length=10),
                user: AppUser = Depends(require_audit)):
        if audit is None:
            raise HTTPException(status_code=503,
                                detail="The audit trail is turned off")
        start, end = _period(period, date_from, date_to)
        try:
            rows = audit.aggregate(date_from=start.isoformat(),
                                   date_to=end.isoformat())
        except Exception as e:
            # The standard 503 detail (with the waiting count), so the
            # console does not read it as "turned off" (NB-016).
            raise audit_unavailable(audit, e)
        out = compute_reports(rows, start, end)
        out["generated_at"] = now_jst().isoformat()
        # Whether the trail is protected against change, and events not
        # written to it yet (DR-05 / DR-07, 2026-10-03).
        out["protection"] = audit.protection()
        try:
            out["pending_delivery"] = int(audit.pending())
        except Exception:
            out["pending_delivery"] = None
        return out

    def _audit_export(user: AppUser, table: str, rows: int, filters: dict,
                      total: int | None = None) -> bool:
        """Record the export; True when it was recorded. The total that
        matched is kept next to the rows written, so a cut export shows
        in the trail (X-03, 2026-10-03)."""
        if audit is None:
            return False
        try:
            audit.event("console", "data_exported", severity="WARNING",
                        actor=user.username,
                        detail={"table": table, "rows": rows,
                                "total": rows if total is None else total,
                                "truncated": bool(total is not None
                                                  and total > rows),
                                "filters": {k: v for k, v in
                                            filters.items() if v}})
            return True
        except Exception:
            return False

    def _csv_response(body: str, table: str, rows: int = 0,
                      total: int = 0, audited: bool = False) -> Response:
        """The CSV, and in its headers how many rows it holds, how many
        matched, whether it was cut at EXPORT_MAX_ROWS and whether it
        was recorded in the audit trail — the page says so (X-03)."""
        stamp = now_jst().strftime("%Y%m%d_%H%M%S")
        return Response(
            content=body.encode("utf-8"), media_type="text/csv",
            headers={"Content-Disposition":
                     f'attachment; filename="finesiii_{table}_{stamp}.csv"',
                     "Cache-Control": "no-store",
                     "X-Export-Rows": str(rows),
                     "X-Export-Total": str(total),
                     "X-Export-Truncated": str(total > rows).lower(),
                     "X-Export-Audited": str(bool(audited)).lower()})

    @router.get("/export/requests")
    def export_requests(
            status: str | None = Query(None, max_length=20),
            operation: str | None = Query(None, max_length=40),
            source: str | None = Query(None, max_length=40),
            date_from: str | None = Query(None, max_length=40),
            date_to: str | None = Query(None, max_length=40),
            q: str | None = Query(None, max_length=100),
            sort: str | None = Query(None, max_length=40),
            order: str | None = Query(None, pattern="^(asc|desc)$"),
            result_code: str | None = Query(None, max_length=40),
            user: AppUser = Depends(require_requests)):
        date_from, date_to = checked_dates(date_from, date_to)
        filters = dict(status=status, operation=operation, source=source,
                       date_from=date_from, date_to=date_to, q=q,
                       result_code=result_code)
        page, total = queue_store.list_page(offset=0, limit=EXPORT_MAX_ROWS,
                                            sort=sort, order=order, **filters)
        rows = [r.to_public_dict() for r in page]
        audited = _audit_export(user, "requests", len(rows), filters, total)
        return _csv_response(to_csv(rows, REQUEST_EXPORT_COLUMNS),
                             "requests", len(rows), total, audited)

    @router.get("/export/transactions")
    def export_transactions(
            status: str | None = Query(None, max_length=20),
            operation: str | None = Query(None, max_length=40),
            source: str | None = Query(None, max_length=40),
            date_from: str | None = Query(None, max_length=40),
            date_to: str | None = Query(None, max_length=40),
            q: str | None = Query(None, max_length=100),
            sort: str | None = Query(None, max_length=40),
            order: str | None = Query(None, pattern="^(asc|desc)$"),
            result_code: str | None = Query(None, max_length=40),
            user: AppUser = Depends(require_requests)):
        date_from, date_to = checked_dates(date_from, date_to)
        filters = dict(status=status, operation=operation, source=source,
                       date_from=date_from, date_to=date_to,
                       result_code=result_code)
        rows, total = transaction_store.list_page(
            offset=0, limit=EXPORT_MAX_ROWS, sort=sort, order=order, q=q,
            **filters)
        rows = [{**r, "submitted_by": str(
                    (r.get("metadata") or {}).get("submitted_by", "")
                    if isinstance(r.get("metadata"), dict) else "")}
                for r in rows]
        audited = _audit_export(user, "transactions", len(rows),
                                {**filters, "q": q}, total)
        return _csv_response(to_csv(rows, TRANSACTION_EXPORT_COLUMNS),
                             "transactions", len(rows), total, audited)

    @router.get("/export/audit")
    def export_audit(
            category: str | None = Query(None, max_length=40),
            action: str | None = Query(None, max_length=60),
            severity: str | None = Query(None, max_length=20),
            request_id: str | None = Query(None, max_length=80),
            date_from: str | None = Query(None, max_length=40),
            date_to: str | None = Query(None, max_length=40),
            q: str | None = Query(None, max_length=100),
            sort: str | None = Query(None, max_length=40),
            order: str | None = Query(None, pattern="^(asc|desc)$"),
            # The same filters as the Audit trail page (DR-06).
            ticket_id: str | None = Query(None, max_length=80),
            operation: str | None = Query(None, max_length=40),
            user: AppUser = Depends(require_audit)):
        if audit is None:
            raise HTTPException(status_code=503,
                                detail="The audit trail is turned off")
        date_from, date_to = checked_dates(date_from, date_to)
        # The whole trail is not exported by accident (UAT-L03,
        # 2026-10-04): a period, or one request or ticket.
        if not (date_from and date_to) and not (request_id or ticket_id):
            raise HTTPException(
                status_code=400,
                detail=("Choose the first and last day (From and To) to "
                        "export the audit trail, or filter on one request "
                        "or ticket."))
        filters = dict(category=category, action=action, severity=severity,
                       request_id=request_id, date_from=date_from,
                       date_to=date_to, ticket_id=ticket_id,
                       operation=operation)
        try:
            page, total = audit.query_page(offset=0, limit=EXPORT_MAX_ROWS,
                                           sort=sort, order=order, q=q,
                                           **filters)
        except Exception as e:
            raise audit_unavailable(audit, e)
        for row in page:
            # Who did it, as a column of its own (DR-06).
            detail = row.get("detail") if isinstance(row.get("detail"),
                                                      dict) else {}
            row["actor"] = detail.get("actor") or detail.get("username") \
                or ""
        audited = _audit_export(user, "audit", len(page),
                                {**filters, "q": q}, total)
        return _csv_response(to_csv(page, AUDIT_EXPORT_COLUMNS), "audit",
                             len(page), total, audited)

    return router
