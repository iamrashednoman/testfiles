"""Branding — the one place the console's look is managed.

  GET /api/v1/console/branding    PUBLIC: what the UI needs before
                                  anyone signs in (name, logo, colours)
  PUT /api/v1/console/branding    settings.edit: replace the branding

Stored as ONE JSON document under the key "BRANDING" in the existing
app_settings table, so it travels with the database, survives upgrades,
and needs no schema change. apply_overrides() ignores keys that are not
in the settings catalogue, so this row has no effect on configuration.

Images are stored as data: URLs, validated for type and size, so the
public route can hand the UI everything in one round trip. The
executable's OWN icon (taskbar / dock / installer) is part of the signed
binary and is set at build time — packaging/make_icons.py — not here.
"""
from __future__ import annotations

import base64
import json
import re

from fastapi import APIRouter, Body, Depends, HTTPException

from src.modules.auth.models import AppUser

KEY = "BRANDING"

DEFAULTS: dict = {
    # AIG brand (2026-09-28), taken from aig.com and aig.co.jp: navy
    # #001871 (header, headings, buttons), blue #1352DE (links), sky
    # #00A4E4 (accent line), charcoal #343741 (text) on light neutrals.
    # An EMPTY image means "the AIG default that ships with the product"
    # (the official AIG logo and icon in desktop/ui/brand).
    "product_name": "FINES III RPA",
    "tagline": "Identity & Access Automation Console",
    "logo": "",                     # data:image/... (≤ 200 KB); "" = AIG logo
    "favicon": "",                  # data:image/... (≤ 64 KB); "" = AIG icon
    "login_background": "",         # data:image/... (≤ 500 KB)
    "accent_color": "#001871",      # primary: buttons, headings
    "secondary_color": "#00a4e4",   # accent line under the header
    "link_color": "#1352de",        # links and focus
    "nav_color": "#001871",         # header bar and sign-in panel
    "background_color": "#f5f7f9",
    "panel_color": "#ffffff",
    "text_color": "#343741",
    "font": "standard",
    "footer_text": "",
    "support_contact": "",
    "signin_notice": ("This system is for authorised use only. Activity "
                      "is recorded and monitored."),
    # E-mail branding — applied to every e-mail the service sends.
    # On by default since 2026-09-29 (D1): the branded designs are used
    # unless switched off on the Branding page.
    "email_html_enabled": True,
    "email_banner": "",             # data:image/png|jpeg|gif (≤ 300 KB)
    "email_logo": "",               # ""  = the AIG logo (built in)
    "email_header_color": "#001871",
    "email_accent_color": "#00a4e4",
    "email_company_name": "AIG General Insurance Company, Ltd.",
    "email_footer_text": "",
}

# Earlier defaults. A document saved before 2026-09-28 holds them as
# ordinary values; they are read as "not chosen" so the AIG defaults
# apply instead (the first dark theme, then the interim navy/sand one).
LEGACY_DEFAULTS = {
    "product_name": {"FINESIII RPA"},
    "tagline": {"admin console"},
    "accent_color": {"#2f81f7", "#10183c"},
    "secondary_color": {"#e2d6ba"},
    "nav_color": {"#10183c"},
    "background_color": {"#0f1419", "#f5f3ee"},
    "panel_color": {"#171d24"},
    "text_color": {"#e6edf3", "#1b2233"},
    "email_header_color": {"#10183c"},
    "email_accent_color": {"#e2d6ba"},
}

# Font choices are a fixed list — never free CSS.
FONTS = {
    # AIG's body typeface (Source Sans, bundled) with the Japanese
    # system fonts AIG's Japan site falls back to.
    "standard": ('"Source Sans 3", "Source Sans Pro", "Hiragino Kaku Gothic '
                 'ProN", Meiryo, "Yu Gothic UI", "Segoe UI", sans-serif'),
    "meiryo": ('Meiryo, "Yu Gothic UI", "Segoe UI", system-ui, '
               'sans-serif'),
    "noto": ('"Noto Sans JP", "Noto Sans", "Segoe UI", Meiryo, '
             'system-ui, sans-serif'),
    "system": ('system-ui, -apple-system, "Segoe UI", "Hiragino Sans", '
               'Meiryo, sans-serif'),
}

_LIMITS = {"logo": 200 * 1024, "favicon": 64 * 1024,
           "login_background": 500 * 1024,
           "email_banner": 300 * 1024, "email_logo": 100 * 1024}
# E-mail programs (Outlook in particular) do not show SVG or WebP.
_EMAIL_IMAGES = ("email_banner", "email_logo")
_TEXT_LIMITS = {"product_name": 60, "tagline": 120, "footer_text": 200,
                "support_contact": 200, "signin_notice": 600,
                "email_company_name": 80, "email_footer_text": 300}
_MULTILINE = ("signin_notice", "email_footer_text")
_BOOL_KEYS = ("email_html_enabled",)
_COLOR_KEYS = ("accent_color", "secondary_color", "link_color", "nav_color",
               "background_color", "panel_color", "text_color",
               "email_header_color", "email_accent_color")
_HEX = re.compile(r"^#[0-9a-fA-F]{6}$")
_DATA_URL = re.compile(
    r"^data:image/(png|jpeg|gif|webp|svg\+xml|x-icon|vnd\.microsoft\.icon);"
    r"base64,([A-Za-z0-9+/=\s]+)$")
# NB-029 (E8): an ICO file is accepted for the browser icon only.
_ICO_KEYS = ("favicon",)
# The names the operator sees on the Branding page, used in messages.
_IMAGE_LABELS = {"logo": "Logo", "favicon": "Browser icon",
                 "login_background": "Sign-in panel image",
                 "email_banner": "E-mail banner",
                 "email_logo": "Logo for e-mail"}


def _as_bool(value) -> bool:
    if isinstance(value, bool):
        return value
    text = str(value).strip().lower()
    if text in ("true", "1", "yes", "on"):
        return True
    if text in ("false", "0", "no", "off", ""):
        return False
    raise ValueError("must be true or false")


def _sniff(data: bytes) -> str | None:
    """The raster type the image bytes really are (their signature), or
    None when they are not a PNG, JPEG, GIF, WebP or ICO image. A cursor
    file (00 00 02 00) is not an icon."""
    if data.startswith(b"\x89PNG\r\n\x1a\n"):
        return "png"
    if data.startswith(b"\xff\xd8\xff"):
        return "jpeg"
    if data[:6] in (b"GIF87a", b"GIF89a"):
        return "gif"
    if len(data) >= 12 and data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return "webp"
    if (len(data) >= 6 and data[:4] == b"\x00\x00\x01\x00"
            and data[4:6] != b"\x00\x00"):
        return "x-icon"
    return None


def _image_types(key: str) -> str:
    """The image types a field accepts, for its messages."""
    return ("PNG, JPEG, GIF, WebP or ICO" if key in _ICO_KEYS
            else "PNG, JPEG, GIF or WebP")


def _size_text(size: int) -> str:
    """200.1 KB (204,801 bytes): rounded UP to one decimal, so a file just
    over a limit never reads as the limit itself."""
    tenths = -(-size * 10 // 1024)
    return f"{tenths / 10:.1f} KB ({size:,} bytes)"


def validate(changes: dict, content_keys=None) -> dict:
    """Return the normalised full document, or raise ValueError.

    content_keys: the image fields whose CONTENT is checked (signature,
    no SVG). None = every image field. put_branding passes the fields
    changed by the request, so an image stored before the check existed
    does not block saving anything else (2026-09-28)."""
    doc = dict(DEFAULTS)
    submitted = dict(changes or {})
    for key, raw in submitted.items():
        if key not in DEFAULTS:
            raise ValueError(f"'{key}' is not a branding field")
        if key in _BOOL_KEYS:
            try:
                doc[key] = _as_bool(raw)
            except ValueError as e:
                raise ValueError(f"{key} {e}")
            continue
        value = "" if raw is None else str(raw).strip()
        if key == "font":
            if value and value not in FONTS:
                raise ValueError(
                    f"font must be one of: {', '.join(FONTS)}")
            doc[key] = value or DEFAULTS[key]
            continue
        if key in _COLOR_KEYS:
            if value and not _HEX.match(value):
                raise ValueError(f"{key} must be a colour like #2f81f7")
            doc[key] = value.lower() or DEFAULTS[key]
        elif key in _LIMITS:
            if value:
                name = _IMAGE_LABELS.get(key, key)
                types = _image_types(key)
                m = _DATA_URL.match(value)
                if not m:
                    raise ValueError(f"{name} must be a {types} image")
                declared = m.group(1)
                if declared == "vnd.microsoft.icon":
                    declared = "x-icon"
                checked = content_keys is None or key in content_keys
                # SVG can carry script; new uploads are refused (an SVG
                # stored earlier stays until it is replaced).
                if checked and declared == "svg+xml":
                    raise ValueError(
                        f"{name}: SVG images are not accepted — upload a "
                        f"{types} image")
                if key in _EMAIL_IMAGES and declared not in (
                        "png", "jpeg", "gif"):
                    raise ValueError(
                        f"{name} must be a PNG, JPEG or GIF image — "
                        f"e-mail programs do not show SVG, WebP or ICO")
                if declared == "x-icon" and key not in _ICO_KEYS:
                    raise ValueError(
                        f"{name} must be a {types} image — an ICO file is "
                        f"accepted only for the browser icon")
                try:
                    data = base64.b64decode(
                        re.sub(r"\s", "", m.group(2)), validate=True)
                except Exception:
                    raise ValueError(f"{name} is not valid image data")
                size = len(data)
                if size > _LIMITS[key]:
                    raise ValueError(
                        f"{name} must be at most {_LIMITS[key] // 1024} KB "
                        f"({_LIMITS[key]:,} bytes); this file is "
                        f"{_size_text(size)}")
                if checked:
                    # The content, not the declared type, decides
                    # (BUG-036): a renamed text file is refused, and a
                    # JPEG declared as PNG is stored as what it is.
                    actual = _sniff(data)
                    if actual == "x-icon" and key not in _ICO_KEYS:
                        raise ValueError(
                            f"{name} is not a {types} image — an ICO file "
                            f"is accepted only for the browser icon")
                    if actual is None:
                        raise ValueError(f"{name} is not a {types} image")
                    if key in _EMAIL_IMAGES and actual not in (
                            "png", "jpeg", "gif"):
                        raise ValueError(
                            f"{name} must be a PNG, JPEG or GIF image — "
                            f"e-mail programs do not show SVG, WebP or ICO")
                    if actual != m.group(1):
                        value = (f"data:image/{actual};base64,"
                                 + re.sub(r"\s", "", m.group(2)))
                elif m.group(1) != declared:
                    value = (f"data:image/{declared};base64,"
                             + re.sub(r"\s", "", m.group(2)))
            doc[key] = value
        else:
            if len(value) > _TEXT_LIMITS[key]:
                raise ValueError(
                    f"{key} must be at most {_TEXT_LIMITS[key]} characters")
            if "\r" in value or ("\n" in value
                                   and key not in _MULTILINE):
                raise ValueError(f"{key} must be a single line")
            # A blank product name or sign-in notice goes back to the
            # default: the sign-in page never shows an empty notice
            # (UR-16, 2026-10-03).
            doc[key] = value or (DEFAULTS[key]
                                 if key in ("product_name", "signin_notice")
                                 else value)
    return doc


def load(settings_store) -> dict:
    """The stored document merged over the defaults; defaults when
    nothing is stored or storage is unavailable."""
    doc = dict(DEFAULTS)
    if settings_store is None:
        return doc
    try:
        raw = settings_store.all().get(KEY)
        if raw:
            stored = json.loads(raw)
            if isinstance(stored, dict):
                doc.update({k: v for k, v in stored.items()
                            if k in DEFAULTS
                            and v not in LEGACY_DEFAULTS.get(k, ())})
    except Exception:
        pass
    return doc


def build_branding_router(settings_store, auth_service,
                          audit=None) -> APIRouter:
    from src.modules.auth.services import build_permission_dependency
    require_edit = build_permission_dependency(auth_service, "settings.edit")
    router = APIRouter(prefix="/api/v1/console")

    def _email_defaults() -> dict:
        """The e-mail texts of notifications.yaml behind the Branding
        page; presentation only (they appear in every e-mail)."""
        try:
            from src.modules.notifications.config import (
                load_notification_config,
            )
            s = load_notification_config()
            return {"company_name": s.company_name or "",
                    "footer_text": s.footer_text or "",
                    "support_contact": s.support_contact or ""}
        except Exception:
            return {}

    @router.get("/branding")
    def get_branding():
        """Public by design: the sign-in page is branded too. Returns
        only presentation data — no configuration, no account facts."""
        return {"branding": load(settings_store),
                "editable": settings_store is not None,
                # What the e-mails use when a Branding field is blank, so
                # the page's preview matches them (UR-16, 2026-10-03).
                "email_defaults": _email_defaults()}

    @router.put("/branding")
    def put_branding(changes: dict = Body(...),
                     user: AppUser = Depends(require_edit)):
        if settings_store is None:
            raise HTTPException(
                status_code=503,
                detail="Settings storage is unavailable on this service")
        current = load(settings_store)
        merged = dict(current)
        merged.update(changes or {})
        # Image content is checked for what this request changes; an
        # image stored earlier is left as it is (BUG-036).
        changed_images = {k for k, v in (changes or {}).items()
                          if k in _LIMITS and v != current.get(k)}
        try:
            doc = validate(merged, content_keys=changed_images)
        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e))
        settings_store.set(KEY, json.dumps(doc), actor=user.username)
        if audit is not None:
            try:
                audit.event("console", "branding_changed",
                            severity="INFO", actor=user.username,
                            detail={"changed": sorted(
                                k for k in (changes or {})
                                if current.get(k) != doc.get(k))})
            except Exception:
                pass
        return {"branding": doc}

    @router.delete("/branding")
    def reset_branding(user: AppUser = Depends(require_edit)):
        if settings_store is None:
            raise HTTPException(status_code=503,
                                detail="Settings storage is unavailable")
        settings_store.clear(KEY)
        if audit is not None:
            try:
                audit.event("console", "branding_reset", severity="INFO",
                            actor=user.username)
            except Exception:
                pass
        return {"branding": dict(DEFAULTS)}

    return router
