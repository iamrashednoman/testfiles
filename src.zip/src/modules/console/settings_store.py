"""Persistence for administrator-edited settings, and applying them.

The resolution order gains one layer, on top:

    class defaults  <  .env / environment  <  ADMIN OVERRIDES

Purely additive — an install with no overrides resolves exactly as it
did before this table existed.

Deliberately NOT overridable, whatever the catalogue says: anything the
overrides themselves depend on. The database settings are read to open
the connection that holds this table, so letting the UI change them
would be a bootstrap loop and a way to lock the console out of its own
data.
"""
from __future__ import annotations

import logging
import os
import threading

from src.core.db import Database
from src.modules.auth.models import now_jst
from src.modules.console.settings_catalogue import (
    BY_KEY, coerce, defaults_in_force,
)

# Never accepted, even if someone adds them to the catalogue.
FORBIDDEN = {
    "database_engine", "database_url", "sqlite_path", "db_pool_size",
    "jwt_secret", "api_host", "api_port", "terminal_driver",
    "evidence_dir", "log_dir", "audit_spool_path", "audit_sqlite_path",
    "audit_database_url", "error_catalog_path", "ocr_keywords_path",
    "ocr_model_dir",
}

# Secrets an earlier version stored in this table. No longer editable
# here (they belong in the credential store or the environment), but a
# row left by an existing installation is still honoured until it is
# moved, so a server run without a credential store keeps working.
LEGACY_SECRET_ENV = {"SMTP_PASSWORD"}


class SettingsStore:
    def __init__(self, db: Database):
        self.db = db
        self._lock = threading.Lock()
        self._ensure_schema()

    def _ensure_schema(self) -> None:
        if self.db.table_exists("app_settings"):
            return
        try:
            with self.db.connect() as conn:
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS app_settings (
                        key        TEXT PRIMARY KEY,
                        value      TEXT NOT NULL,
                        updated_at TEXT NOT NULL,
                        updated_by TEXT DEFAULT ''
                    )
                """)
        except Exception as e:
            # Same posture as the console tables: an addition must never
            # stop the service. Without this table the platform simply
            # runs on its environment configuration, as it always has.
            raise SettingsUnavailableError(
                f"app_settings could not be created ({e})") from e

    def all(self) -> dict[str, str]:
        try:
            return {r["key"]: r["value"] for r in
                    self.db.fetchall("SELECT key, value FROM app_settings")}
        except Exception:
            return {}

    def rows(self) -> list[dict]:
        return self.db.fetchall(
            "SELECT * FROM app_settings ORDER BY key")

    def set(self, key: str, value: str, actor: str = "") -> None:
        with self._lock:
            existing = self.db.fetchone(
                "SELECT key FROM app_settings WHERE key = ?", (key,))
            now = now_jst().isoformat()
            if existing:
                self.db.execute(
                    "UPDATE app_settings SET value = ?, updated_at = ?, "
                    "updated_by = ? WHERE key = ?",
                    (str(value), now, actor, key))
            else:
                self.db.execute(
                    "INSERT INTO app_settings (key, value, updated_at, "
                    "updated_by) VALUES (?,?,?,?)",
                    (key, str(value), now, actor))

    def clear(self, key: str) -> bool:
        """Drop an override so the setting falls back to the
        environment / class default."""
        with self._lock:
            return bool(self.db.execute(
                "DELETE FROM app_settings WHERE key = ?", (key,)))

    def purge(self, key: str) -> bool:
        """Delete a row that held a secret so that its text does not
        stay readable in the database file (NB-019). On SQLite the row
        is deleted with secure_delete (the freed space is overwritten),
        then the file is compacted and the write-ahead log emptied; the
        busy timeout lets this wait for the service's own short
        transactions. A compaction that cannot run now is logged and
        left for later — the row itself is gone either way. PostgreSQL:
        a normal delete."""
        import sqlite3
        path = str(getattr(self.db, "sqlite_path", "") or "")
        if getattr(self.db, "engine", "") != "sqlite" or not path \
                or path == ":memory:":
            return self.clear(key)
        with self._lock:
            conn = sqlite3.connect(path, timeout=30, isolation_level=None)
            try:
                conn.execute("PRAGMA secure_delete=ON")
                removed = bool(conn.execute(
                    "DELETE FROM app_settings WHERE key = ?",
                    (key,)).rowcount)
                try:
                    conn.execute("VACUUM")
                    busy = conn.execute(
                        "PRAGMA wal_checkpoint(TRUNCATE)").fetchone()
                    if busy and busy[0]:
                        raise sqlite3.OperationalError("checkpoint busy")
                except sqlite3.Error:
                    logging.getLogger("finesiii_rpa_v3").warning(
                        f"Database compaction after moving {key} postponed")
                return removed
            finally:
                conn.close()


class SettingsUnavailableError(Exception):
    """The overrides table is absent and cannot be created."""


# ── A save over a newer change (CFG-06, 2026-10-04) ──
#
# Each scope keeps one row: a revision number that every save raises,
# and for each key the revision, person and time of its last change. A
# page sends the revision it was loaded at; a save is refused only for
# keys someone changed after that, so two administrators working on
# different settings do not block each other. A caller that sends no
# revision (a script) is not checked, as before.
REVISION_KEYS = {"console": "SETTINGS_REVISION",
                 "machine": "MACHINE_SETTINGS_REVISION"}
# Rows this service keeps for itself in the settings table: never shown
# or exported as settings.
INTERNAL_KEYS = {"SETTINGS_REVISION", "MACHINE_SETTINGS_REVISION",
                 "PROCESSING_PAUSED", "TERMINAL_SIGN_IN_FAILED_AT",
                 "SERVICE_ACCOUNT", "SETUP_COMPLETE", "SETUP_DISMISSED_BY",
                 "BRANDING"}
INTERNAL_PREFIXES = ("PASSWORD_HISTORY_",)
_REVISION_LOCK = threading.RLock()


def revision_lock():
    """Held from the check to the record, so two saves cannot both pass
    the check before either is recorded."""
    return _REVISION_LOCK


def read_revision(store, scope: str) -> dict:
    """{"rev": n, "by": user, "at": iso, "keys": {key: [rev, by, at]}}."""
    import json
    empty = {"rev": 0, "by": "", "at": "", "keys": {}}
    if store is None:
        return empty
    try:
        raw = store.all().get(REVISION_KEYS[scope])
        data = json.loads(raw) if raw else {}
    except Exception:
        return empty
    if not isinstance(data, dict):
        return empty
    return {"rev": int(data.get("rev") or 0), "by": str(data.get("by") or ""),
            "at": str(data.get("at") or ""),
            "keys": dict(data.get("keys") or {})}


def parse_revision(raw) -> int | None:
    """The revision a page sent (header), or None when it sent none."""
    try:
        text = str(raw if raw is not None else "").strip()
        return int(text) if text else None
    except ValueError:
        return None


def stale_changes(store, scope: str, seen: int | None, keys) -> list:
    """The keys of this save that someone changed after revision `seen`:
    [{"key", "by", "at"}], newest first. Empty when `seen` is None."""
    if seen is None:
        return []
    known = read_revision(store, scope)["keys"]
    out = []
    for key in keys:
        entry = known.get(key)
        if entry and int(entry[0]) > seen:
            out.append({"key": key, "by": entry[1], "at": entry[2]})
    return sorted(out, key=lambda e: e["at"], reverse=True)


def stale_message(stale: list, labels: dict) -> str:
    first = stale[0]
    name = labels.get(first["key"], first["key"])
    others = len(stale) - 1
    when = str(first["at"]).replace("T", " ")[:16]
    return (f"'{name}'" + (f" and {others} other setting(s)" if others else "")
            + f" changed by {first['by'] or 'someone'} at {when} (JST) "
            f"after this page was opened. Reload the page to see the "
            f"current values; nothing was saved.")


def record_revision(store, scope: str, keys, actor: str) -> dict:
    """Raise the revision and note the keys of this save."""
    import json
    current = read_revision(store, scope)
    rev = current["rev"] + 1
    at = now_jst().isoformat(timespec="seconds")
    for key in keys:
        current["keys"][key] = [rev, actor, at]
    data = {"rev": rev, "by": actor, "at": at, "keys": current["keys"]}
    store.set(REVISION_KEYS[scope], json.dumps(data), actor=actor)
    return {"rev": rev, "by": actor, "at": at}


def is_internal(key: str) -> bool:
    return key in INTERNAL_KEYS or key.startswith(INTERNAL_PREFIXES)


# Environment variables this process has overwritten from stored
# overrides, mapped to the value they held BEFORE (None = unset). Kept
# so a later apply — the in-place restart — can put a CLEARED override
# back to what the environment said, instead of leaving the stale
# override in os.environ forever.
_ENV_APPLIED: dict[str, str | None] = {}

# The built-in defaults of the stored restart-type environment settings,
# read by apply_overrides BEFORE it writes the stored values into the
# environment (NB-023). The defaults are resolved from the environment,
# so once an override is applied they would only repeat it: a cleared
# setting would show its old value as "the default" until the restart.
_ENV_DEFAULTS_BEFORE: dict[str, str] = {}


def _restore_env_overrides() -> None:
    for key, original in _ENV_APPLIED.items():
        if original is None:
            os.environ.pop(key, None)
        else:
            os.environ[key] = original
    _ENV_APPLIED.clear()
    _ENV_DEFAULTS_BEFORE.clear()


def env_default_before_override(key: str):
    """The built-in default of a restart-type environment setting as it
    was before the stored overrides were applied (None when unknown)."""
    return _ENV_DEFAULTS_BEFORE.get(key)


# The same for configuration fields (2026-09-28), per configuration
# object: {id(cfg): (cfg, {key: value before}, {key: value applied})}.
# The object itself is held so its id cannot be reused by another one.
# Kept so a later apply to the SAME object can undo a cleared override,
# and so the settings page can show the value a cleared restart-type
# setting falls back to (and that a restart is still pending).
_CFG_APPLIED: dict[int, tuple] = {}
_CFG_RECORDS_MAX = 32


def _cfg_record(cfg, create: bool = False):
    record = _CFG_APPLIED.get(id(cfg))
    if record is not None and record[0] is cfg:
        return record
    if not create:
        return None
    record = (cfg, {}, {})
    _CFG_APPLIED[id(cfg)] = record
    while len(_CFG_APPLIED) > _CFG_RECORDS_MAX:
        del _CFG_APPLIED[next(iter(_CFG_APPLIED))]
    return record


def _restore_cfg_overrides(cfg) -> None:
    record = _cfg_record(cfg)
    if record is None:
        return
    _cfg, originals, applied = record
    for key, original in originals.items():
        try:
            object.__setattr__(cfg, key, original)
        except Exception:
            pass
    originals.clear()
    applied.clear()


def original_value(cfg, key: str):
    """The configuration value `key` had before a stored override was
    applied to `cfg` (the current value when none was applied)."""
    record = _cfg_record(cfg)
    if record is not None and key in record[1]:
        return record[1][key]
    return getattr(cfg, key, None)


def applied_at_build(cfg) -> dict:
    """{key: value} of the configuration overrides applied to `cfg` when
    the service was built (empty when none, or unknown object)."""
    record = _cfg_record(cfg)
    return dict(record[2]) if record is not None else {}


def env_before_override(key: str):
    """(True, value before the console changed it) for an environment
    setting the console has overwritten in this process; else
    (False, None)."""
    if key in _ENV_APPLIED:
        return True, _ENV_APPLIED[key]
    return False, None


def set_env_override(key: str, value: str) -> None:
    """Write a console value into the environment, remembering what was
    there before, so clearing it later restores the original."""
    _ENV_APPLIED.setdefault(key, os.environ.get(key))
    os.environ[key] = value


def clear_env_override(key: str) -> bool:
    """Undo set_env_override for one key: the environment value from
    before the console changed it (or unset). True when something was
    restored. A key the console never set is left alone."""
    if key not in _ENV_APPLIED:
        return False
    original = _ENV_APPLIED.pop(key)
    if original is None:
        os.environ.pop(key, None)
    else:
        os.environ[key] = original
    return True


# Stored values that are no longer valid, already reported once (the
# live settings are re-applied before every ServiceNow poll).
_WARNED_INVALID: set = set()

# Keys whose stored value failed its check when the service was built
# (NB-024): shown as start-up warnings and marked on the settings page.
_INVALID_AT_BUILD: set = set()


def invalid_at_build() -> list[str]:
    """Stored settings ignored at the last service build because their
    value is not valid, sorted."""
    return sorted(_INVALID_AT_BUILD)


def startup_cross_checks(cfg, store=None, logger=None) -> list[str]:
    """The checks Save applies across settings, applied to the values in
    force when the service is built (UAT-07, 2026-10-04): a value stored
    before a rule existed was used without a word.

    - "Stop accepting before close" at least as long as the operating
      window: no new work would ever start. The stored value is ignored
      (the default applies, or 0) and reported, like any value that is
      not valid.
    - A certificate or key file that does not exist on this machine:
      reported (the connection that needs it fails until corrected).
    Returns the warnings for the dashboard and the System page."""
    warnings = []
    start = str(getattr(cfg, "availability_window_start", "") or "")[:5]
    end = str(getattr(cfg, "availability_window_end", "") or "")[:5]

    def _minutes(hhmm: str) -> int:
        hours, mins = hhmm.split(":")
        return int(hours) * 60 + int(mins)
    try:
        span = _minutes(end) - _minutes(start) if start and end else 0
        buffer = int(getattr(cfg, "shutdown_buffer_minutes", 0) or 0)
    except (ValueError, TypeError):
        span = buffer = 0
    if span > 0 and buffer >= span:
        default = 0
        try:
            default = int(type(cfg).model_fields[
                "shutdown_buffer_minutes"].default or 0)
        except Exception:
            pass
        replacement = default if default < span else 0
        try:
            object.__setattr__(cfg, "shutdown_buffer_minutes", replacement)
        except Exception:
            pass
        label = BY_KEY.get("shutdown_buffer_minutes", {}).get(
            "label", "shutdown_buffer_minutes")
        warnings.append(
            f"Stored setting '{label}' ({buffer} min) is not shorter than "
            f"the operating window ({start} to {end}, {span} min) and is "
            f"ignored ({replacement} min applies); correct it under "
            f"Settings > Operating window.")
        if logger:
            logger.warning(warnings[-1])
    from src.modules.console.settings_catalogue import FILE_KEYS
    for key in sorted(FILE_KEYS):
        value = os.environ.get(key, "").strip()
        if value and not os.path.isfile(value):
            label = BY_KEY.get(key, {}).get("label", key)
            warnings.append(
                f"Setting '{label}' ({key}) names a file that does not "
                f"exist on this machine ({os.path.basename(value)}); "
                f"correct it under Settings.")
            if logger:
                logger.warning(warnings[-1])
    return warnings


def _warn_invalid(key: str, raw, logger=None) -> None:
    """A stored value that fails its check is skipped; say so (the key
    only — the value may be an address or a secret)."""
    marker = (key, str(raw))
    if marker in _WARNED_INVALID:
        return
    _WARNED_INVALID.add(marker)
    (logger or logging.getLogger("finesiii_rpa_v3")).warning(
        f"Ignoring stored setting {key}: the stored value is not valid "
        f"(re-enter it on the settings page)")


def apply_hot_env(store: SettingsStore) -> None:
    """Make the environment match the store for every LIVE ("hot")
    environment setting: stored values applied, cleared ones restored
    (2026-09-28 — a cleared ServiceNow setting used to stay in force
    until the process was restarted)."""
    stored = store.all()
    for key, spec in BY_KEY.items():
        if spec["apply"] != "hot" or spec["target"] != "env" \
                or key in FORBIDDEN:
            continue
        if key in stored:
            try:
                value = coerce(spec, stored[key])
            except ValueError:
                _warn_invalid(key, stored[key])
                continue
            set_env_override(key, "true" if value is True else
                             "false" if value is False else str(value))
        else:
            clear_env_override(key)


def apply_overrides(cfg, store: SettingsStore, logger=None) -> dict:
    """Layer stored overrides onto `cfg` and the environment.

    Called ONCE per service build in create_app, BEFORE the database
    stores, dispatcher, executor and notifiers are built — so a
    "restart required" setting genuinely takes effect on the next
    service build, which is exactly what the Restart button does. On a
    rebuild in the SAME process, env-target overrides applied by the
    previous build are first restored, so clearing one really does fall
    back to the environment. Configuration fields set by an earlier
    apply to the same object are put back the same way (2026-09-28).

    Returns {key: value} for what was applied, for the startup log.
    """
    _restore_env_overrides()
    _restore_cfg_overrides(cfg)
    # Every build reports an ignored stored value again (NB-024); the
    # once-only rule is for the live re-apply before each poll.
    _INVALID_AT_BUILD.clear()
    _WARNED_INVALID.clear()
    stored = store.all()
    # The environment holds no override at this point: record what the
    # stored restart-type settings fall back to when cleared (NB-023).
    keys = [k for k in stored
            if k in BY_KEY and k not in FORBIDDEN
            and BY_KEY[k]["target"] == "env"
            and BY_KEY[k]["apply"] == "restart"
            and not BY_KEY[k]["secret"]]
    if keys:
        try:
            _ENV_DEFAULTS_BEFORE.update(defaults_in_force(keys))
        except Exception:
            pass                          # shown as before; never fatal
    applied: dict[str, object] = {}
    for key, raw in stored.items():
        if key in LEGACY_SECRET_ENV:
            if str(raw or "").strip():
                set_env_override(key, str(raw))
                applied[key] = "(set)"
                if logger:
                    logger.warning(
                        f"{key} is held in the settings table; move it to "
                        f"the credential store or the environment")
            continue
        spec = BY_KEY.get(key)
        if spec is None or key in FORBIDDEN:
            continue                      # catalogue changed under us
        if spec["secret"] and not str(raw or "").strip():
            continue                      # a blank secret is "not set"
        try:
            value = coerce(spec, raw)
        except ValueError:
            _INVALID_AT_BUILD.add(key)
            _warn_invalid(key, raw, logger)
            continue
        if spec["target"] == "env":
            # The notification stack resolves its own values from named
            # environment variables; writing there keeps ONE precedence
            # chain instead of two.
            _ENV_APPLIED.setdefault(key, os.environ.get(key))
            # Same form as the live settings: "true"/"false" (was
            # "True"/"False"; every reader accepted both).
            os.environ[key] = ("true" if value is True else
                               "false" if value is False else str(value))
        else:
            record = _cfg_record(cfg, create=True)
            record[1].setdefault(key, getattr(cfg, key, None))
            object.__setattr__(cfg, key, value)
            record[2][key] = value
        applied[key] = value

    if applied and logger:
        logger.info(
            f"Applied {len(applied)} administrator setting(s): "
            f"{', '.join(sorted(applied))}")
    return applied


def resolve_tls_conflict(store: SettingsStore, logger=None):
    """STARTTLS and implicit SSL both stored On by an earlier version
    (NB-010): every e-mail used to be switched off without a word. The
    one that does not match the port is switched Off — implicit SSL is
    kept on port 465, STARTTLS on any other — in the store and in the
    environment in force. Returns {"port", "switched_off"} or None when
    there was nothing to resolve. Called right after apply_overrides."""
    stored = store.all()
    try:
        both = all(coerce(BY_KEY[k], stored[k]) is True
                   for k in ("SMTP_USE_STARTTLS", "SMTP_USE_SSL"))
    except (KeyError, ValueError):
        return None
    if not both:
        return None
    try:
        from src.modules.notifications.config import (
            load_notification_config,
        )
        port = int(load_notification_config().smtp_port)
    except Exception:
        port = 587
    off = "SMTP_USE_STARTTLS" if port == 465 else "SMTP_USE_SSL"
    store.set(off, "false", actor="system (upgrade)")
    # The environment the same way apply_overrides writes it, so the
    # value from before the console changed it is still restored later.
    set_env_override(off, "false")
    (logger or logging.getLogger("finesiii_rpa_v3")).warning(
        f"E-mail: STARTTLS and implicit SSL were both On (stored by an "
        f"earlier version); '{BY_KEY[off]['label']}' was switched Off "
        f"(port {port}).")
    return {"port": port, "switched_off": off}
