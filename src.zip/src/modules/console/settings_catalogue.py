"""What an administrator may change from the console, and how.

An explicit ALLOW-LIST, not "every config field". Most of config/base.py
is deployment identity — which database, which terminal driver, where
the evidence lives, the signing key — and letting a UI edit those turns
a misclick into an outage or a security incident. Those stay
environment-only.

Each entry carries what the UI needs to render a safe control and what
the service needs to apply it:

  target  config -> set on the settings object before anything is built
          env    -> written into os.environ, because the consumer
                    (the notification stack) already resolves its own
                    values from named environment variables
  apply   restart -> consumed once at startup, so it takes effect when
                     the service is rebuilt
          hot     -> re-read per use; live immediately
  secret  never returned by the API — write-only, shown as "set"
  cap     a HARD ceiling the UI cannot exceed (see max_attempts)
"""
from __future__ import annotations

APPLY_RESTART = "restart"
APPLY_HOT = "hot"


def _s(key, label, group, kind, target="config", apply=APPLY_RESTART,
       help="", choices=None, minimum=None, maximum=None, cap=None,
       secret=False, show_when=None, disabled_choices=None, scale=None,
       unit="", choice_labels=None):
    """show_when: {"key": other_key, "value": v} — the UI shows this row
    only while that other setting has that value (e.g. PVWA fields only
    for the pvwa API style); `value` may be a list of accepted values.
    Presentation only; the API accepts the key regardless.
    disabled_choices: choices listed but not selectable (shown as "not
    yet available"). scale/unit: the UI shows value/scale in `unit`
    (e.g. seconds stored, minutes shown); bounds stay in stored units."""
    return {
        "key": key, "label": label, "group": group, "kind": kind,
        "target": target, "apply": apply, "help": help,
        "choices": choices, "min": minimum, "max": maximum,
        "cap": cap, "secret": secret, "show_when": show_when,
        "disabled_choices": disabled_choices or [],
        "scale": scale, "unit": unit,
        # Readable names of the choices ({value: text}); the value is
        # what is stored (2026-09-29).
        "choice_labels": choice_labels or {},
    }


# Fields the settings API sends to the UI (everything the UI needs to
# render a control; `target` is internal).
UI_FIELDS = ("key", "label", "group", "kind", "apply", "help", "min", "max",
             "cap", "secret", "choices", "disabled_choices", "show_when",
             "scale", "unit", "choice_labels")


SETTINGS: list[dict] = [
    # ── Retry policy ──
    _s("max_attempts", "Retry attempts", "Retry policy", "int",
       minimum=1, maximum=5, cap=5,
       help="How many times a failed request is retried. Capped at 5: "
            "a login rejection consumes one mainframe attempt per try, "
            "and a real service account locks out."),
    _s("retry_backoff_base_seconds", "Backoff base (s)", "Retry policy",
       "int", minimum=0, maximum=3600),
    _s("retry_backoff_factor", "Backoff factor", "Retry policy", "float",
       minimum=1.0, maximum=10.0),
    _s("retry_max_delay_seconds", "Maximum delay (s)", "Retry policy",
       "int", minimum=0, maximum=86400),

    # ── Dispatcher ──
    _s("dispatcher_enabled", "Process queued work", "Dispatcher", "bool",
       help="Off = the API still accepts requests, but nothing runs "
            "them, after a restart. To stop processing for a while, use "
            "System > Pause processing instead. The clean-up of old "
            "evidence, stored passwords and sessions continues either "
            "way."),
    _s("dispatch_poll_seconds", "Poll interval (s)", "Dispatcher",
       "float", minimum=0.1, maximum=60),
    _s("idle_poll_seconds", "Idle poll interval (s)", "Dispatcher",
       "float", minimum=0.1, maximum=300),
    _s("drain_seconds", "Shutdown drain (s)", "Dispatcher", "int",
       minimum=10, maximum=3600,
       help="How long a shutdown waits for a transaction that is live "
            "on the terminal before giving up."),

    # ── Operating window ──
    _s("availability_window_start", "Window opens (JST)",
       "Operating window", "time"),
    _s("availability_window_end", "Window closes (JST)",
       "Operating window", "time"),
    _s("shutdown_buffer_minutes", "Stop accepting before close (min)",
       "Operating window", "int", minimum=0, maximum=240),
    _s("health_check_enabled", "Probe the mainframe",
       "Operating window", "bool"),
    _s("probe_interval_seconds", "Probe interval (s)",
       "Operating window", "int", minimum=10, maximum=3600),

    # ── Screen reading ──
    _s("ocr_enabled", "Read screens with OCR", "Screen reading", "bool",
       help="Mandatory on real terminal drivers — turning it off there "
            "removes the control that confirms what the bot saw."),
    _s("ocr_min_confidence", "Confidence floor", "Screen reading",
       "float", minimum=0.0, maximum=1.0,
       help="Below this, a read may never assert an error. Raising it "
            "makes the bot more cautious, not more accurate."),
    _s("ocr_capture_text", "Save the screen text beside each screenshot",
       "Screen reading", "bool"),
    # Read once when the terminal executor is built → restart.
    _s("require_readable_confirmation",
       "Stop when the confirmation cannot be read", "Screen reading",
       "bool"),

    # ── Error handling ──
    _s("error_handling_enabled", "Act on recognised error screens",
       "Error handling", "bool"),
    _s("error_max_step_retries", "Transient retry attempts",
       "Error handling", "int", minimum=0, maximum=10),
    _s("error_acknowledge_wait", "Settle after dismissing a dialog (s)",
       "Error handling", "float", minimum=0.0, maximum=30.0),

    # ── Console sign-in ──
    _s("jwt_ttl_seconds", "Sign out after inactivity (s)",
       "Console sign-in", "int", minimum=300, maximum=86400),
    _s("auth_max_session_hours", "Maximum session length (hours)",
       "Console sign-in", "int", minimum=1, maximum=24),
    _s("auth_min_password_length", "Minimum password length",
       "Console sign-in", "int", minimum=8, maximum=64),
    _s("auth_max_failed_attempts", "Failed sign-ins before lockout",
       "Console sign-in", "int", minimum=3, maximum=20),
    _s("auth_lockout_seconds", "Lockout duration (s)",
       "Console sign-in", "int", minimum=60, maximum=86400),
    _s("auth_windows_sso_enabled", "Allow Windows sign-on",
       "Console sign-in", "bool",
       help="Desktop app on Windows only. The route refuses any caller "
            "that is not on this machine, regardless of this setting."),

    # ── Evidence ──
    _s("evidence_retention_days", "Keep evidence for (days)",
       "Evidence", "int", minimum=1, maximum=3650,
       help="Screenshots contain PII, and a provision capture shows "
            "the account password in clear text."),
    # Retention of what else holds personal data (SY-02 / SY-06,
    # 2026-10-03).
    _s("failed_password_retention_days",
       "Keep the password of a failed request for (days)", "Evidence",
       "int", minimum=0, maximum=30,
       help="So the request can be retried with the same password. 0 = "
            "erased when the request fails (Retry is then refused for a "
            "provisioning request that brought its own password)."),
    _s("log_retention_days", "Keep the service log for (days)",
       "Evidence", "int", minimum=1, maximum=365,
       help="One log file per day; older ones are deleted. The log holds "
            "employee and affiliation codes."),

    # ── Email notifications (resolved from the environment by the
    #     notification stack, so the overlay writes there) ──
    _s("SMTP_ALERTS_ENABLED", "Send email alerts", "Email", "bool",
       target="env"),
    _s("SMTP_HOST", "SMTP host", "Email", "str", target="env"),
    _s("SMTP_PORT", "SMTP port", "Email", "int", target="env",
       minimum=1, maximum=65535,
       help="587 with STARTTLS, or 465 with implicit SSL."),
    # Connection security (2026-09-29): one choice instead of the two
    # switches below, which stay for installations that already use them
    # (shown only while no choice is made here).
    _s("SMTP_SECURITY", "Connection security", "Email", "choice",
       target="env",
       choices=["starttls_if_offered", "starttls", "ssl", "none"],
       choice_labels={
           "starttls_if_offered": "STARTTLS if the server offers it",
           "starttls": "STARTTLS required",
           "ssl": "SSL/TLS from the start (port 465)",
           "none": "None (internal relay, not encrypted)"},
       help="STARTTLS if offered: the usual choice for an internal relay "
            "on port 25. STARTTLS required: port 587, or port 25 when the "
            "relay supports it. SSL/TLS: port 465. None: only for an "
            "internal relay that allows this server's address and offers "
            "no encryption. Default: decided by the port (465 SSL/TLS, 25 "
            "STARTTLS if offered, otherwise STARTTLS required)."),
    _s("SMTP_USE_STARTTLS", "Use STARTTLS (port 587)", "Email", "bool",
       target="env",
       show_when={"key": "SMTP_SECURITY", "value": [""]}),
    _s("SMTP_USE_SSL", "Use implicit SSL (port 465)", "Email", "bool",
       target="env", help="Choose STARTTLS or SSL, not both.",
       show_when={"key": "SMTP_SECURITY", "value": [""]}),
    _s("SMTP_VERIFY_CERT", "Check the server certificate", "Email", "bool",
       target="env",
       help="On: the mail server's certificate must be trusted by this "
            "machine and match the host name. Turn off only while the "
            "certificate authority is being added to the server's trusted "
            "certificates; the connection stays encrypted."),
    _s("SMTP_CA_FILE", "Extra trusted certificate file", "Email", "str",
       target="env",
       help="Optional. A PEM file with the organisation's certificate "
            "authority, when it is not in the machine's trusted "
            "certificates. Full path on this machine."),
    _s("SMTP_TIMEOUT", "Connection time-out (s)", "Email", "int",
       target="env", minimum=5, maximum=300),
    _s("SMTP_EHLO_NAME", "Name given to the mail server", "Email", "str",
       target="env",
       help="Optional. The host name this machine gives the mail server "
            "(EHLO). Blank: this machine's own name. Set it when the relay "
            "allows senders by name."),
    _s("SMTP_USERNAME", "SMTP username", "Email", "str", target="env",
       help="Blank for a relay without login (the relay allows this "
            "server's address). A login is only ever sent over an "
            "encrypted connection."),
    # The SMTP password is NOT a console setting: it is kept in the OS
    # credential store (Credentials) or the environment, never in the
    # settings table (BUG-005).
    _s("ALERT_FROM", "From address", "Email", "str", target="env"),
    _s("ALERT_TO", "Default recipients", "Email", "csv", target="env",
       help="Comma-separated. Used for anything without its own "
            "routing rule."),
    _s("ALERT_CC", "Default CC", "Email", "csv", target="env"),
    _s("ERROR_ALERTS_ENABLED", "Per-error notices", "Email", "bool",
       target="env",
       help="Route a failed transaction to the team that owns THAT "
            "error (the routing rules of the notification configuration)."),
    _s("ERROR_ALERT_TO", "Error-alert recipients", "Email", "csv",
       target="env",
       help="Comma-separated. Receives the per-error notices "
            "(centre not ready, login rejected, and so on)."),
    _s("ERROR_ALERT_CC", "Error-alert CC", "Email", "csv", target="env"),
    _s("TXN_NOTIFICATIONS_ENABLED", "Transaction outcome emails", "Email",
       "bool", target="env",
       help="Success / failure / rejection notices to operations."),
    _s("TXN_SEND_USER_CREDENTIALS", "Registration notice to the new user",
       "Email", "bool", target="env",
       show_when={"key": "TXN_NOTIFICATIONS_ENABLED", "value": "true"},
       help="SailPoint tickets: the new-registration notice (client "
            "template, without the password). Other requests: the "
            "account-created e-mail."),
    _s("TXN_INCLUDE_PASSWORD", "Send the initial password to the new "
       "user", "Email", "bool", target="env",
       show_when={"key": "TXN_NOTIFICATIONS_ENABLED", "value": "true"},
       help="SailPoint tickets: a SEPARATE e-mail with the initial password "
            "(the process design's password notice), sent even while the "
            "registration notice above is Off. Other requests: only "
            "together with the registration notice. OFF by default — turn "
            "on with the security team's agreement."),
    _s("SUPPORT_REPORT_ENABLED", "Support report per SailPoint ticket",
       "Email", "bool", target="env", apply=APPLY_HOT,
       show_when={"key": "TXN_NOTIFICATIONS_ENABLED", "value": "true"},
       help="FINESIIIアカウント登録報告 — once per ticket when all its "
            "affiliation codes are finished."),
    _s("SUPPORT_REPORT_TO", "Support report recipients", "Email", "csv",
       target="env", apply=APPLY_HOT,
       show_when={"key": "SUPPORT_REPORT_ENABLED", "value": ["true", ""]},
       help="Comma-separated. Blank = the default recipients above."),
    _s("SUPPORT_REPORT_CC", "Support report CC", "Email", "csv",
       target="env", apply=APPLY_HOT,
       show_when={"key": "SUPPORT_REPORT_ENABLED", "value": ["true", ""]}),
    _s("SNOW_REQUESTER_SOURCE", "Requester (申請者) shown in the support "
       "report", "Email", "choice", target="env", apply=APPLY_HOT,
       choices=["opened_by", "requested_for", "none"],
       help="Taken from the ServiceNow request: the person who opened it "
            "(default), the person it was requested for, or not shown."),
    _s("EMAIL_CONTACT_ADDRESS", "Contact address shown in user e-mails",
       "Email", "str", target="env", apply=APPLY_HOT,
       help="Printed in the registration and password notices for "
            "questions. It is not the sender."),

    # ── E-mail content and delivery (2026-09-29) ──
    _s("EMAIL_LANGUAGE", "E-mail language", "Email", "choice",
       target="env", apply=APPLY_HOT, choices=["ja_en", "ja", "en"],
       choice_labels={"ja_en": "Japanese and English",
                      "ja": "Japanese only", "en": "English only"},
       help="The language of the e-mails the service writes (alerts, "
            "notices, reports). The client's own templates keep their "
            "wording. Default: Japanese and English in the same e-mail."),
    _s("EMAIL_ENVIRONMENT_LABEL", "Environment name shown in e-mails",
       "Email", "str", target="env", apply=APPLY_HOT,
       help="Shown in every subject, for example UAT or PRODUCTION. "
            "Blank: the service's environment."),
    _s("EMAIL_DIGEST", "Alert summary e-mail", "Email", "choice",
       target="env", choices=["daily", "hourly", "off"],
       choice_labels={"daily": "Daily", "hourly": "Hourly", "off": "Off"},
       help="A summary of the alerts since the last summary, to the "
            "default recipients. Each alert is also e-mailed when it "
            "happens."),
    _s("EMAIL_DIGEST_TIME", "Daily summary time (JST)", "Email", "time",
       target="env",
       show_when={"key": "EMAIL_DIGEST", "value": ["daily", ""]}),
    _s("EMAIL_OUTBOX_HOURS", "Keep resending failed e-mails for (hours)",
       "Email", "int", target="env", minimum=0, maximum=168,
       help="An e-mail the mail server did not accept is kept and resent "
            "every 5 minutes for this long, also after a restart. 0: not "
            "kept. The password notice is never kept."),
    _s("EMAIL_SERVICE_NOTICES", "E-mail when the service starts or stops",
       "Email", "bool", target="env",
       help="A start with problems is always e-mailed."),

    # ── Recipients by system (2026-09-29): the team that owns a system
    #    receives its notices, together with the default recipients ──
    _s("AUDIENCE_SERVICENOW_TO", "ServiceNow team", "Email", "csv",
       target="env", apply=APPLY_HOT,
       help="ServiceNow polling outages and recovery, ticket update "
            "failures. Several addresses: separate them with commas or "
            "semicolons."),
    _s("AUDIENCE_SERVICENOW_CC", "ServiceNow team CC", "Email", "csv",
       target="env", apply=APPLY_HOT),
    _s("AUDIENCE_CYBERARK_TO", "CyberArk / identity team", "Email", "csv",
       target="env", apply=APPLY_HOT,
       help="CyberArk outages and recovery, and the service-account "
            "password rejected by FINESIII."),
    _s("AUDIENCE_CYBERARK_CC", "CyberArk / identity team CC", "Email",
       "csv", target="env", apply=APPLY_HOT),
    _s("AUDIENCE_FINESIII_TO", "FINESIII / mainframe team", "Email", "csv",
       target="env", apply=APPLY_HOT,
       help="FINESIII unavailable and recovered, and the centre not "
            "ready."),
    _s("AUDIENCE_FINESIII_CC", "FINESIII / mainframe team CC", "Email",
       "csv", target="env", apply=APPLY_HOT),
    _s("AUDIENCE_ACCOUNTS_TO", "FINESIII account administration", "Email",
       "csv", target="env", apply=APPLY_HOT,
       help="Operator code not registered (affiliation / staff code "
            "problems)."),
    _s("AUDIENCE_ACCOUNTS_CC", "FINESIII account administration CC",
       "Email", "csv", target="env", apply=APPLY_HOT),
    _s("AUDIENCE_DATABASE_TO", "Database team", "Email", "csv",
       target="env", apply=APPLY_HOT,
       help="Database (AWS RDS) not reachable, and recovered."),
    _s("AUDIENCE_DATABASE_CC", "Database team CC", "Email", "csv",
       target="env", apply=APPLY_HOT),

    # ── ServiceNow (the connector runs inside the desktop agent; on a
    #     server it is scripts/run_servicenow_connector.py) ──
    _s("SNOW_ENABLED", "Poll ServiceNow for tickets", "ServiceNow", "bool",
       target="env", apply=APPLY_HOT,
       help="The agent fetches tickets assigned to the bot account and "
            "queues them. Off = tickets are submitted some other way."),
    _s("SNOW_INSTANCE_URL", "Instance URL", "ServiceNow", "str",
       target="env", apply=APPLY_HOT,
       help="https://<instance>.service-now.com"),
    _s("SNOW_AUTH_METHOD", "Authentication", "ServiceNow", "choice",
       target="env", apply=APPLY_HOT,
       choices=["basic", "oauth_password", "oauth_client_credentials"],
       help="basic = the bot account's username and password. "
            "oauth_password = OAuth with the bot account (client ID and "
            "secret plus username and password). oauth_client_credentials "
            "= OAuth client credentials only (Washington DC or later, "
            "grant enabled on the instance, application user mapped)."),
    _s("SNOW_USERNAME", "Username", "ServiceNow", "str", target="env",
       apply=APPLY_HOT,
       show_when={"key": "SNOW_AUTH_METHOD",
                  "value": ["basic", "oauth_password", ""]},
       help="The password is kept in the OS credential vault."),
    _s("SNOW_CLIENT_ID", "OAuth client ID", "ServiceNow", "str",
       target="env", apply=APPLY_HOT,
       show_when={"key": "SNOW_AUTH_METHOD",
                  "value": ["oauth_password", "oauth_client_credentials"]},
       help="From the OAuth application registry on the instance. The "
            "client secret is kept in the OS credential vault."),
    _s("SNOW_TOKEN_URL", "OAuth token URL", "ServiceNow", "str",
       target="env", apply=APPLY_HOT,
       show_when={"key": "SNOW_AUTH_METHOD",
                  "value": ["oauth_password", "oauth_client_credentials"]},
       help="Blank = <instance URL>/oauth_token.do."),
    _s("SNOW_TABLE", "Ticket table", "ServiceNow", "str", target="env",
       apply=APPLY_HOT, help="e.g. sc_task"),
    _s("SNOW_ASSIGNMENT_MODE", "Match tickets by", "ServiceNow", "choice",
       target="env", apply=APPLY_HOT,
       choices=["assigned_to", "assignment_group"]),
    # Ticket filters: each one optional. A filled-in value is applied,
    # an empty one adds no condition (shown in both modes).
    _s("SNOW_ASSIGNED_TO", "Bot account (sys_id, user name or name)",
       "ServiceNow", "str", target="env", apply=APPLY_HOT,
       help="Filled in: only tickets assigned to this account (Match "
            "tickets by assigned_to), or tickets that are unassigned or "
            "assigned to it (assignment_group). Empty: no filter on who "
            "the ticket is assigned to. Tickets are assigned to this "
            "account, or to the ServiceNow username when empty, before "
            "they are queued; a ticket a person has taken is left "
            "alone."),
    _s("SNOW_ASSIGNMENT_GROUP", "Assignment group (sys_id or name)",
       "ServiceNow", "str", target="env", apply=APPLY_HOT,
       help="Filled in: only tickets of this group. Empty: tickets of "
            "every group."),
    _s("SNOW_REQUESTED_FOR", "Requested For (sys_id or name)",
       "ServiceNow", "csv", target="env", apply=APPLY_HOT,
       help="Filled in: only tickets requested for this user, for "
            "example the account that raises the access requests. "
            "Empty: no filter. Several users separated by commas, or by "
            "; when a name contains a comma (e.g. Admin, Sample;). "
            "Checked by the bot on each ticket; Test connection shows "
            "the values the tickets hold."),
    _s("SNOW_REQUESTED_FOR_FIELD", "Requested For field", "ServiceNow",
       "str", target="env", apply=APPLY_HOT,
       help="Where the ticket holds Requested For, e.g. "
            "request.requested_for. Empty: the bot reads the task's, "
            "its request's and its requested item's Requested For, and "
            "any of them may match."),
    _s("SNOW_REQUIRE_APPROVAL", "Only approved requests", "ServiceNow",
       "bool", target="env", apply=APPLY_HOT,
       help="Pick up a ticket only when its request is approved."),
    _s("SNOW_APPROVAL_FILTER", "Approval condition", "ServiceNow", "str",
       target="env", apply=APPLY_HOT,
       show_when={"key": "SNOW_REQUIRE_APPROVAL", "value": ["true", ""]},
       help="One condition, field=value. Catalog task: "
            "request_item.approval=approved."),
    _s("SNOW_OPEN_STATES", "Open states", "ServiceNow", "csv",
       target="env", apply=APPLY_HOT,
       help="Raw state values counted as open, comma-separated. Blank = "
            "every ticket ServiceNow still treats as active (recommended)."),
    _s("SNOW_POLL_SECONDS", "Poll interval (minutes)", "ServiceNow", "int",
       target="env", apply=APPLY_HOT, minimum=60, maximum=86400,
       scale=60, unit="minutes",
       help="How often tickets are fetched. Default 30 minutes. Saving "
            "applies at once."),
    _s("SNOW_DUPLICATE_WINDOW_DAYS", "Duplicate check window (days)",
       "ServiceNow", "int", target="env", apply=APPLY_HOT, minimum=0,
       maximum=365,
       help="A ticket asking for the same operation, affiliation and "
            "employee as a request queued or completed within this many "
            "days is not queued again. 0 = the same-request check is "
            "off; a newer ticket is never undone and a repeated Access "
            "Request ID is always held."),
    _s("SNOW_WRITEBACK_ENABLED", "Add a work note when a ticket is queued "
       "or found to be a duplicate", "ServiceNow", "bool", target="env",
       apply=APPLY_HOT),
    _s("SNOW_CLOSE_ON_SUCCESS", "Close the ticket after a successful "
       "provisioning or deprovisioning", "ServiceNow", "bool",
       target="env", apply=APPLY_HOT),
    _s("SNOW_CLOSE_STATE", "Closing state value", "ServiceNow", "str",
       target="env", apply=APPLY_HOT,
       show_when={"key": "SNOW_CLOSE_ON_SUCCESS", "value": ["true", ""]},
       help="Raw state value written on close. sc_task: 3 = Closed "
            "Complete."),
    _s("SNOW_CLOSE_COMMENT_PROVISION", "Closing comment (provisioning)",
       "ServiceNow", "template", target="env", apply=APPLY_HOT,
       show_when={"key": "SNOW_CLOSE_ON_SUCCESS", "value": ["true", ""]},
       help="Placeholders: {ticket_id} {affiliation_code} {employee_code} "
            "{result_code} {completed_at} {request_id}."),
    _s("SNOW_CLOSE_COMMENT_DEPROVISION", "Closing comment (deprovisioning)",
       "ServiceNow", "template", target="env", apply=APPLY_HOT,
       show_when={"key": "SNOW_CLOSE_ON_SUCCESS", "value": ["true", ""]},
       help="Same placeholders."),
    _s("SNOW_REVIEW_NOTE_ENABLED", "Work note when the account was "
       "already deleted (ticket stays open)", "ServiceNow", "bool",
       target="env", apply=APPLY_HOT),
    _s("SNOW_REVIEW_NOTE", "Review note text", "ServiceNow", "template",
       target="env", apply=APPLY_HOT,
       show_when={"key": "SNOW_REVIEW_NOTE_ENABLED", "value": ["true", ""]},
       help="e.g. Human review required … Same placeholders."),
    _s("SNOW_FAILURE_NOTE_ENABLED", "Work note when the request failed "
       "(ticket stays open)", "ServiceNow", "bool", target="env",
       apply=APPLY_HOT),
    _s("SNOW_FAILURE_NOTE", "Failure note text", "ServiceNow", "template",
       target="env", apply=APPLY_HOT,
       show_when={"key": "SNOW_FAILURE_NOTE_ENABLED", "value": ["true", ""]},
       help="Placeholders as above plus {attempts} and {error}."),

    _s("SNOW_UNCONFIRMED_NOTE", "Note when the result could not be "
       "confirmed (ticket stays open)", "ServiceNow", "template",
       target="env", apply=APPLY_HOT,
       show_when={"key": "SNOW_REVIEW_NOTE_ENABLED", "value": ["true", ""]},
       help="Written instead of closing when the bot submitted the "
            "change but could not read the result. Same placeholders."),
    _s("SNOW_CANCEL_NOTE_ENABLED", "Work note when a request is "
       "cancelled (ticket stays open)", "ServiceNow", "bool",
       target="env", apply=APPLY_HOT),
    _s("SNOW_CANCEL_NOTE", "Cancel note text", "ServiceNow", "template",
       target="env", apply=APPLY_HOT,
       show_when={"key": "SNOW_CANCEL_NOTE_ENABLED", "value": ["true", ""]},
       help="Same placeholders."),
    _s("SNOW_REJECT_REASSIGN_GROUP", "Hand rejected tickets to group",
       "ServiceNow", "str", target="env", apply=APPLY_HOT,
       help="Assignment group (sys_id or name) that receives a ticket "
            "the bot cannot process (missing data or duplicate). Blank "
            "= the ticket stays assigned to the bot."),
    _s("SNOW_REJECT_NOTE_ENABLED", "Work note on a ticket the bot "
       "rejects (ticket stays open)", "ServiceNow", "bool", target="env",
       apply=APPLY_HOT),
    _s("SNOW_REJECT_NOTE", "Rejection note text", "ServiceNow", "template",
       target="env", apply=APPLY_HOT,
       show_when={"key": "SNOW_REJECT_NOTE_ENABLED", "value": ["true", ""]},
       help="Placeholders: {reason} {ticket_id}."),

    # ── SailPoint catalog tasks (2026-09-28) ──
    _s("SNOW_TICKET_FORMAT", "Ticket format", "ServiceNow", "choice",
       target="env", apply=APPLY_HOT, choices=["sailpoint", "fields"],
       help="sailpoint = SailPoint 'IAM Access Request' catalog tasks "
            "(instruction text and account in the catalog variables). "
            "fields = one request per ticket in separate ticket fields "
            "(the field mapping of the ServiceNow configuration)."),
    _s("SNOW_VAR_TEXT", "Variable: instruction text", "ServiceNow", "csv",
       target="env", apply=APPLY_HOT,
       show_when={"key": "SNOW_TICKET_FORMAT", "value": ["sailpoint", ""]},
       help="Label (as shown on the form) or internal name of the catalog "
            "variable; several alternatives comma-separated."),
    _s("SNOW_VAR_ACCOUNT", "Variable: account (FINESIII employee code)",
       "ServiceNow", "csv", target="env", apply=APPLY_HOT,
       show_when={"key": "SNOW_TICKET_FORMAT", "value": ["sailpoint", ""]}),
    _s("SNOW_VAR_EMPLOYEE_ID", "Variable: employee ID (recorded)",
       "ServiceNow", "csv", target="env", apply=APPLY_HOT,
       show_when={"key": "SNOW_TICKET_FORMAT", "value": ["sailpoint", ""]}),
    _s("SNOW_VAR_EMPLOYEE", "Variable: employee name (recorded)",
       "ServiceNow", "csv", target="env", apply=APPLY_HOT,
       show_when={"key": "SNOW_TICKET_FORMAT", "value": ["sailpoint", ""]}),
    _s("SNOW_VAR_INSTANCE", "Variable: instance", "ServiceNow", "csv",
       target="env", apply=APPLY_HOT,
       show_when={"key": "SNOW_TICKET_FORMAT", "value": ["sailpoint", ""]}),
    _s("SNOW_VAR_APPLICATION", "Variable: application", "ServiceNow",
       "csv", target="env", apply=APPLY_HOT,
       show_when={"key": "SNOW_TICKET_FORMAT", "value": ["sailpoint", ""]}),
    _s("SNOW_VAR_REQUEST_TYPE", "Variable: request type", "ServiceNow",
       "csv", target="env", apply=APPLY_HOT,
       show_when={"key": "SNOW_TICKET_FORMAT", "value": ["sailpoint", ""]}),
    _s("SNOW_APPLICATION_IDS", "Accepted application IDs", "ServiceNow",
       "csv", target="env", apply=APPLY_HOT,
       show_when={"key": "SNOW_TICKET_FORMAT", "value": ["sailpoint", ""]},
       help="The ticket must name one of these, e.g. [1234], in the "
            "application variable or the task description; a ticket for "
            "another application is skipped without a note. Empty or * "
            "= no check."),
    _s("SNOW_ACCEPTED_INSTANCES", "Accepted instances", "ServiceNow", "csv",
       target="env", apply=APPLY_HOT,
       show_when={"key": "SNOW_TICKET_FORMAT", "value": ["sailpoint", ""]},
       help="A filled-in Instance must be one of these; an empty one is "
            "accepted. Empty or * = no check."),
    _s("SNOW_AFFILIATION_ATTRIBUTES", "Affiliation attribute names",
       "ServiceNow", "csv", target="env", apply=APPLY_HOT,
       show_when={"key": "SNOW_TICKET_FORMAT", "value": ["sailpoint", ""]},
       help="AttributeName values that carry the FINESIII affiliation "
            "code (default 所属コード)."),
    _s("SNOW_TASK_TEXT_FIELDS", "Task field: instruction text",
       "ServiceNow", "csv", target="env", apply=APPLY_HOT,
       show_when={"key": "SNOW_TICKET_FORMAT", "value": ["sailpoint", ""]},
       help="Task field(s) that hold the instruction text when the "
            "catalog variable is empty or cannot be read; internal "
            "names, comma-separated. Empty: found automatically (the "
            "task field whose text carries the instruction)."),
    _s("SNOW_SAILPOINT_CHECKS", "Ticket checks", "ServiceNow", "choice",
       target="env", apply=APPLY_HOT, choices=["strict", "minimal"],
       show_when={"key": "SNOW_TICKET_FORMAT", "value": ["sailpoint", ""]},
       help="strict: every check. minimal (for testing): only what a run "
            "needs - the application, the instruction, the attribute, a "
            "known operation, the affiliation code, the account and one "
            "direction; the instance, the account variable, the Request "
            "Type and the removal-only rule are not checked."),
    _s("SNOW_WORDS_PROVISION", "Words meaning provisioning", "ServiceNow",
       "csv", target="env", apply=APPLY_HOT,
       help="Comma-separated, not case-sensitive (e.g. Add, Create)."),
    _s("SNOW_WORDS_DEPROVISION", "Words meaning deprovisioning",
       "ServiceNow", "csv", target="env", apply=APPLY_HOT,
       help="e.g. Remove, Delete, Termination."),
    _s("SNOW_WORDS_CERTIFICATION", "Words meaning a certification "
       "(always a removal)", "ServiceNow", "csv", target="env",
       apply=APPLY_HOT,
       help="e.g. Certification, Revoke. A certification never "
            "provisions."),
    _s("SNOW_TYPE_TERMINATION", "Words marking a Termination",
       "ServiceNow", "csv", target="env", apply=APPLY_HOT,
       show_when={"key": "SNOW_TICKET_FORMAT", "value": ["sailpoint", ""]},
       help="Found in the instruction text, Request Type or short "
            "description. A Termination removes every code listed."),
    _s("SNOW_TYPE_TRANSFER", "Words marking a Transfer", "ServiceNow",
       "csv", target="env", apply=APPLY_HOT,
       show_when={"key": "SNOW_TICKET_FORMAT", "value": ["sailpoint", ""]},
       help="A Transfer removes the codes listed."),
    _s("SNOW_TYPE_ACCOUNT_CERT", "Words marking an Account Certification",
       "ServiceNow", "csv", target="env", apply=APPLY_HOT,
       show_when={"key": "SNOW_TICKET_FORMAT", "value": ["sailpoint", ""]},
       help="Other certifications are Entitlement Certifications (words "
            "above). Both only remove."),
    _s("SNOW_USER_LOOKUP_FIELD", "User field holding the Employee ID",
       "ServiceNow", "str", target="env", apply=APPLY_HOT,
       show_when={"key": "SNOW_TICKET_FORMAT", "value": ["sailpoint", ""]},
       help="ServiceNow user field used to find the user's e-mail address "
            "from the ticket's Employee ID (default employee_number)."),
    _s("SNOW_CLAIM_ON_PICKUP", "Claim the task on pickup (assign to the "
       "bot, set the state below)", "ServiceNow", "bool", target="env",
       apply=APPLY_HOT),
    _s("SNOW_CLAIM_STATE", "State set on pickup", "ServiceNow", "str",
       target="env", apply=APPLY_HOT,
       show_when={"key": "SNOW_CLAIM_ON_PICKUP", "value": ["true", ""]},
       help="Raw state value. sc_task: 2 = Work in Progress. Blank = "
            "assign only."),
    _s("SNOW_CLOSE_COMMENT_CERTIFICATION", "Closing comment "
       "(certification)", "ServiceNow", "template", target="env",
       apply=APPLY_HOT,
       show_when={"key": "SNOW_CLOSE_ON_SUCCESS", "value": ["true", ""]},
       help="Same placeholders as the other closing comments, plus "
            "{category} and {tracking_id}."),

    # ── Bot-generated initial passwords (2026-09-28) ──
    _s("password_symbols", "Symbols used in generated passwords",
       "Provisioning password", "str",
       help="8 characters, a letter first, uppercase letters and digits "
            "plus these symbols (at least one digit and one symbol). Only "
            "@ # $ & * - _ = ! ? . are used. Never the same password "
            "twice."),
    _s("password_exclude_lookalikes", "Leave out look-alike characters "
       "(O 0 I 1)", "Provisioning password", "bool"),

    # ── CyberArk (mainframe service-account password source) ──
    _s("CYBERARK_ENABLED", "Fetch the mainframe password from CyberArk",
       "CyberArk", "bool", target="env",
       help="Required in production with a real terminal driver."),
    _s("CYBERARK_API_STYLE", "API", "CyberArk", "choice", target="env",
       choices=["ccp", "pvwa"],
       help="ccp = Central Credential Provider (recommended for bots); "
            "pvwa = PVWA REST with a service account."),
    _s("CYBERARK_BASE_URL", "Base URL", "CyberArk", "str", target="env",
       help="https://cyberark.corp.example.com"),
    _s("CYBERARK_VERIFY_TLS", "Verify TLS certificate", "CyberArk", "bool",
       target="env", help="Turn off only in non-production."),
    _s("CYBERARK_APP_ID", "Application ID", "CyberArk", "str",
       target="env"),
    _s("CYBERARK_SAFE", "Safe", "CyberArk", "str", target="env"),
    _s("CYBERARK_OBJECT", "Account object name", "CyberArk", "str",
       target="env", help="Either this or the account username below."),
    _s("CYBERARK_ACCOUNT_USERNAME", "Account username", "CyberArk", "str",
       target="env"),
    _s("CYBERARK_CERT_PATH", "Client certificate (mutual TLS)", "CyberArk",
       "str", target="env",
       show_when={"key": "CYBERARK_API_STYLE", "value": "ccp"}),
    _s("CYBERARK_KEY_PATH", "Client private key", "CyberArk", "str",
       target="env",
       show_when={"key": "CYBERARK_API_STYLE", "value": "ccp"}),
    _s("CYBERARK_PVWA_USER", "PVWA username", "CyberArk", "str",
       target="env",
       show_when={"key": "CYBERARK_API_STYLE", "value": "pvwa"},
       help="The PVWA password is kept in the OS credential vault."),
    _s("CYBERARK_PVWA_AUTH_TYPE", "PVWA authentication", "CyberArk",
       "choice", target="env", choices=["CyberArk", "LDAP", "RADIUS"],
       show_when={"key": "CYBERARK_API_STYLE", "value": "pvwa"}),
    _s("CYBERARK_REFRESH_HOURS", "Refresh every (hours)", "CyberArk",
       "float", target="env", minimum=0.25, maximum=24.0),
    _s("CYBERARK_HEALTH_CHECK", "Check the vault is active before each "
       "fetch", "CyberArk", "bool", target="env"),

    # ── FINESIII terminal application (Windows worker) ──
    _s("FINESIII_APP_SHORTCUT_PATH", "Launcher shortcut",
       "FINESIII terminal", "str", target="env",
       help="The Windows shortcut that starts the FINESIII terminal "
            "program, for example the オンライン業務 shortcut on the "
            "public desktop. Enter its full location on this machine."),
    _s("FINESIII_APP_EXECUTABLE", "Terminal program (instead of the "
       "shortcut)", "FINESIII terminal", "str", target="env"),
    _s("FINESIII_APP_WINDOW_TITLE", "Menu window title contains",
       "FINESIII terminal", "str", target="env",
       help="Default 基幹業務."),
    _s("FINESIII_APP_WINDOW_CLASS", "Terminal window class",
       "FINESIII terminal", "str", target="env",
       help="Default F3BJMD101 (Fujitsu terminal)."),
    # Started as administrator, as with right-click > Run as administrator
    # (CFG-04, 2026-10-04): it was only in layouts.yaml.
    _s("FINESIII_APP_RUN_AS_ADMIN", "Start the terminal as administrator",
       "FINESIII terminal", "bool", target="env",
       help="On (default): the terminal program is started as "
            "administrator, which needs the service itself to run as "
            "administrator (scheduled task with highest privileges). Off: "
            "it is opened normally, for a terminal that does not need "
            "administrator rights."),
]

BY_KEY = {s["key"]: s for s in SETTINGS}
GROUPS = []
for _s_ in SETTINGS:
    if _s_["group"] not in GROUPS:
        GROUPS.append(_s_["group"])

SECRET_KEYS = {s["key"] for s in SETTINGS if s["secret"]}
MASK = "•••••"

# Address settings, checked address by address when saved (2026-09-28):
# a stray header or second recipient can never be stored.
EMAIL_LIST_KEYS = {"ALERT_TO", "ALERT_CC", "ERROR_ALERT_TO", "ERROR_ALERT_CC",
                   "SUPPORT_REPORT_TO", "SUPPORT_REPORT_CC",
                   "AUDIENCE_SERVICENOW_TO", "AUDIENCE_SERVICENOW_CC",
                   "AUDIENCE_CYBERARK_TO", "AUDIENCE_CYBERARK_CC",
                   "AUDIENCE_FINESIII_TO", "AUDIENCE_FINESIII_CC",
                   "AUDIENCE_ACCOUNTS_TO", "AUDIENCE_ACCOUNTS_CC",
                   "AUDIENCE_DATABASE_TO", "AUDIENCE_DATABASE_CC"}
EMAIL_KEYS = {"ALERT_FROM", "EMAIL_CONTACT_ADDRESS"}
# Lists where '*' alone means "no check".
NO_CHECK_KEYS = {"SNOW_APPLICATION_IDS", "SNOW_ACCEPTED_INSTANCES",
                 "SNOW_REQUESTED_FOR"}
# Checks that an emptied field switches off: saved as '*', so the
# shipped value does not come back in its place.
BLANK_IS_NO_CHECK = {"SNOW_APPLICATION_IDS", "SNOW_ACCEPTED_INSTANCES"}
NO_CHECK = "*"
# Addresses the service signs in to with a stored secret: https and a
# plain host (2026-10-03). Value: whether a path is allowed.
WEB_ADDRESS_KEYS = {"SNOW_INSTANCE_URL": False, "SNOW_TOKEN_URL": True,
                    "CYBERARK_BASE_URL": True}
# Values placed in the ServiceNow ticket query as they are (SN-01).
# The ServiceNow username is one of them: with the Bot account blank,
# the query looks for tickets assigned to the username (UAT-03,
# 2026-10-04).
QUERY_VALUE_KEYS = {"SNOW_ASSIGNED_TO", "SNOW_ASSIGNMENT_GROUP",
                    "SNOW_REJECT_REASSIGN_GROUP", "SNOW_USERNAME"}
# Files that must exist on this machine when they are saved (CA-01).
FILE_KEYS = {"CYBERARK_CERT_PATH", "CYBERARK_KEY_PATH", "SMTP_CA_FILE"}


def _check_address(spec: dict, text: str) -> None:
    """Raise ValueError unless `text` is one e-mail address. The From
    address may also carry a display name ("Bot <bot@example.com>")."""
    from src.modules.notifications.notifier import valid_address
    if valid_address(text):
        return
    if spec["key"] == "ALERT_FROM" and text.count("<") == 1 \
            and text.endswith(">") and text.count(">") == 1:
        from email.utils import parseaddr
        name, addr = parseaddr(text)
        if addr and valid_address(addr) and text[:-1].endswith(addr) \
                and not any(c in name for c in ",;\r\n"):
            return
    raise ValueError(f"{spec['label']}: '{text}' is not an e-mail address")


def _bound_text(spec: dict, bound) -> str:
    """A bound in the unit the UI shows (e.g. 60 s stored → "1 minutes")."""
    scale = spec.get("scale") or 1
    if scale == 1:
        return str(bound)
    shown = bound / scale
    shown = int(shown) if float(shown).is_integer() else round(shown, 2)
    unit = spec.get("unit") or ""
    if shown == 1 and unit.endswith("s"):
        unit = unit[:-1]                    # "1 minute", not "1 minutes"
    return f"{shown} {unit}".strip()


def coerce(spec: dict, raw):
    """Turn a submitted value into its typed form, or raise ValueError.

    Every bound in the catalogue is enforced HERE, server-side. The UI
    renders the same limits, but a UI is not a control.
    """
    kind = spec["kind"]
    if kind == "bool":
        if isinstance(raw, bool):
            return raw
        text = str(raw).strip().lower()
        if text in ("1", "true", "yes", "on"):
            return True
        if text in ("0", "false", "no", "off", ""):
            return False
        # "maybe" used to be stored as Off without a word (CFG-02).
        raise ValueError(f"{spec['label']} must be on or off")
    if kind in ("int", "float"):
        try:
            number = float(raw)
        except (TypeError, ValueError):
            raise ValueError(f"{spec['label']} must be a number")
        # A whole-number setting given 1.5 is refused, not stored as 1
        # (UAT-L28, 2026-10-04).
        if kind == "int" and not number.is_integer():
            raise ValueError(f"{spec['label']} must be a whole number")
        value = int(number) if kind == "int" else number
        cap = spec.get("cap")
        if cap is not None and value > cap:
            raise ValueError(
                f"{spec['label']} cannot exceed {_bound_text(spec, cap)} — "
                f"see the note on this setting")
        if spec.get("min") is not None and value < spec["min"]:
            raise ValueError(
                f"{spec['label']} must be at least "
                f"{_bound_text(spec, spec['min'])}")
        if spec.get("max") is not None and value > spec["max"]:
            raise ValueError(
                f"{spec['label']} must be at most "
                f"{_bound_text(spec, spec['max'])}")
        return value
    if kind == "time":
        text = str(raw).strip()
        parts = text.split(":")
        if len(parts) != 2 or not all(p.isdigit() for p in parts) \
                or not (0 <= int(parts[0]) <= 23) \
                or not (0 <= int(parts[1]) <= 59):
            raise ValueError(
                f"{spec['label']} must be HH:MM (24-hour)")
        return f"{int(parts[0]):02d}:{int(parts[1]):02d}"
    if kind == "csv":
        # A line break inside a list value (e-mail recipients, ServiceNow
        # query values) could smuggle a header or a condition in
        # (2026-09-28): refused like in every other text setting.
        items = raw if isinstance(raw, (list, tuple)) else [raw]
        if any("\n" in str(x) or "\r" in str(x) for x in items):
            raise ValueError(f"{spec['label']} must be a single line")
        if spec["key"] == "SNOW_REQUESTED_FOR" and not isinstance(
                raw, (list, tuple)) and ";" in str(raw):
            # ';' separates users whose names contain a comma (S-04,
            # 2026-10-04). Stored with ';' so the comma stays in the name.
            parts = [p.strip() for p in str(raw).split(";") if p.strip()]
            for part in parts:
                if any(c in part for c in "^="):
                    raise ValueError(f"{spec['label']}: '{part}' — a "
                                     f"sys_id or a name, without ^ or =")
            if "*" in parts and len(parts) > 1:
                raise ValueError(f"{spec['label']}: * (no check) must be "
                                 f"the only value")
            joined = "; ".join(parts)
            return joined + (";" if len(parts) == 1 and "," in joined
                             else "")
        if isinstance(raw, (list, tuple)):
            parts = [str(x).strip() for x in raw if str(x).strip()]
        else:
            text = str(raw)
            # Address lists also take Outlook's semicolons (2026-09-29).
            if spec["key"] in EMAIL_LIST_KEYS:
                text = text.replace(";", ",")
            parts = [p.strip() for p in text.split(",") if p.strip()]
        if spec["key"] in EMAIL_LIST_KEYS:
            for part in parts:
                _check_address(spec, part)
        if spec["key"] == "SNOW_REQUESTED_FOR":
            for part in parts:
                if any(c in part for c in "^="):
                    raise ValueError(f"{spec['label']}: '{part}' — a "
                                     f"sys_id or a name, without ^ or =")
        if spec["key"] == "SNOW_TASK_TEXT_FIELDS":
            import re as _re
            for part in parts:
                if not _re.match(r"^[A-Za-z0-9_.]+$", part):
                    raise ValueError(f"{spec['label']}: '{part}' — a field "
                                     f"name such as description")
        if spec["key"] == "SNOW_OPEN_STATES":
            # Part of the ticket query (SN-01): plain state values only.
            import re as _re
            for part in parts:
                if not _re.match(r"^-?[A-Za-z0-9_]+$", part):
                    raise ValueError(f"{spec['label']}: '{part}' — a state "
                                     f"value such as 1 or -5")
        if spec["key"] in NO_CHECK_KEYS and "*" in parts and len(parts) > 1:
            raise ValueError(f"{spec['label']}: * (no check) must be the "
                             f"only value")
        return ",".join(parts)
    if kind == "choice":
        text = str(raw).strip()
        match = next((c for c in (spec.get("choices") or [])
                      if c.lower() == text.lower()), None)
        if match is None:
            raise ValueError(
                f"{spec['label']} must be one of: "
                f"{', '.join(spec.get('choices') or [])}")
        if match in (spec.get("disabled_choices") or []):
            raise ValueError(
                f"{spec['label']}: '{match}' is not yet available")
        return match
    text = str(raw).strip()
    if "\n" in text or "\r" in text:
        raise ValueError(f"{spec['label']} must be a single line")
    if spec["key"] in WEB_ADDRESS_KEYS:
        # The service signs in to these addresses with the stored
        # password or secret (X-07, CA-01).
        from src.core.urls import web_address_problem
        problem = web_address_problem(
            text, path_allowed=WEB_ADDRESS_KEYS[spec["key"]])
        if problem:
            raise ValueError(f"{spec['label']} {problem}")
    if spec["key"] in QUERY_VALUE_KEYS and any(c in text for c in "^="):
        # Part of the ticket query (SN-01): "^NQ..." would add tickets.
        raise ValueError(f"{spec['label']}: '{text}' — a sys_id or a name, "
                         f"without ^ or =")
    if spec["key"] == "SNOW_TABLE" and text:
        import re as _re
        if not _re.match(r"^[A-Za-z0-9_]+$", text):
            raise ValueError(f"{spec['label']}: a table name such as sc_task")
    if spec["key"] in ("SNOW_APPROVAL_FILTER", "SNOW_USER_LOOKUP_FIELD",
                       "SNOW_REQUESTED_FOR_FIELD"):
        import re as _re
        pattern = (r"^[A-Za-z0-9_.]+=[A-Za-z0-9_ -]+$"
                   if spec["key"] == "SNOW_APPROVAL_FILTER"
                   else r"^[A-Za-z0-9_.]+$")
        if text and not _re.match(pattern, text):
            raise ValueError(
                f"{spec['label']}: " + (
                    "one condition such as request_item.approval=approved"
                    if spec["key"] == "SNOW_APPROVAL_FILTER"
                    else "a field name such as request_item.requested_for"
                    if spec["key"] == "SNOW_REQUESTED_FOR_FIELD"
                    else "a field name such as employee_number"))
    if spec["key"] == "password_symbols":
        from src.modules.intake.passwords import SAFE_SYMBOLS
        bad = sorted({c for c in text if c not in SAFE_SYMBOLS})
        if bad:
            raise ValueError(
                f"{spec['label']}: '{''.join(bad)}' cannot be typed safely "
                f"on the terminal — use only {' '.join(SAFE_SYMBOLS)}")
    if spec["key"] in EMAIL_KEYS and text:
        _check_address(spec, text)
    if kind == "template":
        # Checked when SAVED so a stray brace never reaches a ticket.
        from src.integrations.servicenow.writeback import template_problem
        problem = template_problem(text)
        if problem:
            raise ValueError(f"{spec['label']}: {problem}")
    return text


# ── Defaults in force when a setting is NOT set ──
# Several env-target settings have their real default in a YAML file or
# a settings class (close-out switches ON, STARTTLS ON, 30-minute
# polling…). The settings API used to return blank for them, which the
# UI showed as Off / empty while the opposite was in force (SN-04,
# UI-STARTTLS). These are read from the SAME loaders the consumers use,
# so what the page shows is what runs.
DEFAULT_SOURCES = {
    "FINESIII_APP_RUN_AS_ADMIN": ("terminal", "run_as_admin"),
    "SNOW_AUTH_METHOD": ("servicenow", "auth_method"),
    "SNOW_TABLE": ("servicenow", "table"),
    "SNOW_ASSIGNMENT_MODE": ("servicenow", "assignment_mode"),
    "SNOW_OPEN_STATES": ("servicenow", "open_states"),
    "SNOW_POLL_SECONDS": ("servicenow", "poll_interval_seconds"),
    "SNOW_DUPLICATE_WINDOW_DAYS": ("servicenow", "duplicate_window_days"),
    "SNOW_WRITEBACK_ENABLED": ("servicenow", "writeback_enabled"),
    "SNOW_CLOSE_ON_SUCCESS": ("servicenow", "close_on_success"),
    "SNOW_CLOSE_STATE": ("servicenow", "close_state"),
    "SNOW_CLOSE_COMMENT_PROVISION": ("servicenow", "close_comment_provision"),
    "SNOW_CLOSE_COMMENT_DEPROVISION": ("servicenow",
                                       "close_comment_deprovision"),
    "SNOW_REVIEW_NOTE_ENABLED": ("servicenow", "review_note_enabled"),
    "SNOW_REVIEW_NOTE": ("servicenow", "review_note"),
    "SNOW_FAILURE_NOTE_ENABLED": ("servicenow", "failure_note_enabled"),
    "SNOW_FAILURE_NOTE": ("servicenow", "failure_note"),
    "SNOW_UNCONFIRMED_NOTE": ("servicenow", "unconfirmed_note"),
    "SNOW_CANCEL_NOTE_ENABLED": ("servicenow", "cancel_note_enabled"),
    "SNOW_CANCEL_NOTE": ("servicenow", "cancel_note"),
    "SNOW_REJECT_REASSIGN_GROUP": ("servicenow", "reject_reassign_group"),
    "SNOW_ASSIGNMENT_GROUP": ("servicenow", "assignment_group"),
    "SNOW_REQUESTED_FOR": ("servicenow", "requested_for"),
    "SNOW_REQUESTED_FOR_FIELD": ("servicenow", "requested_for_field"),
    "SNOW_REQUIRE_APPROVAL": ("servicenow", "require_approval"),
    "SNOW_APPROVAL_FILTER": ("servicenow", "approval_filter"),
    "SNOW_TYPE_TERMINATION": ("servicenow", "request_type_words.termination"),
    "SNOW_TYPE_TRANSFER": ("servicenow", "request_type_words.transfer"),
    "SNOW_TYPE_ACCOUNT_CERT": ("servicenow",
                               "request_type_words.account_certification"),
    "SNOW_USER_LOOKUP_FIELD": ("servicenow", "user_lookup_field"),
    "SNOW_REQUESTER_SOURCE": ("servicenow", "requester_source"),
    "SUPPORT_REPORT_ENABLED": ("ticket_reports", "report_enabled"),
    "EMAIL_CONTACT_ADDRESS": ("ticket_reports", "contact_email"),
    "SNOW_REJECT_NOTE_ENABLED": ("servicenow", "reject_note_enabled"),
    "SNOW_REJECT_NOTE": ("servicenow", "reject_note"),
    "SNOW_TICKET_FORMAT": ("servicenow", "ticket_format"),
    "SNOW_VAR_TEXT": ("servicenow", "sp_variables.text"),
    "SNOW_VAR_ACCOUNT": ("servicenow", "sp_variables.account"),
    "SNOW_VAR_EMPLOYEE_ID": ("servicenow", "sp_variables.employee_id"),
    "SNOW_VAR_EMPLOYEE": ("servicenow", "sp_variables.employee"),
    "SNOW_VAR_INSTANCE": ("servicenow", "sp_variables.instance"),
    "SNOW_VAR_APPLICATION": ("servicenow", "sp_variables.application"),
    "SNOW_VAR_REQUEST_TYPE": ("servicenow", "sp_variables.request_type"),
    "SNOW_APPLICATION_IDS": ("servicenow", "sp_application_ids"),
    "SNOW_ACCEPTED_INSTANCES": ("servicenow", "sp_accepted_instances"),
    "SNOW_AFFILIATION_ATTRIBUTES": ("servicenow", "sp_affiliation_attributes"),
    "SNOW_TASK_TEXT_FIELDS": ("servicenow", "task_text_fields"),
    "SNOW_SAILPOINT_CHECKS": ("servicenow", "sp_checks"),
    "SNOW_WORDS_PROVISION": ("servicenow", "operation_words.provision"),
    "SNOW_WORDS_DEPROVISION": ("servicenow", "operation_words.deprovision"),
    "SNOW_WORDS_CERTIFICATION": ("servicenow",
                                 "operation_words.certification"),
    "SNOW_CLAIM_ON_PICKUP": ("servicenow", "claim_on_pickup"),
    "SNOW_CLAIM_STATE": ("servicenow", "claim_state"),
    "SNOW_CLOSE_COMMENT_CERTIFICATION": ("servicenow",
                                         "close_comment_certification"),
    "SMTP_ALERTS_ENABLED": ("email", "enabled"),
    "SMTP_PORT": ("email", "smtp_port"),
    "SMTP_USE_STARTTLS": ("email", "use_starttls"),
    "SMTP_USE_SSL": ("email", "use_ssl"),
    "SMTP_VERIFY_CERT": ("email", "verify_tls"),
    "SMTP_TIMEOUT": ("email", "timeout_seconds"),
    "EMAIL_DIGEST": ("email", "digest_schedule"),
    "EMAIL_DIGEST_TIME": ("email", "digest_time"),
    "EMAIL_OUTBOX_HOURS": ("email", "outbox_hours"),
    "EMAIL_SERVICE_NOTICES": ("email", "service_notices"),
    "TXN_NOTIFICATIONS_ENABLED": ("transactions", "enabled"),
    "TXN_SEND_USER_CREDENTIALS": ("transactions", "send_user_credentials"),
    "TXN_INCLUDE_PASSWORD": ("transactions", "include_password"),
    "CYBERARK_ENABLED": ("cyberark", "enabled"),
    "CYBERARK_API_STYLE": ("cyberark", "api_style"),
    "CYBERARK_VERIFY_TLS": ("cyberark", "verify_tls"),
    "CYBERARK_PVWA_AUTH_TYPE": ("cyberark", "pvwa_auth_type"),
    "CYBERARK_REFRESH_HOURS": ("cyberark", "refresh_interval_hours"),
    "CYBERARK_HEALTH_CHECK": ("cyberark", "health_check_enabled"),
}


def _load_default_source(name: str):
    if name == "servicenow":
        from src.integrations.servicenow.config import load_servicenow_config
        return load_servicenow_config()
    if name == "email":
        from src.modules.notifications.config import load_notification_config
        return load_notification_config()
    if name == "transactions":
        from src.modules.notifications.transaction_alerts import (
            load_transaction_notification_config,
        )
        return load_transaction_notification_config()
    if name == "ticket_reports":
        from src.modules.notifications.ticket_reports import (
            load_ticket_report_config,
        )
        return load_ticket_report_config()
    if name == "cyberark":
        from src.integrations.cyberark.config import load_cyberark_config
        return load_cyberark_config()
    if name == "terminal":
        from types import SimpleNamespace
        from src.rpa.config import effective_application
        return SimpleNamespace(**effective_application())
    raise KeyError(name)


def defaults_in_force(unset_keys) -> dict:
    """{key: text} for the given UNSET keys that have a known default.
    Never raises: a source that cannot be loaded simply yields nothing."""
    out, loaded = {}, {}
    for key in unset_keys:
        source = DEFAULT_SOURCES.get(key)
        if source is None:
            continue
        name, attr = source
        if name not in loaded:
            try:
                loaded[name] = _load_default_source(name)
            except Exception:
                loaded[name] = None
        obj = loaded[name]
        # "attr.key" reads one entry of a dict attribute (2026-09-28).
        attr, _, sub = attr.partition(".")
        if obj is None or not hasattr(obj, attr):
            continue
        value = getattr(obj, attr)
        if sub:
            value = value.get(sub) if isinstance(value, dict) else None
        if isinstance(value, bool):
            out[key] = "true" if value else "false"
        elif isinstance(value, (list, tuple)):
            out[key] = ",".join(str(v) for v in value)
        elif value is not None:
            # A whole-number setting whose default is held as a decimal
            # (SMTP_TIMEOUT 30.0, EMAIL_OUTBOX_HOURS 24.0) is shown as
            # "30": "30.0" failed its own check, and Save refused every
            # change on a fresh installation (UAT-01, 2026-10-04).
            spec = BY_KEY.get(key)
            if spec and spec["kind"] == "int" \
                    and isinstance(value, float) and value.is_integer():
                value = int(value)
            out[key] = str(value)
    return out
