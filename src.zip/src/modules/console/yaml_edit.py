"""Set one field on one rule in errors.yaml WITHOUT rewriting the file.

config/errors.yaml is the reviewed record of what the bot does: 116 of
its 208 lines are comments carrying the client's decisions per case —
which screenshot a rule came from, why a retry is safe, why a rule was
renamed. Round-tripping it through yaml.safe_dump() silently deletes
every one of them.

So the toggle edits the TEXT: it locates the rule's block, changes or
inserts a single `enabled:` line, and leaves every other byte alone.
"""
from __future__ import annotations

import os
import re
import sys
import tempfile
import threading
import time
from pathlib import Path

# "  - id: SOMETHING"  — the start of a rule block in the errors list.
_RULE_START = re.compile(r"^(\s*)-\s+id:\s*(\S+)\s*$")
_ENABLED = re.compile(r"^(\s*)enabled:\s*\S+\s*$")


# One toggle at a time: two concurrent read-modify-write cycles would
# otherwise each start from the same text and one change would be lost.
_FILE_LOCK = threading.Lock()
_REPLACE_ATTEMPTS = 10
_REPLACE_PAUSE_SECONDS = 0.05


class RuleNotFound(Exception):
    pass


class CatalogInvalid(Exception):
    """The edited text would not load; nothing was written (UR-10)."""


def set_rule_enabled(text: str, rule_id: str, enabled: bool) -> str:
    """Return `text` with rule_id's `enabled:` set. Raises RuleNotFound.

    Comments, ordering, quoting and every other rule are untouched.
    """
    lines = text.splitlines(keepends=True)
    start = indent = None

    for i, line in enumerate(lines):
        m = _RULE_START.match(line.rstrip("\n"))
        if m and m.group(2) == rule_id:
            start, indent = i, m.group(1)
            break
    if start is None:
        raise RuleNotFound(f"No rule with id {rule_id!r}")

    # The block runs until the next rule at the SAME indent, or EOF.
    end = len(lines)
    for j in range(start + 1, len(lines)):
        m = _RULE_START.match(lines[j].rstrip("\n"))
        if m and m.group(1) == indent:
            end = j
            break

    value = "true" if enabled else "false"
    # Field indent: two past the dash, matching "- id:" -> "  id:".
    field_indent = indent + "  "

    for j in range(start + 1, end):
        m = _ENABLED.match(lines[j].rstrip("\n"))
        # Only the rule's OWN flag, at the rule's field indent — never an
        # "enabled:" of a nested block inside the rule (UR-10).
        if m and m.group(1) == field_indent:
            newline = "\n" if lines[j].endswith("\n") else ""
            lines[j] = f"{field_indent}enabled: {value}{newline}"
            return "".join(lines)

    # No `enabled:` yet — insert it immediately after the id line, so
    # it reads next to the rule's identity rather than at the end of a
    # long block.
    lines.insert(start + 1, f"{field_indent}enabled: {value}\n")
    return "".join(lines)


def _replace(source: str, target: Path) -> None:
    """os.replace, retried briefly on Windows, where a reader holding
    the file open (the bot loads the catalogue per transaction) makes
    the rename fail with PermissionError for a moment."""
    for attempt in range(_REPLACE_ATTEMPTS):
        try:
            os.replace(source, target)
            return
        except PermissionError:
            if sys.platform != "win32" or attempt == _REPLACE_ATTEMPTS - 1:
                raise
            time.sleep(_REPLACE_PAUSE_SECONDS)


def write_text_atomic(path, text: str) -> None:
    """Write `text` to `path` so a reader sees the old file or the new
    one, never a half-written one: a temporary file in the same folder,
    flushed to disk, then renamed over the original. Text mode exactly
    as Path.write_text, so the bytes written are the same. On any
    failure the original is left as it was and the temporary file is
    removed."""
    target = Path(path)
    fd, tmp = tempfile.mkstemp(prefix=f".{target.name}.",
                               suffix=".tmp", dir=str(target.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(text)
            fh.flush()
            os.fsync(fh.fileno())
        try:
            # Keep the original's permissions (mkstemp creates 0600).
            os.chmod(tmp, os.stat(target).st_mode & 0o7777)
        except OSError:
            pass
        _replace(tmp, target)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def toggle_rule_file(path, rule_id: str, enabled: bool,
                     validate=None, on_original=None) -> str:
    """Set rule_id's `enabled:` in the catalogue FILE and return the
    new text. Read, edit and write happen under one lock and the write
    is atomic. Raises RuleNotFound (file untouched) or OSError.

    validate: optional check of the new text, returning a problem ('' =
    none); with a problem nothing is written and CatalogInvalid is
    raised (UR-10, 2026-10-03).

    on_original: optional callable given the file text as read under the
    lock, before the change (UAT-12, 2026-10-04)."""
    target = Path(path)
    with _FILE_LOCK:
        original = target.read_text(encoding="utf-8")
        if on_original is not None:
            on_original(original)
        updated = set_rule_enabled(original, rule_id, bool(enabled))
        if validate is not None:
            problem = validate(updated)
            if problem:
                raise CatalogInvalid(problem)
        write_text_atomic(target, updated)
    return updated
