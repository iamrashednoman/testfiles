"""Console settings: sections and tooltips (2026-09-28).

Presentation only. Every setting on the Settings page — the console
catalogue, the machine's deployment keys and the stored credentials —
has a section (where it sits on the page) and a tooltip (what it does,
in plain language). A setting whose catalogue entry already carries help
text keeps it; the texts here cover the rest. Nothing here changes what
a setting does or how it is validated.
"""
from __future__ import annotations

# Sections inside the larger groups. A setting not listed here sits at
# the top level of its group.
SECTIONS: dict[str, str] = {}


def _section(name: str, *keys: str) -> None:
    for key in keys:
        SECTIONS[key] = name


_section("Connection", "SNOW_ENABLED", "SNOW_INSTANCE_URL",
         "SNOW_AUTH_METHOD", "SNOW_USERNAME", "SNOW_CLIENT_ID",
         "SNOW_TOKEN_URL", "SNOW_TABLE")
_section("Ticket selection", "SNOW_ASSIGNMENT_MODE", "SNOW_ASSIGNED_TO",
         "SNOW_ASSIGNMENT_GROUP", "SNOW_REQUESTED_FOR",
         "SNOW_REQUESTED_FOR_FIELD", "SNOW_REQUIRE_APPROVAL",
         "SNOW_APPROVAL_FILTER", "SNOW_OPEN_STATES", "SNOW_POLL_SECONDS",
         "SNOW_DUPLICATE_WINDOW_DAYS", "SNOW_CLAIM_ON_PICKUP",
         "SNOW_CLAIM_STATE")
_section("SailPoint tickets", "SNOW_TICKET_FORMAT", "SNOW_VAR_TEXT",
         "SNOW_VAR_ACCOUNT", "SNOW_VAR_EMPLOYEE_ID", "SNOW_VAR_EMPLOYEE",
         "SNOW_VAR_INSTANCE", "SNOW_VAR_APPLICATION",
         "SNOW_VAR_REQUEST_TYPE", "SNOW_APPLICATION_IDS",
         "SNOW_ACCEPTED_INSTANCES", "SNOW_AFFILIATION_ATTRIBUTES",
         "SNOW_TASK_TEXT_FIELDS", "SNOW_SAILPOINT_CHECKS",
         "SNOW_USER_LOOKUP_FIELD")
_section("Request types", "SNOW_WORDS_PROVISION", "SNOW_WORDS_DEPROVISION",
         "SNOW_WORDS_CERTIFICATION", "SNOW_TYPE_TERMINATION",
         "SNOW_TYPE_TRANSFER", "SNOW_TYPE_ACCOUNT_CERT")
_section("Ticket updates", "SNOW_WRITEBACK_ENABLED", "SNOW_CLOSE_ON_SUCCESS",
         "SNOW_CLOSE_STATE", "SNOW_CLOSE_COMMENT_PROVISION",
         "SNOW_CLOSE_COMMENT_DEPROVISION", "SNOW_CLOSE_COMMENT_CERTIFICATION",
         "SNOW_REVIEW_NOTE_ENABLED", "SNOW_REVIEW_NOTE",
         "SNOW_FAILURE_NOTE_ENABLED", "SNOW_FAILURE_NOTE",
         "SNOW_UNCONFIRMED_NOTE", "SNOW_CANCEL_NOTE_ENABLED",
         "SNOW_CANCEL_NOTE", "SNOW_REJECT_REASSIGN_GROUP",
         "SNOW_REJECT_NOTE_ENABLED", "SNOW_REJECT_NOTE")
_section("Mail server", "SMTP_ALERTS_ENABLED", "SMTP_HOST", "SMTP_PORT",
         "SMTP_SECURITY", "SMTP_USE_STARTTLS", "SMTP_USE_SSL",
         "SMTP_VERIFY_CERT", "SMTP_CA_FILE", "SMTP_TIMEOUT",
         "SMTP_EHLO_NAME", "SMTP_USERNAME", "ALERT_FROM")
_section("Recipients and alerts", "ALERT_TO", "ALERT_CC",
         "ERROR_ALERTS_ENABLED", "ERROR_ALERT_TO", "ERROR_ALERT_CC",
         "TXN_NOTIFICATIONS_ENABLED")
_section("Recipients by system", "AUDIENCE_SERVICENOW_TO",
         "AUDIENCE_SERVICENOW_CC", "AUDIENCE_CYBERARK_TO",
         "AUDIENCE_CYBERARK_CC", "AUDIENCE_FINESIII_TO",
         "AUDIENCE_FINESIII_CC", "AUDIENCE_ACCOUNTS_TO",
         "AUDIENCE_ACCOUNTS_CC", "AUDIENCE_DATABASE_TO",
         "AUDIENCE_DATABASE_CC")
_section("Content and delivery", "EMAIL_LANGUAGE", "EMAIL_ENVIRONMENT_LABEL",
         "EMAIL_DIGEST", "EMAIL_DIGEST_TIME", "EMAIL_OUTBOX_HOURS",
         "EMAIL_SERVICE_NOTICES")
_section("SailPoint ticket e-mails", "TXN_SEND_USER_CREDENTIALS",
         "TXN_INCLUDE_PASSWORD", "SUPPORT_REPORT_ENABLED",
         "SUPPORT_REPORT_TO", "SUPPORT_REPORT_CC", "SNOW_REQUESTER_SOURCE",
         "EMAIL_CONTACT_ADDRESS")
_section("Connection", "CYBERARK_ENABLED", "CYBERARK_API_STYLE",
         "CYBERARK_BASE_URL", "CYBERARK_VERIFY_TLS", "CYBERARK_CERT_PATH",
         "CYBERARK_KEY_PATH")
_section("Account", "CYBERARK_APP_ID", "CYBERARK_SAFE", "CYBERARK_OBJECT",
         "CYBERARK_ACCOUNT_USERNAME")
_section("PVWA sign-in", "CYBERARK_PVWA_USER", "CYBERARK_PVWA_AUTH_TYPE")
_section("Schedule", "CYBERARK_REFRESH_HOURS", "CYBERARK_HEALTH_CHECK")
_section("Confirmation screen", "require_readable_confirmation")

# Tooltips for entries without catalogue help text.
TOOLTIPS: dict[str, str] = {
    # Retry policy
    "retry_backoff_base_seconds":
        "The wait before the first retry of a failed request, in seconds. "
        "Each later retry waits longer (see the backoff factor).",
    "retry_backoff_factor":
        "How much longer each retry waits than the previous one. 2 doubles "
        "the wait each time.",
    "retry_max_delay_seconds":
        "The longest wait between two retries, in seconds, however many "
        "retries have happened.",
    # Dispatcher
    "dispatch_poll_seconds":
        "How often the service checks the queue for new work while it is "
        "busy, in seconds.",
    "idle_poll_seconds":
        "How often the service checks the queue when nothing is waiting, "
        "in seconds. A longer interval means less load on the database.",
    # Operating window
    "availability_window_start":
        "The time (Japan time) from which requests are processed on the "
        "mainframe. Requests received earlier wait in the queue.",
    "availability_window_end":
        "The time (Japan time) at which processing stops for the day. It "
        "must be later than the opening time on the same day.",
    "shutdown_buffer_minutes":
        "No new transaction starts this many minutes before the window "
        "closes, so work in progress can finish in time.",
    "health_check_enabled":
        "Checks regularly that the mainframe can be reached, and pauses "
        "processing while it cannot.",
    "probe_interval_seconds":
        "How often the mainframe check runs, in seconds.",
    # Screen reading
    "ocr_capture_text":
        "Saves the text read from each screen next to its screenshot, so "
        "reviewers can search and copy it.",
    "require_readable_confirmation":
        "When on, the bot cancels a transaction (99) instead of committing "
        "it (70) if the confirmation screen cannot be read to check the "
        "employee code. Off keeps the current behaviour. Switch on only "
        "after screen reading of the confirmation screen has been "
        "confirmed on the real terminal.",
    # Error handling
    "error_handling_enabled":
        "Recognises known error screens from the error rules and follows "
        "their exit steps instead of failing on an unknown screen.",
    "error_max_step_retries":
        "How many times a step is tried again after a temporary error "
        "screen before the request is treated as failed.",
    "error_acknowledge_wait":
        "The pause after closing an error dialog before the next step, in "
        "seconds, so the terminal can settle.",
    # Console sign-in
    "jwt_ttl_seconds":
        "A console with no keyboard or mouse activity for this long, in "
        "seconds, is signed out. A minute before, it asks \"Still "
        "there?\". Default 1800 (30 minutes). Automatic page refreshes "
        "do not count as activity.",
    "auth_max_session_hours":
        "However active, a console session ends this many hours after "
        "the sign-in and the person signs in again. Default 12.",
    "auth_min_password_length":
        "The minimum length of a console password.",
    "auth_max_failed_attempts":
        "Failed sign-ins in a row before the account is locked for a "
        "while.",
    "auth_lockout_seconds":
        "How long a locked account stays locked, in seconds.",
    # E-mail
    "SMTP_ALERTS_ENABLED":
        "The master switch for every e-mail the service sends. Off = no "
        "e-mail of any kind.",
    "SMTP_HOST":
        "The mail server that sends the e-mails, for example "
        "smtp.example.com.",
    "SMTP_USE_STARTTLS":
        "Encrypts the connection to the mail server after connecting "
        "(usually port 587).",
    "SMTP_USERNAME":
        "The account used to sign in to the mail server. Leave blank if "
        "the server does not require sign-in.",
    "ALERT_FROM":
        "The sender address shown on every e-mail.",
    "ALERT_CC":
        "Addresses copied on the general alerts, comma-separated.",
    "ERROR_ALERT_CC":
        "Addresses copied on the per-error notices, comma-separated.",
    "SUPPORT_REPORT_CC":
        "Addresses copied on the support report, comma-separated.",
    "SMTP_TIMEOUT":
        "How long the service waits for the mail server before a send "
        "attempt fails, in seconds.",
    "EMAIL_DIGEST_TIME":
        "When the daily alert summary is sent, Japan time (24-hour).",
    "AUDIENCE_SERVICENOW_CC":
        "Addresses copied on the ServiceNow notices; commas or semicolons.",
    "AUDIENCE_CYBERARK_CC":
        "Addresses copied on the CyberArk and service-account notices; "
        "commas or semicolons.",
    "AUDIENCE_FINESIII_CC":
        "Addresses copied on the FINESIII and mainframe notices; commas "
        "or semicolons.",
    "AUDIENCE_ACCOUNTS_CC":
        "Addresses copied on the account administration notices; commas "
        "or semicolons.",
    "AUDIENCE_DATABASE_CC":
        "Addresses copied on the database notices; commas or semicolons.",
    # ServiceNow
    "SNOW_ASSIGNMENT_MODE":
        "How the Bot account filters tickets when it is filled in: "
        "assigned_to = only tickets already assigned to it; "
        "assignment_group = tickets that are unassigned or assigned to "
        "it (use this when tickets arrive unassigned in a group).",
    "SNOW_ASSIGNMENT_GROUP":
        "Filled in: only tickets of this group (sys_id or name). Empty: "
        "every group. Tickets assigned to another person are left "
        "alone. Each ticket is assigned to the bot account before it is "
        "queued.",
    "SNOW_WRITEBACK_ENABLED":
        "Adds a work note to the ticket when it is queued, or when it is "
        "found to repeat an earlier request.",
    "SNOW_CLOSE_ON_SUCCESS":
        "Closes the ticket with the closing comment once every part of "
        "the request has succeeded.",
    "SNOW_REVIEW_NOTE_ENABLED":
        "Adds the review note when the account to remove no longer "
        "exists. The ticket stays open for a person to check.",
    "SNOW_FAILURE_NOTE_ENABLED":
        "Adds the failure note when a request fails after all attempts. "
        "The ticket stays open.",
    "SNOW_CANCEL_NOTE_ENABLED":
        "Adds the cancel note when a queued request is cancelled from "
        "the console. The ticket stays open.",
    "SNOW_REJECT_NOTE_ENABLED":
        "Adds the rejection note when a ticket cannot be processed (for "
        "example missing data). The ticket stays open.",
    "SNOW_VAR_ACCOUNT":
        "The catalog variable holding the FINESIII employee code, by its "
        "label or internal name. Alternatives comma-separated.",
    "SNOW_VAR_EMPLOYEE_ID":
        "The catalog variable holding the employee ID. Recorded with the "
        "request and used to find the user's e-mail address.",
    "SNOW_VAR_EMPLOYEE":
        "The catalog variable holding the employee's name. Recorded with "
        "the request and shown in the support report.",
    "SNOW_VAR_INSTANCE":
        "The catalog variable holding the target instance, checked "
        "against the accepted instances.",
    "SNOW_VAR_APPLICATION":
        "The catalog variable naming the application, checked against "
        "the accepted application IDs.",
    "SNOW_VAR_REQUEST_TYPE":
        "The catalog variable holding the request type (for example "
        "Termination or Transfer).",
    "SNOW_CLAIM_ON_PICKUP":
        "When the bot picks up a task it assigns the task to itself and "
        "sets the state below, so others can see it is being worked on. "
        "When matching by group the task is always assigned to the bot "
        "before it is queued; this switch then only sets the state.",
    # Provisioning password
    "password_exclude_lookalikes":
        "Leaves out characters that are easy to confuse (O and 0, I and "
        "1) from generated passwords.",
    # CyberArk
    "CYBERARK_APP_ID":
        "The application ID registered for the bot in CyberArk.",
    "CYBERARK_SAFE":
        "The CyberArk safe that holds the mainframe service account.",
    "CYBERARK_ACCOUNT_USERNAME":
        "The user name of the account in the safe. Use this or the "
        "account object name.",
    "CYBERARK_CERT_PATH":
        "The client certificate used to identify the bot to CyberArk "
        "(mutual TLS), if the vault requires one.",
    "CYBERARK_KEY_PATH":
        "The private key that belongs to the client certificate.",
    "CYBERARK_PVWA_AUTH_TYPE":
        "How the PVWA service account signs in: CyberArk, LDAP or "
        "RADIUS.",
    "CYBERARK_REFRESH_HOURS":
        "How often the password is fetched again from CyberArk, in hours. "
        "It is also fetched at once if the mainframe rejects it.",
    "CYBERARK_HEALTH_CHECK":
        "Confirms the vault answers before each fetch, so an outage is "
        "reported clearly.",
    # FINESIII terminal
    "FINESIII_APP_EXECUTABLE":
        "The terminal program to start, when it is started directly "
        "rather than through the launcher shortcut.",
    # Deployment keys (this machine)
    "MAINFRAME_PORT":
        "The mainframe port used by the reachability check.",
    "API_PORT":
        "The port the service listens on. The console uses the same "
        "port.",
    "LOG_LEVEL":
        "How much detail the service log records. INFO is recommended; "
        "DEBUG only while investigating.",
    "DATABASE_ENGINE":
        "The database that holds the queue and history. PostgreSQL is "
        "required in production.",
    "AUDIT_ENABLED":
        "Records every action of the service and its users in the audit "
        "trail. Must stay on in production.",
    "AUDIT_BACKEND":
        "The database that holds the audit trail.",
    "AUDIT_DATABASE_URL":
        "The connection to the audit database. The password is kept in "
        "the credential vault.",
    "AUTH_ENABLED":
        "Machine callers (other systems) must present the API key.",
    "EVIDENCE_DIR":
        "Where screenshots and screen text are stored on this machine.",
    "LOG_DIR":
        "Where the service log files are stored on this machine.",
}

# Stored credentials (write-only).
SECRET_TOOLTIPS: dict[str, str] = {
    "DATABASE_PASSWORD":
        "The password for the main database account.",
    "AUDIT_DATABASE_PASSWORD":
        "The password for the audit database account.",
    "SMTP_PASSWORD":
        "The password for the mail server account.",
    "SNOW_PASSWORD":
        "The password of the ServiceNow bot account.",
    "SNOW_CLIENT_SECRET":
        "The OAuth client secret registered on the ServiceNow instance.",
    "CYBERARK_PVWA_PASSWORD":
        "The password of the PVWA service account.",
    "FINESIII_AFFILIATION_CODE":
        "The affiliation code of the mainframe service account.",
    "FINESIII_APPLICATION_ID":
        "The staff code of the mainframe service account.",
    "FINESIII_PASSWORD":
        "The mainframe service account password, when it is not fetched "
        "from CyberArk.",
    "FINESIII_API_KEYS":
        "The keys other systems (for example the ServiceNow connector) "
        "present to submit requests.",
    "JWT_SECRET":
        "The key that signs console sign-in sessions. Changing it signs "
        "everyone out.",
    "AUTH_DEFAULT_ADMIN_PASSWORD":
        "The first administrator's provisional password, set at "
        "installation. It must be changed at first sign-in. Once the "
        "administrator has chosen their own password, this value is "
        "removed from the credential store automatically (at the latest "
        "at the next start of the service).",
}


def tooltip(key: str, help_text: str = "") -> str:
    """The catalogue's own help first, else the text above."""
    return (help_text or "").strip() or TOOLTIPS.get(key, "") \
        or SECRET_TOOLTIPS.get(key, "")


def section(key: str) -> str:
    return SECTIONS.get(key, "")
