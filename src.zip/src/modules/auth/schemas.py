"""Request/response contracts for the console auth API.

Mirrors src/modules/intake/schemas.py: pydantic models at the edge,
validation errors surfaced as 400 with an actionable message.
"""
from __future__ import annotations

import re

from pydantic import BaseModel, ConfigDict, Field, field_validator

# Plain methods on a model (validate_role below) must be recognised as
# methods, not fields. pydantic ignores Python functions by default; in a
# natively compiled build (packaging/compile.py) a method is a Cython
# function type instead, which pydantic would otherwise treat as a
# non-annotated field. `type(lambda: 0)` is whichever of the two this
# module was built as, so this is correct in both cases.
_METHOD_TYPES = (type(lambda: 0),)


class _Model(BaseModel):
    model_config = ConfigDict(ignored_types=_METHOD_TYPES)


# Names checked when an account or role is created (UR-12, 2026-10-03):
# trimmed and lower-cased as they are stored, then letters, digits and
# . _ - only — no blank names, no look-alike characters, nothing that
# breaks the address of the edit and delete routes ("/").
_USERNAME_RE = re.compile(r"^[a-z0-9][a-z0-9._-]{2,63}$")
_ROLE_NAME_RE = re.compile(r"^[a-z0-9][a-z0-9_-]{1,39}$")
_EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def _username(value: str) -> str:
    value = (value or "").strip().lower()
    if not _USERNAME_RE.match(value):
        raise ValueError("a username has 3 to 64 characters: letters a-z, "
                         "digits and . _ - (starting with a letter or "
                         "digit)")
    return value


# DOMAIN\user, as Windows reports the signed-in account (UAT-L16,
# 2026-10-04): no spaces, no further backslash or slash.
_WINDOWS_ACCOUNT_RE = re.compile(r"^[^\\/\s]+\\[^\\/\s]+$")


def _windows_account(value):
    if value is None:
        return value
    value = value.strip()
    if value and not _WINDOWS_ACCOUNT_RE.match(value):
        raise ValueError("a Windows account in the form DOMAIN\\user")
    return value


def _trim(value):
    """Leading and trailing spaces removed; a name of spaces only is
    stored empty (UAT-L16)."""
    return value if value is None else value.strip()


def _email(value):
    if value is None:
        return value
    value = value.strip()
    if value and not _EMAIL_RE.match(value):
        raise ValueError("not an e-mail address")
    return value


class LoginRequest(BaseModel):
    username: str = Field(min_length=1, max_length=64)
    password: str = Field(min_length=1, max_length=256)


class BootstrapRequest(BaseModel):
    """Creating the FIRST administrator on a fresh install."""
    username: str = Field(min_length=3, max_length=64)
    password: str = Field(min_length=1, max_length=256)
    display_name: str = Field(default="", max_length=128)

    _check_username = field_validator("username")(_username)


class PasswordChangeRequest(BaseModel):
    current_password: str = Field(min_length=1, max_length=256)
    new_password: str = Field(min_length=1, max_length=256)


class CreateUserRequest(_Model):
    username: str = Field(min_length=3, max_length=64)
    password: str = Field(default="", max_length=256)
    display_name: str = Field(default="", max_length=128)
    email: str = Field(default="", max_length=200)
    role: str = Field(default="viewer")
    # Set to sign in with the Windows account instead of a password
    # (DOMAIN\\user). Desktop + Windows only.
    windows_account: str = Field(default="", max_length=200)

    _check_username = field_validator("username")(_username)
    _check_email = field_validator("email")(_email)
    _check_windows = field_validator("windows_account")(_windows_account)

    @field_validator("role", "display_name")
    @classmethod
    def _trimmed(cls, value: str) -> str:
        return (value or "").strip()

    def validate_role(self, known_roles=None) -> str | None:
        """known_roles comes from the roles table, so a custom role is
        accepted and a typo is not."""
        if known_roles is not None and self.role not in known_roles:
            return (f"role must be one of "
                    f"{', '.join(sorted(known_roles))} "
                    f"(got '{self.role}')")
        if not self.password and not self.windows_account:
            return ("a password or a windows_account is required — an "
                    "account with neither could never sign in")
        return None


class UpdateUserRequest(_Model):
    display_name: str | None = Field(default=None, max_length=128)
    email: str | None = Field(default=None, max_length=200)
    role: str | None = None
    is_active: bool | None = None
    windows_account: str | None = Field(default=None, max_length=200)
    # Admin-set password (forces a change at next sign-in).
    password: str | None = Field(default=None, max_length=256)

    _check_email = field_validator("email")(_email)
    _check_windows = field_validator("windows_account")(_windows_account)
    _check_name = field_validator("display_name")(_trim)

    def validate_role(self, known_roles=None) -> str | None:
        if (self.role is not None and known_roles is not None
                and self.role not in known_roles):
            return (f"role must be one of "
                    f"{', '.join(sorted(known_roles))} "
                    f"(got '{self.role}')")
        return None


class RoleRequest(BaseModel):
    """Create or replace a custom role."""
    # The validator alone sets the length rule: one wording (E2E-L19).
    name: str = Field(max_length=40)
    description: str = Field(default="", max_length=200)
    permissions: list[str] = Field(default_factory=list)

    @field_validator("name")
    @classmethod
    def _role_name(cls, value: str) -> str:
        value = (value or "").strip().lower()
        if not _ROLE_NAME_RE.match(value):
            raise ValueError("a role name has 2 to 40 characters: letters "
                             "a-z, digits, _ and - (no spaces or /)")
        return value


class RoleUpdateRequest(BaseModel):
    description: str | None = Field(default=None, max_length=200)
    permissions: list[str] | None = None
