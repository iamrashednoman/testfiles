"""Machine-client authentication and lifecycle (API-first intake).

Clients are systems, not humans: ServiceNow, SailPoint, ops tools.
Client-credentials -> short-lived JWT with per-client scopes
(intake:submit, intake:read, admin). Worker agents authenticate
separately with API keys (see modules/workers).
"""
