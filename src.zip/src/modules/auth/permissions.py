"""The permission catalogue and the built-in roles.

Phase 2 shipped three FIXED roles checked by rank (viewer < operator <
admin). That works but cannot express "this team may view evidence but
not retry work", which is what a real deployment needs.

This module turns roles into DATA without breaking the three that
already exist: each built-in role is seeded as a named bundle of
permissions, so `viewer`, `operator` and `admin` keep their exact
meaning while custom roles can be defined alongside them.

Authorization asks for a PERMISSION, never a role name. Adding a role
therefore never requires touching a route.
"""
from __future__ import annotations

# ── The catalogue ────────────────────────────────────────────────────
# Every permission the console can check. Grouped for the UI; the
# string is what the code and the database use.
PERMISSIONS: dict[str, str] = {
    "dashboard.view":  "See the dashboard and system health",
    "requests.view":   "See queued requests and transaction history",
    "requests.submit": "Submit new provisioning requests",
    "requests.retry":  "Retry a failed request",
    "requests.cancel": "Cancel a queued request",
    "evidence.view":   "Open evidence screenshots and their text "
                       "mirrors (may contain an account password)",
    "audit.view":      "Read the audit trail",
    "rules.view":      "See the screen-error catalogue",
    "rules.edit":      "Enable or disable error-catalogue rules",
    # Read-only access for access reviews (UR-05, 2026-10-03).
    "users.view":      "See console accounts and their roles (read "
                       "only), and export them for access reviews",
    "users.manage":    "Create, edit and remove console accounts",
    "roles.manage":    "Define roles and assign their permissions",
    "settings.view":   "See platform configuration",
    "settings.edit":   "Change platform configuration",
    # Desktop app (2026-09-26): the background service itself — its
    # status, logs, deployment file, vault secrets, pause/stop.
    "system.view":     "See service status, logs and deployment settings",
    "system.manage":   "Change deployment settings and credentials; "
                       "pause, restart or stop the service",
}

PERMISSION_GROUPS = {
    "Monitoring": ["dashboard.view", "requests.view", "audit.view"],
    "Operations": ["requests.submit", "requests.retry", "requests.cancel"],
    "Compliance": ["evidence.view", "rules.view"],
    "Administration": ["rules.edit", "users.view", "users.manage",
                       "roles.manage", "settings.view", "settings.edit",
                       "system.view", "system.manage"],
}

# ── Built-in roles ───────────────────────────────────────────────────
# EXACTLY the behaviour Phase 2's rank check produced, written out as
# permission sets. They are seeded into app_roles and cannot be deleted
# or renamed, so an install always has something to fall back on.
VIEWER = "viewer"
OPERATOR = "operator"
ADMIN = "admin"

_VIEWER_PERMS = ["dashboard.view", "requests.view", "evidence.view",
                 "audit.view", "rules.view", "settings.view"]
# NB-031: no "users.view" — the account list answers only to
# users.manage, so an operator would see a Users page that is refused.
# Built-in roles are reset to this list at every start.
_OPERATOR_PERMS = _VIEWER_PERMS + ["requests.submit", "requests.retry",
                                   "requests.cancel"]

BUILTIN_ROLES: dict[str, dict] = {
    VIEWER: {
        "description": "Read-only: monitoring, evidence and audit.",
        "permissions": list(_VIEWER_PERMS),
    },
    OPERATOR: {
        "description": "Everything a viewer can do, plus acting on "
                       "queued work.",
        "permissions": list(_OPERATOR_PERMS),
    },
    ADMIN: {
        "description": "Full control, including users, roles and "
                       "configuration.",
        "permissions": sorted(PERMISSIONS),
    },
}


def is_builtin(role_name: str) -> bool:
    return role_name in BUILTIN_ROLES


def validate_permissions(names) -> list[str]:
    """Return the unknown entries in `names` (empty list = all valid).

    Rejecting unknown permissions matters: a typo that silently stored
    "evidence.veiw" would grant nothing while LOOKING granted, which is
    the worst kind of access-control bug.
    """
    return sorted({str(n) for n in (names or [])} - set(PERMISSIONS))
