"""Admin user model — the human side of authentication.

The platform already authenticates MACHINES: a shared API key from
FINESIII_API_KEYS (services.build_auth_dependency), used by the
ServiceNow connector and the CLI. That path is untouched here.

This module adds PEOPLE: named accounts with roles, so the desktop
console can say who did what. Every settings change and every retry
made from the UI is attributable to a user in the existing audit trail.

Password hashing uses hashlib.scrypt from the STANDARD LIBRARY — no new
dependency, and a memory-hard KDF rather than a bare digest. Hashes are
never returned by the API (see to_public_dict).
"""
from __future__ import annotations

import hashlib
import hmac
import os
import secrets
from dataclasses import asdict, dataclass, field
from datetime import datetime, timedelta, timezone
from enum import Enum

JST = timezone(timedelta(hours=9))

# scrypt cost. n=2**14 puts one hash at roughly 50-100 ms on a modern
# CPU: slow enough to make guessing expensive, fast enough that a login
# feels instant. Raising n later is safe — the parameters are stored
# alongside each hash, so existing users keep verifying.
_SCRYPT_N = 2 ** 14
_SCRYPT_R = 8
_SCRYPT_P = 1
_SCRYPT_DKLEN = 32


class Role(str, Enum):
    """What a signed-in person may do.

    viewer    read everything: dashboard, transactions, evidence, audit
    operator  ...plus act on work: retry and cancel requests
    admin     ...plus change configuration and manage users
    """
    VIEWER = "viewer"
    OPERATOR = "operator"
    ADMIN = "admin"


# Ordered so a check is "at least this role", never a list of equals.
ROLE_RANK = {Role.VIEWER.value: 0, Role.OPERATOR.value: 1,
             Role.ADMIN.value: 2}

AUTH_LOCAL = "local"          # username + password
AUTH_WINDOWS = "windows"      # signed-in Windows account (SSO)


def now_jst() -> datetime:
    return datetime.now(JST)


def generate_user_id() -> str:
    return f"usr_{secrets.token_hex(6)}"


def hash_password(plaintext: str, salt: str = "") -> tuple[str, str]:
    """Return (hash_hex, salt_hex). A fresh salt is generated unless one
    is supplied (only when re-verifying an existing hash)."""
    salt_bytes = bytes.fromhex(salt) if salt else os.urandom(16)
    digest = hashlib.scrypt(
        plaintext.encode("utf-8"), salt=salt_bytes,
        n=_SCRYPT_N, r=_SCRYPT_R, p=_SCRYPT_P, dklen=_SCRYPT_DKLEN)
    return digest.hex(), salt_bytes.hex()


def verify_password(plaintext: str, hash_hex: str, salt_hex: str) -> bool:
    """Constant-time comparison. False for any malformed stored value —
    an SSO-only account (empty hash) can never be password-authenticated."""
    if not plaintext or not hash_hex or not salt_hex:
        return False
    try:
        candidate, _ = hash_password(plaintext, salt_hex)
    except ValueError:              # salt not valid hex
        return False
    return hmac.compare_digest(candidate, hash_hex)


def password_problems(password: str, minimum: int = 12,
                      username: str = "") -> list[str]:
    """Policy check. Returns the reasons a password is unacceptable —
    empty list means it passes. With `username`, a password containing
    it (any case) is refused too (SEC-07, 2026-10-04); a name shorter
    than 3 characters is not checked."""
    problems = []
    if len(password or "") < minimum:
        problems.append(f"must be at least {minimum} characters")
    if not any(c.isalpha() for c in password or ""):
        problems.append("must contain a letter")
    if not any(c.isdigit() for c in password or ""):
        problems.append("must contain a digit")
    name = (username or "").strip().lower()
    if len(name) >= 3 and name in (password or "").lower():
        problems.append("must not contain the username")
    return problems


@dataclass
class AppUser:
    """A person who can sign in to the admin console."""

    username: str
    display_name: str = ""
    email: str = ""
    password_hash: str = ""
    password_salt: str = ""
    auth_source: str = AUTH_LOCAL
    windows_account: str = ""        # DOMAIN\\user, for SSO mapping
    role: str = Role.VIEWER.value
    is_active: bool = True
    must_change_password: bool = False
    failed_attempts: int = 0
    locked_until: str = ""
    last_login_at: str = ""
    created_at: str = ""
    created_by: str = ""
    updated_at: str = ""
    user_id: str = field(default_factory=generate_user_id)

    def __post_init__(self):
        self.username = (self.username or "").strip().lower()
        self.windows_account = (self.windows_account or "").strip()
        # Any non-empty name: roles are DATA now, so a custom role is
        # as valid as a built-in one. The store rejects a name that
        # does not exist; this only guards against an empty value.
        self.role = (self.role or "").strip().lower()
        if not self.role:
            raise ValueError("A user must have a role")
        if not self.created_at:
            self.created_at = now_jst().isoformat()

    # ── Credentials ──

    def set_password(self, plaintext: str) -> None:
        self.password_hash, self.password_salt = hash_password(plaintext)
        self.must_change_password = False
        self.updated_at = now_jst().isoformat()

    def check_password(self, plaintext: str) -> bool:
        return verify_password(plaintext, self.password_hash,
                               self.password_salt)

    # ── Lockout ──

    def is_locked(self) -> bool:
        """True while a lockout window is still open."""
        if not self.locked_until:
            return False
        try:
            return now_jst() < datetime.fromisoformat(self.locked_until)
        except ValueError:
            return False

    def lock_for(self, seconds: int) -> None:
        self.locked_until = (
            now_jst() + timedelta(seconds=seconds)).isoformat()

    def clear_lock(self) -> None:
        self.failed_attempts = 0
        self.locked_until = ""

    # ── Authorization ──

    def can(self, required: str) -> bool:
        """Rank check against the BUILT-IN roles.

        Kept for the call sites that predate permissions. A custom role
        has no rank, so this returns False for one — callers that must
        work with custom roles use has_permission() instead, which is
        why the dependencies were moved onto permissions.
        """
        return (self.is_active
                and ROLE_RANK.get(self.role, -1)
                >= ROLE_RANK.get(required, 99))

    def has_permission(self, permission: str,
                       granted: list | None = None) -> bool:
        """The authoritative check.

        `granted` is this user's resolved permission list, looked up
        from their role by the caller (AuthService caches it per
        request). An inactive account is refused everything.
        """
        return bool(self.is_active and permission in (granted or []))

    # ── Serialization ──

    def to_dict(self) -> dict:
        d = asdict(self)
        d["is_active"] = 1 if self.is_active else 0
        d["must_change_password"] = 1 if self.must_change_password else 0
        return d

    def to_public_dict(self) -> dict:
        """Safe for the API. The hash and salt NEVER leave the server."""
        d = asdict(self)
        d.pop("password_hash", None)
        d.pop("password_salt", None)
        d["locked"] = self.is_locked()
        return d

    @classmethod
    def from_row(cls, row: dict) -> "AppUser":
        data = dict(row)
        data["is_active"] = bool(data.get("is_active", 1))
        data["must_change_password"] = bool(
            data.get("must_change_password", 0))
        known = {f for f in cls.__dataclass_fields__}
        return cls(**{k: v for k, v in data.items() if k in known})


@dataclass
class AppRole:
    """A named set of permissions.

    The three built-in roles are seeded copies of what Phase 2's rank
    check meant, so existing accounts keep their exact rights; custom
    roles sit alongside them.
    """

    name: str
    description: str = ""
    permissions: list = field(default_factory=list)
    is_builtin: bool = False
    created_at: str = ""
    created_by: str = ""
    updated_at: str = ""

    def __post_init__(self):
        self.name = (self.name or "").strip().lower()
        self.permissions = sorted({str(p) for p in (self.permissions or [])})
        if not self.created_at:
            self.created_at = now_jst().isoformat()

    def allows(self, permission: str) -> bool:
        return permission in self.permissions

    def to_dict(self) -> dict:
        import json
        d = asdict(self)
        d["permissions"] = json.dumps(self.permissions)
        d["is_builtin"] = 1 if self.is_builtin else 0
        return d

    def to_public_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_row(cls, row: dict) -> "AppRole":
        import json
        data = dict(row)
        raw = data.get("permissions") or "[]"
        try:
            data["permissions"] = (json.loads(raw)
                                   if isinstance(raw, str) else list(raw))
        except (TypeError, ValueError):
            data["permissions"] = []
        data["is_builtin"] = bool(data.get("is_builtin", 0))
        known = {f for f in cls.__dataclass_fields__}
        return cls(**{k: v for k, v in data.items() if k in known})


@dataclass
class AppSession:
    """An issued JWT, tracked so it can be revoked before it expires."""

    user_id: str
    issued_at: str = ""
    expires_at: str = ""
    revoked_at: str = ""
    client_info: str = ""
    session_id: str = field(
        default_factory=lambda: f"ses_{secrets.token_hex(8)}")

    def __post_init__(self):
        if not self.issued_at:
            self.issued_at = now_jst().isoformat()

    def is_active(self) -> bool:
        if self.revoked_at:
            return False
        try:
            return now_jst() < datetime.fromisoformat(self.expires_at)
        except ValueError:
            return False

    def to_dict(self) -> dict:
        return asdict(self)
