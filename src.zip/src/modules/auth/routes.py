"""Console authentication + user management.

Endpoints (all under /api/v1/auth and /api/v1/admin):

  GET    /auth/status            is this install initialised? (public)
  POST   /auth/bootstrap         create the FIRST administrator (public,
                                 refused once any account exists)
  POST   /auth/login             username + password  -> JWT
  POST   /auth/login/windows     signed-in Windows account -> JWT
                                 (localhost + Windows only)
  POST   /auth/logout            revoke the current session
  GET    /auth/me                current user + role
  POST   /auth/password          change own password

  GET    /admin/users            list          (users.view or .manage)
  GET    /admin/users/export     CSV for access reviews (same, audited)
  GET    /admin/role-names       role names    (users.view or .manage)
  POST   /admin/users            create        (admin)
  PATCH  /admin/users/{user_id}  update        (admin)
  POST   /admin/users/{user_id}/unlock  lift a lock (admin, audited)
  GET    /admin/sessions         who is signed in (users.view or .manage)
  DELETE /admin/sessions/{id}    end one session (admin, audited)
  DELETE /admin/users/{user_id}  delete        (admin)

These are ADDITIVE. The machine API-key dependency guarding the intake
routes is untouched, so the ServiceNow connector and the CLI keep
working exactly as before.
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, Header, HTTPException, Request, Response

from src.modules.auth.cookie import (
    clear_session_cookie, set_session_cookie, wants_cookie,
)
from src.modules.auth.models import AUTH_WINDOWS, AppUser, Role
from src.modules.auth.permissions import (
    BUILTIN_ROLES, PERMISSION_GROUPS, PERMISSIONS, is_builtin,
    validate_permissions,
)
from src.modules.auth.schemas import (
    BootstrapRequest, CreateUserRequest, LoginRequest,
    PasswordChangeRequest, RoleRequest, RoleUpdateRequest,
    UpdateUserRequest,
)
from src.modules.auth.services import (
    AuthError, build_console_dependency, build_permission_dependency,
    build_session_dependency, current_windows_account,
)

_LOCAL_HOSTS = {"127.0.0.1", "::1", "localhost"}


def _bearer(authorization: str) -> str:
    return (authorization[7:].strip()
            if authorization.lower().startswith("bearer ") else "")


def _client_text(user_agent: str) -> str:
    """The browser and system of a session, in short, from its
    user-agent text (for example "Edge on Windows")."""
    ua = user_agent or ""
    browser = ("Edge" if "Edg/" in ua else "Chrome" if "Chrome/" in ua
               else "Firefox" if "Firefox/" in ua else "Safari"
               if "Safari/" in ua else "")
    system = ("Windows" if "Windows" in ua else "macOS" if "Mac OS" in ua
              else "Linux" if "Linux" in ua else "")
    if browser or system:
        return " on ".join(p for p in (browser, system) if p)
    return ua[:40] or "Unknown"


def build_auth_router(auth_service, store, cfg, audit=None) -> APIRouter:
    router = APIRouter(prefix="/api/v1")

    # Managing users and roles is a PERMISSION, so a custom role can be
    # granted it without being an "admin".
    require_admin = build_permission_dependency(auth_service,
                                                "users.manage")
    require_roles = build_permission_dependency(auth_service,
                                                "roles.manage")
    # Seeing yourself and changing your own password need no permission
    # at all — a provisional password must not lock a user out of the
    # one action that clears it.
    require_self = build_session_dependency(auth_service,
                                            allow_provisional=True)
    require_session = build_session_dependency(auth_service)

    def require_users_read(user: AppUser = Depends(require_session)):
        """Reading the accounts and the role names: users.view, or
        users.manage which includes it (UR-02 / UR-05, 2026-10-03). An
        access review needs to read, never to change."""
        if not (auth_service.require(user, "users.view")
                or auth_service.require(user, "users.manage")):
            raise HTTPException(
                status_code=403,
                detail=(f"Your role '{user.role}' does not include the "
                        f"'users.view' permission"))
        return user

    def _audit(action: str, severity: str = "INFO", **fields):
        if audit is not None:
            try:
                audit.event("auth", action, severity=severity, **fields)
            except Exception:
                pass

    def _fail(e: AuthError):
        headers = ({"Retry-After": str(e.retry_after)}
                   if getattr(e, "retry_after", 0) else None)
        return HTTPException(status_code=e.status_code, detail=str(e),
                             headers=headers)

    def _session(request: Request, response: Response, token: str,
                 user: AppUser) -> dict:
        """A new session for the caller. The console page asks for a
        cookie it cannot read, and then gets no token in the answer
        (SES-01, 2026-10-04); every other caller gets the token as
        before."""
        body = {"token_type": "bearer",
                "expires_in": auth_service.ttl_seconds,
                "max_session_hours": auth_service.max_age_seconds // 3600,
                # The UI routes straight to the change-password screen;
                # the session is otherwise restricted until it is done.
                "must_change_password": user.must_change_password,
                "user": user.to_public_dict()}
        if wants_cookie(request):
            set_session_cookie(response, request, token)
            body["session"] = "cookie"
        else:
            body["access_token"] = token
        return body

    # ── Sign-in ──

    def _sso_possible(request: Request) -> bool:
        """Windows SSO is sound ONLY when the service process and the
        person at the window are the same account — the embedded
        single-user mode. Under the background agent the process runs
        as the bot account, so "the current Windows account" would be
        the bot's, whoever opened the window."""
        return (bool(getattr(cfg, "auth_windows_sso_enabled", False))
                and getattr(request.app.state, "desktop_mode",
                            "embedded") != "agent")

    @router.get("/auth/status")
    def auth_status(request: Request):
        """Public: lets the UI decide between the login screen and the
        first-run setup screen. Reveals no account details."""
        return {
            "initialised": not auth_service.needs_bootstrap(),
            "windows_sso_available": bool(
                _sso_possible(request) and current_windows_account()),
        }

    @router.post("/auth/bootstrap", status_code=201)
    def bootstrap(body: BootstrapRequest):
        try:
            user = auth_service.bootstrap_admin(
                body.username, body.password, body.display_name)
        except AuthError as e:
            raise _fail(e)
        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e))
        return {"user": user.to_public_dict()}

    @router.post("/auth/login")
    def login(body: LoginRequest, request: Request, response: Response):
        try:
            token, user = auth_service.authenticate(
                body.username, body.password,
                client_info=request.headers.get("user-agent", ""))
        except AuthError as e:
            raise _fail(e)
        return _session(request, response, token, user)

    @router.post("/auth/login/windows")
    def login_windows(request: Request, response: Response):
        """Desktop single sign-on.

        The account is read from the OPERATING SYSTEM, never from the
        request body, and only when the caller is on this machine. Over
        a network a client could simply claim to be an administrator,
        so SSO is refused there and password sign-in applies.
        """
        if not getattr(cfg, "auth_windows_sso_enabled", False):
            raise HTTPException(
                status_code=404,
                detail="Windows sign-on is not enabled on this service")
        if not _sso_possible(request):
            _audit("windows_sso_refused", "WARNING",
                   detail={"reason": "service_runs_as_agent"})
            raise HTTPException(
                status_code=403,
                detail=("Windows sign-on is not available while the "
                        "service runs as the background agent — it would "
                        "identify the bot account, not you. Sign in with "
                        "a password."))
        client_host = request.client.host if request.client else ""
        if client_host not in _LOCAL_HOSTS:
            _audit("windows_sso_refused", "WARNING",
                   detail={"client": client_host,
                           "reason": "not_local"})
            raise HTTPException(
                status_code=403,
                detail=("Windows sign-on is only available to the "
                        "desktop application running on this machine"))
        account = current_windows_account()
        if not account:
            raise HTTPException(
                status_code=403,
                detail="No Windows account identity is available here")
        try:
            token, user = auth_service.authenticate_windows(
                account, client_info=request.headers.get("user-agent", ""))
        except AuthError as e:
            raise _fail(e)
        return _session(request, response, token, user)

    @router.post("/auth/refresh")
    def refresh(request: Request, response: Response,
                authorization: str = Header(default="")):
        try:
            token, user = auth_service.refresh(
                _bearer(authorization),
                client_info=request.headers.get("user-agent", ""))
        except AuthError as e:
            raise _fail(e)
        return _session(request, response, token, user)

    @router.post("/auth/logout")
    def logout(request: Request, response: Response,
               authorization: str = Header(default="")):
        auth_service.logout(_bearer(authorization))
        # The cookie goes too, whatever state the session was in.
        clear_session_cookie(response, request)
        return {"status": "signed out"}

    @router.get("/auth/me")
    def me(user: AppUser = Depends(require_self),
           authorization: str = Header(default="")):
        """Identity plus the RESOLVED permissions of the user's role.

        The console hides controls it cannot use; the API still
        enforces every one of them, so this is convenience, never the
        access decision. It also tells a reloaded console page how long
        its session still runs, so it can carry on (SES-01).
        """
        import time
        claims = auth_service.claims(_bearer(authorization))
        remaining = max(0, int(claims.get("exp", 0) - time.time()))
        return {"user": user.to_public_dict(),
                "permissions": auth_service.permissions_for(user),
                "must_change_password": user.must_change_password,
                "expires_in": auth_service.ttl_seconds,
                "session_remaining": remaining,
                "max_session_hours": auth_service.max_age_seconds // 3600}

    @router.post("/auth/password")
    def change_password(body: PasswordChangeRequest,
                        user: AppUser = Depends(require_self)):
        try:
            auth_service.change_password(
                user, body.current_password, body.new_password)
        except AuthError as e:
            raise _fail(e)
        return {"status": "password changed",
                "note": ("Password changed. All sessions, including this "
                         "one, have been signed out — sign in again with "
                         "the new password.")}

    # ── User management (admin) ──

    @router.get("/admin/users")
    def list_users(admin: AppUser = Depends(require_users_read)):
        users = store.list_users()
        return {"count": len(users),
                "users": [u.to_public_dict() for u in users]}

    @router.get("/admin/users/export")
    def export_users(reader: AppUser = Depends(require_users_read)):
        """Every account with its role and the permissions the role
        grants, for a periodic access review (UR-05, 2026-10-03). CSV
        like the other exports; recorded in the audit trail."""
        from fastapi.responses import Response
        from src.modules.console.metrics import to_csv
        from src.modules.intake.models import now_jst
        columns = ("username", "display_name", "email", "role",
                   "role_permissions", "is_active", "sign_in",
                   "windows_account", "must_change_password",
                   "last_login_at", "created_at", "created_by",
                   "user_id")
        rows = []
        for u in store.list_users():
            d = u.to_public_dict()
            d["role_permissions"] = " ".join(
                sorted(store.permissions_for(u.role)))
            d["sign_in"] = ("Windows" if u.windows_account
                            and not u.password_hash else "Password")
            rows.append(d)
        _audit("data_exported", "WARNING", actor=reader.username,
               detail={"table": "users", "rows": len(rows),
                       "total": len(rows), "truncated": False})
        stamp = now_jst().strftime("%Y%m%d_%H%M%S")
        return Response(
            content=to_csv(rows, columns).encode("utf-8"),
            media_type="text/csv",
            headers={"Content-Disposition":
                     f'attachment; filename="finesiii_users_{stamp}.csv"',
                     "Cache-Control": "no-store",
                     "X-Export-Rows": str(len(rows)),
                     "X-Export-Total": str(len(rows)),
                     "X-Export-Truncated": "false",
                     "X-Export-Audited": str(audit is not None).lower()})

    @router.get("/admin/role-names")
    def role_names(reader: AppUser = Depends(require_users_read)):
        """The roles an account can have, for the Users page. Readable
        with users.view or users.manage: a user administrator without
        role management must still see and assign the custom roles
        (UR-02, 2026-10-03). `assignable`: whether THIS reader may give
        the role (never one above their own rights)."""
        return {"roles": [{
            "name": r.name, "description": r.description,
            "is_builtin": r.is_builtin,
            "assignable": not _exceeds(reader, r.name)}
            for r in store.list_roles()]}

    def _exceeds(actor: AppUser, role_name: str) -> list:
        """Permissions `role_name` grants that the ACTOR does not hold.
        Managing users must never be a way to obtain — or hand out —
        more than you have yourself (AUTHZ-01)."""
        if not role_name:
            return []
        held = set(auth_service.permissions_for(actor))
        return sorted(set(store.permissions_for(role_name)) - held)

    def _refuse_if_exceeds(actor: AppUser, role_name: str, what: str):
        extra = _exceeds(actor, role_name)
        if extra:
            _audit("privilege_escalation_refused", "WARNING",
                   actor=actor.username,
                   detail={"role": role_name, "action": what,
                           "missing": extra[:10]})
            raise HTTPException(
                status_code=403,
                detail=(f"You cannot {what} the role '{role_name}': it "
                        f"grants permissions you do not hold yourself"))

    @router.post("/admin/users", status_code=201)
    def create_user(body: CreateUserRequest, request: Request,
                    admin: AppUser = Depends(require_admin)):
        known = {r.name for r in store.list_roles()}
        problem = body.validate_role(known)
        if problem:
            raise HTTPException(status_code=400, detail=problem)
        # An account without a password signs in with Windows only, which
        # is possible only when Windows sign-on is on and the service
        # runs as the signed-in person (UR-13, 2026-10-03).
        if not body.password and not _sso_possible(request):
            raise HTTPException(
                status_code=400,
                detail=("A password is required: Windows sign-on is not "
                        "available on this service, so an account without "
                        "a password could never sign in."))
        _refuse_if_exceeds(admin, body.role, "create an account with")
        if body.password:
            from src.modules.auth.models import password_problems
            issues = password_problems(
                body.password,
                int(getattr(cfg, "auth_min_password_length", 12)),
                username=body.username)
            if issues:
                raise HTTPException(status_code=400,
                                    detail="Password " + "; ".join(issues))
        user = AppUser(
            username=body.username, display_name=body.display_name,
            email=body.email, role=body.role,
            windows_account=body.windows_account,
            auth_source=(AUTH_WINDOWS if body.windows_account
                         and not body.password else "local"),
            created_by=admin.username)
        if body.password:
            user.set_password(body.password)
            # Admin-chosen passwords are provisional by policy.
            user.must_change_password = True
        try:
            store.create(user)
        except ValueError as e:
            raise HTTPException(status_code=409, detail=str(e))
        if body.password:
            auth_service.remember_password(user)
        _audit("user_created", "WARNING", actor=admin.username,
               detail={"username": user.username, "user_id": user.user_id,
                       "role": user.role})
        return {"user": user.to_public_dict()}

    @router.patch("/admin/users/{user_id}")
    def update_user(user_id: str, body: UpdateUserRequest,
                    admin: AppUser = Depends(require_admin)):
        known = {r.name for r in store.list_roles()}
        problem = body.validate_role(known)
        if problem:
            raise HTTPException(status_code=400, detail=problem)
        user = store.get(user_id)
        if user is None:
            raise HTTPException(status_code=404, detail="No such user")
        # Neither grant a role above your own, nor take over an account
        # that holds one (a password reset on an administrator is the
        # same escalation by another door).
        if body.role is not None:
            _refuse_if_exceeds(admin, body.role, "assign")
        if user.user_id != admin.user_id:
            _refuse_if_exceeds(admin, user.role, "change an account holding")

        if body.windows_account:
            # One Windows account maps to ONE console account; re-saving
            # the account's own mapping is fine.
            holders = [u for u in store.find_by_windows_account(
                           body.windows_account)
                       if u.user_id != user.user_id]
            if holders:
                raise HTTPException(
                    status_code=409,
                    detail=(f"Windows account "
                            f"'{body.windows_account.strip()}' is already "
                            f"mapped to '{holders[0].username}'"))

        # Nobody deactivates the account they are signed in with (UR-11,
        # 2026-10-03); another administrator can.
        if user.user_id == admin.user_id and body.is_active is False:
            raise HTTPException(
                status_code=409,
                detail="You cannot deactivate the account you are signed "
                       "in as")

        before = user.to_public_dict()
        losing_admin = (
            (body.role is not None and body.role != Role.ADMIN.value)
            or body.is_active is False)
        if (user.role == Role.ADMIN.value and user.is_active
                and losing_admin
                and store.count_active_admins(excluding=user_id) == 0):
            raise HTTPException(
                status_code=409,
                detail=("This is the last active administrator — "
                        "promote another account first"))

        for field in ("display_name", "email", "role", "windows_account"):
            value = getattr(body, field)
            if value is not None:
                setattr(user, field, value)
        if body.is_active is not None:
            user.is_active = body.is_active
        if body.password:
            from src.modules.auth.models import password_problems
            issues = password_problems(
                body.password,
                int(getattr(cfg, "auth_min_password_length", 12)),
                username=user.username)
            if issues:
                raise HTTPException(status_code=400,
                                    detail="Password " + "; ".join(issues))
            user.set_password(body.password)
            user.must_change_password = True
            # A reset unlocks the account: the person can sign in with
            # the new provisional password at once (UR-01).
            user.clear_lock()
        store.update(user)
        if body.password:
            auth_service.remember_password(user)
            auth_service.unlock(user)      # the wait after failures too

        # A revoked role or a reset password must not leave a live
        # session behind with the old rights.
        if body.role is not None or body.is_active is False or body.password:
            store.revoke_all_for_user(user.user_id)

        _audit("user_updated", "WARNING", actor=admin.username,
               detail={"username": user.username, "user_id": user.user_id,
                       "before": before, "after": user.to_public_dict()})
        if body.password:
            # Who reset whose password, on its own (UR-03, 2026-10-03).
            _audit("user_password_reset", "WARNING", actor=admin.username,
                   detail={"username": user.username,
                           "user_id": user.user_id,
                           "own_account": user.user_id == admin.user_id})
            # An administrator's password reset by another administrator
            # is told to the administrators by e-mail, like a lock-out
            # (D-08, 2026-10-05).
            if user.user_id != admin.user_id and "admin" in (
                    str(before.get("role", "")), str(user.role)) and \
                    getattr(auth_service, "lockout_alert", False) and \
                    getattr(auth_service, "logger", None) is not None:
                try:
                    auth_service.logger.error(
                        f"Console administrator '{admin.username}' reset the "
                        f"password of administrator '{user.username}'.")
                except Exception:
                    pass
        return {"user": user.to_public_dict()}

    @router.post("/admin/users/{user_id}/unlock")
    def unlock_user(user_id: str,
                    admin: AppUser = Depends(require_admin)):
        """Lift a lock from failed sign-ins at once (SEC-05 / OPS-08,
        2026-10-04). The password is not changed; the person signs in
        with the one they have."""
        user = store.get(user_id)
        if user is None:
            raise HTTPException(status_code=404, detail="No such user")
        if user.user_id != admin.user_id:
            _refuse_if_exceeds(admin, user.role, "unlock an account holding")
        locked_until = user.locked_until if user.is_locked() else ""
        had = auth_service.unlock(user)
        _audit("user_unlocked", "WARNING", actor=admin.username,
               detail={"username": user.username, "user_id": user.user_id,
                       "was_locked_until": locked_until,
                       "changed": had})
        return {"status": "unlocked" if had else "not locked",
                "user": user.to_public_dict()}

    # ── Active sessions (SES-06, 2026-10-04) ──

    @router.get("/admin/sessions")
    def list_sessions(reader: AppUser = Depends(require_users_read),
                      authorization: str = Header(default="")):
        """Who is signed in now: one row per open console session (a
        browser window keeps one session, renewed while it is used)."""
        own = auth_service.claims(_bearer(authorization)).get("sid", "")
        sessions = []
        for row in store.list_active_sessions():
            sessions.append({
                "session_id": row["session_id"],
                "user_id": row["user_id"],
                "username": row.get("username") or "(deleted account)",
                "display_name": row.get("display_name") or "",
                "role": row.get("role") or "",
                "issued_at": row["issued_at"],
                "expires_at": row["expires_at"],
                "client": _client_text(row.get("client_info") or ""),
                "current": row["session_id"] == own})
        return {"count": len(sessions), "sessions": sessions}

    @router.delete("/admin/sessions/{session_id}")
    def end_session(session_id: str,
                    admin: AppUser = Depends(require_admin),
                    authorization: str = Header(default="")):
        """End one session at once: its next request is refused and the
        console in that browser returns to the sign-in page."""
        match = [r for r in store.list_active_sessions()
                 if r["session_id"] == session_id]
        if not match:
            raise HTTPException(status_code=404,
                                detail="No such open session")
        row = match[0]
        if row["user_id"] != admin.user_id and row.get("role"):
            _refuse_if_exceeds(admin, row["role"],
                               "end a session of an account holding")
        own = auth_service.claims(_bearer(authorization)).get("sid", "")
        store.revoke_session(session_id)
        _audit("session_ended", "WARNING", actor=admin.username,
               detail={"session_id": session_id,
                       "username": row.get("username") or "",
                       "user_id": row["user_id"],
                       "own_session": session_id == own})
        return {"status": "ended", "username": row.get("username") or ""}

    @router.delete("/admin/users/{user_id}")
    def delete_user(user_id: str,
                    admin: AppUser = Depends(require_admin)):
        user = store.get(user_id)
        if user is None:
            raise HTTPException(status_code=404, detail="No such user")
        if user.user_id == admin.user_id:
            raise HTTPException(
                status_code=409,
                detail="You cannot delete the account you are signed in as")
        # Deleting an account is at least as strong as editing it: no
        # removing a holder of rights you do not have yourself.
        _refuse_if_exceeds(admin, user.role, "delete an account holding")
        if (user.role == Role.ADMIN.value and user.is_active
                and store.count_active_admins(excluding=user_id) == 0):
            raise HTTPException(
                status_code=409,
                detail=("This is the last active administrator — "
                        "promote another account first"))
        store.delete(user_id)
        auth_service.forget_passwords(user_id)
        _audit("user_deleted", "WARNING", actor=admin.username,
               detail={"username": user.username, "user_id": user.user_id,
                       "role": user.role})
        return {"status": "deleted", "username": user.username}

    # ── Roles & permissions (admin) ──

    @router.get("/admin/permissions")
    def list_permissions(admin: AppUser = Depends(require_roles)):
        """The catalogue a role can be built from, grouped for the UI."""
        return {"permissions": PERMISSIONS, "groups": PERMISSION_GROUPS}

    @router.get("/admin/roles")
    def list_roles(admin: AppUser = Depends(require_roles)):
        roles = store.list_roles()
        return {"count": len(roles),
                "roles": [dict(r.to_public_dict(),
                               users=store.count_users_with_role(r.name))
                          for r in roles]}

    def _refuse_permissions_above(actor: AppUser, permissions, what: str):
        """Managing roles must not be a way to give yourself (or anyone)
        more than you hold: a role can only carry permissions the actor
        has. Same rule as user management (AUTHZ-01)."""
        held = set(auth_service.permissions_for(actor))
        extra = sorted({str(p) for p in (permissions or [])} - held)
        if extra:
            _audit("privilege_escalation_refused", "WARNING",
                   actor=actor.username,
                   detail={"action": f"role {what}", "missing": extra[:10]})
            raise HTTPException(
                status_code=403,
                detail=(f"You cannot {what} a role with permissions you do "
                        f"not hold yourself: {', '.join(extra[:5])}"))

    @router.post("/admin/roles", status_code=201)
    def create_role(body: RoleRequest,
                    admin: AppUser = Depends(require_roles)):
        from src.modules.auth.models import AppRole

        unknown = validate_permissions(body.permissions)
        if unknown:
            raise HTTPException(
                status_code=400,
                detail=f"Unknown permission(s): {', '.join(unknown)}")
        # A role that grants nothing is not a role (E2E-L19).
        if not body.permissions:
            raise HTTPException(
                status_code=400,
                detail="Choose at least one permission for the role.")
        if is_builtin(body.name.strip().lower()):
            raise HTTPException(
                status_code=409,
                detail=f"'{body.name}' is a built-in role")
        _refuse_permissions_above(admin, body.permissions, "create")
        role = AppRole(name=body.name, description=body.description,
                       permissions=body.permissions,
                       created_by=admin.username)
        try:
            store.create_role(role)
        except ValueError as e:
            raise HTTPException(status_code=409, detail=str(e))
        _audit("role_created", "WARNING", actor=admin.username,
               detail={"role": role.name,
                       "permissions": role.permissions})
        return {"role": role.to_public_dict()}

    @router.patch("/admin/roles/{name}")
    def update_role(name: str, body: RoleUpdateRequest,
                    admin: AppUser = Depends(require_roles)):
        role = store.get_role(name)
        if role is None:
            raise HTTPException(status_code=404, detail="No such role")
        if role.is_builtin:
            raise HTTPException(
                status_code=409,
                detail=("Built-in roles cannot be edited — their "
                        "permissions are part of the release. Create a "
                        "custom role instead."))
        # Editing a role is only for one that grants nothing beyond the
        # editor's own rights — also when permissions are only taken away
        # (UR-14, 2026-10-03).
        _refuse_permissions_above(admin, role.permissions, "edit")
        if body.permissions is not None:
            if not body.permissions:
                raise HTTPException(
                    status_code=400,
                    detail="Choose at least one permission for the role.")
            unknown = validate_permissions(body.permissions)
            if unknown:
                raise HTTPException(
                    status_code=400,
                    detail=f"Unknown permission(s): {', '.join(unknown)}")
            _refuse_permissions_above(admin, body.permissions, "edit")
            role.permissions = sorted(set(body.permissions))
        if body.description is not None:
            role.description = body.description
        before = store.get_role(name).to_public_dict()
        store.update_role(role)
        _audit("role_updated", "WARNING", actor=admin.username,
               detail={"role": role.name, "before": before,
                       "after": role.to_public_dict()})
        return {"role": role.to_public_dict()}

    @router.delete("/admin/roles/{name}")
    def delete_role(name: str,
                    admin: AppUser = Depends(require_roles)):
        role = store.get_role(name)
        if role is None:
            raise HTTPException(status_code=404, detail="No such role")
        if role.is_builtin:
            raise HTTPException(status_code=409,
                                detail="Built-in roles cannot be deleted")
        _refuse_permissions_above(admin, role.permissions, "delete")
        in_use = store.count_users_with_role(role.name)
        if in_use:
            # Deleting a role in use would silently strip those users
            # of every permission — refuse and say who is affected.
            raise HTTPException(
                status_code=409,
                detail=(f"{in_use} account(s) still use '{role.name}' — "
                        f"move them to another role first"))
        store.delete_role(role.name)
        _audit("role_deleted", "WARNING", actor=admin.username,
               detail={"role": role.name})
        return {"status": "deleted", "role": role.name}

    return router
