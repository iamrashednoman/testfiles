"""The console's session cookie (SES-01, 2026-10-04).

The console page used to hold its session token in memory only, so a
reload, a second tab or a service restart always went back to the
sign-in page. The token now travels in a cookie the page cannot read:

  * HttpOnly        page script never sees it;
  * SameSite=Strict never sent by a page of another site;
  * Path=/api       sent to the API only;
  * Secure          when the console is served over HTTPS;
  * no expiry date  dropped when the browser closes (SEC-09). The
                    server ends an idle session on its own: the token
                    lives only as long as the inactivity limit and is
                    renewed by the page while someone is using it.

Only the console gets a cookie: it asks for one with the console
header on sign-in. Postman, the ServiceNow connector and every other
API caller are unchanged and keep sending "Authorization: Bearer" or
"X-API-Key".

The middleware below turns the cookie into the usual Authorization
header before any route sees the request, so the existing session
checks (verify, permissions, the console grant on the intake API) are
used as they are. A request that changes something must carry the
console header as well: another site cannot add a custom header to a
request without the browser asking this service first, which it never
allows. That is the protection against cross-site request forgery on
top of SameSite=Strict.
"""
from __future__ import annotations

import json

COOKIE_PREFIX = "finesiii_session"
CONSOLE_HEADER = "X-FINESIII-Console"
_SAFE_METHODS = {"GET", "HEAD", "OPTIONS"}


def cookie_name(scope_or_port) -> str:
    """One cookie per port: a browser shares cookies between ports of
    the same host, so two copies on one machine (a test and a live
    instance) would otherwise sign each other out."""
    port = scope_or_port
    if isinstance(scope_or_port, dict):
        server = scope_or_port.get("server") or (None, None)
        port = server[1] if len(server) > 1 else None
    return f"{COOKIE_PREFIX}_{port or 0}"


def wants_cookie(request) -> bool:
    """The console asks for a cookie session with its header."""
    return request.headers.get(CONSOLE_HEADER, "") == "1"


def set_session_cookie(response, request, token: str) -> None:
    response.set_cookie(
        cookie_name(request.scope), token,
        httponly=True, samesite="strict", path="/api",
        secure=request.url.scheme == "https")


def clear_session_cookie(response, request) -> None:
    response.delete_cookie(
        cookie_name(request.scope), path="/api", httponly=True,
        samesite="strict", secure=request.url.scheme == "https")


def _cookie_value(headers: list, name: str) -> str:
    for key, value in headers:
        if key != b"cookie":
            continue
        for part in value.decode("latin-1").split(";"):
            k, _, v = part.strip().partition("=")
            if k == name:
                return v.strip()
    return ""


class ConsoleSessionCookie:
    """Pure ASGI middleware: cookie → Authorization header, and the
    console header on every request that changes something."""

    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http" or not scope.get("path", "").startswith(
                "/api/"):
            return await self.app(scope, receive, send)
        headers = list(scope.get("headers") or [])
        names = {k for k, _ in headers}
        # An explicit Authorization header (Postman, scripts) or an API
        # key wins: the cookie is the console's, and only the console's.
        if b"authorization" in names or b"x-api-key" in names:
            return await self.app(scope, receive, send)
        token = _cookie_value(headers, cookie_name(scope))
        if not token:
            return await self.app(scope, receive, send)
        method = scope.get("method", "GET").upper()
        console = dict(headers).get(CONSOLE_HEADER.lower().encode(), b"")
        if method not in _SAFE_METHODS and console != b"1":
            body = json.dumps({"detail": (
                "This request did not come from the console page and was "
                "refused. Reload the console and try again.")}).encode()
            await send({"type": "http.response.start", "status": 403,
                        "headers": [(b"content-type", b"application/json"),
                                    (b"content-length",
                                     str(len(body)).encode())]})
            await send({"type": "http.response.body", "body": body})
            return
        headers.append((b"authorization", f"Bearer {token}".encode()))
        scope = dict(scope, headers=headers)
        return await self.app(scope, receive, send)
