"""API-key authentication (approved change #6).

Config-driven and off by default (auth_enabled=False) so existing local
flows are untouched; ProductionConfig enables it. Keys live only in the
FINESIII_API_KEYS environment variable (comma-separated, optionally
"client:key" pairs so audit can attribute calls) — never in YAML/code.

Fail-closed: if auth is enabled but no keys are configured, startup
raises instead of silently accepting everything.
"""
from __future__ import annotations

import hmac
import os
import sys

from fastapi import HTTPException, Request

API_KEY_HEADER = "X-API-Key"
API_KEYS_ENV = "FINESIII_API_KEYS"


def _load_keys() -> dict[str, str]:
    """Parse FINESIII_API_KEYS → {key: client_name}."""
    raw = os.environ.get(API_KEYS_ENV, "")
    keys: dict[str, str] = {}
    for entry in raw.split(","):
        entry = entry.strip()
        if not entry:
            continue
        if ":" in entry:
            client, key = entry.split(":", 1)
            keys[key.strip()] = client.strip() or "unnamed"
        else:
            keys[entry] = "default"
    return keys


def _api_permission_for(request: Request) -> str:
    """Which console permission a Bearer caller needs on an intake route.

    Mirrors the role split the UI already applies: reading is a viewer
    right, submitting/retrying/cancelling are operator rights, and the
    audit trail has its own permission. Anything unrecognised falls
    back to the most restrictive read permission rather than opening up.
    """
    path = request.url.path
    method = request.method.upper()
    if path.endswith("/retry"):
        return "requests.retry"
    if method == "DELETE":
        return "requests.cancel"
    if method == "POST":
        return "requests.submit"
    if "/audit/" in path:
        return "audit.view"
    if path.endswith("/health") or path.endswith("/queue"):
        return "dashboard.view"
    return "requests.view"


def build_auth_dependency(cfg, auth_service=None):
    """Return a FastAPI dependency enforcing the configured auth mode.

    auth_service is only consulted when cfg.auth_console_grants_api is
    on (desktop deployments, approved D4): a signed-in console user may
    then call the intake routes with their Bearer token, subject to the
    per-route permission from _api_permission_for. With the flag off —
    the default, and every server deployment — a Bearer token is
    ignored here exactly as before and only the machine API key passes.
    """
    if not cfg.auth_enabled:
        async def no_auth(request: Request) -> str:
            # No key is needed, but a person signed into the console is
            # still named in the audit trail, in the same "user:<name>"
            # form as everywhere else (UAT-L24, 2026-10-04).
            if auth_service is not None:
                authorization = request.headers.get(AUTH_HEADER, "")
                if authorization.lower().startswith(_BEARER):
                    try:
                        user = auth_service.verify(
                            authorization[len(_BEARER):].strip())
                    except Exception:
                        user = None     # not a session: anonymous, as before
                    if user is not None:
                        # A person still needs the route's permission,
                        # as when the key is required (E2E-M05).
                        if user.must_change_password:
                            raise HTTPException(
                                status_code=428,
                                detail=("Your password was set by an "
                                        "administrator and must be changed "
                                        "before you can continue"))
                        needed = _api_permission_for(request)
                        if not auth_service.require(user, needed):
                            raise HTTPException(
                                status_code=403,
                                detail=(f"Your role '{user.role}' does not "
                                        f"include the '{needed}' permission"))
                        return f"user:{user.username}"
            return "anonymous"
        return no_auth

    keys = _load_keys()
    if not keys:
        raise RuntimeError(
            f"auth_enabled=True but {API_KEYS_ENV} is empty — refusing to "
            "start an unauthenticated service (fail-closed)."
        )

    console_grants = bool(getattr(cfg, "auth_console_grants_api", False)
                          and auth_service is not None)

    def require_api_key(request: Request) -> str:
        presented = request.headers.get(API_KEY_HEADER, "")
        if presented:
            for key, client in keys.items():
                if hmac.compare_digest(presented, key):
                    return client
        if console_grants:
            authorization = request.headers.get(AUTH_HEADER, "")
            if authorization.lower().startswith(_BEARER):
                token = authorization[len(_BEARER):].strip()
                try:
                    user = auth_service.verify(token)
                except AuthError as e:
                    raise HTTPException(status_code=e.status_code,
                                        detail=str(e))
                if user.must_change_password:
                    raise HTTPException(
                        status_code=428,
                        detail=("Your password was set by an "
                                "administrator and must be changed "
                                "before you can continue"))
                needed = _api_permission_for(request)
                if not auth_service.require(user, needed):
                    raise HTTPException(
                        status_code=403,
                        detail=(f"Your role '{user.role}' does not "
                                f"include the '{needed}' permission"))
                return f"user:{user.username}"
        raise HTTPException(status_code=401, detail="Invalid or missing API key")

    return require_api_key


# ═══════════════════════════════════════════════════════════════════
# Human authentication (admin console) — Phase 2
#
# The API-key dependency above authenticates MACHINES and is unchanged.
# What follows authenticates PEOPLE for the desktop console: named
# accounts, roles, JWT sessions, lockout, and optional Windows SSO.
# The two are independent; a route can require either or both.
# ═══════════════════════════════════════════════════════════════════

import json as _json
import math as _math
import secrets as _secrets
import threading as _threading
import time as _time
from datetime import datetime, timedelta

from src.modules.auth.models import (
    AppSession, AppUser, Role, now_jst,
)

AUTH_HEADER = "Authorization"
_BEARER = "bearer "
JWT_ALGORITHM = "HS256"


class AuthError(Exception):
    """Authentication or authorization failure (mapped to 401/403)."""

    def __init__(self, message: str, status_code: int = 401,
                 retry_after: int = 0):
        super().__init__(message)
        self.status_code = status_code
        # Seconds before the next attempt is looked at (429 only).
        self.retry_after = retry_after


def resolve_jwt_secret(cfg, logger=None) -> str:
    """The signing key for console sessions.

    An explicit JWT_SECRET always wins — that is what a server
    deployment sets. A desktop install has no environment to set it in,
    so a random per-install secret is generated once and stored in the
    user data directory with owner-only permissions. There is NO
    hard-coded fallback: a predictable signing key would let anyone
    mint an admin token.
    """
    configured = (getattr(cfg, "jwt_secret", "") or "").strip()
    if configured:
        return configured

    from src.core.app_paths import data_path
    secret_file = data_path(".jwt_secret")
    try:
        if secret_file.is_file():
            existing = secret_file.read_text(encoding="utf-8").strip()
            if existing:
                return existing
        secret_file.parent.mkdir(parents=True, exist_ok=True)
        generated = _secrets.token_urlsafe(48)
        secret_file.write_text(generated, encoding="utf-8")
        try:
            os.chmod(secret_file, 0o600)
        except OSError:
            pass
        if logger:
            logger.info(
                f"Generated a per-install console signing key at "
                f"{secret_file} (set JWT_SECRET to manage it centrally)")
        return generated
    except OSError as e:
        raise RuntimeError(
            f"Cannot establish a JWT signing key ({e}). Set JWT_SECRET "
            f"explicitly.") from e


class AuthService:
    """Sign-in, session issue/verify, and password changes."""

    # After the n-th failed sign-in in a row for a username, the next
    # attempt is looked at only after min(2**n, this) seconds (SEC-05).
    FAILURE_WAIT_MAX_SECONDS = 30
    # Usernames tracked at most (oldest dropped first).
    FAILURE_TRACK_LIMIT = 5000
    # Where a user's earlier password hashes are kept (SEC-07).
    HISTORY_KEY = "PASSWORD_HISTORY_{}"

    def __init__(self, store, cfg, logger=None, audit=None):
        self.store = store
        self.cfg = cfg
        self.logger = logger
        self.audit = audit
        # Optional callable(user), called after a successful password
        # change (the desktop app retires the stored initial password).
        # Assigned after construction, like `audit`.
        self.on_password_changed = None
        self.secret = resolve_jwt_secret(cfg, logger)
        # The session lifetime is also the inactivity limit: the console
        # renews it only while someone is using it (SES-02, 2026-10-04).
        self.ttl_seconds = int(getattr(cfg, "jwt_ttl_seconds", 1800))
        # However active, a session ends this long after the sign-in.
        self.max_age_seconds = int(
            getattr(cfg, "auth_max_session_hours", 12)) * 3600
        self.max_failed = int(getattr(cfg, "auth_max_failed_attempts", 5))
        self.lockout_seconds = int(
            getattr(cfg, "auth_lockout_seconds", 900))
        # Password rules and the lockout alert (SEC-05 / SEC-07,
        # 2026-10-04).
        self.history_size = int(getattr(cfg, "auth_password_history", 5))
        self.max_age_days = int(
            getattr(cfg, "auth_password_max_age_days", 0))
        self.lockout_alert = bool(getattr(cfg, "auth_lockout_alert", True))
        # The console settings table, where earlier password hashes are
        # kept, so the database needs no new table. Assigned after
        # construction, like `audit`; None = no history is kept.
        self.settings = None
        # {username: [failures in a row, next attempt (monotonic), told]}
        self._failures: dict = {}
        self._failures_lock = _threading.Lock()

    # ── Audit ──

    def _event(self, action: str, severity: str = "INFO", **fields):
        if self.audit is not None:
            try:
                self.audit.event("auth", action, severity=severity,
                                 **fields)
            except Exception:
                pass

    # ── Sign-in ──

    def authenticate(self, username: str, password: str,
                     client_info: str = "") -> tuple[str, AppUser]:
        """Verify a password and issue a session token.

        Every rejection returns the SAME message: distinguishing
        "no such user" from "wrong password" hands an attacker a user
        enumeration oracle. The audit trail records the real reason.
        """
        generic = "Invalid username or password"
        user = self.store.get_by_username(username)
        # A locked account answers like a wrong password, after the same
        # wait, so the answer never tells which names exist (D-07,
        # 2026-10-05). The lock is in the audit trail and the
        # administrators' lock-out e-mail.
        # Too soon after a failed attempt for this username: refused
        # without looking at the password, so guessing (and locking an
        # account by guessing) is slowed down. The same for every
        # username, known or not (SEC-05, 2026-10-04).
        wait = self._wait_left(username)
        if wait:
            raise AuthError(
                f"Too many failed sign-in attempts. Wait {wait} "
                f"second(s) and try again.", 429, retry_after=wait)

        if user is None:
            self._note_failure(username)
            self._event("login_failed", "WARNING",
                        detail={"username": username,
                                "reason": "unknown_user"})
            raise AuthError(generic)

        if not user.is_active:
            self._note_failure(username)
            self._event("login_failed", "WARNING", actor=user.username,
                        detail={"reason": "inactive",
                                "user_id": user.user_id})
            raise AuthError(generic)

        if user.is_locked():
            self._note_failure(username)
            self._event("login_blocked", "WARNING", actor=user.username,
                        detail={"reason": "locked",
                                "locked_until": user.locked_until,
                                "user_id": user.user_id})
            raise AuthError(generic)
        if user.locked_until:
            # The lockout window has passed: start the count afresh, or
            # the very next mistake would lock the account again. Saved
            # by the failure path below (or by _issue on success).
            user.clear_lock()

        if not user.check_password(password):
            user.failed_attempts += 1
            reason = "bad_password"
            if user.failed_attempts >= self.max_failed:
                user.lock_for(self.lockout_seconds)
                reason = "locked_out"
            self.store.update(user)
            self._note_failure(username)
            self._event("login_failed", "WARNING", actor=user.username,
                        detail={"reason": reason,
                                "failed_attempts": user.failed_attempts,
                                "user_id": user.user_id})
            if reason == "locked_out":
                self._report_lockout(user)
            raise AuthError(generic)

        self._clear_failures(username)
        if self._password_expired(user):
            # The usual change-at-next-sign-in path: the session can do
            # nothing else until the password is changed (SEC-07).
            user.must_change_password = True
            self.store.update(user)
            self._event("password_expired", "WARNING", actor=user.username,
                        detail={"user_id": user.user_id,
                                "max_age_days": self.max_age_days})
        return self._issue(user, client_info, method="password")

    # ── Waiting after failed sign-ins, lockout (SEC-05, 2026-10-04) ──

    def _wait_left(self, username: str) -> int:
        """Seconds before the next attempt for this username is looked
        at (0 = now)."""
        key = (username or "").strip().lower()
        with self._failures_lock:
            entry = self._failures.get(key)
            if not entry:
                return 0
            left = entry[1] - _time.monotonic()
            if left <= 0:
                return 0
            first_refusal = not entry[2]
            entry[2] = True
        if first_refusal:
            # Once per wait, not for every refused attempt.
            self._event("login_throttled", "WARNING",
                        detail={"username": key,
                                "wait_seconds": int(_math.ceil(left))})
        return int(_math.ceil(left))

    def _note_failure(self, username: str) -> None:
        key = (username or "").strip().lower()
        with self._failures_lock:
            count = self._failures.pop(key, [0])[0] + 1
            while len(self._failures) >= self.FAILURE_TRACK_LIMIT:
                self._failures.pop(next(iter(self._failures)))
            wait = min(2 ** min(count, 16), self.FAILURE_WAIT_MAX_SECONDS)
            self._failures[key] = [count, _time.monotonic() + wait, False]

    def _clear_failures(self, username: str) -> None:
        with self._failures_lock:
            self._failures.pop((username or "").strip().lower(), None)

    def _report_lockout(self, user: AppUser) -> None:
        """Audited, and (by default) an error line, which the e-mail
        alerts send to the administrators."""
        until = user.locked_until[11:16] if user.locked_until else ""
        self._event("account_locked", "WARNING", actor=user.username,
                    detail={"user_id": user.user_id,
                            "locked_until": user.locked_until,
                            "failed_attempts": user.failed_attempts})
        if self.lockout_alert and self.logger:
            self.logger.error(
                f"Console account '{user.username}' was locked after "
                f"{user.failed_attempts} failed sign-in attempts, until "
                f"{until} JST. If the account holder did not cause this, "
                f"someone may be guessing passwords. An administrator can "
                f"unlock it on the Users page.")

    def unlock(self, user: AppUser) -> bool:
        """Lift a lock and the failed-attempt count. True when there was
        something to lift. The caller audits it."""
        had = bool(user.is_locked() or user.failed_attempts)
        user.clear_lock()
        self.store.update(user)
        self._clear_failures(user.username)
        return had

    # ── Earlier passwords and expiry (SEC-07, 2026-10-04) ──

    def _history(self, user_id: str) -> list:
        if self.settings is None:
            return []
        try:
            raw = self.settings.all().get(self.HISTORY_KEY.format(user_id))
            entries = _json.loads(raw) if raw else []
            return [e for e in entries if isinstance(e, dict)]
        except Exception:
            return []

    def remember_password(self, user: AppUser) -> None:
        """Keep the hash of the password just set, with the date, so
        that a later change can refuse it again and expiry can be
        counted. At least the newest entry is kept."""
        if self.settings is None or not user.password_hash:
            return
        entries = [{"h": user.password_hash, "s": user.password_salt,
                    "at": now_jst().isoformat()}] + self._history(
                        user.user_id)
        try:
            self.settings.set(self.HISTORY_KEY.format(user.user_id),
                              _json.dumps(
                                  entries[:max(self.history_size, 1)]),
                              actor="system")
        except Exception as e:
            if self.logger:
                self.logger.warning(f"Password history not kept: "
                                    f"{type(e).__name__}")

    def forget_passwords(self, user_id: str) -> None:
        if self.settings is not None:
            try:
                self.settings.clear(self.HISTORY_KEY.format(user_id))
            except Exception:
                pass

    def _reused(self, user: AppUser, new: str) -> bool:
        from src.modules.auth.models import verify_password
        if self.history_size <= 0:
            return False
        return any(verify_password(new, e.get("h", ""), e.get("s", ""))
                   for e in self._history(user.user_id)[:self.history_size])

    def password_changed_at(self, user: AppUser) -> str:
        """When the password was last set: the newest history entry,
        else the account's creation."""
        history = self._history(user.user_id)
        return (history[0].get("at") if history else "") \
            or user.created_at or ""

    def _password_expired(self, user: AppUser) -> bool:
        if self.max_age_days <= 0 or user.must_change_password:
            return False
        try:
            changed = datetime.fromisoformat(self.password_changed_at(user))
        except (TypeError, ValueError):
            return False
        return now_jst() - changed > timedelta(days=self.max_age_days)

    def authenticate_windows(self, windows_account: str,
                             client_info: str = "") -> tuple[str, AppUser]:
        """Sign in as the CURRENT Windows account (desktop SSO).

        The caller must have established that the request is local and
        that the account is this process's own — see
        routes.build_router, which refuses SSO off-localhost. Trusting a
        client-supplied username over a network would let anyone claim
        to be an administrator.
        """
        holders = self.store.find_by_windows_account(windows_account)
        if len(holders) > 1:
            # Which account (and role) would this be? Guessing could hand
            # out the wrong rights — refuse until an admin resolves it.
            self._event("login_failed", "WARNING",
                        detail={"windows_account": windows_account,
                                "reason": "ambiguous_mapping",
                                "accounts": [u.username for u in holders]})
            raise AuthError(
                "This Windows account is mapped to more than one console "
                "account — ask an administrator", 403)
        user = holders[0] if holders else None
        if user is None or not user.is_active:
            self._event("login_failed", "WARNING",
                        detail={"windows_account": windows_account,
                                "reason": "no_mapped_account"})
            raise AuthError(
                f"No active console account is mapped to Windows user "
                f"'{windows_account}'.", 403)
        return self._issue(user, client_info, method="windows_sso")

    def _issue(self, user: AppUser, client_info: str, method: str,
               auth_time: int | None = None) -> tuple[str, AppUser]:
        import jwt

        # A real sign-in updates "last sign-in" and is recorded as one.
        # The console renews its session about every 15 minutes; that
        # is not a sign-in (UR-09, 2026-10-03), so dormant accounts can
        # be told from active ones.
        renewal = method == "refresh"
        if not renewal:
            user.clear_lock()
            user.last_login_at = now_jst().isoformat()
            self.store.update(user)

        issued = now_jst()
        expires = issued + timedelta(seconds=self.ttl_seconds)
        # The sign-in time travels with every renewal, and no renewal
        # reaches past the maximum session length (SES-02).
        if auth_time is None:
            auth_time = int(issued.timestamp())
        limit = datetime.fromtimestamp(auth_time + self.max_age_seconds,
                                       tz=issued.tzinfo)
        if limit <= issued:
            raise AuthError(self._max_age_text())
        expires = min(expires, limit)
        session = self.store.create_session(AppSession(
            user_id=user.user_id, issued_at=issued.isoformat(),
            expires_at=expires.isoformat(), client_info=client_info[:200]))

        token = jwt.encode(
            {"sub": user.user_id, "username": user.username,
             "role": user.role, "sid": session.session_id,
             "iat": int(issued.timestamp()),
             "auth_time": int(auth_time),
             "exp": int(expires.timestamp())},
            self.secret, algorithm=JWT_ALGORITHM)
        self._event("session_renewed" if renewal else "login_succeeded",
                    actor=user.username,
                    detail={"role": user.role, "method": method,
                            "user_id": user.user_id,
                            "session_id": session.session_id})
        return token, user

    # ── Session verification ──

    def verify(self, token: str) -> AppUser:
        """Resolve a bearer token to its user.

        The session row is re-checked on EVERY request, so revoking a
        session (logout, deactivation, password change) takes effect
        immediately instead of at the token's natural expiry.
        """
        import jwt

        if not token:
            raise AuthError("Sign-in required")
        try:
            claims = jwt.decode(token, self.secret,
                                algorithms=[JWT_ALGORITHM])
        except jwt.ExpiredSignatureError:
            raise AuthError("Session expired — sign in again")
        except jwt.InvalidTokenError:
            raise AuthError("Invalid session token")

        session = self.store.get_session(claims.get("sid", ""))
        if session is None or not session.is_active():
            raise AuthError("Session is no longer valid")
        if self._past_max_age(claims):
            raise AuthError(self._max_age_text())

        user = self.store.get(claims.get("sub", ""))
        if user is None or not user.is_active:
            raise AuthError("Account is no longer active")
        return user

    def refresh(self, token: str,
                client_info: str = "") -> tuple[str, AppUser]:
        """Exchange a valid session for a fresh one.

        A console window stays open all day; without this an operator
        watching the dashboard is thrown back to the sign-in screen
        mid-shift when the token hits jwt_ttl_seconds. The OLD session
        is revoked as part of the exchange, so a stolen token cannot be
        refreshed alongside the real one.
        """
        user = self.verify(token)          # raises if invalid/revoked
        claims = self.claims(token)
        auth_time = self._auth_time(claims)
        # The old session ends without a "Logout" event: a renewal is
        # not a sign-out, and an access review must not read it as one
        # (UAT-L15, 2026-10-04).
        self.store.revoke_session(claims.get("sid", ""))
        return self._issue(user, client_info, method="refresh",
                           auth_time=auth_time)

    # ── Session length (SES-02, 2026-10-04) ──

    def claims(self, token: str) -> dict:
        """The claims of a token that verifies ({} when it does not)."""
        import jwt
        try:
            return jwt.decode(token, self.secret,
                              algorithms=[JWT_ALGORITHM])
        except jwt.InvalidTokenError:
            return {}

    @staticmethod
    def _auth_time(claims: dict) -> int:
        """When the person signed in. A token issued before this change
        has no auth_time; its issue time is the best there is."""
        return int(claims.get("auth_time") or claims.get("iat") or 0)

    def _past_max_age(self, claims: dict) -> bool:
        started = self._auth_time(claims)
        return bool(started) and (
            now_jst().timestamp() - started >= self.max_age_seconds)

    def _max_age_text(self) -> str:
        hours = self.max_age_seconds // 3600
        return (f"The session reached its maximum length of {hours} "
                f"hour(s) — sign in again")

    def logout(self, token: str) -> bool:
        import jwt
        try:
            claims = jwt.decode(token, self.secret,
                                algorithms=[JWT_ALGORITHM],
                                options={"verify_exp": False})
        except jwt.InvalidTokenError:
            return False
        revoked = self.store.revoke_session(claims.get("sid", ""))
        if revoked:
            self._event("logout", actor=claims.get("username", ""),
                        detail={"session_id": claims.get("sid", ""),
                                "user_id": claims.get("sub", "")})
        return revoked

    # ── Password management ──

    def change_password(self, user: AppUser, current: str,
                        new: str) -> None:
        from src.modules.auth.models import password_problems

        if not user.check_password(current):
            self._event("password_change_failed", "WARNING",
                        actor=user.username,
                        detail={"reason": "current_password_wrong",
                                "user_id": user.user_id})
            raise AuthError("Current password is incorrect", 403)
        if user.check_password(new):
            # Re-using the current password would clear a provisional
            # (admin-set) password without actually replacing it.
            self._event("password_change_failed", "WARNING",
                        actor=user.username,
                        detail={"reason": "same_as_current",
                                "user_id": user.user_id})
            raise AuthError(
                "New password must differ from the current password", 400)
        problems = password_problems(
            new, int(getattr(self.cfg, "auth_min_password_length", 12)),
            username=user.username)
        if problems:
            raise AuthError("Password " + "; ".join(problems), 400)
        if self._reused(user, new):
            self._event("password_change_failed", "WARNING",
                        actor=user.username,
                        detail={"reason": "recently_used",
                                "user_id": user.user_id})
            raise AuthError(
                f"New password must not be one of your last "
                f"{self.history_size} passwords", 400)

        user.set_password(new)
        self.store.update(user)
        self.remember_password(user)
        # Every session for this user — the caller's own included — dies
        # with the old password; the console signs in again afterwards.
        self.store.revoke_all_for_user(user.user_id)
        self._event("password_changed", actor=user.username,
                    detail={"user_id": user.user_id})
        if self.on_password_changed is not None:
            try:
                self.on_password_changed(user)
            except Exception as e:
                if self.logger:
                    self.logger.warning(
                        f"Post-password-change step failed: "
                        f"{type(e).__name__}")

    # ── Permissions ──

    def permissions_for(self, user: AppUser) -> list[str]:
        """What this user's role currently grants.

        Resolved from the ROLE on every request rather than baked into
        the token: editing a role must take effect immediately, not
        when the holder's session happens to expire.
        """
        return self.store.permissions_for(user.role)

    def require(self, user: AppUser, permission: str) -> bool:
        return user.has_permission(permission,
                                   self.permissions_for(user))

    # ── First-run seeding ──

    def seed_default_admin(self) -> AppUser | None:
        """Create the default administrator on a fresh install.

        Returns the user when one was created, None when the install
        already has accounts (so this can never add a second admin, or
        resurrect one that was deliberately deleted).

        The seeded password is PROVISIONAL: must_change_password is set,
        so it opens nothing until the operator chooses their own.
        """
        if not getattr(self.cfg, "auth_seed_default_admin", False):
            return None
        if self.store.count() > 0:
            return None

        username = getattr(self.cfg, "auth_default_admin_username",
                           "admin")
        password = getattr(self.cfg, "auth_default_admin_password",
                           "ChangeMe!2026")
        user = AppUser(username=username, display_name="Administrator",
                       role=Role.ADMIN.value, created_by="system")
        user.set_password(password)
        user.must_change_password = True      # unusable until changed
        self.store.create(user)
        self.remember_password(user)
        self._event("default_admin_seeded", "WARNING",
                    actor=user.username)
        if self.logger:
            self.logger.warning(
                f"Seeded the default administrator '{username}'. Its "
                f"password MUST be changed at first sign-in — every "
                f"route is refused until then.")
        return user

    def initial_admin_pending(self) -> AppUser | None:
        """The seeded administrator while it still has its initial
        password (SEC-06, 2026-10-04): until it is changed, whoever
        knows that password can take the account."""
        username = getattr(self.cfg, "auth_default_admin_username",
                           "admin")
        try:
            user = self.store.get_by_username(username)
        except Exception:
            return None
        if user is not None and user.created_by == "system" \
                and user.must_change_password and user.is_active:
            return user
        return None

    def needs_bootstrap(self) -> bool:
        """True while the install has no accounts at all — the UI shows
        a 'create the first administrator' screen."""
        return self.store.count() == 0

    def bootstrap_admin(self, username: str, password: str,
                        display_name: str = "") -> AppUser:
        """Create the FIRST administrator. Refuses once any account
        exists, so this can never be used to add a second one."""
        from src.modules.auth.models import password_problems

        if not self.needs_bootstrap():
            raise AuthError(
                "This installation is already initialised", 409)
        problems = password_problems(
            password, int(getattr(self.cfg,
                                  "auth_min_password_length", 12)),
            username=username)
        if problems:
            raise AuthError("Password " + "; ".join(problems), 400)

        user = AppUser(username=username, display_name=display_name,
                       role=Role.ADMIN.value, created_by="bootstrap")
        user.set_password(password)
        self.store.create(user)
        self.remember_password(user)
        self._event("bootstrap_admin_created", "WARNING",
                    actor=user.username)
        if self.logger:
            self.logger.warning(
                f"First administrator '{user.username}' created")
        return user


def current_windows_account() -> str:
    """The Windows account this process is running as, or "".

    Read from the OS — never from a request. Empty everywhere except
    Windows, which is why password sign-in stays the baseline.
    """
    if sys.platform != "win32":
        return ""
    try:
        import win32api                       # type: ignore
        return win32api.GetUserNameEx(2)      # NameSamCompatible
    except Exception:
        pass
    domain = os.environ.get("USERDOMAIN", "")
    user = os.environ.get("USERNAME", "")
    return f"{domain}\\{user}" if domain and user else user


def build_console_dependency(auth_service, required_role: str,
                             allow_provisional: bool = False):
    """FastAPI dependency enforcing 'signed in, with at least this role'.

    Independent of build_auth_dependency: the machine API key does not
    grant console access, and a console session does not grant the API
    key's scope.

    A user still holding an ADMIN-SET password (must_change_password)
    is refused everywhere except the change-password route itself
    (allow_provisional). Without that the flag would be decorative:
    an operator could keep using a credential someone else chose for
    them indefinitely.
    """
    from fastapi import Header, HTTPException

    def require_console_user(
            authorization: str = Header(default="")) -> AppUser:
        token = ""
        if authorization.lower().startswith(_BEARER):
            token = authorization[len(_BEARER):].strip()
        try:
            user = auth_service.verify(token)
        except AuthError as e:
            raise HTTPException(status_code=e.status_code, detail=str(e))
        if user.must_change_password and not allow_provisional:
            raise HTTPException(
                status_code=428,        # Precondition Required
                detail=("Your password was set by an administrator and "
                        "must be changed before you can continue"))
        if not user.can(required_role):
            raise HTTPException(
                status_code=403,
                detail=(f"This action requires the '{required_role}' "
                        f"role; you have '{user.role}'"))
        return user

    return require_console_user


def build_session_dependency(auth_service,
                             allow_provisional: bool = False):
    """Signed in — nothing more.

    For the two routes EVERY account must reach whatever its role:
    seeing who you are, and changing your own password. Requiring a
    role here locked out anyone on a CUSTOM role, because a custom role
    has no rank: they held a provisional password and could not reach
    the one endpoint that clears it.
    """
    from fastapi import Header, HTTPException

    def require_session(
            authorization: str = Header(default="")) -> AppUser:
        token = ""
        if authorization.lower().startswith(_BEARER):
            token = authorization[len(_BEARER):].strip()
        try:
            user = auth_service.verify(token)
        except AuthError as e:
            raise HTTPException(status_code=e.status_code, detail=str(e))
        if user.must_change_password and not allow_provisional:
            raise HTTPException(
                status_code=428,
                detail=("Your password was set by an administrator and "
                        "must be changed before you can continue"))
        return user

    return require_session


def build_permission_dependency(auth_service, permission: str):
    """FastAPI dependency: signed in AND holding `permission`.

    Asks for a PERMISSION, never a role name, so defining a custom role
    never requires touching a route. Permissions are resolved from the
    role on EVERY request, so editing a role takes effect immediately
    rather than when the holder's token happens to expire.
    """
    from fastapi import Header, HTTPException

    def require_permission(
            authorization: str = Header(default="")) -> AppUser:
        token = ""
        if authorization.lower().startswith(_BEARER):
            token = authorization[len(_BEARER):].strip()
        try:
            user = auth_service.verify(token)
        except AuthError as e:
            raise HTTPException(status_code=e.status_code, detail=str(e))
        if user.must_change_password:
            raise HTTPException(
                status_code=428,
                detail=("Your password was set by an administrator and "
                        "must be changed before you can continue"))
        if not auth_service.require(user, permission):
            raise HTTPException(
                status_code=403,
                detail=(f"Your role '{user.role}' does not include the "
                        f"'{permission}' permission"))
        return user

    return require_permission


def build_action_dependency(auth_service, cfg, required_permission: str):
    """Guard an ACTION route that both machines and people can call.

    retry and cancel are reachable two ways:

      * the machine API key — the service identity used by the
        ServiceNow connector and the CLI. It already carries full
        service scope, so it passes through EXACTLY as before. This is
        what keeps the existing contract intact.
      * a console session — a person, who must hold
        `required_permission`. Without this a "viewer" could retry
        transactions from the UI, which is the whole point of roles.

    A request with neither is left to the API-key dependency to reject.
    """
    from fastapi import Header, HTTPException

    def check(authorization: str = Header(default=""),
              x_api_key: str = Header(default="")) -> str:
        if x_api_key:
            # The machine: the ServiceNow connector sends its key as
            # X-API-Key AND as a Bearer header (2026-10-03). The key was
            # verified by the API-key dependency when API keys are on; a
            # person signed into the console sends no X-API-Key.
            return "service"
        if not authorization.lower().startswith(_BEARER):
            # No console token: either an API-key caller (already
            # authorised by auth_dep) or auth is off entirely.
            return "service"
        if auth_service is None:
            raise HTTPException(
                status_code=401,
                detail="Console sign-in is not enabled on this service")
        token = authorization[len(_BEARER):].strip()
        try:
            user = auth_service.verify(token)
        except AuthError as e:
            raise HTTPException(status_code=e.status_code, detail=str(e))
        # Same gate as build_console_dependency: an admin-set password
        # grants NOTHING until it is changed. Checked before the role,
        # or an operator could retry work while still holding a
        # credential somebody else chose for them.
        if user.must_change_password:
            raise HTTPException(
                status_code=428,
                detail=("Your password was set by an administrator and "
                        "must be changed before you can continue"))
        if not auth_service.require(user, required_permission):
            raise HTTPException(
                status_code=403,
                detail=(f"Your role '{user.role}' does not include the "
                        f"'{required_permission}' permission"))
        # The same "user:<name>" as a submission (UAT-L24, 2026-10-04).
        return f"user:{user.username}"

    return check
