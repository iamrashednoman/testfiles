"""Persistence for admin users and their sessions.

Follows the existing store pattern exactly (QueueStore /
TransactionStore): explicit SQL, '?' placeholders translated per
engine, and bootstrap DDL skipped when the schema was applied by a DBA
from scripts/schema.sql — in that deployment the service role does not
own the tables and even a no-op CREATE fails Postgres's ownership check.
"""
from __future__ import annotations

import threading

from src.core.db import Database
from src.modules.auth.models import (
    AppRole, AppSession, AppUser, Role, now_jst,
)
from src.modules.auth.permissions import BUILTIN_ROLES

_USER_COLUMNS = (
    "user_id", "username", "display_name", "email", "password_hash",
    "password_salt", "auth_source", "windows_account", "role",
    "is_active", "must_change_password", "failed_attempts",
    "locked_until", "last_login_at", "created_at", "created_by",
    "updated_at",
)


class SchemaUnavailableError(Exception):
    """The console tables are absent AND cannot be created here.

    The production Postgres deployment deliberately does not let the
    service role own its tables (append-only enforcement — see
    scripts/schema.sql), so a fresh install of this feature needs the
    DBA to apply the DDL. Raised rather than swallowed so the caller
    can disable the console with an actionable message instead of the
    whole service failing to start.
    """


class UserStore:
    def __init__(self, db: Database):
        self.db = db
        self._lock = threading.Lock()
        self._ensure_schema()

    def _ensure_schema(self) -> None:
        """Create only the tables that are MISSING.

        Two reasons this is per-table rather than all-or-nothing:

        * an install from an earlier release already has app_users, so
          a single "if app_users exists: return" guard would leave
          app_roles permanently absent;
        * on the production Postgres the service role does NOT own its
          tables, and re-issuing CREATE against one it does not own
          fails the ownership check even with IF NOT EXISTS.
        """
        builders = {
            "app_users": self._create_users,
            "app_sessions": self._create_sessions,
            "app_roles": self._create_roles,
        }
        missing = [t for t in builders if not self.db.table_exists(t)]
        if not missing:
            return
        try:
            with self.db.connect() as conn:
                for table in missing:
                    builders[table](conn)
        except Exception as e:
            raise SchemaUnavailableError(
                f"the console table(s) {', '.join(missing)} do not "
                f"exist and could not be created ({e})") from e

    @staticmethod
    def _create_users(conn) -> None:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS app_users (
                user_id              TEXT PRIMARY KEY,
                username             TEXT NOT NULL UNIQUE,
                display_name         TEXT DEFAULT '',
                email                TEXT DEFAULT '',
                password_hash        TEXT DEFAULT '',
                password_salt        TEXT DEFAULT '',
                auth_source          TEXT DEFAULT 'local',
                windows_account      TEXT DEFAULT '',
                role                 TEXT NOT NULL DEFAULT 'viewer',
                is_active            INTEGER DEFAULT 1,
                must_change_password INTEGER DEFAULT 0,
                failed_attempts      INTEGER DEFAULT 0,
                locked_until         TEXT DEFAULT '',
                last_login_at        TEXT DEFAULT '',
                created_at           TEXT NOT NULL,
                created_by           TEXT DEFAULT '',
                updated_at           TEXT DEFAULT ''
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_users_windows "
                     "ON app_users(windows_account)")

    @staticmethod
    def _create_sessions(conn) -> None:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS app_sessions (
                session_id  TEXT PRIMARY KEY,
                user_id     TEXT NOT NULL,
                issued_at   TEXT NOT NULL,
                expires_at  TEXT NOT NULL,
                revoked_at  TEXT DEFAULT '',
                client_info TEXT DEFAULT ''
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_sessions_user "
                     "ON app_sessions(user_id)")

    @staticmethod
    def _create_roles(conn) -> None:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS app_roles (
                name        TEXT PRIMARY KEY,
                description TEXT DEFAULT '',
                permissions TEXT DEFAULT '[]',
                is_builtin  INTEGER DEFAULT 0,
                created_at  TEXT NOT NULL,
                created_by  TEXT DEFAULT '',
                updated_at  TEXT DEFAULT ''
            )
        """)

    # ── Users ──

    def count(self) -> int:
        row = self.db.fetchone("SELECT COUNT(*) AS n FROM app_users")
        return int(row["n"]) if row else 0

    def create(self, user: AppUser) -> AppUser:
        data = user.to_dict()
        cols = ", ".join(_USER_COLUMNS)
        marks = ", ".join("?" for _ in _USER_COLUMNS)
        with self._lock:
            if self.get_by_username(user.username) is not None:
                raise ValueError(f"User '{user.username}' already exists")
            # One Windows account signs in as ONE console account; a
            # second mapping would make SSO pick whichever row came first.
            if user.windows_account:
                holders = self.find_by_windows_account(user.windows_account)
                if holders:
                    raise ValueError(
                        f"Windows account '{user.windows_account}' is "
                        f"already mapped to '{holders[0].username}'")
            self.db.execute(
                f"INSERT INTO app_users ({cols}) VALUES ({marks})",
                tuple(data[c] for c in _USER_COLUMNS))
        return user

    def get(self, user_id: str) -> AppUser | None:
        row = self.db.fetchone(
            "SELECT * FROM app_users WHERE user_id = ?", (user_id,))
        return AppUser.from_row(row) if row else None

    def get_by_username(self, username: str) -> AppUser | None:
        row = self.db.fetchone(
            "SELECT * FROM app_users WHERE username = ?",
            ((username or "").strip().lower(),))
        return AppUser.from_row(row) if row else None

    def get_by_windows_account(self, account: str) -> AppUser | None:
        """SSO lookup. Case-insensitive: Windows is. The first match —
        use find_by_windows_account to see every holder."""
        holders = self.find_by_windows_account(account)
        return holders[0] if holders else None

    def find_by_windows_account(self, account: str) -> list[AppUser]:
        """EVERY account mapped to this Windows account (case-insensitive,
        surrounding spaces ignored). More than one means an ambiguous
        mapping left over from before duplicates were refused."""
        wanted = (account or "").strip().lower()
        if not wanted:
            return []
        return [AppUser.from_row(row) for row in self.db.fetchall(
                    "SELECT * FROM app_users WHERE windows_account <> '' "
                    "ORDER BY username")
                if (row["windows_account"] or "").strip().lower() == wanted]

    def list_users(self) -> list[AppUser]:
        return [AppUser.from_row(r) for r in self.db.fetchall(
            "SELECT * FROM app_users ORDER BY username")]

    def update(self, user: AppUser) -> AppUser:
        user.updated_at = now_jst().isoformat()
        data = user.to_dict()
        assignments = ", ".join(
            f"{c} = ?" for c in _USER_COLUMNS if c != "user_id")
        params = tuple(data[c] for c in _USER_COLUMNS if c != "user_id")
        with self._lock:
            self.db.execute(
                f"UPDATE app_users SET {assignments} WHERE user_id = ?",
                params + (user.user_id,))
        return user

    def delete(self, user_id: str) -> bool:
        with self._lock:
            changed = self.db.execute(
                "DELETE FROM app_users WHERE user_id = ?", (user_id,))
        self.revoke_all_for_user(user_id)
        return bool(changed)

    def count_active_admins(self, excluding: str = "") -> int:
        """Guards the last-administrator rule: an install must never be
        left with nobody who can manage it."""
        return sum(
            1 for u in self.list_users()
            if u.role == Role.ADMIN.value and u.is_active
            and u.user_id != excluding)

    # ── Sessions ──

    def create_session(self, session: AppSession) -> AppSession:
        d = session.to_dict()
        self.db.execute(
            "INSERT INTO app_sessions (session_id, user_id, issued_at, "
            "expires_at, revoked_at, client_info) VALUES (?,?,?,?,?,?)",
            (d["session_id"], d["user_id"], d["issued_at"],
             d["expires_at"], d["revoked_at"], d["client_info"]))
        return session

    def get_session(self, session_id: str) -> AppSession | None:
        row = self.db.fetchone(
            "SELECT * FROM app_sessions WHERE session_id = ?",
            (session_id,))
        return AppSession(**dict(row)) if row else None

    def revoke_session(self, session_id: str) -> bool:
        return bool(self.db.execute(
            "UPDATE app_sessions SET revoked_at = ? "
            "WHERE session_id = ? AND revoked_at = ''",
            (now_jst().isoformat(), session_id)))

    def revoke_all_for_user(self, user_id: str) -> int:
        """Used on deactivate/delete/password-change: an existing token
        must stop working immediately, not at its natural expiry."""
        return self.db.execute(
            "UPDATE app_sessions SET revoked_at = ? "
            "WHERE user_id = ? AND revoked_at = ''",
            (now_jst().isoformat(), user_id))

    def list_active_sessions(self) -> list[dict]:
        """Sessions not ended and not expired, newest first, each with
        its account's username (SES-06, 2026-10-04)."""
        rows = self.db.fetchall(
            "SELECT s.session_id, s.user_id, s.issued_at, s.expires_at, "
            "s.client_info, u.username, u.display_name, u.role "
            "FROM app_sessions s LEFT JOIN app_users u "
            "ON u.user_id = s.user_id "
            "WHERE s.revoked_at = '' AND s.expires_at > ? "
            "ORDER BY s.issued_at DESC", (now_jst().isoformat(),))
        return [dict(r) for r in rows]

    def purge_expired_sessions(self) -> int:
        return self.db.execute(
            "DELETE FROM app_sessions WHERE expires_at < ?",
            (now_jst().isoformat(),))


    # ── Roles ──

    def ensure_builtin_roles(self) -> int:
        """Seed viewer/operator/admin, and keep their permissions
        current.

        Built-ins are RESET to the catalogue on every start: they are
        code, not configuration, so a new permission added in a release
        reaches admin without a migration. Custom roles are never
        touched.
        """
        if not self.db.table_exists("app_roles"):
            return 0
        seeded = 0
        for name, spec in BUILTIN_ROLES.items():
            role = AppRole(name=name, description=spec["description"],
                           permissions=spec["permissions"],
                           is_builtin=True, created_by="system")
            existing = self.get_role(name)
            if existing is None:
                self.create_role(role)
                seeded += 1
            elif existing.permissions != role.permissions:
                self.update_role(role)
        return seeded

    def create_role(self, role: AppRole) -> AppRole:
        d = role.to_dict()
        with self._lock:
            if self.get_role(role.name) is not None:
                raise ValueError(f"Role '{role.name}' already exists")
            self.db.execute(
                "INSERT INTO app_roles (name, description, permissions, "
                "is_builtin, created_at, created_by, updated_at) "
                "VALUES (?,?,?,?,?,?,?)",
                (d["name"], d["description"], d["permissions"],
                 d["is_builtin"], d["created_at"], d["created_by"],
                 d["updated_at"]))
        return role

    def get_role(self, name: str) -> AppRole | None:
        row = self.db.fetchone(
            "SELECT * FROM app_roles WHERE name = ?",
            ((name or "").strip().lower(),))
        return AppRole.from_row(row) if row else None

    def list_roles(self) -> list[AppRole]:
        return [AppRole.from_row(r) for r in self.db.fetchall(
            "SELECT * FROM app_roles ORDER BY is_builtin DESC, name")]

    def update_role(self, role: AppRole) -> AppRole:
        role.updated_at = now_jst().isoformat()
        d = role.to_dict()
        with self._lock:
            self.db.execute(
                "UPDATE app_roles SET description = ?, permissions = ?, "
                "updated_at = ? WHERE name = ?",
                (d["description"], d["permissions"], d["updated_at"],
                 d["name"]))
        return role

    def delete_role(self, name: str) -> bool:
        with self._lock:
            return bool(self.db.execute(
                "DELETE FROM app_roles WHERE name = ? AND is_builtin = 0",
                ((name or "").strip().lower(),)))

    def count_users_with_role(self, name: str) -> int:
        row = self.db.fetchone(
            "SELECT COUNT(*) AS n FROM app_users WHERE role = ?",
            ((name or "").strip().lower(),))
        return int(row["n"]) if row else 0

    def permissions_for(self, role_name: str) -> list[str]:
        """The permissions a role grants, or [] if it no longer exists.

        Returning [] rather than raising is deliberate: if a role is
        deleted out from under a signed-in user, they lose access
        rather than gaining an unchecked session.
        """
        role = self.get_role(role_name)
        return list(role.permissions) if role else []
