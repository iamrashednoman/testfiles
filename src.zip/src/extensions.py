"""Thread-safe shared runtime instances (control plane).

Created once by the application factory and injected into modules —
business code never imports these at module top-level, so tests can
substitute their own instances.
"""
from __future__ import annotations

from typing import Optional

from src.core.db import Database

db: Optional[Database] = None


def init_extensions(cfg) -> Database:
    """Create shared instances. Called exactly once from create_app()."""
    global db
    db = Database.from_config(cfg)
    return db
