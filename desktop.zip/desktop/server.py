"""The embedded API service, started and stopped by the desktop shell.

Runs the EXISTING FastAPI app on a background thread bound to
127.0.0.1. Nothing about the service changes: create_app() is called
exactly as `python run.py` calls it, so the dispatcher, workflows,
error catalogue and audit trail behave identically.

Why a class rather than uvicorn.run(): the window needs to STOP the
service (to quit, or to restart it after a settings change) and must be
able to wait for a transaction that is mid-flight on the mainframe.
uvicorn.run() blocks forever and offers no handle to do either.
"""
from __future__ import annotations

import socket
import threading
import time
import urllib.error
import urllib.request


def mount_console_ui(app, logger=None, *, mode: str = "embedded",
                     stop_hook=None) -> bool:
    """Serve the console's static files — and the desktop-only
    /api/v1/system routes — from the running app.

    Mounted here rather than in create_app so the API service stays
    exactly what it is today for `python run.py` and Docker. Shared by
    the window (embedded mode) and the background agent, so both serve
    the identical UI. Returns False when the assets are missing.

    Order matters: the system router must be included BEFORE the "/"
    static mount, or the mount would swallow its paths.
    """
    from fastapi.staticfiles import StaticFiles

    from desktop.system_api import mount_system_api
    from src.core.app_paths import resource_path

    # Lets routes that care (Windows SSO) know whether this process is
    # the shared background agent or a single user's embedded window.
    app.state.desktop_mode = mode
    mount_system_api(app, mode=mode, stop_hook=stop_hook, logger=logger)

    ui_dir = resource_path("desktop", "ui")
    if not ui_dir.is_dir():
        if logger:
            logger.warning(f"Console UI assets not found at {ui_dir}")
        return False
    app.mount("/", _RevalidatedStaticFiles(directory=str(ui_dir), html=True),
              name="console")
    return True


try:
    from fastapi.staticfiles import StaticFiles as _StaticFiles
except Exception:                                    # pragma: no cover
    _StaticFiles = object


class _RevalidatedStaticFiles(_StaticFiles):
    """The console's files with "Cache-Control: no-cache" (2026-09-28).

    Without it a browser may keep an old copy of the page after an
    upgrade and show new content with an old layout. "no-cache" does
    not disable caching: the browser still keeps the files and only
    asks whether they changed (answered "not modified" when they did
    not), so pages stay fast."""

    async def get_response(self, path, scope):
        response = await super().get_response(path, scope)
        response.headers["Cache-Control"] = "no-cache"
        return response


class EmbeddedService:
    """Owns the uvicorn server thread and the app it serves."""

    def __init__(self, cfg, logger=None, cfg_factory=None):
        """cfg_factory: how restart() obtains a FRESH configuration.
        Defaults to re-reading the process configuration (environment
        + .env + stored overrides) with the get_config cache cleared —
        without the clear, a restart reused the same mutated object and
        a cleared override never actually fell back."""
        self.cfg = cfg
        self.logger = logger
        self._cfg_factory = cfg_factory or self._fresh_process_config
        self.app = None
        self.port = 0
        self._server = None
        self._thread = None
        self._restart_requested = threading.Event()

    # ── Address ──

    @staticmethod
    def pick_port(preferred: int = 8000) -> int:
        """The configured port when free, otherwise an ephemeral one.

        A desktop app must never fail to start because something else
        holds 8000 — including a previous copy of itself that has not
        finished releasing the socket.
        """
        for candidate in (preferred, 0):
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                try:
                    s.bind(("127.0.0.1", candidate))
                    return s.getsockname()[1]
                except OSError:
                    continue
        raise RuntimeError("No free local port available")

    @property
    def base_url(self) -> str:
        return f"http://127.0.0.1:{self.port}"

    # ── Lifecycle ──

    def start(self, port: int = 0) -> str:
        """Build the app and serve it. Returns the base URL."""
        import uvicorn

        from src import create_app

        self.port = port or self.pick_port(self.cfg.api_port)
        if not port and self.port != self.cfg.api_port \
                and getattr(self.cfg, "api_port_strict", False):
            raise RuntimeError(
                f"Port {self.cfg.api_port} is in use by another program, and "
                f"'Refuse another port' is on: the service does not start "
                f"on another port. Free port {self.cfg.api_port}, or switch "
                f"the setting off (Settings > This machine).")
        # The console asks for a restart through this; the actual work
        # happens on a watcher thread, because the request that asks
        # for it is being served BY the server about to stop.
        self.app = create_app(self.cfg,
                              restart_hook=self._restart_requested.set)
        self._server = uvicorn.Server(uvicorn.Config(
            self.app, host="127.0.0.1", port=self.port,
            log_config=None, lifespan="on"))
        # Not a daemon: a daemon thread is killed at interpreter exit,
        # which would abandon a transaction on the terminal. Shutdown is
        # explicit and waited for.
        self._thread = threading.Thread(
            target=self._server.run, name="finesiii-api", daemon=False)
        self._thread.start()
        return self.base_url

    def wait_until_ready(self, timeout: float = 60.0) -> bool:
        """Poll /ping until the service answers.

        /ping rather than /health: /health requires the machine API key
        when auth is on, and the shell holds none — polling it made an
        auth-enabled desktop time out here and never open its window.

        Generous by default: the first start of an OCR-bearing build
        loads several hundred MB of models before the API binds.
        """
        deadline = time.time() + timeout
        url = f"{self.base_url}/api/v1/ping"
        while time.time() < deadline:
            if self._thread is not None and not self._thread.is_alive():
                return False            # the server died on startup
            try:
                with urllib.request.urlopen(url, timeout=2) as r:
                    if r.status == 200:
                        return True
            except (urllib.error.URLError, OSError):
                time.sleep(0.25)
        return False

    # ── Draining ──

    def is_busy(self) -> bool:
        """True while a transaction is in flight on the terminal."""
        try:
            dispatcher = getattr(self.app.state, "dispatcher", None)
            return bool(dispatcher and dispatcher.status().get("busy"))
        except Exception:
            return False

    def stop(self, drain_timeout: float | None = None) -> bool:
        """Stop the service, letting an in-flight transaction finish.

        Returns True on a clean stop. Setting should_exit runs uvicorn's
        shutdown, which runs the app's lifespan exit, which calls
        dispatcher.stop() — the SAME graceful drain the service performs
        on SIGTERM today. Killing the thread instead would abandon a
        half-finished operation on the mainframe, which is exactly what
        the drain exists to prevent.
        """
        if self._server is None:
            return True
        if drain_timeout is None:
            drain_timeout = float(
                getattr(self.cfg, "drain_seconds", 300)) + 30.0

        if self.is_busy() and self.logger:
            self.logger.info(
                "Waiting for the in-flight transaction to finish before "
                "shutting down…")

        self._server.should_exit = True
        if self._thread is not None:
            self._thread.join(timeout=drain_timeout)
            if self._thread.is_alive():
                if self.logger:
                    self.logger.warning(
                        f"Service did not stop within {drain_timeout:.0f}s "
                        f"— a transaction may be interrupted; it will be "
                        f"recovered on next startup")
                return False
        self._server, self._thread = None, None
        return True

    def restart(self) -> str:
        """Stop and rebuild on the SAME port.

        Used after a configuration change: most settings are read once
        at startup (RetryPolicy, the alerters, AvailabilityMonitor), so
        a rebuild is what makes them take effect. A fresh config object
        is built so the stored overrides are re-read.
        """
        port = self.port
        self.stop()
        self.cfg = self._cfg_factory()
        self._restart_requested.clear()
        return self.start(port=port)

    @staticmethod
    def _fresh_process_config():
        """Re-read configuration from scratch. get_config() is
        lru_cached (one object per process); clearing it is what makes
        a stored override that was CLEARED in the console fall back to
        the environment value on the rebuild."""
        from config import get_config
        from desktop.deployment import apply_service_defaults

        get_config.cache_clear()
        # The same posture as the first start: start even when not fully
        # configured, audit trail on by default (2026-10-04).
        return apply_service_defaults(get_config())

    @property
    def restart_requested(self) -> bool:
        return self._restart_requested.is_set()
