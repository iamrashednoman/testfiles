/* FINES III RPA console — shared interface pieces (2026-09-28).
 *
 *   LABELS / label()   business names for statuses, categories, …
 *   fmt*               dates, durations, numbers
 *   tipButton()        an accessible "i" tooltip
 *   Drawer             the row-details side panel
 *   DataTable          server-side paging, sorting, search, filters,
 *                      column choice and row details for any list API
 *   Charts             column, line, horizontal-bar and donut charts
 *                      drawn as SVG — no library, no CDN, works offline
 *
 * Every text reaches the page through textContent / createTextNode, never
 * innerHTML, so data from tickets or the audit trail cannot inject markup.
 */
'use strict';

/* ── labels ───────────────────────────────────────────────────────── */
const LABELS = {
  status: {
    queued: 'Queued', running: 'In progress', done: 'Completed',
    failed: 'Failed', already_deleted: 'Already removed',
    cancelled: 'Cancelled'
  },
  operation: { provision: 'Provision', deprovision: 'Deprovision' },
  // 'manual': typed on the console, or sent through the API without a
  // source (UAT-L09, 2026-10-04).
  source: { servicenow: 'ServiceNow', manual: 'Console or API (not specified)', api: 'API',
            cli: 'Command line', sailpoint: 'SailPoint' },
  category: {
    api: 'API', dispatch: 'Processing', rpa_action: 'Bot action',
    rpa_screen: 'Screen', rpa_error: 'Screen error', rpa: 'Bot',
    auth: 'Sign-in', console: 'Console', servicenow: 'ServiceNow',
    system: 'System', notification: 'E-mail', log: 'Log',
    evidence: 'Evidence'
  },
  severity: { INFO: 'Information', WARNING: 'Warning', ERROR: 'Error',
              CRITICAL: 'Critical', DEBUG: 'Debug' },
  driver: {
    simulator: 'Simulator', mock: 'Test double',
    sim_terminal: 'Terminal simulator', pywinauto: 'FINESIII terminal',
    pyautogui: 'Screen automation', tn3270: 'TN3270 terminal'
  },
  environment: { development: 'Development', production: 'Production' },
  engine: { postgres: 'PostgreSQL', sqlite: 'SQLite' },
  kind: {
    new_account: 'New account', access_removal: 'Access removal',
    entitlement_certification: 'Entitlement certification',
    account_certification: 'Account certification',
    transfer: 'Transfer', termination: 'Termination'
  }
};

function humanize(v) {
  const s = String(v ?? '').replace(/[_-]+/g, ' ').trim();
  // Product names keep their spelling (E2E-L05).
  return (s ? s.charAt(0).toUpperCase() + s.slice(1) : '')
    .replace(/\bservicenow\b/gi, 'ServiceNow').replace(/\bcyberark\b/gi, 'CyberArk');
}
function label(group, v) {
  if (v === null || v === undefined || v === '') return '';
  return (LABELS[group] && LABELS[group][v]) || humanize(v);
}

/* ── formatting ───────────────────────────────────────────────────── */
function fmtTime(iso) {
  if (!iso) return '';
  const s = String(iso);
  return s.length >= 19 ? s.slice(0, 10) + ' ' + s.slice(11, 19) : s;
}
function fmtNum(n) {
  if (n === null || n === undefined || n === '') return '—';
  return Number(n).toLocaleString('en-US');
}
function fmtSecs(s) {
  if (s === null || s === undefined || s === '' || isNaN(Number(s))) return '—';
  s = Number(s);
  if (s < 59.5) return `${s.toFixed(s < 10 ? 1 : 0)} s`;
  // Whole seconds first, so 239.6 s reads "4 min", not "3 min 60 s"
  // (UAT-L04, 2026-10-04).
  const total = Math.round(s), m = Math.floor(total / 60), r = total % 60;
  if (m >= 60) return `${Math.floor(m / 60)} h ${m % 60} min`;
  return r ? `${m} min ${r} s` : `${m} min`;
}
function fmtPct(p) {
  return p === null || p === undefined ? '—' : `${Number(p).toFixed(1)}%`;
}

function node(tag, cls, text) {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (text !== undefined && text !== null) n.textContent = text;
  return n;
}

/* Safe per-viewer storage: works without it (private windows, policy). */
const Prefs = {
  get(k, d) {
    try { const v = localStorage.getItem('finesiii.' + k);
          return v === null ? d : JSON.parse(v); } catch (e) { return d; }
  },
  set(k, v) {
    try { localStorage.setItem('finesiii.' + k, JSON.stringify(v)); }
    catch (e) { /* not available — fine */ }
  }
};

/* ── tooltip ──────────────────────────────────────────────────────── */
let TIP_SEQ = 0;
function tipButton(text, about, technical) {
  const b = node('button', 'tip', 'i');
  b.type = 'button';
  const id = 'tip-' + (++TIP_SEQ);
  b.setAttribute('aria-label', 'About ' + (about || 'this item'));
  b.setAttribute('aria-describedby', id);
  const bub = node('span', 'bubble', text || '');
  bub.id = id; bub.setAttribute('role', 'tooltip');
  if (technical) bub.appendChild(node('span', 'key', technical));
  b.appendChild(bub);
  b.onclick = e => e.preventDefault();
  // Open the bubble towards the free side, so it never runs off the
  // screen or makes the page scroll sideways.
  const place = () => {
    const r = b.getBoundingClientRect();
    b.classList.toggle('tip-left', r.left > window.innerWidth - 200);
    b.classList.toggle('tip-right', r.left < 180);
    b.classList.toggle('tip-below', r.top < 140);
  };
  b.addEventListener('mouseenter', place);
  b.addEventListener('focus', place);
  return b;
}

/* ── drawer (row details) ─────────────────────────────────────────── */
/* Keep the keyboard inside an open dialog (X-06, 2026-10-03): Tab and
 * Shift+Tab cycle through its controls while it is shown. */
function trapFocus(container) {
  if (!container || container.dataset.trapped) return;
  container.dataset.trapped = '1';
  container.addEventListener('keydown', e => {
    if (e.key !== 'Tab' || container.classList.contains('hide')) return;
    const items = Array.from(container.querySelectorAll(
      'a[href],button:not([disabled]),input:not([disabled]),select:not([disabled]),' +
      'textarea:not([disabled]),[tabindex]:not([tabindex="-1"])'))
      .filter(x => x.offsetParent !== null);
    if (!items.length) return;
    const first = items[0], last = items[items.length - 1];
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
  });
}

const Drawer = {
  lastFocus: null,
  open(title, sub, build, actions) {
    const d = document.getElementById('drawer');
    this.lastFocus = document.activeElement;
    document.getElementById('dr-title').textContent = title;
    document.getElementById('dr-sub').textContent = sub || '';
    const body = document.getElementById('dr-body');
    const acts = document.getElementById('dr-actions');
    body.textContent = ''; acts.textContent = '';
    build(body);
    (actions || []).forEach(a => acts.appendChild(a));
    acts.classList.toggle('hide', !(actions || []).length);
    trapFocus(d);
    d.classList.remove('hide');
    document.getElementById('drawer-scrim').classList.remove('hide');
    document.getElementById('dr-close').focus();
  },
  close() {
    document.getElementById('drawer').classList.add('hide');
    document.getElementById('drawer-scrim').classList.add('hide');
    if (this.lastFocus && this.lastFocus.focus) this.lastFocus.focus();
  },
  isOpen() { return !document.getElementById('drawer').classList.contains('hide'); }
};

/* A definition list of [label, value] pairs (value: text or a Node). */
function kvList(pairs) {
  const dl = node('dl', 'kv');
  pairs.forEach(([k, v]) => {
    if (v === undefined || v === null || v === '') return;
    dl.appendChild(node('dt', null, k));
    const dd = node('dd');
    if (v instanceof Node) dd.appendChild(v); else dd.textContent = String(v);
    dl.appendChild(dd);
  });
  return dl;
}

/* ── DataTable ────────────────────────────────────────────────────── *
 * opts = {
 *   host, id, columns: [{key, label, sort?, render?(row)→Node|text,
 *            cls?, hidden?, csv?}],
 *   load: async ({offset, limit, sort, order, q, filters}) → {rows, total},
 *   filters: [{key, label, el}],   existing controls placed in the toolbar
 *   searchLabel, onRow(row), exportFn(state), emptyText, defaultSort,
 *   pageSizes, extraTools: [Node]
 * }
 */
class DataTable {
  constructor(opts) {
    this.o = Object.assign({ pageSizes: [25, 50, 100], emptyText: 'Nothing to show.',
                             searchLabel: 'Search' }, opts);
    const saved = Prefs.get('table.' + this.o.id, {});
    this.state = {
      offset: 0,
      limit: saved.limit || this.o.pageSizes[0],
      sort: (this.o.defaultSort || {}).key || null,
      order: (this.o.defaultSort || {}).order || 'desc',
      q: ''
    };
    this.hiddenCols = new Set(saved.hidden ||
      this.o.columns.filter(c => c.hidden).map(c => c.key));
    // Filter controls written in the page itself are borrowed, not
    // owned: destroy() puts them back where they came from (UAT-02).
    this.homes = (this.o.filters || []).filter(f => f.el.parentNode)
      .map(f => [f.el, f.el.parentNode]);
    this.build();
  }

  /* Empties the table and hands the borrowed filter controls back,
   * reset, so the page can build a fresh table for the next user.
   * Emptying the host directly deleted those controls with it, and
   * the table could not be built again (UAT-02, 2026-10-04). */
  destroy() {
    this._seq = (this._seq || 0) + 1;     // an answer still on its way is dropped
    this.homes.forEach(([n, home]) => {
      if ('value' in n) n.value = '';
      home.appendChild(n);
    });
    this.o.host.textContent = '';
    this.rows = []; this.total = 0;
  }

  savePrefs() {
    Prefs.set('table.' + this.o.id,
              { limit: this.state.limit, hidden: Array.from(this.hiddenCols) });
  }

  build() {
    const host = this.o.host;
    host.textContent = '';
    const box = node('div', 'dt');
    const tools = node('div', 'dt-tools');

    const sf = node('div', 'f grow');
    const sid = this.o.id + '-q';
    const sl = node('label', null, this.o.searchLabel); sl.htmlFor = sid;
    this.search = node('input'); this.search.id = sid; this.search.type = 'search';
    this.search.placeholder = 'Type to search…';
    let t = null;
    this.search.oninput = () => {
      clearTimeout(t);
      t = setTimeout(() => { this.state.q = this.search.value.trim();
                             this.state.offset = 0; this.refresh(); }, 350);
    };
    sf.append(sl, this.search);
    tools.appendChild(sf);

    (this.o.filters || []).forEach(f => {
      const w = node('div', 'f');
      const l = node('label', null, f.label);
      if (!f.el.id) f.el.id = this.o.id + '-' + f.key;
      l.htmlFor = f.el.id;
      f.el.style.width = f.el.type === 'date' ? '150px' : '';
      w.append(l, f.el);
      const ev = f.el.tagName === 'SELECT' || f.el.type === 'date' ? 'onchange' : 'onkeydown';
      if (ev === 'onchange') f.el.onchange = () => { this.state.offset = 0; this.refresh(); };
      else f.el.onkeydown = e => { if (e.key === 'Enter') { this.state.offset = 0; this.refresh(); } };
      tools.appendChild(w);
    });

    const acts = node('div', 'acts');
    (this.o.extraTools || []).forEach(n => acts.appendChild(n));
    // Column chooser
    const pick = node('details', 'colpick');
    const sum = node('summary', 'btn sm ghost', 'Columns');
    sum.setAttribute('role', 'button');
    const menu = node('div', 'menu');
    this.o.columns.forEach(c => {
      if (!c.label) return;
      const l = node('label');
      const cb = node('input'); cb.type = 'checkbox';
      cb.checked = !this.hiddenCols.has(c.key);
      cb.onchange = () => {
        if (cb.checked) this.hiddenCols.delete(c.key); else this.hiddenCols.add(c.key);
        this.savePrefs(); this.render();
      };
      l.append(cb, document.createTextNode(c.label));
      menu.appendChild(l);
    });
    pick.append(sum, menu);
    acts.appendChild(pick);
    if (this.o.exportFn) {
      const ex = node('button', 'btn sm ghost', 'Export CSV');
      ex.type = 'button';
      ex.title = 'Download the rows that match the current filters (recorded in the audit trail)';
      ex.onclick = () => this.o.exportFn(this.params());
      acts.appendChild(ex);
    }
    const rf = node('button', 'btn sm ghost', 'Refresh');
    rf.type = 'button';
    rf.onclick = () => this.refresh();
    acts.appendChild(rf);
    tools.appendChild(acts);

    this.wrap = node('div', 'dt-wrap');
    this.wrap.setAttribute('aria-live', 'polite');
    const foot = node('div', 'dt-foot');
    this.info = node('div', null, '');
    const pager = node('div', 'pager');
    const psl = node('label', 'sr-only', 'Rows per page');
    const ps = node('select'); ps.style.width = 'auto';
    ps.id = this.o.id + '-ps'; psl.htmlFor = ps.id;
    // Listed smallest first; the first given stays the default (E2E-L30).
    [...this.o.pageSizes].sort((a, b) => a - b).forEach(n => {
      const op = node('option', null, `${n} per page`); op.value = n;
      if (n === this.state.limit) op.selected = true;
      ps.appendChild(op);
    });
    ps.onchange = () => { this.state.limit = Number(ps.value); this.state.offset = 0;
                          this.savePrefs(); this.refresh(); };
    const mk = (txt, aria, fn) => {
      const b = node('button', 'btn sm ghost', txt); b.type = 'button';
      b.setAttribute('aria-label', aria); b.onclick = fn; return b;
    };
    this.bFirst = mk('«', 'First page', () => { this.state.offset = 0; this.refresh(); });
    this.bPrev = mk('‹ Previous', 'Previous page', () => {
      this.state.offset = Math.max(0, this.state.offset - this.state.limit); this.refresh(); });
    this.bNext = mk('Next ›', 'Next page', () => {
      this.state.offset += this.state.limit; this.refresh(); });
    this.bLast = mk('»', 'Last page', () => {
      this.state.offset = Math.max(0, Math.floor((this.total - 1) / this.state.limit)
                                       * this.state.limit); this.refresh(); });
    pager.append(psl, ps, this.bFirst, this.bPrev, this.bNext, this.bLast);
    foot.append(this.info, pager);

    box.append(tools, this.wrap, foot);
    host.appendChild(box);
    this.rows = []; this.total = 0;
  }

  params() {
    const filters = {};
    (this.o.filters || []).forEach(f => {
      const v = String(f.el.value || '').trim();
      if (v) filters[f.key] = v;
    });
    return Object.assign({}, this.state, { filters });
  }

  async refresh() {
    // Each refresh is numbered; an answer that arrives after a newer
    // request was sent is dropped, so a slow answer for an earlier
    // filter never replaces the current one (X-05, 2026-10-03).
    const seq = this._seq = (this._seq || 0) + 1;
    this.wrap.setAttribute('aria-busy', 'true');
    try {
      const r = await this.o.load(this.params());
      if (seq !== this._seq) return;
      this.rows = r.rows || []; this.total = r.total ?? this.rows.length;
      if (this.state.offset && this.state.offset >= this.total && this.total > 0) {
        this.state.offset = Math.floor((this.total - 1) / this.state.limit) * this.state.limit;
        return this.refresh();
      }
      this.render();
    } catch (e) {
      if (e && (e.status === 401 || e.status === 428)) throw e;
      if (seq !== this._seq) return;
      this.wrap.textContent = '';
      this.wrap.appendChild(node('div', 'dt-empty',
        (e && e.message) ? e.message : 'The list could not be loaded.'));
      this.info.textContent = '';
    } finally {
      if (seq === this._seq) this.wrap.removeAttribute('aria-busy');
    }
  }

  render() {
    const cols = this.o.columns.filter(c => !this.hiddenCols.has(c.key));
    this.wrap.textContent = '';
    if (!this.rows.length) {
      this.wrap.appendChild(node('div', 'dt-empty', this.o.emptyText));
    } else {
      const t = node('table');
      const cap = node('caption', 'sr-only', this.o.caption || this.o.id);
      t.appendChild(cap);
      const thead = node('thead'), hr = node('tr');
      cols.forEach(c => {
        const th = node('th'); th.scope = 'col';
        if (c.sort && c.label) {
          const b = node('button', null, c.label); b.type = 'button';
          const key = c.sort === true ? c.key : c.sort;
          if (this.state.sort === key)
            th.setAttribute('aria-sort', this.state.order === 'asc' ? 'ascending' : 'descending');
          b.onclick = () => {
            if (this.state.sort === key)
              this.state.order = this.state.order === 'asc' ? 'desc' : 'asc';
            else { this.state.sort = key; this.state.order = c.firstOrder || 'asc'; }
            this.state.offset = 0; this.refresh();
          };
          th.appendChild(b);
        } else {
          th.textContent = c.label || '';
          if (!c.label) th.appendChild(node('span', 'sr-only', 'Actions'));
        }
        hr.appendChild(th);
      });
      thead.appendChild(hr); t.appendChild(thead);
      const tb = node('tbody');
      this.rows.forEach(row => {
        const tr = node('tr');
        if (this.o.onRow) {
          tr.className = 'clickable'; tr.tabIndex = 0;
          // Each row says which one it opens (X-06, 2026-10-03).
          tr.setAttribute('aria-label', this.o.rowLabel ? this.o.rowLabel(row)
            : 'Open details: ' + String(row[cols[0] && cols[0].key] ?? '').slice(0, 80));
          tr.onclick = e => {
            if (e.target.closest('button,a,select,input,summary')) return;
            this.o.onRow(row);
          };
          tr.onkeydown = e => {
            if ((e.key === 'Enter' || e.key === ' ') && e.target === tr) {
              e.preventDefault(); this.o.onRow(row);
            }
          };
        }
        cols.forEach(c => {
          const td = node('td', c.cls || null);
          const v = c.render ? c.render(row) : row[c.key];
          if (v instanceof Node) td.appendChild(v);
          else td.textContent = (v === null || v === undefined || v === '') ? '—' : String(v);
          tr.appendChild(td);
        });
        tb.appendChild(tr);
      });
      t.appendChild(tb);
      this.wrap.appendChild(t);
    }
    const from = this.total ? this.state.offset + 1 : 0;
    const to = Math.min(this.state.offset + this.rows.length, this.total);
    this.info.textContent = this.total
      ? `Showing ${fmtNum(from)}–${fmtNum(to)} of ${fmtNum(this.total)}`
      : 'No matching rows';
    const atStart = this.state.offset === 0;
    const atEnd = this.state.offset + this.state.limit >= this.total;
    this.bFirst.disabled = this.bPrev.disabled = atStart;
    this.bNext.disabled = this.bLast.disabled = atEnd;
  }
}

/* Client-side loader: sort / search / page an array the same way. */
function localLoader(getRows, searchKeys) {
  return async p => {
    let rows = await getRows();
    const q = (p.q || '').toLowerCase();
    if (q) rows = rows.filter(r => searchKeys.some(k =>
      String(r[k] ?? '').toLowerCase().includes(q)));
    if (p.sort) {
      const dir = p.order === 'asc' ? 1 : -1;
      rows = rows.slice().sort((a, b) => {
        const x = a[p.sort] ?? '', y = b[p.sort] ?? '';
        return (typeof x === 'number' && typeof y === 'number'
                ? x - y : String(x).localeCompare(String(y))) * dir;
      });
    }
    return { rows: rows.slice(p.offset, p.offset + p.limit), total: rows.length };
  };
}

/* ── Charts (SVG) ─────────────────────────────────────────────────── */
const SVGNS = 'http://www.w3.org/2000/svg';
const PALETTE = {
  // AIG brand colours (aig.com / aig.co.jp) with AIG's status tones.
  succeeded: '#0e8a64', failed: '#e81941', unconfirmed: '#c85200',
  other: '#9aa5b1', info: '#1352de', warning: '#c85200', error: '#e81941',
  navy: '#001871', sand: '#00a4e4',
  series: ['#001871', '#1352de', '#00a4e4', '#5d738d', '#80d2f2', '#0e8a64',
           '#c85200', '#e81941', '#343741', '#c7dbf4']
};

function svgEl(tag, attrs, text) {
  const n = document.createElementNS(SVGNS, tag);
  Object.entries(attrs || {}).forEach(([k, v]) => n.setAttribute(k, v));
  if (text !== undefined) n.textContent = text;
  return n;
}

function niceMax(v) {
  if (v <= 0) return 1;
  const p = Math.pow(10, Math.floor(Math.log10(v)));
  const m = v / p;
  return (m <= 1 ? 1 : m <= 2 ? 2 : m <= 5 ? 5 : 10) * p;
}

const Charts = {
  /* A titled card with the chart, a legend and an accessible data table. */
  card(host, title, subtitle, opts = {}) {
    const c = node('figure', 'chart' + (opts.wide ? ' wide' : ''));
    c.style.margin = '0';
    const h = node('h3', null, title);
    c.appendChild(h);
    if (subtitle) c.appendChild(node('p', 'cs', subtitle));
    host.appendChild(c);
    return c;
  },

  empty(card, text) {
    card.appendChild(node('div', 'empty', text || 'No data for this period.'));
  },

  legend(card, series) {
    const l = node('div', 'legend');
    series.forEach(s => {
      const sp = node('span'); const i = node('i'); i.style.background = s.color;
      sp.append(i, document.createTextNode(s.name)); l.appendChild(sp);
    });
    card.appendChild(l);
  },

  table(card, headers, rows) {
    const d = node('details');
    d.appendChild(node('summary', null, 'Show the figures'));
    const t = node('table');
    const hr = node('tr');
    headers.forEach(h => { const th = node('th', null, h); th.scope = 'col'; hr.appendChild(th); });
    t.appendChild(hr);
    rows.forEach(r => {
      const tr = node('tr');
      r.forEach(v => tr.appendChild(node('td', null, v === null || v === undefined ? '—' : String(v))));
      t.appendChild(tr);
    });
    d.appendChild(t);
    card.appendChild(d);
  },

  /* Drawn at the card's real width, so 1 unit = 1 pixel and text keeps
   * its size on any screen. */
  width(card) {
    return Math.max(300, Math.round((card.clientWidth || 640) - 32));
  },

  svg(card, w, h, desc) {
    const s = svgEl('svg', { viewBox: `0 0 ${w} ${h}`, width: w, height: h, role: 'img',
                             'aria-label': desc, preserveAspectRatio: 'xMidYMid meet' });
    s.appendChild(svgEl('title', {}, desc));
    card.appendChild(s);
    return s;
  },

  /* Vertical columns, stacked. labels: x labels; series: [{name,color,values}] */
  columns(card, { labels, series, desc, fmtX, unit }) {
    const total = labels.map((_, i) => series.reduce((a, s) => a + (s.values[i] || 0), 0));
    if (!total.some(v => v > 0)) return this.empty(card);
    const W = this.width(card), H = 230, L = 42, R = 8, T = 10, B = 28;
    const s = this.svg(card, W, H, desc);
    const max = niceMax(Math.max(...total));
    const iw = W - L - R, ih = H - T - B, bw = iw / labels.length;
    for (let g = 0; g <= 4; g++) {
      const y = T + ih - (ih * g / 4);
      s.appendChild(svgEl('line', { x1: L, x2: W - R, y1: y, y2: y,
                                    stroke: '#ebebeb', 'stroke-width': 1 }));
      s.appendChild(svgEl('text', { x: L - 6, y: y + 4, 'text-anchor': 'end' },
                          fmtNum(Math.round(max * g / 4))));
    }
    const step = Math.max(1, Math.ceil(labels.length / Math.max(4, Math.floor(iw / 56))));
    labels.forEach((lab, i) => {
      let y = T + ih;
      series.forEach(se => {
        const v = se.values[i] || 0;
        if (!v) return;
        const h = ih * v / max;
        y -= h;
        const r = svgEl('rect', { x: L + i * bw + bw * 0.15, y, width: Math.max(1, bw * 0.7),
                                  height: h, fill: se.color, rx: 1 });
        r.appendChild(svgEl('title', {}, `${fmtX ? fmtX(lab) : lab} · ${se.name}: ${fmtNum(v)}${unit || ''}`));
        s.appendChild(r);
      });
      if (i % step === 0)
        s.appendChild(svgEl('text', { x: L + i * bw + bw / 2, y: H - 8, 'text-anchor': 'middle' },
                            fmtX ? fmtX(lab) : lab));
    });
    if (series.length > 1) this.legend(card, series);
    this.table(card, [''].concat(series.map(x => x.name)).concat(series.length > 1 ? ['Total'] : []),
      labels.map((lab, i) => [fmtX ? fmtX(lab) : lab].concat(series.map(x => fmtNum(x.values[i] || 0)))
                             .concat(series.length > 1 ? [fmtNum(total[i])] : [])));
  },

  /* Lines; values may be null (gap). */
  line(card, { labels, series, desc, fmtX, fmtY }) {
    const all = series.flatMap(x => x.values).filter(v => v !== null && v !== undefined);
    if (!all.length) return this.empty(card);
    const W = this.width(card), H = 230, L = 58, R = 12, T = 10, B = 28;
    const s = this.svg(card, W, H, desc);
    const max = niceMax(Math.max(...all));
    const iw = W - L - R, ih = H - T - B;
    const x = i => L + (labels.length === 1 ? iw / 2 : iw * i / (labels.length - 1));
    const y = v => T + ih - ih * v / max;
    for (let g = 0; g <= 4; g++) {
      const yy = T + ih - (ih * g / 4);
      s.appendChild(svgEl('line', { x1: L, x2: W - R, y1: yy, y2: yy, stroke: '#ebebeb' }));
      s.appendChild(svgEl('text', { x: L - 6, y: yy + 4, 'text-anchor': 'end' },
                          fmtY ? fmtY(max * g / 4) : fmtNum(max * g / 4)));
    }
    series.forEach(se => {
      let d = '', pen = false;
      se.values.forEach((v, i) => {
        if (v === null || v === undefined) { pen = false; return; }
        d += (pen ? ' L' : ' M') + x(i).toFixed(1) + ' ' + y(v).toFixed(1); pen = true;
        const c = svgEl('circle', { cx: x(i), cy: y(v), r: 3, fill: se.color });
        c.appendChild(svgEl('title', {}, `${fmtX ? fmtX(labels[i]) : labels[i]} · ${se.name}: ${fmtY ? fmtY(v) : v}`));
        s.appendChild(c);
      });
      if (d) s.insertBefore(svgEl('path', { d, fill: 'none', stroke: se.color,
                                            'stroke-width': 2, 'stroke-dasharray': se.dash || '' }),
                            s.children[1]);
    });
    const step = Math.max(1, Math.ceil(labels.length / Math.max(4, Math.floor(iw / 56))));
    labels.forEach((lab, i) => {
      if (i % step === 0)
        s.appendChild(svgEl('text', { x: x(i), y: H - 8, 'text-anchor': 'middle' },
                            fmtX ? fmtX(lab) : lab));
    });
    this.legend(card, series);
    this.table(card, [''].concat(series.map(x => x.name)),
      labels.map((lab, i) => [fmtX ? fmtX(lab) : lab].concat(
        series.map(se => se.values[i] === null || se.values[i] === undefined
                         ? '—' : (fmtY ? fmtY(se.values[i]) : se.values[i])))));
  },

  /* Horizontal bars, optionally stacked. items: [{label, values:[…]}] */
  bars(card, { items, series, desc }) {
    const totals = items.map(it => it.values.reduce((a, v) => a + (v || 0), 0));
    if (!items.length || !totals.some(v => v > 0)) return this.empty(card);
    const rowH = 26, W = this.width(card), L = Math.min(210, Math.round(W * 0.4)), R = 50, T = 4;
    const H = T + items.length * rowH + 4;
    const s = this.svg(card, W, H, desc);
    const max = Math.max(...totals);
    const iw = W - L - R;
    items.forEach((it, i) => {
      const y = T + i * rowH;
      const fit = Math.max(8, Math.floor((L - 12) / 6.4));
      const lab = it.label.length > fit ? it.label.slice(0, fit - 1) + '…' : it.label;
      const tl = svgEl('text', { x: L - 8, y: y + 16, 'text-anchor': 'end' }, lab);
      tl.appendChild(svgEl('title', {}, it.label));
      s.appendChild(tl);
      let x = L;
      it.values.forEach((v, k) => {
        if (!v) return;
        const w = Math.max(1, iw * v / max);
        const r = svgEl('rect', { x, y: y + 5, width: w, height: rowH - 10,
                                  fill: series[k].color, rx: 1 });
        r.appendChild(svgEl('title', {}, `${it.label} · ${series[k].name}: ${fmtNum(v)}`));
        s.appendChild(r);
        x += w;
      });
      s.appendChild(svgEl('text', { x: x + 6, y: y + 16 }, fmtNum(totals[i])));
    });
    if (series.length > 1) this.legend(card, series);
    this.table(card, [''].concat(series.map(x => x.name)),
      items.map(it => [it.label].concat(it.values.map(v => fmtNum(v || 0)))));
  },

  /* Donut: items [{label, value, color}] */
  donut(card, { items, desc, centre }) {
    const total = items.reduce((a, i) => a + i.value, 0);
    if (!total) return this.empty(card);
    const W = this.width(card), H = 200, cx = 100, cy = 100, r = 78, w = 26;
    const s = this.svg(card, W, H, desc);
    let a0 = -Math.PI / 2;
    items.forEach(it => {
      const frac = it.value / total;
      const a1 = a0 + frac * Math.PI * 2;
      let p;
      if (frac >= 0.9999) {
        p = svgEl('circle', { cx, cy, r: r - w / 2, fill: 'none', stroke: it.color,
                              'stroke-width': w });
      } else {
        const large = a1 - a0 > Math.PI ? 1 : 0;
        const ro = r, ri = r - w;
        const P = (rad, a) => `${(cx + rad * Math.cos(a)).toFixed(2)} ${(cy + rad * Math.sin(a)).toFixed(2)}`;
        p = svgEl('path', { d: `M ${P(ro, a0)} A ${ro} ${ro} 0 ${large} 1 ${P(ro, a1)} ` +
                               `L ${P(ri, a1)} A ${ri} ${ri} 0 ${large} 0 ${P(ri, a0)} Z`,
                            fill: it.color });
      }
      p.appendChild(svgEl('title', {}, `${it.label}: ${fmtNum(it.value)} (${(frac * 100).toFixed(1)}%)`));
      s.appendChild(p);
      a0 = a1;
    });
    s.appendChild(svgEl('text', { x: cx, y: cy + 2, 'text-anchor': 'middle',
                                  style: 'font-size:20px;font-weight:600;fill:#343741' },
                        fmtNum(total)));
    s.appendChild(svgEl('text', { x: cx, y: cy + 20, 'text-anchor': 'middle' }, centre || 'total'));
    items.forEach((it, i) => {
      const y = 30 + i * 22;
      if (y > H - 10) return;
      s.appendChild(svgEl('rect', { x: 210, y: y - 10, width: 12, height: 12, fill: it.color, rx: 2 }));
      s.appendChild(svgEl('text', { x: 230, y }, `${it.label} — ${fmtNum(it.value)} ` +
                                                 `(${(it.value / total * 100).toFixed(1)}%)`));
    });
    this.table(card, ['', 'Count', 'Share'],
      items.map(it => [it.label, fmtNum(it.value), (it.value / total * 100).toFixed(1) + '%']));
  }
};

/* "2026-09-28" → "9/28" for chart axes */
function shortDay(d) {
  const m = /^\d{4}-(\d{2})-(\d{2})$/.exec(String(d || ''));
  return m ? `${Number(m[1])}/${Number(m[2])}` : String(d || '');
}
