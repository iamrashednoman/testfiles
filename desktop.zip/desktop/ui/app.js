/* FINES III RPA console.
 *
 * Plain JavaScript: no framework, no build step, no CDN. The console must
 * work fully offline inside a packaged desktop bundle, and every byte here
 * ships inside the application. Shared pieces (tables, charts, tooltips,
 * the details panel, business labels) are in ui-kit.js.
 *
 * The session is held in a cookie the page cannot read (HttpOnly,
 * SameSite=Strict, sent to /api only), never in page script or
 * localStorage: a provision evidence screenshot shows an account
 * password in clear text, so the session must not be readable by
 * anything running in the page. The cookie survives a reload, a second
 * tab and a service restart (SES-01, 2026-10-04) and is dropped when the
 * browser closes. Every request carries the console header, which the
 * service requires before it accepts a change made with the cookie.
 * (localStorage holds only view preferences, plus the time of the last
 * activity and renewal so that tabs of one console agree on them.)
 */
'use strict';

const API = location.origin + '/api/v1';
const CONSOLE_HEADER = { 'X-FINESIII-Console': '1' };
let SIGNED_IN = false;
let ME = null;
let refreshTimer = null;
let metricsTimer = null;

/* ── tiny helpers ─────────────────────────────────────────────── */
const $ = id => document.getElementById(id);
const el = (tag, cls, txt) => {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (txt !== undefined) n.textContent = txt;   // textContent: no HTML injection
  return n;
};
const show = (n, on) => n.classList.toggle('hide', !on);

/* The session renewal in progress, if any. A request waits for it, so
 * it is never sent with a session the renewal is about to replace. */
let RENEWING = null;
let RENEWALS = 0;               // completed renewals (see fetchAuthedRaw)
let SESSION_TTL = 0;            // seconds, from the server (expires_in)

/* fetch() with the session cookie and the console header. A request
 * answered 401 because the session was renewed while it was on its way
 * is sent once more (the renewal revokes the previous session at once
 * and the browser then holds the new cookie). */
async function fetchAuthedRaw(url, init = {}, waitForRenewal = true) {
  if (RENEWING && waitForRenewal) { try { await RENEWING; } catch (e) { } }
  const send = () => fetch(url, Object.assign({}, init, {
    credentials: 'same-origin',
    headers: Object.assign({}, init.headers || {}, CONSOLE_HEADER)
  }));
  const sent = RENEWALS;
  let res = await send();
  if (res.status === 401 && SIGNED_IN && waitForRenewal) {
    if (RENEWING) { try { await RENEWING; } catch (e) { } }
    if (RENEWALS !== sent) res = await send();
  }
  return res;
}

/* Validation errors (422) as plain sentences, not raw JSON. */
function detailText(detail) {
  if (Array.isArray(detail)) {
    return detail.map(d => {
      if (!d || typeof d !== 'object') return String(d);
      const loc = Array.isArray(d.loc) ? d.loc : [];
      const last = loc.length ? loc[loc.length - 1] : '';
      const field = typeof last === 'string' && last !== 'body' ? humanize(last) : '';
      const ctx = d.ctx || {};
      if (field && d.type === 'string_too_short')
        return `${field} must be at least ${ctx.min_length} characters`;
      if (field && d.type === 'string_too_long')
        return `${field} must be at most ${ctx.max_length} characters`;
      if (field && d.type === 'missing') return `${field} is required`;
      // Without the validator's own prefix ("Value error, ...", UAT-L05).
      const text = String(d.msg || '').replace(/^(Value|Assertion) error, /, '');
      return field ? `${field}: ${text || 'not valid'}` : (text || 'Not valid');
    }).join('; ') + '.';
  }
  if (detail && typeof detail === 'object')
    return detail.message || JSON.stringify(detail);
  return detail;
}

async function api(path, opts = {}) {
  const headers = Object.assign({}, opts.headers || {});
  if (opts.body) headers['Content-Type'] = 'application/json';
  let res;
  try {
    res = await fetchAuthedRaw(API + path, Object.assign({}, opts, {
      headers, body: opts.body ? JSON.stringify(opts.body) : undefined
    }), !opts.renewal);
  } catch (e) {
    // No answer at all: the service is stopped or unreachable.
    setConnection(false);
    const err = new Error('The service cannot be reached.');
    err.status = 0; err.offline = true;
    throw err;
  }
  setConnection(true);
  const text = await res.text();
  let data = null;
  try { data = text ? JSON.parse(text) : null; } catch (e) { data = text; }
  if (!res.ok) {
    const err = new Error(detailText(data && data.detail) || res.statusText);
    err.status = res.status;
    err.data = data;
    throw err;
  }
  return data;
}

/* 'Not connected' notice: shown while status calls get no answer, so
 * the console never keeps showing the last values as if they were live. */
let CONNECTED = true;
function setConnection(ok) {
  if (ok === CONNECTED) return;
  CONNECTED = ok;
  const box = $('conn-banner');
  if (box) {
    box.textContent = ok ? '' : 'The service cannot be reached — it may have ' +
      'been stopped. The values shown are from the last successful update; ' +
      'the console keeps trying.';
    show(box, !ok);
  }
  ['dash-cards', 'sys-cards'].forEach(id => {
    const cards = $(id);
    if (cards) cards.classList.toggle('stale', !ok);
  });
}

/* A query string from an object, skipping empty values. */
function qs(params) {
  const p = new URLSearchParams();
  Object.entries(params).forEach(([k, v]) => {
    if (v !== undefined && v !== null && v !== '') p.set(k, v);
  });
  const s = p.toString();
  return s ? '?' + s : '';
}

/* Download an authenticated file (CSV exports, diagnostics). */
async function download(path, fallbackName) {
  const r = await fetchAuthedRaw(API + path);
  if (r.status === 401) { signOut(); return false; }
  if (!r.ok) {
    let m = r.statusText;
    try { m = detailText((await r.json()).detail) || m; } catch (e) { }
    throw new Error(m);
  }
  const cd = r.headers.get('Content-Disposition') || '';
  const m = /filename="?([^";]+)"?/.exec(cd);
  const a = el('a');
  a.href = URL.createObjectURL(await r.blob());
  a.download = m ? m[1] : fallbackName;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  // What an export holds (X-03, 2026-10-03): rows written, rows that
  // matched, cut at the limit or not, recorded in the audit trail or not.
  const h = name => r.headers.get(name);
  return { rows: h('X-Export-Rows'), total: h('X-Export-Total'),
           truncated: h('X-Export-Truncated') === 'true',
           audited: h('X-Export-Audited') };
}

/* The message after an export: what it holds and whether it was
 * recorded — only said when it was (X-03). */
function exportText(info) {
  if (!info || typeof info !== 'object') return 'The export was downloaded.';
  let text = info.truncated
    ? `The export was downloaded, but it holds only the first ${fmtNum(info.rows)} ` +
      `of ${fmtNum(info.total)} matching rows (the most one file can hold). ` +
      'Choose a shorter period or narrower filters for the rest.'
    : `The export was downloaded (${fmtNum(info.rows)} row${Number(info.rows) === 1 ? '' : 's'}).`;
  if (info.audited === 'true') text += ' It is recorded in the audit trail.';
  else if (info.audited === 'false') text += ' The audit trail is off, so it is not recorded.';
  return text;
}

function gateError(msg) {
  const box = $('gate-err');
  box.textContent = msg || '';
  show(box, !!msg);
}

/* ── sign in / first run / forced change ──────────────────────── */
let CHANGE_VOLUNTARY = false;   // "Change password" from the header (D-08)
function showGate(mode, opts = {}) {
  CHANGE_VOLUNTARY = mode === 'change' && !!opts.voluntary;
  $('cp-back').textContent = CHANGE_VOLUNTARY ? 'Cancel' : 'Back to sign in';
  show($('shell'), false);
  show($('gate'), true);
  show($('form-login'), mode === 'login');
  show($('form-setup'), mode === 'setup');
  show($('form-change'), mode === 'change');
  gateError('');
  Drawer.close();
  if (mode === 'setup') {
    $('gate-title').textContent = 'First-time setup';
    $('gate-sub').textContent =
      'No console accounts exist yet. Create the first administrator.';
  } else if (mode === 'change') {
    $('gate-title').textContent = 'Choose a new password';
    $('gate-sub').textContent = CHANGE_VOLUNTARY
      ? 'Enter your current password and choose a new one. Every session of ' +
        'your account is ended and this window signs in again.'
      : 'Your password was set by an administrator. Please choose your own ' +
        'before you continue.';
    $('cp-cur').value = opts.current || '';
  } else {
    $('gate-title').textContent = 'Sign in';
    $('gate-sub').textContent = 'Sign in with your console account.';
  }
}

/* ── branding ─────────────────────────────────────────────────────
 * Loaded BEFORE sign-in (public route) and applied through CSS
 * variables + a handful of elements, so one saved change reaches every
 * page, including the sign-in page. */
let BRAND = {
  product_name: 'FINES III RPA', tagline: 'Identity & Access Automation Console',
  logo: '', favicon: '', login_background: '',
  accent_color: '#001871', secondary_color: '#00a4e4', link_color: '#1352de',
  nav_color: '#001871', background_color: '#f5f7f9', panel_color: '#ffffff',
  text_color: '#343741', font: 'standard', footer_text: '', support_contact: '',
  signin_notice: 'This system is for authorised use only. Activity is ' +
                 'recorded and monitored.'
};
/* The official AIG artwork that ships with the product; used whenever no
 * other image has been uploaded on the Branding page. */
const AIG_DEFAULTS = {
  mark: 'brand/aig-mark-white.svg',          // header
  full: 'brand/aig-logo-full-white.svg',     // sign-in panel
  favicon: 'brand/favicon.ico'
};
const FONTS = {
  standard: '"Source Sans 3","Source Sans Pro","Hiragino Kaku Gothic ProN",Meiryo,"Yu Gothic UI","Segoe UI",sans-serif',
  meiryo: 'Meiryo,"Yu Gothic UI","Segoe UI",system-ui,sans-serif',
  noto: '"Noto Sans JP","Noto Sans","Segoe UI",Meiryo,system-ui,sans-serif',
  system: 'system-ui,-apple-system,"Segoe UI","Hiragino Sans",Meiryo,sans-serif'
};

/* White or navy text, whichever reads better on a colour (WCAG). */
function textOn(hex) {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex || '');
  if (!m) return '#ffffff';
  const n = parseInt(m[1], 16);
  const lin = c => { c /= 255; return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4); };
  const L = 0.2126 * lin(n >> 16 & 255) + 0.7152 * lin(n >> 8 & 255) + 0.0722 * lin(n & 255);
  return L > 0.4 ? '#001871' : '#ffffff';
}

function applyBranding(b) {
  BRAND = Object.assign({}, BRAND, b || {});
  const r = document.documentElement.style;
  r.setProperty('--accent', BRAND.accent_color);
  r.setProperty('--on-accent', textOn(BRAND.accent_color));
  r.setProperty('--secondary', BRAND.secondary_color || '#00a4e4');
  r.setProperty('--link', BRAND.link_color || '#1352de');
  r.setProperty('--focus', BRAND.link_color || '#1352de');
  r.setProperty('--nav', BRAND.nav_color || BRAND.accent_color);
  r.setProperty('--nav-text', textOn(BRAND.nav_color || BRAND.accent_color));
  r.setProperty('--bg', BRAND.background_color);
  r.setProperty('--panel', BRAND.panel_color);
  r.setProperty('--text', BRAND.text_color);
  r.setProperty('--font', FONTS[BRAND.font] || FONTS.standard);
  document.title = BRAND.product_name;
  $('brand-name').textContent = BRAND.product_name;
  $('brand-tagline').textContent = BRAND.tagline || '';
  $('gate-product').textContent = BRAND.product_name;
  $('gate-wordmark').textContent = BRAND.product_name;
  $('gate-tagline').textContent = BRAND.tagline || '';
  // An uploaded logo replaces the AIG one everywhere; otherwise the AIG
  // mark (header) and the full AIG logo (sign-in panel) are shown.
  const nl = $('brand-logo'); nl.src = BRAND.logo || AIG_DEFAULTS.mark;
  nl.alt = BRAND.logo ? BRAND.product_name : 'AIG';
  const gl = $('gate-logo'); gl.src = BRAND.logo || AIG_DEFAULTS.full;
  gl.alt = BRAND.logo ? BRAND.product_name : 'AIG';
  show(nl, true); show(gl, true); show($('gate-wordmark'), false);
  $('favicon').href = BRAND.favicon || AIG_DEFAULTS.favicon;
  const panel = $('gate-brand');
  panel.style.backgroundImage = BRAND.login_background
    ? `url("${BRAND.login_background}")` : '';
  panel.classList.toggle('withbg', !!BRAND.login_background);
  const foot = [BRAND.footer_text, BRAND.support_contact]
    .filter(Boolean).join(' · ');
  $('gate-foot').textContent = foot;
  $('foot-text').textContent = foot;
  $('gate-notice').textContent = BRAND.signin_notice || '';
  show($('gate-notice'), !!BRAND.signin_notice);
}

async function loadBranding() {
  try { applyBranding((await api('/console/branding')).branding); }
  catch (e) { applyBranding({}); /* defaults stay */ }
}

async function boot() {
  await loadBranding();
  // A session that is still running (a reload, a second tab, a service
  // restart) carries on where it was (SES-01, 2026-10-04).
  try {
    const me = await api('/auth/me');
    if (me && me.user) {
      ME = me.user;
      resumeSession(me);
      if (me.must_change_password) return showGate('change');
      return enterConsole(me);
    }
  } catch (e) { /* not signed in: the sign-in page below */ }
  try {
    const s = await api('/auth/status');
    showGate(s.initialised ? 'login' : 'setup');
    show($('lg-sso'), !!s.windows_sso_available);
  } catch (e) {
    showGate('login');
    gateError(e.offline ? e.message : 'The service cannot be reached: ' + e.message);
  }
}

/* A new session from the server (the cookie is set by the answer):
 * its lifetime, which is also the inactivity limit. */
function setSession(r) {
  SIGNED_IN = true;
  if (Number(r.expires_in) > 0) SESSION_TTL = Number(r.expires_in);
  RENEWED_AT = Date.now();
  RENEWALS += 1;
  share('finesiii.renewed', RENEWED_AT);
}

/* A session found running on load: how far into its lifetime it is. */
function resumeSession(me) {
  SIGNED_IN = true;
  if (Number(me.expires_in) > 0) SESSION_TTL = Number(me.expires_in);
  const used = Math.max(0, SESSION_TTL - Number(me.session_remaining || 0));
  RENEWED_AT = Date.now() - used * 1000;
  markActivity(true);              // opening the page is activity
}

async function doWindowsLogin() {
  $('lg-sso').disabled = true;
  try {
    const r = await api('/auth/login/windows', { method: 'POST' });
    setSession(r); ME = r.user;
    markActivity(true);            // signing in is activity (E2E-H01)
    if (r.must_change_password) return showGate('change');
    enterConsole();
  } catch (e) {
    gateError(e.message);
  } finally {
    $('lg-sso').disabled = false;
  }
}

async function doLogin() {
  const user = $('lg-user').value.trim();
  const pass = $('lg-pass').value;
  if (!user || !pass) return gateError('Enter your username and password.');
  $('lg-go').disabled = true;
  try {
    const r = await api('/auth/login', {
      method: 'POST', body: { username: user, password: pass }
    });
    setSession(r);
    markActivity(true);            // signing in is activity (E2E-H01)
    ME = r.user;
    if (r.must_change_password) return showGate('change', { current: pass });
    enterConsole();
  } catch (e) {
    gateError(e.message);
  } finally {
    $('lg-go').disabled = false;
  }
}

async function doSetup() {
  const body = {
    username: $('su-user').value.trim(),
    display_name: $('su-name').value.trim(),
    password: $('su-pass').value
  };
  if (!body.username || !body.password)
    return gateError('Enter a username and password.');
  // Typed twice (UR-08, 2026-10-03): a typing mistake here would lock
  // the only administrator out.
  if (body.password !== $('su-pass2').value)
    return gateError('The two passwords are not the same. Type them again.');
  $('su-go').disabled = true;
  try {
    await api('/auth/bootstrap', { method: 'POST', body });
    $('su-pass').value = ''; $('su-pass2').value = '';
    $('lg-user').value = body.username;
    showGate('login');
    gateError('');
  } catch (e) {
    gateError(e.message);
  } finally {
    $('su-go').disabled = false;
  }
}

async function doChange() {
  const body = {
    current_password: $('cp-cur').value,
    new_password: $('cp-new').value
  };
  if (body.new_password !== $('cp-new2').value)
    return gateError('The two new passwords are not the same. Type them again.');
  $('cp-go').disabled = true;
  let changed = false;
  try {
    await api('/auth/password', { method: 'POST', body });
    changed = true;
    // Changing the password revokes every session, this one included.
    const r = await api('/auth/login', {
      method: 'POST',
      body: { username: ME.username, password: body.new_password }
    });
    setSession(r); ME = r.user;
    markActivity(true);            // signing in is activity (E2E-H01)
    $('cp-new2').value = '';
    enterConsole();
  } catch (e) {
    if (e.status === 401) {
      // The session was ended (e.g. the password was changed in another
      // window): back to the sign-in screen with a plain reason (NB-030).
      // The message goes after signOut, whose showGate clears it.
      $('cp-cur').value = ''; $('cp-new').value = ''; $('cp-new2').value = '';
      await signOut();
      gateError(changed
        ? 'Your password was changed. Sign in with the new password.'
        : 'This session has ended. Sign in again.');
      return;
    }
    gateError(e.message);
  } finally {
    $('cp-go').disabled = false;
  }
}

async function enterConsole(known) {
  show($('gate'), false);
  show($('shell'), true);
  $('who').textContent = (ME.display_name || ME.username) +
                         ' · ' + humanize(ME.role);
  // Hide what this role cannot use. The API enforces it regardless —
  // this only avoids showing a page that would answer 403.
  try {
    const me = known || await api('/auth/me');
    PERMS = me.permissions || [];
  } catch (e) { PERMS = []; }
  show($('nav-dashboard'), may('dashboard.view'));
  show($('nav-reports'), may('dashboard.view') || may('audit.view'));
  show($('nav-requests'), may('requests.view'));
  show($('nav-history'), may('requests.view'));
  show($('nav-evidence'), may('evidence.view'));
  show($('nav-audit'), may('audit.view'));
  show($('nav-rules'), may('rules.view'));
  // The account list answers only to users.manage (NB-031).
  // users.view reads the accounts (access review); users.manage
  // also changes them (UR-05, 2026-10-03).
  show($('nav-users'), may('users.manage') || may('users.view'));
  show($('nav-roles'), may('roles.manage'));
  show($('nav-settings'), may('settings.view'));
  show($('nav-system'), may('system.view'));
  show($('nav-branding'), may('settings.edit'));
  // A navigation group with nothing in it is not shown.
  document.querySelectorAll('nav .navgroup').forEach(g => {
    show(g, Array.from(g.querySelectorAll('button[data-view]'))
                 .some(b => !b.classList.contains('hide')));
  });
  SETUP = undefined;
  clearSensitive();
  TABLES = {};
  DASH_PROBLEMS_AT = 0;
  startSessionWatch();
  // The page in the address (a reload, a bookmark) when this role may
  // use it (SES-03); otherwise the first page it may use (the Dashboard
  // for most).
  const first = Array.from(document.querySelectorAll('nav button[data-view]'))
    .find(b => !b.classList.contains('hide'));
  show($('no-pages'), !first);
  const route = parseRoute();
  const target = route && mayOpen(route.view) ? route.view
                 : first ? first.dataset.view : null;
  if (route && target === 'settings') WANTED_PAGE = route.page;
  if (target) switchView(target, { replace: true, force: true });
  if (route && route.view && !mayOpen(route.view) && target)
    msg('route-msg', 'banner', 'You do not have access to that page; your first page is shown.', 8000);
  else VIEWS.forEach(v => show($('v-' + v), false));
  // First sign-in after install: walk the administrator through the
  // module setup (ServiceNow → SMTP → CyberArk → FINESIII). Every page
  // can be skipped; Settings → "Run setup again" reopens it.
  // The assistant saves settings and credentials: it opens only for
  // someone who may do both (SN-09, 2026-10-03).
  if (may('system.manage') && may('settings.edit') && !WIZARD_DISMISSED) {
    try {
      SETUP = await api('/system/setup');
      // "Skip for now" is remembered per account (SES-05).
      if (!SETUP.complete && !SETUP.dismissed) openWizard();
    } catch (e) { SETUP = null; }
  }
}

/* ── session: inactivity, renewal, sign-out (SES-02, 2026-10-04) ──
 * The session lifetime the server reports is also the inactivity
 * limit. The session is renewed only while someone uses the console
 * (keyboard, mouse, touch); the automatic Dashboard refresh is not
 * activity. A minute before the limit the console asks "Still
 * there?"; without an answer it signs out. However active, the server
 * ends a session at its maximum length (12 hours by default).
 *
 * The tabs of one console share the time of the last activity and of
 * the last renewal (localStorage holds only those two times), so a tab
 * nobody looks at does not sign out a person working in another one. */
const IDLE_WARN_MS = 60 * 1000;
let ACTIVITY_AT = 0;
let RENEWED_AT = 0;
let SESSION_WATCH = null;

function sharedTime(key) {
  try { return Number(localStorage.getItem(key)) || 0; } catch (e) { return 0; }
}
function share(key, value) {
  try { localStorage.setItem(key, String(value)); } catch (e) { }
}
const lastActivity = () => Math.max(ACTIVITY_AT, sharedTime('finesiii.activity'));
const lastRenewal = () => Math.max(RENEWED_AT, sharedTime('finesiii.renewed'));

function markActivity(force) {
  if (!SIGNED_IN) return;
  const now = Date.now();
  if (!force && now - ACTIVITY_AT < 2000) return;
  ACTIVITY_AT = now;
  share('finesiii.activity', now);
  if (!$('idle-box').classList.contains('hide')) hideIdlePrompt();
}
['pointerdown', 'keydown', 'wheel', 'touchstart', 'mousemove'].forEach(ev =>
  document.addEventListener(ev, e => {
    // While "Still there?" is shown, moving the mouse towards its
    // button is not an answer; a click or a key press is.
    if (e.type === 'mousemove' && !$('idle-box').classList.contains('hide')) return;
    markActivity(false);
  }, { passive: true, capture: true }));

/* One renewal at a time; requests wait for it (see fetchAuthedRaw). */
function renewSession() {
  if (!RENEWING) {
    RENEWING = (async () => {
      try {
        const r = await api('/auth/refresh', { method: 'POST', renewal: true });
        setSession(r);
      } finally { RENEWING = null; }
    })();
  }
  return RENEWING;
}

function idleMinutes() { return Math.round((SESSION_TTL || 1800) / 60); }

function showIdlePrompt(seconds) {
  const box = $('idle-box');
  const m = Math.max(1, Math.floor((Date.now() - lastActivity()) / 60000));
  $('idle-text').textContent =
    `The console has not been used for ${m} minute${m === 1 ? '' : 's'}. ` +
    `You will be signed out in ${seconds} second${seconds === 1 ? '' : 's'}.`;
  if (box.classList.contains('hide')) {
    IDLE_FOCUS = document.activeElement;
    show(box, true);
    $('idle-stay').focus();
  }
}
let IDLE_FOCUS = null;
function hideIdlePrompt() {
  const box = $('idle-box');
  if (box.classList.contains('hide')) return;
  show(box, false);
  restoreFocus(IDLE_FOCUS);
  IDLE_FOCUS = null;
}

async function sessionTick() {
  if (!SIGNED_IN || !SESSION_TTL) return;
  const now = Date.now(), limit = SESSION_TTL * 1000;
  const idle = now - lastActivity();
  if (idle >= limit) return signOut({ reason: 'idle' });
  if (idle >= limit - IDLE_WARN_MS)
    return showIdlePrompt(Math.max(1, Math.ceil((limit - idle) / 1000)));
  hideIdlePrompt();
  // A session ended on the server (an administrator ended it, changed
  // the role or the account) is noticed within 30 s, not at the next
  // click (E2E-L22). Reading /auth/me is not activity.
  if (now - SESSION_CHECKED_AT >= 30000) {
    SESSION_CHECKED_AT = now;
    try { await api('/auth/me'); }
    catch (e) {
      if (e.status === 401) return signOut({ message: 'Your session was ended. Sign in again.' });
    }
  }
  // Renewed once it is half-way through, and only when someone has used
  // the console since the last renewal (in any of its tabs).
  const renewed = lastRenewal();
  if (lastActivity() > renewed && now - renewed >= limit / 2) {
    try { await renewSession(); }
    catch (e) {
      // The maximum session length, or the session was ended elsewhere.
      if (e.status === 401) return signOut({ message: e.message });
    }
  }
}

let SESSION_CHECKED_AT = 0;
function startSessionWatch() {
  SESSION_CHECKED_AT = Date.now();
  clearInterval(SESSION_WATCH);
  SESSION_WATCH = setInterval(sessionTick, 5000);
}

/* Signing out. reason:
 *   'user'      the Sign out link: asks about unsaved settings first;
 *   'idle'      no activity for the inactivity limit;
 *   'other-tab' another tab of this console signed out;
 *   none        a request was answered "signed out" (401): first make
 *               sure, because another tab may just have renewed the
 *               session, which ends the previous one. */
async function signOut(opts = {}) {
  const reason = opts.reason || '';
  const wasSignedIn = SIGNED_IN;
  if (!reason && SIGNED_IN) {
    try {
      const me = await api('/auth/me');
      if (me && me.user) { resumeSession(me); return; }
    } catch (e) { /* really ended */ }
  }
  if (reason === 'user' && settingsUnsaved() &&
      !confirm('Settings has unsaved changes. Sign out without saving them?')) return;
  if (reason !== 'other-tab') {
    try { await api('/auth/logout', { method: 'POST' }); } catch (e) { }
    share('finesiii.signout', `${Date.now()}|${reason}`);
  }
  SIGNED_IN = false; ME = null; PERMS = [];
  clearSensitive();
  TABLES = {};
  clearInterval(refreshTimer); refreshTimer = null;
  clearInterval(metricsTimer); metricsTimer = null;
  clearInterval(SESSION_WATCH); SESSION_WATCH = null;
  clearInterval(STOP_WATCH); STOP_WATCH = null;
  hideIdlePrompt();
  setConnection(true);
  $('lg-pass').value = '';
  // A deliberate sign-out starts the next person on their own first
  // page; after an automatic one the same person returns to this page.
  if (reason === 'user') history.replaceState(null, '', location.pathname + location.search);
  showGate('login');
  const why = reason === 'other-tab' ? opts.cause : reason;
  if (why === 'idle')
    gateError(`You were signed out after ${idleMinutes()} minutes without activity.`);
  else if (reason === 'other-tab')
    gateError('You were signed out in another window of this console.');
  else if (opts.message) gateError(opts.message);
  // Signed out by the server: say so (E2E-L22).
  else if (!reason && wasSignedIn) gateError('Your session has ended. Sign in again.');
}

/* Another tab of this console signed out: this one follows. */
window.addEventListener('storage', e => {
  if (e.key !== 'finesiii.signout' || !SIGNED_IN) return;
  const cause = String(e.newValue || '').split('|')[1] || '';
  signOut({ reason: 'other-tab', cause });
});

/* Any 401/428 mid-session drops straight back to the gate. */
function guard(fn) {
  return async (...a) => {
    try { return await fn(...a); }
    catch (e) {
      if (e.status === 401) return signOut();
      if (e.status === 428) return showGate('change');
      throw e;
    }
  };
}

/* One click at a time (SN-10, 2026-10-03): the button stays disabled
 * while its call runs, so a test is never started twice (each
 * ServiceNow test is a sign-in, which counts towards a lockout). */
function busy(btn, fn) {
  return async (...a) => {
    if (btn.disabled) return;
    btn.disabled = true;
    try { return await fn(...a); } finally { btn.disabled = false; }
  };
}

/* ── navigation ───────────────────────────────────────────────── */
const VIEWS = ['dashboard', 'reports', 'requests', 'history', 'evidence',
               'audit', 'rules', 'users', 'roles', 'settings', 'system',
               'branding'];
let PERMS = [];                 // this user's permissions
const may = p => PERMS.includes(p);
const LOADERS = {};
let TABLES = {};                // one DataTable per page, built on first visit

/* ── page addresses (SES-03, 2026-10-04) ──────────────────────────
 * The page, and the Settings section, are kept in the address
 * (#/requests, #/settings/servicenow): a reload returns to them, a
 * bookmark opens them, and Back and Forward move between pages. */
let CURRENT_VIEW = null;
let WANTED_PAGE = '';           // Settings section asked for by the address
const slug = t => String(t || '').toLowerCase().replace(/^machine: /, 'machine-')
  .replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
function parseRoute() {
  const m = /^#\/([a-z]+)(?:\/([a-z0-9-]+))?$/.exec(location.hash || '');
  return m && VIEWS.includes(m[1]) ? { view: m[1], page: m[2] || '' } : null;
}
function mayOpen(view) {
  const b = document.querySelector(`nav button[data-view="${view}"]`);
  return !!b && !b.classList.contains('hide');
}
function routeHash(view) {
  return '#/' + view + (view === 'settings' && SET_PAGE ? '/' + slug(SET_PAGE) : '');
}
function setRoute(view, replace) {
  const h = routeHash(view);
  if (location.hash === h) return;
  history[replace ? 'replaceState' : 'pushState'](null, '', h);
}
window.addEventListener('popstate', () => {
  if (!SIGNED_IN) return;
  const r = parseRoute();
  if (!r) return;
  if (!mayOpen(r.view)) {
    // Said, and the address put back to the page shown (E2E-L20).
    setRoute(CURRENT_VIEW, true);
    return msg('route-msg', 'banner', 'You do not have access to that page.', 8000);
  }
  if (r.view !== CURRENT_VIEW) {
    if (r.view === 'settings') WANTED_PAGE = r.page;
    return switchView(r.view, { fromHistory: true });
  }
  if (r.view === 'settings' && r.page) {
    const g = settingsGroups().find(x => slug(x) === r.page);
    if (g && g !== SET_PAGE) selectSettingsPage(g, { fromHistory: true });
  }
});

function switchView(name, opts = {}) {
  // Leaving Settings with changes not saved: ask first (SES-04).
  if (CURRENT_VIEW === 'settings' && name !== 'settings' && !opts.force &&
      settingsUnsaved()) {
    if (!confirm('Settings has unsaved changes. Leave the page without saving them?')) {
      setRoute('settings', true);
      return;
    }
    // Left without saving: the typed values are discarded (the page is
    // loaded afresh on the next visit).
    $('set-body').textContent = ''; $('set-deploy').textContent = '';
  }
  CURRENT_VIEW = name;
  if (!opts.fromHistory) setRoute(name, !!opts.replace);
  VIEWS.forEach(v => show($('v-' + v), v === name));
  document.querySelectorAll('nav button[data-view]').forEach(b => {
    const on = b.dataset.view === name;
    b.classList.toggle('on', on);
    if (on) b.setAttribute('aria-current', 'page');
    else b.removeAttribute('aria-current');
  });
  Drawer.close();
  clearInterval(refreshTimer); refreshTimer = null;
  clearInterval(metricsTimer); metricsTimer = null;
  if (LOADERS[name]) LOADERS[name]();
  if (name === 'dashboard') {
    // Not while the window is hidden or minimised (DR-01, 2026-10-03);
    // the loader itself skips while its previous call is still running.
    refreshTimer = setInterval(() => { if (!document.hidden) LOADERS.dashboard(); }, 5000);
    metricsTimer = setInterval(() => { if (!document.hidden) loadDashMetrics(); }, 60000);
  } else if (name === 'system') {
    // Read again every 30 s (E2E-M09); not while hidden, nor while a
    // control on the page has the keyboard focus.
    refreshTimer = setInterval(() => {
      if (!document.hidden && !systemHasFocus()) LOADERS.system({ auto: true });
    }, 30000);
  }
}

function systemHasFocus() {
  const a = document.activeElement;
  return !!(a && a !== document.body && $('v-system').contains(a) && a.matches(':focus-visible'));
}

/* Back in view: bring the page up to date at once. */
document.addEventListener('visibilitychange', () => {
  if (!document.hidden && refreshTimer) {
    if (CURRENT_VIEW === 'system') LOADERS.system({ auto: true });
    else LOADERS.dashboard();
  }
});

/* "since 09:12 (35 min)" for a JST time (DR-04). */
function sinceText(iso) {
  const t = Date.parse(iso);
  if (isNaN(t)) return '';
  const mins = Math.max(0, Math.round((Date.now() - t) / 60000));
  const span = mins < 120 ? `${mins} min` : `${Math.floor(mins / 60)} h ${mins % 60} min`;
  return `since ${String(iso).slice(11, 16)} (${span})`;
}

/* ── dashboard ────────────────────────────────────────────────── */
function card(k, v, cls, s, tip) {
  const c = el('div', 'card');
  const kk = el('div', 'k', k);
  if (tip) { kk.appendChild(document.createTextNode(' ')); kk.appendChild(tipButton(tip, k)); }
  c.appendChild(kk);
  c.appendChild(el('div', 'v ' + (cls || ''), v));
  if (s) c.appendChild(el('div', 's', s));
  return c;
}

/* Two badges, each saying what it is (OPS-03, 2026-10-04): the
 * service's own posture and the mainframe environment (the 99 prefix).
 * One badge used to show either, depending on the page. */
function setEnvironment(service, mainframe) {
  [['env-chip', 'Service', service], ['mf-chip', 'Mainframe', mainframe]]
    .forEach(([id, what, env]) => {
      const chip = $(id);
      if (!env) return show(chip, false);
      chip.textContent = `${what}: ${label('environment', env)}`;
      chip.classList.toggle('dev', env !== 'production');
      show(chip, true);
    });
}

/* Why processing cannot run (startup problems from the system status),
 * as a list in a banner, and below it the settings that need attention
 * although requests are still processed (startup warnings); hidden when
 * there is neither. */
function renderProblems(box, problems, warnings) {
  box.textContent = '';
  const list = (problems || []).filter(Boolean);
  const notes = (warnings || []).filter(Boolean);
  show(box, list.length > 0 || notes.length > 0);
  if (list.length) {
    box.appendChild(el('div', null, list.length === 1
      ? 'Requests are not being processed because of this problem:'
      : 'Requests are not being processed because of these problems:'));
    const ul = el('ul', 'problems');
    list.forEach(p => ul.appendChild(el('li', null, String(p))));
    box.appendChild(ul);
  }
  if (notes.length) {
    box.appendChild(el('div', null,
      'Needs attention (requests are still processed):'));
    const ul = el('ul', 'problems');
    notes.forEach(p => ul.appendChild(el('li', null, String(p))));
    box.appendChild(ul);
  }
}

/* What weakens the protection of the service: an open request API in
 * red, the others as warnings (SEC-01 / 02 / 03 / 06, 2026-10-04). */
function renderSecurity(box, notices) {
  box.textContent = '';
  (notices || []).forEach(n => {
    const b = el('div', 'banner' + (n.level === 'danger' ? ' danger' : ''), n.text);
    b.setAttribute('role', 'alert');
    if (n.code === 'account_changed' && may('system.manage')) {
      const use = el('button', 'btn sm ghost', 'Use this account');
      use.style.marginLeft = '8px';
      use.onclick = busy(use, async () => {
        if (!confirm('Use the account this service runs as from now on? ' +
                     'Passwords saved for the earlier account are not moved: ' +
                     'save them again under Credentials.')) return;
        try {
          await api('/system/service-account/accept', { method: 'POST' });
          msg('sys-msg', 'okmsg', 'The account was recorded.', 6000);
        } catch (e) { msg('sys-msg', 'err', e.message); }
        LOADERS.system();
      });
      b.appendChild(use);
    }
    box.appendChild(b);
  });
}

/* Dashboard: the same problems, read from the system status at most
 * once a minute (installed application only — a plain server answers
 * 404 and nothing is shown). */
let DASH_PROBLEMS_AT = 0;
async function loadDashProblems() {
  const box = $('dash-problems');
  if (!may('system.view')) return show(box, false);
  if (Date.now() - DASH_PROBLEMS_AT < 60000) return;
  DASH_PROBLEMS_AT = Date.now();
  try {
    const st = await api('/system/status');
    renderProblems(box, st.startup_problems,
                   (st.startup_warnings || []).concat(serviceAlerts(st)));
  } catch (e) {
    if (e.status === 401) return signOut();
    if (!e.offline) show(box, false);
  }
}

/* ServiceNow and CyberArk trouble for the Dashboard, from the status the
 * System page cards read (E2E-M09). */
function serviceAlerts(st) {
  const out = [], sn = st.servicenow, ca = st.cyberark;
  if (sn && sn.enabled) {
    if (!sn.running) out.push('ServiceNow ticket collection is not running.');
    else if (sn.auth_held) out.push(`ServiceNow polling is paused: ${sn.last_error}.`);
    else if (sn.not_configured) out.push(`ServiceNow: ${sn.last_error || 'not configured'}.`);
    else if (sn.consecutive_errors)
      out.push(`ServiceNow is failing (${sn.consecutive_errors} check(s) in a row): ${sn.last_error}.`);
    else if (sn.last_error) out.push(`ServiceNow, last check: ${sn.last_error}.`);
    const tu = sn.ticket_updates || {}, byHand = (tu.given_up || 0) + (tu.refused || 0);
    if (byHand) out.push(`${byHand} ServiceNow ticket update(s) not written: update those tickets by hand (System page).`);
  }
  if (ca && (ca.using_fallback || !ca.available))
    out.push(ca.using_fallback ? 'CyberArk has not delivered the mainframe password yet.'
      : `CyberArk is unavailable${ca.last_error ? ': ' + ca.last_error : ''}.`);
  return out;
}

/* The mainframe window in one wording on the Dashboard and the System
 * page (E2E-L27): Open, Closing (no new work starts) or Closed. */
function windowState(av) {
  av = av || {};
  const open = !!av.within_time_window, closing = open && av.accepting_new_work === false;
  return { value: !open ? 'Closed' : closing ? 'Closing' : 'Open',
           cls: av.available ? 'ok' : 'warn',
           sub: (av.window || '') + (closing ? ' · closing: no new work starts' : '') +
                (av.health_probe_ok === false ? ' · mainframe not reachable' : '') };
}

let DASH_METRICS_AT = 0;
let DASH_BUSY = false;          // a summary call is under way (DR-01)
let DASH_UPDATED = '';          // time of the last good refresh (DR-02)
let DASH_SIG = '';              // the data last drawn (X-06)
let DASH_METRICS_SIG = '';      // the figures last drawn (UAT-L26)
LOADERS.dashboard = guard(async () => {
  if (!may('dashboard.view') || DASH_BUSY) return;
  DASH_BUSY = true;
  let d;
  try { d = await api('/console/summary'); }
  catch (e) {
    // The figures on the page are now older than they look (DR-02).
    $('dash-updated').textContent = (DASH_UPDATED
      ? `Last updated ${DASH_UPDATED} (JST)` : 'Not updated yet') +
      ' — the latest refresh failed; trying again.';
    $('dash-updated').classList.add('stale');
    // Not reachable: the notice is up; the 5-second refresh keeps trying.
    if (e.offline) return;
    throw e;
  } finally { DASH_BUSY = false; }
  DASH_UPDATED = String(d.generated_at || '').slice(11, 19);
  $('dash-updated').textContent = DASH_UPDATED ? `Last updated ${DASH_UPDATED} (JST)` : '';
  $('dash-updated').classList.remove('stale');
  // Unchanged data: the page is left as it is, so keyboard focus and an
  // open figure table are not lost every 5 seconds (X-06, 2026-10-03).
  const sigData = Object.assign({}, d, { generated_at: '', user: '' });
  if (sigData.availability)       // its clock changes on every answer
    sigData.availability = Object.assign({}, sigData.availability, { current_time_jst: '' });
  const sig = JSON.stringify(sigData);
  if (sig === DASH_SIG && $('dash-cards').children.length) {
    setupBanner();
    loadDashProblems();
    refreshPendingRestart();
    if (Date.now() - DASH_METRICS_AT > 55000) loadDashMetrics();
    return;
  }
  DASH_SIG = sig;
  setEnvironment(d.service_environment, d.environment);
  $('dash-sub').textContent =
    `${label('driver', d.driver)} · Mainframe: ${label('environment', d.environment)} ` +
    `environment · ${label('engine', d.engine)} database` +
    (d.ocr_enabled ? ' · Screen reading on' : '');

  const q = d.queue || {}, av = d.availability || {};
  const cards = $('dash-cards');
  cards.textContent = '';
  cards.append(
    card('Service', d.service === 'up' ? 'Running' : 'Not running',
         d.service === 'up' ? 'ok' : 'bad'),
    card('Database', d.database === 'up' ? 'Connected' : 'Unavailable',
         d.database === 'up' ? 'ok' : 'bad', label('engine', d.engine)),
    processingCard(d.dispatcher),
    ((ws) => card('Mainframe window', ws.value, ws.cls, ws.sub,
         'Requests are processed only while the operating window is open.'))(windowState(av)),
    d.queue
      ? card('Queue', fmtNum(q.eligible ?? 0) + ' waiting', '',
             `${fmtNum(q.running ?? 0)} in progress · ${fmtNum(q.cooling_down ?? 0)} waiting to retry` +
             // How long the oldest request has waited (DR-04, 2026-10-03).
             (q.oldest_queued_at ? ` · oldest waiting ${sinceText(q.oldest_queued_at)}` : ''))
      // Not "0 waiting": the queue could not be read (DR-02).
      : card('Queue', 'Unavailable', 'bad', 'The queue could not be read'),
  );
  // Events not yet in the audit database: its outage shows here (DR-07).
  const au = d.audit || {};
  if (au.enabled) {
    cards.appendChild(card('Audit trail',
      au.pending == null ? 'Unknown' : au.pending ? `${fmtNum(au.pending)} waiting` : 'Up to date',
      au.pending ? 'warn' : au.pending == null ? 'dim' : 'ok',
      au.pending ? 'Events waiting to be written to the audit database' : '',
      'Events are kept on this machine until the audit database has them.'));
  }

  // Which error RULES fired. Not the same as result codes: a rule can
  // fire with no mainframe code at all (a modal dialog, a rejected
  // login), and those are the failures worth watching.
  const rules = Object.entries(d.errors_by_rule || {})
                      .sort((a, b) => b[1] - a[1]);
  // The audit trail could not be read: said, not left out (UAT-L01).
  if (d.errors_by_rule === null && au.enabled)
    cards.appendChild(card('Error screens recognised (today)', 'Unavailable', 'dim',
                           'The audit trail could not be read'));
  if (rules.length) {
    const c = el('div', 'card');
    const k = el('div', 'k', 'Error screens recognised (today) ');
    k.appendChild(tipButton('Recognised error screens the bot handled today ' +
      '(JST), from the audit trail. See Error rules for what each one means.', 'error screens'));
    c.appendChild(k);
    const chips = el('div', 'chips');
    chips.style.marginTop = '8px';
    rules.forEach(([id, n]) =>
      chips.appendChild(el('span', 'chip', `${id} × ${n}`)));
    c.appendChild(chips);
    c.style.gridColumn = '1 / -1';
    cards.appendChild(c);
  }
  $('dash-recent').textContent = '';
  $('dash-recent').appendChild(d.recent
    ? txnTable(d.recent)
    : el('p', 'err', 'The latest transactions could not be read.'));
  setupBanner();
  loadDashProblems();
  refreshPendingRestart();
  // Figures refresh every minute, not with the 5-second health refresh.
  if (Date.now() - DASH_METRICS_AT > 55000) loadDashMetrics();
});

function kpi(k, v, tip, delta, tone) {
  const c = el('div', 'kpi' + (tone ? ' ' + tone : ''));
  const kk = el('div', 'k', k);
  if (tip) kk.appendChild(tipButton(tip, k));
  c.append(kk, el('div', 'v', v));
  if (delta) c.appendChild(el('div', 'd', delta));
  return c;
}

function change(now, before, unit) {
  if (before === null || before === undefined || now === null || now === undefined) return '';
  const diff = now - before;
  if (!diff) return 'Same as the previous period';
  const sign = diff > 0 ? '+' : '−';
  return `${sign}${unit === '%' ? Math.abs(diff).toFixed(1) + ' pts'
                                : fmtNum(Math.abs(diff))} on the previous period`;
}

function periodText(p) {
  if (!p) return '';
  return p.from === p.to ? `${p.from} (JST)` : `${p.from} to ${p.to} (JST)`;
}

async function loadDashMetrics() {
  if (!may('dashboard.view')) return;
  DASH_METRICS_AT = Date.now();
  const period = $('dash-period').value;
  let m;
  try { m = await api('/console/metrics' + qs({ period })); }
  catch (e) {
    if (e.status === 401) return signOut();
    $('dash-kpis').textContent = '';
    $('dash-kpis').appendChild(el('p', 'sub', 'The figures could not be loaded: ' + e.message));
    return;
  }
  $('dash-period-label').textContent = periodText(m.period);
  // Unchanged figures are not drawn again, and an open figure table
  // stays open when they are (UAT-L26, 2026-10-04).
  const sig = JSON.stringify(Object.assign({}, m, { generated_at: '', compared_until: '' }));
  if (sig === DASH_METRICS_SIG && $('dash-charts').children.length) return;
  DASH_METRICS_SIG = sig;
  const open = new Set(Array.from($('dash-charts').querySelectorAll('figure'))
    .filter(f => f.querySelector('details[open]'))
    .map(f => (f.querySelector('h3') || {}).textContent));
  renderProcessing(m, $('dash-kpis'), $('dash-charts'), false);
  $('dash-charts').querySelectorAll('figure').forEach(f => {
    const d = f.querySelector('details');
    if (d && open.has((f.querySelector('h3') || {}).textContent)) d.open = true;
  });
}

/* KPI tiles and charts for one period of processing (dashboard + reports). */
function renderProcessing(m, kpiHost, chartHost, forReport) {
  const k = m.kpis || {}, prev = k.previous || {};
  const b = (m.backlog || {}).by_status || {};
  kpiHost.textContent = '';
  kpiHost.append(
    kpi('Transactions', fmtNum(k.total),
        'Finished transactions in the period (completed, failed, already removed or not confirmed).',
        change(k.total, prev.total)),
    kpi('Success rate', fmtPct(k.success_rate),
        'Completed (or already removed) as a share of all finished transactions.',
        change(k.success_rate, prev.success_rate, '%'),
        k.success_rate === null || k.success_rate === undefined ? ''
          : k.success_rate >= 95 ? 'good' : k.success_rate >= 80 ? 'warnk' : 'badk'),
    kpi('Failed', fmtNum(k.failed),
        'Transactions that failed after every attempt. Each one needs attention.',
        change(k.failed, prev.failed), k.failed ? 'badk' : 'good'),
    kpi('Needs verification', fmtNum(k.unconfirmed),
        'The change was submitted but its result could not be read from the screen. Check these on the mainframe.',
        '', k.unconfirmed ? 'warnk' : ''),
    kpi('Average time', fmtSecs(k.avg_duration_seconds),
        'Average processing time of a successful transaction.',
        k.p95_duration_seconds ? `95% finish within ${fmtSecs(k.p95_duration_seconds)}` : ''),
    // From receipt to the finished change (DR-04, 2026-10-03).
    kpi('Lead time', fmtSecs(k.avg_lead_time_seconds),
        'Average time from the request being received to the change being done ' +
        '(successful transactions). A retried request counts from its retry.',
        k.p95_lead_time_seconds ? `95% within ${fmtSecs(k.p95_lead_time_seconds)}` : ''),
    kpi('Retried', fmtNum(k.retried),
        'Transactions that needed more than one attempt.'),
    kpi('Backlog now', fmtNum((b.queued || 0) + (b.running || 0)),
        'Requests waiting or in progress at this moment.',
        `${fmtNum(b.queued || 0)} queued · ${fmtNum(b.running || 0)} in progress`),
  );

  chartHost.textContent = '';
  const days = (m.daily || []).map(x => x.day);
  const c1 = Charts.card(chartHost, 'Daily volume by outcome',
    'Finished transactions per day (JST).', { wide: true });
  Charts.columns(c1, {
    labels: days, fmtX: shortDay,
    desc: 'Daily transactions by outcome',
    series: [
      { name: 'Completed', color: PALETTE.succeeded, values: m.daily.map(x => x.succeeded) },
      { name: 'Failed', color: PALETTE.failed, values: m.daily.map(x => x.failed) },
      { name: 'Needs verification', color: PALETTE.unconfirmed, values: m.daily.map(x => x.unconfirmed) },
      { name: 'Other', color: PALETTE.other, values: m.daily.map(x => x.other) }]
  });

  const c2 = Charts.card(chartHost, 'By request type', 'Outcome for each type of request.');
  Charts.bars(c2, {
    desc: 'Transactions by request type',
    series: [{ name: 'Completed', color: PALETTE.succeeded },
             { name: 'Failed', color: PALETTE.failed },
             { name: 'Needs verification', color: PALETTE.unconfirmed }],
    items: (m.by_request_type || []).map(r => ({
      label: r.label, values: [r.succeeded, r.failed, r.unconfirmed] }))
  });

  const c3 = Charts.card(chartHost, 'Processing time',
    'Average and 95th-percentile time of successful transactions per day.');
  Charts.line(c3, {
    labels: days, fmtX: shortDay, fmtY: v => fmtSecs(v),
    desc: 'Processing time trend',
    series: [
      { name: 'Average', color: PALETTE.navy, values: m.duration_trend.map(x => x.avg) },
      { name: '95th percentile', color: PALETTE.sand, dash: '5 4',
        values: m.duration_trend.map(x => x.p95) }]
  });

  const c4 = Charts.card(chartHost, 'All requests by status',
    'Every request received, by its status now (all time). The backlog is the waiting and running ones.');
  Charts.bars(c4, {
    desc: 'Requests by status',
    series: [{ name: 'Requests', color: PALETTE.navy }],
    items: Object.entries(b).sort((x, y) => y[1] - x[1])
                 .map(([s, n]) => ({ label: label('status', s), values: [n] }))
  });

  const c5 = Charts.card(chartHost, 'Most frequent failure reasons',
    'Failed or unconfirmed transactions, by result code or reason.');
  Charts.bars(c5, {
    desc: 'Top failure reasons',
    series: [{ name: 'Transactions', color: PALETTE.failed }],
    items: (m.top_failures || []).map(f => ({ label: f.label, values: [f.count] }))
  });

  const c6 = Charts.card(chartHost, 'Where requests came from', 'Finished transactions by source.');
  Charts.donut(c6, {
    desc: 'Transactions by source', centre: 'transactions',
    items: Object.entries(m.by_source || {}).map(([s, n], i) => ({
      label: label('source', s), value: n, color: PALETTE.series[i % PALETTE.series.length] }))
  });

  if (forReport) {
    const c7 = Charts.card(chartHost, 'Activity by hour of day',
      'When transactions finished (JST), to plan capacity and the operating window.', { wide: true });
    Charts.columns(c7, {
      labels: (m.by_hour || []).map(h => String(h.hour).padStart(2, '0') + ':00'),
      desc: 'Transactions by hour of day',
      series: [{ name: 'Transactions', color: PALETTE.navy,
                 values: (m.by_hour || []).map(h => h.count) }]
    });
  }
}

/* First-run checklist (installed desktop app only — the route is
 * absent on a plain server). Shown to system.manage holders until they
 * mark setup complete. */
let SETUP;
async function setupBanner() {
  const box = $('setup-banner');
  if (!may('system.manage')) return show(box, false);
  if (SETUP === undefined) {
    try { SETUP = await api('/system/setup'); } catch (e) { SETUP = null; }
  }
  if (!SETUP || SETUP.complete) return show(box, false);
  box.textContent = '';
  box.className = 'infobar';
  // ServiceNow is a module, not one of the server's checks: Done when
  // ticket collection is on and configured.
  const sn = (SETUP.modules || {}).servicenow;
  const snCheck = sn ? {
    ok: !!(sn.enabled && sn.configured),
    enabled: !!sn.enabled, configured: !!sn.configured,
    note: 'Optional if requests arrive only through the service interface.'
  } : null;
  const items = [
    ['servicenow', 'ServiceNow', v => v.enabled
      ? (v.configured ? 'on' : 'on, not fully configured') : 'off'],
    ['database', 'Database', v => label('engine', v.value)],
    ['service_account', 'Mainframe service account / CyberArk', () => ''],
    ['ocr', 'Screen reading', v => v.value ? 'on' : 'off'],
    ['email', 'E-mail', () => ''],
  ];
  box.appendChild(el('div', null,
    'Please finish setting up this installation. Each item can be changed ' +
    'later under Settings or System.'));
  const ul = el('ul', 'checks');
  items.forEach(([key, lab, fmt]) => {
    const c = key === 'servicenow' ? snCheck : (SETUP.checks || {})[key];
    if (!c) return;
    const li = el('li');
    li.appendChild(el('span', 'mark ' + (c.ok ? 'ok' : 'skipped'),
                      c.needed === false ? 'Not needed' : c.ok ? 'Done' : 'To do'));
    const t = el('div');
    t.appendChild(el('div', null, lab + (fmt(c) ? ` — ${fmt(c)}` : '')));
    if (c.note) t.appendChild(el('div', 'dimmer', c.note));
    li.appendChild(t);
    ul.appendChild(li);
  });
  box.appendChild(ul);
  const row = el('div', 'row');
  const go = el('button', 'btn sm ghost', 'Open Settings');
  go.onclick = () => switchView('settings');
  const done = el('button', 'btn sm', 'Mark setup complete');
  done.onclick = guard(async () => {
    // The same check as the setup assistant (UAT-09, 2026-10-04): a
    // module switched on but not fully set up is named and confirmed.
    const missing = incompleteModules(SETUP);
    if (missing.length && !confirm(`${missing.join(', ')} ` +
        (missing.length === 1 ? 'is' : 'are') + ' switched on but not fully ' +
        'set up. Mark the setup complete anyway? The checklist then leaves the ' +
        'Dashboard.')) return;
    SETUP = await api('/system/setup', { method: 'PUT',
      body: { complete: true, confirm: missing.length > 0 } });
    show(box, false);
  });
  row.append(go, done);
  box.appendChild(row);
  show(box, true);
}

/* Modules switched on but not fully set up, by name (UAT-09). */
const MODULE_NAMES = { servicenow: 'ServiceNow', smtp: 'E-mail', cyberark: 'CyberArk',
                       finesiii: 'FINESIII terminal' };
function incompleteModules(setup) {
  return Object.entries((setup && setup.modules) || {})
    .filter(([, m]) => m && m.enabled && m.configured === false)
    .map(([k]) => MODULE_NAMES[k] || k);
}

/* The row (optional) names two states the status alone hides
 * (E2E-L07): a result not confirmed, and a retry that is scheduled. The
 * stored status is unchanged. */
function statusTag(s, r) {
  r = r || {};
  if (s === 'done' && String(r.result_code || '').toUpperCase() === 'UNCONFIRMED')
    return el('span', 'tag running', 'Needs verification');
  if (s === 'queued' && r.next_attempt_at && Date.parse(r.next_attempt_at) > Date.now())
    return el('span', 'tag queued', 'Waiting to retry · next ' + fmtTime(r.next_attempt_at).slice(11, 16));
  return el('span', 'tag ' + s, label('status', s));
}

function evidenceLink(r) {
  if (!may('evidence.view')) return '—';
  if (!r.screenshot_count) {
    // A request that failed with an error may still have screenshots of
    // the steps it took (RQ-09, 2026-10-03).
    if (r.status !== 'failed') return '—';
    const a = el('a', null, 'Look for screenshots');
    a.href = '#';
    a.onclick = ev => { ev.preventDefault(); openEvidence(r.request_id); };
    return a;
  }
  const a = el('a', null, `${r.screenshot_count} screenshots`);
  a.href = '#';
  a.onclick = ev => { ev.preventDefault(); openEvidence(r.request_id); };
  return a;
}

function txnTable(rows) {
  if (!rows.length) return el('p', 'sub', 'No transactions yet.');
  const wrap = el('div', 'dt');
  const t = el('table');
  const head = el('tr');
  ['Ticket', 'Operation', 'Employee code', 'Status', 'Result code', 'Completed (JST)', 'Evidence']
    .forEach(h => { const th = el('th', null, h); th.scope = 'col'; head.appendChild(th); });
  t.appendChild(head);
  rows.forEach(r => {
    const tr = el('tr');
    tr.appendChild(el('td', 'mono', r.ticket_id || r.request_id || '—'));
    tr.appendChild(el('td', null, label('operation', r.operation)));
    tr.appendChild(el('td', 'mono', r.employee_code || ''));
    const st = el('td'); st.appendChild(statusTag(r.status || '', r)); tr.appendChild(st);
    tr.appendChild(el('td', 'mono', r.result_code || '—'));
    tr.appendChild(el('td', 'mono', fmtTime(r.completed_at)));
    const shots = el('td');
    const link = evidenceLink(r);
    if (link instanceof Node) shots.appendChild(link); else shots.textContent = link;
    tr.appendChild(shots);
    t.appendChild(tr);
  });
  const scroll = el('div', 'dt-wrap');
  scroll.appendChild(t);
  wrap.appendChild(scroll);
  return wrap;
}

/* ── row details ──────────────────────────────────────────────── */
/* The e-mails to the new user in words (E2E-L06): true sent, "queued"
 * waiting in the outbox, "failed", false not sent. The password's state
 * may arrive masked like any value under a "password" key. */
function noticesText(n) {
  if (n.reason) return `Not sent — ${n.reason}`;
  const w = v => v === true ? 'sent' : v === 'queued' ? 'waiting to be sent'
                : v === 'failed' ? 'failed'
                : v === '****' ? 'waiting or failed (see the audit trail)' : 'not sent';
  return `Registration ${w(n.registration)} · Password ${w(n.password)}`;
}

/* An audit event's detail as "Label: value" pairs (E2E-L05). Display
 * only: the stored record and the CSV export keep it as written. */
function eventDetailText(d) {
  if (d === null || d === undefined || d === '') return '';
  if (typeof d !== 'object') return String(d);
  return Object.entries(d)
    .filter(([, v]) => v !== null && v !== undefined && v !== '')
    .map(([k, v]) => `${humanize(k)}: ${typeof v === 'object' ? JSON.stringify(v) : String(v)}`)
    .join(' · ');
}
/* The state of a request's ServiceNow ticket update, in words (SN-02,
 * 2026-10-03), instead of the stored marker. */
function writebackText(m) {
  const note = String(m.note || '');
  const action = humanize(m.action || 'update');
  if (note.startsWith('refused: '))
    return `Refused by ServiceNow — ${note.slice(9)}. Update the ticket by hand.`;
  if (m.pending) {
    const rounds = Number(m.rounds || 0);
    return `${action} not written yet — tried on ${rounds} poll(s)` +
      (rounds >= 6 ? '; given up: update the ticket by hand' : '; tried again on the next polls') +
      (note ? ` (${note})` : '') + '.';
  }
  return `${action} written to the ticket.`;
}

function metaPairs(meta) {
  if (!meta || typeof meta !== 'object') return [];
  const pairs = [];
  const names = {
    request_kind_label: 'Request type', category: 'Request category',
    tracking_id: 'Tracking ID', request_type: 'Request type (ticket)',
    employee_id: 'Employee ID', employee_name: 'Employee name',
    entitlement: 'Entitlement', affiliation_name: 'Affiliation name',
    parent_ticket: 'Task', part: 'Part', parts: 'Parts',
    requested_item: 'Requested item', request_number: 'Request',
    password_generated: 'Password generated by the bot',
    user_email: 'User e-mail', snow_writeback: 'ServiceNow ticket update',
    requester: 'Requester', user_display_name: 'User name',
    // In words, not the stored markers (E2E-L06).
    commit_sent_at: 'Commit sent (JST)', user_notices_sent: 'E-mails to the user',
    support_report_sent: 'Support report', submitted_by: 'Submitted by'
  };
  Object.entries(meta).forEach(([k, v]) => {
    // 'category' repeats request_kind_label (the business name) — shown once.
    if (k === 'snow_details' || k === 'entitlements' || k === 'category' ||
        k.startsWith('_')) return;
    if (k.includes('password_fp')) return;
    if (v === null || v === undefined || v === '') return;
    let text = v;
    if (k === 'category') text = label('kind', v);
    else if (k === 'snow_writeback' && typeof v === 'object') text = writebackText(v);
    else if (k === 'commit_sent_at') text = fmtTime(v);
    else if (k === 'user_notices_sent' && typeof v === 'object') text = noticesText(v);
    else if (k === 'support_report_sent') text = 'Sent';
    else if (k === 'submitted_by') text = String(v).replace(/^user:/, '');
    // A person (the requester): name, employee number and e-mail as text,
    // not the raw record (UAT-L28, 2026-10-04).
    else if (v && typeof v === 'object' && !Array.isArray(v) && ('name' in v || 'email' in v))
      text = [v.name, v.employee_number, v.email].filter(Boolean).join(' · ') || '—';
    else if (typeof v === 'boolean') text = v ? 'Yes' : 'No';
    else if (typeof v === 'object') text = JSON.stringify(v);
    pairs.push([names[k] || humanize(k), String(text)]);
  });
  return pairs;
}

async function relatedEvents(host, requestId) {
  if (!may('audit.view') || !requestId) return;
  host.appendChild(el('h4', null, 'Audit events'));
  const box = el('div', 'dimmer', 'Loading…');
  host.appendChild(box);
  try {
    const d = await api('/console/audit/events' + qs({ request_id: requestId, limit: 50,
                                                       offset: 0, sort: 'occurred_at', order: 'asc' }));
    box.textContent = '';
    if (!(d.events || []).length) { box.textContent = 'No audit events recorded.'; return; }
    // The first 50: say so, and lead to all of them (DR-09, 2026-10-03).
    if ((d.total || 0) > d.events.length) {
      const more = el('p', 'dimmer', `The first ${d.events.length} of ${fmtNum(d.total)} events. `);
      const a = el('a', null, 'Show all on the Audit trail page');
      a.href = '#';
      a.onclick = ev => { ev.preventDefault(); showAuditFor(requestId); };
      more.appendChild(a);
      box.appendChild(more);
    }
    const t = el('table');
    d.events.forEach(e => {
      const tr = el('tr');
      tr.appendChild(el('td', 'mono', fmtTime(e.occurred_at)));
      tr.appendChild(el('td', null, humanize(e.action)));
      tr.appendChild(el('td', 'dim', label('severity', e.severity)));
      t.appendChild(tr);
    });
    box.className = ''; box.appendChild(t);
  } catch (e) {
    // With the audit trail off there is nothing to load (UAT-L10).
    box.textContent = e.status === 503 && /disabled|turned off/i.test(e.message)
      ? 'The audit trail is turned off, so no events are recorded.'
      : 'The audit events could not be loaded.';
  }
}

/* The Audit trail page, filtered by one request. */
function showAuditFor(requestId) {
  Drawer.close();
  $('au-req').value = requestId;
  switchView('audit');
  if (TABLES.audit) { TABLES.audit.state.offset = 0; TABLES.audit.refresh(); }
}

/* Retry is offered only where it can succeed (RQ-08, 2026-10-03): a
 * provision whose own password was supplied with the ticket and has been
 * erased since is always refused by the service. */
function canRetry(r) {
  if (!may('requests.retry') || r.status !== 'failed') return false;
  const m = r.metadata || {};
  return !(r.operation === 'provision' && !r.password && m.password_supplied);
}
function confirmRetry(r) {
  return confirm(`Retry ${r.ticket_id || r.request_id}?\n\nThe ` +
    `${label('operation', r.operation).toLowerCase()} is carried out on the ` +
    'mainframe again.');
}

function requestDetail(r) {
  const acts = [];
  if (canRetry(r)) {
    const b = el('button', 'btn sm', 'Retry');
    b.onclick = () => {
      if (!confirmRetry(r)) return;
      Drawer.close(); act1(`/console/requests/${encodeURIComponent(r.request_id)}/retry`,
                           'POST', 'req-msg', () => TABLES.requests.refresh());
    };
    acts.push(b);
  }
  if (may('requests.cancel') && r.status === 'queued') {
    const b = el('button', 'btn sm ghost', 'Cancel request');
    b.onclick = () => {
      if (!confirm('Cancel this queued request?')) return;
      Drawer.close(); act1(`/console/requests/${encodeURIComponent(r.request_id)}`, 'DELETE',
                           'req-msg', () => TABLES.requests.refresh());
    };
    acts.push(b);
  }
  // Also for a request that failed before any screenshot was recorded:
  // its folder may still hold the steps taken (RQ-09).
  if ((r.evidence_path || r.status === 'failed') && may('evidence.view')) {
    const b = el('button', 'btn sm ghost', 'Open evidence');
    b.onclick = () => openEvidence(r.request_id);
    acts.push(b);
  }
  Drawer.open('Request ' + (r.ticket_id || r.request_id), r.request_id, body => {
    body.appendChild(kvList([
      ['Status', statusTag(r.status, r)],
      ['Operation', label('operation', r.operation)],
      ['Ticket', r.ticket_id], ['Source', label('source', r.source)],
      ['Affiliation code', r.affiliation_code], ['Employee code', r.employee_code],
      ['Result code', r.result_code], ['Error', r.error],
      ['Attempts', String(r.attempt_count ?? 0)],
      ['Received (JST)', fmtTime(r.enqueued_at)],
      ['Started (JST)', fmtTime(r.started_at)],
      ['Finished (JST)', fmtTime(r.completed_at)],
      ['Next attempt (JST)', fmtTime(r.next_attempt_at)],
      ['Request ID', r.request_id]
    ]));
    const meta = metaPairs(r.metadata);
    if (meta.length) { body.appendChild(el('h4', null, 'Ticket details'));
                       body.appendChild(kvList(meta)); }
    relatedEvents(body, r.request_id);
  }, acts);
}

function transactionDetail(t) {
  const acts = [];
  if ((t.screenshot_count || t.status === 'failed') && may('evidence.view')) {
    const b = el('button', 'btn sm ghost', 'Open evidence');
    b.onclick = () => openEvidence(t.request_id);
    acts.push(b);
  }
  Drawer.open('Transaction ' + (t.ticket_id || t.transaction_id), t.transaction_id, body => {
    body.appendChild(kvList([
      ['Status', statusTag(t.status, t)],
      ['Operation', label('operation', t.operation)],
      ['Ticket', t.ticket_id], ['Source', label('source', t.source)],
      ['Affiliation code', t.affiliation_code], ['Employee code', t.employee_code],
      ['Result code', t.result_code], ['Error', t.error_message],
      ['Submitted (JST)', fmtTime(t.submitted_at)],
      ['Started (JST)', fmtTime(t.started_at)],
      ['Completed (JST)', fmtTime(t.completed_at)],
      ['Processing time', fmtSecs(t.duration_seconds)],
      ['Attempts', String(t.attempt_count ?? '')],
      ['Screenshots', String(t.screenshot_count ?? 0)],
      ['Operator', t.operator], ['Worker', String(t.worker_id ?? '')],
      ['Request ID', t.request_id], ['Transaction ID', t.transaction_id]
    ]));
    const meta = metaPairs(t.metadata);
    if (meta.length) { body.appendChild(el('h4', null, 'Ticket details'));
                       body.appendChild(kvList(meta)); }
    relatedEvents(body, t.request_id);
  }, acts);
}

function auditDetail(e) {
  Drawer.open(humanize(e.action), `${label('category', e.category)} · ${fmtTime(e.occurred_at)}`, body => {
    body.appendChild(kvList([
      ['Severity', label('severity', e.severity)],
      ['Category', label('category', e.category)],
      ['Action', humanize(e.action)],
      ['When (JST)', fmtTime(e.occurred_at)],
      ['Request ID', e.request_id], ['Ticket', e.ticket_id],
      ['Operation', label('operation', e.operation)],
      ['Affiliation code', e.affiliation_code], ['Employee code', e.employee_code],
      ['Status', e.status ? label('status', e.status) : ''],
      ['Result code', e.result_code], ['Error', e.error_message],
      ['Source', e.source], ['Service', e.service_instance],
      ['Event ID', e.event_id]
    ]));
    if (e.detail && typeof e.detail === 'object' && Object.keys(e.detail).length) {
      body.appendChild(el('h4', null, 'Detail'));
      body.appendChild(kvList(Object.entries(e.detail).map(([k, v]) =>
        [humanize(k), typeof v === 'object' ? JSON.stringify(v) : String(v)])));
    }
  }, e.request_id && may('requests.view') ? (() => {
    const b = el('button', 'btn sm ghost', 'Find the request');
    b.onclick = () => { switchView('requests');
                        TABLES.requests.search.value = e.request_id;
                        TABLES.requests.state.q = e.request_id;
                        TABLES.requests.refresh(); };
    return [b];
  })() : []);
}

/* ── requests ─────────────────────────────────────────────────── */
function opSelect(id) {
  const s = el('select'); s.id = id;
  [['', 'All operations'], ['provision', 'Provision'], ['deprovision', 'Deprovision']]
    .forEach(([v, t]) => { const o = el('option', null, t); o.value = v; s.appendChild(o); });
  return s;
}
function srcSelect(id) {
  const s = el('select'); s.id = id;
  [['', 'All sources'], ['servicenow', 'ServiceNow'], ['sailpoint', 'SailPoint'],
   ['manual', 'Console or API (not specified)'], ['api', 'API'], ['cli', 'Command line']]
    .forEach(([v, t]) => { const o = el('option', null, t); o.value = v; s.appendChild(o); });
  return s;
}
function dateInput(id) { const d = el('input'); d.type = 'date'; d.id = id; return d; }

async function exportCsv(path, params, msgId) {
  try {
    const info = await download(path + qs(Object.assign({ q: params.q, sort: params.sort,
                                                          order: params.order }, params.filters)),
                                'export.csv');
    if (!info) return;
    msg(msgId, info.truncated ? 'banner' : 'okmsg', exportText(info), info.truncated ? 0 : 6000);
  } catch (e) { msg(msgId, 'err', e.message, 8000); }
}

LOADERS.requests = guard(async () => {
  if (!TABLES.requests) {
    TABLES.requests = new DataTable({
      host: $('req-table'), id: 'requests', caption: 'Requests',
      searchLabel: 'Search requests',
      defaultSort: { key: 'enqueued_at', order: 'desc' },
      filters: [
        { key: 'status', label: 'Status', el: $('req-status') },
        { key: 'operation', label: 'Operation', el: opSelect('req-op') },
        { key: 'source', label: 'Source', el: srcSelect('req-src') },
        { key: 'date_from', label: 'Received from', el: dateInput('req-from') },
        { key: 'date_to', label: 'Received to', el: dateInput('req-to') }],
      columns: [
        { key: 'enqueued_at', label: 'Received (JST)', sort: true, cls: 'mono',
          render: r => fmtTime(r.enqueued_at) },
        { key: 'ticket_id', label: 'Ticket', sort: true, cls: 'mono' },
        { key: 'operation', label: 'Operation', sort: true,
          render: r => label('operation', r.operation) },
        { key: 'kind', label: 'Request type',
          render: r => (r.metadata && r.metadata.category)
            ? label('kind', r.metadata.category) : '' },
        { key: 'affiliation_code', label: 'Affiliation', sort: true, cls: 'mono' },
        { key: 'employee_code', label: 'Employee code', sort: true, cls: 'mono' },
        { key: 'status', label: 'Status', sort: true, render: r => statusTag(r.status, r) },
        { key: 'result_code', label: 'Result code', sort: true, cls: 'mono' },
        { key: 'attempt_count', label: 'Attempts', sort: true },
        { key: 'source', label: 'Source', sort: true, hidden: true,
          render: r => label('source', r.source) },
        { key: 'completed_at', label: 'Finished (JST)', sort: true, cls: 'mono',
          hidden: true, render: r => fmtTime(r.completed_at) },
        { key: 'error', label: 'Error', cls: 'dim',
          render: r => (r.error || '').slice(0, 80) },
        { key: 'request_id', label: 'Request ID', sort: true, cls: 'mono', hidden: true },
        { key: '_actions', label: 'Actions', render: r => requestActions(r) }],
      load: async p => {
        // "Needs verification" = done + UNCONFIRMED, as on History (E2E-L07).
        const d = await api('/console/requests' + qs(Object.assign({
          offset: p.offset, limit: p.limit, sort: p.sort, order: p.order, q: p.q
        }, historyFilters(p.filters))));
        return { rows: d.requests || [], total: d.total ?? (d.requests || []).length };
      },
      onRow: requestDetail,
      exportFn: p => exportCsv('/console/export/requests',
        Object.assign({}, p, { filters: historyFilters(p.filters) }), 'req-msg'),
      emptyText: 'No requests match.'
    });
  }
  requestActionsBar();
  await TABLES.requests.refresh();
});

/* Above the Requests table (RQ-12, 2026-10-03): a new request, and Retry
 * or Cancel for every row shown — after a mainframe outage, for
 * example. Each button by permission. */
function requestActionsBar() {
  const bar = $('req-actions');
  if (bar.dataset.built) return;
  bar.dataset.built = '1';
  if (may('requests.submit')) {
    const b = el('button', 'btn sm', 'New request');
    b.onclick = openRequestForm;
    bar.appendChild(b);
  }
  if (may('requests.retry')) {
    const b = el('button', 'btn sm ghost', 'Retry the failed requests shown');
    b.onclick = busy(b, () => bulkAction('retry'));
    bar.appendChild(b);
  }
  if (may('requests.cancel')) {
    const b = el('button', 'btn sm ghost', 'Cancel the queued requests shown');
    b.onclick = busy(b, () => bulkAction('cancel'));
    bar.appendChild(b);
  }
}

async function bulkAction(kind) {
  const table = TABLES.requests;
  if (!table) return;
  const retry = kind === 'retry';
  const rows = (table.rows || []).filter(r => retry ? canRetry(r) : r.status === 'queued');
  if (!rows.length) {
    return msg('req-msg', 'banner', retry
      ? 'No failed request shown on this page can be retried.'
      : 'No queued request is shown on this page.', 6000);
  }
  if (!confirm(retry
      ? `Retry ${rows.length} failed request(s) shown on this page?\n\nEach one is carried out on the mainframe again.`
      : `Cancel ${rows.length} queued request(s) shown on this page?`)) return;
  let done = 0;
  const refused = [];
  for (const r of rows) {
    const path = `/console/requests/${encodeURIComponent(r.request_id)}` + (retry ? '/retry' : '');
    try { await api(path, { method: retry ? 'POST' : 'DELETE' }); done++; }
    catch (e) {
      if (e.status === 401) return signOut();
      // Without the closing full stop, so the list reads cleanly (UAT-L12).
      refused.push(`${r.ticket_id || r.request_id}: ${String(e.message).replace(/[.\s]+$/, '')}`);
    }
  }
  msg('req-msg', refused.length ? 'err' : 'okmsg',
      `${done} request(s) ${retry ? 're-queued' : 'cancelled'}.` +
      (refused.length ? ` ${refused.length} refused — ${refused.slice(0, 3).join('; ')}` +
                        (refused.length > 3 ? '; …' : '') : ''), refused.length ? 0 : 6000);
  await table.refresh();
}

function openRequestForm() {
  ['rf-aff', 'rf-emp', 'rf-ticket', 'rf-pass'].forEach(id => { $(id).value = ''; });
  $('rf-op').value = 'provision';
  show($('rf-pass-row'), true);
  show($('req-form'), true);
  $('rf-aff').focus();
}

async function submitRequestForm() {
  const op = $('rf-op').value;
  const body = { operation: op, affiliation_code: $('rf-aff').value.trim(),
                 employee_code: $('rf-emp').value.trim(),
                 ticket_id: $('rf-ticket').value.trim(), source: 'manual' };
  if (op === 'provision' && $('rf-pass').value) body.password = $('rf-pass').value;
  $('rf-save').disabled = true;
  try {
    const r = await api('/console/requests', { method: 'POST', body });
    $('rf-pass').value = '';
    show($('req-form'), false);
    msg('req-msg', 'okmsg', `Request ${r.request_id} was queued` +
        (r.queue_position ? ` (position ${r.queue_position})` : '') + `. ${r.message || ''}`, 8000);
    if (TABLES.requests) TABLES.requests.refresh();
  } catch (e) {
    // The form stays open to correct the value named in the message.
    msg('req-msg', 'err', e.message);
  } finally {
    $('rf-save').disabled = false;
  }
}

/* Retry (failed) and Cancel (queued) straight from the row. By
 * PERMISSION, not role name — a custom role with requests.retry sees
 * Retry, a role without requests.cancel does not see Cancel. */
function requestActions(r) {
  const box = el('div', 'row');
  box.style.flexWrap = 'nowrap';
  if (canRetry(r)) {
    const b = el('button', 'btn sm ghost', 'Retry');
    b.setAttribute('aria-label', 'Retry request ' + (r.ticket_id || r.request_id));
    b.onclick = () => {
      if (!confirmRetry(r)) return;
      act1(`/console/requests/${encodeURIComponent(r.request_id)}/retry`, 'POST', 'req-msg',
           () => TABLES.requests.refresh(), b);
    };
    box.appendChild(b);
  }
  if (may('requests.cancel') && r.status === 'queued') {
    const b = el('button', 'btn sm ghost', 'Cancel');
    b.setAttribute('aria-label', 'Cancel request ' + (r.ticket_id || r.request_id));
    b.onclick = () => {
      if (!confirm(`Cancel the queued request ${r.ticket_id || r.request_id}?`)) return;
      act1(`/console/requests/${encodeURIComponent(r.request_id)}`, 'DELETE', 'req-msg',
           () => TABLES.requests.refresh(), b);
    };
    box.appendChild(b);
  }
  if (!box.children.length) return '—';
  return box;
}

async function act1(path, method, msgId, reload, btn, done) {
  msg(msgId, '', '');
  if (btn) btn.disabled = true;
  try {
    const r = await api(path, { method });
    // done: what the caller did, e.g. a deleted account (E2E-L21).
    msg(msgId, 'okmsg', (r && r.message) || done ||
        (method === 'DELETE' ? 'The request was cancelled.' : 'Done.'), 6000);
  } catch (e) {
    msg(msgId, 'err', e.message);
    if (e.status === 401) return signOut();
  } finally {
    if (btn) btn.disabled = false;
  }
  // The list is read again after every answer, also a refusal: the row
  // shows what the service holds now (RQ-08).
  try { reload(); } catch (e) { }
}

/* ── transaction history ──────────────────────────────────────── */
/* "Needs verification" is a completed transaction whose result could not
 * be read on the terminal (RQ-06, 2026-10-03). */
function historyFilters(f) {
  const out = Object.assign({}, f || {});
  if (out.status === 'unconfirmed') { out.status = 'done'; out.result_code = 'UNCONFIRMED'; }
  return out;
}
LOADERS.history = guard(async () => {
  if (!TABLES.history) {
    const status = el('select'); status.id = 'hi-status';
    [['', 'All outcomes'], ['done', 'Completed'],
     ['unconfirmed', 'Needs verification (result not confirmed)'], ['failed', 'Failed'],
     ['already_deleted', 'Already removed'], ['cancelled', 'Cancelled']]
      .forEach(([v, t]) => { const o = el('option', null, t); o.value = v; status.appendChild(o); });
    TABLES.history = new DataTable({
      host: $('hi-table'), id: 'history', caption: 'Transaction history',
      searchLabel: 'Search history',
      defaultSort: { key: 'completed_at', order: 'desc' },
      filters: [
        { key: 'status', label: 'Outcome', el: status },
        { key: 'operation', label: 'Operation', el: opSelect('hi-op') },
        { key: 'source', label: 'Source', el: srcSelect('hi-src') },
        { key: 'date_from', label: 'Completed from', el: dateInput('hi-from') },
        { key: 'date_to', label: 'Completed to', el: dateInput('hi-to') }],
      columns: [
        { key: 'completed_at', label: 'Completed (JST)', sort: true, cls: 'mono',
          render: r => fmtTime(r.completed_at) },
        { key: 'ticket_id', label: 'Ticket', sort: true, cls: 'mono' },
        { key: 'operation', label: 'Operation', sort: true,
          render: r => label('operation', r.operation) },
        { key: 'affiliation_code', label: 'Affiliation', sort: true, cls: 'mono' },
        { key: 'employee_code', label: 'Employee code', sort: true, cls: 'mono' },
        { key: 'status', label: 'Outcome', sort: true, render: r => statusTag(r.status, r) },
        { key: 'result_code', label: 'Result code', sort: true, cls: 'mono' },
        { key: 'duration_seconds', label: 'Time', sort: true,
          render: r => fmtSecs(r.duration_seconds) },
        { key: 'attempt_count', label: 'Attempts', sort: true },
        { key: 'screenshot_count', label: 'Evidence', render: r => evidenceLink(r) },
        { key: 'source', label: 'Source', sort: true, hidden: true,
          render: r => label('source', r.source) },
        { key: 'operator', label: 'Operator', sort: true, hidden: true },
        { key: 'error_message', label: 'Error', cls: 'dim', hidden: true,
          render: r => (r.error_message || '').slice(0, 80) },
        { key: 'transaction_id', label: 'Transaction ID', sort: true, cls: 'mono', hidden: true }],
      load: async p => {
        const d = await api('/console/transactions' + qs(Object.assign({
          offset: p.offset, limit: p.limit, sort: p.sort, order: p.order, q: p.q
        }, historyFilters(p.filters))));
        return { rows: d.transactions || [], total: d.total ?? (d.transactions || []).length };
      },
      onRow: transactionDetail,
      exportFn: p => exportCsv('/console/export/transactions',
                               Object.assign({}, p, { filters: historyFilters(p.filters) }), 'hi-msg'),
      emptyText: 'No transactions match.'
    });
  }
  await TABLES.history.refresh();
});

/* ── evidence ─────────────────────────────────────────────────── */
function openEvidence(requestId) {
  // The request is set first and the page loads it once (RQ-04,
  // 2026-10-03): loading the page with the previous request and then
  // again mixed the screenshots of two requests.
  $('ev-id').value = requestId;
  switchView('evidence');
}

/* Each evidence load is numbered; images of an earlier load are not
 * shown once a newer one started (RQ-04). */
let EV_SEQ = 0;
LOADERS.evidence = guard(async () => {
  const seq = ++EV_SEQ;
  const id = $('ev-id').value.trim();
  const body = $('ev-body'), msgBox = $('ev-msg');
  body.textContent = ''; msgBox.textContent = ''; msgBox.className = '';
  releaseImages();
  if (!id) {
    body.appendChild(el('p', 'dimmer', 'Enter a request ID, or open the ' +
      'evidence from a row on the Requests or Transaction history page.'));
    return;
  }
  let d;
  try {
    // As a query value: a split ticket's number ("SCTASK…/1") holds a
    // "/" that the address path cannot carry (UAT-L08, 2026-10-04).
    d = await api('/console/evidence' + qs({ ref: id }));
  } catch (e) {
    if (e.status === 401 || e.status === 428) throw e;
    if (seq !== EV_SEQ) return;
    msgBox.className = 'err'; msgBox.textContent = e.message;
    return;
  }
  if (seq !== EV_SEQ) return;
  if (d.placeholders) {
    body.appendChild(el('div', 'banner',
      `${d.placeholders} of ${d.count} screenshots are blank: the screen ` +
      `capture did not work for those steps, so the evidence is incomplete.`));
  }
  // A ticket number entered in the box is answered with its request
  // (RQ-09, 2026-10-03); the files are read under the request ID.
  const rid = d.request_id;
  body.appendChild(el('p', 'sub', `${d.count} screenshots for request ${rid}` +
    (d.ticket_id ? ` (ticket ${d.ticket_id})` : '') +
    '. A retry adds its screenshots to the same request; the times tell the attempts apart.'));

  const grid = el('div', 'shots');
  d.captures.forEach(c => {
    const s = el('button', 'shot' + (c.placeholder ? ' blank' : ''));
    s.type = 'button';
    s.setAttribute('aria-label', `Open screenshot ${c.sequence}: ${humanize(c.step)}` +
                                 (c.taken_at ? ` (${fmtTime(c.taken_at)})` : ''));
    const img = el('img');
    img.alt = '';
    img.loading = 'lazy';
    // The API needs the bearer token, which <img> cannot send — fetch
    // it and hand the tag an object URL instead. Marked as a thumbnail:
    // the audited listing above already records what the grid shows.
    fetchAuthed(`${API}/console/evidence/${encodeURIComponent(rid)}/` +
                encodeURIComponent(c.name) + '?purpose=thumbnail')
      .then(u => { if (u && seq === EV_SEQ) img.src = u; else releaseImage(u); });
    s.appendChild(img);
    s.appendChild(el('div', 'cap', `${c.sequence} · ${humanize(c.step)}` +
                                   (c.taken_at ? ` · ${String(c.taken_at).slice(11, 19)}` : '')));
    s.onclick = () => showCapture(rid, c);
    grid.appendChild(s);
  });
  body.appendChild(grid);
});

async function fetchAuthed(url) {
  try {
    const r = await fetchAuthedRaw(url);
    if (!r.ok) return null;
    const u = URL.createObjectURL(await r.blob());
    IMAGE_URLS.add(u);
    return u;
  } catch (e) { return null; }
}

/* Screenshot images held by the page (object URLs). Released when the
 * evidence page loads another request, the viewer closes, or the user
 * signs out, so no screenshot stays in memory (RQ-05, 2026-10-03). */
const IMAGE_URLS = new Set();
function releaseImage(u) {
  if (!u) return;
  URL.revokeObjectURL(u);
  IMAGE_URLS.delete(u);
}
function releaseImages() {
  IMAGE_URLS.forEach(u => URL.revokeObjectURL(u));
  IMAGE_URLS.clear();
}

/* Everything one user saw that the next one must not (RQ-05): evidence,
 * the screenshot viewer, every table, the drawer, the latest
 * transactions, and what the other pages showed (UAT-08). Run on
 * sign-out and on sign-in. Each area is drawn afresh by its page's
 * loader on the next visit. */
function clearSensitive() {
  EV_SEQ++;                       // a load still running is dropped
  DASH_SIG = '';                  // the dashboard is drawn afresh
  DASH_METRICS_SIG = '';
  $('ev-id').value = '';
  $('ev-body').textContent = '';
  $('ev-msg').textContent = ''; $('ev-msg').className = '';
  show($('viewer'), false);
  $('vw-img').removeAttribute('src');
  $('vw-txt').textContent = '';
  $('vw-name').textContent = '';
  VIEWER_FOCUS = null;
  releaseImages();
  // A table hands its filter controls back to the page before it is
  // emptied; emptying its host directly deleted them, and Requests and
  // Audit trail stayed blank after the next sign-in (UAT-02).
  Object.values(TABLES).forEach(t => t.destroy());
  ['dash-recent', 'dash-cards', 'dash-restart', 'sys-restart', 'dr-body', 'dr-sub', 'req-actions',
   'rules-history-body', 'rl-body', 'nr-perms',
   'set-nav', 'set-body', 'set-deploy',
   'sys-cards', 'sys-controls', 'sys-problems', 'sys-selftest',
   'sys-outbox-body', 'sys-files-body', 'us-sessions',
   'rp-period-label', 'rp-kpis', 'rp-charts', 'rp-audit-kpis',
   'rp-audit-charts', 'rp-printed', 'wz-body']
    .forEach(id => { const n = $(id); if (n) n.textContent = ''; });
  ['req-msg', 'hi-msg', 'au-msg', 'us-msg', 'rl-msg', 'set-msg', 'sys-msg',
   'rp-msg'].forEach(id => {
    const n = $(id);
    if (!n) return;
    clearTimeout(n._msgTimer); n._msgTimer = null;
    n.textContent = ''; n.className = '';
  });
  // The actions offered depend on who is signed in: built again.
  delete $('req-actions').dataset.built;
  show($('sys-problems'), false);
  show($('dash-restart'), false); show($('sys-restart'), false);
  PENDING = 0; PENDING_AT = 0;
  $('sys-log').textContent = '—';
  $('dr-title').textContent = 'Details';
  // Half-filled forms (a new account's e-mail, a typed password).
  ['req-form', 'us-form', 'rl-form'].forEach(id => {
    const f = $(id);
    show(f, false);
    f.querySelectorAll('input, select, textarea').forEach(i => {
      if (i.type === 'checkbox' || i.type === 'radio') i.checked = false;
      else if (i.tagName === 'SELECT') i.selectedIndex = 0;
      else i.value = '';
    });
  });
  if (!$('wizard').classList.contains('hide')) show($('wizard'), false);
  WZ = { step: 0, state: {}, tests: {}, settings: null, deploy: null };
  WIZARD_DISMISSED = false;       // the next person decides for themself
  CURRENT_VIEW = null;
  SETTINGS_META = null; DEPLOY = null;
  USERS_DATA = []; ROLES_INFO = [];
  if (Drawer.isOpen()) Drawer.close();
}

/* Where the focus was before a dialog opened, to return it on close. */
let VIEWER_FOCUS = null;
function restoreFocus(node) {
  if (node && node.focus && document.body.contains(node) &&
      node.offsetParent !== null) node.focus();
}

function closeViewer() {
  show($('viewer'), false);
  // The full screenshot can show a password: not kept after closing.
  const shown = $('vw-img').getAttribute('src');
  $('vw-img').removeAttribute('src');
  $('vw-txt').textContent = '';
  releaseImage(shown);
  restoreFocus(VIEWER_FOCUS);
  VIEWER_FOCUS = null;
}

async function showCapture(id, c) {
  if ($('viewer').classList.contains('hide')) VIEWER_FOCUS = document.activeElement;
  $('vw-name').textContent = `${c.sequence} · ${humanize(c.step)}`;
  $('vw-img').removeAttribute('src');
  $('vw-txt').textContent = 'Loading…';
  show($('viewer'), true);
  $('vw-close').focus();
  const base = `${API}/console/evidence/${encodeURIComponent(id)}/`;
  const u = await fetchAuthed(base + encodeURIComponent(c.name));
  if (u) $('vw-img').src = u;
  if (c.text) {
    try {
      const r = await fetchAuthedRaw(base + encodeURIComponent(c.text));
      $('vw-txt').textContent = r.ok ? await r.text()
                                     : 'The screen text could not be loaded.';
    } catch (e) { $('vw-txt').textContent = 'The screen text could not be loaded.'; }
  } else {
    $('vw-txt').textContent = 'No screen text was saved for this screenshot.';
  }
}

/* ── audit ────────────────────────────────────────────────────── */
LOADERS.audit = guard(async () => {
  if (!TABLES.audit) {
    TABLES.audit = new DataTable({
      host: $('au-body'), id: 'audit', caption: 'Audit trail',
      searchLabel: 'Search events', pageSizes: [50, 100, 25],
      defaultSort: { key: 'occurred_at', order: 'desc' },
      filters: [
        { key: 'category', label: 'Category', el: $('au-cat') },
        { key: 'severity', label: 'Severity', el: $('au-sev') },
        { key: 'request_id', label: 'Request ID', el: $('au-req') },
        { key: 'date_from', label: 'From', el: dateInput('au-from') },
        { key: 'date_to', label: 'To', el: dateInput('au-to') }],
      columns: [
        { key: 'occurred_at', label: 'When (JST)', sort: true, cls: 'mono',
          render: e => fmtTime(e.occurred_at) },
        { key: 'severity', label: 'Severity', sort: true,
          render: e => el('span', 'tag ' + (e.severity === 'ERROR' || e.severity === 'CRITICAL'
            ? 'failed' : e.severity === 'WARNING' ? 'running' : ''),
            label('severity', e.severity)) },
        { key: 'category', label: 'Category', sort: true,
          render: e => label('category', e.category) },
        { key: 'action', label: 'Action', sort: true, render: e => humanize(e.action) },
        { key: 'actor', label: 'By',
          render: e => (e.detail && (e.detail.actor || e.detail.username)) || '' },
        { key: 'request_id', label: 'Request', sort: true, cls: 'mono' },
        { key: 'ticket_id', label: 'Ticket', sort: true, cls: 'mono', hidden: true },
        { key: 'employee_code', label: 'Employee code', sort: true, cls: 'mono', hidden: true },
        { key: 'detail', label: 'Detail', cls: 'dim',
          render: e => eventDetailText(e.detail).slice(0, 110) }],
      load: async p => {
        try {
          const d = await api('/console/audit/events' + qs(Object.assign({
            offset: p.offset, limit: p.limit, sort: p.sort, order: p.order, q: p.q
          }, p.filters)));
          // Events still on this machine, not yet in the audit database
          // (DR-07, 2026-10-03).
          if (d.pending_delivery) msg('au-msg', 'banner', `${fmtNum(d.pending_delivery)} ` +
            'event(s) waiting to be written to the audit database; they are listed once written.');
          // All written: the notice goes (UAT-L25), other messages stay.
          else if (/waiting to be written/.test($('au-msg').textContent)) msg('au-msg', '', '');
          return { rows: d.events || [], total: d.total ?? (d.events || []).length };
        } catch (e) {
          if (e.status === 503) throw new Error(auditErrorText(e));
          throw e;
        }
      },
      onRow: auditDetail,
      exportFn: p => exportCsv('/console/export/audit', p, 'au-msg'),
      emptyText: 'No events match.'
    });
  }
  await TABLES.audit.refresh();
});

/* A 503 from an audit read: the audit database is out of reach (the
 * service says how many events are waiting to be written) or the audit
 * trail is turned off (NB-016). */
function auditErrorText(e) {
  const detail = e && e.data && e.data.detail;
  if (e && e.status === 503 && detail && typeof detail === 'object' &&
      detail.status === 'audit_unavailable')
    return e.message;
  return 'The audit trail is turned off on this service.';
}

/* ── error rules ──────────────────────────────────────────────── */
let RULES_DATA = [];
LOADERS.rules = guard(async () => {
  const d = await api('/console/error-rules');
  RULES_DATA = d.rules.map(r => Object.assign({}, r, { markers_text: (r.markers || []).join(' , ') }));
  $('rules-sub').textContent =
    `${d.count} error screens are recognised. Catalogue version ` +
    `${String(d.digest || '').slice(0, 12)} — the same version is recorded ` +
    `with every error screen the bot recognises (audit trail).`;
  // A file the bot would refuse is said so (UR-10, 2026-10-03).
  const probs = $('rules-problems');
  probs.textContent = (d.problems || []).length
    ? 'The catalogue file has a problem: the bot would refuse it and stop ' +
      'processing. ' + d.problems.join(' ') : '';
  show(probs, (d.problems || []).length > 0);
  loadRuleHistory();
  if (!TABLES.rules) {
    TABLES.rules = new DataTable({
      host: $('rules-body'), id: 'rules', caption: 'Error rules',
      searchLabel: 'Search rules', pageSizes: [50, 100, 25],
      defaultSort: { key: 'priority', order: 'asc' },
      columns: [
        { key: 'priority', label: 'Order', sort: true },
        { key: 'id', label: 'Rule', sort: true, render: r => {
            const d2 = el('div'); d2.appendChild(el('div', 'mono', r.id));
            d2.appendChild(el('div', 'dim', r.name)); return d2; } },
        { key: 'scope', label: 'Screen', sort: true, cls: 'dim' },
        { key: 'markers_text', label: 'Recognised by', cls: 'mono' },
        { key: 'action', label: 'Bot action', sort: true,
          render: r => humanize(r.action) + (r.then && r.action === 'acknowledge'
            ? ' → ' + humanize(r.then) : '') },
        { key: 'classification', label: 'Type', sort: true,
          render: r => el('span', 'tag ' + (r.classification === 'business' ? 'failed' : 'running'),
                          humanize(r.classification)) },
        { key: 'retry_whole_request', label: 'Retry',
          render: r => r.retry_whole_request ? 'Whole request' : 'No' },
        { key: 'enabled', label: 'In use', sort: true, render: r => {
            if (!may('rules.edit')) return el('span', r.enabled ? 'ok' : 'dim', r.enabled ? 'On' : 'Off');
            const b = el('button', 'btn sm ghost', r.enabled ? 'Turn off' : 'Turn on');
            b.setAttribute('aria-label', (r.enabled ? 'Turn off rule ' : 'Turn on rule ') + r.id);
            b.onclick = async () => {
              // A safety rule is never switched with one click (UR-07,
              // 2026-10-03): the rule is named, a reason is required and
              // recorded in the audit trail.
              const turning = r.enabled ? 'off' : 'on';
              if (!confirm(`Turn ${turning} the rule ${r.id} (${r.name})?\n\n` +
                           'It applies from the next transaction.')) return;
              const reason = (prompt(`Why is ${r.id} turned ${turning}? ` +
                                     '(recorded in the audit trail)') || '').trim();
              if (!reason) {
                return msg('rules-msg', 'banner', 'Not changed: a reason is required.', 6000);
              }
              b.disabled = true;
              try {
                await api('/console/error-rules/' + encodeURIComponent(r.id),
                          { method: 'PATCH', body: { enabled: !r.enabled, reason } });
                msg('rules-msg', 'okmsg', `${r.id} turned ${turning}.`, 6000);
              } catch (e) { msg('rules-msg', 'err', e.message); }
              LOADERS.rules();
            };
            return b; } }],
      load: localLoader(() => RULES_DATA, ['id', 'name', 'scope', 'markers_text', 'action',
                                           'classification', 'message']),
      onRow: r => Drawer.open(r.id, r.name, body => body.appendChild(kvList([
        ['In use', r.enabled ? 'Yes' : 'No'], ['Order', String(r.priority)],
        ['Screen', r.scope], ['Recognised by', r.markers_text],
        ['Bot action', humanize(r.action)], ['Then', r.then ? humanize(r.then) : ''],
        ['Type', humanize(r.classification)], ['Error raised', r.exception],
        ['Request status', r.status ? label('status', r.status) : ''],
        ['Exit from', r.exit_from], ['Retry', r.retry_whole_request ? 'Whole request' : 'No'],
        ['Message', r.message]]))),
      emptyText: 'No rules match.'
    });
  }
  await TABLES.rules.refresh();
});

/* The last rule changes, from the audit trail (UR-07). */
async function loadRuleHistory() {
  const box = $('rules-history');
  if (!may('audit.view')) return show(box, false);
  const body = $('rules-history-body');
  try {
    const d = await api('/console/audit/events' + qs({
      category: 'console', action: 'error_rule_toggled', limit: 10, offset: 0,
      sort: 'occurred_at', order: 'desc' }));
    body.textContent = '';
    if (!(d.events || []).length) {
      body.appendChild(el('p', 'dimmer', 'No rule has been changed from the console.'));
    } else {
      const t = el('table');
      const head = el('tr');
      ['When (JST)', 'By', 'Rule', 'Change', 'Reason'].forEach(h => {
        const th = el('th', null, h); th.scope = 'col'; head.appendChild(th); });
      t.appendChild(head);
      d.events.forEach(e => {
        const x = e.detail || {};
        const tr = el('tr');
        tr.appendChild(el('td', 'mono', fmtTime(e.occurred_at)));
        tr.appendChild(el('td', null, x.actor || ''));
        tr.appendChild(el('td', 'mono', x.rule || ''));
        tr.appendChild(el('td', null, `${x.before ? 'On' : 'Off'} → ${x.after ? 'On' : 'Off'}`));
        tr.appendChild(el('td', null, x.reason || '—'));
        t.appendChild(tr);
      });
      const wrap = el('div', 'dt'); wrap.appendChild(t); body.appendChild(wrap);
    }
    show(box, true);
  } catch (e) { show(box, false); }
}

/* ── users ────────────────────────────────────────────────────── */
let ROLE_NAMES = [];
let ROLES_INFO = [];           // {name, is_builtin, assignable} (UR-02)
/* Whether this user may change account u: its role grants nothing they
 * do not hold themselves (UAT-L13). Their own account always opens. */
function mayChange(u) {
  if (ME && u.user_id === ME.user_id) return true;
  const r = ROLES_INFO.find(x => x.name === u.role);
  return !r || !!r.assignable;
}
let USERS_DATA = [];

LOADERS.users = guard(async () => {
  show($('us-new'), may('users.manage'));
  show($('us-export'), may('users.manage') || may('users.view'));
  // The role names answer to users.manage or users.view, so a user
  // administrator without role management sees custom roles too (UR-02).
  try {
    ROLES_INFO = (await api('/admin/role-names')).roles;
  } catch (e) { ROLES_INFO = []; }
  ROLE_NAMES = ROLES_INFO.map(r => r.name);
  USERS_DATA = (await api('/admin/users')).users;
  if (!TABLES.users) {
    TABLES.users = new DataTable({
      host: $('us-body'), id: 'users', caption: 'Console users',
      searchLabel: 'Search users',
      defaultSort: { key: 'username', order: 'asc' },
      columns: [
        { key: 'username', label: 'Username', sort: true, cls: 'mono' },
        { key: 'display_name', label: 'Name', sort: true },
        { key: 'email', label: 'E-mail', sort: true, hidden: true },
        { key: 'role', label: 'Role', sort: true, render: u => {
            // Read-only: without users.manage, for one's own account
            // (UR-11), for a role this page does not know (UR-02: never
            // shown as another role that a change would apply), and for
            // an account this user may not change (UAT-L13).
            if (!may('users.manage') || u.user_id === ME.user_id
                || !ROLE_NAMES.includes(u.role) || !mayChange(u)) return humanize(u.role);
            const sel = el('select');
            sel.setAttribute('aria-label', 'Role for ' + u.username);
            ROLES_INFO.filter(r => r.assignable || r.name === u.role).forEach(r => {
              const o = el('option', null, humanize(r.name) + (r.is_builtin ? '' : ' (custom)'));
              o.value = r.name;
              if (u.role === r.name) o.selected = true;
              sel.appendChild(o);
            });
            sel.onchange = () => {
              if (!confirm(`Change the role of ${u.username} from ${humanize(u.role)} ` +
                           `to ${humanize(sel.value)}?\n\nTheir open sessions end.`)) {
                sel.value = u.role; return;
              }
              patchUser(u.user_id, { role: sel.value });
            };
            return sel; } },
        { key: 'windows_account', label: 'Sign-in', sort: true, cls: 'dim',
          render: u => u.windows_account ? 'Windows: ' + u.windows_account : 'Password' },
        { key: 'is_active', label: 'Active', sort: true,
          // A lock from failed sign-ins, with its end (SEC-05, 2026-10-04).
          render: u => u.locked
            ? el('span', 'bad', 'Locked until ' + fmtTime(u.locked_until))
            : el('span', u.is_active ? 'ok' : 'bad', u.is_active ? 'Yes' : 'No') },
        { key: 'last_login_at', label: 'Last sign-in (JST)', sort: true, cls: 'mono dim',
          render: u => fmtTime(u.last_login_at) || '—' },
        { key: '_actions', label: '', render: u => {
            const act = el('div', 'row');
            // An account holding rights this user does not have cannot
            // be changed by them (the service refuses it): no buttons
            // that would only answer "not allowed" (UAT-L13, 2026-10-04).
            if (!may('users.manage') || !mayChange(u)) return act;
            const edit = el('button', 'btn sm ghost', 'Edit');
            edit.setAttribute('aria-label', 'Edit the account ' + u.username);
            edit.onclick = () => openUserEdit(u);
            act.appendChild(edit);
            // Lift a lock at once; recorded in the audit trail (SEC-05).
            if (u.locked) {
              const unlock = el('button', 'btn sm ghost', 'Unlock');
              unlock.setAttribute('aria-label', 'Unlock the account ' + u.username);
              unlock.onclick = busy(unlock, async () => {
                if (!confirm(`Unlock the account ${u.username}? They can sign in ` +
                             'again at once with their current password.')) return;
                try {
                  await api('/admin/users/' + u.user_id + '/unlock', { method: 'POST' });
                  msg('us-msg', 'okmsg', `The account ${u.username} was unlocked.`, 6000);
                } catch (e) { msg('us-msg', 'err', e.message); }
                LOADERS.users();
              });
              act.appendChild(unlock);
            }
            // One's own account is never deactivated here (UR-11).
            if (u.user_id !== ME.user_id) {
              const tog = el('button', 'btn sm ghost', u.is_active ? 'Deactivate' : 'Activate');
              tog.onclick = () => {
                if (u.is_active && !confirm(`Deactivate the account ${u.username}? ` +
                                            'They are signed out at once.')) return;
                patchUser(u.user_id, { is_active: !u.is_active });
              };
              act.appendChild(tog);
            }
            if (u.user_id !== ME.user_id) {
              const del = el('button', 'btn sm ghost', 'Delete');
              del.onclick = () => {
                if (!confirm(`Delete the account ${u.username}?`)) return;
                act1('/admin/users/' + u.user_id, 'DELETE', 'us-msg', LOADERS.users,
                     null, `The account ${u.username} was deleted.`);
              };
              act.appendChild(del);
            }
            return act; } }],
      load: localLoader(() => USERS_DATA, ['username', 'display_name', 'email', 'role',
                                           'windows_account']),
      emptyText: 'No users match.'
    });
  }
  await TABLES.users.refresh();
  loadSessions();
});

async function patchUser(id, body, okText, errBox) {
  let ok = false;
  try {
    await api('/admin/users/' + id, { method: 'PATCH', body });
    msg('us-msg', 'okmsg', okText || 'Updated.', 6000);
    ok = true;
  } catch (e) {
    msg(errBox || 'us-msg', 'err', e.message);
  }
  LOADERS.users();
  return ok;
}

/* Edit an account and reset its password (UR-01, 2026-10-03), through
 * the same update route. A reset password is provisional: the user must
 * change it at the next sign-in; their sessions end and a lock from
 * failed attempts is lifted. */
function openUserEdit(u) {
  const field = (labelText, id, value, type) => {
    const w = el('div');
    const l = el('label', null, labelText); l.htmlFor = id;
    const i = el('input'); i.id = id; i.value = value || '';
    if (type) { i.type = type; i.autocomplete = 'new-password'; }
    w.append(l, i);
    return w;
  };
  const save = el('button', 'btn sm', 'Save');
  const reset = el('button', 'btn sm ghost', 'Reset password');
  Drawer.open('Edit ' + u.username, (u.locked ? 'Locked after failed sign-ins · ' : '') +
              humanize(u.role), body => {
    const grid = el('div', 'formgrid');
    grid.append(field('Display name', 'ue-name', u.display_name),
                field('E-mail', 'ue-email', u.email),
                field('Windows account (optional)', 'ue-win', u.windows_account));
    body.appendChild(grid);
    body.appendChild(el('h4', null, 'Reset the password'));
    body.appendChild(el('p', 'dimmer', 'The new password is provisional: ' +
      `${u.username} must change it at the next sign-in. Their sessions end` +
      (u.locked ? ' and the lock is lifted.' : '.')));
    const pw = el('div', 'formgrid');
    pw.append(field('New password', 'ue-pass', '', 'password'),
              field('Confirm the new password', 'ue-pass2', '', 'password'));
    body.appendChild(pw);
    const m = el('div'); m.id = 'ue-msg'; m.setAttribute('role', 'status');
    body.appendChild(m);
  }, [save, reset]);
  save.onclick = busy(save, async () => {
    if (await patchUser(u.user_id, {
          display_name: $('ue-name').value.trim(), email: $('ue-email').value.trim(),
          windows_account: $('ue-win').value.trim() },
        `The account ${u.username} was updated.`, 'ue-msg')) Drawer.close();
  });
  reset.onclick = busy(reset, async () => {
    const p1 = $('ue-pass').value, p2 = $('ue-pass2').value;
    if (!p1) return msg('ue-msg', 'err', 'Enter the new password twice.');
    if (p1 !== p2) return msg('ue-msg', 'err', 'The two passwords are not the same.');
    if (!confirm(`Reset the password of ${u.username}?`)) return;
    if (await patchUser(u.user_id, { password: p1 },
        `The password of ${u.username} was reset. They must change it at the next sign-in.`,
        'ue-msg')) {
      Drawer.close();
    }
  });
}

async function openUserForm() {
  const sel = $('nu-role');
  sel.textContent = '';
  try {
    // users.manage reads the role names (UR-02); only roles this user
    // may give are offered.
    const d = await api('/admin/role-names');
    const roles = d.roles.filter(r => r.assignable);
    roles.forEach(r => {
      const o = el('option', null,
                   `${humanize(r.name)}${r.is_builtin ? '' : ' (custom)'}`);
      o.value = r.name;
      sel.appendChild(o);
    });
    sel.value = roles.some(r => r.name === 'viewer') ? 'viewer'
              : (roles[0] ? roles[0].name : '');
  } catch (e) { /* the API will reject an unknown role anyway */ }
  ['nu-user', 'nu-name', 'nu-email', 'nu-pass', 'nu-win']
    .forEach(id => { $(id).value = ''; });
  show($('us-form'), true);
  $('nu-user').focus();
}

async function saveUser() {
  const body = {
    username: $('nu-user').value.trim(),
    display_name: $('nu-name').value.trim(),
    email: $('nu-email').value.trim(),
    role: $('nu-role').value,
    password: $('nu-pass').value,
    windows_account: $('nu-win').value.trim()
  };
  $('nu-save').disabled = true;
  try {
    await api('/admin/users', { method: 'POST', body });
    msg('us-msg', 'okmsg', `The account ${body.username} was created. ` +
        (body.password ? 'The user must change the password at first sign-in.'
                       : 'The user signs in with the Windows account.'), 6000);
    show($('us-form'), false);
    LOADERS.users();
  } catch (e) {
    // Stays until the next action: the form is still open to correct.
    msg('us-msg', 'err', e.message);
  } finally {
    $('nu-save').disabled = false;
  }
}

/* ── roles & permissions ──────────────────────────────────────── */
let CATALOGUE = null;

LOADERS.roles = guard(async () => {
  if (!CATALOGUE) CATALOGUE = await api('/admin/permissions');
  const d = await api('/admin/roles');
  const host = $('rl-body');
  host.textContent = '';

  const wrap = el('div', 'dt');
  const t = el('table');
  const head = el('tr');
  ['Role', 'Description', 'Permissions', 'Users', '']
    .forEach(h => { const th = el('th', null, h); th.scope = 'col'; head.appendChild(th); });
  t.appendChild(head);

  d.roles.forEach(r => {
    const tr = el('tr');
    const name = el('td');
    name.appendChild(el('div', null, humanize(r.name)));
    if (r.is_builtin) name.appendChild(el('div', 'dim', 'Built-in'));
    tr.appendChild(name);
    tr.appendChild(el('td', 'dim', r.description || '—'));

    const perms = el('td');
    const chips = el('div', 'chips');
    r.permissions.forEach(p => {
      const c = el('span', 'chip', p);
      c.title = (CATALOGUE.permissions || {})[p] || '';
      chips.appendChild(c);
    });
    perms.appendChild(chips);
    tr.appendChild(perms);

    tr.appendChild(el('td', null, String(r.users)));

    const act = el('td', 'row');
    if (!r.is_builtin) {
      const ed = el('button', 'btn sm ghost', 'Edit');
      ed.onclick = () => openRoleForm(r);
      act.appendChild(ed);
      const del = el('button', 'btn sm ghost', 'Delete');
      del.onclick = () => {
        if (!confirm(`Delete the role ${r.name}?`)) return;
        act1('/admin/roles/' + encodeURIComponent(r.name), 'DELETE', 'rl-msg', LOADERS.roles,
             null, `The role ${r.name} was deleted.`);
      };
      act.appendChild(del);
    } else {
      act.appendChild(el('span', 'dim', 'Part of the release'));
    }
    tr.appendChild(act);
    t.appendChild(tr);
  });
  const scroll = el('div', 'dt-wrap');
  scroll.appendChild(t);
  wrap.appendChild(scroll);
  host.appendChild(wrap);
});

let EDITING_ROLE = null;

async function openRoleForm(role) {
  if (!CATALOGUE) CATALOGUE = await api('/admin/permissions');
  EDITING_ROLE = role || null;
  $('nr-name').value = role ? role.name : '';
  $('nr-name').disabled = !!role;      // a role's name is its identity
  $('nr-desc').value = role ? role.description : '';

  const host = $('nr-perms');
  host.textContent = '';
  const held = new Set(role ? role.permissions : []);
  Object.entries(CATALOGUE.groups).forEach(([group, names]) => {
    const box = el('div', 'permgroup');
    box.appendChild(el('h4', null, group));
    names.forEach(name => {
      const row = el('label', 'permrow');
      const cb = el('input');
      cb.type = 'checkbox';
      cb.value = name;
      cb.checked = held.has(name);
      row.appendChild(cb);
      const text = el('div');
      text.appendChild(el('div', null, CATALOGUE.permissions[name] || name));
      text.appendChild(el('div', 'd mono', name));
      row.appendChild(text);
      box.appendChild(row);
    });
    host.appendChild(box);
  });
  show($('rl-form'), true);
}

async function saveRole() {
  const permissions = Array.from(
    $('nr-perms').querySelectorAll('input:checked')).map(c => c.value);
  // A role that grants nothing is refused by the service too (E2E-L19).
  if (!permissions.length) { msg('rl-msg', 'err', 'Choose at least one permission.'); return; }
  $('nr-save').disabled = true;
  try {
    if (EDITING_ROLE) {
      await api('/admin/roles/' + encodeURIComponent(EDITING_ROLE.name), {
        method: 'PATCH',
        body: { description: $('nr-desc').value.trim(), permissions }
      });
    } else {
      await api('/admin/roles', {
        method: 'POST',
        body: { name: $('nr-name').value.trim(),
                description: $('nr-desc').value.trim(), permissions }
      });
    }
    msg('rl-msg', 'okmsg', 'Saved.', 6000);
    show($('rl-form'), false);
    LOADERS.roles();
  } catch (e) {
    msg('rl-msg', 'err', e.message);
  } finally {
    $('nr-save').disabled = false;
  }
}

/* ── settings ─────────────────────────────────────────────────── *
 * One page per group, chosen from the sub-navigation; every row stays
 * in the page (hidden when another section is chosen), so Save still
 * collects every change and conditional rows still work. */
let SETTINGS_META = null;
const SETTINGS_NAV = [
  ['Processing', ['Retry policy', 'Dispatcher', 'Operating window', 'Error handling']],
  ['Screens and evidence', ['Screen reading', 'Evidence']],
  ['Integrations', ['ServiceNow', 'Email', 'CyberArk', 'FINESIII terminal']],
  ['Security', ['Console sign-in', 'Provisioning password']],
  ['History', ['Recent changes']],
];

/* "Stored in: application database", and the last change on this
 * page: who and when (CFG-03, 2026-10-04). */
function storedLine(items) {
  const last = items.filter(s => s.changed_at)
                    .sort((a, b) => String(b.changed_at).localeCompare(String(a.changed_at)))[0];
  return el('p', 'dimmer', 'Stored in: application database' +
    (last ? ` · last change ${fmtTime(last.changed_at)} (JST) by ${last.changed_by || 'unknown'}`
          : ' · not changed here yet'));
}

/* The Settings changes recorded in the audit trail, newest first, with
 * Restore for those recorded with their earlier value (CFG-07). */
function recentChangesGroup() {
  const box = el('div', 'setgroup');
  box.dataset.group = 'Recent changes';
  box.appendChild(el('h3', null, 'Recent changes'));
  box.appendChild(el('p', 'intro', 'Changes made on these Settings pages, from the ' +
    'audit trail. Restore puts the value from before a change back; it is saved and ' +
    'recorded like any other change.'));
  const body = el('div'); body.textContent = 'Loading…';
  const refresh = el('button', 'btn sm ghost', 'Refresh');
  refresh.type = 'button';
  refresh.onclick = () => loadRecentChanges(body);
  box.append(refresh, body);
  loadRecentChanges(body);
  return box;
}

function settingText(v) {
  if (v === null || v === undefined) return '(default)';
  if (v === true || v === 'True' || v === 'true') return 'On';
  if (v === false || v === 'False' || v === 'false') return 'Off';
  return String(v) === '' ? '(empty)' : String(v);
}

async function loadRecentChanges(body) {
  let d;
  try { d = await api('/console/settings/changes?limit=50'); }
  catch (e) { body.textContent = 'The recent changes could not be loaded: ' + e.message; return; }
  body.textContent = '';
  if (!d.enabled) {
    body.appendChild(el('p', 'dimmer', 'The audit trail is turned off, so changes are not recorded.'));
    return;
  }
  if (d.available === false) {
    body.appendChild(el('p', 'dimmer', 'The audit trail cannot be read at the moment.'));
    return;
  }
  if (!d.changes.length) { body.appendChild(el('p', 'dimmer', 'No changes recorded yet.')); return; }
  const t = el('table');
  const hr = el('tr');
  ['When (JST)', 'By', 'Page', 'Setting', 'Before', 'After', ''].forEach(h => {
    const th = el('th', null, h); th.scope = 'col'; hr.appendChild(th);
  });
  t.appendChild(hr);
  d.changes.forEach(c => {
    const tr = el('tr');
    tr.appendChild(el('td', 'mono', fmtTime(c.at)));
    tr.appendChild(el('td', null, c.by));
    tr.appendChild(el('td', null, GROUP_TITLES[c.group] || c.group));
    tr.appendChild(el('td', null, c.label));
    tr.appendChild(el('td', 'mono', c.secret ? '(hidden)'
      : c.before_known ? settingText(c.before) : '(not recorded)'));
    tr.appendChild(el('td', 'mono', c.secret ? '(hidden)'
      : c.after_set ? settingText(c.after) : '(default)'));
    const act = el('td');
    if (c.before_known && may('settings.edit')) {
      const b = el('button', 'btn sm ghost', 'Restore');
      b.type = 'button';
      b.setAttribute('aria-label', `Restore ${c.label} to ${settingText(c.before)}`);
      b.onclick = busy(b, () => restoreSetting(c));
      act.appendChild(b);
    }
    tr.appendChild(act);
    t.appendChild(tr);
  });
  const wrap = el('div', 'dt'); wrap.appendChild(t); body.appendChild(wrap);
}

async function restoreSetting(c) {
  if (!confirm(`Restore "${c.label}" to ${settingText(c.before)}?`)) return;
  try {
    const r = await api('/console/settings', { method: 'PUT',
      body: { [c.key]: c.before === null ? '' : c.before },
      headers: { 'X-Settings-Revision': String((SETTINGS_META.revision || {}).rev ?? '') } });
    msg('set-msg', r.restart_required ? 'banner' : 'okmsg', `"${c.label}" was restored. ` +
        (r.restart_required ? 'Restart the service to apply it.' : 'It applies now.'));
    LOADERS.settings();
  } catch (e) { msg('set-msg', 'err', 'Not restored: ' + e.message); }
}

/* Export configuration: every setting with its value and source,
 * secrets masked, and the configuration files (CFG-03). */
async function exportConfiguration() {
  try {
    const info = await download('/system/configuration/export', 'configuration.csv');
    if (!info) return;
    msg('set-msg', 'okmsg', exportText(info), 6000);
  } catch (e) { msg('set-msg', 'err', e.message, 8000); }
}
// The machine's screen-reading page is not the module page of the
// same name (E2E-L30).
const GROUP_TITLES = { 'Email': 'E-mail', 'Machine: Screen reading': 'Screen reading (start-up)' };
const GROUP_INTROS = {
  'Retry policy': 'What happens when a request fails for a temporary reason.',
  'Dispatcher': 'How the bot takes work from the queue.',
  'Operating window': 'When requests are processed on the mainframe.',
  'Error handling': 'How the bot reacts to recognised error screens.',
  'Screen reading': 'How the bot reads and confirms what is on the screen.',
  'Evidence': 'How long screenshots are kept.',
  'ServiceNow': 'Where tickets come from, which ones the bot takes, and how the tickets are updated.',
  'Email': 'The mail server and who receives which e-mail.',
  'CyberArk': 'Where the mainframe service-account password comes from.',
  'FINESIII terminal': 'The terminal program the bot drives on this machine.',
  'Console sign-in': 'Sign-in rules for this console.',
  'Provisioning password': 'How the bot generates initial passwords for new accounts.',
  'Deployment': 'How the service starts on this machine.',
  'Database': 'Where the queue, history and audit trail are stored.',
  'Security': 'Access rules for other systems.',
  'Storage': 'Where files are kept on this machine.',
  'Credentials': 'Passwords and keys, kept in the operating system\'s credential store.'
};
let SET_PAGE = null;

LOADERS.settings = guard(async () => {
  const d = await api('/console/settings');
  SETTINGS_META = d;
  const host = $('set-body');
  host.textContent = '';
  show($('set-restart'), d.restartable && may('settings.edit'));
  show($('set-save-restart'), d.restartable && d.editable && may('settings.edit'));
  show($('set-save'), d.editable && may('settings.edit'));
  if (!d.editable) {
    host.appendChild(el('div', 'banner',
      'Settings cannot be stored on this service at the moment. It is ' +
      'running on its installed configuration only.'));
  }

  d.groups.forEach(group => {
    const items = d.settings.filter(s => s.group === group);
    if (!items.length) return;
    const box = settingsGroup(group, items, settingRow);
    // Where these settings are kept and who changed them last (CFG-03).
    box.insertBefore(storedLine(items), box.children[GROUP_INTROS[group] ? 2 : 1] || null);
    host.appendChild(box);
  });
  // Recent changes, with Restore (CFG-07, 2026-10-04).
  host.appendChild(recentChangesGroup());
  applyShowWhen(host);
  wireTlsHint(host);
  const mailGroup = host.querySelector('.setgroup[data-group="Email"]');
  if (mailGroup && may('system.manage')) mailGroup.appendChild(mailTestRow(host));
  if (may('system.manage')) Object.keys(SETTINGS_TESTS).forEach(group => {
    const card = host.querySelector(`.setgroup[data-group="${group}"]`);
    const row = card && moduleTestRow(group);
    if (row) card.appendChild(row);
  });
  show($('set-wizard'), may('system.manage') && may('settings.edit'));
  show($('set-export'), may('settings.view') && may('system.view'));
  await loadDeployment();
  await terminalSummary(host);
  buildSettingsNav();
});

/* A group card with its sections; `rowFn` renders one setting. */
function settingsGroup(group, items, rowFn) {
  const box = el('div', 'setgroup');
  box.dataset.group = group;
  box.appendChild(el('h3', null, GROUP_TITLES[group] || group));
  if (GROUP_INTROS[group]) box.appendChild(el('p', 'intro', GROUP_INTROS[group]));
  // Each section's rows together, sections in order of first appearance
  // (settings added later sit at the end of the catalogue).
  const order = [];
  items.forEach(s => { const k = s.section || ''; if (!order.includes(k)) order.push(k); });
  items = order.flatMap(k => items.filter(s => (s.section || '') === k));
  let current = null;
  items.forEach(s => {
    if (s.section && s.section !== current) {
      current = s.section;
      box.appendChild(el('div', 'setsection', s.section));
    }
    box.appendChild(rowFn(s));
  });
  return box;
}

function buildSettingsNav() {
  const nav = $('set-nav');
  nav.textContent = '';
  const find = el('div', 'find');
  const fl = el('label', 'sr-only', 'Find a setting'); fl.htmlFor = 'set-find';
  const fi = el('input'); fi.id = 'set-find'; fi.type = 'search';
  fi.placeholder = 'Find a setting…';
  fi.oninput = () => filterSettings(fi.value);
  find.append(fl, fi);
  nav.appendChild(find);

  const pages = Array.from(document.querySelectorAll(
    '#set-body .setgroup[data-group], #set-deploy .setgroup[data-group]'));
  const known = new Set(pages.map(p => p.dataset.group));
  const placed = new Set();
  const addHeading = t => nav.appendChild(el('h4', null, t));
  const addItem = g => {
    if (!known.has(g) || placed.has(g)) return;
    placed.add(g);
    const b = el('button', null, GROUP_TITLES[g] || g.replace(/^Machine: /, ''));
    b.type = 'button'; b.dataset.page = g;
    b.onclick = () => selectSettingsPage(g);
    b.dataset.label = b.textContent;
    nav.appendChild(b);
  };
  SETTINGS_NAV.forEach(([h, groups]) => {
    if (!groups.some(g => known.has(g))) return;
    addHeading(h); groups.forEach(addItem);
  });
  const rest = pages.filter(p => !placed.has(p.dataset.group) && !p.dataset.machine);
  if (rest.length) { addHeading('Other'); rest.forEach(p => addItem(p.dataset.group)); }
  const machine = pages.filter(p => p.dataset.machine);
  if (machine.length) {
    addHeading('This machine');
    machine.forEach(p => addItem(p.dataset.group));
  }
  // The section in the address (a reload, a bookmark), when it exists.
  if (WANTED_PAGE) {
    const g = Array.from(known).find(x => slug(x) === WANTED_PAGE);
    if (g) SET_PAGE = g;
    WANTED_PAGE = '';
  }
  if (!SET_PAGE || !known.has(SET_PAGE)) SET_PAGE = pages.length ? pages[0].dataset.group : null;
  selectSettingsPage(SET_PAGE, { replace: true });
  markUnsavedSections();
}

/* The Settings sections on the page, in order. */
function settingsGroups() {
  return Array.from(document.querySelectorAll(
    '#set-body .setgroup[data-group], #set-deploy .setgroup[data-group]'))
    .map(g => g.dataset.group);
}

function selectSettingsPage(group, opts = {}) {
  SET_PAGE = group;
  if (CURRENT_VIEW === 'settings' && !opts.fromHistory) setRoute('settings', !!opts.replace);
  const fi = $('set-find'); if (fi) fi.value = '';
  document.querySelectorAll('#set-body .setgroup[data-group], #set-deploy .setgroup[data-group]')
    .forEach(g => {
      show(g, g.dataset.group === group);
      g.querySelectorAll('.setrow').forEach(r => { r.classList.remove('filtered');
                                                   r.style.display = ''; });
      g.querySelectorAll('.setsection').forEach(s => show(s, true));
    });
  document.querySelectorAll('#set-nav button[data-page]').forEach(b => {
    const on = b.dataset.page === group;
    b.classList.toggle('on', on);
    if (on) b.setAttribute('aria-current', 'true'); else b.removeAttribute('aria-current');
  });
  applyShowWhen($('set-body'));
  applyShowWhen($('set-deploy'));
}

/* Search across every section: matching rows only. */
function filterSettings(text) {
  const q = text.trim().toLowerCase();
  if (!q) return selectSettingsPage(SET_PAGE);
  document.querySelectorAll('#set-nav button[data-page]').forEach(b => b.classList.remove('on'));
  document.querySelectorAll('#set-body .setgroup[data-group], #set-deploy .setgroup[data-group]')
    .forEach(g => {
      let any = false;
      g.querySelectorAll('.setrow').forEach(r => {
        const hit = (r.dataset.search || '').includes(q);
        r.classList.toggle('filtered', !hit);
        r.style.display = hit ? '' : 'none';
        any = any || hit;
      });
      g.querySelectorAll('.setsection').forEach(s => show(s, false));
      show(g, any);
    });
}

/* ── deployment settings + credentials (installed app only) ─────── */
let DEPLOY = null;

async function loadDeployment() {
  const host = $('set-deploy');
  host.textContent = '';
  DEPLOY = null;
  if (!may('system.view')) return;
  try { DEPLOY = await api('/system/deployment'); }
  catch (e) { return; }                      // not a desktop install

  DEPLOY.groups.forEach((group, i) => {
    const items = DEPLOY.settings.filter(s => s.group === group);
    if (!items.length) return;
    const box = settingsGroup(group, items, deployRow);
    box.dataset.group = 'Machine: ' + group;
    box.dataset.machine = '1';
    box.querySelector('h3').textContent = GROUP_TITLES['Machine: ' + group] || group;
    if (i === 0) {
      box.insertBefore(el('p', 'intro',
        'These settings decide how the service starts, so every change needs ' +
        'a restart. Each shows where its value comes from, in this order: a ' +
        'Windows environment variable ("Set by environment", changed by the ' +
        'system administrator only), the application settings file (.env in ' +
        'the application folder), the machine settings file (finesiii.env in ' +
        'the data folder), or the default. Save changes the file the value ' +
        'comes from.'), box.children[1] || null);
    }
    if (!DEPLOY.vault.available && i === 0) {
      box.insertBefore(el('div', 'banner',
        'No credential store is available on this machine (' +
        (DEPLOY.vault.error || 'unknown reason') + '). Passwords cannot be ' +
        'kept securely here; ask the system administrator to provide them ' +
        'as environment variables.'), box.children[1] || null);
    }
    host.appendChild(box);
  });

  // Credentials: write-only. The API reports set / not set, never a
  // value; a typed value is stored in the OS vault on Save.
  const cred = el('div', 'setgroup');
  cred.dataset.group = 'Machine: Credentials';
  cred.dataset.machine = '1';
  cred.appendChild(el('h3', null, 'Credentials'));
  if (DEPLOY.vault.available) {
    cred.appendChild(el('p', 'intro',
      'Kept in the operating system\'s credential store and loaded into the ' +
      'service when it starts. Type a value to set or replace it; leave a ' +
      'field blank to keep what is there. Values are never shown.'));
    // One store per Windows account: the account the service runs as
    // (SEC-03, 2026-10-04).
    if (DEPLOY.vault.account)
      cred.appendChild(el('p', 'intro', 'Stored for Windows account: ' +
        DEPLOY.vault.account + ' (the account this service runs as). A ' +
        'service started as another account does not see these values.'));
  } else {
    cred.appendChild(el('p', 'intro',
      'The passwords and keys this service uses. They cannot be set on this ' +
      'page on this machine. Values are never shown.'));
    cred.appendChild(el('div', 'banner',
      'No credential store is available on this machine (' +
      (DEPLOY.vault.error || 'unknown reason') + '). Passwords cannot be ' +
      'kept securely here; ask the system administrator to provide them ' +
      'as environment variables.'));
  }
  // The ServiceNow password and client secret follow the authentication
  // method chosen on the ServiceNow page, the PVWA password the CyberArk
  // API (NB-025), as in the setup assistant.
  const showWhen = Object.assign({}, ...WIZARD_PAGES.map(p => p.secretShowWhen || {}));
  // The ServiceNow password and client secret are shown with the
  // ServiceNow settings, as in the setup assistant (SN-09, 2026-10-03).
  const snowCard = $('set-body').querySelector('.setgroup[data-group="ServiceNow"]');
  let snowSecrets = null;
  if (snowCard) {
    snowSecrets = el('div', 'snow-secrets');
    snowSecrets.dataset.bodyControls = '1';
    snowCard.appendChild(snowSecrets);
  }
  Object.entries(DEPLOY.secrets).forEach(([name, s]) => {
    const row = secretRow(name, s,
      may('system.manage') && DEPLOY.vault.available, showWhen[name]);
    (snowSecrets && name.startsWith('SNOW_') ? snowSecrets : cred).appendChild(row);
  });
  host.appendChild(cred);
  applyShowWhen(host);
  if (snowSecrets) applyShowWhen(snowSecrets);
  show($('set-save'), true);
}

function rowLabel(text, tooltip, technical) {
  const lab = el('div', 'lab');
  lab.appendChild(document.createTextNode(text));
  if (tooltip) lab.appendChild(tipButton(tooltip, text, technical));
  return lab;
}

function deployRow(s) {
  const row = el('div', 'setrow');
  row.dataset.search = `${s.label} ${s.tooltip || s.help || ''} ${s.key}`.toLowerCase();
  const left = el('div');
  const lab = rowLabel(s.label, s.tooltip || s.help, 'Setting: ' + s.key);
  lab.appendChild(el('span', 'badge restart', 'Restart needed'));
  // Where the value comes from (CFG-01, 2026-10-04).
  const SOURCE_BADGES = {
    environment: ['env', 'Set by environment'],
    app_file: ['over', 'Application settings file'],
    machine_file: ['over', 'Machine settings file']
  };
  const src = SOURCE_BADGES[s.source || (s.from_environment ? 'environment'
                                          : s.in_file ? 'machine_file' : '')];
  if (src) lab.appendChild(el('span', 'badge ' + src[0], src[1]));
  if (s.pending_restart) lab.appendChild(el('span', 'badge restart', 'Saved — applies after restart'));
  left.appendChild(lab);
  if (s.locked && s.locked_reason) left.appendChild(el('div', 'hint', s.locked_reason));
  if (s.min != null || s.max != null)
    left.appendChild(el('div', 'hint', `Allowed: ${s.min ?? '−'} to ${s.max ?? '−'}.`));
  row.appendChild(left);

  let field;
  if (s.kind === 'bool' || s.kind === 'choice') {
    field = el('select');
    const opts = s.kind === 'bool' ? [['true', 'On'], ['false', 'Off']]
                                   : s.choices.map(c => [c, humanize(c)]);
    if (s.kind === 'choice') opts.unshift(['', '(default)']);
    let norm = String(s.value ?? '');
    if (s.kind === 'bool')
      norm = ['1', 'true', 'yes', 'on'].includes(norm.trim().toLowerCase())
        ? 'true' : 'false';
    opts.forEach(([v, t]) => {
      const o = el('option', null, t); o.value = v;
      if (norm === v) o.selected = true;
      field.appendChild(o);
    });
    field.dataset.original = norm;
  } else {
    field = el('input');
    if (s.kind === 'int') numberField(field, 'int');
    field.value = s.value ?? '';
    field.dataset.original = String(s.value ?? '');
  }
  field.dataset.dkey = s.key;
  field.setAttribute('aria-label', s.label);
  if (s.locked || s.from_environment || !may('system.manage')) field.disabled = true;
  row.appendChild(field);

  if (s.key === 'DATABASE_URL' || s.key === 'AUDIT_DATABASE_URL') {
    const test = el('button', 'btn sm ghost', 'Test connection');
    test.style.gridColumn = '2';
    test.onclick = () => testDatabase(s.key, field);
    row.appendChild(test);
  }
  return row;
}

/* E-mail tests on Settings > E-mail (2026-09-29): the values on the
 * page, before they are saved. Test connection sends nothing. */
function mailTestRow(root) {
  const row = el('div', 'setrow');
  row.dataset.search = 'test connection send test e-mail email smtp mail server';
  const left = el('div');
  left.appendChild(rowLabel('Test the mail server',
    'Uses the values on this page, before they are saved. Test connection ' +
    'connects, secures the connection and signs in, without sending ' +
    'anything. Send test e-mail sends one e-mail to the addresses typed ' +
    'here; separate several with commas or semicolons.'));
  row.appendChild(left);
  const right = el('div');
  const to = el('input'); to.id = 'set-mail-to'; to.type = 'text';
  to.placeholder = 'Test recipients (empty: the Default recipients)';
  to.setAttribute('aria-label', 'Test recipients');
  const connect = el('button', 'btn sm ghost', 'Test connection');
  const send = el('button', 'btn sm ghost', 'Send test e-mail');
  const read = key => {
    const f = root.querySelector(`[data-key="${key}"]`);
    return f ? String(fieldValue(f)).trim() : '';
  };
  const secret = name => {
    const f = document.querySelector(`[data-skey="${name}"]`);
    return f ? f.value : '';
  };
  const run = async sending => {
    // An empty box sends to the Default recipients (E2E-L16).
    const dest = to.value.trim() || read('ALERT_TO');
    if (sending && !dest) {
      msg('set-msg', 'err', 'Enter at least one test recipient, or save the Default recipients.'); return;
    }
    msg('set-msg', 'infobar', sending ? 'Sending a test e-mail…' : 'Testing the connection…');
    try {
      const r = await api('/system/test-email', { method: 'POST',
        body: mailTestBody(read, secret, sending, dest) });
      msg('set-msg', r.ok ? 'okmsg' : 'err', mailTestText(r));
    } catch (e) { msg('set-msg', 'err', e.message); }
  };
  connect.onclick = busy(connect, () => run(false));
  send.onclick = busy(send, () => run(true));
  right.append(to, connect, send);
  row.appendChild(right);
  return row;
}

function mailTestBody(read, secret, sending, to) {
  const security = read('SMTP_SECURITY');
  // The earlier two switches only while no security is chosen, and only
  // when changed on this page (EM-04, 2026-10-03): a field showing the
  // default in force is left to the server, which then decides like
  // real sending does (STARTTLS when offered on port 25).
  const changed = key => {
    const value = read(key);
    const fields = document.querySelectorAll(
      `#wz-body [data-key="${key}"], #set-body [data-key="${key}"]`);
    for (const f of fields) {
      if (String(fieldValue(f)).trim() === String(value).trim()
          && f.value === f.dataset.original) return undefined;
    }
    return value || undefined;
  };
  return {
    send: sending, to, host: read('SMTP_HOST'), port: read('SMTP_PORT'),
    username: read('SMTP_USERNAME'), password: secret('SMTP_PASSWORD'),
    from: read('ALERT_FROM'), security: security || undefined,
    use_ssl: security ? undefined : changed('SMTP_USE_SSL'),
    use_starttls: security ? undefined : changed('SMTP_USE_STARTTLS'),
    verify_cert: read('SMTP_VERIFY_CERT') || undefined,
    ca_file: read('SMTP_CA_FILE'), ehlo_name: read('SMTP_EHLO_NAME') };
}

function mailTestText(r) {
  if (!r.ok) return `${r.error}${r.hint ? ' — ' + r.hint : ''}`;
  if (r.sent) return `Test e-mail sent to ${r.to} via ${r.host}:${r.port}.`;
  const size = Number(r.max_size || 0);
  return `Connected to ${r.host}:${r.port}: ` +
    (r.encrypted ? `encrypted (${r.tls_version || 'TLS'})` : 'not encrypted') +
    `; STARTTLS ${r.starttls_offered ? 'offered' : 'not offered'}; ` +
    (r.login ? 'signed in' : 'no sign-in (relay)') +
    (r.auth_methods ? `; sign-in methods: ${r.auth_methods}` : '') +
    (size ? `; largest message ${Math.round(size / 1048576)} MB` : '') + '.';
}

async function testDatabase(key, field) {
  msg('set-msg', 'infobar', 'Testing the connection…');
  const pwKey = key.startsWith('AUDIT_') ? 'AUDIT_DATABASE_PASSWORD'
                                         : 'DATABASE_PASSWORD';
  const pwField = document.querySelector(`[data-skey="${pwKey}"]`);
  try {
    const r = await api('/system/test-database', {
      method: 'POST',
      body: { key, url: field.value, password: pwField ? pwField.value : '' }
    });
    // Connected, but not usable yet (e.g. the tables are missing): a
    // warning, not a failed connection.
    msg('set-msg', r.ok ? 'okmsg' : r.connected ? 'banner' : 'err', r.ok
      ? `Connected to ${r.server}${r.user ? ' as ' + r.user : ''}` +
        (r.missing_tables.length ? `. ${r.hint}` : '. The tables are in place.')
      : r.connected
        ? `${r.error || 'Connected, but the database is not ready'}` +
          `${r.hint ? ' — ' + r.hint : ''}`
        : `${r.error || 'The connection failed'}${r.hint ? ' — ' + r.hint : ''}`);
  } catch (e) {
    msg('set-msg', 'err', e.message);
  }
}

function machineRevision() {
  return { 'X-Machine-Revision': String(((DEPLOY || {}).revision || {}).rev ?? '') };
}

async function saveDeployment(root) {
  root = root || $('set-deploy');
  if (!DEPLOY || !may('system.manage')) return { changed: 0 };
  const changes = {}, secrets = {};
  root.querySelectorAll('[data-dkey]').forEach(f => {
    if (f.disabled) return;
    if (f.value !== f.dataset.original) changes[f.dataset.dkey] = f.value;
  });
  // Spaces alone mean "no change", like an empty field (NB-026). The
  // ServiceNow credentials sit in the ServiceNow group (SN-09).
  const secretRoots = root === $('set-deploy')
    ? [root, $('set-body').querySelector('.snow-secrets')].filter(Boolean) : [root];
  secretRoots.forEach(r => r.querySelectorAll('[data-skey]').forEach(f => {
    if (f.value.trim()) secrets[f.dataset.skey] = f.value;
  }));
  let n = 0, restart = false;
  if (Object.keys(changes).length) {
    let r;
    try {
      r = await api('/system/deployment', { method: 'PUT', body: changes,
                    headers: machineRevision() });
    } catch (e) {
      // The database server did not answer (NB-005): saved only when
      // the administrator confirms.
      const d = e.data && e.data.detail;
      if (e.status !== 400 || !d || d.status !== 'database_unreachable') throw e;
      if (!confirm(`${d.message}\n\nSave anyway? The service will not start ` +
                   'until the database can be reached.')) {
        // saveSettings and the wizard add "Not saved: " themselves.
        const err = new Error(d.message);
        err.status = 400;
        throw err;
      }
      r = await api('/system/deployment?force=true', { method: 'PUT', body: changes,
                    headers: machineRevision() });
    }
    n += r.changed.length + r.cleared.length; restart = true;
  }
  for (const [name, value] of Object.entries(secrets)) {
    const r = await api('/system/secrets/' + encodeURIComponent(name),
                        { method: 'PUT', body: { value } });
    // The ServiceNow credentials apply at once; the others at restart.
    n += 1; restart = restart || !r || r.restart_required !== false;
  }
  return { changed: n, restart };
}

function settingRow(s) {
  const row = el('div', 'setrow');
  row.dataset.search = `${s.label} ${s.tooltip || s.help || ''} ${s.key} ${s.section || ''}`
    .toLowerCase();

  const left = el('div');
  const lab = rowLabel(s.label, s.tooltip || s.help, 'Setting: ' + s.key);
  // The value shown is saved but not in force yet: say so.
  if (s.pending_restart)
    lab.appendChild(el('span', 'badge restart pending', 'Applies after restart'));
  else if (s.apply === 'restart')
    lab.appendChild(el('span', 'badge restart', 'Restart needed'));
  if (s.overridden)
    lab.appendChild(el('span', 'badge over', 'Changed here'));
  // A stored value that is not valid is ignored (NB-024).
  if (s.invalid)
    lab.appendChild(el('span', 'badge err', 'Not valid — ignored, enter it again'));
  left.appendChild(lab);
  // Scaled numbers: stored in one unit (seconds), shown in another
  // (minutes). Bounds and the value are converted for display; the
  // save path multiplies back (see scaledOut).
  const scale = Number(s.scale) > 0 ? Number(s.scale) : 1;
  const shown = v => (v === '' || v == null || isNaN(Number(v)))
    ? (v ?? '') : String(Number(v) / scale);
  let hint = '';
  if (s.cap != null) hint = `Upper limit: ${shown(s.cap)}${s.unit ? ' ' + s.unit : ''}.`;
  else if (s.min != null || s.max != null)
    hint = `Allowed: ${s.min != null ? shown(s.min) : '−'} to ${s.max != null ? shown(s.max) : '−'}` +
           (s.unit ? ` ${s.unit}` : '') + '.';
  if (hint) left.appendChild(el('div', 'hint', hint));
  row.appendChild(left);

  let field;
  let effective = null;
  if (s.kind === 'bool') {
    field = el('select');
    // Normalise first: an env value of "1"/"yes"/"" matched neither
    // option, so the select showed "On" while `original` differed, and
    // saving ANY setting silently submitted this one too.
    const norm = ['1', 'true', 'yes', 'on']
      .includes(String(s.value).trim().toLowerCase()) ? 'true' : 'false';
    // "Default" hands the setting back (clears the stored value), as for
    // lists. Not changed here: it is the choice shown, with the value in
    // force; changed here: the stored value is shown.
    const def = s.overridden ? 'Default (as installed)'
                             : `Default (${norm === 'true' ? 'On' : 'Off'})`;
    const selected = s.overridden ? norm : '';
    [['', def], ['true', 'On'], ['false', 'Off']].forEach(([v, t]) => {
      const o = el('option', null, t); o.value = v;
      if (selected === v) o.selected = true;
      field.appendChild(o);
    });
    effective = norm;
    s = Object.assign({}, s, { value: selected });
  } else if (s.kind === 'choice') {
    field = el('select');
    const cur = String(s.value ?? '');
    // Readable names where the catalogue gives them (2026-09-29).
    const names = s.choice_labels || {};
    const opts = [['', '(default)']].concat((s.choices || []).map(c => [c, names[c] || c]));
    opts.forEach(([v, t]) => {
      const disabled = (s.disabled_choices || []).includes(v);
      const o = el('option', null, disabled ? `${t} (not yet available)` : t);
      o.value = v; o.disabled = disabled;
      if (cur === v) o.selected = true;
      field.appendChild(o);
    });
    s = Object.assign({}, s, { value: cur });
  } else {
    field = el('input');
    if (s.kind === 'int' || s.kind === 'float') {
      // The bounds are in the hint; the service checks them on Save.
      numberField(field, s.kind);
      if (scale !== 1) { field.dataset.scale = String(scale); s = Object.assign({}, s, { value: shown(s.value) }); }
    } else if (s.secret) {
      field.type = 'password';
      field.placeholder = s.value ? 'Set — type to replace' : 'Not set';
    }
    // A secret is never sent back to the browser, so the field starts
    // empty and only a typed value is submitted.
    field.value = s.secret ? '' : (s.value ?? '');
  }
  field.dataset.key = s.key;
  field.dataset.kind = s.kind;
  field.dataset.secret = s.secret ? '1' : '';
  field.dataset.original = s.secret ? '' : String(s.value ?? '');
  // What "Default" means for an On/Off setting (used by conditional rows
  // and the setup assistant while "Default" is chosen).
  if (effective !== null) field.dataset.effective = effective;
  field.setAttribute('aria-label', s.label);
  // Read-only without the right to change settings (E2E-L20).
  if (!may('settings.edit')) field.disabled = true;
  if (s.invalid) field.setAttribute('aria-invalid', 'true');
  row.appendChild(field);
  if (s.show_when) {
    row.dataset.showKey = s.show_when.key;
    row.dataset.showValue = JSON.stringify(
      Array.isArray(s.show_when.value) ? s.show_when.value : [s.show_when.value]);
  }
  return row;
}

/* The value to SUBMIT for a settings field: a scaled number is
 * multiplied back into its stored unit (minutes typed → seconds sent). */
function scaledOut(f) {
  const scale = Number(f.dataset.scale) > 0 ? Number(f.dataset.scale) : 1;
  if (scale === 1 || f.value === '' || isNaN(Number(f.value))) return f.value;
  return String(Math.round(Number(f.value) * scale));
}

/* The value a field stands for: an On/Off field left on "Default"
 * stands for the value in force (data-effective). */
function fieldValue(f) {
  return f.value === '' && f.dataset.effective !== undefined
    ? f.dataset.effective : f.value;
}

/* Conditional rows: a row with data-show-key is visible only while the
 * controlling field holds data-show-value. The controlling field is in
 * the same container; for the machine settings (the credentials) it may
 * be on the settings pages above. Wired once per container and field;
 * re-evaluated on every change of a controlling field. */
const SHOW_WIRED = new WeakMap();
function applyShowWhen(container) {
  const rows = Array.from(container.querySelectorAll('[data-show-key]'));
  if (!rows.length) return;
  const norm = v => {
    const t = String(v ?? '').trim().toLowerCase();
    return ['1', 'yes', 'on'].includes(t) ? 'true' : t;
  };
  const accepted = row => {
    // JSON list (new) or a single value (older callers).
    try { const v = JSON.parse(row.dataset.showValue);
          return (Array.isArray(v) ? v : [v]).map(norm); }
    catch (e) { return [norm(row.dataset.showValue)]; }
  };
  const control = key => {
    const sel = `[data-key="${key}"],[data-dkey="${key}"]`;
    const own = container.querySelector(sel);
    if (own || (container.id !== 'set-deploy' && !container.dataset.bodyControls)) return own;
    return $('set-body').querySelector(sel);
  };
  const evaluate = () => rows.forEach(row => {
    const ctl = control(row.dataset.showKey);
    if (!ctl) return;
    show(row, accepted(row).includes(norm(fieldValue(ctl))));
  });
  rows.forEach(row => {
    const ctl = control(row.dataset.showKey);
    if (!ctl) return;
    const wired = SHOW_WIRED.get(ctl) || new Set();
    if (!wired.has(container)) {
      wired.add(container);
      SHOW_WIRED.set(ctl, wired);
      ctl.addEventListener('change', evaluate);
    }
  });
  evaluate();
}

/* STARTTLS and implicit SSL exclude each other (the save refuses both
 * On). Switching implicit SSL On shows how to fix it next to the field;
 * the other switch is never changed for the user. */
function wireTlsHint(container) {
  const ssl = container.querySelector('[data-key="SMTP_USE_SSL"]');
  const tls = container.querySelector('[data-key="SMTP_USE_STARTTLS"]');
  if (!ssl || !tls) return;
  const left = ssl.closest('.setrow').firstElementChild;
  let hint = left.querySelector('.tlshint');
  if (!hint) {
    hint = el('div', 'hint warnhint tlshint hide',
      'Implicit SSL (port 465) replaces STARTTLS — switch \'Use STARTTLS\' ' +
      'Off as well');
    hint.setAttribute('role', 'status');
    hint.id = (container.id || 'set') + '-tls-hint';
    left.appendChild(hint);
  }
  const check = () => {
    const both = fieldValue(ssl) === 'true' && fieldValue(tls) === 'true';
    show(hint, both);
    if (both) ssl.setAttribute('aria-describedby', hint.id);
    else ssl.removeAttribute('aria-describedby');
  };
  ssl.addEventListener('change', check);
  tls.addEventListener('change', check);
  check();
}

/* One vault-secret row (write-only). Shared by Settings and the wizard. */
function secretRow(name, s, manageable, showWhen) {
  const row = el('div', 'setrow');
  row.dataset.search = `${s.label} ${s.tooltip || ''} ${name}`.toLowerCase();
  if (showWhen) {
    row.dataset.showKey = showWhen.key;
    row.dataset.showValue = JSON.stringify(
      Array.isArray(showWhen.value) ? showWhen.value : [showWhen.value]);
  }
  const left = el('div');
  const lab = rowLabel(s.label, s.tooltip || 'Kept in the credential store.',
                       'Credential: ' + name);
  // A value an earlier version kept in the settings table (NB-020).
  const legacy = s.set && s.source === 'settings_table';
  lab.appendChild(el('span', 'badge ' + (legacy ? 'restart' : s.set ? 'over' : ''),
                     legacy ? 'Stored in the application database (legacy)'
                     : s.set ? (s.source === 'environment' ? 'Set by environment' : 'Set')
                           : 'Not set'));
  left.appendChild(lab);
  row.appendChild(left);
  const f = el('input'); f.type = 'password'; f.autocomplete = 'new-password';
  f.placeholder = s.set ? 'Set — type to replace' : 'Not set';
  f.dataset.skey = name;
  f.setAttribute('aria-label', s.label);
  if (!manageable) f.disabled = true;
  row.appendChild(f);
  if (legacy && may('system.manage')) {
    const rm = el('button', 'btn sm ghost', 'Remove from database');
    rm.type = 'button';
    rm.style.justifySelf = 'start';     // wraps under the label on a phone
    rm.onclick = () => removeLegacySecret(name, s.label, rm);
    row.appendChild(rm);
  }
  return row;
}

/* Remove a secret an earlier version kept in the settings table, then
 * show the credentials again (NB-020). */
async function removeLegacySecret(name, labelText, btn) {
  if (!confirm(`Remove "${labelText}" from the application database?\n\n` +
               'Set it in the service environment (or the credential store) ' +
               'first; without it the service cannot use it after the next ' +
               'restart.')) return;
  btn.disabled = true;
  try {
    const r = await api('/system/secrets/' + encodeURIComponent(name),
                        { method: 'DELETE' });
    msg('set-msg', 'banner', r.note || 'Removed from the application database.');
    if ($('set-deploy').contains(btn)) LOADERS.settings();
    else btn.remove();
  } catch (e) {
    btn.disabled = false;
    msg('set-msg', 'err', e.message);
  }
}

/* Numbers are typed into a plain text field (NB-012). A number-type
 * field reads as empty when it holds text the browser cannot parse (and
 * refuses full-width digits typed with an input method), which silently
 * handed the setting back to its default. The text is checked here
 * instead; the service still checks the bounds. */
function numberField(f, kind) {
  f.type = 'text';
  f.inputMode = kind === 'float' ? 'decimal' : 'numeric';
  f.autocomplete = 'off';
  f.spellcheck = false;
  f.dataset.num = kind;
}
const NUMBER_TEXT = {
  int: /^[+-]?\d+$/,
  float: /^[+-]?(\d+(\.\d*)?|\.\d+)$/
};

/* Number fields holding something that is not a number are marked
 * invalid and returned, so nothing is sent. Full-width digits and
 * surrounding spaces are normalised and written back, so " 2525 " is
 * not taken for a change of "2525". Empty still means "clear". */
function invalidNumbers(roots) {
  const bad = [];
  roots.forEach(root => {
    if (!root) return;
    root.querySelectorAll('input[data-num]').forEach(f => {
      if (f.disabled) { f.removeAttribute('aria-invalid'); return; }
      const t = f.value.normalize('NFKC').trim();
      const wrong = t !== '' && !(NUMBER_TEXT[f.dataset.num] || NUMBER_TEXT.float).test(t);
      if (wrong) { f.setAttribute('aria-invalid', 'true'); bad.push(f); return; }
      f.removeAttribute('aria-invalid');
      if (t !== f.value) f.value = t;
    });
  });
  return bad;
}
function numbersMessage(bad) {
  return bad.map(f => `${f.getAttribute('aria-label') || 'This field'}: ` +
                      (f.dataset.num === 'int' ? 'enter a whole number' : 'enter a number'))
    .join('. ') +
    '. Nothing was saved.';
}

async function saveSettings() {
  const box = $('set-msg');
  const bad = invalidNumbers([$('set-body'), $('set-deploy')]);
  if (bad.length) {
    // Show the section of the first one, then point at it.
    const page = bad[0].closest('.setgroup[data-group]');
    if (page && page.classList.contains('hide')) selectSettingsPage(page.dataset.group);
    msg(box, 'err', numbersMessage(bad));
    bad[0].focus();
    return;
  }
  const changes = {};
  $('set-body').querySelectorAll('[data-key]').forEach(f => {
    const value = f.value;
    if (f.dataset.secret) {
      if (value) changes[f.dataset.key] = value;   // only if retyped
    } else if (value !== f.dataset.original) {
      changes[f.dataset.key] = scaledOut(f);
    }
  });
  $('set-save').disabled = true;
  let n = 0;
  try {
    let restart = false;
    if (Object.keys(changes).length) {
      // The revision the page was loaded at: a setting someone else
      // changed since is not overwritten (CFG-06, 2026-10-04).
      const r = await api('/console/settings', { method: 'PUT', body: changes,
        headers: { 'X-Settings-Revision': String((SETTINGS_META.revision || {}).rev ?? '') } });
      n += Object.keys(r.changed).length + r.cleared.length;
      restart = restart || r.restart_required;
    }
    const dep = await saveDeployment();
    n += dep.changed; restart = restart || dep.restart;
    if (!n) { msg(box, 'okmsg', 'Nothing was changed.', 3000); return { saved: 0 }; }
    msg(box, restart ? 'banner' : 'okmsg', `${n} setting(s) saved. ` +
      (restart ? 'Restart the service to apply them.' : 'They apply now.'));
    SETUP = undefined;
    LOADERS.settings();
    refreshPendingRestart(true);
    return { saved: n, restart };
  } catch (e) {
    // Refused (e.g. STARTTLS and implicit SSL both On): the reason, shown
    // where it is seen. A refused settings request stores nothing.
    msg(box, 'err', (n ? `${n} setting(s) saved, then this failed: `
                       : 'Not saved: ') + e.message);
    if (box.scrollIntoView) box.scrollIntoView({ block: 'nearest' });
  } finally {
    $('set-save').disabled = false;
  }
}

/* Restart, then carry on on the same page (OPS-02, 2026-10-04): wait
 * for the service to answer again, reload the page's data (not the
 * page — the sign-in is kept, F2), and say so where the restart was
 * started from. */
async function restartService(opts = {}) {
  // The wording follows whether saved settings wait for it (E2E-L28).
  const pending = PENDING > 0;
  if (!opts.confirmed && !confirm((pending ? 'Restart the service to apply the saved settings?'
                                           : 'Restart the service?') + '\n\n' +
               'A transaction in progress finishes first.')) return;
  const box = !$('wizard').classList.contains('hide') ? 'wz-msg'
    : CURRENT_VIEW === 'system' ? 'sys-msg'
    : CURRENT_VIEW === 'dashboard' ? 'dash-restart' : 'set-msg';
  if (box === 'dash-restart') show($(box), true);
  msg(box, 'banner', 'Restarting — a transaction in progress finishes first. ' +
      'This page carries on when the service is back…');
  let before = null;
  if (may('system.view')) {
    try { before = (await api('/system/status')).started_at || null; } catch (e) { }
  }
  try {
    await api('/console/restart', { method: 'POST' });
  } catch (e) {
    return msg(box, 'err', e.message);
  }
  if (!await waitForRestart(before)) {
    return msg(box, 'err', 'The service has not answered for 3 minutes. Check ' +
               'the System page, or the service log on the server.');
  }
  await refreshPendingRestart(true);
  if (CURRENT_VIEW && LOADERS[CURRENT_VIEW]) LOADERS[CURRENT_VIEW]();
  if (box === 'dash-restart') show($(box), true);
  msg(box, 'okmsg', pending ? 'Restarted — the saved settings are now in force.'
                            : 'Restarted.', 8000);
}

/* Where the start-up settings come from (OPS-05, 2026-10-04): the card
 * used to say "Defaults" whenever finesiii.env was absent, even with a
 * .env that set nearly every start-up setting. */
function machineSettingsCard(d) {
  const f = d.settings_files || {};
  const parts = [];
  if (f.environment_keys) parts.push(`${f.environment_keys} from the environment`);
  if (f.app_file_keys) parts.push(`${f.app_file_keys} from the application settings file` +
                                  (f.app_file_writable === false ? ' (read-only)' : ''));
  if (f.machine_file_keys) parts.push(`${f.machine_file_keys} from the machine settings file`);
  const custom = parts.length > 0 || d.deployment_file_exists;
  return card('Machine settings', custom ? 'Customised' : 'Defaults',
              custom ? 'ok' : 'dim',
              parts.length ? parts.join(' · ') : 'All start-up settings at their defaults');
}

/* Saved settings waiting for a restart (CFG-09, 2026-10-04): counted
 * from the console settings and the machine settings, at most once a
 * minute, and shown on the Dashboard and the System page. */
let PENDING_AT = 0;
let PENDING = 0;
async function refreshPendingRestart(force) {
  if (force || Date.now() - PENDING_AT >= 60000) {
    PENDING_AT = Date.now();
    let n = 0;
    if (may('settings.view')) {
      try { n += ((await api('/console/settings')).settings || [])
                   .filter(x => x.pending_restart).length; } catch (e) { }
    }
    if (may('system.view')) {
      try { n += (await api('/system/status')).machine_settings_pending || 0; }
      catch (e) { }
    }
    PENDING = n;
  }
  ['dash-restart', 'sys-restart'].forEach(id => {
    const box = $(id);
    if (!box) return;
    box.textContent = '';
    show(box, PENDING > 0);
    if (!PENDING) return;
    box.appendChild(el('span', null, `${PENDING} saved setting(s) are waiting for a ` +
                                     'restart of the service.'));
    if (may('settings.edit')) {
      const b = el('button', 'btn sm', 'Restart now');
      b.onclick = () => restartService();
      box.appendChild(b);
    }
  });
}

const sleep = ms => new Promise(r => setTimeout(r, ms));

/* The service is back after a restart: its start time changed (or, for
 * a user who cannot read the System page, it stopped answering and
 * answers again). False after 3 minutes. */
async function waitForRestart(before) {
  const started = Date.now(), until = started + 180000;
  let wentDown = false;
  await sleep(1500);
  while (Date.now() < until) {
    try {
      if (before) {
        const st = await api('/system/status');
        if (st.started_at && st.started_at !== before) return true;
      } else {
        const r = await fetch(API + '/ping', { cache: 'no-store' });
        if (r.ok && (wentDown || Date.now() - started > 20000)) return true;
        if (!r.ok) wentDown = true;
      }
    } catch (e) { wentDown = true; }
    await sleep(2000);
  }
  return false;
}

/* The terminal set-up in one place (CFG-04, 2026-10-04), read-only, on
 * Settings > FINESIII terminal: it is spread over This machine, this
 * page, Credentials and CyberArk. */
async function terminalSummary(host) {
  const box = host.querySelector('.setgroup[data-group="FINESIII terminal"]');
  if (!box || !may('system.view')) return;
  let m;
  try { m = ((await api('/system/setup')).modules || {}).finesiii; } catch (e) { return; }
  if (!m) return;
  const yes = v => v === true ? 'Yes' : v === false ? 'No' : 'Cannot be told on this machine';
  const rows = [
    ['Terminal driver', label('driver', m.driver)],
    ['Mainframe environment', label('environment', m.mainframe_environment)],
    ['Screen reading (OCR)', m.ocr_enabled ? 'On' : 'Off'],
    ['Service account password from', m.credential_source === 'cyberark' ? 'CyberArk'
      : m.credential_source === 'vault' ? 'Credentials (this machine)' : 'Not set'],
    ['Terminal started as administrator', m.run_as_admin ? 'Yes' : 'No'],
    ['This service runs as administrator', yes(m.service_elevated)],
  ];
  const sum = el('div', 'termsummary');
  sum.appendChild(el('div', 'setsection', 'Terminal summary (as the service runs now)'));
  const dl = el('dl', 'kv');
  rows.forEach(([k, v]) => dl.append(el('dt', null, k), el('dd', null, v)));
  sum.appendChild(dl);
  if (m.run_as_admin && m.service_elevated === false)
    sum.appendChild(el('div', 'banner', 'The terminal is started as administrator, but ' +
      'this service does not run as administrator: Windows will not let the bot type ' +
      'into it. Start the service with highest privileges, or switch "Start the ' +
      'terminal as administrator" off if the terminal does not need it.'));
  box.insertBefore(sum, box.children[2] || null);
}

/* ── system (the installed background service) ─────────────────── */
let STOP_WATCH = null;          // after "Stop the bot": polls until gone
/* One clear-timer per message box (NB-018): a newer message is never
 * wiped by the timer of an older one. Without `ms` the message stays
 * until the next one — errors are shown that way. */
function msg(id, cls, text, ms) {
  const box = typeof id === 'string' ? $(id) : id;
  clearTimeout(box._msgTimer);
  box._msgTimer = null;
  box.className = cls; box.textContent = text;
  if (ms) box._msgTimer = setTimeout(() => {
    box.textContent = ''; box.className = ''; box._msgTimer = null;
  }, ms);
}

LOADERS.system = guard(async (opts) => {
  // auto: the 30-second refresh (E2E-M09), which leaves the log alone.
  const auto = !!(opts && opts.auto);
  let d;
  try { d = await api('/system/status'); }
  catch (e) {
    if (e.status === 401 || e.status === 428) throw e;
    if (e.offline) return;          // the 'not connected' notice is up
    $('sys-cards').textContent = '';
    $('sys-controls').textContent = '';
    show($('sys-problems'), false);
    $('sys-cards').appendChild(el('p', 'sub',
      e.status === 404 ? 'This page is available on machines where the ' +
      'service is installed as the desktop application.'
      : e.message));
    return;
  }
  const up = d.uptime_seconds, h = Math.floor(up / 3600),
        m = Math.floor((up % 3600) / 60);
  setEnvironment(d.environment, d.mainframe_environment);
  $('sys-sub').textContent =
    `${d.mode === 'agent' ? 'Background service' : humanize(d.mode) + ' mode'} · ` +
    `version ${d.version}`;

  renderSecurity($('sys-security'), d.security);
  renderProblems($('sys-problems'), d.startup_problems, d.startup_warnings);
  const disp = d.dispatcher || {};
  const cards = $('sys-cards');
  cards.textContent = '';
  cards.append(
    card('Service', (d.startup_problems || []).length ? 'Running with problems' : 'Running',
         (d.startup_problems || []).length ? 'warn' : 'ok',
         (d.mode === 'agent' ? 'In the background · ' : '') +
         `up ${h} h ${m} min since ${fmtTime(d.started_at)}` +
         // Fixed, whatever API_HOST says (CFG-10, 2026-10-04).
         (d.listens_on ? ` · listens on ${d.listens_on}` : '') +
         // The configured port was taken at start (OPS-04).
         (d.port && d.configured_port && d.port !== d.configured_port
           ? ` · Running on port ${d.port} instead of the configured ` +
             `${d.configured_port}: external callers using ${d.configured_port} ` +
             'do not reach it' : '')),
    processingCard(disp),
    card('Terminal', label('driver', d.driver), '',
         'Mainframe: ' + label('environment', d.mainframe_environment || d.environment)),
    card('Database', label('engine', d.database_engine), '', ''),
    card('Screen reading', d.ocr_enabled ? 'On' : 'Off',
         d.ocr_enabled ? 'ok' : 'dim', ''),
    // Windows keeps one store per account: the service's (SEC-03).
    card('Credential store', d.vault.available ? 'Available' : 'Unavailable',
         d.vault.available ? 'ok' : 'warn',
         d.vault.available
           ? (d.vault.account ? 'Stored for Windows account: ' + d.vault.account : '')
           : (d.vault.error || '')),
    machineSettingsCard(d),
  );
  // The operating window, CyberArk and e-mail (SY-04, 2026-10-03).
  const av = d.availability;
  if (av) {
    const ws = windowState(av);
    cards.appendChild(card('Mainframe window', ws.value, ws.cls, ws.sub));
  }
  const ca = d.cyberark;
  if (ca) cards.appendChild(card('CyberArk',
    ca.using_fallback ? 'Fallback password' : ca.available ? 'Connected' : 'Unavailable',
    ca.using_fallback || !ca.available ? 'warn' : 'ok',
    (ca.last_refresh_at ? `Password fetched ${fmtTime(ca.last_refresh_at)} (JST)` : 'Not fetched yet') +
    (ca.last_error ? ` · ${ca.last_error}` : '')));
  const em = d.email || {};
  cards.appendChild(card('E-mail', !em.enabled ? 'Off' : em.problem ? 'Not delivering' : 'On',
    !em.enabled ? 'dim' : em.problem ? 'bad' : em.waiting ? 'warn' : 'ok',
    em.problem || (em.waiting ? `${em.waiting} e-mail(s) waiting to be resent (outbox below)` : '')));
  const sn = d.servicenow;
  if (sn) {
    const stats = sn.last_stats || {};
    const tu = sn.ticket_updates || {};
    // Updates the bot gave up on, and those ServiceNow refused (the
    // ticket was no longer the bot's): both need the ticket updated by
    // hand (UAT-L18, 2026-10-04).
    const byHand = (tu.given_up || 0) + (tu.refused || 0);
    // While ServiceNow is failing or not configured, the counts of the
    // last good check would read as current (UAT-L17): not shown.
    const troubled = sn.consecutive_errors || sn.not_configured;
    const detail = sn.last_poll_at
      ? `Last check ${fmtTime(sn.last_poll_at)}` +
        (sn.enabled && sn.next_poll_in_seconds != null
          ? ` · next in ${Math.ceil(sn.next_poll_in_seconds / 60)} min` : '') +
        (stats.fetched != null && !troubled
          ? ` · ${stats.fetched} open, ${stats.submitted || 0} queued` +
            // Skipped as not the bot's (S-03, 2026-10-04).
            (stats.out_of_selection ? `, ${stats.out_of_selection} not in the selection` : '') +
            (stats.duplicate_content ? `, ${stats.duplicate_content} duplicate` : '') : '') +
        (sn.last_error ? ` · ${sn.last_error}` : '') +
        // Since when ServiceNow has not answered, and ticket updates not
        // written yet (SN-02 / SN-03, 2026-10-03).
        (sn.consecutive_errors
          ? ` · last successful check ${sn.last_success_at ? fmtTime(sn.last_success_at) : 'none yet'}` : '') +
        ((sn.ticket_updates || {}).pending
          ? ` · ${sn.ticket_updates.pending} ticket update(s) waiting to be written` : '') +
        (byHand
          ? ` · ${byHand} ticket update(s) not written: update those tickets by hand` : '')
      : (sn.enabled ? 'Not checked yet' : 'Ticket collection is off');
    // A setting missing on this machine is "Not configured", not a
    // ServiceNow outage (UAT-10, 2026-10-04).
    cards.append(card('ServiceNow',
      !sn.enabled ? 'Off' : !sn.running ? 'Not running'
        : sn.auth_held ? 'Paused — sign-in rejected'
        : sn.not_configured ? 'Not configured'
        : sn.consecutive_errors ? `Failing (${sn.consecutive_errors})` : 'On',
      !sn.enabled ? 'dim' : !sn.running ? 'bad' : sn.auth_held ? 'bad'
        : sn.not_configured ? 'warn'
        : sn.consecutive_errors ? 'bad' : 'ok',
      detail));
  }

  loadOutbox();
  if (!auto) loadConfigFiles();
  refreshPendingRestart(true);

  const ctl = $('sys-controls');
  ctl.textContent = '';
  if (may('system.manage')) {
    const pr = el('button', 'btn sm ghost', disp.paused ? 'Resume processing'
                                                       : 'Pause processing');
    pr.onclick = guard(async () => {
      await api('/system/dispatcher/' + (disp.paused ? 'resume' : 'pause'),
                { method: 'POST' });
      msg('sys-msg', 'okmsg', disp.paused ? 'Processing resumed.'
        : 'Paused. No new work starts; a transaction in progress ' +
          'finishes.', 5000);
      LOADERS.system();
    });
    ctl.appendChild(pr);

    if (d.cyberark) {
      // Fetch the mainframe password now (SY-04, 2026-10-03).
      const cr = el('button', 'btn sm ghost', 'Refresh CyberArk now');
      cr.onclick = busy(cr, guard(async () => {
        const c0 = d.cyberark || {};
        const before = (c0.refresh_count || 0) + (c0.failure_count || 0);
        const r = await api('/system/cyberark/refresh-now', { method: 'POST' });
        msg('sys-msg', 'okmsg', r && r.already
          ? 'The password is already being fetched…' : 'Fetching the password…', 5000);
        // The outcome, once the fetch has ended (E2E-L18): up to about
        // 40 s (three attempts with their time-out).
        for (let i = 0; i < 10; i++) {
          await sleep(4000);
          let ca;
          try { ca = (await api('/system/status')).cyberark || {}; } catch (e) { break; }
          if ((ca.refresh_count || 0) + (ca.failure_count || 0) !== before) {
            msg('sys-msg', ca.last_error ? 'err' : 'okmsg', ca.last_error
              ? 'CyberArk did not deliver the password: ' + ca.last_error
              : `Password fetched from CyberArk at ${fmtTime(ca.last_refresh_at)} (JST).`, 10000);
            break;
          }
        }
        LOADERS.system({ auto: true });
      }));
      ctl.appendChild(cr);
    }
    if (sn && sn.enabled) {
      const pn = el('button', 'btn sm ghost', 'Check ServiceNow now');
      pn.onclick = guard(async () => {
        pn.disabled = true;
        try {
          await api('/system/servicenow/poll-now', { method: 'POST' });
          // When ServiceNow does not answer, a check takes up to about
          // 30 seconds (UAT-L17): the card is read again after that too.
          msg('sys-msg', 'okmsg', 'Checking now — the card updates in a few ' +
              'seconds, or after about 30 seconds when ServiceNow does not answer.', 8000);
          setTimeout(() => LOADERS.system(), 4000);
          setTimeout(() => { if (CURRENT_VIEW === 'system') LOADERS.system(); }, 35000);
        } finally { pn.disabled = false; }
      });
      ctl.appendChild(pn);
    }

    const st = el('button', 'btn sm ghost', 'Run self-test');
    st.onclick = guard(async () => {
      st.disabled = true;
      msg('sys-msg', 'infobar', 'Running the self-test…');
      try {
        const r = await api('/system/selftest', { method: 'POST' });
        renderSelftest(r);
        msg('sys-msg', r.ok ? 'okmsg' : 'err',
            r.ok ? 'Every component is usable.' : 'Some components are not usable — see below.', 6000);
      } finally { st.disabled = false; }
    });
    ctl.appendChild(st);

    const dg = el('button', 'btn sm ghost', 'Download diagnostics');
    dg.onclick = guard(async () => {
      try { await download('/system/diagnostics', 'finesiii-diagnostics.zip'); }
      catch (e) { msg('sys-msg', 'err', 'The diagnostics could not be prepared.', 5000); }
    });
    ctl.appendChild(dg);
  }
  if (may('settings.edit') && d.can_restart) {
    const rs = el('button', 'btn sm ghost', 'Restart service');
    rs.onclick = restartService;
    ctl.appendChild(rs);
  }
  if (may('system.manage') && d.can_stop) {
    const sp = el('button', 'btn sm danger', 'Stop the bot');
    sp.onclick = guard(async () => {
      if (!confirm('Stop the background service?\n\nA transaction in ' +
                   'progress finishes first. No requests are processed ' +
                   'until it is started again on this machine.')) return;
      await api('/system/stop', { method: 'POST' });
      msg('sys-msg', 'banner', 'Stopping — this window loses its ' +
          'connection once the service has finished its work.');
      // Keep asking, so the 'not connected' notice appears once it stops.
      clearInterval(STOP_WATCH);
      STOP_WATCH = setInterval(async () => {
        if (!SIGNED_IN) return clearInterval(STOP_WATCH);
        try { await api('/system/status'); }
        catch (e) { if (e.offline || e.status === 401) clearInterval(STOP_WATCH); }
      }, 3000);
    });
    ctl.appendChild(sp);
  }
  if (!auto) loadLog();
});

function renderSelftest(r) {
  const host = $('sys-selftest');
  host.textContent = '';
  const box = el('div', 'setgroup');
  box.style.marginTop = '14px';
  box.appendChild(el('h3', null, `Self-test · ${r.build} · ${fmtTime(r.at)}`));
  const ul = el('ul', 'checks');
  r.checks.forEach(c => {
    const li = el('li');
    li.appendChild(el('span', 'mark ' + c.status,
                      c.status === 'ok' ? 'OK' : c.status === 'failed'
                        ? 'Failed' : 'n/a'));
    const t = el('div');
    t.appendChild(el('div', null, c.name));
    if (c.detail) t.appendChild(el('div', 'dimmer mono', c.detail));
    li.appendChild(t);
    ul.appendChild(li);
  });
  box.appendChild(ul);
  host.appendChild(box);
}

async function loadLog() {
  try {
    // A level and a search (SY-02, 2026-10-03).
    const d = await api('/system/logs' + qs({ file: $('log-file').value,
      lines: $('log-lines').value, level: $('log-level').value || undefined,
      q: $('log-q').value.trim() || undefined }));
    const filtered = $('log-level').value || $('log-q').value.trim();
    $('sys-log').textContent = d.exists
      ? (d.lines.join('\n') || (filtered ? '(No line matches.)' : '(The log is empty.)'))
      : '(No log has been written yet.)';
    $('sys-log').scrollTop = $('sys-log').scrollHeight;
  } catch (e) {
    $('sys-log').textContent = e.message;
  }
}

/* ── branding page ────────────────────────────────────────────── */
const BR_IMAGES = { logo: 'br-logo', favicon: 'br-icon',
                    login_background: 'br-lbg',
                    email_banner: 'br-email-banner', email_logo: 'br-email-logo' };
const BR_LIMITS = { logo: 200, favicon: 64, login_background: 500,
                    email_banner: 300, email_logo: 100 };
let BR_DRAFT = {};

let EMAIL_DEFAULTS = {};       // notifications.yaml values behind Branding (UR-16)
LOADERS.branding = guard(async () => {
  const resp = await api('/console/branding');
  const b = resp.branding;
  EMAIL_DEFAULTS = resp.email_defaults || {};
  BR_DRAFT = Object.assign({}, b);
  $('br-name').value = b.product_name; $('br-tagline').value = b.tagline;
  $('br-foot').value = b.footer_text; $('br-support').value = b.support_contact;
  $('br-notice').value = b.signin_notice || '';
  $('br-accent').value = b.accent_color; $('br-bg').value = b.background_color;
  $('br-secondary').value = b.secondary_color; $('br-nav').value = b.nav_color;
  $('br-link').value = b.link_color || '#1352de';
  $('br-panel').value = b.panel_color; $('br-text').value = b.text_color;
  $('br-font').value = b.font || 'standard';
  $('br-email-html').checked = !!b.email_html_enabled;
  $('br-email-header').value = b.email_header_color;
  $('br-email-accent').value = b.email_accent_color;
  $('br-email-company').value = b.email_company_name || '';
  $('br-email-foot').value = b.email_footer_text || '';
  Object.entries(BR_IMAGES).forEach(([key, id]) => {
    $(id).value = '';
    brPreview(key);
  });
  renderMailPreview();
});

/* The preview shows the uploaded image, or the AIG default it falls back
 * to (on the header colour, since the defaults are the white versions). */
const BR_DEFAULT_PREVIEW = { logo: AIG_DEFAULTS.full, favicon: AIG_DEFAULTS.favicon,
                             email_logo: AIG_DEFAULTS.mark };
function brPreview(key) {
  const prev = $(BR_IMAGES[key] + '-prev');
  const src = BR_DRAFT[key] || BR_DEFAULT_PREVIEW[key] || '';
  prev.src = src; show(prev, !!src);
  // The logos are the white versions: shown on the header colour.
  prev.style.background = (key === 'logo' || key === 'email_logo')
    ? ($('br-nav').value || '#001871') : '#fff';
  prev.title = BR_DRAFT[key] ? 'Uploaded image' : (BR_DEFAULT_PREVIEW[key] ? 'AIG default' : '');
}

/* The top and bottom of every e-mail, built from the same values as the
 * e-mails the service sends (header: logo left, product name right;
 * footer: footer text, contact, the automatic-message line and
 * "© year company"). */
function renderMailPreview() {
  const host = $('br-email-preview');
  host.textContent = '';
  // Blank fields fall back like the real e-mails do (UR-16, 2026-10-03).
  const company = $('br-email-company').value.trim() || EMAIL_DEFAULTS.company_name || '';
  const product = $('br-name').value.trim() || 'FINES III RPA';
  const name = company || product;
  if (BR_DRAFT.email_banner) {
    const img = el('img'); img.src = BR_DRAFT.email_banner; img.alt = 'E-mail banner';
    img.style.cssText = 'display:block;width:100%;height:auto';
    host.appendChild(img);
  } else {
    const head = el('div', 'mp-head');
    head.style.background = $('br-email-header').value;
    head.style.color = textOn($('br-email-header').value);
    const img = el('img'); img.src = BR_DRAFT.email_logo || AIG_DEFAULTS.mark;
    img.alt = name;
    img.style.cssText = 'height:32px;display:block';
    head.appendChild(img);
    head.appendChild(el('span', null, product));
    host.appendChild(head);
  }
  const bar = el('div', 'mp-bar'); bar.style.background = $('br-email-accent').value;
  host.appendChild(bar);
  host.appendChild(el('div', 'mp-body', 'Preview of the top and bottom of every e-mail.'));
  const support = $('br-support').value.trim() || EMAIL_DEFAULTS.support_contact || '';
  const foot = [$('br-email-foot').value.trim() || EMAIL_DEFAULTS.footer_text || '',
                support ? `Contact: ${support}` : '',
                'This message was sent automatically. Please do not reply to it.',
                company ? `© ${new Date().getFullYear()} ${company}` : '']
    .filter(Boolean).join('\n');
  host.appendChild(el('div', 'mp-foot', foot));
}

function readImage(input, key, limitKb) {
  const f = input.files && input.files[0];
  if (!f) return;
  if (f.type === 'image/svg+xml' || /\.svg$/i.test(f.name || '')) {
    msg('br-msg', 'err', 'SVG images are not accepted — choose a PNG, JPEG, ' +
        'GIF or WebP image.', 8000);
    input.value = ''; return;
  }
  if (f.size > limitKb * 1024) {
    // Rounded UP to one decimal, with the bytes: a file just over the
    // limit never reads as the limit itself.
    const kb = (Math.ceil(f.size * 10 / 1024) / 10).toFixed(1);
    const n = v => v.toLocaleString('en-US');
    msg('br-msg', 'err', `That file is ${kb} KB (${n(f.size)} bytes); the ` +
        `limit is ${limitKb} KB (${n(limitKb * 1024)} bytes).`, 8000);
    input.value = ''; return;
  }
  const reader = new FileReader();
  reader.onload = () => {
    let url = String(reader.result || '');
    // Some systems give an .ico file no type or a generic one: name it
    // an icon, so the service reads it as one (NB-029). The service
    // checks the content either way.
    if (/\.ico$/i.test(f.name || '') &&
        /^data:(application\/octet-stream|image\/vnd\.microsoft\.icon)?;base64,/i.test(url))
      url = url.replace(/^data:[^;]*;/, 'data:image/x-icon;');
    BR_DRAFT[key] = url;
    brPreview(key);
    renderMailPreview();
  };
  reader.readAsDataURL(f);
}

async function saveBranding() {
  const body = {
    product_name: $('br-name').value.trim(),
    tagline: $('br-tagline').value.trim(),
    footer_text: $('br-foot').value.trim(),
    support_contact: $('br-support').value.trim(),
    signin_notice: $('br-notice').value.trim(),
    accent_color: $('br-accent').value, background_color: $('br-bg').value,
    secondary_color: $('br-secondary').value, nav_color: $('br-nav').value,
    link_color: $('br-link').value,
    panel_color: $('br-panel').value, text_color: $('br-text').value,
    font: $('br-font').value,
    logo: BR_DRAFT.logo || '', favicon: BR_DRAFT.favicon || '',
    login_background: BR_DRAFT.login_background || '',
    email_html_enabled: $('br-email-html').checked,
    email_banner: BR_DRAFT.email_banner || '', email_logo: BR_DRAFT.email_logo || '',
    email_header_color: $('br-email-header').value,
    email_accent_color: $('br-email-accent').value,
    email_company_name: $('br-email-company').value.trim(),
    email_footer_text: $('br-email-foot').value.trim()
  };
  $('br-save').disabled = true;
  try {
    const r = await api('/console/branding', { method: 'PUT', body });
    applyBranding(r.branding);
    msg('br-msg', 'okmsg', 'Saved. The console and the e-mails use it from now on.', 5000);
  } catch (e) {
    msg('br-msg', 'err', e.message, 8000);
  } finally { $('br-save').disabled = false; }
}

async function resetBranding() {
  if (!confirm('Return every branding setting to its default?')) return;
  try {
    const r = await api('/console/branding', { method: 'DELETE' });
    applyBranding(r.branding);
    LOADERS.branding();
    msg('br-msg', 'okmsg', 'The defaults are back in place.', 4000);
  } catch (e) { msg('br-msg', 'err', e.message, 6000); }
}

/* ── reports ──────────────────────────────────────────────────── */
function reportPeriod() {
  const p = $('rp-period').value;
  if (p !== 'custom') return { period: p };
  return { period: 'custom', date_from: $('rp-from').value, date_to: $('rp-to').value };
}

LOADERS.reports = guard(async () => {
  const p = reportPeriod();
  if (p.period === 'custom' && (!p.date_from || !p.date_to)) {
    return msg('rp-msg', 'banner', 'Choose the first and last day of the period.', 5000);
  }
  // Reversed dates are refused here, not answered empty (UAT-L03).
  if (p.period === 'custom' && p.date_to < p.date_from) {
    return msg('rp-msg', 'banner', 'The last day is before the first day. Choose the period again.', 5000);
  }
  $('rp-msg').textContent = ''; $('rp-msg').className = '';
  show($('rp-processing'), may('dashboard.view'));
  show($('rp-audit'), may('audit.view'));
  show($('rp-export'), may('audit.view'));
  let generated = '';
  if (may('dashboard.view')) {
    try {
      const m = await api('/console/metrics' + qs(p));
      $('rp-period-label').textContent = periodText(m.period);
      generated = m.generated_at || generated;
      renderProcessing(m, $('rp-kpis'), $('rp-charts'), true);
    } catch (e) {
      if (e.status === 401) return signOut();
      msg('rp-msg', 'err', e.message);
    }
  }
  if (may('audit.view')) {
    try {
      const a = await api('/console/reports' + qs(p));
      if (!may('dashboard.view')) $('rp-period-label').textContent = periodText(a.period);
      generated = generated || a.generated_at || '';
      renderAuditReport(a);
    } catch (e) {
      if (e.status === 401) return signOut();
      $('rp-audit-kpis').textContent = '';
      $('rp-audit-charts').textContent = '';
      $('rp-audit-kpis').appendChild(el('p', 'sub', e.status === 503
        ? auditErrorText(e) : e.message));
    }
  }
  // On the printout: when the figures were read and by whom (DR-11).
  $('rp-printed').textContent = generated
    ? `Generated ${fmtTime(generated)} (JST) by ${(ME && ME.username) || ''} — ` +
      `${$('rp-period-label').textContent}` : '';
});

function renderAuditReport(a) {
  const k = a.kpis || {};
  const host = $('rp-audit-kpis');
  host.textContent = '';
  // Whether the trail is protected, and events not written yet
  // (DR-05 / DR-07, 2026-10-03).
  const pr = a.protection || {};
  const state = el('p', pr.protected ? 'okmsg' : pr.protected === false ? 'banner' : 'dimmer',
    (pr.protected ? 'Audit trail protected: ' : pr.protected === false
      ? 'Audit trail NOT protected: ' : 'Audit trail protection: ') + (pr.detail || 'not checked') +
    (a.pending_delivery ? ` ${fmtNum(a.pending_delivery)} event(s) are waiting to be written ` +
                          'to the audit database.' : ''));
  state.style.gridColumn = '1 / -1';
  host.appendChild(state);
  host.append(
    kpi('Audit events', fmtNum(k.events), 'Everything recorded in the audit trail in the period.'),
    kpi('Warnings', fmtNum(k.warnings), 'Events recorded as warnings.', '', k.warnings ? 'warnk' : ''),
    kpi('Errors', fmtNum(k.errors), 'Events recorded as errors or critical.', '', k.errors ? 'badk' : 'good'),
    kpi('Sign-ins', fmtNum(k.sign_ins), 'Successful console sign-ins.'),
    kpi('Failed sign-ins', fmtNum(k.failed_sign_ins),
        'Rejected or blocked sign-in attempts. A sudden rise can mean someone is guessing passwords.',
        '', k.failed_sign_ins ? 'warnk' : ''),
    kpi('E-mails sent', fmtNum(k.emails_sent),
        'E-mails delivered to the mail server.', k.emails_failed ? `${fmtNum(k.emails_failed)} failed` : ''),
    kpi('Evidence opened', fmtNum(k.evidence_views),
        'Screenshots opened in the console. Screenshots can contain personal data.'),
    kpi('Configuration changes', fmtNum(k.configuration_changes),
        'Changes to settings, machine settings, credentials, branding and error rules.'),
    kpi('Account changes', fmtNum(k.account_changes), 'Console users and roles created, changed or removed.'),
    kpi('Data exports', fmtNum(k.exports), 'CSV exports downloaded from the console.'),
  );
  const charts = $('rp-audit-charts');
  charts.textContent = '';
  const days = (a.daily || []).map(x => x.day);
  const c1 = Charts.card(charts, 'Audit events per day', 'By severity (JST).', { wide: true });
  Charts.columns(c1, {
    labels: days, fmtX: shortDay, desc: 'Audit events per day by severity',
    series: [{ name: 'Information', color: PALETTE.info, values: a.daily.map(x => x.info) },
             { name: 'Warning', color: PALETTE.warning, values: a.daily.map(x => x.warning) },
             { name: 'Error', color: PALETTE.error, values: a.daily.map(x => x.error) }]
  });
  const c2 = Charts.card(charts, 'By category', 'Where the recorded events came from.');
  Charts.bars(c2, {
    desc: 'Audit events by category',
    series: [{ name: 'Events', color: PALETTE.navy }],
    items: (a.by_category || []).slice(0, 12).map(c => ({ label: label('category', c.label), values: [c.count] }))
  });
  const c3 = Charts.card(charts, 'By severity', 'Share of each severity.');
  const sevColor = { INFO: PALETTE.info, WARNING: PALETTE.warning, ERROR: PALETTE.error,
                     CRITICAL: '#7a1111', DEBUG: PALETTE.other };
  Charts.donut(c3, {
    desc: 'Audit events by severity', centre: 'events',
    items: Object.entries(a.by_severity || {}).map(([s, n]) => ({
      label: label('severity', s), value: n, color: sevColor[s] || PALETTE.other }))
  });
  const c4 = Charts.card(charts, 'Most frequent actions', 'The 15 actions recorded most often.', { wide: true });
  Charts.bars(c4, {
    desc: 'Most frequent audit actions',
    series: [{ name: 'Events', color: PALETTE.sand }],
    items: (a.top_actions || []).map(x => ({
      label: `${label('category', x.category)} · ${humanize(x.action)}`, values: [x.count] }))
  });
}

async function exportReportAudit() {
  const p = reportPeriod();
  // Without both days a custom range would export the whole trail
  // (DR-10, 2026-10-03): the same check as the report itself.
  if (p.period === 'custom' && (!p.date_from || !p.date_to)) {
    return msg('rp-msg', 'banner', 'Choose the first and last day of the period.', 5000);
  }
  // Reversed dates are refused here, not answered empty (UAT-L03).
  if (p.period === 'custom' && p.date_to < p.date_from) {
    return msg('rp-msg', 'banner', 'The last day is before the first day. Choose the period again.', 5000);
  }
  let from = p.date_from, to = p.date_to;
  if (p.period !== 'custom') {
    try {
      const a = await api('/console/reports' + qs(p));
      from = a.period.from; to = a.period.to;
    } catch (e) { return msg('rp-msg', 'err', e.message, 6000); }
  }
  try {
    const info = await download('/console/export/audit' + qs({ date_from: from, date_to: to,
                                                                sort: 'occurred_at', order: 'asc' }),
                                'audit.csv');
    if (!info) return;
    msg('rp-msg', info.truncated ? 'banner' : 'okmsg', exportText(info), info.truncated ? 0 : 6000);
  } catch (e) { msg('rp-msg', 'err', e.message, 8000); }
}

/* "Processing" as it really is (SY-04, 2026-10-03): paused, stopped,
 * or waiting for CyberArk or the operating window — not "Active" while
 * nothing can start. */
/* The Dashboard and the System page use this one card (UAT-L23,
 * 2026-10-04): the Dashboard said "Active" outside the window. */
function processingCard(disp) {
  disp = disp || {};
  let v = 'Active', cls = 'ok', sub = disp.busy ? 'A transaction is in progress' : 'Idle';
  if (disp.paused) {
    v = 'Paused'; cls = 'warn';
    // Who paused it and since when; kept across restarts (OPS-01).
    sub = disp.paused_by
      ? `Paused by ${disp.paused_by}` + (disp.paused_at ? ` since ${fmtTime(disp.paused_at)}` : '')
      : 'No new work starts until processing is resumed';
  }
  else if (!disp.running) { v = 'Stopped'; cls = 'bad'; sub = disp.reason || disp.mode || ''; }
  else if (disp.gate_open === false) {
    v = 'Waiting'; cls = 'warn';
    sub = 'CyberArk has not delivered the mainframe password yet';
  } else if (disp.accepting === false && !disp.busy) {
    v = 'Waiting'; cls = 'warn';
    sub = 'Outside the operating window, or the mainframe is not available';
  }
  return card('Processing', v, cls, sub, 'Whether the bot is taking work from the queue now.');
}

/* The e-mails kept for resending (EM-05, 2026-10-03): what waits, resend
 * now, and delete one that must not be sent any more. */
/* The configuration files in force, read-only (CFG-08 / OPS-07). */
async function loadConfigFiles() {
  const box = $('sys-files'), body = $('sys-files-body');
  let d;
  try { d = await api('/system/config-files'); }
  catch (e) { return show(box, false); }
  show(box, true);
  body.textContent = '';
  body.appendChild(el('p', 'dimmer', 'The copy of each file the service reads now. The ' +
    'files are changed on the server under change control; this page only shows them.'));
  const t = el('table');
  const hr = el('tr');
  // The file name only: the server's folders are not shown (E2E-L31).
  ['File', 'Used for', 'Last changed (JST)', 'Checksum (SHA-256)', ''].forEach(h => {
    const th = el('th', null, h); th.scope = 'col'; hr.appendChild(th);
  });
  t.appendChild(hr);
  d.files.forEach(f => {
    const tr = el('tr');
    tr.appendChild(el('td', 'mono', f.name));
    tr.appendChild(el('td', null, f.purpose));
    tr.appendChild(el('td', 'mono', f.exists ? fmtTime(f.modified) : 'Not present'));
    const sum = el('td', 'mono', f.sha256 ? f.sha256.slice(0, 12) + '…' : '—');
    if (f.sha256) sum.title = f.sha256;
    tr.appendChild(sum);
    const act = el('td');
    if (f.viewable && f.exists) {
      const b = el('button', 'btn sm ghost', 'View');
      b.type = 'button';
      b.setAttribute('aria-label', 'View ' + f.name);
      b.onclick = busy(b, () => viewConfigFile(f.name));
      act.appendChild(b);
    }
    tr.appendChild(act);
    t.appendChild(tr);
  });
  const wrap = el('div', 'dt'); wrap.appendChild(t); body.appendChild(wrap);
}

async function viewConfigFile(name) {
  let f;
  try { f = await api('/system/config-files/view' + qs({ name })); }
  catch (e) { return msg('sys-msg', 'err', e.message, 8000); }
  Drawer.open(f.name, `${f.purpose} · read-only · last changed ${fmtTime(f.modified)} (JST)`, b => {
    b.appendChild(el('pre', 'logbox', f.text));
  });
}

/* Who is signed in now, with End session (SES-06, 2026-10-04). */
async function loadSessions() {
  const box = $('us-sessions-box'), body = $('us-sessions');
  let d;
  try { d = await api('/admin/sessions'); }
  catch (e) { return show(box, false); }
  show(box, true);
  body.textContent = '';
  body.appendChild(el('p', 'dimmer', 'One row for each open console window. Ending a ' +
    'session signs that window out at once; the person can sign in again.'));
  if (!d.sessions.length) { body.appendChild(el('p', 'dimmer', 'No open sessions.')); return; }
  const t = el('table');
  const hr = el('tr');
  ['User', 'Signed in or renewed (JST)', 'Ends (JST)', 'Browser', ''].forEach(h => {
    const th = el('th', null, h); th.scope = 'col'; hr.appendChild(th);
  });
  t.appendChild(hr);
  d.sessions.forEach(x => {
    const tr = el('tr');
    tr.appendChild(el('td', 'mono', x.username + (x.current ? ' (this window)' : '')));
    tr.appendChild(el('td', 'mono', fmtTime(x.issued_at)));
    tr.appendChild(el('td', 'mono', fmtTime(x.expires_at)));
    tr.appendChild(el('td', null, x.client));
    const act = el('td');
    if (may('users.manage') && !x.current) {
      const b = el('button', 'btn sm ghost', 'End session');
      b.type = 'button';
      b.setAttribute('aria-label', 'End the session of ' + x.username);
      b.onclick = busy(b, async () => {
        if (!confirm(`End this session of ${x.username}? That window is signed out at once.`)) return;
        try {
          await api('/admin/sessions/' + encodeURIComponent(x.session_id), { method: 'DELETE' });
          msg('us-msg', 'okmsg', `The session of ${x.username} was ended.`, 6000);
        } catch (e) { msg('us-msg', 'err', e.message); }
        loadSessions();
      });
      act.appendChild(b);
    }
    tr.appendChild(act);
    t.appendChild(tr);
  });
  const wrap = el('div', 'dt'); wrap.appendChild(t); body.appendChild(wrap);
}

async function loadOutbox() {
  const box = $('sys-outbox'), body = $('sys-outbox-body');
  if (!may('system.manage')) return show(box, false);
  let d;
  try { d = await api('/system/email/outbox'); }
  catch (e) { return show(box, false); }
  show(box, true);
  body.textContent = '';
  if (!d.active) {
    body.appendChild(el('p', 'dimmer', 'Not in use: e-mail is switched off, ' +
      'or e-mails are not kept for resending.'));
    return;
  }
  const head = el('div', 'row');
  head.appendChild(el('span', 'dimmer', d.waiting
    ? `${d.waiting} e-mail(s) waiting to be resent; each is kept for ${d.keep_hours} hours.`
    : 'No e-mail is waiting: everything was delivered.'));
  if (d.waiting) {
    const b = el('button', 'btn sm ghost', 'Resend now');
    b.onclick = busy(b, async () => {
      try {
        const r = await api('/system/email/outbox/retry', { method: 'POST' });
        msg('sys-msg', r.paused_until_jst ? 'banner' : 'okmsg', r.paused_until_jst
          ? 'The mail server refused the sign-in recently; to avoid a lock-out ' +
            `the next attempt is at ${r.paused_until_jst} (JST).`
          : r.busy ? 'A resend is already running.'
          : `${r.sent} sent, ${r.given_up} given up, ${r.waiting} still waiting.`, 8000);
      } catch (e) { msg('sys-msg', 'err', e.message); }
      // The banner and the E-mail card too, not only this table (E2E-L17).
      LOADERS.system({ auto: true });
    });
    head.appendChild(b);
  }
  body.appendChild(head);
  if (!(d.emails || []).length) return;
  const t = el('table');
  const hr = el('tr');
  ['Kept since (JST)', 'Subject', 'To', 'Attempts', 'Last error', 'Given up after (JST)', '']
    .forEach(x => { const th = el('th', null, x); th.scope = 'col'; hr.appendChild(th); });
  t.appendChild(hr);
  d.emails.forEach(m => {
    const tr = el('tr');
    [m.kept_since_jst, m.subject, (m.recipients || []).join(', '), m.attempts,
     (m.last_error || '').slice(0, 80), m.given_up_after_jst]
      .forEach(v => tr.appendChild(el('td', null, String(v ?? ''))));
    const td = el('td');
    const del = el('button', 'btn sm ghost', 'Delete');
    del.setAttribute('aria-label', 'Delete the e-mail ' + m.subject);
    del.onclick = busy(del, async () => {
      if (!confirm(`Delete the e-mail "${m.subject}"? It will not be sent.`)) return;
      try {
        await api('/system/email/outbox/' + encodeURIComponent(m.id), { method: 'DELETE' });
        msg('sys-msg', 'okmsg', 'The e-mail was deleted from the outbox.', 5000);
      } catch (e) { msg('sys-msg', 'err', e.message); }
      loadOutbox();
    });
    td.appendChild(del); tr.appendChild(td);
    t.appendChild(tr);
  });
  const wrap = el('div', 'dt'); wrap.appendChild(t); body.appendChild(wrap);
}

/* ── module setup wizard ──────────────────────────────────────────
 * ServiceNow → SMTP → CyberArk → FINESIII → summary. Each page renders
 * the SAME rows as the Settings page (catalogue groups, deployment keys,
 * vault secrets) and saves through the same routes, so nothing here
 * has its own storage. Skip saves nothing and moves on. */
let WIZARD_DISMISSED = false;
const WIZARD_PAGES = [
  { id: 'servicenow', title: 'ServiceNow',
    intro: 'Where tickets come from. Choose the authentication the ' +
           'instance expects: the bot account (basic), OAuth with the ' +
           'bot account, or OAuth client credentials. Passwords and the ' +
           'client secret go to the OS credential vault. Tickets are ' +
           'fetched on the interval below, and closed with your comment ' +
           'after a successful provisioning or deprovisioning.',
    groups: ['ServiceNow'], secrets: ['SNOW_PASSWORD', 'SNOW_CLIENT_SECRET'],
    secretShowWhen: {
      SNOW_PASSWORD: { key: 'SNOW_AUTH_METHOD', value: ['basic', 'oauth_password', ''] },
      SNOW_CLIENT_SECRET: { key: 'SNOW_AUTH_METHOD', value: ['oauth_password', 'oauth_client_credentials'] } },
    test: 'servicenow' },
  { id: 'smtp', title: 'Email (SMTP)',
    intro: 'Outgoing mail for alerts, transaction notices and the ' +
           'account-created email. An internal relay on port 25 usually ' +
           'needs no username (STARTTLS if offered); port 587 uses ' +
           'STARTTLS, 465 uses SSL/TLS.',
    groups: ['Email'], secrets: ['SMTP_PASSWORD'], test: 'email' },
  { id: 'cyberark', title: 'CyberArk',
    intro: 'Where the mainframe service-account password comes from. ' +
           'Required in production with the real terminal driver.',
    groups: ['CyberArk'], secrets: ['CYBERARK_PVWA_PASSWORD'],
    // Only the PVWA API uses a password; the default (CCP) does not.
    secretShowWhen: {
      CYBERARK_PVWA_PASSWORD: { key: 'CYBERARK_API_STYLE', value: ['pvwa'] } },
    test: 'cyberark' },
  { id: 'finesiii', title: 'FINESIII target',
    intro: 'The terminal the bot drives: driver, mainframe environment and ' +
           'host, the service account (from the vault, or from CyberArk) ' +
           'and the Windows terminal application.',
    deployGroups: ['Deployment', 'Screen reading'],
    groups: ['FINESIII terminal', 'Operating window'],
    secrets: ['FINESIII_AFFILIATION_CODE', 'FINESIII_APPLICATION_ID',
              'FINESIII_PASSWORD'], test: 'mainframe' },
];
let WZ = { step: 0, state: {}, tests: {}, settings: null, deploy: null };

let WIZARD_FOCUS = null;        // where the focus was when it opened

async function openWizard() {
  WZ = { step: 0, state: {}, tests: {}, settings: null, deploy: null };
  const opener = document.activeElement;
  try {
    // What is set up already, so an unchanged page reads "kept" (E2E-L02).
    [WZ.settings, WZ.deploy, WZ.setup] = await Promise.all([
      api('/console/settings'), api('/system/deployment'),
      api('/system/setup').catch(() => null)]);
  } catch (e) {
    return msg('set-msg', 'err', 'Cannot open the setup: ' + e.message, 6000);
  }
  DEPLOY = WZ.deploy;
  WIZARD_FOCUS = opener;
  show($('wizard'), true);
  renderWizardPage();
  $('wz-close').focus();
}

function closeWizard() {
  WIZARD_DISMISSED = true;
  // Remembered for this account on the service (SES-05): the assistant
  // does not open again at the next sign-in or reload. Settings → "Run
  // setup again" still opens it.
  if (SETUP && !SETUP.complete && !SETUP.dismissed)
    api('/system/setup', { method: 'PUT', body: { dismissed: true } })
      .then(r => { SETUP = r; }).catch(() => { });
  show($('wizard'), false);
  restoreFocus(WIZARD_FOCUS);
  WIZARD_FOCUS = null;
  SETUP = undefined;
  if (LOADERS.settings && !$('v-settings').classList.contains('hide'))
    LOADERS.settings();
  if (may('dashboard.view')) LOADERS.dashboard();
}

function renderWizardSteps() {
  const host = $('wz-steps');
  host.textContent = '';
  WIZARD_PAGES.concat([{ id: 'summary', title: 'Summary' }]).forEach((p, i) => {
    const st = WZ.state[p.id];
    // A step can be opened directly (E2E-L02); like Back, what was typed
    // on the open page and not saved is left.
    const chip = el('button', 'wzstep' + (i === WZ.step ? ' on' : '') +
      (st === 'saved' || st === 'kept' ? ' done' : st === 'skipped' ? ' skipped' : ''),
      `${i + 1}. ${p.title}`);
    chip.type = 'button';
    if (i === WZ.step) chip.setAttribute('aria-current', 'step');
    chip.onclick = () => { if (i !== WZ.step) { WZ.step = i; renderWizardPage(); } };
    host.appendChild(chip);
  });
}

function renderWizardPage() {
  renderWizardSteps();
  msg('wz-msg', '', '');
  const body = $('wz-body'), tests = $('wz-test-area');
  body.textContent = ''; tests.textContent = '';
  $('wz-back').disabled = WZ.step === 0;
  if (WZ.step >= WIZARD_PAGES.length) return renderWizardSummary();
  const page = WIZARD_PAGES[WZ.step];
  $('wz-title').textContent = `${WZ.step + 1}. ${page.title}`;
  $('wz-intro').textContent = page.intro;
  show($('wz-skip'), true);
  $('wz-next').textContent = 'Save & continue';

  // FINESIII page: where the mainframe password comes from.
  if (page.id === 'finesiii') {
    const box = el('div', 'setgroup');
    box.appendChild(el('h3', null, 'Mainframe service account'));
    const row = el('div', 'setrow');
    const left = el('div');
    left.appendChild(el('div', 'lab', 'Password source'));
    const cyberOn = wizardValue('CYBERARK_ENABLED') === 'true';
    left.appendChild(el('div', 'hint', cyberOn
      ? 'CyberArk is enabled: the password is fetched from the vault ' +
        'you configured on the previous page. Enter only the affiliation ' +
        'and staff codes below.'
      : 'CyberArk is not enabled: enter the full service account below. ' +
        'In production with the real terminal driver CyberArk is required.'));
    row.appendChild(left);
    const sel = el('select'); sel.id = 'wz-credsource';
    [['vault', 'Stored here (OS credential vault)'],
     ['cyberark', 'Fetched from CyberArk']].forEach(([v, t]) => {
      const o = el('option', null, t); o.value = v;
      if ((cyberOn ? 'cyberark' : 'vault') === v) o.selected = true;
      if (v === 'cyberark' && !cyberOn) { o.disabled = true;
        o.textContent += ' — enable CyberArk first'; }
      sel.appendChild(o);
    });
    row.appendChild(sel);
    box.appendChild(row);
    body.appendChild(box);
  }

  (page.deployGroups || []).forEach(group => {
    const items = (WZ.deploy.settings || []).filter(s => s.group === group);
    if (!items.length) return;
    const box = el('div', 'setgroup');
    box.appendChild(el('h3', null, group));
    items.forEach(s => box.appendChild(deployRow(s)));
    body.appendChild(box);
  });
  (page.groups || []).forEach(group => {
    const items = (WZ.settings.settings || []).filter(s => s.group === group);
    if (!items.length) return;
    const box = el('div', 'setgroup');
    box.appendChild(el('h3', null, group));
    items.forEach(s => box.appendChild(settingRow(s)));
    body.appendChild(box);
  });
  if (page.secrets && page.secrets.length) {
    const box = el('div', 'setgroup');
    box.appendChild(el('h3', null, 'Credentials (OS vault)'));
    if (!WZ.deploy.vault.available)
      box.appendChild(el('div', 'banner', 'No OS credential vault is ' +
        'available on this machine — set these as environment variables.'));
    page.secrets.forEach(name => {
      const s = WZ.deploy.secrets[name];
      if (s) box.appendChild(secretRow(name, s, WZ.deploy.vault.available,
                                       (page.secretShowWhen || {})[name]));
    });
    body.appendChild(box);
  }
  applyShowWhen(body);
  wireTlsHint(body);
  if (page.id === 'finesiii') {
    const sel = $('wz-credsource');
    const toggle = () => {
      const useVault = sel.value === 'vault';
      body.querySelectorAll('[data-skey="FINESIII_PASSWORD"]').forEach(f => {
        show(f.closest('.setrow'), useVault);
      });
    };
    sel.onchange = toggle; toggle();
  }

  // Test controls for this page.
  if (page.test === 'email') {
    const to = el('input'); to.id = 'wz-test-to'; to.type = 'text';
    to.placeholder = 'send a test email to… (empty: the Default recipients)';
    tests.appendChild(to);
  }
  const t = el('button', 'btn sm ghost', {
    servicenow: 'Test connection', email: 'Send test email',
    cyberark: 'Test retrieval', mainframe: 'Test mainframe host' }[page.test]);
  t.onclick = busy(t, () => runWizardTest(page, holder));
  tests.appendChild(t);
  const holder = el('div');
  if (page.id === 'servicenow') {
    const d = el('button', 'btn sm ghost', 'Discover fields');
    d.onclick = busy(d, () => {
      if (savedSettingsOnly($('wz-body'), $('wz-msg'))) return discoverFields();
    });
    tests.appendChild(d);
    const p = el('button', 'btn sm ghost', 'Preview tickets');
    p.onclick = busy(p, () => {
      if (savedSettingsOnly($('wz-body'), $('wz-msg'))) return previewTickets($('wz-msg'), holder);
    });
    tests.appendChild(p);
  }
  if (page.test === 'mainframe') {
    [['Test terminal launch', 'launch'], ['Test sign-in and navigation', 'navigate']]
      .forEach(([label, level]) => {
        const b = el('button', 'btn sm ghost', label);
        b.onclick = busy(b, async () => {
          // The terminal test's result counts in the summary (E2E-L01).
          const r = await terminalTest(level, $('wz-msg'), holder);
          if (r) WZ.tests.terminal = !!(r.ok && r.sign_off && r.sign_off.ok);
        });
        tests.appendChild(b);
      });
  }
  tests.appendChild(holder);
}

const window_wizardValue = key => wizardValue(key);
const window_wizardSecret = name => wizardSecret(name);
function wizardValue(key) {
  // Current value as typed on the open page, else what the server holds.
  const f = $('wz-body').querySelector(`[data-key="${key}"],[data-dkey="${key}"]`);
  if (f) return String(fieldValue(f));
  const s = (WZ.settings && WZ.settings.settings || []).find(x => x.key === key)
        || (WZ.deploy && WZ.deploy.settings || []).find(x => x.key === key);
  if (!s) return '';
  const v = String(s.value ?? '').trim().toLowerCase();
  return ['1', 'yes', 'on'].includes(v) ? 'true' : v;
}
function wizardSecret(name) {
  const f = $('wz-body').querySelector(`[data-skey="${name}"]`);
  return f ? f.value : '';
}

async function runWizardTest(page, holder) {
  const r = await runModuleTest(page.test, wizardValue, wizardSecret, $('wz-msg'),
                                // Empty: the Default recipients (E2E-L16).
                                ($('wz-test-to') || {}).value || wizardValue('ALERT_TO'),
                                holder);
  // Kept for the summary (SN-04, 2026-10-03). With no mainframe host
  // configured the probe tests nothing (E2E-L01).
  if (r) WZ.tests[page.id] = page.test === 'mainframe' && r.ok && !r.host
    ? 'no-host' : !!r.ok;
}

/* One module test, from the setup assistant or a Settings page
 * (2026-09-29): `read`/`secret` give the values on that page, `box`
 * shows the result. Every write goes through msg(), so an earlier
 * message's timer never clears this result (NB-018). */
async function runModuleTest(test, read, secret, box, to, holder) {
  const wizardValue = read, wizardSecret = secret;
  msg(box, 'banner', 'Testing…');
  if (holder) holder.textContent = '';
  try {
    let r;
    if (test === 'servicenow') {
      r = await api('/system/test-servicenow', { method: 'POST', body: snowTestBody(read, secret) });
      msg(box, r.ok ? 'okmsg' : 'err', r.ok
        ? `Connected to ${r.instance_url}.` + (r.would_read != null
            ? ` The next poll would read ${fmtNum(r.would_read)} ticket(s).` : '') +
          ((r.notes || []).length ? ' See the notes below.' : '')
        : `${r.error}${r.hint ? ' — ' + r.hint : ''}`);
      if (r.ok && holder) holder.appendChild(snowTestReport(r));
    } else if (test === 'email') {
      r = await api('/system/test-email', { method: 'POST',
        body: mailTestBody(wizardValue, wizardSecret, true, to) });
      msg(box, r.ok ? 'okmsg' : 'err', mailTestText(r));
    } else if (test === 'cyberark') {
      r = await api('/system/test-cyberark', { method: 'POST', body: {
        api_style: wizardValue('CYBERARK_API_STYLE'),
        base_url: wizardValue('CYBERARK_BASE_URL'),
        app_id: wizardValue('CYBERARK_APP_ID'), safe: wizardValue('CYBERARK_SAFE'),
        object_name: wizardValue('CYBERARK_OBJECT'),
        account_username: wizardValue('CYBERARK_ACCOUNT_USERNAME'),
        pvwa_username: wizardValue('CYBERARK_PVWA_USER'),
        pvwa_auth_type: wizardValue('CYBERARK_PVWA_AUTH_TYPE'),
        pvwa_password: wizardSecret('CYBERARK_PVWA_PASSWORD'),
        client_cert_path: wizardValue('CYBERARK_CERT_PATH'),
        client_key_path: wizardValue('CYBERARK_KEY_PATH'),
        verify_tls: wizardValue('CYBERARK_VERIFY_TLS') || undefined } });
      msg(box, r.ok ? 'okmsg' : 'err', r.ok
        ? `Retrieved the password from ${r.base_url} (${r.api_style}). The value is not shown.`
        : `${r.error}${r.hint ? ' — ' + r.hint : ''}`);
    } else {
      r = await api('/system/test-mainframe', { method: 'POST', body: {
        host: wizardValue('MAINFRAME_HOST'), port: wizardValue('MAINFRAME_PORT') } });
      msg(box, r.ok ? 'okmsg' : 'err', r.ok
        ? (r.note || `${r.host}:${r.port} reachable (${r.latency_ms} ms).`)
        : `${r.error}${r.hint ? ' — ' + r.hint : ''}`);
    }
    return r;
  } catch (e) {
    msg(box, 'err', e.message);
    if (e.status === 401) signOut();
    return { ok: false };
  }
}

/* A small result table (2026-09-29): headers and rows of text. */
function resultTable(headers, rows) {
  const t = el('table');
  const hr = el('tr');
  headers.forEach(h => hr.appendChild(el('th', null, h)));
  t.appendChild(hr);
  rows.forEach(r => {
    const tr = el('tr');
    r.forEach(v => tr.appendChild(el('td', null, String(v ?? ''))));
    t.appendChild(tr);
  });
  return t;
}

/* A titled block of a ServiceNow report. */
function reportSection(title, ...nodes) {
  const s = el('section', 'rep-sec');
  s.appendChild(el('h4', null, title));
  nodes.filter(Boolean).forEach(n => s.appendChild(n));
  return s;
}
/* The ticket filters: what is applied and what is not set. */
function filterTable(filters) {
  const t = resultTable(['Filter', 'Value', 'Applied'],
    (filters || []).map(f => [f.name, f.value || 'Not set',
                              f.value ? 'Yes' : 'No (skipped)']));
  t.classList.add('rep-table');
  t.querySelectorAll('tr').forEach((tr, i) => {
    if (i && !(filters[i - 1] || {}).value) tr.classList.add('rep-off');
  });
  return t;
}
/* A list of notes, or nothing. */
function noteList(notes) {
  if (!(notes || []).length) return null;
  const ul = el('ul', 'rep-notes');
  notes.forEach(n => ul.appendChild(el('li', null, n)));
  return ul;
}

/* Test connection, ServiceNow: the connection, the bot account, the
 * filters, and the open tickets left after each filter. */
function snowTestReport(r) {
  const box = el('div', 'snowreport');
  const checks = el('ul', 'rep-checks');
  const check = (ok, text) => {
    const li = el('li', ok === true ? 'rep-ok' : ok === false ? 'rep-bad' : 'rep-info');
    li.appendChild(el('span', 'rep-mark', ok === true ? '✓' : ok === false ? '✗' : 'i'));
    li.appendChild(el('span', null, text));
    checks.appendChild(li);
  };
  check(true, `Signed in to ${r.instance_url} (${r.auth_method}` +
              (r.token_ok ? ', OAuth token obtained' : '') + ').');
  const a = r.account;
  const who = r.account_source === 'sign_in' ? 'ServiceNow username' : 'Bot account';
  check(!!a, a ? `${who}: ${a.name || a.user_name} (user name ${a.user_name}, sys_id ${a.sys_id}).` +
                 ' Tickets are assigned to this account before they are queued.'
               : `${who} not found in ServiceNow: tickets cannot be assigned to the bot.`);
  check(!!r.table_ok, `Ticket table ${r.table} is readable.`);
  if (r.group_member === true) check(true, 'The bot account is a member of the group.');
  if (r.group_member === false) check(false, 'The bot account is not a member of the group.');
  (r.requested_for || []).filter(f => f.matches === 1).forEach(f =>
    check(true, `Requested For "${f.value}" is ${f.name} (sys_id ${f.sys_id}).`));
  box.appendChild(reportSection('Connection', checks));

  if ((r.filters || []).length) {
    box.appendChild(reportSection('Ticket filters', filterTable(r.filters),
      el('p', 'rep-hint', 'A filter that is not set is skipped. Closed tickets are never read.')));
  }
  const counts = r.selection_counts || [];
  if (counts.length) {
    const t = resultTable(['Step', 'Open tickets'], counts.map(c => [
      c.step + (c.by === 'bot' ? ' (checked by the bot)' : ''),
      c.count == null ? 'Could not be counted'
        : fmtNum(c.count) + (c.of != null ? ` of ${fmtNum(c.of)}` + (c.capped ? ' read' : '') : '')]));
    t.classList.add('rep-table', 'rep-counts');
    const rows = t.querySelectorAll('tr');
    counts.forEach((c, i) => { if (c.count === 0) rows[i + 1].classList.add('rep-zero'); });
    const total = el('p', 'rep-total', r.would_read != null
      ? `The next poll would read ${fmtNum(r.would_read)} ticket(s).` : '');
    box.appendChild(reportSection('Open tickets after each filter', t, total));
  }
  const sample = r.requested_for_sample || [];
  if (sample.length) {
    const t = resultTable(['Field', 'Value on the tickets', 'Tickets'],
      sample.map(x => [x.field, x.value, fmtNum(x.tickets)]));
    t.classList.add('rep-table');
    box.appendChild(reportSection('Requested For on these tickets', t));
  }
  const notes = noteList(r.notes);
  if (notes) box.appendChild(reportSection('Notes', notes));
  return box;
}

/* Preview tickets (2026-09-29): what the next poll WOULD do with each
 * open ticket. Read-only — nothing is written to ServiceNow. */
async function previewTickets(box, holder) {
  msg(box, 'banner', 'Reading the open tickets (nothing is written)…');
  holder.textContent = '';
  try {
    const r = await api('/system/servicenow/preview', { method: 'POST' });
    if (!r.ok) return msg(box, 'err', r.error || 'The preview failed.');
    const words = { queue: 'Queue', reject: 'Reject', skip: 'Skip', defer: 'Next poll' };
    // The preview reads at most r.limit tickets.
    const capped = r.limit && r.fetched >= r.limit;
    msg(box, 'okmsg', (capped
      ? `Preview of the first ${fmtNum(r.limit)} open tickets (there may be more).`
      : `Preview of ${fmtNum(r.fetched)} open ticket(s).`) +
      ' Nothing was written to ServiceNow.' +
      (r.polling_enabled ? '' : ' Polling is switched off.'));
    const rep = el('div', 'snowreport');
    // What would happen, in numbers.
    const sum = r.summary || {};
    const chips = el('div', 'rep-chips');
    const chip = (n, label, cls) => {
      const c = el('span', 'rep-chip ' + cls);
      c.appendChild(el('b', null, fmtNum(n)));
      c.appendChild(document.createTextNode(' ' + label));
      chips.appendChild(c);
    };
    chip(r.fetched || 0, 'read', 'all');
    chip(sum.queue || 0, 'to queue', 'queue');
    chip(sum.reject || 0, 'to reject (note on the ticket)', 'reject');
    chip(sum.skip || 0, 'skipped', 'skip');
    chip(sum.defer || 0, 'next poll', 'defer');
    rep.appendChild(reportSection('Summary', chips));
    if ((r.filters || []).length) rep.appendChild(reportSection('Ticket filters', filterTable(r.filters)));
    if (r.tickets.length) {
      const order = { queue: 0, defer: 1, reject: 2, skip: 3 };
      const tickets = [...r.tickets].sort((a, b) => (order[a.action] ?? 9) - (order[b.action] ?? 9));
      const t = resultTable(['Ticket', 'The bot would', 'Details'],
        tickets.map(t => [t.ticket,
          t.action === 'queue' && t.assign_to ? 'Assign to the bot, then queue'
            : (words[t.action] || t.action),
          t.action === 'queue'
            ? (t.requests || []).map(q => `${q.operation} ${q.affiliation_code} ${q.employee_code}`).join('; ') +
              (t.possible_duplicate_of ? ` (looks like ${t.possible_duplicate_of})` : '')
            : t.reason + (t.already_reported ? ' (already reported)' : '')]));
      t.classList.add('rep-table');
      t.querySelectorAll('tr').forEach((tr, i) => {
        if (i) tr.classList.add('rep-' + (tickets[i - 1].action || ''));
      });
      rep.appendChild(reportSection('Tickets', t));
    } else {
      rep.appendChild(reportSection('Tickets', el('p', 'rep-hint',
        'No open ticket matches the filters. Test connection shows where the count drops to 0.')));
    }
    if (r.query) {
      const d = el('details', 'rep-query');
      d.appendChild(el('summary', null, 'ServiceNow query (for support)'));
      d.appendChild(el('code', 'mono', r.query));
      rep.appendChild(d);
    }
    holder.appendChild(rep);
  } catch (e) { msg(box, 'err', e.message); }
}

/* Terminal check (2026-09-29): launch only, or sign-in and navigation to
 * Task 903 (no data typed, never 00 or 70). Processing must be paused. */
async function terminalTest(level, box, holder) {
  if (level === 'navigate' && !confirm(
      'Test sign-in and navigation?\n\nThe bot signs in to FINESIII once ' +
      'with the service account and opens Task 903. No data is typed and ' +
      'nothing is submitted. A wrong password counts toward the account ' +
      'lockout.\n\nProcessing must be paused (System page).')) return;
  msg(box, 'banner', level === 'navigate'
    ? 'Signing in and opening Task 903… (up to a few minutes)'
    : 'Starting the terminal… (up to a minute)');
  holder.textContent = '';
  try {
    const r = await api('/system/test-terminal', { method: 'POST',
      body: { level, confirm: level === 'navigate' } });
    // The program and window in force: the settings the service started
    // with, not the values on the page (TM-02, 2026-10-03).
    const a = r.application || {};
    const used = ` Used: ${a.shortcut ? 'shortcut ' + a.shortcut
                          : a.executable ? 'program ' + a.executable : 'the default program'}` +
      (a.window_title ? `, window title containing "${a.window_title}"` : '') + '.';
    msg(box, r.ok && r.sign_off.ok ? 'okmsg' : 'err', (r.ok
      ? `Terminal check passed (${r.driver}).` +
        (r.sign_off.ok ? ' Signed off cleanly.' : ` Sign-off stopped at ${r.sign_off.stopped_at}.`) +
        // The folder's name only, not the server path (E2E-L31).
        ` Screenshots: ${String(r.evidence_folder || '').split(/[\\/]/).pop()}`
      : `Failed at "${r.failed_step}": ${r.error}${r.hint ? ' — ' + r.hint : ''}`) + used);
    holder.appendChild(resultTable(['Step', 'What', 'Result', 'Seconds', 'Detail'],
      r.steps.map(s => [s.step, s.what, s.status === 'ok' ? 'OK' : 'Failed',
                         s.seconds, s.detail || s.screen])));
    return r;
  } catch (e) { msg(box, 'err', e.message); }
}

/* The module tests on the Settings pages (2026-09-29): the same tests as
 * the setup assistant, with the values on the page. */
/* What each test reads (SN-05 / TM-02, 2026-10-03). */
const TEST_HINTS = {
  'ServiceNow': 'Test connection uses the values on this page, before they ' +
    'are saved. Discover fields and Preview tickets compare the tickets with ' +
    'the SAVED settings (Discover reads them with the connection on this ' +
    'page): save your changes first.',
  'CyberArk': 'Uses the values on this page, before they are saved.',
  'FINESIII terminal': 'Test mainframe host uses the values on this page. The ' +
    'terminal tests use the settings the service was started with (restart ' +
    'after changing the terminal program) and need processing to be paused ' +
    '(System page).'
};

/* Unsaved changes anywhere on the Settings page, credentials included
 * (SES-04, 2026-10-04): a field whose value differs from the one
 * loaded, or a password typed and not saved. */
function changedField(f) {
  if (f.disabled) return false;
  if (f.dataset.skey) return !!String(f.value || '').trim();
  return String(f.value ?? '') !== String(f.dataset.original ?? '');
}
const SETTING_FIELDS = '[data-key],[data-dkey],[data-skey]';
function settingsUnsaved() {
  return [$('set-body'), $('set-deploy')].some(root => root &&
    Array.from(root.querySelectorAll(SETTING_FIELDS)).some(changedField));
}
/* The sections holding unsaved changes are marked in the section list. */
function markUnsavedSections() {
  document.querySelectorAll('#set-nav button[data-page]').forEach(b => {
    const box = document.querySelector(
      `#set-body .setgroup[data-group="${CSS.escape(b.dataset.page)}"], ` +
      `#set-deploy .setgroup[data-group="${CSS.escape(b.dataset.page)}"]`);
    const dirty = !!box && Array.from(box.querySelectorAll(SETTING_FIELDS)).some(changedField);
    b.classList.toggle('dirty', dirty);
    b.textContent = (b.dataset.label || b.textContent) + (dirty ? ' •' : '');
    if (dirty) b.setAttribute('aria-description', 'unsaved changes');
    else b.removeAttribute('aria-description');
  });
}
['input', 'change'].forEach(ev => ['set-body', 'set-deploy'].forEach(id =>
  $(id).addEventListener(ev, markUnsavedSections)));
/* Reloading or closing the page with unsaved settings: the browser asks. */
window.addEventListener('beforeunload', e => {
  if (SIGNED_IN && settingsUnsaved()) { e.preventDefault(); e.returnValue = ''; }
});

/* Unsaved changes in one settings group, or on the assistant's page. */
function unsavedIn(container) {
  // A typed password or secret not saved yet counts too (UAT-L19).
  return !!container && Array.from(container.querySelectorAll(SETTING_FIELDS))
    .some(changedField);
}
function savedSettingsOnly(container, box) {
  if (!unsavedIn(container)) return true;
  msg(box, 'banner', 'This test uses the saved settings, and this page has ' +
      'unsaved changes. Save them first (Save changes, or Next in the setup ' +
      'assistant), then run the test.');
  return false;
}

const SETTINGS_TESTS = {
  'ServiceNow': [['Test connection', 'servicenow'], ['Discover fields', 'discover'],
                 ['Preview tickets', 'preview']],
  'CyberArk': [['Test retrieval', 'cyberark']],
  'FINESIII terminal': [['Test mainframe host', 'mainframe'],
                        ['Test terminal launch', 'launch'],
                        ['Test sign-in and navigation', 'navigate']],
};

function settingsValue(key) {
  const f = document.querySelector(
    `#set-body [data-key="${key}"], #set-deploy [data-key="${key}"], ` +
    `#set-body [data-dkey="${key}"], #set-deploy [data-dkey="${key}"]`);
  return f ? String(fieldValue(f)).trim() : '';
}
function settingsSecret(name) {
  const f = document.querySelector(`[data-skey="${name}"]`);
  return f ? f.value : '';
}

function moduleTestRow(group) {
  const tests = SETTINGS_TESTS[group];
  if (!tests) return null;
  const row = el('div', 'setrow');
  row.dataset.search = ('test ' + tests.map(t => t[0]).join(' ')).toLowerCase();
  const left = el('div');
  left.appendChild(rowLabel('Tests', TEST_HINTS[group] || ''));
  row.appendChild(left);
  const right = el('div');
  const holder = el('div');
  holder.style.gridColumn = '1 / -1';
  tests.forEach(([label, kind]) => {
    const b = el('button', 'btn sm ghost', label);
    b.onclick = busy(b, () => {
      const card = row.closest('.setgroup');
      if ((kind === 'discover' || kind === 'preview') &&
          !savedSettingsOnly(card, 'set-msg')) return;
      if (kind === 'discover') return discoverFields(settingsValue, settingsSecret, 'set-msg');
      if (kind === 'preview') return previewTickets($('set-msg'), holder);
      if (kind === 'launch' || kind === 'navigate') return terminalTest(kind, $('set-msg'), holder);
      return runModuleTest(kind, settingsValue, settingsSecret, $('set-msg'), '', holder);
    });
    right.appendChild(b);
  });
  row.appendChild(right);
  row.appendChild(holder);
  return row;
}

/* What the ServiceNow test/discover calls send: everything typed on the
 * page (blanks fall back server-side to what is stored). */
function snowTestBody(read, secret) {
  // Default: the values on the setup assistant's page.
  const wizardValue = read || window_wizardValue;
  const wizardSecret = secret || window_wizardSecret;
  return {
    instance_url: wizardValue('SNOW_INSTANCE_URL'),
    auth_method: wizardValue('SNOW_AUTH_METHOD'),
    username: wizardValue('SNOW_USERNAME'),
    password: wizardSecret('SNOW_PASSWORD'),
    client_id: wizardValue('SNOW_CLIENT_ID'),
    client_secret: wizardSecret('SNOW_CLIENT_SECRET'),
    token_url: wizardValue('SNOW_TOKEN_URL'),
    table: wizardValue('SNOW_TABLE'),
    // Ticket selection (2026-09-30): the bot account the tickets are
    // assigned to, and in group mode the group and Requested For.
    assigned_to: wizardValue('SNOW_ASSIGNED_TO'),
    assignment_mode: wizardValue('SNOW_ASSIGNMENT_MODE'),
    assignment_group: wizardValue('SNOW_ASSIGNMENT_GROUP'),
    requested_for: wizardValue('SNOW_REQUESTED_FOR'),
    // The field is tested too (S-02, 2026-10-04).
    requested_for_field: wizardValue('SNOW_REQUESTED_FOR_FIELD') };
}

async function discoverFields(read = wizardValue, secret = wizardSecret,
                              box = $('wz-msg')) {
  msg(box, 'banner', 'Reading a sample of tickets…');
  try {
    const r = await api('/system/discover-servicenow', { method: 'POST', body: snowTestBody(read, secret) });
    if (!r.ok) return msg(box, 'err', r.error);
    if (r.empty) {
      // No ticket to look at: nothing can be said about the mapping.
      return msg(box, 'banner', 'Connected, but no open ticket is assigned to the bot ' +
        '(its account or group) yet, so the fields cannot be checked. ' +
        'Route a sample ticket to the bot and run Discover fields again.');
    }
    if (r.ticket_format === 'sailpoint') {
      // SailPoint tasks: the catalog variables are what the bot reads.
      const notFound = Object.entries(r.variables_found || {})
        .filter(([, ok]) => !ok).map(([k]) => k);
      // Found on the tickets, but with no value on any sample ticket.
      const empty = r.variables_empty || [];
      const first = (r.variables || [])[0] || [];
      msg(box, notFound.length || empty.length ? 'banner' : 'okmsg',
        `${first.length} catalog variable(s) on the first ` +
        `sample task: ${first.map(v => `${v.label || v.name}` +
          (v.name && v.label ? ` [${v.name}]` : '')).join('; ') || 'none'}. ` +
        (notFound.length
          ? `Not found with the configured labels: ${notFound.join(', ')} — ` +
            `adjust the "Variable: …" settings below.`
          : 'Every configured variable was found.') +
        (empty.length
          ? ` Found, but empty on the sample ticket: ${empty.join(', ')}.`
          : ''));
      return;
    }
    const missing = Object.entries(r.mapped || {}).filter(([, f]) => !r.fields.includes(f));
    msg(box, missing.length ? 'banner' : 'okmsg', `${r.fields.length} fields on the table. ` +
      (missing.length
        ? `Mapped fields NOT present: ${missing.map(([k, f]) => `${f} (${k})`).join(', ')} — ` +
          `update the field mapping in the ServiceNow configuration and restart the service.`
        : 'All mapped fields are present.'));
  } catch (e) { msg(box, 'err', e.message); }
}

async function saveWizardPage() {
  const body = $('wz-body');
  const bad = invalidNumbers([body]);
  if (bad.length) {
    bad[0].focus();
    throw new Error(numbersMessage(bad));
  }
  const changes = {};
  body.querySelectorAll('[data-key]').forEach(f => {
    if (f.disabled) return;
    if (f.dataset.secret) { if (f.value) changes[f.dataset.key] = f.value; }
    else if (f.value !== f.dataset.original) changes[f.dataset.key] = scaledOut(f);
  });
  let n = 0;
  if (Object.keys(changes).length) {
    const r = await api('/console/settings', { method: 'PUT', body: changes });
    n += Object.keys(r.changed).length + r.cleared.length;
  }
  let dep;
  try { dep = await saveDeployment(body); }
  catch (e) {
    // The settings above ARE saved; say what was not (SN-04).
    if (n) {
      const err = new Error(`${n} setting(s) were saved, but the machine settings ` +
                            `or credentials on this page were not: ${e.message}`);
      err.status = e.status; err.partial = true;
      throw err;
    }
    throw e;
  }
  return n + dep.changed;
}

/* Each module as the service holds it now (SN-04, 2026-10-03): on, set
 * up (with its password or secret), the test result of this session, and
 * what this run saved. A module set up earlier shows as set up. */
function wizardModules() {
  const m = (WZ.setup && WZ.setup.modules) || {};
  return WIZARD_PAGES.map(p => {
    const s = m[p.id] || {};
    return { page: p, enabled: p.id === 'finesiii' ? true : !!s.enabled,
             configured: p.id === 'finesiii' ? true : !!s.configured,
             test: WZ.tests[p.id], saved: WZ.state[p.id] === 'saved' };
  });
}
function wizardIncomplete() {
  return wizardModules().filter(x => x.enabled && !x.configured);
}
/* A module switched on and fully set up — now or in an earlier run. */
function wizardSetUpAny() {
  return wizardModules().some(x => x.page.id !== 'finesiii' && x.enabled && x.configured);
}

async function renderWizardSummary() {
  $('wz-title').textContent = 'Summary';
  $('wz-intro').textContent = 'Each module as it is set up now. ' +
    'Restart-scoped settings take effect after the service restarts.';
  show($('wz-skip'), false);
  $('wz-next').textContent = 'Finish';
  const body = $('wz-body');
  try { WZ.setup = await api('/system/setup'); } catch (e) { WZ.setup = null; }
  const ul = el('ul', 'wzsummary checks');
  wizardModules().forEach(x => {
    const ok = x.page.id === 'finesiii' || !x.enabled || x.configured;
    const li = el('li');
    li.appendChild(el('span', 'mark ' + (ok ? 'ok' : 'skipped'),
      x.page.id === 'finesiii' ? (x.saved ? 'saved' : 'as is')
        : !x.enabled ? 'off' : x.configured ? 'set up' : 'incomplete'));
    const t = el('div'); t.appendChild(el('div', null, x.page.title));
    const notes = [];
    if (x.saved) notes.push('Saved in this run.');
    if (x.enabled && !x.configured)
      notes.push('Switched on, but not fully set up (address, account, or its ' +
                 'password or secret is missing).');
    if (!x.enabled && x.page.id !== 'finesiii') notes.push('Off — can be set up later under Settings.');
    if (x.page.id === 'finesiii') {
      // The terminal tests and the host probe, each for what it is (E2E-L01).
      const term = WZ.tests.terminal;
      if (term !== undefined) notes.push(term ? 'Terminal test passed.' : 'Terminal test failed — see Settings.');
      if (x.test === 'no-host') notes.push('No mainframe host configured — host probe only.');
      else if (x.test === true) notes.push(term === undefined
        ? 'Mainframe host reachable (host probe only).' : 'Mainframe host reachable.');
      else if (x.test === false) notes.push('Mainframe host not reachable.');
      else if (term === undefined) notes.push('Not tested in this run.');
    } else if (x.test === true) notes.push('Test passed.');
    else if (x.test === false) notes.push('Test failed — see Settings.');
    else if (x.page.test && x.enabled) notes.push('Not tested in this run.');
    if (notes.length) t.appendChild(el('div', 'dimmer', notes.join(' ')));
    li.appendChild(t); ul.appendChild(li);
  });
  body.appendChild(ul);
  // Every page skipped: Finish stores nothing and the setup is not
  // marked complete, so the Dashboard keeps its checklist.
  if (!wizardSavedAny() && !wizardSetUpAny()) {
    body.appendChild(el('div', 'infobar',
      'Nothing was set up — the checklist stays on the Dashboard.'));
  } else if (wizardIncomplete().length) {
    body.appendChild(el('div', 'banner',
      'A module is switched on but not fully set up: the setup is not marked ' +
      'complete, and the checklist stays on the Dashboard until it is.'));
  }
  const tests = $('wz-test-area');
  const rs = el('button', 'btn sm ghost', 'Restart service now');
  rs.onclick = restartService;
  tests.appendChild(rs);
}

function wizardSavedAny() {
  return WIZARD_PAGES.some(p => WZ.state[p.id] === 'saved');
}

async function wizardNext() {
  const box = $('wz-msg');
  if (WZ.step >= WIZARD_PAGES.length) {
    // Complete only when something was set up and no module is on but
    // half set up (SN-04, 2026-10-03).
    const missing = wizardIncomplete();
    if (missing.length && !confirm(`${missing.map(x => x.page.title).join(', ')} ` +
        'is switched on but not fully set up. Close the assistant anyway? The ' +
        'setup stays open on the Dashboard.')) return;
    if ((wizardSavedAny() || wizardSetUpAny()) && !missing.length) {
      try { await api('/system/setup', { method: 'PUT', body: { complete: true } }); }
      catch (e) { msg(box, 'err', e.message); return; }
    }
    closeWizard();
    return;
  }
  $('wz-next').disabled = true;
  try {
    const n = await saveWizardPage();
    // Nothing entered: the page counts as skipped, unless it was saved
    // before (NB-032). Finish then marks the setup complete only when a
    // page really stored something.
    const id = WIZARD_PAGES[WZ.step].id;
    const before = WZ.state[id];
    // A module set up earlier and left unchanged is kept, not skipped
    // (E2E-L02).
    const m = ((WZ.setup || {}).modules || {})[id] || {};
    const kept = !n && before !== 'saved' &&
      (id === 'finesiii' || (m.enabled && m.configured));
    WZ.state[id] = n ? 'saved' : (before === 'saved' ? 'saved' : kept ? 'kept' : 'skipped');
    // Refresh what the server holds so later pages (CyberArk → FINESIII)
    // see the saved values.
    [WZ.settings, WZ.deploy] = await Promise.all([
      api('/console/settings'), api('/system/deployment')]);
    DEPLOY = WZ.deploy;
    WZ.step += 1;
    renderWizardPage();
    if (n) msg('wz-msg', 'okmsg', `Saved ${n} setting(s).`, 3000);
    else if (before === 'saved') msg('wz-msg', 'infobar', 'Nothing was changed on that page.', 5000);
    else if (kept) msg('wz-msg', 'infobar',
                       'Nothing was changed on that page — kept as configured.', 5000);
    else msg('wz-msg', 'infobar',
             'Nothing was entered on that page — it counts as skipped.', 5000);
  } catch (e) {
    // Refused (e.g. STARTTLS and implicit SSL both On): the reason.
    msg(box, 'err', e.partial ? e.message : 'Could not save this page: ' + e.message);
    if (e.status === 401) signOut();
  } finally { $('wz-next').disabled = false; }
}

function wizardSkip() {
  if (WZ.step < WIZARD_PAGES.length) {
    WZ.state[WIZARD_PAGES[WZ.step].id] = WZ.state[WIZARD_PAGES[WZ.step].id] || 'skipped';
    WZ.step += 1;
    renderWizardPage();
  }
}

/* ── wiring ───────────────────────────────────────────────────── */
// The sign-in forms never navigate: their buttons do the work. Set here
// rather than in the page, whose security policy refuses inline
// handlers (SEC-04, 2026-10-04).
['form-login', 'form-setup', 'form-change'].forEach(id =>
  $(id).addEventListener('submit', e => e.preventDefault()));
$('lg-go').onclick = doLogin;
$('wz-close').onclick = closeWizard;
$('wz-back').onclick = () => { if (WZ.step > 0) { WZ.step -= 1; renderWizardPage(); } };
$('wz-skip').onclick = wizardSkip;
$('wz-next').onclick = wizardNext;
$('set-wizard').onclick = () => { WIZARD_DISMISSED = false; openWizard(); };
$('lg-sso').onclick = doWindowsLogin;
$('log-refresh').onclick = loadLog;
$('log-file').onchange = loadLog;
$('log-lines').onchange = loadLog;
$('log-level').onchange = loadLog;
$('log-q').onkeydown = e => { if (e.key === 'Enter') loadLog(); };
// Dialogs keep the keyboard inside them (X-06).
trapFocus($('viewer')); trapFocus($('wizard')); trapFocus($('idle-box'));
$('br-save').onclick = saveBranding;
$('br-reset').onclick = resetBranding;
Object.entries(BR_IMAGES).forEach(([key, id]) => {
  $(id).onchange = () => readImage($(id), key, BR_LIMITS[key]);
  $(id + '-clear').onclick = () => { BR_DRAFT[key] = ''; $(id).value = '';
                                     brPreview(key); renderMailPreview(); };
});
['br-email-header', 'br-email-accent', 'br-email-company', 'br-email-foot', 'br-name',
 'br-support']
  .forEach(id => { $(id).addEventListener('input', renderMailPreview); });
$('su-go').onclick = doSetup;
$('set-export').onclick = exportConfiguration;
$('cp-go').onclick = doChange;
$('cp-back').onclick = () => {   // NB-030: leave the forced change
  $('cp-cur').value = ''; $('cp-new').value = ''; $('cp-new2').value = '';
  if (CHANGE_VOLUNTARY && SIGNED_IN) {
    // A change asked for from the header: back to the console (D-08).
    CHANGE_VOLUNTARY = false;
    $('cp-back').textContent = 'Back to sign in';
    show($('gate'), false); show($('shell'), true);
    return;
  }
  signOut({ reason: 'user' });
};
$('chpw').onclick = e => { e.preventDefault(); showGate('change', { voluntary: true }); };
$('lg-pass').onkeydown = e => { if (e.key === 'Enter') doLogin(); };
$('signout').onclick = e => { e.preventDefault(); signOut({ reason: 'user' }); };
$('idle-stay').onclick = async () => {
  markActivity(true);
  hideIdlePrompt();
  try { await renewSession(); } catch (e) { if (e.status === 401) signOut(); }
};
$('idle-out').onclick = () => signOut({ reason: 'user' });
$('dash-refresh').onclick = () => { LOADERS.dashboard(); loadDashMetrics(); };
$('dash-period').value = Prefs.get('dash.period', '7d');
$('dash-period').onchange = () => { Prefs.set('dash.period', $('dash-period').value);
                                    loadDashMetrics(); };
$('rp-period').onchange = () => {
  const custom = $('rp-period').value === 'custom';
  show($('rp-from'), custom); show($('rp-to'), custom);
  if (!custom) LOADERS.reports();
};
$('rp-go').onclick = () => LOADERS.reports();
$('rp-export').onclick = exportReportAudit;
$('rp-print').onclick = () => window.print();
$('rf-save').onclick = submitRequestForm;
$('rf-cancel').onclick = () => { $('rf-pass').value = ''; show($('req-form'), false); };
$('rf-op').onchange = () => show($('rf-pass-row'), $('rf-op').value === 'provision');
$('ev-go').onclick = () => LOADERS.evidence();
$('ev-id').onkeydown = e => { if (e.key === 'Enter') LOADERS.evidence(); };
$('au-go').onclick = () => TABLES.audit && TABLES.audit.refresh();
$('us-new').onclick = openUserForm;
$('nu-save').onclick = saveUser;
$('us-export').onclick = busy($('us-export'), async () => {
  try {
    const info = await download('/admin/users/export', 'users.csv');
    if (info) msg('us-msg', 'okmsg', exportText(info), 6000);
  } catch (e) { msg('us-msg', 'err', e.message, 8000); }
});
$('nu-cancel').onclick = () => show($('us-form'), false);
$('rl-new').onclick = () => openRoleForm(null);
$('nr-save').onclick = saveRole;
$('nr-cancel').onclick = () => show($('rl-form'), false);
$('set-save').onclick = saveSettings;
$('set-restart').onclick = () => restartService();
/* Save and restart in one step (OPS-06 / CFG-09, 2026-10-04). */
$('set-save-restart').onclick = async () => {
  const r = await saveSettings();
  if (!r || !(r.restart || PENDING > 0)) return;
  if (!confirm('Saved. Restart the service now to apply the settings?\n\n' +
               'A transaction in progress finishes first.')) return;
  restartService({ confirmed: true });
};
$('vw-close').onclick = closeViewer;
$('dr-close').onclick = () => Drawer.close();
$('drawer-scrim').onclick = () => Drawer.close();
/* Esc closes the top-most thing: the screenshot viewer, the setup
 * assistant, an open Columns menu, then the details panel — and the
 * focus goes back to what opened it. */
document.onkeydown = e => {
  if (e.key !== 'Escape') return;
  if (!$('idle-box').classList.contains('hide')) return $('idle-stay').click();
  if (!$('viewer').classList.contains('hide')) return closeViewer();
  if (!$('wizard').classList.contains('hide')) return closeWizard();
  const pick = document.querySelector('details.colpick[open]');
  if (pick) {
    pick.open = false;
    const sum = pick.querySelector('summary');
    if (sum) sum.focus();
    return;
  }
  if (Drawer.isOpen()) Drawer.close();
};
document.querySelectorAll('nav button[data-view]').forEach(b => {
  b.onclick = () => switchView(b.dataset.view);
});

boot();
