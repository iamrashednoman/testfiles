"""Secrets for the installed desktop app — the OS credential vault.

An installed app has no deployment pipeline to inject environment
variables, and writing passwords to a file is what the whole design
avoids. So the secrets that exist BEFORE the database is open — the
database password itself, the mainframe service account, the machine
API keys, the console signing key, the SMTP password — live in the
operating system's own store:

    Windows   Credential Manager (DPAPI, per user)
    macOS     Keychain
    Linux     Secret Service (libsecret)

through the `keyring` package (already the worker's dev-only credential
backend). The agent copies them into its OWN process environment before
configuration is read (load_secrets_into_env), so every existing
consumer — pydantic settings, CredentialManager, the notification
stack, the API-key loader — works unchanged and never learns where the
value came from. A value already present in the environment always
wins, so a server deployment that sets variables the usual way is
unaffected.

The vault is write-only from the API: callers learn whether a secret
is SET, never what it is. `run.py` and Docker never import this module.
"""
from __future__ import annotations

import os
import sys
from urllib.parse import urlsplit, urlunsplit

SERVICE_NAME = "FINESIII-RPA"

# Environment variable → label. The ONLY names the vault will store; a
# request for anything else is refused, so the vault cannot be used as
# a general key/value store.
SECRET_KEYS: dict[str, str] = {
    "DATABASE_PASSWORD": "Database password",
    "AUDIT_DATABASE_PASSWORD": "Audit database password",
    "FINESIII_AFFILIATION_CODE": "Service account — affiliation code",
    "FINESIII_APPLICATION_ID": "Service account — staff code",
    "FINESIII_PASSWORD": "Service account — password",
    "FINESIII_API_KEYS": "Machine API keys (ServiceNow connector, CLI)",
    "JWT_SECRET": "Console session signing key",
    "SMTP_PASSWORD": "SMTP password",
    "SNOW_PASSWORD": "ServiceNow — bot account password",
    "SNOW_CLIENT_SECRET": "ServiceNow — OAuth client secret",
    "CYBERARK_PVWA_PASSWORD": "CyberArk — PVWA service account password",
    # Install-time only: the seeded administrator's provisional password
    # (config auth_default_admin_password). Forced change at first
    # sign-in, so its value grants nothing afterwards.
    "AUTH_DEFAULT_ADMIN_PASSWORD": "Initial administrator password",
}

# ── Installer hand-off (Windows) ──
# The MSI runs as an administrator; the agent runs as the BOT account,
# whose Credential Manager is a different store. So the installer leaves
# the secrets in this file — encrypted with machine-scope DPAPI, in the
# shared data directory — and the agent, on its first start as the bot
# account, imports them into its own vault and deletes the file.
BOOTSTRAP_FILE = "bootstrap-secrets.bin"


class VaultUnavailableError(RuntimeError):
    """No usable OS credential store on this machine."""


class MemoryVault:
    """In-process store — tests, and nothing else."""

    name = "memory"
    available = True

    def __init__(self):
        self._data: dict[str, str] = {}

    def get(self, key: str) -> str | None:
        return self._data.get(key)

    def set(self, key: str, value: str) -> None:
        self._data[key] = value

    def delete(self, key: str) -> None:
        self._data.pop(key, None)


class KeyringVault:
    """The OS store via `keyring`. `available` is False when the package
    is missing or only its fail/null backend is present (a headless
    Linux box without Secret Service) — callers must then refuse to
    store secrets rather than fall back to plaintext."""

    name = "keyring"

    def __init__(self):
        self._kr = None
        self.error = ""
        try:
            import keyring
            from keyring.backends import fail, null
            backend = keyring.get_keyring()
            if isinstance(backend, (fail.Keyring, null.Keyring)):
                self.error = (f"no OS credential store is available "
                              f"(keyring backend: {type(backend).__name__})")
            else:
                self._kr = keyring
                self.backend = type(backend).__name__
        except Exception as e:          # ImportError, backend init errors
            self.error = f"keyring is not usable: {e}"

    @property
    def available(self) -> bool:
        return self._kr is not None

    def _require(self):
        if self._kr is None:
            raise VaultUnavailableError(self.error)
        return self._kr

    def get(self, key: str) -> str | None:
        try:
            return self._require().get_password(SERVICE_NAME, key)
        except VaultUnavailableError:
            raise
        except Exception as e:
            raise VaultUnavailableError(f"vault read failed: {e}") from e

    def set(self, key: str, value: str) -> None:
        try:
            self._require().set_password(SERVICE_NAME, key, value)
        except VaultUnavailableError:
            raise
        except Exception as e:
            raise VaultUnavailableError(f"vault write failed: {e}") from e

    def delete(self, key: str) -> None:
        kr = self._require()
        try:
            kr.delete_password(SERVICE_NAME, key)
        except Exception as e:
            # keyring raises PasswordDeleteError for a missing entry.
            if "not found" not in str(e).lower() and \
                    type(e).__name__ != "PasswordDeleteError":
                raise VaultUnavailableError(
                    f"vault delete failed: {e}") from e


_vault = None


def vault():
    """The process-wide vault, created on first use."""
    global _vault
    if _vault is None:
        _vault = KeyringVault()
    return _vault


def use_vault(v) -> None:
    """Swap the backing store (tests use MemoryVault)."""
    global _vault
    _vault = v


# Values this process put into os.environ from the vault (load or set),
# so status() can tell a stored credential from a real environment
# variable.
_FROM_VAULT: dict[str, str] = {}


def check_key(key: str) -> str:
    if key not in SECRET_KEYS:
        raise KeyError(f"'{key}' is not a vault-managed secret")
    return key


# ── Into the process environment ──

def load_secrets_into_env(logger=None) -> list[str]:
    """Copy every stored secret whose variable is NOT already set into
    os.environ. Returns the names loaded. Never raises: an unavailable
    vault is reported and the process runs on whatever the environment
    provides — exactly today's behaviour."""
    v = vault()
    if not getattr(v, "available", False):
        if logger:
            logger.warning(
                f"Credential vault unavailable — running on environment "
                f"variables only ({getattr(v, 'error', '')})")
        return []
    loaded = []
    for key in SECRET_KEYS:
        if os.environ.get(key):
            continue
        try:
            value = v.get(key)
        except VaultUnavailableError as e:
            if logger:
                logger.warning(f"Vault read failed for {key}: {e}")
            continue
        if value:
            os.environ[key] = value
            _FROM_VAULT[key] = value
            loaded.append(key)
    if loaded and logger:
        logger.info(f"Loaded {len(loaded)} secret(s) from the "
                    f"{v.name} vault: {', '.join(loaded)}")
    return loaded


# Values replaced or removed while this process runs: they can still
# be in the log written before, so the log view keeps masking them
# (UAT-L22, 2026-10-04). Kept in memory only, never written anywhere.
_RETIRED: set = set()
_RETIRED_LIMIT = 200


def _retire(key: str) -> None:
    old = os.environ.get(key, "") or ""
    parts = [p.split(":", 1)[-1] for p in old.split(",")] \
        if key == "FINESIII_API_KEYS" else [old]
    for part in parts:
        part = part.strip()
        if part and len(_RETIRED) < _RETIRED_LIMIT:
            _RETIRED.add(part)


def retired_values() -> set:
    """Earlier values of the secrets, for masking."""
    return set(_RETIRED)


def set_secret(key: str, value: str) -> None:
    """Store AND apply immediately (os.environ), so a restart — which
    re-reads configuration in this same process — picks it up."""
    check_key(key)
    vault().set(key, value)
    if os.environ.get(key, "") != value:
        _retire(key)
    os.environ[key] = value
    _FROM_VAULT[key] = value


def delete_secret(key: str) -> None:
    check_key(key)
    vault().delete(key)
    _retire(key)
    os.environ.pop(key, None)
    _FROM_VAULT.pop(key, None)


def migrate_legacy_setting_secrets(store, logger=None) -> list[str]:
    """Move secrets an earlier version kept in the console settings
    table into the credential store, and delete the table rows. Returns
    the names moved. A blank row is simply deleted. Never raises: a
    failure leaves the row in place (still applied at startup) and is
    logged by name only — never the value."""
    from src.modules.console.settings_store import (
        LEGACY_SECRET_ENV, clear_env_override,
    )
    moved = []
    try:
        stored = store.all()
    except Exception:
        return moved
    for key in sorted(LEGACY_SECRET_ENV & set(stored)):
        value = str(stored.get(key) or "")
        try:
            if value.strip():
                # Undo the startup overlay first, so the environment's
                # own value is not remembered as the one to restore.
                clear_env_override(key)
                set_secret(key, value)
                moved.append(key)
            # Deleted so the text does not stay in the database file
            # (NB-019).
            if hasattr(store, "purge"):
                store.purge(key)
            else:
                store.clear(key)
        except Exception as e:
            if logger:
                logger.warning(f"Could not move {key} from the settings "
                               f"table to the credential store: "
                               f"{type(e).__name__}")
    if moved and logger:
        logger.info(f"Moved {', '.join(moved)} from the settings table to "
                    f"the credential store")
    return moved


def _from_settings_table(key: str) -> bool:
    """True when the value in force for `key` is a legacy row of the
    console settings table, applied at startup (NB-020)."""
    try:
        from src.modules.console.settings_store import (
            LEGACY_SECRET_ENV, env_before_override,
        )
    except Exception:
        return False
    return key in LEGACY_SECRET_ENV and env_before_override(key)[0]


def status() -> dict:
    """{name: {label, set, source}} — never the value. "vault" when the
    value in force is the one this process took from the credential
    store; "settings_table" when it is a row an earlier version kept in
    the settings table; "environment" when something else set it."""
    v = vault()
    out = {}
    for key, label in SECRET_KEYS.items():
        source = ""
        current = os.environ.get(key)
        if current:
            source = ("vault" if _FROM_VAULT.get(key) == current
                      else "settings_table" if _from_settings_table(key)
                      else "environment")
        elif getattr(v, "available", False):
            try:
                if v.get(key):
                    source = "vault"
            except VaultUnavailableError:
                pass
        out[key] = {"label": label, "set": bool(source), "source": source}
    return out


def store_account() -> str:
    """The account whose credential store this process uses: Windows
    keeps one store per account, so it is the account the service runs
    as (SEC-03, 2026-10-04). DOMAIN\\user on Windows."""
    try:
        from src.modules.auth.services import current_windows_account
        account = current_windows_account()
        if account:
            return account
    except Exception:
        pass
    try:
        import getpass
        return getpass.getuser()
    except Exception:
        return ""


def vault_info() -> dict:
    v = vault()
    return {"available": bool(getattr(v, "available", False)),
            "backend": getattr(v, "backend", getattr(v, "name", "")),
            "error": getattr(v, "error", ""),
            "account": store_account()}


# ── Installer hand-off file ──

def _protect(data: bytes) -> bytes:
    """Machine-scope DPAPI on Windows: any account ON THIS MACHINE can
    decrypt, no account on another machine can. Elsewhere the file is
    plain (installer and agent are the same user there, and the file
    lives only until the first agent start)."""
    if sys.platform == "win32":
        import win32crypt
        CRYPTPROTECT_LOCAL_MACHINE = 0x4
        return win32crypt.CryptProtectData(
            data, "FINESIII-RPA bootstrap", None, None, None,
            CRYPTPROTECT_LOCAL_MACHINE)
    return data


def _unprotect(blob: bytes) -> bytes:
    if sys.platform == "win32":
        import win32crypt
        return win32crypt.CryptUnprotectData(blob, None, None, None, 0)[1]
    return blob


def bootstrap_path():
    from src.core.app_paths import data_path
    return data_path(BOOTSTRAP_FILE)


def write_bootstrap_secrets(secrets: dict[str, str]) -> None:
    """Installer side. Only vault-managed names are accepted."""
    import json
    payload = {check_key(k): str(v) for k, v in secrets.items() if v}
    if not payload:
        return
    path = bootstrap_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(_protect(json.dumps(payload).encode("utf-8")))
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass


def import_bootstrap_secrets(logger=None) -> list[str]:
    """Agent side, before load_secrets_into_env(): move the installer's
    secrets into THIS user's vault and remove the file. Returns the
    names imported. Never raises — a failure leaves the file for the
    next start and is logged."""
    import json
    path = bootstrap_path()
    if not path.is_file():
        return []
    v = vault()
    if not getattr(v, "available", False):
        if logger:
            logger.warning("Installer secrets found but no credential "
                           "vault is available — leaving them in place")
        return []
    try:
        payload = json.loads(_unprotect(path.read_bytes()).decode("utf-8"))
        imported = []
        for key, value in payload.items():
            if key in SECRET_KEYS and value:
                v.set(key, value)
                imported.append(key)
        path.unlink()
        if logger:
            logger.info(f"Imported {len(imported)} installer secret(s) "
                        f"into the {v.name} vault: {', '.join(imported)}")
        return imported
    except Exception as e:
        if logger:
            logger.error(f"Could not import installer secrets: {e}")
        return []


# ── URL helpers ──

def strip_url_password(url: str) -> str:
    """postgresql://user:pw@host/db → postgresql://user@host/db. What is
    stored in finesiii.env and shown in the console."""
    if not url:
        return url
    parts = urlsplit(url)
    if parts.password is None:
        return url
    host = parts.hostname or ""
    if ":" in host and not host.startswith("["):
        host = f"[{host}]"
    netloc = f"{parts.username}@{host}" if parts.username else host
    if parts.port is not None:
        netloc += f":{parts.port}"
    return urlunsplit((parts.scheme, netloc, parts.path, parts.query,
                       parts.fragment))


def mask_url(url: str) -> str:
    """A URL safe for the audit trail and the logs, even when it cannot
    be read (NB-002): an un-encoded '#', '?' or '/' in the password
    moves part of it out of the address, where strip_url_password would
    leave it in clear. Then everything between '://' and the last '@'
    is masked instead."""
    if not url:
        return url
    text = str(url)
    try:
        parts = urlsplit(text)
        parts.port                          # raises on a non-numeric port
        rest = text.split("://", 1)[1] if "://" in text else ""
        if not parts.fragment and not ("@" in rest
                                       and "@" not in parts.netloc):
            return strip_url_password(text)
    except ValueError:
        pass
    if "://" in text:
        head, rest = text.split("://", 1)
        if "@" in rest:
            return f"{head}://*****@{rest.rsplit('@', 1)[1]}"
    return text


def url_password(url: str) -> str | None:
    """The password embedded in a URL, decoded, or None."""
    from urllib.parse import unquote
    if not url:
        return None
    pw = urlsplit(url).password
    return unquote(pw) if pw is not None else None
