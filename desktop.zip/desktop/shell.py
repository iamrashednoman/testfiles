"""The desktop window.

A native window (pywebview: WebView2 on Windows, WebKit on macOS,
WebKitGTK on Linux) showing the console UI. The UI is served BY the
service and talks to the same /api/v1 routes as any other client, so
nothing in src/ knows a window exists.

Two modes:

ATTACHED (default — the installed product). The bot runs in the
background agent (desktop/agent.py), started at logon by the OS
supervisor. The window looks the agent up (desktop/runtime.py) and
connects to it; if none is running it launches one, detached, and
connects to that. CLOSING THE WINDOW LEAVES THE BOT RUNNING — stopping
is a deliberate act (`--stop`, or the console's Stop button).

EMBEDDED (FINESIII_DESKTOP_EMBEDDED=1, or DesktopShell(embedded=True)).
The pre-agent behaviour, kept for troubleshooting and for the tests
that pin the drain: the window process hosts the service itself, and
closing the window runs the same graceful drain the service performs
on SIGTERM — a transaction in flight is a live session on the FINESIII
terminal, and tearing the process down mid-operation would leave the
mainframe in an unknown state.
"""
from __future__ import annotations

import logging
import os
import sys
import threading

from desktop import runtime
from desktop.server import EmbeddedService, mount_console_ui
from desktop.single_instance import AlreadyRunningError, SingleInstance

logger = logging.getLogger("finesiii_rpa_v3")

WINDOW_TITLE = "FINESIII RPA"
_MIN_SIZE = (900, 620)
EMBEDDED_ENV = "FINESIII_DESKTOP_EMBEDDED"


class _ShutdownRequested(Exception):
    """A signal arrived before the window was showing."""


class DesktopShell:
    def __init__(self, cfg, embedded: bool | None = None):
        self.cfg = cfg
        self.embedded = (embedded if embedded is not None
                         else os.environ.get(EMBEDDED_ENV, "") == "1")
        self.service = EmbeddedService(cfg, logger=logger)
        self.window = None
        self._closing = threading.Event()

    # ── Window callbacks ──

    def _on_closing(self) -> bool:
        """pywebview asks before the window goes away.

        Attached: always allowed — the bot is in another process and
        keeps running. Embedded: returning False keeps the window open;
        a busy service gets a confirmation, because the operator is the
        one who knows whether the transaction on screen matters.
        """
        if self._closing.is_set() or not self.embedded:
            self._closing.set()
            return True
        if not self.service.is_busy():
            self._closing.set()
            return True

        confirmed = True
        try:
            confirmed = self.window.create_confirmation_dialog(
                "Transaction in progress",
                "A transaction is currently running on the terminal.\n\n"
                "Quitting will wait for it to finish before closing — "
                "it will not be interrupted.\n\nQuit now?")
        except Exception:
            pass                    # no dialog support: allow the close
        if confirmed:
            self._closing.set()
        return bool(confirmed)

    # ── Signals ──

    def _install_signal_handlers(self) -> None:
        """Drain on SIGINT/SIGTERM as well as on window close.

        Two problems stack up here, and a plain signal.signal() handler
        solves neither:

        1. uvicorn installs handlers ONLY on the main thread ("Signals
           can only be listened to from the main thread" —
           uvicorn/server.py). It runs on a worker thread so the window
           can own the main thread, so uvicorn's handling is off.

        2. Python runs signal handlers between BYTECODES on the main
           thread — but webview.start() hands the main thread to the
           native GUI loop (Cocoa/GTK/WinForms), which executes no
           Python. A handler registered there simply never runs; this
           was verified on macOS, where the app had to be SIGKILLed.

        So the signals are BLOCKED and a dedicated thread waits for
        them with sigwait(). That thread is ordinary Python, so it runs
        immediately and can close the window, which returns the main
        thread and lets the normal drain proceed. Windows has no
        sigwait; there the classic handler is used, which is correct
        because its GUI loop does pump Python.

        CALL THIS BEFORE STARTING ANY THREAD. A signal mask is
        per-thread and is INHERITED AT CREATION: arming it after the
        uvicorn thread exists leaves that thread unmasked, SIGTERM is
        delivered there, and its default action kills the process with
        a transaction still running. Verified the hard way.
        """
        import signal

        signals = (signal.SIGINT, signal.SIGTERM)

        def shutdown(signame: str) -> None:
            if self._closing.is_set():
                return                  # already draining — let it finish
            self._closing.set()
            print(f"\n Received {signame} — finishing any transaction "
                  f"in progress, then closing…", flush=True)
            try:
                if self.window is not None:
                    self.window.destroy()   # unblocks webview.start()
            except Exception:
                pass

        if not hasattr(signal, "sigwait"):          # Windows
            for sig in signals:
                try:
                    signal.signal(
                        sig,
                        lambda s, _f: shutdown(signal.Signals(s).name))
                except (ValueError, OSError):
                    pass
            return

        try:
            signal.pthread_sigmask(signal.SIG_BLOCK, signals)
        except (ValueError, OSError):
            return

        def waiter():
            while not self._closing.is_set():
                try:
                    received = signal.sigwait(signals)
                except (ValueError, OSError):
                    return
                shutdown(signal.Signals(received).name)

        threading.Thread(target=waiter, name="finesiii-signals",
                         daemon=True).start()

    # ── Run ──

    def run(self) -> int:
        if self.embedded:
            return self._run_embedded()
        return self._run_attached()

    def _run_attached(self) -> int:
        """Connect the window to the background agent, launching one
        first if none is running. The window never owns the service."""
        import webview

        # Armed first, as in embedded mode: a signal must be able to
        # close the window even while we are still waiting for the
        # agent to come up.
        self._install_signal_handlers()

        url = runtime.find_running_agent()
        if url is None:
            print(" No background service is running — starting one…",
                  flush=True)
            try:
                proc = runtime.spawn_agent()
            except OSError as e:
                print(f"\n [FATAL] Could not start the background "
                      f"service: {e}", file=sys.stderr)
                return 1
            url = runtime.wait_for_agent(proc=proc)
            if url is None:
                print(f"\n [FATAL] The background service did not become "
                      f"ready.\n         See {runtime.agent_log_path()} "
                      f"for the startup error.", file=sys.stderr)
                return 1
        print(f" Connected — {url}", flush=True)

        if self._closing.is_set():
            return 0
        self.window = webview.create_window(
            _window_title(url), url,
            width=1180, height=760,
            min_size=_MIN_SIZE, text_select=True)
        self.window.events.closing += self._on_closing
        if self._closing.is_set():
            return 0
        webview.start()
        print(" Window closed — the FINESIII RPA service keeps running "
              "in the background.", flush=True)
        return 0

    def _run_embedded(self) -> int:
        import webview

        try:
            lock = SingleInstance(
                _lock_path()).acquire()
        except AlreadyRunningError as e:
            print(f"\n [STOP] {e}\n"
                  f"        Close the other window first.",
                  file=sys.stderr)
            return 3

        # BEFORE any thread exists — see _install_signal_handlers.
        self._install_signal_handlers()

        try:
            print(" Starting the FINESIII RPA service…", flush=True)
            url = self.service.start()
            if not self.service.wait_until_ready():
                print("\n [FATAL] The embedded service did not become "
                      "ready.\n         Run with --headless to see the "
                      "startup error.", file=sys.stderr)
                self.service.stop(drain_timeout=10)
                return 1

            self._mount_ui()
            print(f" Ready — {url}", flush=True)

            self.window = webview.create_window(
                WINDOW_TITLE, url,
                width=1180, height=760,
                min_size=_MIN_SIZE, text_select=True)
            self.window.events.closing += self._on_closing
            self._watch_for_restart()
            if self._closing.is_set():
                # A signal arrived while the service was still starting.
                raise _ShutdownRequested()

            # Blocks on the MAIN thread until the window closes —
            # required on macOS, and the convention on every backend.
            webview.start()

            return self._shutdown()
        except _ShutdownRequested:
            return self._shutdown()
        finally:
            lock.release()

    def _shutdown(self) -> int:
        print(" Shutting down…", flush=True)
        clean = self.service.stop()
        print(" Stopped." if clean
              else " Stopped (drain timed out — see the log).",
              flush=True)
        return 0 if clean else 1

    def _watch_for_restart(self) -> None:
        """Rebuild the service when the console asks for it.

        Done on a watcher thread, never inline: the HTTP request that
        asks for a restart is being served BY the server that is about
        to stop, so handling it in the request would deadlock. The
        rebuild uses EmbeddedService.stop(), which drains a transaction
        that is live on the terminal exactly as a shutdown does.
        """
        def watcher():
            while not self._closing.is_set():
                if self.service.restart_requested:
                    print(" Restarting the service to apply settings…",
                          flush=True)
                    try:
                        self.service.restart()
                        self._mount_ui()
                        if self.window is not None:
                            self.window.load_url(self.service.base_url)
                        print(" Restarted.", flush=True)
                    except Exception as e:
                        logger.error(f"Restart failed: {e}")
                self._closing.wait(1.0)

        threading.Thread(target=watcher, name="finesiii-restart",
                         daemon=True).start()

    def _mount_ui(self) -> None:
        """Embedded mode: serve the console UI from this process's app
        (shared implementation with the agent — desktop/server.py)."""
        mount_console_ui(self.service.app, logger, mode="embedded")


def _window_title(url: str) -> str:
    """The branded product name for the native window's title bar,
    from the public branding route; the default on any problem."""
    import json
    import urllib.request
    try:
        with urllib.request.urlopen(f"{url}/api/v1/console/branding",
                                    timeout=2) as r:
            name = (json.load(r).get("branding") or {}).get("product_name")
            return str(name).strip() or WINDOW_TITLE
    except Exception:
        return WINDOW_TITLE


def _lock_path():
    from src.core.app_paths import data_path
    return data_path("desktop.lock")


def run_desktop(cfg, embedded: bool | None = None) -> int:
    return DesktopShell(cfg, embedded=embedded).run()
