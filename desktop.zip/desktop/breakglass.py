"""Reset a console password from the server itself (UR-08, 2026-10-03).

The way back in when the only administrator has forgotten the password
or is locked out — before this, the only recovery was editing the
database by hand. It runs on the server, as an account that can read the
application's settings and database (the server administrator), never
through the console or the network:

    python desktop/app.py --reset-console-password <username>

The new password is typed twice without being shown (or taken from the
environment variable FINESIII_NEW_CONSOLE_PASSWORD for unattended use).
It is PROVISIONAL like every password an administrator sets: the user
must choose their own at the next sign-in. The account is unlocked and
activated, its open sessions end, and the reset is written to the
service log and, when it is switched on, the audit trail.
"""
from __future__ import annotations

import getpass
import logging
import os
import sys

PASSWORD_ENV = "FINESIII_NEW_CONSOLE_PASSWORD"


def _new_password() -> str:
    from_env = os.environ.get(PASSWORD_ENV, "")
    if from_env:
        return from_env
    if not sys.stdin.isatty():
        raise ValueError(f"no terminal to type the password in — set "
                         f"{PASSWORD_ENV} for an unattended reset")
    first = getpass.getpass(" New password (not shown): ")
    second = getpass.getpass(" The same password again: ")
    if first != second:
        raise ValueError("the two passwords are not the same")
    return first


def reset_console_password(argv: list[str]) -> int:
    """0 = reset, 1 = refused (reason printed), 2 = wrong usage."""
    if len(argv) != 1 or argv[0].startswith("-"):
        print(" Usage: --reset-console-password <username>",
              file=sys.stderr)
        return 2
    username = argv[0].strip().lower()

    from config import get_config
    from src import extensions
    from src.modules.auth.models import password_problems
    from src.modules.auth.store import UserStore

    cfg = get_config()
    log = logging.getLogger("finesiii_rpa_v3")
    db = extensions.init_extensions(cfg)
    try:
        store = UserStore(db)
        user = store.get_by_username(username)
        if user is None:
            print(f" [NG] No console account '{username}'.",
                  file=sys.stderr)
            return 1
        try:
            password = _new_password()
        except (ValueError, EOFError, KeyboardInterrupt) as e:
            print(f"\n [NG] Not reset: {e}.", file=sys.stderr)
            return 1
        problems = password_problems(
            password, int(getattr(cfg, "auth_min_password_length", 12)))
        if problems:
            print(" [NG] Not reset: the password " + "; ".join(problems)
                  + ".", file=sys.stderr)
            return 1

        user.set_password(password)
        user.must_change_password = True
        user.clear_lock()
        user.is_active = True
        store.update(user)
        ended = store.revoke_all_for_user(user.user_id)

        actor = f"server:{getpass.getuser()}"
        detail = {"username": user.username, "user_id": user.user_id,
                  "sessions_ended": ended}
        log.warning(f"Console password of '{user.username}' reset on the "
                    f"server by {actor} (break-glass)")
        _audit(cfg, log, actor, detail)
        print(f" [OK] The password of '{user.username}' was reset. Sign "
              f"in with it; a new password is asked for at once. Open "
              f"sessions ended: {ended}.")
        return 0
    finally:
        try:
            db.close()
        except Exception:
            pass


def _audit(cfg, log, actor: str, detail: dict) -> None:
    """Into the audit trail when it is switched on; never fails the
    reset itself."""
    try:
        from src.modules.audit.trail import maybe_start_audit_trail
        trail = maybe_start_audit_trail(cfg, log)
        if trail is None:
            return
        trail.event("auth", "password_reset_break_glass",
                    severity="WARNING", actor=actor, detail=detail)
        trail.close(drain_timeout=10.0)
    except Exception as e:
        log.warning(f"The break-glass reset could not be written to the "
                    f"audit trail: {e}")
