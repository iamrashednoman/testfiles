"""ServiceNow polling INSIDE the background agent (desktop only).

On a server the connector is `scripts/run_servicenow_connector.py`, a
separate process. An installed desktop app has no operator to start
scripts, so the agent runs the same connector on a supervised thread
when the console's ServiceNow page turns it on (SNOW_ENABLED).

Design points:
  • The connector is REUSED unchanged: it still submits through the
    public intake API (this agent's own URL, with the installer-issued
    machine key), so the platform sees ServiceNow exactly as before.
  • "Hot" settings: before every poll the ServiceNow overrides stored
    from the console are applied to this process's environment and the
    connector settings are rebuilt, so a change on the page takes effect
    on the next poll without a restart. Saving a ServiceNow setting also
    WAKES the poller (poll_now), so a new interval applies at once.
  • Tickets the platform already knows (any status) are skipped via
    the queue store, so a poll never resubmits queued, running, done or
    FAILED work — a failed ticket is re-run by an operator's Retry.
  • Duplicate content (2026-09-26): a ticket for the same operation,
    affiliation and employee as a request already held under another
    ticket number is skipped, audited and alerted; same requester +
    description with a different key is flagged only.
  • Evidence: every poll writes one audit event; the last poll is
    persisted to the data directory so the System page shows it after
    a restart. After FAILURE_ALERT_THRESHOLD consecutive failures an
    outage email goes out (recovery email when polling works again).
  • Isolation: a ServiceNow outage, a bad setting or a bug in a poll
    is recorded and retried after a back-off; it never touches the
    dispatcher, `stop()` returns promptly, and the agent restarts the
    thread if it ever dies (ensure_running).
"""
from __future__ import annotations

import json
import os
import threading
import time
from datetime import datetime, timedelta

from desktop import runtime
from src.integrations.servicenow.config import ServiceNowConfigError
# Ticket creation-time helpers; shared with the check just before
# execution (NB-001).
from src.integrations.servicenow.duplicates import (
    request_created_on as _req_created, ticket_created_on as _created,
)

STATE_FILE = "servicenow-poller.json"


def _later(a, b) -> bool:
    """Was request `a`'s ticket created after request `b`'s? By ticket
    creation time when both carry it, else by queue time."""
    ca, cb = _req_created(a), _req_created(b)
    if ca and cb:
        return ca > cb
    return str(a.enqueued_at) > str(b.enqueued_at)


def _first_api_key() -> str:
    """The machine key the connector presents to our own API: the first
    entry of FINESIII_API_KEYS ("client:key,...")."""
    raw = os.environ.get("FINESIII_API_KEYS", "")
    for entry in raw.split(","):
        entry = entry.strip()
        if entry:
            return entry.split(":", 1)[1].strip() if ":" in entry else entry
    return ""


class ServiceNowPoller:
    ERROR_BACKOFF_SECONDS = 60.0
    DISABLED_CHECK_SECONDS = 5.0
    FAILURE_ALERT_THRESHOLD = 3

    def __init__(self, app, base_url: str, logger=None):
        self.app = app
        self.base_url = base_url.rstrip("/")
        self.logger = logger
        self._stop = threading.Event()
        self._wake = threading.Event()
        self._thread: threading.Thread | None = None
        self._lock = threading.Lock()
        self.last_poll_at = ""
        # When ServiceNow last answered a poll (SN-03, 2026-10-03).
        self.last_success_at = ""
        self.last_stats: dict = {}
        self.last_error = ""
        self.consecutive_errors = 0
        self.not_configured = False
        self.polls = 0
        self.restarts = 0
        self._next_poll_at = 0.0
        self._alerted_down = False
        self._notified: dict = {}       # ticket number -> fingerprint (SN-03)
        # Sign-in rejected several times in a row: polling waits for a
        # new password or "Check ServiceNow now", so the bot account is
        # not locked by the same rejected password (E2E-M10).
        self.auth_held = False
        self._auth_rejections = 0
        self._load_state()

    # ── lifecycle ──

    def start(self) -> None:
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop,
                                        name="finesiii-snow-poller",
                                        daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        self._wake.set()
        if self._thread is not None:
            self._thread.join(timeout=10)

    def poll_now(self) -> None:
        """Wake the loop: used by the console's Poll now button and after
        a ServiceNow setting is saved, so the change applies at once."""
        self._wake.set()

    def ensure_running(self) -> bool:
        """Restart the thread if it died. Returns True when it did."""
        if self._stop.is_set():
            return False
        if self._thread is not None and self._thread.is_alive():
            return False
        self.restarts += 1
        if self.logger:
            self.logger.error("ServiceNow poller thread was not running — "
                              "restarting it")
        self.start()
        return True

    # ── settings ──

    @staticmethod
    def enabled() -> bool:
        return os.environ.get("SNOW_ENABLED", "").strip().lower() in (
            "1", "true", "yes", "on")

    def _apply_hot_overrides(self) -> None:
        """Console-stored ServiceNow settings → this process's env, so a
        page change is live on the next poll (the restart-scoped keys
        are left to apply_overrides at rebuild)."""
        store = getattr(self.app.state, "settings_store", None)
        if store is None:
            return
        # Stored values applied AND cleared ones restored (2026-09-28:
        # a cleared setting used to stay in force until a full restart).
        from src.modules.console.settings_store import apply_hot_env
        try:
            apply_hot_env(store)
        except Exception:
            return

    def _build_connector(self, read_only: bool = False):
        """The connector with the platform's hooks. read_only=True (the
        console's ticket preview, 2026-09-29): nothing is written — a
        known ticket's missing ticket update is not delivered here."""
        from src.integrations.servicenow.config import load_servicenow_config
        from src.integrations.servicenow.connector import ServiceNowConnector
        from src.integrations.servicenow import duplicates
        from src.integrations.servicenow.sailpoint import parent_of

        settings = load_servicenow_config()
        settings.service_base_url = self.base_url
        settings.service_token = _first_api_key()
        # /health needs the API key; /ping is the credential-free probe.
        settings.health_path = "/api/v1/ping"
        settings.validate()

        # Unmappable tickets and duplicates → the same rejection email
        # the intake API sends (was missing in the agent before).
        rejection = getattr(self.app.state, "rejection_alerter", None)
        connector = ServiceNowConnector(
            settings, logger=self.logger,
            on_rejected=(rejection.request_rejected
                         if rejection is not None else None))
        connector.audit_hook = self._audit_event
        # One report per stuck ticket; survives restarts (state file).
        from src.integrations.servicenow.connector import ReportMemory
        connector.reported = ReportMemory(self._notified)

        queue_store = getattr(self.app.state, "queue_store", None)
        if queue_store is not None:
            closeout = getattr(self.app.state, "ticket_closeout", None)

            def known_ticket(number):
                requests = queue_store.find_ticket_requests(number)
                if not requests:
                    return False
                # A ticket with several codes is known only when every
                # code's request exists; otherwise the missing ones are
                # submitted again (the existing ones answer 409).
                meta = requests[0].metadata if isinstance(
                    requests[0].metadata, dict) else {}
                parts = int(meta.get("parts", 1) or 1)
                if parts > 1 and len(requests) < parts:
                    return False
                # The ticket is still open although the platform knows
                # it: if its requests have finished, make sure the ticket
                # was told (lost or failed write-backs are delivered
                # here; delivered ones are skipped).
                if closeout is not None and not read_only:
                    closeout.reconcile(requests[-1])
                return True

            connector.known_ticket = known_ticket
            window = int(settings.duplicate_window_days or 0)
            # Queue timestamps are JST; compare like with like (SN-12).
            from src.modules.intake.models import (
                DUPLICATE_BLOCKING_STATUSES, now_jst,
            )
            since = ((now_jst() - timedelta(days=window)).isoformat()
                     if window > 0 else "")
            # The same-request (content) check follows the window; 0 turns
            # it off. The tracking-ID and newer-ticket rules protect access
            # already granted or removed, so they always apply and look
            # back over all time (2026-09-28).
            content_since = since if window > 0 else None
            rule_since = ""
            user_email_field = (settings.field_mapping or {}).get(
                "user_email", "")

            def duplicate_of(payload, ticket):
                number = payload.get("ticket_id", "")
                # Same SailPoint tracking ID on another task that is
                # queued, running or done (2026-09-28).
                tracking = str((payload.get("metadata") or {}).get(
                    "tracking_id", "") or "")
                if tracking:
                    for req in queue_store.list_recent_by_source(
                            "servicenow", since=rule_since):
                        meta = req.metadata if isinstance(
                            req.metadata, dict) else {}
                        # The other codes of the SAME ticket share
                        # its tracking ID — they are not a repeat.
                        if parent_of(req.ticket_id) != parent_of(number) \
                                and meta.get("tracking_id") == tracking \
                                and req.status in DUPLICATE_BLOCKING_STATUSES:
                            return {"request_id": req.request_id,
                                    "ticket_id": req.ticket_id,
                                    "status": req.status,
                                    "matched_fields": ["tracking_id"],
                                    "reason": f"same access request ID "
                                              f"{tracking}"}
                op, aff, emp = duplicates.business_key(payload)
                hit = (queue_store.find_content_duplicate(
                    op, aff, emp, exclude_ticket_id=number,
                    since=content_since)
                    if content_since is not None else None)
                opposite = queue_store.find_content_duplicate(
                    "deprovision" if op == "provision" else "provision",
                    aff, emp, exclude_ticket_id=number, since=rule_since)
                # Order is when ServiceNow CREATED the tickets, not
                # when the bot saw them (2026-09-28).
                mine = _created(ticket)
                newer = (opposite is not None and bool(mine)
                         and _req_created(opposite) > mine)
                if hit is not None:
                    # Latest action wins: an opposite operation after
                    # the match (Add → Remove → Add) makes this new
                    # work — unless that opposite ticket is NEWER than
                    # this one (then this ticket is stale).
                    if opposite is not None and not newer and \
                            _later(opposite, hit):
                        return None
                    details = (hit.metadata or {}).get("snow_details") \
                        if isinstance(hit.metadata, dict) else None
                    return {"request_id": hit.request_id,
                            "ticket_id": hit.ticket_id,
                            "status": hit.status,
                            "matched_fields": duplicates.matched_fields(
                                details, ticket)}
                if newer:
                    # Never undo a NEWER ticket: e.g. a certification
                    # revoke raised before an Add that already ran.
                    return {"request_id": opposite.request_id,
                            "ticket_id": opposite.ticket_id,
                            "status": opposite.status,
                            "matched_fields": [], "superseded": True,
                            "reason": (f"a newer ticket "
                                       f"{opposite.ticket_id} "
                                       f"({opposite.operation}) for the "
                                       f"same account and affiliation "
                                       f"code was received after this "
                                       f"one; this older ticket is not "
                                       f"executed")}
                return None

            def possible_duplicate_of(payload, ticket):
                for req in queue_store.list_recent_by_source(
                        "servicenow", since=since):
                    if req.ticket_id == payload.get("ticket_id", ""):
                        continue
                    details = (req.metadata or {}).get("snow_details") \
                        if isinstance(req.metadata, dict) else None
                    if duplicates.is_possible_duplicate(
                            details, ticket, user_email_field):
                        return {"request_id": req.request_id,
                                "ticket_id": req.ticket_id,
                                "status": req.status,
                                "matched_fields":
                                    duplicates.matched_fields(details, ticket)}
                return None

            connector.duplicate_of = duplicate_of
            if window > 0:
                connector.possible_duplicate_of = possible_duplicate_of
        return connector, settings

    # A preview answers in seconds, not minutes (SN-11, 2026-10-03): no
    # retries, a short time-out and the first tickets only.
    PREVIEW_TIMEOUT_SECONDS = 15.0
    PREVIEW_MAX_TICKETS = 50

    def preview(self) -> dict:
        """What the next poll WOULD do with each open ticket; nothing is
        claimed, noted, e-mailed or remembered (2026-09-29, T3)."""
        self._apply_hot_overrides()
        connector, settings = self._build_connector(read_only=True)
        # The client holds this same settings object.
        settings.max_retries = 0
        settings.http_timeout_seconds = min(
            float(settings.http_timeout_seconds or 30),
            self.PREVIEW_TIMEOUT_SECONDS)
        settings.fetch_ceiling = min(int(settings.fetch_ceiling or 1000),
                                     self.PREVIEW_MAX_TICKETS)
        stats = connector.poll_once(dry_run=True)
        tickets = stats.get("tickets", [])
        summary = {}
        for t in tickets:
            action = t.get("action", "")
            summary[action] = summary.get(action, 0) + 1
        return {"query": settings.build_query(),
                "filters": settings.filter_summary(),
                "polling_enabled": self.enabled(),
                "fetched": stats.get("fetched", 0),
                "summary": summary,
                "error": stats.get("error_detail", ""),
                "tickets": tickets}

    # ── loop ──

    def _loop(self) -> None:
        while not self._stop.is_set():
            try:
                self._apply_hot_overrides()
                if not self.enabled():
                    self._next_poll_at = 0.0
                    self._wake.wait(self.DISABLED_CHECK_SECONDS)
                    self._wake.clear()
                    continue
                if self.auth_held:
                    # Released by a saved ServiceNow setting or secret,
                    # or by "Check ServiceNow now" (both wake the loop).
                    self._next_poll_at = 0.0
                    if self._wake.wait(self.DISABLED_CHECK_SECONDS):
                        self.auth_held = False
                        self._save_state()
                    self._wake.clear()
                    continue
                interval = self._poll_once()
            except Exception as e:      # belt and braces: the loop never dies
                if self.logger:
                    self.logger.error(f"ServiceNow poller loop error: {e}")
                interval = self.ERROR_BACKOFF_SECONDS
            self._next_poll_at = time.time() + interval
            self._wake.wait(interval)
            self._wake.clear()

    def _retry_in(self, interval: float) -> float:
        """After a failed poll: 1, 2, 4, 8, 16, 32 minutes, never longer
        than the poll interval (SN-03, 2026-10-03). The outage e-mail
        (third failure) then follows within minutes, not 1-1.5 hours."""
        n = max(1, self.consecutive_errors)
        return min(float(interval),
                   self.ERROR_BACKOFF_SECONDS * (2 ** min(n - 1, 5)))

    def _poll_once(self) -> float:
        """One cycle; returns the seconds to wait before the next."""
        interval = 1800.0
        try:
            connector, settings = self._build_connector()
            interval = float(settings.poll_interval_seconds)
            stats = connector.poll_once()
            if connector.reported is not None:
                self._notified = dict(connector.reported.data)
            # Only ServiceNow not answering is an outage (SN-03): an
            # error on a single ticket is reported but does not count
            # toward the outage e-mail, and our own service being
            # unavailable is not a ServiceNow outage.
            outage = bool(stats.pop("fetch_failed", False))
            failed = bool(stats.get("errors") or stats.get("service_unavailable"))
            # The raw error text is in the log; the page and the outage
            # e-mail get the reason in plain words (2026-09-28).
            from src.integrations.servicenow.client import explain_error
            reason = self._auth_check(
                explain_error(stats.pop("error_detail", "")), outage)
            error = ("RPA service unavailable" if stats.get("service_unavailable")
                     else (reason or f"{stats.get('errors')} error(s) in the "
                                     f"last poll")
                     if failed else "")
            skipped = bool(stats.get("service_unavailable"))
            self._record(stats, error, outage=outage,
                         answered=not outage and not skipped,
                         neutral=skipped)
            return self._retry_in(interval) if outage else interval
        except ServiceNowConfigError as e:
            # A setting missing or not valid on this machine (a password
            # not stored yet, for example) is not ServiceNow failing:
            # no outage count, no back-off, no "ServiceNow down" e-mail
            # (UAT-10, 2026-10-04). Checked again every minute, and at
            # once when a setting or the password is saved.
            self._record({}, "Not configured: " + e.plain(),
                         neutral=True, not_configured=True)
            if self.logger:
                self.logger.warning(f"ServiceNow polling not configured: "
                                    f"{e.plain()}")
            return self.ERROR_BACKOFF_SECONDS
        except Exception as e:
            from src.integrations.servicenow.client import explain_error
            # The reason in plain words, without the internal error type
            # (UAT-L05, 2026-10-04); the type stays in the log.
            self._record({}, self._auth_check(
                explain_error(e) or str(e) or type(e).__name__, True),
                outage=True)
            if self.logger:
                self.logger.error(f"ServiceNow poll failed: "
                                  f"{type(e).__name__}: {e}")
            return self._retry_in(interval)

    def _auth_check(self, reason: str, outage: bool) -> str:
        """Count sign-in rejections in a row (not a 403 on a ticket, not
        a network error); from the third one polling is held until the
        password is saved again or a check is asked for (E2E-M10)."""
        rejected = bool(outage) and str(reason or "").startswith(
            "sign-in rejected") and "HTTP 403" not in str(reason)
        self._auth_rejections = self._auth_rejections + 1 if rejected else 0
        if rejected and self._auth_rejections >= self.FAILURE_ALERT_THRESHOLD:
            self.auth_held = True
            return (f"{reason} — polling paused until the ServiceNow password "
                    f"(or client secret) is saved again or 'Check ServiceNow "
                    f"now' is pressed")
        return reason

    def _record(self, stats: dict, error: str, outage: bool | None = None,
                answered: bool = False, neutral: bool = False,
                not_configured: bool = False) -> None:
        """outage: ServiceNow did not answer (counts toward the outage
        e-mail); None = any error counts (earlier callers). answered:
        ServiceNow answered this poll (the "last successful check").
        neutral: ServiceNow was not contacted (our own service was
        unavailable) — the outage count and its e-mails are unchanged."""
        if outage is None:
            outage = bool(error)
        with self._lock:
            # JST like every time the console shows (E2E-L03).
            from src.modules.intake.models import now_jst
            now = now_jst().isoformat(timespec="seconds")
            self.last_poll_at = now
            if answered:
                self.last_success_at = now
            self.last_stats = dict(stats)
            self.not_configured = not_configured
            self.polls += 1
            if neutral:
                pass
            elif outage:
                self.consecutive_errors += 1
            else:
                self.consecutive_errors = 0
            repeated = bool(error) and error == self.last_error
            self.last_error = error
            errors = self.consecutive_errors
        self._save_state()
        detail = {k: v for k, v in stats.items() if v not in (0, False, None)}
        if error:
            detail["error"] = error
        # The same failure again is not written again: a configuration
        # error used to add an audit event every minute (SN-03).
        if not repeated:
            self._audit_event(
                "servicenow_poll_failed" if error else "servicenow_polled",
                detail, severity="WARNING" if error else "INFO")
        if not neutral:
            self._alerts(errors, error if outage else "")

    def _alerts(self, consecutive: int, error: str) -> None:
        alerter = getattr(self.app.state, "availability_alerter", None)
        if alerter is None:
            return
        try:
            from src.modules.notifications.availability_alerts import (
                COMPONENT_SERVICENOW,
            )
            # The outage counts as notified only when the notice was
            # sent; one held back by the re-alert floor is tried again on
            # the next failed poll, and a Recovered notice follows only a
            # notified outage (NB-011). False = suppressed.
            if error and consecutive >= self.FAILURE_ALERT_THRESHOLD \
                    and not self._alerted_down:
                if alerter.component_down(
                        COMPONENT_SERVICENOW,
                        f"{consecutive} consecutive polling failures — "
                        f"last: {error}") is not False:
                    self._alerted_down = True
                    self._save_state()
            elif not error and self._alerted_down:
                if alerter.component_recovered(
                        COMPONENT_SERVICENOW) is not False:
                    self._alerted_down = False
                    self._save_state()
        except Exception as e:
            if self.logger:
                self.logger.warning(f"ServiceNow polling alert failed: {e}")

    # ── evidence ──

    def _audit_event(self, action: str, detail: dict,
                     severity: str = "INFO") -> None:
        audit = getattr(self.app.state, "audit", None)
        if audit is None:
            return
        if severity == "INFO" and action.endswith("_failed"):
            severity = "WARNING"        # a failure is never "Information" (E2E-M11)
        try:
            audit.event("servicenow", action, severity=severity,
                        detail=dict(detail or {}))
        except Exception:
            pass

    def _state_path(self):
        try:
            return runtime.data_path(STATE_FILE)
        except Exception:
            return None

    def _save_state(self) -> None:
        path = self._state_path()
        if path is None:
            return
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps({
                "last_poll_at": self.last_poll_at,
                "last_success_at": self.last_success_at,
                "last_stats": self.last_stats,
                "last_error": self.last_error,
                "consecutive_errors": self.consecutive_errors,
                "notified": self._notified,
                # An outage e-mail already sent survives a restart, so
                # it is not sent again (2026-09-28).
                "alerted_down": self._alerted_down,
                # A held poll stays held after a restart (E2E-M10).
                "auth_held": self.auth_held,
                "auth_rejections": self._auth_rejections,
            }), encoding="utf-8")
        except OSError:
            pass

    def _load_state(self) -> None:
        path = self._state_path()
        if path is None or not path.is_file():
            return
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            self.last_poll_at = str(data.get("last_poll_at", "") or "")
            self.last_success_at = str(data.get("last_success_at", "") or "")
            self.last_stats = dict(data.get("last_stats", {}) or {})
            self.last_error = str(data.get("last_error", "") or "")
            self.consecutive_errors = int(data.get("consecutive_errors", 0) or 0)
            notified = data.get("notified", {})
            self._notified = dict(notified) if isinstance(notified, dict) else {}
            self._alerted_down = bool(data.get("alerted_down", False))
            self.auth_held = bool(data.get("auth_held", False))
            self._auth_rejections = int(data.get("auth_rejections", 0) or 0)
        except (OSError, ValueError, TypeError):
            pass

    # ── introspection ──

    def status(self) -> dict:
        with self._lock:
            return {
                "enabled": self.enabled(),
                "running": self._thread is not None and self._thread.is_alive(),
                "last_poll_at": self.last_poll_at,
                "last_success_at": self.last_success_at,
                "last_stats": dict(self.last_stats),
                "last_error": self.last_error,
                "consecutive_errors": self.consecutive_errors,
                # Paused after repeated sign-in rejections (E2E-M10).
                "auth_held": bool(self.auth_held),
                # The settings on this machine are incomplete (UAT-10):
                # shown as "Not configured", not as an outage.
                "not_configured": bool(getattr(self, "not_configured", False)),
                "polls": self.polls,
                "restarts": self.restarts,
                "next_poll_in_seconds": max(
                    0, int(self._next_poll_at - time.time()))
                if self.enabled() and self._next_poll_at else None,
                "instance_url": os.environ.get("SNOW_INSTANCE_URL", ""),
                "auth_method": os.environ.get("SNOW_AUTH_METHOD", "basic") or "basic",
                "poll_seconds": os.environ.get("SNOW_POLL_SECONDS", ""),
                # Ticket updates still to be written to ServiceNow (SN-02).
                "ticket_updates": self._pending_updates(),
            }

    def _pending_updates(self) -> dict:
        """{"pending": n, "given_up": m}; {} when it cannot be read."""
        store = getattr(self.app.state, "queue_store", None)
        if store is None or not hasattr(store, "writeback_backlog"):
            return {}
        try:
            from src.integrations.servicenow.writeback import TicketCloseout
            return store.writeback_backlog(TicketCloseout.MAX_ROUNDS)
        except Exception:
            return {}
