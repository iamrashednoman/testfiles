"""Single-instance guard.

Two copies of the desktop app against one database would mean two
dispatchers claiming work — and the platform's whole concurrency model
is max_concurrent_sessions=1, because the FINESIII terminal is a single
interactive session. A second instance must be refused, not tolerated.

Implemented with an OS advisory lock held open for the process's life,
rather than a PID file: the kernel releases it automatically if the app
crashes or is killed, so there is no stale-lock recovery to get wrong.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path


class AlreadyRunningError(Exception):
    """Another instance of the desktop app holds the lock."""


class SingleInstance:
    def __init__(self, lock_path: Path):
        self.lock_path = Path(lock_path)
        self._fd = None

    def acquire(self) -> "SingleInstance":
        self.lock_path.parent.mkdir(parents=True, exist_ok=True)
        # Opened, never truncated: the PID inside is only for humans
        # reading the file, the LOCK is what actually guards.
        self._fd = os.open(str(self.lock_path),
                           os.O_RDWR | os.O_CREAT, 0o600)
        try:
            self._lock()
        except OSError:
            os.close(self._fd)
            self._fd = None
            raise AlreadyRunningError(
                f"Another FINESIII RPA desktop instance is already "
                f"running (lock: {self.lock_path})")
        os.ftruncate(self._fd, 0)
        os.write(self._fd, str(os.getpid()).encode())
        return self

    def _lock(self) -> None:
        if sys.platform == "win32":
            import msvcrt
            msvcrt.locking(self._fd, msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(self._fd, fcntl.LOCK_EX | fcntl.LOCK_NB)

    @staticmethod
    def is_held(lock_path: Path) -> bool:
        """Does another process (or another handle) hold this lock right
        now? A non-blocking try-lock that never creates, truncates or
        keeps the file."""
        path = Path(lock_path)
        if not path.is_file():
            return False
        probe = SingleInstance(path)
        try:
            probe._fd = os.open(str(path), os.O_RDWR)
        except OSError:
            return False
        try:
            probe._lock()
        except OSError:
            os.close(probe._fd)
            probe._fd = None
            return True
        probe.release()
        return False

    def release(self) -> None:
        if self._fd is None:
            return
        try:
            if sys.platform == "win32":
                import msvcrt
                os.lseek(self._fd, 0, os.SEEK_SET)
                msvcrt.locking(self._fd, msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(self._fd, fcntl.LOCK_UN)
        except OSError:
            pass
        finally:
            try:
                os.close(self._fd)
            except OSError:
                pass
            self._fd = None

    def __enter__(self):
        return self.acquire()

    def __exit__(self, *exc):
        self.release()
        return False
