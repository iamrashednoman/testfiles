"""Where the background agent is, and how the window finds it.

The agent (desktop/agent.py, `--agent`) and the window (desktop/shell.py)
are separate PROCESSES: the bot must keep running when the window is
closed, and the OS supervisor (Scheduled Task / LaunchAgent) restarts
the agent on its own. This module is the small file-based contract
between them, all under the writable data directory:

  agent.json   written by a READY agent: {url, port, pid, version,
               started_at}. Removed on a clean stop. A stale file (crash)
               is harmless — readers always confirm with /ping.
  agent.stop   a stop REQUEST. Touched by `--stop` (and, later, by the
               console's Stop button); the agent polls for it and runs
               its graceful drain. A file rather than a signal because a
               detached Windows process has no console to receive one,
               and a plain-file request needs no network credentials.
  agent.lock   the agent's single-instance lock (desktop/single_instance).

Nothing here imports the service or the GUI, so the window can decide
"attach or launch" before either is loaded.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime, timedelta, timezone
from pathlib import Path

from src.core.app_paths import data_path, is_frozen, resource_path

RUNTIME_FILE = "agent.json"
AGENT_LOG_MAX_BYTES = 10 * 1024 * 1024
STOP_FILE = "agent.stop"
LOCK_FILE = "agent.lock"
AGENT_LOG = os.path.join("logs", "agent.log")

AGENT_ARG = "--agent"


# ── agent.json ──

def runtime_path() -> Path:
    return data_path(RUNTIME_FILE)


def write_runtime(port: int, pid: int | None = None,
                  version: str = "") -> Path:
    """Publish the agent's address. Written atomically (temp + rename)
    so a reader never sees a half-written file."""
    path = runtime_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    info = {
        "url": f"http://127.0.0.1:{port}",
        "port": int(port),
        "pid": int(pid if pid is not None else os.getpid()),
        "version": version,
        # JST like every time the console shows (E2E-L03).
        "started_at": datetime.now(timezone(timedelta(hours=9))).isoformat(
            timespec="seconds"),
    }
    tmp = path.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(info, indent=2), encoding="utf-8")
    os.replace(tmp, path)
    return path


def read_runtime() -> dict | None:
    try:
        return json.loads(runtime_path().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def remove_runtime() -> None:
    try:
        runtime_path().unlink()
    except OSError:
        pass


# ── Liveness ──

def pid_alive(pid: int) -> bool:
    """Is a process with this id running? (No permission to signal it
    still counts as alive.)"""
    if not pid or pid <= 0:
        return False
    if sys.platform == "win32":
        import ctypes
        SYNCHRONIZE = 0x00100000
        handle = ctypes.windll.kernel32.OpenProcess(SYNCHRONIZE, False, pid)
        if not handle:
            return False
        try:
            STILL_ACTIVE = 259
            code = ctypes.c_ulong()
            ok = ctypes.windll.kernel32.GetExitCodeProcess(
                handle, ctypes.byref(code))
            return bool(ok) and code.value == STILL_ACTIVE
        finally:
            ctypes.windll.kernel32.CloseHandle(handle)
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True


def ping(url: str, timeout: float = 2.0) -> bool:
    """True when the service at `url` answers /ping (unauthenticated —
    see intake/routes.py)."""
    try:
        with urllib.request.urlopen(f"{url}/api/v1/ping",
                                    timeout=timeout) as r:
            return r.status == 200
    except (urllib.error.URLError, OSError, ValueError):
        return False


def find_running_agent(timeout: float = 1.0) -> str | None:
    """The base URL of a LIVE agent, or None. A runtime file whose
    service does not answer is treated as stale, not trusted."""
    info = read_runtime()
    if not info or not info.get("url"):
        return None
    return info["url"] if ping(info["url"], timeout) else None


def wait_for_agent(timeout: float = 90.0,
                   proc: subprocess.Popen | None = None) -> str | None:
    """Poll until a live agent is published, or `timeout` passes, or the
    process we launched exits first (a startup failure — do not wait
    the full timeout for a service that is already gone)."""
    deadline = time.time() + timeout
    while time.time() < deadline:
        url = find_running_agent()
        if url:
            return url
        if proc is not None and proc.poll() is not None:
            return None
        time.sleep(0.5)
    return None


# ── Stop requests ──

def stop_path() -> Path:
    return data_path(STOP_FILE)


def request_stop() -> None:
    path = stop_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(datetime.now().isoformat(timespec="seconds"),
                    encoding="utf-8")


def stop_requested() -> bool:
    return stop_path().is_file()


def clear_stop_request() -> None:
    try:
        stop_path().unlink()
    except OSError:
        pass


# ── Launching the agent from the window ──

def agent_log_path() -> Path:
    return data_path(AGENT_LOG)


def agent_command() -> list[str]:
    """How to start the agent for THIS runtime. Frozen: the executable
    re-invokes itself (same pattern as the sim-terminal worker). From
    source: desktop/app.py with the same flag."""
    if is_frozen():
        return [sys.executable, AGENT_ARG]
    return [sys.executable, str(resource_path("desktop", "app.py")),
            AGENT_ARG]


def rotate_agent_log(log: Path, max_bytes: int = AGENT_LOG_MAX_BYTES) -> bool:
    """Keep the agent's console output to two files of at most
    `max_bytes` (SY-02, 2026-10-03): it used to grow for ever. The full
    file becomes agent.log.1 (replacing the one before). Returns True
    when it rotated. Never raises."""
    try:
        if log.is_file() and log.stat().st_size > max_bytes:
            os.replace(log, log.with_name(log.name + ".1"))
            return True
    except OSError:
        pass
    return False


def truncate_agent_log(log: Path, max_bytes: int = AGENT_LOG_MAX_BYTES) -> bool:
    """The same limit while the agent RUNS (UAT-L21, 2026-10-04): the
    agent writes to agent.log for as long as it runs, so the check at
    start alone let it grow without limit under the scheduled task. The
    content is copied to agent.log.1 and the file emptied where it is:
    the agent keeps writing to it (it was opened for appending). Never
    raises."""
    import shutil
    try:
        if log.is_file() and log.stat().st_size > max_bytes:
            shutil.copyfile(log, log.with_name(log.name + ".1"))
            with open(log, "r+b") as f:
                f.truncate(0)
            return True
    except OSError:
        pass
    return False


def previous_run_ended_unexpectedly() -> dict | None:
    """The address file of an agent that did not stop cleanly: a clean
    stop removes it, so one left behind whose process is gone means the
    previous run was killed, crashed or the machine went down (OPS-09,
    2026-10-04). None when the previous run stopped cleanly."""
    info = read_runtime()
    if not info:
        return None
    try:
        pid = int(info.get("pid") or 0)
    except (TypeError, ValueError):
        pid = 0
    if pid and pid_alive(pid):
        return None                       # still running: not ours to judge
    return info


def spawn_agent() -> subprocess.Popen:
    """Start the agent DETACHED, so it outlives the window that
    launched it. Its console output goes to logs/agent.log — the only
    place a startup failure of a windowless process can be seen."""
    log = agent_log_path()
    log.parent.mkdir(parents=True, exist_ok=True)
    rotate_agent_log(log)
    log_fh = open(log, "ab")
    kwargs: dict = {
        "stdin": subprocess.DEVNULL,
        "stdout": log_fh,
        "stderr": subprocess.STDOUT,
        "cwd": str(resource_path()) if not is_frozen()
        else str(data_path()),
        "env": dict(os.environ),
    }
    if sys.platform == "win32":
        DETACHED_PROCESS = 0x00000008
        CREATE_NEW_PROCESS_GROUP = 0x00000200
        kwargs["creationflags"] = DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
    else:
        kwargs["start_new_session"] = True
    try:
        return subprocess.Popen(agent_command(), **kwargs)
    finally:
        log_fh.close()          # the child holds its own handle
