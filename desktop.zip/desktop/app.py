"""Desktop entry point — argument dispatch and the four run modes.

Everything the executable can be asked to do enters here. Nothing in
src/ knows a desktop app exists: each mode builds the SAME FastAPI
service `python run.py` builds, so the API, dispatcher, workflows,
error catalogue and audit trail are byte-for-byte the same.

    (default)                 the desktop window (desktop/shell.py) —
                              attaches to the background agent, or
                              launches one; closing it leaves the bot
                              running
    --agent                   the background agent: the bot with no
                              window, run at logon by the OS supervisor
                              (desktop/agent.py, packaging/agent/)
    --stop                    ask the running agent to drain and exit
    --check-db [URL] [--json] database connectivity + schema check
                              (installer; password via DATABASE_PASSWORD)
    --configure ...           install-time step: write finesiii.env,
                              store secrets, register the supervisor,
                              check the database (desktop/configure.py)
    --selftest [--json]       verify this bundle on the machine it was
                              installed on; exit 0 = all usable
    --reset-console-password <user>
                              set a provisional console password from
                              the server itself (desktop/breakglass.py)
    --headless                the service with no window IN THE
                              FOREGROUND — troubleshooting (startup
                              errors print to the console)
    --sim-terminal-worker     frozen re-entry, see below

Frozen-app entry dispatch
-------------------------
The sim-terminal driver launches a worker with
    [sys.executable, "-m", "src.rpa.sim_terminal_app", req, res]
which cannot work in a bundle: sys.executable IS this app and there is
no -m. A frozen build therefore re-invokes ITSELF with a leading
marker argument, handled here before anything else starts.
"""
from __future__ import annotations

import importlib.util
import os
import socket
import sys

# Running this file DIRECTLY (`python desktop/app.py --agent`, which is
# how the window launches the agent from source) puts desktop/ on the
# module path instead of the repo root, so `import src` fails. Anchor
# the root explicitly; a frozen bundle and `-m desktop.app` are
# unaffected (the root is already there, and the insert is a no-op).
if not getattr(sys, "frozen", False):
    _ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if _ROOT not in sys.path:
        sys.path.insert(0, _ROOT)

_BANNER = "\n FINESIII RPA — desktop\n" + "=" * 46

SIM_WORKER_ARG = "--sim-terminal-worker"
SELFTEST_ARG = "--selftest"
HEADLESS_ARG = "--headless"
AGENT_ARG = "--agent"
STOP_ARG = "--stop"
CHECK_DB_ARG = "--check-db"
CONFIGURE_ARG = "--configure"
RESET_PASSWORD_ARG = "--reset-console-password"
JSON_FLAG = "--json"


def _pick_port(preferred: int = 8000) -> int:
    """Preferred port when free, else an ephemeral one — a desktop app
    must never fail to start because something else holds 8000."""
    for candidate in (preferred, 0):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                s.bind(("127.0.0.1", candidate))
                return s.getsockname()[1]
            except OSError:
                continue
    raise RuntimeError("No free local port available")


def _selftest(argv: list[str]) -> int:
    """Verify the BUNDLE on the machine it was installed on.

    Shared implementation with the console's System page
    (desktop/selftest.py). `--json` prints the report as JSON for the
    installer's post-install check. Exit code 0 = every component usable.
    """
    from desktop.selftest import print_report, run_selftest, to_json

    _prepare_environment()
    cfg = None
    try:
        from config import get_config
        cfg = get_config()
    except Exception as e:          # report it, but still test the rest
        print(f" [WARN] configuration did not load: {e}", file=sys.stderr)
    report = run_selftest(cfg)
    if JSON_FLAG in argv:
        print(to_json(report))
    else:
        print_report(report)
    return 0 if report["ok"] else 1


def _check_db(argv: list[str]) -> int:
    """--check-db [URL] [--json]: can this machine reach the database
    and is the schema in place? Used by the installer before it commits
    to a configuration. With no URL, checks the current configuration.
    A password may be supplied via DATABASE_PASSWORD in the environment
    (so it never appears on a command line)."""
    import json

    from desktop.deployment import check_database

    args = [a for a in argv if a != JSON_FLAG]
    url = args[0] if args else ""
    engine = ""
    if not url:
        _prepare_environment()
        from config import get_config
        cfg = get_config()
        if cfg.database_engine == "sqlite":
            url, engine = f"sqlite:///{cfg.sqlite_path}", "sqlite"
        else:
            url, engine = cfg.database_url, "postgres"
    result = check_database(url, engine=engine,
                            password=os.environ.get("DATABASE_PASSWORD", ""))
    if JSON_FLAG in argv:
        print(json.dumps(result, indent=2))
    else:
        from desktop.vault import strip_url_password
        print(f" Database : {strip_url_password(url)}")
        print(f" Engine   : {result['engine']}")
        if result["server"]:
            print(f" Server   : {result['server']}")
        if result["user"]:
            print(f" User     : {result['user']}")
        if result["missing_tables"]:
            print(f" Missing  : {', '.join(result['missing_tables'])}")
        if result["error"]:
            print(f" Error    : {result['error']}")
        if result["hint"]:
            print(f" Hint     : {result['hint']}")
        print(" Result   : " + ("OK" if result["ok"] else "FAILED"))
    return 0 if result["ok"] else 1


def _run_sim_worker(argv: list[str]) -> int:
    """Frozen re-entry: act as the sim-terminal subprocess."""
    from src.rpa.sim_terminal_app import main as sim_main
    sys.argv = ["sim_terminal_app", *argv]
    sim_main()
    return 0


def _prepare_environment(import_bootstrap: bool = False) -> None:
    """Create the writable data tree and seed the editable configs.

    import_bootstrap: ONLY the background agent (which runs as the bot
    account) may import the installer's secret hand-off into its vault.
    Any other mode — the window opened by an administrator, the
    self-test — must leave that file alone, or the bot's secrets would
    land in the wrong account's credential store and be gone for the
    agent.

    Phase 0 needed an os.chdir() here so the then-relative config
    defaults resolved somewhere writable. Phase 1 removed that
    dependency: config/base.py anchors every path to the correct root
    via src/core/app_paths, so NOTHING relies on the working directory
    and this is now a pure first-run bootstrap.
    """
    from src.core.app_paths import bootstrap_data_dir, is_frozen

    if is_frozen():
        bootstrap_data_dir()

    # Secrets from the OS credential vault → this process's environment,
    # BEFORE get_config() reads anything. A variable already set in the
    # environment always wins; an unavailable vault is reported, never
    # fatal (the process then runs on the environment alone, as today).
    try:
        import logging

        from desktop.vault import (import_bootstrap_secrets,
                                   load_secrets_into_env)
        log = logging.getLogger("finesiii_rpa_v3")
        if import_bootstrap:
            import_bootstrap_secrets(log)  # installer hand-off, first start
        load_secrets_into_env(log)
    except Exception as e:                # never block startup on this
        print(f" [WARN] credential vault not consulted: {e}",
              file=sys.stderr)


def serve() -> int:
    """Run the API with NO window and block (--headless).

    Used for troubleshooting (startup errors are printed instead of
    hidden behind a window that never opens), and on a server where the
    bot runs unattended.
    """
    _prepare_environment()

    import uvicorn
    from config import get_config
    from src import create_app

    cfg = get_config()
    # The audit trail is on by default for the installed service (SEC-02).
    from desktop.deployment import apply_service_defaults
    apply_service_defaults(cfg, degraded=False)
    port = _pick_port(cfg.api_port)

    from src.core.app_paths import data_root
    from src.core.banner import print_banner
    print_banner(cfg, "service starting (headless)", extra=[
        ("Data dir", str(data_root())),
        ("Evidence", str(cfg.evidence_dir)),
        ("Console", f"http://127.0.0.1:{port}"),
    ])

    app = create_app(cfg)
    uvicorn.run(app, host="127.0.0.1", port=port, log_config=None)
    return 0


def run_agent() -> int:
    """The background agent (--agent): the bot with no window."""
    import logging

    _prepare_environment(import_bootstrap=True)

    from config import get_config
    from desktop.agent import AgentRunner
    from src.core.app_paths import data_root

    cfg = get_config()
    # Desktop posture: a not-yet-configured install must still bring up
    # the console (API-only) so the setup can be finished from it; the
    # audit trail is on by default (SEC-02, 2026-10-04).
    from desktop.deployment import apply_service_defaults
    apply_service_defaults(cfg)
    # The same welcome and summary as run.py (was a four-line header).
    from src.core.banner import print_banner
    print_banner(cfg, "background agent starting", extra=[
        ("Data dir", str(data_root())),
        ("Evidence", str(cfg.evidence_dir)),
        ("Console", f"http://127.0.0.1:{cfg.api_port} (the address is "
                    f"confirmed on the 'Ready' line below)"),
    ])
    return AgentRunner(cfg, logger=logging.getLogger("finesiii_rpa_v3")).run()


def stop_agent() -> int:
    """--stop: graceful drain + exit of the running agent."""
    from desktop.agent import stop_running_agent
    return stop_running_agent()


def run_window() -> int:
    """Default: the desktop window, attached to the background agent."""
    _prepare_environment()

    from config import get_config
    from src.core.app_paths import data_root

    cfg = get_config()
    from desktop.deployment import apply_service_defaults
    apply_service_defaults(cfg)
    print(_BANNER)
    print(f"  data dir : {data_root()}")
    print(f"  database : {cfg.database_engine}")
    print(f"  driver   : {cfg.terminal_driver}")

    try:
        from desktop.shell import run_desktop
    except ImportError as e:
        print(f"\n [FATAL] The desktop window is unavailable: {e}\n"
              f"         Run the bot with --agent (stop it with --stop), "
              f"or the service in the foreground with --headless.",
              file=sys.stderr)
        return 1
    return run_desktop(cfg)


def _usage(stream=None) -> None:
    """The options this executable accepts."""
    print("Usage: FINESIII RPA [option]\n"
          "\n"
          "  --agent      start the bot in the background (no window)\n"
          "  --stop       ask the running bot to finish its current "
          "transaction and stop\n"
          "  --headless   run the service in the foreground "
          "(troubleshooting)\n"
          "  --check-db [URL] [--json]\n"
          "               check the database connection and tables\n"
          "  --configure ...\n"
          "               installation step: write the settings and "
          "register the bot\n"
          "  --selftest [--json]\n"
          "               verify this installation\n"
          "  --reset-console-password <username>\n"
          "               set a provisional console password from this "
          "server\n"
          "  -h, --help   show this help\n"
          "\n"
          "Without an option the desktop window opens, when it is part of "
          "this delivery.", file=stream or sys.stdout, flush=True)


def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    # A configuration that cannot be used is reported in one line naming
    # the setting, never as a trace (NB-009).
    from config import ConfigError
    try:
        return _dispatch(argv)
    except ConfigError as e:
        print(f"\n [FATAL] {e}", file=sys.stderr, flush=True)
        return 1


def _dispatch(argv: list[str]) -> int:
    if argv and argv[0] == SIM_WORKER_ARG:
        return _run_sim_worker(argv[1:])
    if argv and argv[0] == SELFTEST_ARG:
        return _selftest(argv[1:])
    if argv and argv[0] == HEADLESS_ARG:
        return serve()
    if argv and argv[0] == AGENT_ARG:
        return run_agent()
    if argv and argv[0] == STOP_ARG:
        return stop_agent()
    if argv and argv[0] == CHECK_DB_ARG:
        return _check_db(argv[1:])
    if argv and argv[0] == CONFIGURE_ARG:
        from desktop.configure import main as configure_main
        return configure_main(argv[1:])
    if argv and argv[0] == RESET_PASSWORD_ARG:
        # The way back in for a forgotten or locked-out administrator
        # (UR-08, 2026-10-03): stored secrets first (the database
        # password), then the reset.
        _prepare_environment()
        from desktop.breakglass import reset_console_password
        return reset_console_password(argv[1:])
    if argv and argv[0] in ("-h", "--help"):
        _usage()
        return 0
    if argv:
        print(f"Unknown option '{argv[0]}'\n", file=sys.stderr, flush=True)
        _usage(sys.stderr)
        return 2
    if importlib.util.find_spec("webview") is None:
        print("The desktop window is not part of this delivery. Use --agent "
              "to start the bot and --stop to stop it.\n",
              file=sys.stderr, flush=True)
        _usage(sys.stderr)
        return 2
    return run_window()


if __name__ == "__main__":
    sys.exit(main())
