"""/api/v1/system/* — the installed service, managed from the console.

Mounted ONLY by the desktop entry points (agent, embedded window), the
same way the console's static files are: `python run.py` and Docker
never see these routes, so the server API surface is unchanged.

  GET  /system/status              service, dispatcher, mode, vault
  GET  /system/deployment          finesiii.env settings + vault status
  PUT  /system/deployment          validate ALL, then write (atomic)
  PUT  /system/secrets/{name}      store a secret (write-only)
  DELETE /system/secrets/{name}
  POST /system/test-database       connectivity + schema check
  POST /system/selftest            the bundle self-test, as JSON
  GET  /system/logs                tail of the service / agent log
  GET  /system/diagnostics         support bundle (zip), secrets masked
  POST /system/dispatcher/pause    stop claiming NEW work
  POST /system/dispatcher/resume
  POST /system/stop                graceful drain + exit (agent only)

Every route needs a signed-in console user holding system.view or
system.manage (admin by default). Every write is audited. No route ever
returns a secret value.
"""
from __future__ import annotations

import io
import os
import re
import smtplib
import time
import zipfile
from datetime import datetime, timedelta, timezone
from pathlib import Path

from fastapi import APIRouter, Body, Depends, Header, HTTPException, Query
from fastapi.responses import Response

from desktop import deployment, runtime, vault
from src.modules.auth.models import AppUser
from src.modules.console import settings_help

# What a remote server answered, inside an error text: after an HTTP
# status ("failed: 401 <reply>"), a token answer, or an SMTP reply
# ("(535, b'<reply>')"). A connection test shows the status only; the
# reply stays in the service log (X-08, 2026-10-03), so the test
# buttons cannot be used to read what another server says.
_REMOTE_REPLY = (
    (re.compile(r"(failed: [1-5]\d\d)\b.*", re.S), r"\1"),
    (re.compile(r"(has no access_token)\b.*", re.S), r"\1"),
    (re.compile(r"\((\d{3}), b?['\"].*", re.S), r"(server reply \1)"),
)


# A test e-mail checks the connection; it is not a mailing (X-08).
MAX_TEST_RECIPIENTS = 5


def plain_error(e) -> str:
    """An error for the page in plain words: its message without the
    internal error type ("ValueError: ...", UAT-L05, 2026-10-04)."""
    return (str(e).strip() or type(e).__name__)[:300]


def public_error(text, logger=None, what: str = "Connection") -> str:
    """The error a connection test returns, without the remote reply;
    the full text goes to the log."""
    text = str(text or "")
    if logger is not None and text:
        try:
            logger.info(f"{what} test failed: {mask_secrets(text)[:2000]}")
        except Exception:
            pass
    for pattern, keep in _REMOTE_REPLY:
        text = pattern.sub(keep, text)
    return text[:300]

# An environment-style line (KEY=value, optionally indented or after
# "export"): the whole value, which may hold commas (API key lists) or
# spaces. PASS as a whole word segment (SNOW_PASS, pass) counts too.
_SECRET_LINE = re.compile(
    r"^(?P<lead>[ \t]*(?:export[ \t]+)?)(?P<key>[A-Za-z0-9_]*(?:PASSWORD|"
    r"PASSWD|PASSPHRASE|SECRET|API_KEY|API_KEYS|TOKEN)[A-Za-z0-9_]*|"
    r"(?:[A-Za-z0-9]+_)*PASS(?:_[A-Za-z0-9_]+)?)[ \t]*=.*$",
    re.MULTILINE | re.IGNORECASE)
# Key names that hold a secret. "pass" only as a whole word or segment
# (db_pass, pass) — never inside compass, bypass or passed (NB-006).
_KEY_EN = (r"[\w.-]*(?:password|passwd|passphrase|pwd|secret|api[_-]?keys?"
           r"|token)[\w.-]*|(?<![\w.-])(?:[\w.-]*[_.-])?pass(?:[_.-][\w.-]*)?"
           r"(?!\w)"
           # PW as a whole word or segment (PW=, db_pw) — SY-03.
           r"|(?<![\w.-])(?:[\w.-]*[_.-])?pw(?:[_.-][\w.-]*)?(?!\w)")
_KEY_JA = r"[^\s=:：\"']*(?:パスワード|暗証)[^\s=:：\"']*"
# key = value / key: value / "key": "value" where the key names a
# secret — anywhere in a line, any case (log lines, env files, JSON).
# A quoted value is masked up to its closing quote (spaces included),
# an unquoted one up to the next space or comma (';' and '&' included).
_SECRET_PAIR = re.compile(
    r"(?P<key>[\"']?(?:" + _KEY_EN + "|" + _KEY_JA
    + r")[\"']?[ \t　]*[=:：][ \t　]*)(?P<val>\"(?:\\.|[^\"\\\n])*\"|"
    r"'(?:\\.|[^'\\\n])*'|[^\s\"',]+)", re.IGNORECASE)
# A Japanese password label followed by the value without "=" or ":"
# ("パスワードAbc12345", "パスワードは Abc12345") — SY-03, 2026-10-03.
# Only a run of half-width characters is taken as the value, so Japanese
# text such as "パスワードを変更" is left alone.
_JA_NO_SEPARATOR = re.compile(
    r"(?P<key>(?:パスワード|暗証番号|暗証)(?:は)?[ \t　]*)(?P<val>[!-~]{4,})")
# The password field of a CyberArk answer ("Content": "...").
_CYBERARK_CONTENT = re.compile(
    r"(?P<key>[\"']Content[\"'][ \t]*:[ \t]*)(?P<val>\"(?:\\.|[^\"\\\n])*\"|"
    r"'(?:\\.|[^'\\\n])*')")
# Full-width LETTERS ("ＰＡＳＳＷＯＲＤ＝…") are read in their half-width
# form for masking (SY-03). Only lines with full-width letters are
# converted, so Japanese text with a full-width colon stays as written.
_FULL_WIDTH = re.compile(r"[\uff21-\uff3a\uff41-\uff5a]")
# Longest line shown (SY-03). A longer line is masked first and cut
# afterwards, so a secret that crosses the cut is not shown in part
# (UAT-L22, 2026-10-04). Only this much more than the limit is read for
# masking, which keeps it fast.
MAX_LINE_CHARS = 4000
_MASK_MARGIN = 1000

# Authorization headers, any scheme (Basic, Bearer, Digest …).
_AUTH_HEADER = re.compile(
    r"((?:proxy-)?authorization[\"']?[ \t]*[:=][ \t]*[\"']?"
    r"(?:(?:basic|bearer|digest|negotiate|ntlm)[ \t]+)?)[^\s\"',]+",
    re.IGNORECASE)
_BEARER = re.compile(r"(bearer\s+)\S+", re.IGNORECASE)
# URL passwords: scheme://user:pw@host → scheme://user:*****@host
_URL_PASSWORD = re.compile(r"(://[^:/@\s]+:)[^@\s]+@")

# Credentials read again on every use, so saving one takes effect at
# once: the ServiceNow poller rebuilds its connector (and signs in anew)
# before every poll (2026-09-28). Every other secret is read at startup.
HOT_SECRETS = {"SNOW_PASSWORD", "SNOW_CLIENT_SECRET"}


def _secret_values() -> list:
    """The secrets in use in this process (vault and environment), so a
    value is masked wherever it appears, labelled or not (SY-03,
    2026-10-03). Short values are left out: masking "abc" everywhere
    would garble the log."""
    values = set()
    try:
        names = list(vault.SECRET_KEYS)
    except Exception:
        names = []
    for name in names:
        raw = os.environ.get(name, "") or ""
        parts = [raw]
        if name == "FINESIII_API_KEYS":
            parts = [p.split(":", 1)[-1] for p in raw.split(",")]
        for part in parts:
            part = part.strip()
            if len(part) >= 6:
                values.add(part)
    # Earlier values of a secret replaced while the service runs: the
    # log written before still holds them (UAT-L22, 2026-10-04).
    try:
        values |= {v for v in vault.retired_values() if len(v) >= 6}
    except Exception:
        pass
    return sorted(values, key=len, reverse=True)


def mask_secrets(text: str) -> str:
    """Mask every secret-looking value in free text: KEY=value pairs,
    JSON "password": "x", Bearer tokens and URL passwords, the secrets in
    use themselves, and (2026-10-03) PW=, a Japanese label without a
    separator, full-width text and CyberArk's "Content". Used for the
    log view and every file of the diagnostics bundle."""
    if not text:
        return text
    if _FULL_WIDTH.search(text):
        import unicodedata
        text = "\n".join(unicodedata.normalize("NFKC", line)
                         if _FULL_WIDTH.search(line) else line
                         for line in text.split("\n"))
    for value in _secret_values():
        if value in text:
            text = text.replace(value, "*****")
    text = _CYBERARK_CONTENT.sub(_mask_pair, text)
    text = _JA_NO_SEPARATOR.sub(lambda m: f"{m.group('key')}*****", text)
    text = _SECRET_LINE.sub(
        lambda m: f"{m.group('lead')}{m.group('key')}=*****", text)
    text = _AUTH_HEADER.sub(r"\1*****", text)
    text = _SECRET_PAIR.sub(_mask_pair, text)
    text = _BEARER.sub(r"\1*****", text)
    return _URL_PASSWORD.sub(r"\1*****@", text)


def _mask_pair(m) -> str:
    """The key as written, the value replaced; a quoted value keeps its
    quotes so JSON and quoted log values stay well-formed."""
    val = m.group("val")
    q = val[0] if val[:1] in ("'", '"') else ""
    # Already masked by whoever wrote the line ("pw=***"): left as is.
    if val.strip("'\"") and not val.strip("'\"").strip("*"):
        return m.group(0)
    return f"{m.group('key')}{q}*****{q}"


_SECRET_KEY_NAME = re.compile(
    r"password|passwd|passphrase|pwd|secret|api[_-]?keys?|token"
    r"|(?<![A-Za-z0-9])pass(?![A-Za-z0-9])"
    r"|(?<![A-Za-z0-9])pw(?![A-Za-z0-9])|パスワード|暗証", re.IGNORECASE)


def _mask_obj(obj):
    """mask_secrets for a JSON-able structure, keeping it valid JSON: a
    text value under a secret-looking key is replaced whole, every other
    text is masked; numbers and on/off values are left as they are."""
    if isinstance(obj, dict):
        return {k: ("*****" if isinstance(v, str) and v
                    and _SECRET_KEY_NAME.search(str(k))
                    else _mask_obj(v)) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_mask_obj(v) for v in obj]
    if isinstance(obj, str):
        return mask_secrets(obj)
    return obj


def _tail(path: Path, lines: int) -> str:
    """The last `lines` lines, with every secret masked, and a very long
    line cut AFTER masking (UAT-L22)."""
    try:
        with open(path, "rb") as f:
            f.seek(0, os.SEEK_END)
            size = f.tell()
            block = min(size, max(4096, lines * 200))
            f.seek(size - block)
            data = f.read().decode("utf-8", errors="replace")
        rows = data.splitlines()
        # The first line of a block read from the middle of the file is
        # cut; it is left out (SY-03, 2026-10-03).
        if block < size and rows:
            rows = rows[1:]
        rows = rows[-lines:]
        longer = [len(r) > MAX_LINE_CHARS for r in rows]
        rows = [r[:MAX_LINE_CHARS + _MASK_MARGIN] for r in rows]
        masked = mask_secrets("\n".join(rows)).split("\n")
        if len(masked) != len(rows):          # cannot happen; be safe
            masked = [mask_secrets(r) for r in rows]
        return "\n".join(r[:MAX_LINE_CHARS] + " ...(cut)" if cut else r
                         for r, cut in zip(masked, longer))
    except OSError:
        return ""


_LEVELS = ("DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL")
# Where a pause of processing is kept across restarts (OPS-01).
PAUSE_KEY = "PROCESSING_PAUSED"
# The account the service first ran as: its credential store holds the
# passwords (SEC-03, 2026-10-04).
SERVICE_ACCOUNT_KEY = "SERVICE_ACCOUNT"
JST_TZ = timezone(timedelta(hours=9))


# The configuration files the service reads, by name (CFG-08, 2026-10-04).
# Settings files hold secrets, so they are listed with their checksum
# but never shown.
_EMAIL_TEMPLATES = ("support_report.txt", "user_registration.txt",
                    "user_password.txt")


def config_files(cfg) -> list:
    """[{name, purpose, path, exists, modified, size, sha256, viewable}],
    each the copy in force."""
    import hashlib
    from src.core.app_paths import config_path, resource_path
    from src.rpa.config import DEFAULT_LAYOUTS_PATH

    def first(*paths):
        for p in paths:
            if Path(p).is_file():
                return Path(p)
        return Path(paths[0])

    entries = [
        ("servicenow.yaml", "ServiceNow field mapping",
         config_path("servicenow.yaml"), True),
        ("email_messages.yaml", "E-mail texts",
         first(config_path("email_messages.yaml"),
               resource_path("config", "email_messages.yaml")), True),
        ("notifications.yaml", "E-mail alerts",
         config_path("notifications.yaml"), True),
        ("errors.yaml", "Error rules",
         Path(getattr(cfg, "error_catalog_path", "")
              or config_path("errors.yaml")), True),
        ("ocr.yaml", "Screen reading words",
         Path(getattr(cfg, "ocr_keywords_path", "")
              or config_path("ocr.yaml")), True),
        ("cyberark.yaml", "CyberArk", config_path("cyberark.yaml"), True),
        ("layouts.yaml", "Terminal screens and fields",
         Path(DEFAULT_LAYOUTS_PATH), True),
    ] + [(f"email_templates/{n}", "E-mail template",
          config_path(f"email_templates/{n}"), True)
         for n in _EMAIL_TEMPLATES] + [
        (".env", "Application settings file", deployment.app_env_file(),
         False),
        ("finesiii.env", "Machine settings file",
         deployment.deployment_file(), False),
    ]
    out = []
    for name, purpose, path, viewable in entries:
        path = Path(path)
        info = {"name": name, "purpose": purpose,
                "path": str(path.resolve() if path.exists() else path),
                "exists": path.is_file(), "modified": "", "size": 0,
                "sha256": "", "viewable": viewable}
        if path.is_file():
            try:
                st = path.stat()
                info["modified"] = datetime.fromtimestamp(
                    st.st_mtime, JST_TZ).isoformat(timespec="seconds")
                info["size"] = st.st_size
                info["sha256"] = hashlib.sha256(path.read_bytes()).hexdigest()
            except OSError:
                pass
        out.append(info)
    return out


def unread_app_env_keys() -> list:
    """Keys in the application settings file (.env) that the service
    does not read from it (CFG-03, 2026-10-04): only the start-up
    settings are; module settings live on the Settings pages."""
    from config.base import BaseConfig
    fields = {name.upper() for name in BaseConfig.model_fields}
    return sorted(k for k in deployment.read_app_env()
                  if k.upper() not in fields and k.upper() != "APP_ENV")


def process_elevated():
    """Whether this service runs with administrator rights (True/False),
    None when it cannot be told. The FINESIII terminal is started as
    administrator by default, which needs an elevated service (CFG-04,
    2026-10-04)."""
    try:
        if os.name == "nt":
            import ctypes
            return bool(ctypes.windll.shell32.IsUserAnAdmin())
        return os.geteuid() == 0
    except Exception:
        return None


def run_as_admin_setting() -> bool:
    """The terminal is started as administrator unless switched off:
    FINESIII_APP_RUN_AS_ADMIN, else layouts.yaml, else On."""
    try:
        from src.rpa.config import effective_application
        return bool(effective_application().get("run_as_admin", True))
    except Exception:
        return True
# Lines a filtered log view looks through (SY-02).
LOG_SEARCH_LINES = 20000


def _filter_log(text: str, level: str | None, q: str | None,
                lines: int) -> list:
    """The last `lines` lines at `level` or above that contain `q`
    (case-insensitive), searched in the MASKED text (SY-02)."""
    wanted = _LEVELS[_LEVELS.index(level):] if level in _LEVELS else None
    needle = (q or "").strip().lower()
    out = []
    keep = True             # whether the current message is shown
    for row in text.splitlines():
        if wanted is not None:
            parts = row.split("|")
            row_level = parts[1].strip() if len(parts) > 2 else ""
            # A line without a level continues the message above it (a
            # trace, a long text): it is kept with that message (UAT-L21,
            # 2026-10-04).
            if row_level in _LEVELS:
                keep = row_level in wanted
            if not keep:
                continue
        if needle and needle not in row.lower():
            continue
        out.append(row)
    return out[-lines:]


def build_system_router(app, *, mode: str, started_at: float,
                        stop_hook=None, logger=None) -> APIRouter:
    cfg = app.state.config
    auth_service = app.state.auth_service
    audit = getattr(app.state, "audit", None)
    from src.modules.auth.services import build_permission_dependency
    require_view = build_permission_dependency(auth_service, "system.view")
    require_manage = build_permission_dependency(auth_service,
                                                 "system.manage")
    router = APIRouter(prefix="/api/v1/system")

    def _audit(action: str, user: AppUser, severity: str = "WARNING",
               **fields):
        if audit is not None:
            try:
                audit.event("system", action, severity=severity,
                            actor=user.username, **fields)
            except Exception:
                pass

    def _dispatcher():
        return getattr(app.state, "dispatcher", None)

    # The machine settings as they were when this service was built: a
    # value that differs now was saved since and applies after a restart
    # (CFG-09, 2026-10-04).
    try:
        at_start = {spec["key"]: deployment.effective_value(spec["key"], cfg)
                    for spec in deployment.DEPLOYMENT_KEYS}
    except Exception:
        at_start = {}

    def _deployment_pending() -> list:
        out = []
        for spec in deployment.DEPLOYMENT_KEYS:
            key = spec["key"]
            if key in at_start and \
                    deployment.effective_value(key, cfg) != at_start[key]:
                out.append(key)
        return out

    _INVALID_WARNING = re.compile(r"\(([A-Za-z_]+)\) is not valid and is "
                                  r"ignored")

    def _startup_warnings() -> list:
        """The warnings of the last start, with an invalid stored value
        that has been corrected since shown as such (UAT-L06,
        2026-10-04): it used to stay until the next restart."""
        out = []
        store = getattr(app.state, "settings_store", None)
        for text in list(getattr(app.state, "startup_warnings", []) or []):
            m = _INVALID_WARNING.search(text)
            if m and store is not None:
                from src.modules.console.settings_catalogue import (
                    BY_KEY as _CAT, coerce as _coerce,
                )
                key = m.group(1)
                stored = store.all()
                still_bad = False
                if key in stored and key in _CAT:
                    try:
                        _coerce(_CAT[key], stored[key])
                    except ValueError:
                        still_bad = True
                if not still_bad:
                    label = _CAT.get(key, {}).get("label", key)
                    text = (f"Stored setting '{label}' ({key}) was corrected; "
                            f"restart the service to apply it.")
            out.append(text)
        # Keys in .env that are not read from it (CFG-03).
        unread = unread_app_env_keys()
        if unread:
            shown = ", ".join(unread[:6]) + (
                f" and {len(unread) - 6} more" if len(unread) > 6 else "")
            out.append(
                f"The application settings file (.env) holds {shown}, "
                f"which the service does not read from that file. Module "
                f"settings are kept on the Settings pages (application "
                f"database) and passwords in the credential store; remove "
                f"these lines from .env to avoid confusion.")
        # The service stopped unexpectedly before this start: shown for
        # 24 hours on the Dashboard and the System page (E2E-M07).
        note = getattr(app.state, "recovery_notice", None)
        if note and time.time() - note[0] < 24 * 3600:
            out.append(note[1])
        # Live warnings, e.g. e-mail not being delivered (E2E-L17).
        for check in getattr(app.state, "live_warnings", []) or []:
            try:
                text = check()
            except Exception:
                text = ""
            if text:
                out.append(text)
        return out

    def _settings_files() -> dict:
        """Where the start-up settings come from, for the System page's
        "Machine settings" card (OPS-05, 2026-10-04)."""
        keys = {spec["key"] for spec in deployment.DEPLOYMENT_KEYS}
        app_keys = sorted(keys & set(deployment.read_app_env()))
        machine_keys = sorted(keys & set(deployment.read()))
        env_keys = sorted(k for k in keys if k in os.environ)
        return {"app_file": deployment.app_env_file().is_file(),
                "app_file_keys": len(app_keys),
                "app_file_writable": deployment.app_env_writable(),
                "machine_file_keys": len(machine_keys),
                "environment_keys": len(env_keys)}

    def _environment_name() -> str:
        """The environment actually in force — the installer writes
        APP_ENV into finesiii.env, not the process environment (CFG-05)."""
        try:
            from config import _app_env
            return _app_env() or "development"
        except Exception:
            return os.environ.get("APP_ENV", "development")

    def _service_log() -> Path:
        return Path(cfg.log_dir) / "finesiii_rpa_v3.log"

    def _startup_problems() -> list:
        """Startup problems plus the live ones (e.g. CyberArk required
        but not delivered yet), which disappear once the cause clears."""
        problems = list(getattr(app.state, "startup_problems", []) or [])
        for check in getattr(app.state, "live_problems", []) or []:
            try:
                text = check()
            except Exception:
                text = ""
            if text:
                problems.append(text)
        return problems

    def _security_notices() -> list:
        """What weakens the protection of this service, for the System
        page (SEC-01 / 02 / 03 / 06, 2026-10-04). Each notice: level
        "danger" or "warning", a code and the text."""
        out = []
        # Shown with every terminal driver (D-01, 2026-10-05); red with
        # the real terminal, where it can change real accounts.
        if not getattr(cfg, "auth_enabled", False):
            out.append({"level": ("danger" if cfg.terminal_driver
                                  in deployment._REAL_DRIVERS else "warning"),
                        "code": "intake_open", "text": (
                "Requests are accepted without an API key. Any program or "
                "person on this server can create or delete FINESIII "
                "accounts through the request API. Before production use: "
                "save the API keys under Settings > This machine > "
                "Credentials (Machine API keys), turn on 'Require the "
                "machine API key' and 'Console sign-in may use the API' "
                "under Security, then restart.")})
        if getattr(app.state, "audit", None) is None:
            out.append({"level": "warning", "code": "audit_off", "text": (
                "The audit trail is off: sign-ins, settings and credential "
                "changes, evidence views and user changes are not "
                "recorded. Turn on 'Audit event trail' under Settings > "
                "This machine > Database, then restart.")})
        store = getattr(app.state, "settings_store", None)
        current = vault.store_account()
        try:
            recorded = (store.all().get(SERVICE_ACCOUNT_KEY, "")
                        if store is not None else "")
        except Exception:
            recorded = ""
        if recorded and current and recorded.lower() != current.lower():
            out.append({"level": "warning", "code": "account_changed",
                        "text": (
                f"This service runs as {current}, but it was set up to run "
                f"as {recorded}. Windows keeps saved passwords per account, "
                f"so the passwords saved for {recorded} are not available "
                f"here. Start the service as {recorded} (the account of "
                f"the scheduled task). If {current} is now the right "
                f"account, save the passwords again under Credentials and "
                f"choose 'Use this account'.")})
        pending = auth_service.initial_admin_pending() \
            if auth_service is not None else None
        if pending is not None:
            text = (f"The console administrator '{pending.username}' has "
                    f"not chosen its own password yet. Sign in as "
                    f"'{pending.username}' and choose a new password now: "
                    f"until then, anyone who knows the password it was "
                    f"given can take over the account.")
            if _is_published_default(pending):
                text += " Its password is the published default."
            out.append({"level": "warning", "code": "initial_admin",
                        "text": text})
        # CyberArk reached without checking its certificate (E2E-L18):
        # allowed on this machine only, or while CyberArk is not
        # required, but not for production use.
        ca_settings = getattr(getattr(app.state, "cyberark", None), "s", None)
        if ca_settings is not None and (
                not getattr(ca_settings, "verify_tls", True)
                or str(getattr(ca_settings, "base_url", "")).lower()
                .startswith("http://")):
            out.append({"level": "warning", "code": "cyberark_tls", "text": (
                "The mainframe password is fetched from CyberArk over a "
                "connection whose certificate is not checked. Use an https "
                "address and turn on 'Verify TLS certificate' under "
                "Settings > CyberArk before production use.")})
        # The registration notice promises a separate password e-mail
        # that is not sent (E2E-M02, D-02).
        try:
            from src.modules.notifications.ticket_reports import (
                load_ticket_report_config)
            tr = load_ticket_report_config()
            if tr.txn_enabled and tr.send_registration and not tr.send_password:
                out.append({"level": "warning", "code": "password_notice_off",
                            "text": (
                    "The registration e-mail tells a new user that the "
                    "password follows in a separate e-mail, but 'Send the "
                    "initial password to the new user' is Off: no password "
                    "e-mail is sent. Turn it on under Settings > E-mail, or "
                    "tell new users their password another way.")})
        except Exception:
            pass
        return out

    _published_check: dict = {}

    def _is_published_default(user) -> bool:
        """Whether the account's password is the default printed in the
        documentation. Checked once per stored password (a check takes
        a moment)."""
        key = (user.user_id, user.password_hash)
        if key not in _published_check:
            try:
                published = type(cfg).model_fields[
                    "auth_default_admin_password"].default
                _published_check.clear()
                _published_check[key] = bool(
                    published and user.check_password(published))
            except Exception:
                _published_check[key] = False
        return _published_check[key]

    def _cyberark_card():
        """The CyberArk status for the System card, with the error in
        plain words and without the vault's reply (E2E-L18)."""
        ca = getattr(app.state, "cyberark", None)
        if ca is None:
            return None
        st = ca.status()
        err = public_error(st.get("last_error", ""))
        if "(Inactive)" in err:
            err = ("CyberArk did not pass its availability check; the "
                   "password was not fetched")
        st["last_error"] = err
        return st

    def _status_payload() -> dict:
        d = _dispatcher()
        info = runtime.read_runtime() or {}
        return {
            "mode": mode,
            "version": getattr(app, "version", ""),
            "pid": os.getpid(),
            "started_at": datetime.fromtimestamp(started_at, JST_TZ).isoformat(
                timespec="seconds"),
            "uptime_seconds": int(time.time() - started_at),
            "url": info.get("url", ""),
            # The port in use and the one configured: they differ when
            # the configured one was taken at start (OPS-04, 2026-10-04).
            "port": info.get("port"),
            "configured_port": cfg.api_port,
            "mainframe_environment": cfg.mainframe_environment,
            "environment": _environment_name(),
            "driver": cfg.terminal_driver,
            "database_engine": cfg.database_engine,
            "data_dir": str(runtime.data_path()),
            "deployment_file": str(deployment.deployment_file()),
            "deployment_file_exists": deployment.deployment_file().is_file(),
            "ocr_enabled": bool(cfg.ocr_enabled),
            "dispatcher": (d.status() if d is not None
                           else {"running": False, "busy": False,
                                 "paused": False,
                                 "mode": "api-only (no executor)",
                                 # Why nothing is processed, in words
                                 # (UAT-L23, 2026-10-04).
                                 "reason": ("Process queued work is Off (Settings > Dispatcher)"
                          if not getattr(cfg, "dispatcher_enabled", True)
                          else "No terminal to run requests on (the service "
                               "accepts requests only)")}),
            "vault": vault.vault_info(),
            # What weakens the protection of this service (F7).
            "security": _security_notices(),
            "can_stop": stop_hook is not None,
            "can_restart": getattr(app.state, "settings_store",
                                   None) is not None,
            # Why processing is disabled, if it is (degraded start).
            "startup_problems": _startup_problems(),
            # Settings that need attention although requests are still
            # processed (ignored stored values, e-mail switched off …).
            "startup_warnings": _startup_warnings(),
            # Where the start-up settings come from (OPS-05), and the
            # address the service listens on: this machine only, whatever
            # API_HOST says (CFG-10, 2026-10-04).
            "settings_files": _settings_files(),
            "listens_on": "127.0.0.1 (this machine only)",
            "machine_settings_pending": len(_deployment_pending()),
            "cyberark": _cyberark_card(),
            # The operating window and e-mail delivery, for the System
            # page cards (SY-04, 2026-10-03).
            "availability": (app.state.availability.status()
                             if getattr(app.state, "availability", None)
                             is not None else None),
            "email": _email_card(),
            "servicenow": (app.state.snow_poller.status()
                           if getattr(app.state, "snow_poller", None)
                           is not None else None),
        }

    def _email_card() -> dict:
        """E-mail on/off, a delivery problem, and e-mails waiting."""
        services = getattr(app.state, "email_services", None)
        out = {"enabled": services is not None, "problem": "",
               "waiting": 0}
        if services is None:
            return out
        try:
            out["problem"] = services.delivery_problem() or ""
        except Exception:
            pass
        box = getattr(services, "outbox", None)
        if box is not None:
            try:
                out["waiting"] = box.pending()
            except Exception:
                pass
        return out

    def _effective(key: str) -> str:
        """Value in force for an env-target setting: a console override
        (stored, even before the restart applies it) beats the process
        environment."""
        store = getattr(app.state, "settings_store", None)
        if store is not None:
            try:
                stored = store.all()
                if key in stored:
                    return str(stored[key])
            except Exception:
                pass
        return os.environ.get(key, "")

    def _truthy(value: str) -> bool:
        return str(value or "").strip().lower() in ("1", "true", "yes", "on")

    # ── Status ──

    @router.get("/status")
    def status(user: AppUser = Depends(require_view)):
        return _status_payload()

    def _servicenow_configured() -> bool:
        """Configured = instance URL plus the identity AND the stored
        secret the chosen authentication needs (SN-04, 2026-10-03: a
        username without its password was counted as configured)."""
        if not _effective("SNOW_INSTANCE_URL"):
            return False
        method = (_effective("SNOW_AUTH_METHOD") or "basic").lower()
        password = bool(os.environ.get("SNOW_PASSWORD"))
        secret = bool(os.environ.get("SNOW_CLIENT_SECRET"))
        if method == "oauth_client_credentials":
            return bool(_effective("SNOW_CLIENT_ID")) and secret
        if method in ("oauth", "oauth_password"):
            return bool(_effective("SNOW_CLIENT_ID")
                        and _effective("SNOW_USERNAME")) and secret \
                and password
        return bool(_effective("SNOW_USERNAME")) and password

    # ── First-run checklist ──

    def _setup_payload() -> dict:
        store = getattr(app.state, "settings_store", None)
        stored = store.all() if store is not None else {}
        cyberark_on = _truthy(_effective("CYBERARK_ENABLED"))
        real_driver = cfg.terminal_driver in deployment._REAL_DRIVERS
        modules = {
            "servicenow": {
                "enabled": _truthy(_effective("SNOW_ENABLED")),
                "configured": _servicenow_configured(),
            },
            "smtp": {
                "enabled": _truthy(_effective("SMTP_ALERTS_ENABLED")),
                # A sign-in name needs its password (SN-04).
                "configured": bool(_effective("SMTP_HOST")
                                   and _effective("ALERT_FROM")
                                   and (not _effective("SMTP_USERNAME")
                                        or os.environ.get("SMTP_PASSWORD"))),
            },
            "cyberark": {
                "enabled": cyberark_on,
                "configured": bool(_effective("CYBERARK_BASE_URL")
                                   and _effective("CYBERARK_APP_ID")
                                   and _effective("CYBERARK_SAFE")
                                   and ((_effective("CYBERARK_API_STYLE")
                                         or "ccp").lower() != "pvwa"
                                        or os.environ.get(
                                            "CYBERARK_PVWA_PASSWORD"))),
                "required": bool(cfg.require_cyberark and real_driver),
            },
            "finesiii": {
                "driver": cfg.terminal_driver,
                "mainframe_environment": cfg.mainframe_environment,
                "credential_source": ("cyberark" if cyberark_on
                                      else "vault"
                                      if os.environ.get("FINESIII_PASSWORD")
                                      else "none"),
                "ocr_enabled": bool(cfg.ocr_enabled),
                # Started as administrator (setting) and whether this
                # service can do it (CFG-04, 2026-10-04).
                "run_as_admin": run_as_admin_setting(),
                "service_elevated": process_elevated(),
            },
        }
        return {
            "complete": stored.get("SETUP_COMPLETE", "") == "true",
            "editable": store is not None,
            "modules": modules,
            "startup_problems": _startup_problems(),
            "startup_warnings": _startup_warnings(),
            "checks": {
                "database": {"ok": cfg.database_engine == "postgres",
                             "value": cfg.database_engine,
                             "note": "PostgreSQL is expected for a shared "
                                     "or production install."},
                # The simulated terminal signs in with its built-in test
                # account: nothing to set up. With the real terminal, a
                # password in the vault or CyberArk IN FORCE (saved but
                # not yet applied does not count) (E2E-M04).
                "service_account": {
                    "ok": (bool(os.environ.get("FINESIII_PASSWORD"))
                           or getattr(app.state, "cyberark", None) is not None
                           or not real_driver),
                    "needed": real_driver,
                    "note": ("Mainframe service account in the vault, or "
                             "CyberArk enabled and in force (after a restart)."
                             if real_driver else
                             "Not needed with the simulated terminal: it signs "
                             "in with its built-in test account.")},
                "driver": {"ok": True, "value": cfg.terminal_driver},
                "ocr": {"ok": bool(cfg.ocr_enabled)
                        or cfg.terminal_driver not in
                        deployment._REAL_DRIVERS,
                        "value": bool(cfg.ocr_enabled),
                        "note": "Required with a real terminal driver."},
                "email": {"ok": os.environ.get(
                    "SMTP_ALERTS_ENABLED", "").lower() in ("true", "1"),
                    "note": "Optional — alerts and outcome emails."},
            },
        }

    def _dismissed_by() -> set:
        store = getattr(app.state, "settings_store", None)
        raw = (store.all() if store is not None else {}).get(
            "SETUP_DISMISSED_BY", "")
        return {u for u in str(raw).split(",") if u}

    @router.get("/setup")
    def get_setup(user: AppUser = Depends(require_view)):
        payload = _setup_payload()
        # "Skip for now" in the setup assistant, remembered per account
        # on the service, so the assistant does not open again at every
        # sign-in or reload (SES-05, 2026-10-04).
        payload["dismissed"] = user.user_id in _dismissed_by()
        return payload

    @router.put("/setup")
    def put_setup(body: dict = Body(...),
                  user: AppUser = Depends(require_manage)):
        store = getattr(app.state, "settings_store", None)
        if store is None:
            raise HTTPException(status_code=503,
                                detail="Settings storage is unavailable")
        if "dismissed" in (body or {}):
            # Only this account's choice; the set-up state is unchanged.
            raw = body.get("dismissed")
            dismissed = raw if isinstance(raw, bool) else _truthy(raw)
            ids = _dismissed_by()
            (ids.add if dismissed else ids.discard)(user.user_id)
            if ids:
                store.set("SETUP_DISMISSED_BY", ",".join(sorted(ids)),
                          actor=user.username)
            else:
                store.clear("SETUP_DISMISSED_BY")
            payload = _setup_payload()
            payload["dismissed"] = dismissed
            return payload
        raw = (body or {}).get("complete", True)
        # "false"/"0"/"no" as TEXT must clear the flag too (CFG-04).
        complete = raw if isinstance(raw, bool) else _truthy(raw)
        incomplete = []
        if complete:
            # A module switched on but not fully set up is refused unless
            # the request confirms it, as the setup assistant asks
            # (UAT-09, 2026-10-04).
            names = {"servicenow": "ServiceNow", "smtp": "E-mail",
                     "cyberark": "CyberArk", "finesiii": "FINESIII terminal"}
            incomplete = [names.get(k, k) for k, m in
                          (_setup_payload().get("modules") or {}).items()
                          if isinstance(m, dict) and m.get("enabled")
                          and m.get("configured") is False]
            confirmed = (body or {}).get("confirm", False)
            confirmed = confirmed if isinstance(confirmed, bool) \
                else _truthy(confirmed)
            if incomplete and not confirmed:
                raise HTTPException(status_code=409, detail=(
                    f"{', '.join(incomplete)} "
                    f"{'is' if len(incomplete) == 1 else 'are'} switched on "
                    f"but not fully set up. Confirm to mark the setup "
                    f"complete anyway."))
            store.set("SETUP_COMPLETE", "true", actor=user.username)
        else:
            store.clear("SETUP_COMPLETE")
        _audit("setup_marked", user, "INFO" if not incomplete else "WARNING",
               detail={"complete": complete,
                       "incomplete_confirmed": incomplete})
        payload = _setup_payload()
        payload["dismissed"] = user.user_id in _dismissed_by()
        return payload

    # ── Deployment file ──

    @router.get("/deployment")
    def get_deployment(user: AppUser = Depends(require_view)):
        in_file = deployment.read()
        in_app = deployment.read_app_env()
        app_writable = deployment.app_env_writable()
        pending = set(_deployment_pending())
        items = []
        for spec in deployment.DEPLOYMENT_KEYS:
            key = spec["key"]
            value = deployment.effective_value(key, cfg)
            if spec["secret_url"]:
                # A URL that cannot be read must not 500 the page nor
                # show its password (NB-002).
                value = vault.mask_url(value)
            from_env = key in os.environ
            # Where the value comes from (CFG-01, 2026-10-04): the
            # environment, the application settings file (.env), the
            # machine settings file (finesiii.env) or the default.
            source = ("environment" if from_env else "app_file"
                      if key in in_app else "machine_file"
                      if key in in_file else "default")
            locked = from_env or (key in in_app and not app_writable)
            items.append({
                **{k: spec[k] for k in ("key", "label", "kind", "group",
                                        "help", "choices", "min", "max")},
                "value": value,
                "in_file": key in in_file,
                "in_app_file": key in in_app,
                "from_environment": from_env,
                "source": source,
                "locked": locked,
                "locked_reason": (
                    "Set by a Windows environment variable — change it "
                    "there." if from_env else
                    "Set in the application settings file (.env in the "
                    "application folder), which this service cannot "
                    "change — change it there, then restart."
                    if locked else ""),
                # Saved since the service started: applies after a
                # restart (CFG-09).
                "pending_restart": key in pending,
                "tooltip": settings_help.tooltip(key, spec["help"]),
            })
        secrets = vault.status()
        for name, info in secrets.items():
            info["tooltip"] = settings_help.tooltip(name)
        return {"file": str(deployment.deployment_file()),
                "exists": deployment.deployment_file().is_file(),
                "app_file": {"exists": deployment.app_env_file().is_file(),
                             "writable": app_writable,
                             "keys": sorted(k for k in in_app
                                            if k in deployment.BY_KEY)},
                "groups": deployment.GROUPS, "settings": items,
                "secrets": secrets, "vault": vault.vault_info(),
                # The revision a save from this page refers to (CFG-06).
                "revision": _machine_revision()}

    def _machine_revision() -> dict:
        from src.modules.console.settings_store import read_revision
        r = read_revision(getattr(app.state, "settings_store", None),
                          "machine")
        return {k: r[k] for k in ("rev", "by", "at")}

    @router.put("/deployment")
    async def put_deployment(changes: dict = Body(...),
                             force: bool = Query(False),
                             user: AppUser = Depends(require_manage),
                             x_machine_revision: str | None = Header(None)):
        """Validate EVERY key first; write nothing unless all pass —
        a half-applied deployment file is worse than a rejected one."""
        from src.modules.console.settings_store import (
            parse_revision, record_revision, revision_lock, stale_changes,
            stale_message,
        )
        store = getattr(app.state, "settings_store", None)
        seen = parse_revision(x_machine_revision)
        normalised: dict[str, str | None] = {}
        secrets_to_store: dict[str, str] = {}
        submitted = dict(changes or {})
        for key, raw in submitted.items():
            spec = deployment.BY_KEY.get(key)
            if spec is None:
                raise HTTPException(
                    status_code=400,
                    detail=f"'{key}' is not a deployment setting")
            if raw is None or (isinstance(raw, str) and raw.strip() == ""):
                normalised[key] = None
                continue
            try:
                value = deployment.coerce(spec, raw)
            except ValueError as e:
                raise HTTPException(status_code=400, detail=str(e))
            if spec["secret_url"]:
                pw = vault.url_password(value)
                if pw:
                    secret_key = ("AUDIT_DATABASE_PASSWORD"
                                  if key.startswith("AUDIT_")
                                  else "DATABASE_PASSWORD")
                    secrets_to_store[secret_key] = pw
                    value = vault.strip_url_password(value)
            normalised[key] = value

        # Cross-field rule, on the values that WILL be in force: a real
        # terminal driver with OCR off is refused (client-mandated
        # control — the service would refuse to start anyway; better to
        # say so now than after a restart).
        driver = normalised.get("TERMINAL_DRIVER")
        if driver is None and "TERMINAL_DRIVER" not in normalised:
            driver = deployment.effective_value("TERMINAL_DRIVER", cfg)
        ocr = normalised.get("OCR_ENABLED")
        if ocr is None and "OCR_ENABLED" not in normalised:
            ocr = deployment.effective_value("OCR_ENABLED", cfg)
        if driver in deployment._REAL_DRIVERS \
                and str(ocr or "").lower() not in ("true", "1"):
            raise HTTPException(
                status_code=400,
                detail=("A real terminal driver requires OCR "
                        "(client-mandated control) — enable Screen "
                        "reading first."))
        # ADR 7 / require_cyberark (D16): production + real driver needs
        # the CyberArk module enabled (Settings → CyberArk) — refuse the
        # combination here rather than after a restart.
        app_env = normalised.get("APP_ENV")
        if app_env is None and "APP_ENV" not in normalised:
            app_env = deployment.effective_value("APP_ENV", cfg) or \
                os.environ.get("APP_ENV", "development")
        if driver in deployment._REAL_DRIVERS \
                and str(app_env).lower() == "production" \
                and not _truthy(_effective("CYBERARK_ENABLED")):
            raise HTTPException(
                status_code=400,
                detail=("In production a real terminal driver requires the "
                        "mainframe password to come from CyberArk — enable "
                        "and test the CyberArk module first."))

        # A driver that cannot run on this machine is refused now, not
        # on the first ticket (2026-09-28). Checked after the rules above
        # so their messages keep priority.
        chosen = normalised.get("TERMINAL_DRIVER")
        if chosen:
            problem = deployment.driver_problem(chosen)
            if problem:
                raise HTTPException(status_code=400, detail=problem)

        # A database server that cannot be reached is refused unless the
        # administrator saves anyway (?force=true): a saved unreachable
        # address stopped every later start (NB-005). Only "no server
        # answered" refuses — a rejected sign-in or a missing database
        # means the server is there.
        if not force:
            from starlette.concurrency import run_in_threadpool
            for target in _database_targets(normalised, secrets_to_store):
                result = await run_in_threadpool(
                    deployment.check_database, target["url"],
                    engine="postgres", password=target["password"],
                    timeout=5)
                if result.get("unreachable"):
                    reason = mask_secrets(result.get("error") or
                                          result.get("hint") or "")
                    raise HTTPException(status_code=400, detail={
                        "status": "database_unreachable",
                        "key": target["key"],
                        "message": (f"The database server cannot be "
                                    f"reached ({reason}). Check the "
                                    f"address, or save anyway.")})

        if secrets_to_store and not vault.vault_info()["available"]:
            raise HTTPException(
                status_code=503,
                detail=("The OS credential vault is unavailable on this "
                        "machine, so the database password cannot be "
                        "stored securely. Set DATABASE_PASSWORD in the "
                        "environment instead."))
        # Each value goes where the service reads it from (CFG-01,
        # 2026-10-04): a key the application settings file (.env) holds
        # is changed THERE, since .env wins over finesiii.env; it used
        # to be written to finesiii.env and never applied. A Windows
        # environment variable, or a .env this service cannot write,
        # cannot be changed here: refused with where to change it.
        # Someone else changed one of these after the page was loaded
        # (CFG-06, 2026-10-04): nothing is written.
        stale = stale_changes(store, "machine", seen, list(normalised))
        if stale:
            raise HTTPException(status_code=409, detail=stale_message(
                stale, {k: deployment.BY_KEY[k]["label"]
                        for k in normalised}))
        in_app = deployment.read_app_env()
        app_writable = deployment.app_env_writable()
        for key in normalised:
            if key in os.environ:
                raise HTTPException(status_code=409, detail=(
                    f"{deployment.BY_KEY[key]['label']} is set by a Windows "
                    f"environment variable; change it there."))
            if key in in_app and not app_writable:
                raise HTTPException(status_code=409, detail=(
                    f"{deployment.BY_KEY[key]['label']} is set in the "
                    f"application settings file (.env in the application "
                    f"folder), which this service cannot change; change it "
                    f"there, then restart."))
        to_app = {k: v for k, v in normalised.items() if k in in_app}
        to_machine = {k: v for k, v in normalised.items() if k not in in_app}
        # Handing a .env key back to the default also removes a value
        # the machine settings file may hold for it.
        for k, v in to_app.items():
            if v is None and k in deployment.read():
                to_machine[k] = None
        # The file first, then the credential store; a failure on either
        # side leaves both as they were (BUG-045).
        file_existed = deployment.deployment_file().is_file()
        old_file = deployment.read()
        old_secrets = {}
        for skey in secrets_to_store:
            try:
                old_secrets[skey] = (vault.vault().get(skey),
                                     os.environ.get(skey))
            except Exception as e:
                raise HTTPException(
                    status_code=503,
                    detail=(f"The OS credential vault could not be read "
                            f"({type(e).__name__}) — nothing was changed."))
        app_before = None
        try:
            if to_app:
                app_before = deployment.update_app_env(to_app)
            if to_machine:
                deployment.update(to_machine)
        except (OSError, ValueError, KeyError) as e:
            if app_before is not None:
                try:
                    deployment.restore_app_env(app_before)
                except OSError:
                    pass
            raise HTTPException(
                status_code=500,
                detail=(f"The settings file could not be written "
                        f"({getattr(e, 'strerror', None) or e}) — nothing "
                        f"was changed."))
        stored = []
        try:
            for skey, pw in secrets_to_store.items():
                vault.set_secret(skey, pw)
                stored.append(skey)
        except Exception as e:
            for skey in stored + [k for k in secrets_to_store
                                  if k not in stored]:
                old_value, old_env = old_secrets[skey]
                try:
                    if old_value is None:
                        vault.vault().delete(skey)
                    else:
                        vault.vault().set(skey, old_value)
                except Exception:
                    pass
                if old_env is None:
                    os.environ.pop(skey, None)
                else:
                    os.environ[skey] = old_env
                vault._FROM_VAULT.pop(skey, None)
                if old_env is not None and old_env == old_value:
                    vault._FROM_VAULT[skey] = old_env
            try:
                if file_existed:
                    deployment.write(old_file)
                else:
                    deployment.deployment_file().unlink(missing_ok=True)
                if app_before is not None:
                    deployment.restore_app_env(app_before)
            except OSError:
                pass
            detail = (str(e) if isinstance(e, vault.VaultUnavailableError)
                      else type(e).__name__)
            raise HTTPException(
                status_code=503,
                detail=(f"The database password could not be stored in the "
                        f"OS credential vault ({detail}) — nothing was "
                        f"changed."))
        changed = sorted(k for k, v in normalised.items() if v is not None)
        cleared = sorted(k for k, v in normalised.items() if v is None)
        revision = None
        if store is not None and (changed or cleared):
            with revision_lock():
                try:
                    revision = record_revision(store, "machine",
                                               changed + cleared,
                                               user.username)
                except Exception:
                    revision = None
        _audit("deployment_changed", user,
               detail={"changed": changed, "cleared": cleared,
                       "secrets_stored": sorted(secrets_to_store),
                       "application_file": sorted(to_app),
                       "machine_file": sorted(to_machine)})
        return {"changed": changed, "cleared": cleared,
                "secrets_stored": sorted(secrets_to_store),
                "application_file": sorted(to_app),
                "machine_file": sorted(to_machine),
                "restart_required": True,
                "revision": revision,
                "note": "Restart the service to apply these."}

    def _database_targets(normalised: dict, new_secrets: dict) -> list:
        """The PostgreSQL databases this deployment change points at and
        the password to test each with (NB-005): the one typed in this
        request, or the stored one when the server is the configured or
        saved one. Only targets whose address or engine changes; a
        cleared value (falls back to what is not known here) is not
        checked."""
        saved = deployment.read()
        out = []
        for url_key, engine_key, secret_key, running, extra in (
                ("DATABASE_URL", "DATABASE_ENGINE", "DATABASE_PASSWORD",
                 cfg.database_url, ()),
                ("AUDIT_DATABASE_URL", "AUDIT_BACKEND",
                 "AUDIT_DATABASE_PASSWORD", cfg.audit_database_url,
                 ("AUDIT_ENABLED",))):
            keys = (url_key, engine_key) + extra
            if not any(k in normalised for k in keys):
                continue
            values = {}
            for k in keys:
                values[k] = (normalised[k] if k in normalised
                             else deployment.effective_value(k, cfg))
            if any(values[k] is None for k in keys):
                continue
            if extra and not _truthy(values["AUDIT_ENABLED"]):
                continue
            if str(values[engine_key]).lower() != "postgres" \
                    or not values[url_key]:
                continue
            url = str(values[url_key])
            password = new_secrets.get(secret_key, "")
            if not password and _same_database(url, running,
                                               saved.get(url_key)):
                password = os.environ.get(secret_key, "")
            out.append({"key": url_key, "url": url, "password": password})
        return out

    def _same_database(url: str, *others) -> bool:
        """The same server, user and database as one of `others` once
        passwords are left out. A URL that cannot be read matches
        nothing (never a 500)."""
        try:
            target = vault.strip_url_password(url or "")
        except ValueError:
            return False
        for other in others:
            try:
                if other and vault.strip_url_password(other) == target:
                    return True
            except ValueError:
                continue
        return False

    # ── Secrets (write-only) ──

    def _poll_after_secret(name: str) -> None:
        """A new ServiceNow password or secret is used at once (SN-03,
        2026-10-03), like a saved ServiceNow setting."""
        if name not in HOT_SECRETS:
            return
        poller = getattr(app.state, "snow_poller", None)
        if poller is not None:
            try:
                poller.poll_now()
            except Exception:
                pass

    @router.put("/secrets/{name}")
    def put_secret(name: str, body: dict = Body(...),
                   user: AppUser = Depends(require_manage)):
        try:
            vault.check_key(name)
        except KeyError as e:
            raise HTTPException(status_code=400, detail=str(e.args[0]))
        value = str((body or {}).get("value", ""))
        # Spaces alone are not a credential; they replaced the real one
        # (NB-026). Empty still clears. A real value is never trimmed.
        if value and not value.strip():
            raise HTTPException(
                status_code=400,
                detail="A credential cannot be made only of spaces. Leave "
                       "the field empty to keep the stored value.")
        # The service account's codes follow the same rules as a request
        # (E2E-M03); the value is never repeated in the answer.
        from src.modules.intake.schemas import (_EMPLOYEE_CODE_RE,
                                                _ascii_digits)
        if value and name == "FINESIII_AFFILIATION_CODE" and not (
                _ascii_digits(value) and len(value) == 5):
            raise HTTPException(
                status_code=400,
                detail="The service-account affiliation code must be 5 "
                       "half-width digits (0-9). Nothing was saved.")
        if value and name == "FINESIII_APPLICATION_ID" and \
                not _EMPLOYEE_CODE_RE.fullmatch(value):
            raise HTTPException(
                status_code=400,
                detail="The service-account staff code must be 7 half-width "
                       "letters or digits (A-Z, a-z, 0-9). Nothing was saved.")
        if not vault.vault_info()["available"]:
            raise HTTPException(
                status_code=503,
                detail="The OS credential vault is unavailable on this "
                       "machine.")
        try:
            if value:
                vault.set_secret(name, value)
            else:
                vault.delete_secret(name)
        except vault.VaultUnavailableError as e:
            raise HTTPException(status_code=503, detail=str(e))
        _audit("secret_changed", user,
               detail={"name": name, "action": "set" if value else "cleared"})
        _poll_after_secret(name)
        return {"name": name, "set": bool(value),
                "restart_required": name not in HOT_SECRETS}

    @router.delete("/secrets/{name}")
    def delete_secret(name: str,
                      user: AppUser = Depends(require_manage)):
        try:
            vault.check_key(name)
        except KeyError as e:
            raise HTTPException(status_code=400, detail=str(e.args[0]))
        # A secret an earlier version kept in the settings table can be
        # removed from there even without a credential store (NB-020):
        # the row is purged and the real environment value (if any) is
        # back in force.
        from src.modules.console.settings_store import (
            LEGACY_SECRET_ENV, clear_env_override,
        )
        store = getattr(app.state, "settings_store", None)
        legacy = False
        if name in LEGACY_SECRET_ENV and store is not None:
            try:
                legacy = name in store.all()
            except Exception:
                legacy = False
        if legacy:
            if hasattr(store, "purge"):
                store.purge(name)
            else:
                store.clear(name)
            clear_env_override(name)
        try:
            vault.delete_secret(name)
        except vault.VaultUnavailableError as e:
            if not legacy:
                raise HTTPException(status_code=503, detail=str(e))
        detail = {"name": name, "action": "cleared"}
        if legacy:
            detail["source"] = "settings_table"
        _audit("secret_changed", user, detail=detail)
        _poll_after_secret(name)
        answer = {"name": name, "set": False,
                  "restart_required": name not in HOT_SECRETS}
        if legacy:
            answer.update(
                set=bool(os.environ.get(name)), legacy=True,
                note=(f"Removed from the application database. Set {name} "
                      f"in the service environment and restart."))
        return answer

    # ── Checks ──

    @router.post("/test-database")
    def test_database(body: dict = Body(default={}),
                      user: AppUser = Depends(require_manage)):
        """Test the SUBMITTED url/password, or the running
        configuration when none is given. The password is used for the
        connection only — not stored, not echoed."""
        body = body or {}
        url = str(body.get("url", "") or "")
        engine = str(body.get("engine", "") or "")
        password = str(body.get("password", "") or "")
        # Which address is tested (NB-028): the database or the audit
        # database, each with its own stored password.
        key = str(body.get("key", "") or "DATABASE_URL")
        if key not in ("DATABASE_URL", "AUDIT_DATABASE_URL"):
            raise HTTPException(
                status_code=400,
                detail="key must be DATABASE_URL or AUDIT_DATABASE_URL")
        audit_key = key == "AUDIT_DATABASE_URL"
        secret_key = ("AUDIT_DATABASE_PASSWORD" if audit_key
                      else "DATABASE_PASSWORD")
        running = (cfg.audit_database_url if audit_key
                   else cfg.database_url) or ""
        if not url:
            if cfg.database_engine == "sqlite":
                url, engine = f"sqlite:///{cfg.sqlite_path}", "sqlite"
            else:
                url, engine = cfg.database_url, "postgres"
        else:
            if engine != "sqlite" and not url.startswith("sqlite"):
                # The same check as Save (NB-002): a password with an
                # un-encoded '#', '?' or '/' is refused before any
                # connection, and never reaches the audit trail.
                try:
                    deployment.check_url_parts("Database URL", url)
                except ValueError as e:
                    _audit("database_tested", user, "INFO",
                           detail={"ok": False, "refused": True,
                                   "engine": engine or "postgres",
                                   "url": vault.mask_url(url)})
                    return {"ok": False, "engine": engine or "postgres",
                            "server": "", "user": "", "missing_tables": [],
                            "privileges": {}, "error": str(e), "hint": ""}
            if not password and vault.url_password(url) is None:
                # The stored password is used ONLY for the configured
                # server (same user@host:port/db) — the one running or
                # the one saved for the next start. Typing another host
                # and pressing Test must never send our password there.
                if _same_database(url, running,
                                  deployment.read().get(key)):
                    password = os.environ.get(secret_key, "")
        result = deployment.check_database(url, engine=engine,
                                           password=password)
        _audit("database_tested", user, "INFO",
               detail={"ok": result["ok"], "engine": result["engine"],
                       "url": vault.mask_url(url)})
        return result

    # ── Module connection tests (sync `def`: FastAPI runs them on a
    #     worker thread so a slow remote never blocks the event loop).
    #     Typed values win; blanks fall back to what is stored/in force.
    #     Nothing is persisted and no secret is echoed. ──

    def _body_or(body: dict, key: str, env_key: str) -> str:
        value = str((body or {}).get(key, "") or "").strip()
        return value or _effective(env_key)

    def _same_target(a: str, b: str) -> bool:
        """Two endpoints are the same when they match after trimming,
        lower-casing and dropping a trailing slash. Blank never matches."""
        a = str(a or "").strip().lower().rstrip("/")
        b = str(b or "").strip().lower().rstrip("/")
        return bool(a) and a == b

    def _stored_secret(name: str, *targets) -> str:
        """A secret from the vault, for a connection test — ONLY when
        every endpoint the test will contact is the CONFIGURED one
        (same rule as test-database). Typing another host and pressing
        Test must never send our secret there; the caller then has to
        type the secret. `targets` are (value_in_use, configured) pairs."""
        for in_use, configured in targets:
            if not _same_target(in_use, configured):
                return ""
        return os.environ.get(name, "")

    STORED_SECRET_NOTE = ("The stored secret is only used with the saved "
                          "address. To test a different address, type "
                          "the password/secret as well.")

    def _snow_targets(instance: str, token_url: str, method: str) -> list:
        """(in use, configured) endpoint pairs a ServiceNow call contacts:
        the instance, and for OAuth the EFFECTIVE token URL (the typed
        one, or <instance>/oauth_token.do)."""
        conf_instance = _effective("SNOW_INSTANCE_URL")
        pairs = [(instance, conf_instance)]
        if str(method or "").startswith("oauth"):
            def token(inst, tok):
                inst = str(inst or "").strip().rstrip("/")
                return str(tok or "").strip() or (
                    inst + "/oauth_token.do" if inst else "")
            pairs.append((token(instance, token_url),
                          token(conf_instance, _effective("SNOW_TOKEN_URL"))))
        return pairs

    def _servicenow_settings_from(body: dict, timeout: float):
        """ServiceNowSettings for a connection test, from what the page
        holds (typed values win, blanks fall back to stored/in-force;
        secrets typed on the page win over the vault). Returns
        (settings, error)."""
        from src.integrations.servicenow.config import ServiceNowSettings

        body = body or {}
        instance = _body_or(body, "instance_url", "SNOW_INSTANCE_URL")
        method = (_body_or(body, "auth_method", "SNOW_AUTH_METHOD")
                  or "basic").lower()
        if method == "oauth":
            method = "oauth_password"
        username = _body_or(body, "username", "SNOW_USERNAME")
        client_id = _body_or(body, "client_id", "SNOW_CLIENT_ID")
        token_url = _body_or(body, "token_url", "SNOW_TOKEN_URL")
        table = _body_or(body, "table", "SNOW_TABLE") or "sc_task"
        if not instance:
            return None, "Instance URL is required for the test"
        # The same address rules as when the settings are saved (X-08,
        # 2026-10-03): https and a plain host, http for this machine only.
        from src.core.urls import web_address_problem
        for label, value, path_allowed in (
                ("Instance URL", instance, False),
                ("OAuth token URL", token_url, True)):
            problem = web_address_problem(value, path_allowed=path_allowed)
            if problem:
                return None, f"{label} {problem}"
        if not re.match(r"^[A-Za-z0-9_]+$", table):
            return None, "Ticket table: a table name such as sc_task"
        # Stored secrets go ONLY to the configured instance and token
        # endpoint (SN-01): both the instance and the effective token
        # URL must be the saved ones.
        targets = _snow_targets(instance, token_url, method)
        password = str(body.get("password", "") or "") \
            or _stored_secret("SNOW_PASSWORD", *targets)
        client_secret = str(body.get("client_secret", "") or "") \
            or _stored_secret("SNOW_CLIENT_SECRET", *targets)
        foreign = not all(_same_target(a, b) for a, b in targets)
        note = (" " + STORED_SECRET_NOTE) if foreign else ""
        if method == "basic" and not (username and password):
            return None, ("Username and password are required for basic "
                          "authentication." + note)
        if method == "oauth_password" and not (
                client_id and client_secret and username and password):
            return None, ("OAuth with the bot account needs the client ID, "
                          "client secret, username and password." + note)
        if method == "oauth_client_credentials" and not (
                client_id and client_secret):
            return None, ("OAuth client credentials need the client ID and "
                          "client secret." + note)
        if method not in ("basic", "oauth_password",
                          "oauth_client_credentials"):
            return None, f"Unknown authentication type '{method}'"
        settings = ServiceNowSettings(
            instance_url=instance.rstrip("/"), auth_method=method,
            username=username, password=password, client_id=client_id,
            client_secret=client_secret, token_url=token_url, table=table,
            http_timeout_seconds=timeout, max_retries=0)
        return settings, ""

    def _typed_or(body: dict, key: str, env_key: str) -> str:
        """A ticket filter for a connection test: the value on the page
        when the page sent the field (blank = no filter, as when saved),
        otherwise the value in force."""
        if isinstance(body, dict) and key in body:
            return str(body.get(key) or "").strip()
        return _effective(env_key)

    def _snow_selection(body: dict) -> dict:
        """Bot account, mode, group, Requested For and its field for a
        connection test: the values on the page, else the values in
        force. A blank filter is a filter that is not applied."""
        defaults = None
        try:
            from src.integrations.servicenow.config import (
                load_servicenow_config,
            )
            defaults = load_servicenow_config()
        except Exception:
            pass
        from src.integrations.servicenow.config import split_requested_for
        raw_rf = _typed_or(body, "requested_for", "SNOW_REQUESTED_FOR")
        values = split_requested_for(raw_rf)
        mode = _body_or(body, "assignment_mode", "SNOW_ASSIGNMENT_MODE") \
            or (getattr(defaults, "assignment_mode", "") if defaults else "")
        return {
            "requested_for_field": _typed_or(
                body, "requested_for_field", "SNOW_REQUESTED_FOR_FIELD"),
            "assigned_to": _typed_or(body, "assigned_to", "SNOW_ASSIGNED_TO"),
            "mode": str(mode or "assigned_to").strip().lower(),
            "group": _typed_or(body, "assignment_group",
                               "SNOW_ASSIGNMENT_GROUP"),
            "requested_for": [] if values == ["*"] else values,
        }

    def _check_selection(client, selection, users, result) -> None:
        """The ticket filters, read-only: whether the bot account is a
        member of the group, who each Requested For value names, and how
        many open tickets are left after each filter that is filled in.
        Each answer is shown on the page; a read the account may not do
        is said so."""
        import re as _re
        from src.integrations.servicenow.client import ServiceNowError
        notes = list(result.get("notes") or [])
        sys_id_re = r"^[0-9a-fA-F]{32}$"
        bot = str(users[0].get("sys_id", "")) if users else ""
        group = selection["group"]
        result["group_member"] = None
        if bot and group and not any(c in group for c in "^=\n\r"):
            field = "group" if _re.match(sys_id_re, group) else "group.name"
            try:
                rows = client.get_records(
                    "sys_user_grmember", f"user={bot}^{field}={group}",
                    fields=["sys_id"], limit=1)
                result["group_member"] = bool(rows)
                if not rows:
                    notes.append(f"The bot account is not a member of the "
                                 f"group '{group}'. ServiceNow may refuse "
                                 f"to assign the tickets to it.")
            except ServiceNowError:
                notes.append("The group membership could not be read with "
                             "this account; please confirm it in "
                             "ServiceNow.")
        found = []
        for value in selection["requested_for"]:
            if any(c in value for c in "^=\n\r"):
                found.append({"value": value, "matches": 0})
                notes.append(f"Requested For '{value}' is not allowed.")
                continue
            query = (f"sys_id={value}" if _re.match(sys_id_re, value)
                     else f"name={value}")
            try:
                rows = client.get_records(
                    "sys_user", query,
                    fields=["sys_id", "name", "user_name"], limit=2)
            except ServiceNowError:
                found.append({"value": value, "matches": None})
                notes.append(f"Requested For '{value}' could not be looked "
                             f"up with this account. The bot still compares "
                             f"the name shown on each ticket.")
                continue
            found.append({"value": value, "matches": len(rows),
                          "sys_id": rows[0].get("sys_id", "") if rows else "",
                          "name": rows[0].get("name", "") if rows else ""})
            if not rows:
                notes.append(f"No ServiceNow user is named '{value}'. No "
                             f"ticket will match the Requested For filter.")
            elif len(rows) > 1:
                notes.append(f"Several users are named '{value}'. Enter "
                             f"the sys_id instead.")
        # Two values that match nobody but name a user together: a name
        # with a comma that was split.
        for a, b in zip(found, found[1:]):
            if a.get("matches") == 0 and b.get("matches") == 0:
                joined = f"{a['value']}, {b['value']}"
                try:
                    rows = client.get_records(
                        "sys_user", f"name={joined}", fields=["sys_id"],
                        limit=1)
                except ServiceNowError:
                    rows = []
                if rows:
                    notes.append(f"'{joined}' is one user: separate the "
                                 f"users with ; so the comma stays in the "
                                 f"name (for example: {joined};), or enter "
                                 f"the sys_id.")
        result["requested_for"] = found
        notes += _selection_counts(client, selection, bot, result)
        result["notes"] = notes

    # How many tickets the bot checks itself for Requested For.
    SELECTION_SAMPLE_LIMIT = 1000

    def _selection_counts(client, selection, bot_sys_id, result) -> list:
        """The open tickets left after each filter that is filled in, in
        the order the bot applies them, and what the Requested For
        fields hold on them, so a filter that removes every ticket shows
        where. Read-only. Returns notes for the page."""
        from src.integrations.servicenow.client import ServiceNowError
        from src.integrations.servicenow.config import load_servicenow_config
        try:
            s = load_servicenow_config()
        except Exception:
            return []
        s.assignment_mode = selection["mode"]
        s.assignment_group = selection["group"]
        s.assigned_to = selection["assigned_to"]
        s.bot_sys_id = bot_sys_id if s.bot_filter else ""
        s.requested_for = list(selection["requested_for"])
        s.requested_for_field = selection["requested_for_field"]
        if s.selection_problems() or s.requested_for_problems():
            return []
        result["filters"] = s.filter_summary()
        steps = [("Open tickets in the table", "active=true")]
        query = "active=true"
        if s.assignment_group:
            query += f"^{s.assignment_field}={s.assignment_group}"
            steps.append((f"In the group '{s.assignment_group}'", query))
        if s.bot_filter:
            query += "^" + s.assignee_clause()
            steps.append(("Assigned to the bot account"
                          if s.assignment_mode == "assigned_to"
                          else "Unassigned or the bot account's", query))
        if s.require_approval and s.approval_filter_ok():
            query += "^" + s.approval_filter.strip()
            steps.append(("Approved", query))
        if s.open_states:
            query += "^stateIN" + ",".join(str(x) for x in s.open_states)
            steps.append(("In the open states", query))
        counts = []
        try:
            for label, q in steps:
                counts.append({"step": label, "by": "servicenow",
                               "count": client.count_records(s.table, q)})
        except ServiceNowError:
            result["selection_counts"] = counts
            return ["The tickets could not be counted with this account."]
        notes = []
        last = counts[-1]["count"] if counts else 0
        if s.requested_for:
            # Checked by the bot on each ticket, as the poll does.
            fields = s.selection_fields()
            try:
                rows = client.get_records(
                    s.table, query, fields=["sys_id"] + fields,
                    limit=SELECTION_SAMPLE_LIMIT, display_value="all")
            except ServiceNowError:
                rows = None
            if rows is None:
                counts.append({"step": "Requested For", "by": "bot",
                               "count": None})
                notes.append("The Requested For fields could not be read "
                             "with this account.")
            else:
                check = load_servicenow_config()
                check.assignment_group = ""
                check.requested_for = s.requested_for
                check.requested_for_field = s.requested_for_field
                kept = [r for r in rows if not check.selection_mismatch(r)]
                counts.append({"step": "Requested For", "by": "bot",
                               "count": len(kept),
                               "of": len(rows),
                               "capped": len(rows) >= SELECTION_SAMPLE_LIMIT})
                tally = {}
                for row in rows:
                    for fld, value in check.requested_for_found(row) or \
                            [(", ".join(check.requested_for_fields()), "")]:
                        key = (fld, value or "(empty)")
                        tally[key] = tally.get(key, 0) + 1
                result["requested_for_sample"] = [
                    {"field": f, "value": v, "tickets": n}
                    for (f, v), n in sorted(tally.items(),
                                            key=lambda x: -x[1])][:10]
                if rows and not kept:
                    notes.append("None of these tickets is requested for "
                                 "the Requested For value(s). The values "
                                 "the tickets hold are listed below.")
                last = len(kept)
        result["selection_counts"] = counts
        result["would_read"] = last
        if counts and counts[0]["count"] == 0:
            notes.append(f"No open ticket in the table '{s.table}' is "
                         f"readable with this account.")
        elif s.assignment_group and len(counts) > 1 and \
                counts[1]["count"] == 0:
            notes.append(f"No open ticket is in the group "
                         f"'{s.assignment_group}'. Check the group name, "
                         f"or enter its sys_id.")
        if not (s.assignment_group or s.bot_filter or s.requested_for):
            notes.append("No group, Bot account or Requested For is set: "
                         "every open ticket of the table is read (up to "
                         "the fetch limit per poll). Set at least the "
                         "group in production.")
        if s.bot_filter and not s.bot_ref:
            notes.append(f"The Bot account '{s.bot_filter}' was not found "
                         f"in ServiceNow, so tickets assigned to it cannot "
                         f"be matched. Enter its user name or sys_id.")
        return notes

    @router.post("/test-servicenow")
    def test_servicenow(body: dict = Body(default={}),
                        user: AppUser = Depends(require_manage)):
        from src.integrations.servicenow.client import (
            ServiceNowClient, ServiceNowError,
        )

        settings, error = _servicenow_settings_from(body, 15.0)
        result = {"ok": False, "account": None, "table_ok": False,
                  "error": error, "hint": "", "token_ok": None,
                  "instance_url": (settings.instance_url if settings
                                   else _body_or(body, "instance_url",
                                                 "SNOW_INSTANCE_URL")),
                  "auth_method": settings.auth_method if settings else "",
                  "table": settings.table if settings else ""}
        if settings is None:
            return result
        client = ServiceNowClient(settings, logger=logger,
                                  sleep_func=lambda s: None)
        # Ticket filters as on the page (a blank one is not applied).
        # The account checked is the one tickets are assigned to: the
        # Bot account, or the sign-in user name when it is blank.
        selection = _snow_selection(body)
        result["notes"] = []
        # Which call failed decides the hint: a 404 on the first Table
        # API call means the address is not a ServiceNow instance, not a
        # missing ticket table.
        step = "sign_in"
        try:
            if settings.uses_oauth:
                client._ensure_token()
                result["token_ok"] = True
            step = "account"
            lookup = selection["assigned_to"] or settings.username
            if any(c in lookup for c in "^=\n\r"):
                raise ValueError(f"Bot account '{lookup}' contains a "
                                 f"character that is not allowed (^ =)")
            # A sys_id, a user name, or the name shown on a form (used
            # when exactly one user has it).
            by_sys_id = bool(re.match(r"^[0-9a-fA-F]{32}$", lookup))
            fields = ["user_name", "sys_id", "name", "active"]
            users = client.get_records(
                "sys_user",
                f"sys_id={lookup}" if by_sys_id else f"user_name={lookup}",
                fields=fields, limit=1) if lookup else []
            if lookup and not users and not by_sys_id:
                named = client.get_records("sys_user", f"name={lookup}",
                                           fields=fields, limit=2)
                users = named if len(named) == 1 else []
                if len(named) > 1:
                    result["notes"].append(
                        f"Several users are named '{lookup}'. Enter the "
                        f"bot account's user name or sys_id.")
            result["account"] = ({"user_name": users[0].get("user_name"),
                                  "sys_id": users[0].get("sys_id"),
                                  "name": users[0].get("name"),
                                  "active": users[0].get("active")}
                                 if users else None)
            result["account_source"] = ("bot_account"
                                        if selection["assigned_to"]
                                        else "sign_in" if lookup else "")
            step = "table"
            client.get_records(settings.table, "", fields=["sys_id"], limit=1)
            result["table_ok"] = True
            result["ok"] = True
            if lookup and not users:
                result["notes"].append(
                    f"No ServiceNow user is '{lookup}'. Tickets cannot be "
                    f"assigned to the bot until the account is found.")
            elif users and str(users[0].get("active", "")).strip().lower() \
                    in ("false", "0"):
                result["notes"].append(
                    "The bot account is inactive in ServiceNow. Tickets "
                    "cannot be assigned to it until it is activated.")
            elif not lookup:
                result["notes"].append(
                    "Signed in with client credentials, which have no user "
                    "name. Enter the Bot account so tickets can be "
                    "assigned to the bot.")
            _check_selection(client, selection, users, result)
            result["hint"] = " ".join(result["notes"])
        except ServiceNowError as e:
            text = str(e)
            result["error"] = public_error(text, logger, "ServiceNow")
            low = text.lower()
            if "oauth token" in low and "network" in low:
                result["token_ok"] = False
                result["hint"] = ("The token endpoint is unreachable from "
                                  "this machine — check the instance URL, "
                                  "the token URL and the proxy.")
            elif "oauth token" in low:
                result["token_ok"] = False
                result["hint"] = ("The instance refused the OAuth token "
                                  "request — check the client ID/secret, "
                                  "the grant type enabled on the "
                                  "application registry, and the bot "
                                  "account for the password grant.")
            elif " 401" in low or " 403" in low:
                result["hint"] = "Credentials rejected."
            elif (" 404" in low or " 400" in low) and step != "table" \
                    and "invalid table" not in low:
                result["hint"] = ("The address answered, but not as a "
                                  "ServiceNow instance (no Table API) — "
                                  "check the instance URL.")
            elif " 404" in low or (" 400" in low and "invalid table" in low):
                # ServiceNow answers an unknown table with 400 "Invalid
                # table" on current releases (2026-09-28).
                result["hint"] = f"Table '{settings.table}' does not exist."
            elif "network" in low:
                result["hint"] = "The instance is unreachable from this " \
                                 "machine — check the URL and proxy."
        except Exception as e:
            result["error"] = plain_error(e)
        _audit("servicenow_tested", user, "INFO",
               detail={"ok": result["ok"], "instance_url": settings.instance_url,
                       "auth_method": settings.auth_method})
        return result

    @router.post("/discover-servicenow")
    def discover_servicenow(body: dict = Body(default={}),
                            user: AppUser = Depends(require_manage)):
        """A couple of raw tickets, so the u_* field names in
        servicenow.yaml can be confirmed. Values are truncated and any
        password-like field is masked."""
        from src.integrations.servicenow.client import (
            ServiceNowClient, ServiceNowError,
        )
        from src.integrations.servicenow.config import load_servicenow_config

        from src.core.app_paths import config_path

        try:
            # Connection identity comes from the guarded helper (stored
            # secrets only for the configured endpoints, SN-01); the
            # fetch/mapping structure comes from servicenow.yaml.
            tested, error = _servicenow_settings_from(body, 20.0)
            if tested is None:
                return {"ok": False, "error": error, "fields": [],
                        "sample": []}
            settings = load_servicenow_config()
            for key in ("instance_url", "auth_method", "username",
                        "password", "client_id", "client_secret",
                        "token_url", "table"):
                setattr(settings, key, getattr(tested, key))
            settings.http_timeout_seconds = 20.0
            settings.max_retries = 0
            client = ServiceNowClient(settings, logger=logger,
                                      sleep_func=lambda s: None)
            sample = client.fetch_raw_sample(limit=2)
        except (ServiceNowError, ValueError) as e:
            return {"ok": False,
                    "error": public_error(e, logger, "ServiceNow discover"),
                    "fields": [], "sample": []}
        except Exception as e:
            return {"ok": False, "error": plain_error(e),
                    "fields": [], "sample": []}
        if not sample:
            # Nothing to inspect: no conclusion about the mapping (SN-11).
            return {"ok": True, "fields": [], "sample": [], "mapped": {},
                    "empty": True,
                    "config_file": config_path("servicenow.yaml").name,
                    "query": settings.build_query()}
        fields = sorted({k for t in sample for k in t.keys()})
        # Field names and whether each holds a value — never the values
        # themselves (names, employee details, descriptions; SN-08,
        # 2026-10-03). The page needs nothing more.
        cleaned = [{k: v not in (None, "", [], {}) for k, v in t.items()}
                   for t in sample]
        sampled = [str(t.get("number") or t.get("sys_id") or "")
                   for t in sample]
        # SailPoint tasks: their catalog variables too (2026-09-28), so
        # the variable labels in the settings can be confirmed here.
        variables, expected, filled = [], {}, {}
        if settings.ticket_format == "sailpoint":
            from src.integrations.servicenow.sailpoint import (
                has_variable, variable,
            )
            for t in sample:
                try:
                    rows = client.fetch_variables(t)
                except Exception:
                    rows = []
                variables.append([
                    {"label": r["label"], "name": r["name"],
                     "has_value": r["value"] not in (None, "")}
                    for r in rows])
                # Found = the variable is on the ticket, even when it is
                # empty there (2026-09-28); filled = it has a value.
                for key, labels in (settings.sp_variables or {}).items():
                    if has_variable(rows, labels):
                        expected[key] = True
                    if variable(rows, labels):
                        filled[key] = True
            for key in (settings.sp_variables or {}):
                expected.setdefault(key, False)
        _audit("servicenow_discovered", user, "INFO",
               detail={"fields": len(fields), "tickets": sampled})
        # The mapping in force and where it is edited on THIS machine
        # (the installed app reads the seeded copy in the data directory).
        mapped = {k: v.split(".")[-1] if isinstance(v, str) else v
                  for k, v in (settings.field_mapping or {}).items()
                  if k != "ticket_number"}
        return {"ok": True, "fields": fields, "sample": cleaned,
                "mapped": mapped,
                "ticket_format": settings.ticket_format,
                "variables": variables,
                # {setting: found in the sample} for the SailPoint labels
                "variables_found": expected,
                # Settings whose variable is on the tickets but empty on
                # every sample ticket (found, but nothing to read).
                "variables_empty": sorted(k for k, v in expected.items()
                                          if v and not filled.get(k)),
                "config_file": config_path("servicenow.yaml").name,
                "query": settings.build_query()}

    @router.post("/test-email")
    def test_email(body: dict = Body(default={}),
                   user: AppUser = Depends(require_manage)):
        """Send test e-mail, or (send: false) Test connection only —
        connect, secure and log in, nothing sent (2026-09-29). Uses the
        values on screen, before they are saved."""
        import dataclasses

        from src.modules.notifications.audiences import split_addresses
        from src.modules.notifications.config import (
            SECURITY_MODES, load_notification_config,
        )
        from src.modules.notifications.diagnostics import (
            explain, send_test_email,
        )
        from src.modules.notifications.notifier import (
            EmailNotifier, NotificationError, valid_address,
        )

        body = body or {}
        send = body.get("send", True) not in (False, "false", "0", 0)
        # No test recipient typed: the Default recipients (E2E-L16).
        recipients = split_addresses(_body_or(body, "to", "ALERT_TO"))
        if len(recipients) > MAX_TEST_RECIPIENTS:
            return {"ok": False,
                    "error": (f"A test e-mail goes to at most "
                              f"{MAX_TEST_RECIPIENTS} addresses.")}
        if send:
            if not recipients:
                return {"ok": False, "error": "Enter a recipient address."}
            bad = [a for a in recipients if not valid_address(a)]
            if bad:
                return {"ok": False,
                        "error": f"Not an e-mail address: {bad[0]}"}
        settings = load_notification_config()
        host = _body_or(body, "host", "SMTP_HOST")
        port_raw = _body_or(body, "port", "SMTP_PORT") or "587"
        try:
            port = int(port_raw)
        except ValueError:
            return {"ok": False, "error": "Port must be a number."}
        username = _body_or(body, "username", "SMTP_USERNAME")
        # Stored SMTP password only for the configured relay (SEC-03).
        password = str(body.get("password", "") or "") \
            or _stored_secret(
                "SMTP_PASSWORD",
                (host, _effective("SMTP_HOST")),
                (str(port), _effective("SMTP_PORT") or "587"))
        mail_from = _body_or(body, "from", "ALERT_FROM")
        # Connection security: the choice on screen, else the saved one;
        # the earlier two switches when neither is set.
        security = str(body.get("security") or "").strip().lower()
        use_ssl_raw = body.get("use_ssl")
        use_tls_raw = body.get("use_starttls")
        if security not in SECURITY_MODES and use_ssl_raw is None \
                and use_tls_raw is None:
            security = _effective("SMTP_SECURITY").strip().lower()
        if security not in SECURITY_MODES:
            security = ""
        use_ssl = (_truthy(use_ssl_raw) if use_ssl_raw is not None
                   else (_truthy(_effective("SMTP_USE_SSL"))
                         if _effective("SMTP_USE_SSL") else port == 465))
        use_starttls = (_truthy(use_tls_raw) if use_tls_raw is not None
                        else (_truthy(_effective("SMTP_USE_STARTTLS"))
                              if _effective("SMTP_USE_STARTTLS")
                              else not use_ssl))
        if not security and not (use_ssl and use_starttls):
            security = ("ssl" if use_ssl else
                        ("starttls_if_offered" if port == 25
                         and not _effective("SMTP_USE_STARTTLS")
                         and use_tls_raw is None else "starttls")
                        if use_starttls else "none")
        verify_raw = body.get("verify_cert")
        verify = (_truthy(verify_raw) if verify_raw not in (None, "")
                  else (_truthy(_effective("SMTP_VERIFY_CERT"))
                        if _effective("SMTP_VERIFY_CERT") else True))
        # The stored password is only sent over a checked connection
        # (X-08, 2026-10-03); to test without checking, type it.
        if password and not str(body.get("password", "") or "") \
                and not verify:
            return {"ok": False,
                    "error": ("Certificate checking cannot be switched off "
                              "for a test with the stored password. Switch "
                              "'Check the server certificate' on, or type "
                              "the password for this test.")}
        if not host or (send and not mail_from):
            return {"ok": False,
                    "error": "SMTP host and From address are required."}
        settings = dataclasses.replace(
            settings, enabled=True, smtp_host=host, smtp_port=port,
            username=username, password=password,
            mail_from=mail_from or "test@example.com",
            security=security, use_ssl=use_ssl, use_starttls=use_starttls,
            verify_tls=verify,
            ca_file=_body_or(body, "ca_file", "SMTP_CA_FILE"),
            local_hostname=_body_or(body, "ehlo_name", "SMTP_EHLO_NAME"),
            async_send=False,
            # The test goes to the typed addresses only, so it works before
            # any default recipients are saved (WIZ-MAIL).
            recipients_to=recipients or ["test@example.com"],
            recipients_cc=[], environment_label=cfg.mainframe_environment,
            # The configured time-out, as real sending uses (EM-04).
            dry_run=False, max_retries=0,
            timeout_seconds=float(getattr(settings, "timeout_seconds", 0)
                                  or 20.0),
            # The port was checked above; a stored invalid one is
            # replaced by what is tested.
            config_error="")
        result = {"ok": False, "to": ", ".join(recipients), "host": host,
                  "port": port, "security": settings.effective_security,
                  "sent": False}
        try:
            settings.validate()
            notifier = EmailNotifier(settings, logger=logger)
            # The console Branding page applies to the test e-mail as to
            # every other one (BUG-058), so the design can be checked.
            store = getattr(app.state, "settings_store", None)
            if store is not None:
                from src.modules.console import branding as _branding
                notifier.branding_source = lambda: _branding.load(store)
            if send:
                sent = send_test_email(notifier, user.username, recipients)
                result.update(ok=bool(sent), sent=bool(sent),
                              error="" if sent else "Not sent (no recipients?)")
            else:
                info = notifier.check_connection()
                result.update(ok=True, **{k: v for k, v in info.items()
                                         if k != "security"})
        except (NotificationError, ValueError, OSError,
                smtplib.SMTPException) as e:
            cause = e.__cause__ or e.__context__ or e
            result.update(ok=False,
                          error=public_error(e, logger, "E-mail"),
                          hint=explain(cause) or explain(e))
        _audit("email_tested", user, "INFO",
               detail={"ok": result["ok"], "host": host,
                       "to": result["to"], "send": send,
                       "security": result["security"]})
        return result

    # ── E-mail checks (2026-09-29, ET1–ET5) ──
    # Built by the application's own e-mail code. Nothing reaches the
    # real recipients: previews are not sent, a sample goes only to the
    # typed addresses.

    def _email_context():
        from src.modules.notifications.config import load_notification_config
        settings = load_notification_config()
        settings.environment_label = cfg.mainframe_environment
        store = getattr(app.state, "settings_store", None)
        branding = None
        if store is not None:
            from src.modules.console import branding as _branding
            branding = lambda: _branding.load(store)       # noqa: E731
        return settings, branding

    def _email_args(body: dict) -> dict:
        return {k: str((body or {}).get(k) or "").strip()
                for k in ("kind", "language", "system", "rule")}

    @router.get("/email/status")
    def email_status(user: AppUser = Depends(require_manage)):
        from src.modules.notifications import checks
        settings, branding = _email_context()
        return checks.status(branding, settings=settings)

    @router.get("/email/routing")
    def email_routing(user: AppUser = Depends(require_manage)):
        from src.modules.notifications import checks
        settings, branding = _email_context()
        return {"emails": checks.routing(branding, settings=settings)}

    @router.post("/email/preview")
    def email_preview(body: dict = Body(default={}),
                      user: AppUser = Depends(require_manage)):
        from src.modules.notifications import checks
        settings, branding = _email_context()
        args = _email_args(body)
        try:
            result = checks.preview(branding_source=branding,
                                    settings=settings, user=user.username,
                                    **args)
        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e))
        _audit("email_previewed", user, "INFO",
               detail={"kind": args["kind"], "system": args["system"],
                       "rule": args["rule"]})
        return result

    @router.post("/email/send-sample")
    def email_send_sample(body: dict = Body(default={}),
                          user: AppUser = Depends(require_manage)):
        from src.modules.notifications import checks
        from src.modules.notifications.audiences import split_addresses
        from src.modules.notifications.diagnostics import explain
        from src.modules.notifications.notifier import valid_address
        settings, branding = _email_context()
        args = _email_args(body)
        recipients = split_addresses((body or {}).get("to", ""))
        if not recipients:
            raise HTTPException(status_code=400,
                                detail="Enter the test recipient address(es).")
        bad = [a for a in recipients if not valid_address(a)]
        if bad:
            raise HTTPException(status_code=400,
                                detail=f"Not an e-mail address: {bad[0]}")
        if not settings.smtp_host:
            raise HTTPException(status_code=400,
                                detail="The mail server is not set "
                                       "(Settings > E-mail).")
        try:
            result = {"ok": True, **checks.send_sample(
                recipients=recipients, branding_source=branding,
                settings=settings, user=user.username, **args)}
        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e))
        except (OSError, smtplib.SMTPException) as e:
            result = {"ok": False, "kind": args["kind"],
                      "error": str(e)[:300], "hint": explain(e)}
        _audit("email_sample_sent", user, "INFO" if result["ok"] else "WARNING",
               detail={"kind": args["kind"], "ok": result["ok"],
                       "to": ", ".join(recipients)})
        return result

    @router.get("/email/outbox")
    def email_outbox(user: AppUser = Depends(require_manage)):
        from src.modules.notifications import notifier
        box = notifier.get_outbox()
        if box is None:
            return {"active": False, "waiting": 0, "emails": []}
        return {"active": True, "keep_hours": box.keep_hours,
                "waiting": box.pending(), "emails": box.list()}

    @router.post("/email/outbox/retry")
    def email_outbox_retry(user: AppUser = Depends(require_manage)):
        from src.modules.notifications import notifier
        box = notifier.get_outbox()
        if box is None:
            raise HTTPException(status_code=409,
                                detail="The e-mail outbox is not active "
                                       "(e-mail switched off, or kept "
                                       "hours set to 0).")
        result = box.run_once()
        _audit("email_outbox_retried", user, "INFO", detail=dict(result))
        return result

    @router.delete("/email/outbox/{entry_id}")
    def email_outbox_delete(entry_id: str,
                            user: AppUser = Depends(require_manage)):
        """Remove one kept e-mail that should not be sent any more
        (EM-05, 2026-10-03). Recorded in the audit trail."""
        from src.modules.notifications import notifier
        box = notifier.get_outbox()
        if box is None:
            raise HTTPException(status_code=409,
                                detail="The e-mail outbox is not active.")
        try:
            removed = box.delete(entry_id)
        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e))
        if not removed:
            raise HTTPException(status_code=404,
                                detail="No such e-mail in the outbox.")
        _audit("email_outbox_deleted", user, "WARNING",
               detail={"id": entry_id, "subject": removed.get("subject", ""),
                       "kind": removed.get("kind", "")})
        return {"deleted": entry_id, "waiting": box.pending()}

    @router.post("/test-cyberark")
    def test_cyberark(body: dict = Body(default={}),
                      user: AppUser = Depends(require_manage)):
        import dataclasses

        from src.integrations.cyberark.client import (
            CyberArkClient, CyberArkError,
        )
        from src.integrations.cyberark.config import load_cyberark_config

        try:
            settings = load_cyberark_config()
        except Exception as e:
            return {"ok": False, "error": f"cyberark.yaml: {e}"}
        overrides = {}
        mapping = {"api_style": "CYBERARK_API_STYLE",
                   "base_url": "CYBERARK_BASE_URL",
                   "app_id": "CYBERARK_APP_ID", "safe": "CYBERARK_SAFE",
                   "object_name": "CYBERARK_OBJECT",
                   "account_username": "CYBERARK_ACCOUNT_USERNAME",
                   "pvwa_username": "CYBERARK_PVWA_USER",
                   "pvwa_auth_type": "CYBERARK_PVWA_AUTH_TYPE",
                   "client_cert_path": "CYBERARK_CERT_PATH",
                   "client_key_path": "CYBERARK_KEY_PATH"}
        for field, env_key in mapping.items():
            value = _body_or(body, field, env_key)
            if value:
                overrides[field] = value
        verify_raw = (body or {}).get("verify_tls")
        if verify_raw is not None:
            overrides["verify_tls"] = _truthy(verify_raw)
        elif _effective("CYBERARK_VERIFY_TLS"):
            overrides["verify_tls"] = _truthy(_effective("CYBERARK_VERIFY_TLS"))
        # Stored PVWA password only for the configured vault (SEC-04).
        # The configured address is what is in force (console/env), or
        # cyberark.yaml when neither sets it.
        configured_base = _effective("CYBERARK_BASE_URL") or settings.base_url
        in_use_base = overrides.get("base_url", settings.base_url)
        pvwa_pw = str((body or {}).get("pvwa_password", "") or "") \
            or _stored_secret("CYBERARK_PVWA_PASSWORD",
                              (in_use_base, configured_base))
        # Never inherit a password the loader read from the environment
        # when the address is not the configured one.
        overrides["pvwa_password"] = pvwa_pw
        settings = dataclasses.replace(
            settings, enabled=True, http_timeout_seconds=15.0,
            max_retries=0, **overrides)
        # The length of the retrieved password is no longer returned
        # (X-08, 2026-10-03): only whether one was retrieved.
        result = {"ok": False, "api_style": settings.api_style,
                  "base_url": settings.base_url, "available": None,
                  "retrieved": False, "error": "", "hint": ""}
        # The stored PVWA password is only sent over a checked
        # connection (X-08); to test without checking, type it.
        if pvwa_pw and not str((body or {}).get("pvwa_password", "") or "") \
                and settings.api_style == "pvwa" and not settings.verify_tls:
            result["error"] = ("Certificate checking cannot be switched off "
                               "for a test with the stored PVWA password. "
                               "Switch 'Verify TLS certificate' on, or type "
                               "the password for this test.")
            return result
        try:
            # The same address rules as when the settings are saved.
            settings.validate(
                require_verified_tls=bool(getattr(cfg, "require_cyberark",
                                                  False)))
            client = CyberArkClient(settings, logger=logger,
                                    sleep_func=lambda s: None)
            result["available"] = client.check_availability()
            password = client.fetch_password()
            result["retrieved"] = bool(password)
            result["ok"] = bool(password)
            del password
        except CyberArkError as e:
            text = str(e)
            result["error"] = public_error(text, logger, "CyberArk")
            low = text.lower()
            if "inactive" in low or "availability" in low:
                result["hint"] = ("The vault did not answer — check the "
                                  "base URL, TLS and network.")
            elif " 403" in low or " 401" in low:
                result["hint"] = ("Access denied — check the Application "
                                  "ID, the allowed-machine rules and the "
                                  "client certificate.")
            elif "no content" in low or "no account" in low:
                result["hint"] = "Check the Safe and the object/account name."
        except ValueError as e:
            result["error"] = str(e)[:300]
        except Exception as e:
            result["error"] = plain_error(e)
        _audit("cyberark_tested", user, "INFO",
               detail={"ok": result["ok"], "base_url": settings.base_url,
                       "api_style": settings.api_style})
        return result

    def _mainframe_reach(host: str, port: int) -> dict:
        """TCP reachability of the mainframe host (no sign-in)."""
        import socket
        if not host:
            return {"ok": True, "host": "", "port": port,
                    "note": "No mainframe host configured — the "
                            "availability probe assumes reachable."}
        started = time.time()
        try:
            with socket.create_connection((host, port), timeout=5):
                pass
            return {"ok": True, "host": host, "port": port,
                    "latency_ms": int((time.time() - started) * 1000)}
        except OSError as e:
            return {"ok": False, "host": host, "port": port,
                    "error": str(e)[:200],
                    "hint": "Check the host name, port and firewall from "
                            "this machine."}

    @router.post("/test-terminal")
    def test_terminal(body: dict = Body(default={}),
                      user: AppUser = Depends(require_manage)):
        """Terminal check (2026-09-29, T1/T2). level "launch": start the
        terminal and close it, no sign-in. level "navigate" (confirm:
        true): sign in once and open Task 903 — no data typed, never '00'
        at the execution field or '70' — then sign off. Only while
        processing is paused and no request is running."""
        from src.rpa.terminal_check import LEVELS, SUPPORTED_DRIVERS
        body = body or {}
        level = str(body.get("level") or "launch").strip().lower()
        if level not in LEVELS:
            raise HTTPException(status_code=400,
                                detail="level must be launch or navigate")
        check = getattr(app.state, "terminal_check", None)
        if check is None:
            raise HTTPException(
                status_code=409,
                detail="No terminal in this service: the terminal settings "
                       "are not complete (the System page names the "
                       "problem).")
        if check.driver_name() not in SUPPORTED_DRIVERS:
            raise HTTPException(
                status_code=409,
                detail=f"The terminal check needs the real terminal driver "
                       f"(pywinauto or pyautogui) or mock; this service "
                       f"uses '{check.driver_name()}'.")
        d = _dispatcher()
        if d is not None:
            state = d.status()
            if not state.get("paused"):
                raise HTTPException(
                    status_code=409,
                    detail="Pause processing first (System page > Pause "
                           "processing), so no request starts during the "
                           "check.")
            if state.get("busy"):
                raise HTTPException(
                    status_code=409,
                    detail="A request is still running. Wait until it has "
                           "finished, then run the check.")
        if check.running:
            raise HTTPException(status_code=409,
                                detail="A terminal check is already running.")
        # One session per service account (TM-03, 2026-10-03).
        availability = getattr(app.state, "availability", None)
        if availability is not None and \
                getattr(availability, "login_probe_running", False):
            raise HTTPException(
                status_code=409,
                detail="The scheduled sign-in health check is running with "
                       "the service account. Try again in a minute.")
        if level == "navigate":
            wait = check.sign_in_wait_seconds()
            if wait > 0:
                raise HTTPException(
                    status_code=409,
                    detail=(f"The last check could not sign in. To protect "
                            f"the service account from a lock-out, the next "
                            f"sign-in check is possible in {wait // 60 + 1} "
                            f"minute(s); check the password first."))
            if body.get("confirm") not in (True, "true", "yes"):
                raise HTTPException(
                    status_code=400,
                    detail="confirm: true is required — the check signs in "
                           "once with the service account; a wrong password "
                           "counts toward the account lockout.")
            availability = getattr(app.state, "availability", None)
            if availability is not None and \
                    not availability.is_within_time_window(check_buffer=False):
                raise HTTPException(
                    status_code=409,
                    detail="Outside the operating window: FINESIII does not "
                           "accept sign-ins now.")
            try:
                port = int(_effective("MAINFRAME_PORT") or
                           getattr(cfg, "mainframe_port", 23) or 23)
            except ValueError:
                port = 23
            reach = _mainframe_reach(
                _effective("MAINFRAME_HOST") or
                getattr(cfg, "mainframe_host", ""), port)
            if not reach["ok"]:
                raise HTTPException(
                    status_code=409,
                    detail=f"The mainframe host does not answer "
                           f"({reach.get('error', '')}); the sign-in is not "
                           f"attempted.")
            cyberark = getattr(app.state, "cyberark", None)
            if cyberark is not None:
                try:
                    fallback = cyberark.status().get("using_fallback", False)
                except Exception:
                    fallback = True
                if fallback:
                    raise HTTPException(
                        status_code=409,
                        detail="CyberArk has not delivered the service-account "
                               "password yet; the sign-in is not attempted.")
        try:
            result = check.run(level)
        except RuntimeError as e:
            raise HTTPException(status_code=409, detail=str(e))
        _audit("terminal_tested", user, "INFO" if result["ok"] else "WARNING",
               detail={"level": level, "ok": result["ok"],
                       "failed_step": result["failed_step"],
                       "signed_off": result["sign_off"]["ok"],
                       "check_id": result["check_id"]})
        return result

    @router.post("/test-mainframe")
    def test_mainframe(body: dict = Body(default={}),
                       user: AppUser = Depends(require_manage)):
        """TCP reachability of the mainframe host — the same probe the
        availability monitor uses. Deliberately NOT a login: a bad
        password would consume a lockout attempt on the service account."""
        host = _body_or(body, "host", "MAINFRAME_HOST") or \
            getattr(cfg, "mainframe_host", "")
        port_raw = _body_or(body, "port", "MAINFRAME_PORT") or \
            str(getattr(cfg, "mainframe_port", 23))
        try:
            port = int(port_raw)
        except ValueError:
            return {"ok": False, "error": "Port must be a number."}
        result = _mainframe_reach(host, port)
        _audit("mainframe_tested", user, "INFO",
               detail={"ok": result["ok"], "host": host, "port": port})
        return result

    def _loaded_ocr_engine():
        """The screen-reading engine the service has loaded (None when
        there is none); the self-test reports it instead of loading a
        second one (X-01, 2026-10-03)."""
        return getattr(getattr(app.state, "executor", None), "ocr_engine",
                       None)

    @router.post("/selftest")
    def selftest(user: AppUser = Depends(require_manage)):
        from desktop.selftest import run_selftest
        report = run_selftest(cfg, ocr_engine=_loaded_ocr_engine())
        _audit("selftest_run", user, "INFO", detail={"ok": report["ok"]})
        return report

    # ── Logs & diagnostics ──

    @router.get("/logs")
    def logs(lines: int = Query(200, ge=1, le=5000),
             file: str = Query("service"),
             level: str | None = Query(
                 None, pattern="^(DEBUG|INFO|WARNING|ERROR|CRITICAL)$"),
             q: str | None = Query(None, max_length=100),
             user: AppUser = Depends(require_view)):
        path = (runtime.agent_log_path() if file == "agent"
                else _service_log())
        if level or (q or "").strip():
            # A level or a search looks through the last 20,000 lines,
            # not only the last few (SY-02, 2026-10-03).
            text = _tail(path, LOG_SEARCH_LINES)       # masked
            rows = _filter_log(text, level, q, lines)
        else:
            rows = _tail(path, lines).splitlines()     # masked
        return {"file": str(path), "exists": path.is_file(), "lines": rows}

    @router.get("/diagnostics")
    def diagnostics(user: AppUser = Depends(require_manage)):
        """A zip a support engineer can read: status, self-test, log
        tails, the deployment file. Every secret-looking value and every
        URL password is masked before it goes in."""
        import json
        from desktop.selftest import run_selftest

        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
            z.writestr("status.json", json.dumps(
                _mask_obj(_status_payload()), indent=2, default=str))
            z.writestr("selftest.json", json.dumps(
                _mask_obj(run_selftest(cfg, ocr_engine=_loaded_ocr_engine())),
                indent=2, default=str))
            for name, path in (("service.log", _service_log()),
                               ("agent.log", runtime.agent_log_path())):
                if path.is_file():
                    z.writestr(name, _tail(path, 5000))    # masked
            dep = deployment.deployment_file()
            if dep.is_file():
                z.writestr("finesiii.env", mask_secrets(
                    dep.read_text(encoding="utf-8", errors="replace")))
            z.writestr("environment.txt", mask_secrets("\n".join(
                f"{k}={v}" for k, v in sorted(os.environ.items())
                if k.startswith(("FINESIII", "APP_", "DATABASE",
                                 "TERMINAL", "OCR", "AUDIT", "SMTP",
                                 "AUTH", "API_", "MAINFRAME", "LOG_",
                                 "EVIDENCE", "CYBERARK")))))
        _audit("diagnostics_downloaded", user, "INFO")
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        return Response(
            content=buf.getvalue(), media_type="application/zip",
            headers={"Content-Disposition":
                     f"attachment; filename=finesiii_diagnostics_"
                     f"{stamp}.zip"})

    # ── Control ──

    # ── Configuration files and export (CFG-03 / CFG-08 / OPS-07) ──

    @router.get("/config-files")
    def list_config_files(user: AppUser = Depends(require_view)):
        """Each configuration file in force: where it is, when it was
        last changed, and its checksum. Read-only: these files are
        changed under change control."""
        return {"files": config_files(cfg)}

    @router.get("/config-files/view")
    def view_config_file(name: str = Query(..., max_length=80),
                         user: AppUser = Depends(require_view)):
        """One configuration file's text, with any secret-looking value
        masked. Only the files listed above that may be shown."""
        match = [f for f in config_files(cfg)
                 if f["name"] == name and f["viewable"]]
        if not match:
            raise HTTPException(status_code=404,
                                detail="No such configuration file")
        info = match[0]
        if not info["exists"]:
            raise HTTPException(status_code=404,
                                detail=f"{name} does not exist on this "
                                       f"machine")
        if info["size"] > 1024 * 1024:
            raise HTTPException(status_code=413,
                                detail=f"{name} is too large to show here")
        text = Path(info["path"]).read_text(encoding="utf-8",
                                            errors="replace")
        _audit("config_file_viewed", user, "INFO", detail={"file": name})
        return {**info, "text": mask_secrets(text)}

    @router.get("/configuration/export")
    def export_configuration(user: AppUser = Depends(require_view)):
        """Every setting with its value and where it comes from, secrets
        masked, plus the configuration files in force: a read-only
        report for change control and handover (CFG-03, 2026-10-04)."""
        from src.modules.console.metrics import to_csv
        if not auth_service.require(user, "settings.view"):
            raise HTTPException(
                status_code=403,
                detail=(f"Your role '{user.role}' does not include the "
                        f"'settings.view' permission"))
        rows = []
        payload_fn = getattr(app.state, "settings_payload", None)
        if payload_fn is not None:
            for s in payload_fn()["settings"]:
                value = s.get("value")
                rows.append({
                    "area": "Settings", "page": s.get("group", ""),
                    "setting": s.get("label", ""), "key": s.get("key", ""),
                    "value": ("(set)" if s.get("secret") and value
                              else "" if value is None
                              else "On" if value is True
                              else "Off" if value is False else value),
                    "source": ("application database" if s.get("overridden")
                               else "default" if s.get("is_default")
                               else "environment or default"),
                    "changed_at": s.get("changed_at", ""),
                    "changed_by": s.get("changed_by", "")})
        sources = {"environment": "Windows environment",
                   "app_file": ".env (application folder)",
                   "machine_file": "finesiii.env (data folder)",
                   "default": "default"}
        in_file, in_app = deployment.read(), deployment.read_app_env()
        machine_rev = _machine_rev_keys()
        for spec in deployment.DEPLOYMENT_KEYS:
            key = spec["key"]
            value = deployment.effective_value(key, cfg)
            if spec["secret_url"]:
                value = vault.mask_url(value)
            source = ("environment" if key in os.environ else "app_file"
                      if key in in_app else "machine_file"
                      if key in in_file else "default")
            last = machine_rev.get(key) or [0, "", ""]
            rows.append({"area": "This machine", "page": spec["group"],
                         "setting": spec["label"], "key": key,
                         "value": value, "source": sources[source],
                         "changed_at": last[2], "changed_by": last[1]})
        for name, info in vault.status().items():
            rows.append({"area": "This machine", "page": "Credentials",
                         "setting": info["label"], "key": name,
                         "value": "(set)" if info["set"] else "(not set)",
                         "source": ("credential store of "
                                    + (vault.store_account() or "this account"))
                         if info["source"] == "vault"
                         else info["source"] or "",
                         "changed_at": "", "changed_by": ""})
        for f in config_files(cfg):
            rows.append({"area": "Configuration file", "page": f["purpose"],
                         "setting": f["name"], "key": "",
                         "value": f"sha256 {f['sha256']}" if f["exists"]
                         else "(not present)",
                         "source": f["path"], "changed_at": f["modified"],
                         "changed_by": ""})
        rows = [{k: mask_secrets(str(v)) if isinstance(v, str) else v
                 for k, v in r.items()} for r in rows]
        _audit("configuration_exported", user, "WARNING",
               detail={"rows": len(rows)})
        stamp = datetime.now(JST_TZ).strftime("%Y%m%d_%H%M%S")
        columns = ("area", "page", "setting", "key", "value", "source",
                   "changed_at", "changed_by")
        return Response(
            content=to_csv(rows, columns).encode("utf-8"),
            media_type="text/csv",
            headers={"Content-Disposition":
                     f'attachment; filename="finesiii_configuration_'
                     f'{stamp}.csv"',
                     "Cache-Control": "no-store",
                     "X-Export-Rows": str(len(rows)),
                     "X-Export-Total": str(len(rows)),
                     "X-Export-Truncated": "false",
                     "X-Export-Audited": str(audit is not None).lower()})

    def _machine_rev_keys() -> dict:
        from src.modules.console.settings_store import read_revision
        return read_revision(getattr(app.state, "settings_store", None),
                             "machine")["keys"]

    @router.post("/service-account/accept")
    def accept_service_account(user: AppUser = Depends(require_manage)):
        """The account this service runs as is now the expected one
        (SEC-03): its credential store is the one in use."""
        store = getattr(app.state, "settings_store", None)
        if store is None:
            raise HTTPException(status_code=409,
                                detail="Settings cannot be saved on this "
                                       "service")
        current = vault.store_account()
        before = store.all().get(SERVICE_ACCOUNT_KEY, "")
        store.set(SERVICE_ACCOUNT_KEY, current, actor=user.username)
        _audit("service_account_recorded", user,
               detail={"before": before, "after": current})
        return {"account": current}

    @router.post("/dispatcher/pause")
    def pause(user: AppUser = Depends(require_manage)):
        d = _dispatcher()
        if d is None:
            raise HTTPException(status_code=409,
                                detail="No dispatcher in this service "
                                       "(API-only mode)")
        at = datetime.now(JST_TZ).isoformat(timespec="seconds")
        d.pause(by=user.username, at=at)
        # Kept in the settings table, so a restart, a crash or a reboot
        # does not resume processing on its own (OPS-01, 2026-10-04).
        store = getattr(app.state, "settings_store", None)
        if store is not None:
            try:
                import json as _json
                store.set(PAUSE_KEY, _json.dumps({"by": user.username,
                                                  "at": at}),
                          actor=user.username)
            except Exception:
                pass
        _audit("dispatcher_paused", user)
        return {"dispatcher": d.status(),
                "note": "No new work will start; a transaction in flight "
                        "finishes."}

    @router.post("/dispatcher/resume")
    def resume(user: AppUser = Depends(require_manage)):
        d = _dispatcher()
        if d is None:
            raise HTTPException(status_code=409,
                                detail="No dispatcher in this service "
                                       "(API-only mode)")
        check = getattr(app.state, "terminal_check", None)
        if check is not None and check.running:
            raise HTTPException(status_code=409,
                                detail="A terminal check is running; resume "
                                       "once it has finished.")
        d.resume()
        store = getattr(app.state, "settings_store", None)
        if store is not None:
            try:
                store.clear(PAUSE_KEY)
            except Exception:
                pass
        _audit("dispatcher_resumed", user)
        return {"dispatcher": d.status()}

    @router.post("/cyberark/refresh-now")
    def cyberark_refresh_now(user: AppUser = Depends(require_manage)):
        """Fetch the mainframe password from CyberArk now instead of at
        the next scheduled refresh (SY-04, 2026-10-03)."""
        provider = getattr(app.state, "cyberark", None)
        if provider is None:
            raise HTTPException(
                status_code=409,
                detail="CyberArk is not in use on this service.")
        accepted = provider.request_refresh()
        if accepted is False:
            # Already fetching: one fetch, not one per click (UAT-L23).
            return {"ok": True, "already": True,
                    "note": "The password is already being fetched; the "
                            "CyberArk card shows the result in a few "
                            "seconds."}
        _audit("cyberark_refresh_requested", user, "INFO")
        return {"ok": True,
                "note": "The password is being fetched; the CyberArk card "
                        "shows the result in a few seconds."}

    @router.post("/servicenow/poll-now")
    def servicenow_poll_now(user: AppUser = Depends(require_manage)):
        """Wake the in-agent poller so it fetches tickets now (2026-09-26).
        Only meaningful while polling is enabled."""
        poller = getattr(app.state, "snow_poller", None)
        if poller is None:
            raise HTTPException(status_code=404,
                                detail="ServiceNow polling runs in the "
                                       "background service only")
        if not poller.enabled():
            raise HTTPException(status_code=409,
                                detail="ServiceNow polling is turned off — "
                                       "enable it on the ServiceNow page")
        poller.poll_now()
        _audit("servicenow_poll_requested", user, "INFO")
        return {"ok": True, "status": poller.status()}

    @router.post("/servicenow/preview")
    def servicenow_preview(user: AppUser = Depends(require_manage)):
        """What the next poll WOULD do with each open ticket (2026-09-29,
        T3): queue, reject, skip or defer, with the reason. Read-only —
        nothing is claimed, noted, handed over, e-mailed or remembered.
        Works while polling is switched off."""
        poller = getattr(app.state, "snow_poller", None)
        if poller is None:
            raise HTTPException(status_code=404,
                                detail="ServiceNow polling runs in the "
                                       "background service only")
        from src.integrations.servicenow.config import ServiceNowConfigError
        try:
            result = poller.preview()
        except ServiceNowConfigError as e:
            raise HTTPException(status_code=400,
                                detail="Not configured: " + e.plain())
        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e))
        except Exception as e:
            from src.integrations.servicenow.client import explain_error
            result = {"tickets": [], "fetched": 0,
                      "error": explain_error(e) or plain_error(e)}
        # The preview reads at most this many tickets (SN-11): the page
        # says "the first N" when it reached the limit (UAT-L19).
        result["limit"] = getattr(poller, "PREVIEW_MAX_TICKETS", 50)
        _audit("servicenow_previewed", user, "INFO",
               detail={"fetched": result.get("fetched", 0),
                       "tickets": len(result.get("tickets", [])),
                       "error": str(result.get("error", ""))[:200]})
        return {"ok": not result.get("error"), **result}

    @router.post("/stop", status_code=202)
    def stop(user: AppUser = Depends(require_manage)):
        """Graceful drain + exit of the background agent. Only the agent
        can honour this; the embedded window stops when it is closed."""
        if stop_hook is None:
            raise HTTPException(
                status_code=501,
                detail=("This service is not running as the background "
                        "agent — close the window, or stop it the way "
                        "you started it."))
        check = getattr(app.state, "terminal_check", None)
        if check is not None and check.running:
            raise HTTPException(
                status_code=409,
                detail="A terminal check is running. Wait until it has "
                       "finished (it signs off the terminal), then stop.")
        _audit("service_stop_requested", user)
        stop_hook()
        return {"status": "stopping",
                "note": "Any transaction in flight finishes first. A "
                        "deliberate stop is not restarted automatically; "
                        "no requests are processed until the service is "
                        "started again on this machine (RUN_COMMANDS.txt, "
                        "section 5)."}

    return router


def mount_system_api(app, *, mode: str, stop_hook=None, logger=None) -> bool:
    """Include the router on a built app. Requires the console (an
    auth_service) — with the console disabled there is nobody who could
    be authorised, so the routes are simply absent."""
    auth_service = getattr(app.state, "auth_service", None)
    if auth_service is None:
        if logger:
            logger.info("System API not mounted — console sign-in is "
                        "disabled on this service")
        return False
    # Secrets an earlier version kept in the settings table move to the
    # credential store (BUG-005). Without a store they stay where they
    # are and are still applied at startup.
    store = getattr(app.state, "settings_store", None)
    if store is not None:
        try:
            if vault.vault_info()["available"]:
                vault.migrate_legacy_setting_secrets(store, logger)
        except Exception as e:
            if logger:
                logger.warning(f"Moving stored secrets to the credential "
                               f"store failed: {type(e).__name__}")
        # Still there (no credential store here, or the move failed):
        # the operator is told what to do (NB-020).
        try:
            from src.modules.console.settings_store import LEGACY_SECRET_ENV
            left = sorted(LEGACY_SECRET_ENV & set(store.all()))
        except Exception:
            left = []
        warnings = getattr(app.state, "startup_warnings", None)
        if warnings is None:
            warnings = app.state.startup_warnings = []
        try:
            no_store = not vault.vault_info()["available"]
        except Exception:
            no_store = True
        for key in left:
            warnings.append(
                f"{key} is still stored in the application database ("
                + ("there is no credential store on this machine"
                   if no_store else "it could not be moved to the "
                   "credential store")
                + f"). Set {key} in the service environment, restart, then "
                f"remove it under Settings > This machine > Credentials.")

    cfg = app.state.config

    def _retire_initial_admin_pw(_user=None) -> None:
        """The installer's provisional administrator password stays in
        the credential store only until that administrator has chosen
        their own (BUG-024)."""
        try:
            username = getattr(cfg, "auth_default_admin_username", "admin")
            admin = auth_service.store.get_by_username(username)
            if admin is None or admin.must_change_password:
                return
            if not vault.vault_info()["available"]:
                return
            if vault.vault().get("AUTH_DEFAULT_ADMIN_PASSWORD") or \
                    os.environ.get("AUTH_DEFAULT_ADMIN_PASSWORD"):
                vault.delete_secret("AUTH_DEFAULT_ADMIN_PASSWORD")
                if logger:
                    logger.info("Initial administrator password removed "
                                "from the credential store (changed at "
                                "first sign-in)")
        except Exception as e:
            if logger:
                logger.warning(f"Could not remove the initial administrator "
                               f"password: {type(e).__name__}")

    _retire_initial_admin_pw()
    auth_service.on_password_changed = _retire_initial_admin_pw
    # The account of the first start is the one whose credential store
    # holds the passwords; a later start as another account is reported
    # on the System page (SEC-03, 2026-10-04).
    if store is not None:
        try:
            account = vault.store_account()
            if account and not store.all().get(SERVICE_ACCOUNT_KEY):
                store.set(SERVICE_ACCOUNT_KEY, account, actor="system")
        except Exception as e:
            if logger:
                logger.warning(f"Service account not recorded: "
                               f"{type(e).__name__}")
    app.include_router(build_system_router(
        app, mode=mode, started_at=time.time(), stop_hook=stop_hook,
        logger=logger))
    return True
