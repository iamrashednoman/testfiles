"""`finesiii-rpa --configure` — the install-time configuration step.

ONE implementation for every installer: the Windows MSI calls it from a
custom action with the values collected in its dialog; the macOS
installer and a developer call it from the command line. It:

  1. writes the deployment file (finesiii.env) into the data directory;
  2. stores the secrets — database password, initial administrator
     password, generated machine API key — in the OS vault, or, when
     the installer runs as a different account than the bot (Windows),
     in the machine-encrypted hand-off file the agent imports on its
     first start (desktop/vault.py);
  3. registers the OS supervisor that runs `--agent` at logon
     (Scheduled Task on Windows via schtasks XML, LaunchAgent on macOS);
  4. checks the database (connectivity + schema) and refuses to finish
     on failure, so an installer never completes with a configuration
     the service cannot start on.

Passwords are NEVER taken on the command line (process lists, shell
history, MSI logs): they arrive through environment variables named by
--db-password-env / --admin-password-env, or on stdin as JSON with
--stdin-json. Nothing here prints a secret.

Exit codes: 0 configured · 2 bad arguments · 3 database check failed ·
4 supervisor registration failed.
"""
from __future__ import annotations

import argparse
import json
import os
import secrets
import subprocess
import sys
from pathlib import Path

from desktop import deployment, vault

TASK_NAME = "FINESIII RPA Agent"
TASK_FOLDER = "\\AIG\\"
LAUNCH_AGENT_LABEL = "com.aig.finesiii.rpa.agent"


def _parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="finesiii-rpa --configure", description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--db-url", help="postgresql://user@host:port/db "
                   "(password NOT in the URL) or sqlite:///path")
    p.add_argument("--db-engine", choices=["postgres", "sqlite"])
    p.add_argument("--db-password-env", metavar="VAR",
                   help="environment variable holding the DB password")
    p.add_argument("--admin-password-env", metavar="VAR",
                   help="environment variable holding the initial "
                        "administrator password")
    p.add_argument("--stdin-json", action="store_true",
                   help="read {db_password, admin_password, ...} from stdin")
    p.add_argument("--answers-file", metavar="PATH",
                   help="INI written by the installer ([secrets] "
                        "db_password=, admin_password=); read once and "
                        "DELETED")
    p.add_argument("--data-dir", metavar="PATH",
                   help="the data directory (sets FINESIII_DATA_DIR for "
                        "this step; the installer sets it machine-wide)")
    p.add_argument("--driver", choices=deployment._DRIVERS)
    p.add_argument("--environment", choices=["development", "production"])
    p.add_argument("--mainframe-environment",
                   choices=["development", "production"])
    p.add_argument("--ocr", choices=["on", "off"])
    p.add_argument("--api-port", type=int)
    p.add_argument("--auth", choices=["on", "off"],
                   help="require the machine API key (default on for "
                        "installs); generates FINESIII_API_KEYS when on")
    p.add_argument("--set", action="append", default=[], metavar="KEY=VALUE",
                   help="any other deployment key (repeatable)")
    p.add_argument("--bot-user", help="account that runs the agent "
                   "(Windows Scheduled Task principal)")
    p.add_argument("--exe", help="path of the installed executable for the "
                   "supervisor (default: this executable)")
    p.add_argument("--register-supervisor", action="store_true")
    p.add_argument("--unregister-supervisor", action="store_true")
    p.add_argument("--start-now", action="store_true",
                   help="start the agent right after registering")
    p.add_argument("--no-check", action="store_true",
                   help="skip the database check (not recommended)")
    p.add_argument("--json", action="store_true", help="machine-readable "
                   "result on stdout")
    return p


def _read_stdin_json() -> dict:
    try:
        data = json.loads(sys.stdin.read() or "{}")
        return data if isinstance(data, dict) else {}
    except ValueError:
        return {}


def _read_answers_file(path: str) -> dict:
    """The installer's hand-off file: [secrets] db_password / admin_password.
    Read once, then overwritten and deleted — it must not outlive this
    step, whatever happens afterwards."""
    import configparser
    p = Path(path)
    if not p.is_file():
        return {}
    cp = configparser.ConfigParser(interpolation=None)
    try:
        cp.read(p, encoding="utf-8")
        secrets_section = cp["secrets"] if cp.has_section("secrets") else {}
        data = {k: v for k, v in secrets_section.items() if v}
    finally:
        try:
            p.write_bytes(b"\0" * max(64, p.stat().st_size))
            p.unlink()
        except OSError:
            pass
    return data


def _secret(env_name: str | None, stdin: dict, key: str) -> str:
    if stdin.get(key):
        return str(stdin[key])
    if env_name:
        return os.environ.get(env_name, "")
    return ""


def _installed_exe(explicit: str | None) -> str:
    if explicit:
        return explicit
    if getattr(sys, "frozen", False):
        return sys.executable
    # From source: the same interpreter running desktop/app.py.
    from src.core.app_paths import resource_path
    return f'"{sys.executable}" "{resource_path("desktop", "app.py")}"'


# ── Supervisors ──

def _schtasks_xml(exe: str, bot_user: str) -> str:
    """Task Scheduler definition: at logon of the bot account, interactive
    session, restart on failure, no time limit, never a second copy."""
    from xml.sax.saxutils import escape
    command, arguments = exe, "--agent"
    if exe.startswith('"'):                      # "python" "app.py"
        command, _, rest = exe[1:].partition('"')
        arguments = f"{rest.strip()} --agent"
    # Values from the command line are text inside XML elements.
    command, arguments, bot_user = (escape(command), escape(arguments),
                                    escape(bot_user))
    return f"""<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.4" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <RegistrationInfo>
    <Description>FINESIII RPA background agent (the bot). Starts at logon of the bot account; the window attaches to it.</Description>
  </RegistrationInfo>
  <Triggers>
    <LogonTrigger><Enabled>true</Enabled><UserId>{bot_user}</UserId></LogonTrigger>
  </Triggers>
  <Principals>
    <Principal id="Author"><UserId>{bot_user}</UserId><LogonType>InteractiveToken</LogonType><RunLevel>LeastPrivilege</RunLevel></Principal>
  </Principals>
  <Settings>
    <MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>
    <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>
    <StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>
    <AllowHardTerminate>false</AllowHardTerminate>
    <StartWhenAvailable>true</StartWhenAvailable>
    <ExecutionTimeLimit>PT0S</ExecutionTimeLimit>
    <RestartOnFailure><Interval>PT1M</Interval><Count>999</Count></RestartOnFailure>
    <Enabled>true</Enabled>
  </Settings>
  <Actions Context="Author">
    <Exec><Command>{command}</Command><Arguments>{arguments}</Arguments></Exec>
  </Actions>
</Task>
"""


def register_windows_task(exe: str, bot_user: str, start_now: bool) -> None:
    import tempfile
    xml = _schtasks_xml(exe, bot_user)
    fd, path = tempfile.mkstemp(suffix=".xml")
    os.close(fd)
    Path(path).write_text(xml, encoding="utf-16")
    try:
        subprocess.run(["schtasks", "/Create", "/F", "/TN",
                        TASK_FOLDER + TASK_NAME, "/XML", path],
                       check=True, capture_output=True)
        if start_now:
            subprocess.run(["schtasks", "/Run", "/TN",
                            TASK_FOLDER + TASK_NAME],
                           check=False, capture_output=True)
    finally:
        try:
            os.remove(path)
        except OSError:
            pass


def unregister_windows_task() -> None:
    subprocess.run(["schtasks", "/Delete", "/F", "/TN",
                    TASK_FOLDER + TASK_NAME], check=False,
                   capture_output=True)


def launch_agent_path() -> Path:
    return Path.home() / "Library" / "LaunchAgents" / \
        f"{LAUNCH_AGENT_LABEL}.plist"


def register_launch_agent(exe: str, start_now: bool) -> None:
    from src.core.app_paths import data_path, resource_path
    template = resource_path("packaging", "agent", "macos",
                             f"{LAUNCH_AGENT_LABEL}.plist")
    log_dir = data_path("logs")
    log_dir.mkdir(parents=True, exist_ok=True)
    text = template.read_text(encoding="utf-8")
    if exe.startswith('"'):                      # from source: two args
        command, _, rest = exe[1:].partition('"')
        text = text.replace("<string>__EXECUTABLE__</string>",
                            f"<string>{command}</string>\n    "
                            f"<string>{rest.strip().strip(chr(34))}</string>")
    else:
        text = text.replace("__EXECUTABLE__", exe)
    text = text.replace("__LOG_DIR__", str(log_dir))
    dest = launch_agent_path()
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(text, encoding="utf-8")
    uid = os.getuid()
    subprocess.run(["launchctl", "bootout", f"gui/{uid}", str(dest)],
                   check=False, capture_output=True)
    subprocess.run(["launchctl", "bootstrap", f"gui/{uid}", str(dest)],
                   check=True, capture_output=True)
    if start_now:
        subprocess.run(["launchctl", "kickstart", "-k",
                        f"gui/{uid}/{LAUNCH_AGENT_LABEL}"],
                       check=False, capture_output=True)


def unregister_launch_agent() -> None:
    dest = launch_agent_path()
    if dest.exists():
        subprocess.run(["launchctl", "bootout", f"gui/{os.getuid()}",
                        str(dest)], check=False, capture_output=True)
        dest.unlink()


def register_supervisor(exe: str, bot_user: str | None,
                        start_now: bool) -> str:
    if sys.platform == "win32":
        if not bot_user:
            raise ValueError("--bot-user is required on Windows")
        register_windows_task(exe, bot_user, start_now)
        return f"Scheduled Task '{TASK_FOLDER}{TASK_NAME}' for {bot_user}"
    if sys.platform == "darwin":
        register_launch_agent(exe, start_now)
        return f"LaunchAgent {launch_agent_path()}"
    raise ValueError("no supervisor template for this platform — use a "
                     "systemd --user unit")


def unregister_supervisor() -> None:
    if sys.platform == "win32":
        unregister_windows_task()
    elif sys.platform == "darwin":
        unregister_launch_agent()


# ── The configure step ──

def _answers_file_arg(argv: list[str]) -> str | None:
    """--answers-file, found even when the rest of the arguments are
    invalid, so the file is always destroyed."""
    pre = argparse.ArgumentParser(add_help=False)
    pre.add_argument("--answers-file")
    try:
        known, _ = pre.parse_known_args(argv)
    except SystemExit:
        return None
    return known.answers_file


def _wipe_file(path: str | None) -> None:
    if not path:
        return
    p = Path(path)
    try:
        if p.is_file():
            p.write_bytes(b"\0" * max(64, p.stat().st_size))
            p.unlink()
    except OSError:
        pass


def configure(argv: list[str]) -> dict:
    """Run the step; returns a result dict (also what --json prints).
    The installer's answers file is destroyed whatever happens."""
    answers_file = _answers_file_arg(argv)
    try:
        return _configure(argv)
    finally:
        _wipe_file(answers_file)


def _configure(argv: list[str]) -> dict:
    p = _parser()
    try:
        a = p.parse_args(argv)
    except SystemExit:
        return {"ok": False, "exit": 2, "error": "bad arguments"}

    if a.data_dir:
        os.environ["FINESIII_DATA_DIR"] = a.data_dir
    stdin = _read_stdin_json() if a.stdin_json else {}
    if a.answers_file:
        stdin.update(_read_answers_file(a.answers_file))
    result: dict = {"ok": True, "exit": 0, "written": [], "secrets": [],
                    "supervisor": "", "check": None, "warnings": []}

    if a.unregister_supervisor:
        unregister_supervisor()
        result["supervisor"] = "removed"
        return result

    # 1. Validate and compute everything; nothing is written yet.
    changes: dict[str, str] = {}
    if a.db_url:
        pw_in_url = vault.url_password(a.db_url)
        if pw_in_url:
            stdin.setdefault("db_password", pw_in_url)
        changes["DATABASE_URL"] = vault.strip_url_password(a.db_url)
        changes["DATABASE_ENGINE"] = a.db_engine or (
            "sqlite" if a.db_url.startswith("sqlite") else "postgres")
    elif a.db_engine:
        changes["DATABASE_ENGINE"] = a.db_engine
    if a.driver:
        changes["TERMINAL_DRIVER"] = a.driver
    if a.environment:
        changes["APP_ENV"] = a.environment
    if a.mainframe_environment:
        changes["MAINFRAME_ENVIRONMENT"] = a.mainframe_environment
    if a.ocr:
        changes["OCR_ENABLED"] = "true" if a.ocr == "on" else "false"
    if a.api_port:
        changes["API_PORT"] = str(a.api_port)
    auth_on = a.auth != "off"
    if a.auth:
        changes["AUTH_ENABLED"] = "true" if auth_on else "false"
        changes["AUTH_CONSOLE_GRANTS_API"] = "true" if auth_on else "false"
    for item in a.set:
        key, _, value = item.partition("=")
        changes[key.strip().upper()] = value
    for key, value in list(changes.items()):
        spec = deployment.BY_KEY.get(key)
        if spec is None:
            return {"ok": False, "exit": 2,
                    "error": f"'{key}' is not a deployment setting"}
        try:
            changes[key] = deployment.coerce(spec, value)
        except ValueError as e:
            return {"ok": False, "exit": 2, "error": str(e)}
    if changes.get("TERMINAL_DRIVER") in deployment._REAL_DRIVERS \
            and changes.get("OCR_ENABLED", "false") != "true":
        return {"ok": False, "exit": 2,
                "error": "a real terminal driver requires --ocr on "
                         "(client-mandated control)"}
    # Same rule as the console's Deployment page: production with a real
    # terminal driver needs the mainframe password from CyberArk.
    merged = {**deployment.read(), **changes}
    driver = merged.get("TERMINAL_DRIVER", "")
    app_env = (merged.get("APP_ENV") or os.environ.get("APP_ENV", "")
               or "development")
    cyberark_on = str(os.environ.get("CYBERARK_ENABLED", "")).strip() \
        .lower() in ("1", "true", "yes", "on")
    if driver in deployment._REAL_DRIVERS \
            and str(app_env).strip().lower() == "production" \
            and not cyberark_on:
        return {"ok": False, "exit": 2,
                "error": "in production a real terminal driver requires the "
                         "mainframe password to come from CyberArk "
                         "(CYBERARK_ENABLED) — enable the CyberArk module "
                         "first"}

    to_store: dict[str, str] = {}
    db_pw = _secret(a.db_password_env, stdin, "db_password")
    if db_pw:
        to_store["DATABASE_PASSWORD"] = db_pw
    admin_pw = _secret(a.admin_password_env, stdin, "admin_password")
    if admin_pw:
        to_store["AUTH_DEFAULT_ADMIN_PASSWORD"] = admin_pw
    if a.auth and auth_on and not os.environ.get("FINESIII_API_KEYS"):
        to_store["FINESIII_API_KEYS"] = \
            f"installer:{secrets.token_urlsafe(32)}"

    # 2. Database check, on the values about to be written — a failure
    #    leaves the deployment file and the secrets untouched.
    if not a.no_check:
        engine = merged.get("DATABASE_ENGINE", "postgres")
        url = merged.get("DATABASE_URL", "")
        if engine == "sqlite":
            from config import get_config
            get_config.cache_clear()
            try:
                url = f"sqlite:///{get_config().sqlite_path}"
            except Exception:
                url = url or "sqlite:///finesiii_v3.db"
        check = deployment.check_database(
            url, engine=engine,
            password=db_pw or os.environ.get("DATABASE_PASSWORD", ""))
        result["check"] = check
        if not check["ok"]:
            result.update(ok=False, exit=3,
                          error=f"database check failed: {check['error']} "
                                f"{check['hint']}".strip())
            return result

    # 3. Deployment file.
    if changes:
        deployment.update(changes)
        result["written"] = sorted(changes)
        result["file"] = str(deployment.deployment_file())

    # 4. Secrets.
    if to_store:
        if sys.platform == "win32" and a.bot_user:
            # Different account will run the agent — hand off.
            vault.write_bootstrap_secrets(to_store)
            result["secrets_via"] = ("bootstrap file (imported by the "
                                     "agent on first start)")
        elif vault.vault_info()["available"]:
            for key, value in to_store.items():
                vault.set_secret(key, value)
            result["secrets_via"] = f"{vault.vault_info()['backend']} vault"
        else:
            vault.write_bootstrap_secrets(to_store)
            result["warnings"].append(
                "no credential vault available — secrets left in the "
                "hand-off file for the agent to import")
            result["secrets_via"] = "bootstrap file"
        result["secrets"] = sorted(to_store)

    # 5. Supervisor.
    if a.register_supervisor:
        try:
            result["supervisor"] = register_supervisor(
                _installed_exe(a.exe), a.bot_user, a.start_now)
        except Exception as e:
            result.update(ok=False, exit=4,
                          error=f"supervisor registration failed: {e}")
            return result
    return result


def main(argv: list[str]) -> int:
    result = configure(argv)
    if "--json" in argv:
        print(json.dumps(result, indent=2))
    else:
        if result.get("written"):
            print(f" Deployment file : {result.get('file')} "
                  f"({', '.join(result['written'])})")
        if result.get("secrets"):
            print(f" Secrets stored  : {', '.join(result['secrets'])} "
                  f"via {result.get('secrets_via', '')}")
        if result.get("check") is not None:
            c = result["check"]
            print(f" Database check  : {'OK' if c['ok'] else 'FAILED'}"
                  + (f" — {c['server']}" if c.get("server") else "")
                  + (f" — {c['error']}" if c.get("error") else ""))
        if result.get("supervisor"):
            print(f" Supervisor      : {result['supervisor']}")
        for w in result.get("warnings", []):
            print(f" [WARN] {w}")
        if not result["ok"]:
            print(f" [FAILED] {result.get('error', '')}", file=sys.stderr)
    return int(result.get("exit", 0 if result["ok"] else 1))
