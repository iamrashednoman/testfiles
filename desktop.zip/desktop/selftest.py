"""Bundle self-test — one implementation for the CLI and the console.

`finesiii-rpa --selftest` (exit code + printed report), the installer's
post-install check (`--selftest --json`) and the System page's
"Run self-test" button all call run_selftest(). A frozen app has no
REPL, so this is the only way a field engineer finds out WHY an
optional native component (OCR, Tk) failed — build_ocr_engine degrades
to the null engine silently on sim/mock drivers, hiding exactly that.
"""
from __future__ import annotations

import importlib.util
import json
import os
import sys
import traceback
from datetime import datetime, timedelta, timezone


class SkipCheck(Exception):
    """A component that is absent BY DESIGN in this build."""


def _check(report: dict, name: str, fn) -> None:
    try:
        detail = fn()
        report["checks"].append({"name": name, "status": "ok",
                                 "detail": detail or ""})
    except SkipCheck as e:
        report["checks"].append({"name": name, "status": "skipped",
                                 "detail": str(e) or "excluded from this "
                                                     "build"})
    except Exception as e:
        report["checks"].append({
            "name": name, "status": "failed",
            "detail": f"{type(e).__name__}: {e}",
            "traceback": traceback.format_exc(limit=3)})
        report["ok"] = False


def run_selftest(cfg=None, ocr_engine=None) -> dict:
    """Verify THIS installation on THIS machine. Never raises.

    ocr_engine: the engine the running service has already loaded. The
    check then reports it instead of loading a second engine inside
    the service (X-01, 2026-10-03): loading the models takes long and
    holds their memory twice."""
    from src.core.app_paths import (bootstrap_data_dir, data_root,
                                    is_frozen, resource_root)

    if is_frozen():
        bootstrap_data_dir()

    report = {
        "ok": True,
        # JST like every time the console shows (E2E-L03).
        "at": datetime.now(timezone(timedelta(hours=9))).isoformat(
            timespec="seconds"),
        "frozen": is_frozen(),
        "python": sys.version.split()[0],
        "platform": sys.platform,
        "resources": str(resource_root()),
        "data_dir": str(data_root()),
        "checks": [],
    }

    ocr_included = importlib.util.find_spec("paddleocr") is not None
    report["build"] = ("full (bot runtime + console)" if ocr_included
                       else "console only (no OCR — by design)")

    def tk():
        import tkinter                                   # noqa: F401
        return "available"
    _check(report, "tkinter (simulator window)", tk)

    def paddlex_meta():
        if not ocr_included:
            raise SkipCheck
        import importlib.metadata as _md
        from paddlex.utils import deps as _deps
        _meta = _md.metadata("paddlex")
        return (f"Provides-Extra="
                f"{len(_meta.get_all('Provides-Extra', []) or [])} "
                f"ocr-core={_deps.is_extra_available('ocr-core')}")
    _check(report, "paddlex metadata", paddlex_meta)

    def ocr():
        if not ocr_included:
            raise SkipCheck
        from src.rpa.vision.ocr import PaddleOcrEngine
        if isinstance(ocr_engine, PaddleOcrEngine) \
                and getattr(ocr_engine, "_pipeline", None) is not None:
            return "loaded in the running service"
        model_dir = os.environ.get("OCR_MODEL_DIR") or (
            getattr(cfg, "ocr_model_dir", "") if cfg else "") or str(
            resource_root() / "models" / "paddleocr")
        from src.rpa.vision.ocr import PaddleOcrEngine
        engine = PaddleOcrEngine(lang="japan", model_dir=model_dir,
                                 allow_download=False)
        engine.load()
        return f"models {model_dir}"
    _check(report, "ocr engine", ocr)

    def rules():
        from src.rpa.vision.error_catalog import ErrorCatalog
        path = getattr(cfg, "error_catalog_path", "") if cfg else ""
        if not path:
            path = (str(data_root() / "config" / "errors.yaml")
                    if is_frozen() else "config/errors.yaml")
        catalog = ErrorCatalog.load(path, strict=True)
        return f"{len(catalog)} rules, sha {catalog.digest} ({path})"
    _check(report, "error catalogue", rules)

    def vault():
        from desktop.vault import vault_info
        info = vault_info()
        if not info["available"]:
            raise RuntimeError(info["error"] or "no credential store")
        return info["backend"]
    _check(report, "credential vault", vault)

    def webview():
        if importlib.util.find_spec("webview") is None:
            raise SkipCheck("pywebview not installed (headless build)")
        return "pywebview available"
    _check(report, "desktop window toolkit", webview)

    def database():
        if cfg is None:
            raise SkipCheck("no configuration loaded")
        from desktop.deployment import check_database
        url = cfg.database_url if cfg.database_engine == "postgres" \
            else f"sqlite:///{cfg.sqlite_path}"
        result = check_database(url, engine=cfg.database_engine)
        if not result["ok"]:
            raise RuntimeError(f"{result['error']} {result['hint']}".strip())
        missing = result["missing_tables"]
        return (f"{result['server']}"
                + (f" — tables to create: {', '.join(missing)}"
                   if missing else " — schema present"))
    _check(report, "database", database)

    return report


def print_report(report: dict) -> None:
    print("FINESIII RPA — bundle self-test")
    print(f"  frozen      : {report['frozen']}")
    print(f"  build type  : {report['build']}")
    print(f"  resources   : {report['resources']}")
    print(f"  data dir    : {report['data_dir']}")
    for c in report["checks"]:
        mark = {"ok": "OK", "skipped": "n/a", "failed": "FAILED"}[c["status"]]
        print(f"  {c['name'][:22]:<22}: {mark} — {c['detail']}"
              if c["detail"] else f"  {c['name'][:22]:<22}: {mark}")
        if c["status"] == "failed" and c.get("traceback"):
            for line in c["traceback"].rstrip().splitlines():
                print(f"        {line}")
    failed = sum(1 for c in report["checks"] if c["status"] == "failed")
    print("  result      : "
          + ("ALL COMPONENTS USABLE" if not failed
             else f"{failed} COMPONENT(S) UNUSABLE"))


def to_json(report: dict) -> str:
    return json.dumps(report, indent=2, ensure_ascii=False)
