"""The background agent — the bot with no window (`--agent`).

This is what the OS supervisor runs at logon of the bot account
(Windows Scheduled Task, macOS LaunchAgent — see packaging/agent/). It
owns the ONE service process on the machine; the desktop window only
attaches to it, so closing the window never stops the bot, and a crash
is recovered by the supervisor, not by a person.

It reuses EmbeddedService wholesale: the same create_app(), the same
graceful drain, the same in-place restart the console's Restart button
already triggers. What it adds is small:

  • the single-instance lock (agent.lock) — two agents on one data
    directory would be two dispatchers on one terminal session;
  • publishing its address (agent.json) once it is READY, so a window
    can find it;
  • a stop request it polls for (agent.stop), because a detached
    Windows process receives no signals;
  • signal handling for SIGINT/SIGTERM on POSIX (launchd stops a
    LaunchAgent with SIGTERM) — plain handlers work here because this
    process has no GUI loop hogging the main thread.

Exit codes: 0 clean stop · 1 failed to start / failed restart / drain
timed out · 3 another agent already holds the lock.
"""
from __future__ import annotations

import logging
import os
import signal
import sys
import threading
import time

from desktop import runtime
from desktop.server import EmbeddedService, mount_console_ui
from desktop.single_instance import AlreadyRunningError, SingleInstance

logger = logging.getLogger("finesiii_rpa_v3")


def agent_lock_path():
    return runtime.data_path(runtime.LOCK_FILE)


class AgentRunner:
    def __init__(self, cfg, logger=logger, cfg_factory=None,
                 poll_seconds: float = 1.0):
        self.cfg = cfg
        self.logger = logger
        self.service = EmbeddedService(cfg, logger=logger,
                                       cfg_factory=cfg_factory)
        self.poll_seconds = poll_seconds
        self._stop = threading.Event()
        self.snow_poller = None
        # Set to 1 when a restart fails: the agent then exits (releasing
        # its lock and address file) so the supervisor starts it afresh,
        # instead of living on with no service behind it.
        self._exit_code = 0

    # ── Control ──

    def request_stop(self) -> None:
        self._stop.set()

    def _install_signal_handlers(self) -> None:
        """POSIX only, main thread only (signal.signal refuses anything
        else). Windows stops the agent through agent.stop instead."""
        if threading.current_thread() is not threading.main_thread():
            return
        for sig in (signal.SIGINT, signal.SIGTERM):
            try:
                signal.signal(sig, lambda *_: self.request_stop())
            except (ValueError, OSError):
                pass

    def _should_stop(self) -> bool:
        return self._stop.is_set() or runtime.stop_requested()

    # ── Run ──

    def run(self) -> int:
        try:
            lock = SingleInstance(agent_lock_path()).acquire()
        except AlreadyRunningError as e:
            print(f" [STOP] {e}", file=sys.stderr, flush=True)
            return 3

        # A stop request left over from a previous life must not stop
        # THIS agent the moment it starts.
        runtime.clear_stop_request()
        # The previous run ended without a stop (OPS-09): reported once
        # this service is up.
        previous = runtime.previous_run_ended_unexpectedly()
        self._install_signal_handlers()

        try:
            print(" Starting the FINESIII RPA service…", flush=True)
            # A database that cannot be reached ends the start with one
            # line saying where to correct it — not a 30-second wait and
            # a trace (NB-005). The supervisor starts the agent again.
            problem = self._database_unreachable()
            if problem:
                return self._fail_start(problem)
            try:
                url = self.service.start()
            except Exception as e:
                from src.core.banner import is_database_error
                if not is_database_error(e) and self.logger:
                    self.logger.error("The service could not be started",
                                      exc_info=True)
                return self._fail_start(self._start_error_line(e))
            if not self.service.wait_until_ready():
                print(" [FATAL] The service did not become ready — see "
                      "the log above.", file=sys.stderr, flush=True)
                self.service.stop(drain_timeout=10)
                return 1
            self._mount()
            self._publish()
            self._start_snow_poller()
            print(f" Ready — {url} (pid {os.getpid()}). Running in the "
                  f"background until stopped.", flush=True)
            if previous:
                self._report_recovery(previous)

            next_log_check = time.monotonic() + self.LOG_CHECK_SECONDS
            while not self._should_stop():
                if self.service.restart_requested:
                    self._restart()
                if self.snow_poller is not None:
                    self.snow_poller.ensure_running()
                if time.monotonic() >= next_log_check:
                    next_log_check = time.monotonic() + self.LOG_CHECK_SECONDS
                    runtime.truncate_agent_log(runtime.agent_log_path())
                self._stop.wait(self.poll_seconds)

            print(" Stop requested — finishing any transaction in "
                  "progress, then stopping…", flush=True)
            self._stop_snow_poller()
            clean = self.service.stop()
            print(" Stopped." if clean
                  else " Stopped (drain timed out — see the log).",
                  flush=True)
            return self._exit_code or (0 if clean else 1)
        finally:
            runtime.remove_runtime()
            runtime.clear_stop_request()
            lock.release()

    def _database_unreachable(self) -> str:
        """The start-up line when the PostgreSQL server does not answer
        at all ('' otherwise — a refused sign-in or missing tables are
        reported by the service itself, with the console up)."""
        if getattr(self.cfg, "database_engine", "") != "postgres":
            return ""
        from desktop import deployment
        from src.core.banner import database_unreachable_line
        try:
            result = deployment.check_database(
                self.cfg.database_url, engine="postgres",
                password=os.environ.get("DATABASE_PASSWORD", ""), timeout=5)
        except Exception:
            return ""
        if not result.get("unreachable"):
            return ""
        return database_unreachable_line(self.cfg, result.get("error") or
                                         result.get("hint") or "")

    def _start_error_line(self, exc) -> str:
        from src.core.banner import startup_error_line
        return startup_error_line(exc, self.cfg)

    def _fail_start(self, line: str) -> int:
        """Report a failed start in one line (log and console), close
        anything half-created, exit code 1."""
        if self.logger:
            self.logger.error(line)
        print(f" [FATAL] {line}", file=sys.stderr, flush=True)
        try:
            from src import extensions
            if extensions.db is not None:
                extensions.db.close()
        except Exception:
            pass
        return 1

    def _mount(self) -> None:
        """UI + /system routes. The Stop button drives the same stop
        request `--stop` uses."""
        mount_console_ui(self.service.app, self.logger, mode="agent",
                         stop_hook=runtime.request_stop)
        self._show_recovery_notice()

    # agent.log is size-checked this often while the agent runs (UAT-L21).
    LOG_CHECK_SECONDS = 3600

    def _report_recovery(self, previous: dict) -> None:
        """The service is back after the previous run ended without a
        stop: an audit event, and an ERROR in the service log, which the
        e-mail alerts send to the administrators (OPS-09, 2026-10-04).
        Never raises."""
        started = str(previous.get("started_at", "") or "unknown")
        text = (f"Service recovered after an unexpected stop: the previous "
                f"run (started {started}, process {previous.get('pid', '?')}) "
                f"ended without being stopped - a crash, a forced end or "
                f"a server restart. The service is running again.")
        try:
            audit = getattr(self.service.app.state, "audit", None)
            if audit is not None:
                audit.event("system", "service_recovered_after_unexpected_stop",
                            severity="ERROR",
                            detail={"previous_started_at": started,
                                    "previous_pid": previous.get("pid")})
        except Exception:
            pass
        try:
            if self.logger:
                self.logger.error(text)
            print(f" [WARN] {text}", flush=True)
        except Exception:
            pass
        try:
            from datetime import datetime, timedelta, timezone
            at = datetime.now(timezone(timedelta(hours=9))).strftime(
                "%Y-%m-%d %H:%M")
            self._recovery_notice = (time.time(), (
                f"The service stopped unexpectedly (previous run started "
                f"{started.replace('T', ' ')[:19]}) and was started again "
                f"at {at} JST. See the audit trail and the service log for "
                f"the cause."))
            self._show_recovery_notice()
        except Exception:
            pass

    def _show_recovery_notice(self) -> None:
        """The recovery notice on the service the console reads; set
        again after a settings restart rebuilds it (E2E-M07)."""
        note = getattr(self, "_recovery_notice", None)
        if note:
            try:
                self.service.app.state.recovery_notice = note
            except Exception:
                pass

    def _publish(self) -> None:
        version = getattr(self.service.app, "version", "") or ""
        runtime.write_runtime(self.service.port, os.getpid(), version)

    def _start_snow_poller(self) -> None:
        """ServiceNow polling on a supervised thread (desktop/snow_poller).
        Always started; it idles until SNOW_ENABLED is on, so the console
        can switch polling on and off without a restart."""
        from desktop.snow_poller import ServiceNowPoller
        self.snow_poller = ServiceNowPoller(
            self.service.app, self.service.base_url, logger=self.logger)
        self.service.app.state.snow_poller = self.snow_poller
        self.snow_poller.start()

    def _stop_snow_poller(self) -> None:
        if self.snow_poller is not None:
            self.snow_poller.stop()
            self.snow_poller = None

    def _restart(self) -> None:
        """The console asked for a restart (settings change). Same
        rebuild the window used to do on its watcher thread."""
        print(" Restarting the service to apply settings…", flush=True)
        try:
            self._stop_snow_poller()
            self.service.restart()
            if not self.service.wait_until_ready():
                raise RuntimeError("the rebuilt service did not become "
                                   "ready")
            self._mount()
            self._publish()
            self._start_snow_poller()
            print(" Restarted.", flush=True)
        except Exception as e:
            if self.logger:
                self.logger.error(f"Restart failed: {e}")
            print(f" [ERROR] Restart failed: {e} — stopping the agent "
                  f"so it can be started again.", file=sys.stderr,
                  flush=True)
            self._exit_code = 1
            self.request_stop()


def stop_running_agent(timeout: float | None = None) -> int:
    """`--stop`: ask the agent to drain and exit, then wait for it.

    Returns 0 when no agent is running or it stopped in time, 1 when it
    was still up at the deadline (a transaction may still be live on
    the terminal — do NOT kill it; wait or check the console)."""
    url = runtime.find_running_agent()
    if url is None:
        # No answer from the API — but an agent whose service died can
        # still be alive and holding its lock. Ask it to stop too.
        if SingleInstance.is_held(agent_lock_path()):
            return _stop_unresponsive_agent(timeout)
        runtime.remove_runtime()            # stale file, if any
        print(" No FINESIII RPA agent is running.", flush=True)
        return 0
    info = runtime.read_runtime() or {}
    pid = int(info.get("pid") or 0)
    print(f" Asking the agent at {url} (pid {pid or '?'}) to stop…",
          flush=True)
    runtime.request_stop()
    deadline = time.time() + (timeout if timeout is not None else 330.0)
    while time.time() < deadline:
        # "Stopped" means the agent has FINISHED: it removes agent.json
        # only after the drain completes. The API going quiet is not
        # enough — the dispatcher may still be mid-transaction.
        if runtime.read_runtime() is None:
            print(" Agent stopped.", flush=True)
            return 0
        if pid and not runtime.pid_alive(pid):
            runtime.remove_runtime()          # crashed; stale file
            print(" Agent process is gone.", flush=True)
            return 0
        time.sleep(0.5)
    print(" [WARN] The agent is still running — a transaction may be in "
          "progress. It will stop when the drain completes.",
          file=sys.stderr, flush=True)
    return 1


def _stop_unresponsive_agent(timeout: float | None = None) -> int:
    """The agent holds its lock but its API does not answer: request the
    stop through the stop file and wait for the lock to be released."""
    print(" An agent is running but not answering — asking it to stop…",
          flush=True)
    runtime.request_stop()
    deadline = time.time() + (timeout if timeout is not None else 330.0)
    while time.time() < deadline:
        if not SingleInstance.is_held(agent_lock_path()):
            print(" Agent stopped.", flush=True)
            return 0
        time.sleep(0.5)
    print(" [WARN] The agent is still running — a transaction may be in "
          "progress. It will stop when the drain completes.",
          file=sys.stderr, flush=True)
    return 1
