"""The deployment file (finesiii.env) and the database check.

Four layers of configuration, one precedence chain (config/base.py):

    class defaults < finesiii.env < .env < environment < admin overrides

finesiii.env (the "machine settings file", in the data folder) is this
module's own file. The application folder's .env (the "application
settings file", written by the set-up scripts when running from source)
holds many of the same keys and WINS over it. Since 2026-10-04 (CFG-01)
the console updates a key in .env when .env holds it and can be written;
when .env cannot be written the key is shown locked, with where to
change it.

This module owns the second layer — the settings an installed app must
have BEFORE the database is open, which is exactly why they cannot live
in the app_settings table (src/modules/console/settings_store.py keeps
them FORBIDDEN there). The installer writes the file from what it
collects; the console's Deployment page edits it afterwards; every
change takes effect on the next service restart.

Secrets never go in this file. A DATABASE_URL that arrives with a
password is split: the password goes to the OS vault (desktop/vault.py)
and the URL is stored without it.
"""
from __future__ import annotations

import os
import time
from pathlib import Path

from config.base import (
    DEPLOYMENT_ENV_FILE, TERMINAL_DRIVERS, inject_url_password,
)
from src.core.app_paths import data_path

REQUIRED_TABLES = ("request_queue", "transaction_history", "app_users",
                   "app_sessions", "app_roles", "app_settings")

# The configuration's own list (NB-009), so the two cannot drift apart.
_DRIVERS = list(TERMINAL_DRIVERS)
_REAL_DRIVERS = {"pywinauto", "pyautogui", "tn3270"}


def _d(key, label, kind, group, help="", choices=None, minimum=None,
       maximum=None, secret_url=False):
    return {"key": key, "label": label, "kind": kind, "group": group,
            "help": help, "choices": choices, "min": minimum,
            "max": maximum, "secret_url": secret_url}


# The allow-list. Everything here is a config/base.py field's
# environment name (pydantic-settings is case-insensitive) — the file is
# read by the SAME loader as .env, so nothing new interprets it.
DEPLOYMENT_KEYS: list[dict] = [
    _d("APP_ENV", "Service environment", "choice", "Deployment",
       choices=["development", "production"],
       help="production is fail-closed: API key required, CyberArk "
            "required on real drivers. PostgreSQL recommended; SQLite "
            "is allowed but reported as a warning."),
    _d("TERMINAL_DRIVER", "Terminal driver", "choice", "Deployment",
       choices=_DRIVERS,
       help="simulator/mock/sim_terminal for testing; pywinauto is the "
            "real FINESIII terminal (Windows only)."),
    _d("MAINFRAME_ENVIRONMENT", "Mainframe environment", "choice",
       "Deployment", choices=["development", "production"],
       help="development prepends 99 to the LOGIN affiliation code."),
    _d("MAINFRAME_HOST", "Mainframe host (probe)", "str", "Deployment",
       help="Empty = assume reachable."),
    _d("MAINFRAME_PORT", "Mainframe port (probe)", "int", "Deployment",
       minimum=1, maximum=65535),
    _d("API_PORT", "Service port", "int", "Deployment",
       minimum=1024, maximum=65535),
    _d("API_PORT_STRICT", "Refuse another port", "bool", "Deployment",
       help="On: when the service port is in use, the service does not "
            "start, instead of starting on another free port that "
            "external callers would not find. Off by default."),
    _d("LOG_LEVEL", "Log level", "choice", "Deployment",
       choices=["DEBUG", "INFO", "WARNING", "ERROR"]),

    _d("DATABASE_ENGINE", "Database engine", "choice", "Database",
       choices=["postgres", "sqlite"]),
    _d("DATABASE_URL", "Database URL", "url", "Database", secret_url=True,
       help="postgresql://user@host:port/database — the password is "
            "kept in the OS credential vault, never in this file."),
    _d("AUDIT_ENABLED", "Audit event trail", "bool", "Database",
       help="On by default for the installed service (SEC-02): sign-ins, "
            "settings and credential changes, evidence views and user "
            "changes are recorded. Off only when the organisation keeps "
            "these records elsewhere."),
    _d("AUDIT_BACKEND", "Audit backend", "choice", "Database",
       choices=["postgres", "sqlite"],
       help="sqlite (a file in the data folder) unless an audit "
            "database is set up."),
    _d("AUDIT_DATABASE_URL", "Audit database URL", "url", "Database",
       secret_url=True),

    _d("OCR_ENABLED", "Screen reading (OCR)", "bool", "Screen reading",
       help="Mandatory on real terminal drivers. Off by default on an "
            "installed desktop app; enable and verify from the console."),

    _d("AUTH_ENABLED", "Require the machine API key", "bool", "Security"),
    _d("AUTH_CONSOLE_GRANTS_API", "Console sign-in may use the API",
       "bool", "Security",
       help="Desktop mode: lets the console's own session call the "
            "intake API. Machine clients still need X-API-Key."),
    _d("AUTH_PASSWORD_HISTORY", "Passwords remembered", "int", "Security",
       minimum=0, maximum=24,
       help="A new console password may not be one of this many earlier "
            "passwords. 0 = only the current one."),
    _d("AUTH_PASSWORD_MAX_AGE_DAYS", "Password expiry (days)", "int",
       "Security", minimum=0, maximum=365,
       help="0 = never (recommended). Otherwise a console password older "
            "than this must be changed at the next sign-in."),
    _d("AUTH_LOCKOUT_ALERT", "E-mail when an account is locked", "bool",
       "Security",
       help="On: a locked console account is reported to the "
            "administrators through the e-mail alerts."),
    _d("EVIDENCE_DIR", "Evidence folder", "path", "Storage"),
    _d("LOG_DIR", "Log folder", "path", "Storage"),
]

BY_KEY = {d["key"]: d for d in DEPLOYMENT_KEYS}
GROUPS = []
for _entry in DEPLOYMENT_KEYS:
    if _entry["group"] not in GROUPS:
        GROUPS.append(_entry["group"])


# ── The file ──

def driver_problem(driver: str) -> str:
    """Why this terminal driver cannot run on this machine ('' = it can).

    Checked when the driver is chosen on the dashboard and at start, so a
    missing prerequisite is reported at once instead of failing on the
    first ticket (2026-09-28)."""
    import importlib.util
    import shutil
    import sys

    def missing(*modules: str) -> list[str]:
        out = []
        for name in modules:
            try:
                if importlib.util.find_spec(name) is None:
                    out.append(name)
            except (ImportError, ValueError):
                out.append(name)
        return out

    driver = str(driver or "").strip().lower()
    if driver in ("", "simulator", "mock"):
        return ""
    if driver == "sim_terminal":
        gone = missing("tkinter")
        return ("The visible simulated terminal needs the Python Tk "
                "component (tkinter), which is not installed."
                if gone else "")
    if driver == "pywinauto":
        if sys.platform != "win32":
            return "The pywinauto driver runs on Windows only."
        gone = missing("pywinauto", "win32gui")
        return (f"The pywinauto driver needs {', '.join(gone)} — install "
                f"the worker requirements." if gone else "")
    if driver == "pyautogui":
        gone = missing("pyautogui")
        return ("The pyautogui driver needs the pyautogui package — "
                "install the worker requirements." if gone else "")
    if driver == "tn3270":
        gone = missing("py3270")
        emulator = shutil.which("s3270") or shutil.which("ws3270")
        if gone or not emulator:
            return ("The tn3270 driver needs the py3270 package and the "
                    "s3270 terminal-protocol program, which are not part "
                    "of the installation.")
        return ""
    return f"Unknown terminal driver '{driver}'."


def deployment_file() -> Path:
    return data_path(DEPLOYMENT_ENV_FILE)


def read() -> dict[str, str]:
    """KEY=value pairs currently in finesiii.env ({} when absent)."""
    path = deployment_file()
    if not path.is_file():
        return {}
    from dotenv import dotenv_values
    return {k: (v if v is not None else "")
            for k, v in dotenv_values(str(path)).items()}


def _quote(value: str) -> str:
    # A line break inside a value would start a new KEY=value line —
    # refuse it outright (coerce() rejects it too; this is the last line
    # of defence for callers that bypass coerce).
    if "\n" in value or "\r" in value:
        raise ValueError("deployment values must be a single line")
    if value == "" or any(c in value for c in " #'\"\\\t"):
        return '"' + value.replace("\\", "\\\\").replace('"', '\\"') + '"'
    return value


def write(values: dict[str, str]) -> Path:
    """Rewrite the whole file atomically (temp + rename). Keys are
    sorted so two writes of the same content are byte-identical."""
    path = deployment_file()
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        "# FINESIII RPA — deployment settings (desktop install).",
        "# Written by the installer and the console's Deployment page.",
        "# Read below the environment and .env; secrets are NEVER stored",
        "# here (they live in the OS credential vault). Edit from the",
        "# console, or by hand followed by a service restart.",
        f"# Updated: {time.strftime('%Y-%m-%d %H:%M:%S')}",
        "",
    ]
    for key in sorted(values):
        lines.append(f"{key}={_quote(str(values[key]))}")
    tmp = path.with_suffix(".env.tmp")
    tmp.write_text("\n".join(lines) + "\n", encoding="utf-8")
    os.replace(tmp, path)
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass
    return path


def update(changes: dict[str, str | None]) -> dict[str, str]:
    """Apply {key: value} (None or "" removes the key) and write."""
    current = read()
    for key, value in changes.items():
        if value is None or value == "":
            current.pop(key, None)
        else:
            current[key] = str(value)
    write(current)
    return current


# ── Validation ──

def coerce(spec: dict, raw) -> str:
    """Normalise a submitted value to its file form, or raise ValueError.
    Server-side, always — the UI's limits are a convenience."""
    value = _coerce(spec, raw)
    if "\n" in value or "\r" in value:
        raise ValueError(f"{spec['label']} must be a single line")
    return value


def _coerce(spec: dict, raw) -> str:
    kind = spec["kind"]
    label = spec["label"]
    if kind == "bool":
        if isinstance(raw, bool):
            return "true" if raw else "false"
        text = str(raw).strip().lower()
        if text in ("1", "true", "yes", "on"):
            return "true"
        if text in ("0", "false", "no", "off"):
            return "false"
        raise ValueError(f"{label} must be true or false")
    if kind == "int":
        try:
            value = int(str(raw).strip())
        except ValueError:
            raise ValueError(f"{label} must be a whole number")
        if spec["min"] is not None and value < spec["min"]:
            raise ValueError(f"{label} must be at least {spec['min']}")
        if spec["max"] is not None and value > spec["max"]:
            raise ValueError(f"{label} must be at most {spec['max']}")
        return str(value)
    if kind == "choice":
        text = str(raw).strip()
        match = next((c for c in spec["choices"]
                      if c.lower() == text.lower()), None)
        if match is None:
            raise ValueError(
                f"{label} must be one of: {', '.join(spec['choices'])}")
        return match
    if kind == "url":
        text = str(raw).strip()
        if text and "://" not in text:
            raise ValueError(f"{label} must be a URL such as "
                             f"postgresql://user@host:5432/database")
        if text:
            _check_url_parts(label, text)
        return text
    text = str(raw).strip()
    if "\n" in text:
        raise ValueError(f"{label} must be a single line")
    return text


def check_url_parts(label: str, text: str) -> None:
    """Public form of the URL check Save applies, for the connection
    test (NB-002): raises ValueError with the percent-encode advice."""
    _check_url_parts(label, text)


def _check_url_parts(label: str, text: str) -> None:
    """Refuse a URL whose password would be cut short: an un-encoded
    '#', '?', '/' or '@' in the password moves the rest of it into
    another part of the URL, where it would be saved in clear."""
    from urllib.parse import urlsplit
    advice = ("percent-encode # ? / @ in the password (# → %23), or leave "
              "the password out and enter it under Credentials")
    try:
        parts = urlsplit(text)
        parts.port                        # raises on a non-numeric port
    except ValueError:
        raise ValueError(f"{label} could not be read — {advice}") from None
    after_scheme = text.split("://", 1)[1]
    if parts.fragment or ("@" in after_scheme and "@" not in parts.netloc):
        raise ValueError(f"{label} could not be read — {advice}")


# ── The application settings file (.env), CFG-01, 2026-10-04 ──

# Backups of .env kept next to it, newest first.
APP_ENV_BACKUPS = 5


def app_env_file() -> Path:
    """The .env the configuration reads: the one in the working folder
    (the application folder when the service runs from source)."""
    return Path(".env").resolve()


def read_app_env() -> dict[str, str]:
    """KEY=value pairs active in .env ({} when absent or unreadable)."""
    path = app_env_file()
    if not path.is_file():
        return {}
    from dotenv import dotenv_values
    try:
        return {k: (v if v is not None else "")
                for k, v in dotenv_values(str(path)).items()}
    except Exception:
        return {}


def app_env_writable() -> bool:
    """Whether the service may update .env: the file and its folder
    (for the backup) can be written by this account. Least-privilege
    installations keep the application folder read-only; the console
    then shows the keys of .env as locked."""
    path = app_env_file()
    return (path.is_file() and os.access(path, os.W_OK)
            and os.access(path.parent, os.W_OK))


def source_of(key: str) -> str:
    """Where the value in force for `key` comes from:
    environment > app_file (.env) > machine_file (finesiii.env) >
    default."""
    if key in os.environ:
        return "environment"
    if key in read_app_env():
        return "app_file"
    if key in read():
        return "machine_file"
    return "default"


_LINE_KEY = None


def _line_key(line: str) -> str:
    """The key an active KEY=value line sets ("" for others)."""
    import re
    global _LINE_KEY
    if _LINE_KEY is None:
        _LINE_KEY = re.compile(r"^\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=")
    m = _LINE_KEY.match(line)
    return m.group(1) if m else ""


def _split_value(rest: str) -> tuple[str, str]:
    """(value text, trailing comment) of what follows "KEY=". A quoted
    value runs to its closing quote; an unquoted one to " #"."""
    stripped = rest.lstrip()
    lead = rest[:len(rest) - len(stripped)]
    if stripped[:1] in ("'", '"'):
        quote = stripped[0]
        i = 1
        while i < len(stripped):
            if stripped[i] == "\\" and quote == '"':
                i += 2
                continue
            if stripped[i] == quote:
                return lead + stripped[:i + 1], stripped[i + 1:]
            i += 1
        return rest, ""
    import re
    m = re.search(r"\s+#", stripped)
    if not m:
        return rest, ""
    return lead + stripped[:m.start()], stripped[m.start():]


def update_app_env(changes: dict[str, str | None]) -> str:
    """Change the lines of .env for the given keys IN PLACE and return
    the previous text (to put it back if a later step fails).

    Only keys .env already holds are changed: a value replaces the old
    one (an inline comment, the line order and every other line stay
    as they are); None comments the line out ("handed back"). A copy of
    the file is kept first (.env.bak-YYYYMMDD-HHMMSS, the newest
    APP_ENV_BACKUPS). The file is rewritten where it is rather than
    replaced, so its Windows permissions stay as the administrator set
    them."""
    import shutil
    path = app_env_file()
    with open(path, encoding="utf-8", newline="") as f:
        original = f.read()
    newline = "\r\n" if "\r\n" in original else "\n"
    lines = original.splitlines(keepends=True)
    stamp = time.strftime("%Y-%m-%d %H:%M")
    done = set()
    for i, line in enumerate(lines):
        key = _line_key(line)
        if not key or key not in changes:
            continue
        body = line.rstrip("\r\n")
        ending = line[len(body):]
        value = changes[key]
        if value is None:
            lines[i] = (f"# {body}   # cleared from the console {stamp}"
                        f"{ending}")
        else:
            head, rest = body.split("=", 1)
            _old, comment = _split_value(rest)
            lines[i] = f"{head}={_quote(str(value))}{comment}{ending}"
        done.add(key)
    missing = sorted(k for k in changes if k not in done)
    if missing:
        raise KeyError(", ".join(missing))
    backup = path.with_name(
        f"{path.name}.bak-{time.strftime('%Y%m%d-%H%M%S')}")
    shutil.copy2(path, backup)
    old = sorted(path.parent.glob(f"{path.name}.bak-*"), reverse=True)
    for extra in old[APP_ENV_BACKUPS:]:
        try:
            extra.unlink()
        except OSError:
            pass
    text = "".join(lines)
    if not text.endswith(("\n", "\r\n")) and text:
        text += newline
    with open(path, "w", encoding="utf-8", newline="") as f:
        f.write(text)
    return original


def restore_app_env(text: str) -> None:
    """Put .env back as it was (after a later step failed)."""
    with open(app_env_file(), "w", encoding="utf-8", newline="") as f:
        f.write(text)


def effective_value(key: str, cfg=None) -> str:
    """What is in force for `key` (after a restart for a value saved
    since), in file form: the environment wins, then .env, then
    finesiii.env, then the loaded configuration (CFG-01: .env was left
    out, so a value .env overrode was shown as in force)."""
    env = os.environ.get(key)
    if env is not None:
        return env
    in_app = read_app_env().get(key)
    if in_app is not None:
        return in_app
    in_file = read().get(key)
    if in_file is not None:
        return in_file
    if cfg is not None:
        value = getattr(cfg, key.lower(), None)
        if isinstance(value, bool):
            return "true" if value else "false"
        if value is not None:
            return str(value)
    return ""


def apply_service_defaults(cfg, degraded: bool = True):
    """The installed service's own defaults, on a freshly read
    configuration (the first start and every Restart).

    * It starts even when not fully configured (processing then waits
      and the System page says why), so the console stays reachable. A
      Restart used to read the configuration without this, and could
      stop the service instead (2026-10-04).
    * The audit trail is on unless AUDIT_ENABLED is set somewhere
      (SEC-02, 2026-10-04). Without an audit database it is kept in a
      SQLite file in the data folder.

    A value set in the environment, .env or finesiii.env always wins.
    `degraded` False: the troubleshooting start (--headless), which
    stops on a start-up error so that the error is printed."""
    if degraded:
        object.__setattr__(cfg, "startup_degraded_mode", True)
    given = set(getattr(cfg, "model_fields_set", set()) or set())
    if "audit_enabled" not in given:
        object.__setattr__(cfg, "audit_enabled", True)
        if "audit_backend" not in given \
                and "audit_database_url" not in given:
            object.__setattr__(cfg, "audit_backend", "sqlite")
    return cfg


# ── Database connectivity check ──

def _url_host(url: str) -> str:
    from urllib.parse import urlsplit
    try:
        return urlsplit(url).hostname or ""
    except ValueError:
        return ""


def check_database(url: str = "", engine: str = "", password: str = "",
                   timeout: float = 5.0) -> dict:
    """Can THIS machine reach the database, and is it ready for the app?

    Used by the installer (`--check-db`) before it commits to a
    configuration, and by the console's Test connection button. Reports
    a plain-language error and a hint instead of a traceback. Never
    echoes the password.
    """
    url = (url or "").strip()
    if password:
        url = inject_url_password(url, password)
    if not engine:
        engine = "sqlite" if url.startswith("sqlite") or not url \
            else "postgres"
    result = {"ok": False, "engine": engine, "server": "", "user": "",
              "missing_tables": [], "privileges": {}, "error": "",
              "hint": ""}

    if engine == "sqlite":
        import sqlite3
        path = url.split("///", 1)[1] if "///" in url else url
        result["server"] = f"sqlite {sqlite3.sqlite_version}"
        result["exists"] = bool(path) and Path(path).is_file()
        if path and not result["exists"]:
            # A test never creates the file (BUG-047); it only checks the
            # service will be able to.
            folder = Path(path).resolve().parent
            if not folder.is_dir():
                result["error"] = (f"The folder for the database file does "
                                   f"not exist: {folder.name}")
                result["hint"] = "Create the folder, or choose another path."
                return result
            if not os.access(folder, os.W_OK):
                result["error"] = ("The folder for the database file is "
                                   "not writable")
                result["hint"] = ("Check the service account's permissions "
                                  "on the folder.")
                return result
            result["missing_tables"] = list(REQUIRED_TABLES)
            result["ok"] = True
            result["hint"] = ("The database file does not exist yet — it "
                              "will be created on first start (SQLite).")
            return result
        try:
            if path:
                conn = sqlite3.connect(
                    Path(path).resolve().as_uri() + "?mode=ro", uri=True,
                    timeout=timeout)
            else:
                conn = sqlite3.connect(":memory:", timeout=timeout)
            try:
                have = {r[0] for r in conn.execute(
                    "SELECT name FROM sqlite_master WHERE type='table'")}
            finally:
                conn.close()
        except sqlite3.Error as e:
            result["error"] = str(e)
            result["hint"] = "Check the file path is readable."
            return result
        result["missing_tables"] = [t for t in REQUIRED_TABLES
                                    if t not in have]
        result["ok"] = True          # SQLite creates its tables itself
        if result["missing_tables"]:
            result["hint"] = ("Tables will be created on first start "
                              "(SQLite).")
        return result

    try:
        import psycopg
    except ImportError as e:
        result["error"] = f"PostgreSQL driver missing: {e}"
        return result
    try:
        with psycopg.connect(url, connect_timeout=int(max(1, timeout)),
                             autocommit=True) as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT version(), current_user")
                version, user = cur.fetchone()
                result["server"] = version.split(" on ")[0]
                result["user"] = user
                for table in REQUIRED_TABLES:
                    cur.execute("SELECT to_regclass(%s)",
                                (f"public.{table}",))
                    if cur.fetchone()[0] is None:
                        result["missing_tables"].append(table)
                if not result["missing_tables"]:
                    cur.execute(
                        "SELECT has_table_privilege(current_user, "
                        "'request_queue', 'SELECT'), "
                        "has_table_privilege(current_user, "
                        "'request_queue', 'INSERT'), "
                        "has_table_privilege(current_user, "
                        "'request_queue', 'UPDATE'), "
                        "has_table_privilege(current_user, "
                        "'transaction_history', 'INSERT'), "
                        "has_table_privilege(current_user, "
                        "'transaction_history', 'UPDATE')")
                    sel, ins, upd, hist_ins, hist_upd = cur.fetchone()
                    result["privileges"] = {
                        "request_queue": {"select": sel, "insert": ins,
                                          "update": upd},
                        "transaction_history": {"insert": hist_ins,
                                                # append-only: must be
                                                # False for the app role
                                                "update": hist_upd},
                    }
    except Exception as e:
        text = str(e).strip().splitlines()[0] if str(e).strip() else \
            type(e).__name__
        result["error"] = text
        low = text.lower()
        if "password" in low or "authentication" in low:
            result["hint"] = "The user name or password is wrong."
        elif "does not exist" in low and "database" in low:
            result["hint"] = ("The database has not been created — ask "
                              "the DBA to run the setup scripts.")
        elif any(k in low for k in ("resolve host", "could not translate "
                                    "host", "name or service not known",
                                    "no such host", "nodename nor servname")):
            host = _url_host(url)
            result["hint"] = (f"The host name '{host}' could not be found "
                              f"— check the spelling or DNS.")
            # No server answered at all (NB-005) — unlike a refused
            # sign-in or a missing database, where the server did.
            result["unreachable"] = True
        elif any(k in low for k in ("refused", "timeout", "timed out",
                                    "could not", "unreachable")):
            result["hint"] = ("The server is unreachable from this "
                              "machine — check host, port and firewall.")
            result["unreachable"] = True
        return result

    if result["missing_tables"]:
        # Connected — only the tables are missing (BUG-048).
        result["connected"] = True
        result["error"] = (f"Connected to {result['server'] or 'the server'}"
                           f", but the application tables are missing")
        result["hint"] = ("Run Setup_Database.py (or ask the database "
                          "administrator to apply scripts/schema.sql).")
        return result
    priv = result["privileges"].get("request_queue", {})
    if not (priv.get("select") and priv.get("insert")
            and priv.get("update")):
        result["error"] = (f"User '{result['user']}' lacks SELECT/INSERT/"
                           f"UPDATE on request_queue")
        result["hint"] = "Grant the application role its privileges."
        return result
    result["ok"] = True
    return result
