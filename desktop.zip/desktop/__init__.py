"""Desktop application shell for the FINESIII RPA orchestrator.

Wraps the EXISTING FastAPI service in a per-OS executable. Nothing in
src/ changes: the UI is an HTTP client of the same /api/v1 routes, and
`python run.py` / Docker keep working exactly as before.
"""
