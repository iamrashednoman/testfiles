=====================================================================
 AIG IAM ACCESS RPA - TOOL: TRANSFER OF THE SQLITE DATA TO POSTGRESQL
 Version of 2 November 2026
=====================================================================
 Copies every row of the application tables from the SQLite file the
 service used before (finesiii_v3.db in the data folder) into the
 PostgreSQL database the service uses now. No file of the application
 is changed.

     app\scripts\transfer_sqlite_to_postgres.py   the transfer
     app\scripts\setup_rds_database.py            used by the transfer
                                                  (same file as the
                                                  RDS setup tool of
                                                  2 November 2026)
     app\tests\unit\test_transfer_sqlite_to_postgres.py
     app\tests\unit\test_setup_rds_database_tool.py

 WHAT IS TRANSFERRED
   request_queue        requests, with their status (queued requests
                        are processed after the start)
   transaction_history  the history of every run
   app_users            console accounts, with their passwords
   app_roles            custom roles (built-in roles come from the
                        application itself)
   app_settings         settings saved on the console
   Not transferred: console sessions (everyone signs in again).

 HOW THE DATA IS PROTECTED
   * The SQLite file is only read; it is checked first (integrity
     check) and a copy of it is written to <data folder>\backups.
   * Every column of the file must exist in PostgreSQL. Values are
     copied unchanged; a value that cannot be stored unchanged stops
     the tool and names the row.
   * Everything is written in ONE transaction. Before it is committed,
     every copied row is read back and compared with the file; any
     difference undoes the whole transfer.
   * --check-only does all of this and then undoes it.
   * It can be run again: rows already there with the same values are
     left as they are. History and requests already in PostgreSQL are
     never overwritten. Console accounts, custom roles and settings of
     the file replace those of PostgreSQL with the same key; the
     "admin" account created at the first start on PostgreSQL gives
     way to the "admin" account of the file (its old password).
   * duration_seconds is a "real" column in PostgreSQL (about 7
     digits), as when the service writes it: a duration keeps its
     value to a fraction of a millisecond.

=====================================================================
 BEFORE
=====================================================================
   * The database setup on PostgreSQL is done (tool of 2 November
     2026: Setup READY).
   * Console > System > Pause processing on the PostgreSQL service is
     NOT enough: the tool stops the service itself (or use
     --no-service with the service already stopped).
   * Optional, recommended: the DBA takes a snapshot of the cluster.

=====================================================================
 STEPS
=====================================================================
 1. Sign in to the server by remote desktop AS THE BOT ACCOUNT and
    open a NEW PowerShell window.

 2. Copy the tool

Copy-Item "<folder of this tool>\app\*" C:\FINESIII\app -Recurse -Force
Get-ChildItem C:\FINESIII\app\scripts\*.py | Unblock-File
cd C:\FINESIII\app

 3. Check (everything is undone, nothing is kept)

.\.venv\Scripts\python.exe scripts\transfer_sqlite_to_postgres.py --check-only

    [OK] one [OK] line per table and "CHECK PASSED".
    [NG] "NOT DONE": the line above names the table, the row and the
         column; nothing was changed. Report it.

 4. Transfer (stops the service, transfers, starts the service)

.\.venv\Scripts\python.exe scripts\transfer_sqlite_to_postgres.py --yes

    [OK] "Copy of the SQLite file: ..." , one [OK] line per table with
         "checked (SHA-256 ...)", and "DONE".

 5. In the console
    - Sign in with the console accounts and passwords of before (the
      accounts come from the SQLite file).
    - Requests and Transaction history show the earlier rows.
    - Settings show the values saved before.
    - Resume processing.

 6. Unattended option A only: leave the server with
    unattended\Leave_Bot_Running.cmd (Run as administrator).

 Another SQLite file: --source <path>.  The tool may be run again at
 any time; the second run reports "already there" for every row.

=====================================================================
 OPTIONAL - AUTOMATED TESTS
=====================================================================
.\.venv\Scripts\python.exe -m pytest tests\unit\test_transfer_sqlite_to_postgres.py tests\unit\test_setup_rds_database_tool.py -q
# [OK] no failure

=====================================================================
 GOING BACK
=====================================================================
 The SQLite file is unchanged (and copied to <data folder>\backups).
 Back to SQLite: in C:\FINESIII\app\.env set DATABASE_ENGINE=sqlite,
 then stop and start the service. The rows copied to PostgreSQL stay
 there; the DBA can drop the database finesiii_v3 if it is not used.
