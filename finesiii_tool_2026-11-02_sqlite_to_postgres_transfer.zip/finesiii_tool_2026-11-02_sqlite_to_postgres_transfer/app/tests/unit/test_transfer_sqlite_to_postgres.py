"""The SQLite to PostgreSQL transfer tool (scripts/transfer_sqlite_to_postgres.py).

Pins:
  - values are stored unchanged: text stays text, numbers stay numbers,
    and a number held as text in a number column becomes that number;
  - a value that cannot be stored unchanged stops the transfer;
  - rows already in PostgreSQL with the same values are left alone, a
    different request or history row is kept, a console row is replaced;
  - the SQLite file is checked and only read.
The run against a real PostgreSQL server is proved outside the suite.
"""
import importlib.util
import sqlite3
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
_spec = importlib.util.spec_from_file_location(
    "transfer_sqlite_to_postgres",
    ROOT / "scripts" / "transfer_sqlite_to_postgres.py")
tool = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(tool)


class FakeConn:
    """A PostgreSQL connection stand-in holding one table's rows."""

    def __init__(self, rows):
        """Keep the rows the table holds."""
        self.rows = rows

    def fetchall(self, sql, params=()):
        """Return the rows of the table."""
        return list(self.rows)


class TestValues:
    """Values keep their meaning in PostgreSQL."""

    @pytest.mark.parametrize("value, kind, expected", [
        ("富士通「エラー」\n'x' \"y\" 😀", "text", "富士通「エラー」\n'x' \"y\" 😀"),
        (7, "integer", 7),
        ("7", "integer", 7),
        (7.0, "integer", 7),
        (1.25, "real", 1.25),
        ("2.5", "double precision", 2.5),
        (None, "integer", None),
        (12, "text", "12"),
    ])
    def test_converted_unchanged(self, value, kind, expected):
        """Each value is stored as the same value."""
        assert tool.convert(value, kind, "t") == expected

    @pytest.mark.parametrize("value, kind", [
        ("abc", "integer"), (b"\x00\x01", "text"), ("a\x00b", "text"),
        ("x1", "real"),
    ])
    def test_refused(self, value, kind):
        """A value that would change stops the transfer."""
        with pytest.raises(tool.Stop):
            tool.convert(value, kind, "t")

    def test_real_compared_at_its_precision(self):
        """A real column is compared at the precision PostgreSQL keeps."""
        assert tool.comparable(124.456789123, "real") == \
            tool.comparable(124.45679, "real")
        assert tool.comparable(124.456789123, "double precision") != \
            tool.comparable(124.45679, "double precision")


class TestPlan:
    """What happens to each row of the file."""

    COLUMNS = ["k", "v"]
    TYPES = {"k": "text", "v": "text"}

    def _plan(self, there, rows, policy):
        """Return the plan for rows against the rows already there."""
        return tool.plan_table(FakeConn(there), "t", "k", rows, self.COLUMNS,
                               self.TYPES, policy)

    def test_new_same_and_kept(self):
        """New rows are inserted, equal rows left, different rows kept."""
        plan = self._plan([{"k": "a", "v": "1"}, {"k": "b", "v": "old"}],
                          [{"k": "a", "v": "1"}, {"k": "b", "v": "new"},
                           {"k": "c", "v": "3"}], "keep")
        assert [r["k"] for r in plan["insert"]] == ["c"]
        assert [r["k"] for r in plan["same"]] == ["a"]
        assert [r["k"] for r in plan["keep"]] == ["b"]
        assert plan["replace"] == []

    def test_console_rows_replaced(self):
        """A different console row is replaced by the file's row."""
        plan = self._plan([{"k": "b", "v": "old"}], [{"k": "b", "v": "new"}],
                          "replace")
        assert [r["v"] for r in plan["replace"]] == ["new"]

    def test_history_and_requests_never_replaced(self):
        """History and requests already in PostgreSQL are never overwritten."""
        policies = {t: p for t, _, p in tool.TABLES}
        assert policies["transaction_history"] == "keep"
        assert policies["request_queue"] == "keep"
        assert "app_sessions" in tool.SKIPPED_TABLES


class TestSource:
    """The SQLite file is checked and only read."""

    def test_damaged_file_stops(self, tmp_path):
        """A file that is not a database is refused."""
        broken = tmp_path / "broken.db"
        broken.write_bytes(b"not a database file at all" * 10)
        with pytest.raises((tool.Stop, sqlite3.DatabaseError)):
            tool.open_source(broken)

    def test_missing_file_stops(self, tmp_path):
        """A missing file is refused."""
        with pytest.raises(tool.Stop):
            tool.open_source(tmp_path / "none.db")

    def test_read_only_and_backup(self, tmp_path):
        """The file cannot be written through the tool; a copy is made."""
        path = tmp_path / "finesiii_v3.db"
        with sqlite3.connect(path) as c:
            c.execute("CREATE TABLE app_settings (key TEXT PRIMARY KEY, "
                      "value TEXT)")
            c.execute("INSERT INTO app_settings VALUES ('A', '1')")
        conn = tool.open_source(path)
        with pytest.raises(sqlite3.OperationalError):
            conn.execute("DELETE FROM app_settings")
        copy = tool.backup_source(conn, tmp_path)
        conn.close()
        with sqlite3.connect(copy) as c:
            assert c.execute("SELECT value FROM app_settings").fetchone() \
                == ("1",)
