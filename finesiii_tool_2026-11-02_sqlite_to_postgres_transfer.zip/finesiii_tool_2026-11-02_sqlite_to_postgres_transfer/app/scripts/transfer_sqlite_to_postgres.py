#!/usr/bin/env python3
"""
Transfer the application data from the SQLite file to PostgreSQL.

Copies every row of the application tables from the SQLite file the
service used before (finesiii_v3.db in the data folder) into the
PostgreSQL database the service uses now (DATABASE_URL in the settings
file, with the password from the credential store of this account):

  request_queue        requests, with their status
  transaction_history  the history of every run
  app_users            console accounts (with their passwords)
  app_roles            custom roles (built-in roles are code)
  app_settings         settings saved on the console

Console sessions are not copied: everyone signs in again.

Run it from the application folder, signed in as the bot account, with
the service stopped:

  cd C:\\FINESIII\\app
  .\\.venv\\Scripts\\python.exe scripts\\transfer_sqlite_to_postgres.py --check-only
  .\\.venv\\Scripts\\python.exe scripts\\transfer_sqlite_to_postgres.py --yes

How the data is protected
  * The SQLite file is only read. A consistent copy of it is written
    first to the backups folder of the data folder.
  * The file is checked (PRAGMA integrity_check) before anything is read.
  * Every column of the file must exist in PostgreSQL; values are copied
    unchanged (a number held as text in a number column is stored as
    that number).
  * Everything is written in ONE transaction. Before it is committed,
    every copied row is read back and compared with the file; any
    difference undoes the whole transfer.
  * --check-only does the same and then undoes it: nothing is kept.
  * A row already in PostgreSQL with the same key and the same values is
    left as it is, so the tool can be run again. History and requests
    already in PostgreSQL are never overwritten.

Exit code 0: done (or the check passed). 1: stopped, nothing changed.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import os
import sqlite3
import struct
import sys
from datetime import datetime
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(APP_DIR))

# Tables in the order they are written, with their key and what happens
# when PostgreSQL already holds a different row with the same key:
# "keep" leaves it, "replace" puts the file's row in its place.
TABLES = (
    ("app_roles", "name", "replace"),
    ("app_users", "user_id", "replace"),
    ("app_settings", "key", "replace"),
    ("transaction_history", "transaction_id", "keep"),
    ("request_queue", "request_id", "keep"),
)
SKIPPED_TABLES = ("app_sessions",)


class Stop(Exception):
    """Raised to end the run with a message; nothing is changed."""


class Undo(Exception):
    """Raised inside the transaction to undo it after a check-only run."""


def _setup_tool():
    """Return the RDS setup tool module (stop, start, data folder, confirm)."""
    spec = importlib.util.spec_from_file_location(
        "setup_rds_database", APP_DIR / "scripts" / "setup_rds_database.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


# ---------------------------------------------------------------------
#  The SQLite file (read only)
# ---------------------------------------------------------------------
def open_source(path: Path) -> sqlite3.Connection:
    """Open the SQLite file read-only and check its integrity.

    Raises:
        Stop: The file is missing or damaged.
    """
    if not path.is_file():
        raise Stop(f"The SQLite file {path} was not found. Give it with "
                   f"--source.")
    conn = sqlite3.connect(path.resolve().as_uri() + "?mode=ro", uri=True)
    conn.row_factory = sqlite3.Row
    result = conn.execute("PRAGMA integrity_check").fetchone()[0]
    if result != "ok":
        conn.close()
        raise Stop(f"The SQLite file {path} is damaged ({result}). "
                   f"Nothing was transferred.")
    return conn


def backup_source(conn: sqlite3.Connection, data_dir: Path) -> Path:
    """Write a consistent copy of the SQLite file; return its path."""
    folder = data_dir / "backups"
    folder.mkdir(parents=True, exist_ok=True)
    target = folder / ("finesiii_v3_before_transfer_"
                       + datetime.now().strftime("%Y%m%d_%H%M%S") + ".db")
    copy = sqlite3.connect(str(target))
    try:
        conn.backup(copy)
    finally:
        copy.close()
    return target


def source_tables(conn: sqlite3.Connection) -> set[str]:
    """Return the names of the tables in the SQLite file."""
    return {r[0] for r in conn.execute(
        "SELECT name FROM sqlite_master WHERE type = 'table'")}


def source_columns(conn: sqlite3.Connection, table: str) -> list[str]:
    """Return the columns of a table in the SQLite file, in order."""
    return [r[1] for r in conn.execute(f'PRAGMA table_info("{table}")')]


def source_rows(conn: sqlite3.Connection, table: str, key: str) -> list[dict]:
    """Return every row of a table in the SQLite file, by key."""
    return [dict(r) for r in conn.execute(
        f'SELECT * FROM "{table}" ORDER BY "{key}"')]


# ---------------------------------------------------------------------
#  PostgreSQL (the database of the service)
# ---------------------------------------------------------------------
def open_target():
    """Return (Database, cfg) of the PostgreSQL database the service uses.

    The password comes from the credential store of this account, as
    for the service.

    Raises:
        Stop: The service is not set up for PostgreSQL.
    """
    import logging

    from desktop.vault import load_secrets_into_env
    load_secrets_into_env(logging.getLogger("finesiii_rpa_v3"))
    from config import get_config
    from src.core.db import Database
    cfg = get_config()
    if cfg.database_engine != "postgres" or not cfg.database_url:
        raise Stop("The settings do not name a PostgreSQL database "
                   "(DATABASE_ENGINE=postgres and DATABASE_URL). Run the "
                   "database setup first.")
    return Database(engine="postgres", pg_url=cfg.database_url,
                    pool_size=2), cfg


def target_columns(conn, table: str) -> dict[str, str]:
    """Return {column: data type} of a table in PostgreSQL ({} if absent)."""
    rows = conn.fetchall(
        "SELECT column_name, data_type FROM information_schema.columns "
        "WHERE table_schema = 'public' AND table_name = ?", (table,))
    return {r["column_name"]: r["data_type"] for r in rows}


# ---------------------------------------------------------------------
#  Values
# ---------------------------------------------------------------------
_INTEGER = ("integer", "bigint", "smallint")
_FLOAT = ("real", "double precision", "numeric")


def convert(value, data_type: str, where: str):
    """Return the value as PostgreSQL stores it in a column of that type.

    Text stays text and numbers stay numbers. A number held as text in a
    number column (SQLite allows it) is stored as that number.

    Raises:
        Stop: The value cannot be stored without being changed.
    """
    if value is None:
        return None
    if isinstance(value, bytes):
        raise Stop(f"{where}: binary data, which the column cannot hold.")
    if data_type in _INTEGER:
        if isinstance(value, bool):
            return int(value)
        if isinstance(value, int):
            return value
        if isinstance(value, float) and value.is_integer():
            return int(value)
        text = str(value).strip()
        if text.lstrip("+-").isdigit():
            return int(text)
        raise Stop(f"{where}: {value!r} is not a whole number.")
    if data_type in _FLOAT:
        if isinstance(value, (int, float)):
            return float(value)
        try:
            return float(str(value).strip())
        except ValueError:
            raise Stop(f"{where}: {value!r} is not a number.") from None
    text = value if isinstance(value, str) else str(value)
    if "\x00" in text:
        raise Stop(f"{where}: the text holds a NUL character, which "
                   f"PostgreSQL cannot store.")
    return text


def comparable(value, data_type: str):
    """Return a value in the form both databases give it back.

    PostgreSQL 'real' keeps about seven digits, as when the service
    writes it, so the comparison is made at that precision.
    """
    if value is None:
        return None
    if data_type == "real":
        return struct.unpack("f", struct.pack("f", float(value)))[0]
    if data_type in _FLOAT:
        return float(value)
    if data_type in _INTEGER:
        return int(value)
    return str(value)


def digest(rows: list[dict], columns: list[str], types: dict) -> str:
    """Return the SHA-256 of rows (in key order) for a final comparison."""
    h = hashlib.sha256()
    for row in rows:
        for c in columns:
            h.update(repr(comparable(row.get(c), types[c])).encode("utf-8"))
            h.update(b"\x1f")
        h.update(b"\x1e")
    return h.hexdigest()


# ---------------------------------------------------------------------
#  Transfer of one table
# ---------------------------------------------------------------------
def plan_table(conn, table: str, key: str, rows: list[dict],
               columns: list[str], types: dict, policy: str) -> dict:
    """Return what happens to each row: insert, same, keep or replace.

    Raises:
        Stop: A value cannot be stored unchanged.
    """
    names = ", ".join(f'"{c}"' for c in columns)
    existing = {r[key]: r for r in conn.fetchall(
        f'SELECT {names} FROM "{table}"')}
    plan = {"insert": [], "same": [], "keep": [], "replace": []}
    for row in rows:
        values = {c: convert(row.get(c), types[c],
                             f"{table} {key}={row.get(key)!r} column {c}")
                  for c in columns}
        there = existing.get(values[key])
        if there is None:
            plan["insert"].append(values)
        elif all(comparable(there.get(c), types[c])
                 == comparable(values[c], types[c]) for c in columns):
            plan["same"].append(values)
        elif policy == "replace":
            plan["replace"].append(values)
        else:
            plan["keep"].append(values)
    return plan


def write_table(conn, table: str, key: str, columns: list[str],
                plan: dict) -> None:
    """Insert the new rows and put the replaced rows in place."""
    names = ", ".join(f'"{c}"' for c in columns)
    marks = ", ".join("?" for _ in columns)
    insert = f'INSERT INTO "{table}" ({names}) VALUES ({marks})'
    for values in plan["replace"]:
        conn.execute(f'DELETE FROM "{table}" WHERE "{key}" = ?',
                     (values[key],))
    if table == "app_users":
        # A user name is unique: a different account of PostgreSQL with
        # the same name (the one created at the first start) gives way
        # to the account of the file.
        for values in plan["insert"] + plan["replace"]:
            conn.execute('DELETE FROM "app_users" WHERE "username" = ? '
                         'AND "user_id" <> ?',
                         (values["username"], values["user_id"]))
    for values in plan["insert"] + plan["replace"]:
        conn.execute(insert, tuple(values[c] for c in columns))


def verify_table(conn, table: str, key: str, columns: list[str],
                 types: dict, plan: dict) -> str:
    """Compare every copied row with PostgreSQL; return the digest.

    Raises:
        Stop: A row differs (the transaction is then undone).
    """
    expected = sorted(plan["insert"] + plan["replace"] + plan["same"],
                      key=lambda v: v[key])
    names = ", ".join(f'"{c}"' for c in columns)
    stored = {r[key]: r for r in conn.fetchall(
        f'SELECT {names} FROM "{table}"')}
    found = {}
    for values in expected:
        row = stored.get(values[key])
        if row is None:
            raise Stop(f"{table}: row {values[key]!r} is missing after "
                       f"the copy.")
        for c in columns:
            if comparable(row.get(c), types[c]) != \
                    comparable(values[c], types[c]):
                raise Stop(f"{table}: row {values[key]!r} column {c} "
                           f"differs after the copy.")
        found[values[key]] = row
    if digest(expected, columns, types) != digest(
            [found[v[key]] for v in expected], columns, types):
        raise Stop(f"{table}: the copied rows do not match the file.")
    return digest(expected, columns, types)


def active_key_clash(conn, rows: list[dict]) -> list[str]:
    """Return requests whose active key is already active in PostgreSQL.

    Only one queued or running request may hold an idempotency key.
    """
    active = [r for r in rows if r.get("status") in ("queued", "running")]
    if not active:
        return []
    held = {r["idempotency_key"]: r["request_id"] for r in conn.fetchall(
        "SELECT idempotency_key, request_id FROM request_queue "
        "WHERE status IN ('queued', 'running')")}
    return [r["request_id"] for r in active
            if held.get(r["idempotency_key"]) not in (None, r["request_id"])]


# ---------------------------------------------------------------------
#  Main
# ---------------------------------------------------------------------
def transfer(source: sqlite3.Connection, db, check_only: bool,
             say=print) -> dict:
    """Copy every table in one transaction; return the result per table.

    Raises:
        Stop: A problem; the transaction is undone, nothing is kept.
    """
    present = source_tables(source)
    results = {}
    try:
        with db.connect() as conn:
            for table, key, policy in TABLES:
                if table not in present:
                    results[table] = None
                    continue
                types = target_columns(conn, table)
                if not types:
                    raise Stop(f"The table {table} is missing in "
                               f"PostgreSQL. Run the database setup "
                               f"first.")
                columns = source_columns(source, table)
                missing = [c for c in columns if c not in types]
                if missing:
                    raise Stop(f"{table}: the column(s) {', '.join(missing)} "
                               f"of the file are missing in PostgreSQL. "
                               f"Nothing was transferred.")
                rows = source_rows(source, table, key)
                if table == "app_roles":
                    # Built-in roles are reset from the code at every start.
                    rows = [r for r in rows if not r.get("is_builtin")]
                if table == "request_queue":
                    clash = active_key_clash(conn, rows)
                    if clash:
                        raise Stop("request_queue: these requests are "
                                   "already queued or running in "
                                   "PostgreSQL under another id: "
                                   + ", ".join(clash[:10]))
                plan = plan_table(conn, table, key, rows, columns, types,
                                  policy)
                write_table(conn, table, key, columns, plan)
                sha = verify_table(conn, table, key, columns, types, plan)
                results[table] = dict(
                    rows=len(rows), inserted=len(plan["insert"]),
                    same=len(plan["same"]), replaced=len(plan["replace"]),
                    kept=len(plan["keep"]), digest=sha[:16])
                say(f"  [OK     ] {table}: {len(rows)} row(s) in the file; "
                    f"{len(plan['insert'])} copied, {len(plan['replace'])} "
                    f"replaced, {len(plan['same'])} already there, "
                    f"{len(plan['keep'])} kept as in PostgreSQL; checked "
                    f"(SHA-256 {sha[:16]})")
            if check_only:
                raise Undo()
    except Undo:
        pass
    return results


def parse_arguments(argv):
    """Read the command line."""
    p = argparse.ArgumentParser(
        description="Transfer the application data from the SQLite file "
                    "to the PostgreSQL database of the service.")
    p.add_argument("--source", default="", metavar="PATH",
                   help="the SQLite file (default: finesiii_v3.db in the "
                        "data folder)")
    p.add_argument("--check-only", action="store_true",
                   help="copy and check in a transaction that is then "
                        "undone; nothing is kept")
    p.add_argument("--yes", action="store_true",
                   help="answer yes to stopping the service, the transfer "
                        "and starting the service")
    p.add_argument("--no-service", action="store_true",
                   help="neither stop nor start the service (it must be "
                        "stopped already)")
    return p.parse_args(argv)


def run(args) -> int:
    """Run the transfer; return the exit code."""
    tool = _setup_tool()
    print("=" * 69)
    print(" AIG IAM Access RPA - transfer of the SQLite data to PostgreSQL")
    print("=" * 69)
    env = dict(os.environ)
    try:
        folder = tool.data_folder(env)
    except tool.Stop as e:
        raise Stop(str(e)) from None
    if env.get(tool.DATA_DIR_VARIABLE):
        # The data folder stored for the account, also for get_config.
        os.environ[tool.DATA_DIR_VARIABLE] = env[tool.DATA_DIR_VARIABLE]
    db, cfg = open_target()
    source_path = Path(args.source) if args.source else Path(cfg.sqlite_path)
    print(f"  Data folder : {folder}")
    print(f"  From        : {source_path}")
    target = cfg.database_url.split("@")[-1].split("?")[0]
    print(f"  To          : {target}")
    print(f"  Mode        : " + ("check only (everything is undone)"
                                 if args.check_only else "transfer"))
    try:
        from desktop import runtime
        running = runtime.find_running_agent() is not None
        if running and not args.check_only:
            if args.no_service:
                raise Stop("The service is running. Stop it first: "
                           ".\\.venv\\Scripts\\python.exe desktop\\app.py "
                           "--stop")
            if not tool.confirm("The service is running. Stop it for the "
                                "transfer?", args.yes):
                raise Stop("Stopped. Nothing was transferred.")
            if not tool.stop_service(tool.application_python(), env):
                raise Stop("The service did not confirm the stop. Nothing "
                           "was transferred.")
        source = open_source(source_path)
        try:
            print("  [OK     ] SQLite file: integrity check passed")
            if not args.check_only:
                if not tool.confirm("Transfer the data now?", args.yes):
                    raise Stop("Stopped. Nothing was transferred.")
                copy = backup_source(source, Path(env.get(
                    tool.DATA_DIR_VARIABLE) or source_path.parent))
                print(f"  [OK     ] Copy of the SQLite file: {copy}")
            print("")
            results = transfer(source, db, args.check_only)
            for table in SKIPPED_TABLES:
                if table in source_tables(source):
                    print(f"  [INFO   ] {table}: not transferred (everyone "
                          f"signs in again)")
        finally:
            source.close()
    finally:
        db.close()
    absent = [t for t, r in results.items() if r is None]
    if absent:
        print(f"  [INFO   ] not in the file: {', '.join(absent)}")
    print("")
    if args.check_only:
        print(" CHECK PASSED - every row can be transferred unchanged; "
              "nothing was kept.")
        return 0
    print(" DONE - every row was copied and checked; the transaction is "
          "committed.")
    if not args.no_service and tool.confirm("Start the service now?",
                                            args.yes):
        if tool.start_service():
            print("  Started. Sign in to the console and check the "
                  "Requests and Transaction history pages.")
    return 0


def main(argv=None) -> int:
    """Run the tool and return its exit code."""
    args = parse_arguments(sys.argv[1:] if argv is None else argv)
    try:
        return run(args)
    except Stop as e:
        print(f"\n  {e}\n NOT DONE - nothing was changed in PostgreSQL.")
        return 1
    except KeyboardInterrupt:
        print("\n  Stopped at the keyboard. Nothing was changed.")
        return 1
    except Exception as e:                       # never a traceback
        print(f"\n  Unexpected problem: {type(e).__name__}: "
              f"{' '.join(str(e).split())[:300]}\n NOT DONE - the "
              f"transaction was undone; nothing was changed in "
              f"PostgreSQL.")
        return 1


if __name__ == "__main__":
    sys.exit(main())
