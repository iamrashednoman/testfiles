"""Audit-trail unit tests (focused port of v2 tests/test_audit_trail.py):
event capture, secret redaction, the durable spool (no event loss across
sink outages, idempotent delivery), the log-record bridge with TXN=/STEP=
parsing, the reentrancy guard, and the settings-object factory. SQLite
backend + tmp_path spool only — no PostgreSQL needed."""
from __future__ import annotations

import uuid

from config.development import DevelopmentConfig
from src.core.logging import TransactionLogger
from src.modules.audit.trail import AuditTrail, maybe_start_audit_trail
from src.modules.audit.trail_db import SQLiteAuditBackend
from src.modules.intake.models import TransactionRecord


def make_trail(tmp_path, backend=None, **kw):
    backend = backend or SQLiteAuditBackend(str(tmp_path / "audit.db"))
    backend.ensure_schema()
    return AuditTrail(backend, spool_path=str(tmp_path / "spool.db"),
                      flush_interval=0.05, **kw)


def make_txn(status="done", **kw):
    defaults = dict(
        request_id="req_1", ticket_id="INC0000001", operation="provision",
        affiliation_code="30822", employee_code="1217036",
        source="servicenow", status=status, result_code="O-0000",
        error_message="", submitted_at="", started_at="", completed_at="",
        duration_seconds=4.2, worker_id=1, evidence_path="",
        screenshot_count=2, operator="1217036", attempt_count=1,
    )
    defaults.update(kw)
    return TransactionRecord(**defaults)


def make_logger(tmp_path):
    return TransactionLogger({"log_dir": str(tmp_path / "logs"),
                              "console_output": False})


def make_cfg(tmp_path, **overrides):
    defaults = dict(
        database_engine="sqlite",
        sqlite_path=str(tmp_path / "svc.db"),
        dispatcher_enabled=False,
        audit_enabled=True,
        audit_backend="sqlite",
        audit_sqlite_path=str(tmp_path / "audit.db"),
        audit_spool_path=str(tmp_path / "spool.db"),
        audit_flush_interval_seconds=0.05,
    )
    defaults.update(overrides)
    return DevelopmentConfig(_env_file=None, **defaults)


class FlakyBackend(SQLiteAuditBackend):
    """Fails the first N insert batches — simulates an audit-DB outage."""

    def __init__(self, path, fail_batches=2):
        super().__init__(path)
        self.fail_batches = fail_batches
        self.attempts = 0

    def insert_events(self, events):
        self.attempts += 1
        if self.attempts <= self.fail_batches:
            raise ConnectionError("audit db down (simulated)")
        super().insert_events(events)


class TestEventCapture:
    def test_event_spools_and_flushes_with_field_split(self, tmp_path):
        trail = make_trail(tmp_path)
        trail.event("api", "request_submitted",
                    request_id="req_9", operation="provision",
                    employee_code="1217036", queue_position=3)
        assert trail.flush(timeout=5)
        ev = trail.backend.query_events(category="api")[0]
        assert ev["action"] == "request_submitted"
        assert ev["request_id"] == "req_9"            # known column lifted
        assert ev["detail"]["queue_position"] == 3    # extras ride in detail
        trail.close()

    def test_secrets_redacted_before_spool(self, tmp_path):
        trail = make_trail(tmp_path)
        trail.event("connector", "ticket_mapped",
                    detail={"password": "SECRET99", "note": "keep",
                            "nested": {"api_key": "K123"}})
        assert trail.flush(timeout=5)
        detail = trail.backend.query_events()[0]["detail"]
        assert detail["password"] == "****"
        assert detail["nested"]["api_key"] == "****"
        assert detail["note"] == "keep"
        trail.close()

    def test_transaction_promotes_columns_and_severity(self, tmp_path):
        trail = make_trail(tmp_path)
        trail.transaction(make_txn(status="done"))
        trail.transaction(make_txn(status="failed", result_code="",
                                   error_message="E-9901 boom"))
        assert trail.flush(timeout=5)
        assert len(trail.backend.query_events(severity="ERROR")) == 1
        ok = trail.backend.query_events(severity="INFO",
                                        action="transaction_completed")[0]
        assert ok["status"] == "done"                  # promoted columns
        assert ok["ticket_id"] == "INC0000001"
        assert ok["operation"] == "provision"
        assert ok["employee_code"] == "1217036"
        assert ok["worker_id"] == 1
        assert ok["detail"]["duration_seconds"] == 4.2  # detail packing
        assert ok["detail"]["screenshot_count"] == 2
        assert ok["detail"]["operator"] == "1217036"
        trail.close()

    def test_event_never_raises_even_when_spool_breaks(self, tmp_path):
        trail = make_trail(tmp_path)
        trail.spool_path = "/nonexistent/dir/spool.db"     # force failure
        trail.event("api", "request_submitted")            # must not raise
        trail.spool_path = str(tmp_path / "spool.db")
        trail.close()

    def test_query_events_filters(self, tmp_path):
        trail = make_trail(tmp_path)
        trail.event("api", "request_submitted", request_id="req_a")
        trail.event("api", "request_rejected", severity="WARNING",
                    request_id="req_b")
        trail.event("dispatch", "transaction_completed", severity="ERROR",
                    request_id="req_a")
        assert trail.flush(timeout=5)
        q = trail.backend.query_events
        assert len(q(category="api")) == 2
        assert len(q(severity="ERROR")) == 1
        assert len(q(request_id="req_a")) == 2
        assert len(q(category="api", request_id="req_a")) == 1
        assert len(q()) == 3
        trail.close()


class TestDurableSpool:
    def test_pending_counts_backlog_while_sink_down(self, tmp_path):
        backend = FlakyBackend(str(tmp_path / "audit.db"),
                               fail_batches=10**6)          # always down
        backend.ensure_schema()
        trail = make_trail(tmp_path, backend=backend)
        for i in range(3):
            trail.event("worker", "step", detail={"i": i})
        assert trail.pending() == 3                    # spool holds backlog
        assert not trail.flush(timeout=0.3)            # sink still down
        assert trail.pending() == 3                    # nothing lost
        trail._stop.set()
        trail._wake.set()
        trail._thread.join(timeout=5)

    def test_outage_loses_nothing_and_delivers_exactly_once(self, tmp_path):
        backend = FlakyBackend(str(tmp_path / "audit.db"), fail_batches=2)
        backend.ensure_schema()
        trail = make_trail(tmp_path, backend=backend)
        for i in range(5):
            trail.event("worker", "step", detail={"i": i})
        assert trail.flush(timeout=10)                 # survives the outage
        assert backend.count() == 5
        assert trail.pending() == 0
        trail.close()

    def test_delivery_idempotent_on_event_id(self, tmp_path):
        backend = SQLiteAuditBackend(str(tmp_path / "audit.db"))
        backend.ensure_schema()
        ev = {"event_id": str(uuid.uuid4()),
              "occurred_at": "2026-08-03T10:00:00+09:00",
              "category": "api", "action": "x", "severity": "INFO"}
        backend.insert_events([ev])
        backend.insert_events([ev])                    # redelivery
        assert backend.count() == 1

    def test_close_drains_spool(self, tmp_path):
        trail = make_trail(tmp_path)
        for i in range(4):
            trail.event("worker", "step", detail={"i": i})
        trail.close()                                  # drains before stop
        assert trail.pending() == 0
        reopened = SQLiteAuditBackend(str(tmp_path / "audit.db"))
        assert reopened.count() == 4


class TestLogHandlerBridge:
    def test_error_log_becomes_event_with_txn_step_context(self, tmp_path):
        logger = make_logger(tmp_path)
        trail = make_trail(tmp_path)
        trail.attach_log_handler()
        logger.set_transaction("20260803_100000")
        logger.step_start("PROVISION")
        logger.error("Account data validation failed")
        assert trail.flush(timeout=5)
        errors = trail.backend.query_events(severity="ERROR")
        assert errors[0]["error_message"] == "Account data validation failed"
        assert errors[0]["detail"]["logger_txn"] == "20260803_100000"
        assert errors[0]["detail"]["step"] == "PROVISION"
        infos = trail.backend.query_events(action="info")
        assert any("PROVISION" in e["detail"]["message"] for e in infos)
        trail.close()

    def test_app_logger_records_are_captured_too(self, tmp_path):
        import logging
        trail = make_trail(tmp_path)
        trail.attach_log_handler(min_level="WARNING")
        logging.getLogger("finesiii_rpa_v3").warning("queue paused")
        assert trail.flush(timeout=5)
        events = trail.backend.query_events(category="log")
        assert events[0]["detail"]["message"] == "queue paused"
        trail.close()

    def test_min_level_filters_and_internal_logs_never_loop(self, tmp_path):
        logger = make_logger(tmp_path)
        trail = make_trail(tmp_path, logger=logger)
        trail.attach_log_handler(min_level="WARNING")
        logger.info("routine chatter")                 # below min level
        trail._internal_warn("audit db unreachable")   # guarded: no event
        logger.warning("real anomaly")
        assert trail.flush(timeout=5)
        events = trail.backend.query_events(category="log")
        assert len(events) == 1
        assert events[0]["detail"]["message"] == "real anomaly"
        trail.close()

    def test_close_detaches_handler_from_both_loggers(self, tmp_path):
        import logging
        make_logger(tmp_path)                          # ensure rpa logger set up
        trail = make_trail(tmp_path)
        handler = trail.attach_log_handler()
        assert handler in logging.getLogger("finesiii_rpa_v3").handlers
        assert handler in logging.getLogger("finesiii_rpa_v3.rpa").handlers
        trail.close()
        assert handler not in logging.getLogger("finesiii_rpa_v3").handlers
        assert handler not in logging.getLogger("finesiii_rpa_v3.rpa").handlers


class TestFactory:
    def test_disabled_config_returns_none(self, tmp_path):
        assert maybe_start_audit_trail(None) is None
        assert maybe_start_audit_trail(
            make_cfg(tmp_path, audit_enabled=False)) is None

    def test_enabled_sqlite_backend_records_startup_event(self, tmp_path):
        trail = maybe_start_audit_trail(make_cfg(tmp_path))
        assert trail is not None
        assert trail.flush(timeout=5)
        started = trail.backend.query_events(action="audit_started")
        assert started and started[0]["detail"]["backend"] == "sqlite"
        trail.close()


class _RecordingConnection:
    """Stands in for a PostgreSQL connection: records every statement
    and answers the existence check."""

    def __init__(self, table_exists):
        self.table_exists = table_exists
        self.statements = []

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False

    def execute(self, sql, params=None):
        self.statements.append(" ".join(sql.split()))
        return self

    def fetchone(self):
        return {"t": "audit.audit_events" if self.table_exists else None}


class TestPostgresSchemaProvisionedByTheAdministrator:
    """A least-privilege role (USAGE + INSERT/SELECT) is refused by
    PostgreSQL for ANY CREATE statement, including a CREATE ... IF NOT
    EXISTS that would do nothing. With the table in place the backend
    must therefore issue no DDL at all, or the trail never delivers."""

    def _backend(self, table_exists):
        from src.modules.audit.trail_db import PostgresAuditBackend
        backend = PostgresAuditBackend("postgresql://unused")
        conn = _RecordingConnection(table_exists)
        backend._connect = lambda: conn
        return backend, conn

    def test_existing_table_means_no_ddl(self):
        backend, conn = self._backend(table_exists=True)
        backend.ensure_schema()
        assert len(conn.statements) == 1
        assert "to_regclass('audit.audit_events')" in conn.statements[0]
        assert not any(s.upper().startswith("CREATE")
                       for s in conn.statements)

    def test_missing_table_is_still_self_provisioned(self):
        backend, conn = self._backend(table_exists=False)
        backend.ensure_schema()
        created = [s for s in conn.statements
                   if s.upper().startswith("CREATE")]
        assert created[0] == "CREATE SCHEMA IF NOT EXISTS audit"
        assert any("CREATE TABLE IF NOT EXISTS audit.audit_events" in s
                   for s in created)
        assert sum("CREATE INDEX IF NOT EXISTS" in s for s in created) == 2
