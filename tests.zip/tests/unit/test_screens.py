"""Unit tests for the ported screens layer: field mapping rules,
result-code parsing, and the config-driven rpa config builder."""
import pytest

from src.core.exceptions import InvalidInputError
from src.rpa.config import build_rpa_config
from src.rpa.drivers.mock import MockDriver
from src.rpa.screens.field_mapper import AccountData, FieldMapper
from src.rpa.screens.state import ScreenState


class TestAccountData:
    def test_create_defaults(self):
        data = FieldMapper.build_create_data("822", "1217036", "Kxq@4821")
        assert data.affiliation_code == "00822"      # zero-padded
        assert data.audit_target == "1"
        assert len(data.processing_date) == 6        # auto-filled YYMMDD

    def test_delete_spec(self):
        """Delete: FID 104 EMPTY, date optional and left empty."""
        data = FieldMapper.build_delete_data("30822", "1217036")
        assert data.processing_type == "4"
        assert data.audit_target == ""
        assert data.processing_date == ""
        data.validate()                              # must be valid as-is

    def test_password_rules(self):
        with pytest.raises(InvalidInputError):
            FieldMapper.build_create_data(
                "30822", "1217036", password="short").validate()
        with pytest.raises(InvalidInputError):
            FieldMapper.build_create_data(
                "30822", "1217036", password="1UJI@33F").validate()

    def test_no_default_password(self):
        """A new account's password is always given: the builders have
        no default (UAT-L27, 2026-10-04)."""
        with pytest.raises(TypeError):
            FieldMapper.build_create_data("30822", "1217036")
        with pytest.raises(TypeError):
            FieldMapper.build_password_reset_data("30822", "1217036")

    def test_log_safe_dict_masks_password(self):
        data = FieldMapper.build_create_data("30822", "1217036", "Kxq@4821")
        assert data.to_log_safe_dict()["new_password"] == "****"


class TestFieldEntryOrder:
    def test_delete_types_only_type_affiliation_employee(self):
        driver = MockDriver()
        driver.initialize({})
        driver.screen = "task_903"
        mapper = FieldMapper(driver, {}, {"field_entry_delay": 0})
        mapper.enter_account_data(
            FieldMapper.build_delete_data("30822", "1217036"))
        assert driver.typed_values == ["4", "30822", "1217036"]

    def test_create_types_all_fields(self):
        driver = MockDriver()
        driver.initialize({})
        driver.screen = "task_903"
        mapper = FieldMapper(driver, {}, {"field_entry_delay": 0})
        data = FieldMapper.build_create_data("30822", "1217036",
                                             "FUJI@33F", "260803")
        mapper.enter_account_data(data)
        assert driver.typed_values == [
            "2", "1", "30822", "1217036", "FUJI@33F", "260803"]


class _StubDriver:
    """Minimal driver stub exposing a settable screen text."""

    def __init__(self, text):
        self.text = text

    def get_screen_text(self):
        return self.text


class TestTransactionResult:
    def _state(self, text):
        return ScreenState({}, _StubDriver(text))

    def test_o0000_success(self):
        result = self._state("処理結果\nO-0000").check_transaction_result()
        assert result == {"success": True, "code": "O-0000",
                          "raw_line": "O-0000",
                          "result_source": "screen"}

    def test_error_code_detected(self):
        result = self._state(
            "処理結果\nE-9901 所属コード誤り").check_transaction_result()
        assert result["success"] is False
        assert result["code"] == "E-9901"

    def test_unreadable_title_only_is_unconfirmed(self):
        """Title-only read (real terminal) must NOT be a failure."""
        result = self._state("FINESⅢ").check_transaction_result()
        assert result["success"] is True
        assert result["code"] == "UNCONFIRMED"


class TestRpaConfigBuilder:
    def test_keystroke_delay_reaches_drivers(self, tmp_path):
        """Approved fix: timing.keystroke_delay is merged into the
        application section, where the drivers read it."""
        cfg = build_rpa_config(driver="mock", environment="development",
                               evidence_dir=str(tmp_path))
        assert cfg["application"]["keystroke_delay"] == \
            cfg["timing"]["keystroke_delay"]

    def test_missing_v2_capture_points_present(self, tmp_path):
        """Approved fix: the four capture points v2 omitted are wired."""
        cfg = build_rpa_config(driver="mock", environment="development",
                               evidence_dir=str(tmp_path))
        points = set(cfg["evidence"]["capture_points"])
        assert {"confirmation_screen", "confirmation_mismatch",
                "already_deleted_screen", "login_failed"} <= points

    def test_scenario_and_strictness_flow_through(self, tmp_path):
        cfg = build_rpa_config(driver="mock", environment="development",
                               evidence_dir=str(tmp_path),
                               scenario="error",
                               strict_screen_detection=True)
        assert cfg["application"]["mock_scenario"] == "error"
        assert cfg["application"]["strict_screen_detection"] is True
