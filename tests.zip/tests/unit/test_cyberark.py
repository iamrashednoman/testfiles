"""Unit tests for the CyberArk integration (client + provider),
using httpx.MockTransport — no real network, no real vault."""
import os

import httpx
import pytest

from src.integrations.cyberark.config import CyberArkSettings
from src.integrations.cyberark.client import (
    CyberArkClient, CyberArkError, CyberArkUnavailable
)
from src.integrations.cyberark.provider import (
    CyberArkPasswordProvider, maybe_start_cyberark
)
from src.rpa.credentials import FINESIIICredentials


def make_settings(**overrides):
    base = dict(
        enabled=True, api_style="ccp",
        base_url="https://vault.corp.example.com",
        app_id="FINESIII_RPA", safe="RPA-FINESIII",
        object_name="finesiii-svc-account",
        target_env_var="TEST_CYBERARK_PASSWORD",
        refresh_interval_hours=4.0,
        max_retries=2, backoff_base_seconds=0.01, backoff_max_seconds=0.05,
    )
    base.update(overrides)
    return CyberArkSettings(**base)


@pytest.fixture(autouse=True)
def clean_target_env():
    os.environ.pop("TEST_CYBERARK_PASSWORD", None)
    yield
    os.environ.pop("TEST_CYBERARK_PASSWORD", None)


# ═══════════════════════════════════════════════════════════════
# Client — CCP + availability gate
# ═══════════════════════════════════════════════════════════════

class TestClientCCP:
    def test_fetch_returns_content_password(self):
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["path"] = request.url.path
            captured["params"] = dict(request.url.params)
            return httpx.Response(200, json={"Content": "FUJI@33F",
                                             "UserName": "finesiii-svc"})

        s = make_settings(health_check_enabled=False)
        c = CyberArkClient(s, transport=httpx.MockTransport(handler))
        assert c.fetch_password() == "FUJI@33F"
        assert captured["path"] == "/AIMWebService/api/Accounts"
        assert captured["params"] == {"AppID": "FINESIII_RPA",
                                      "Safe": "RPA-FINESIII",
                                      "Object": "finesiii-svc-account"}

    def test_empty_content_raises(self):
        def handler(request):
            return httpx.Response(200, json={"UserName": "x"})   # no Content
        s = make_settings(health_check_enabled=False)
        c = CyberArkClient(s, transport=httpx.MockTransport(handler))
        with pytest.raises(CyberArkError, match="no Content"):
            c.fetch_password()


class TestAvailabilityGate:
    def test_gate_down_on_network_error_skips_fetch(self):
        paths = []

        def handler(request):
            paths.append(request.url.path)
            raise httpx.ConnectError("refused")

        s = make_settings(health_check_enabled=True)
        c = CyberArkClient(s, transport=httpx.MockTransport(handler))
        with pytest.raises(CyberArkUnavailable):
            c.fetch_password()
        assert paths == ["/AIMWebService/api/Accounts"]   # single probe only

    def test_gate_down_on_503_skips_fetch(self):
        calls = {"n": 0}

        def handler(request):
            calls["n"] += 1
            return httpx.Response(503, text="unavailable")

        s = make_settings(health_check_enabled=True)
        c = CyberArkClient(s, transport=httpx.MockTransport(handler))
        with pytest.raises(CyberArkUnavailable):
            c.fetch_password()
        assert calls["n"] == 1            # gate is single-attempt, no retries


# ═══════════════════════════════════════════════════════════════
# Client — PVWA
# ═══════════════════════════════════════════════════════════════

class TestClientPVWA:
    def test_full_flow_logon_retrieve_logoff(self):
        log = []

        def handler(request: httpx.Request) -> httpx.Response:
            log.append((request.method, request.url.path))
            p = request.url.path
            if p.endswith("/auth/CyberArk/Logon"):
                return httpx.Response(200, json="TOKEN123")
            if p == "/PasswordVault/API/Accounts":
                return httpx.Response(200, json={"value": [{"id": "77_4"}]})
            if p == "/PasswordVault/API/Accounts/77_4/Password/Retrieve":
                return httpx.Response(200, json="PVWA@PW1")
            if p.endswith("/auth/Logoff"):
                return httpx.Response(200, json={})
            return httpx.Response(404, text=p)

        s = make_settings(api_style="pvwa", pvwa_username="svc",
                          pvwa_password="pw", health_check_enabled=False)
        c = CyberArkClient(s, transport=httpx.MockTransport(handler))
        assert c.fetch_password() == "PVWA@PW1"
        assert log == [
            ("POST", "/PasswordVault/API/auth/CyberArk/Logon"),
            ("GET", "/PasswordVault/API/Accounts"),
            ("POST", "/PasswordVault/API/Accounts/77_4/Password/Retrieve"),
            ("POST", "/PasswordVault/API/auth/Logoff"),
        ]

    def test_logoff_runs_even_when_retrieve_fails(self):
        log = []

        def handler(request):
            log.append(request.url.path)
            if request.url.path.endswith("/Logon"):
                return httpx.Response(200, json="T")
            if request.url.path == "/PasswordVault/API/Accounts":
                return httpx.Response(200, json={"value": []})   # no match
            if request.url.path.endswith("/Logoff"):
                return httpx.Response(200, json={})
            return httpx.Response(404)

        s = make_settings(api_style="pvwa", pvwa_username="svc",
                          pvwa_password="pw", health_check_enabled=False)
        c = CyberArkClient(s, transport=httpx.MockTransport(handler))
        with pytest.raises(CyberArkError, match="No account"):
            c.fetch_password()
        assert log[-1].endswith("/Logoff")               # session never dangles


# ═══════════════════════════════════════════════════════════════
# Provider — cache, env, credential propagation, outage handling
# ═══════════════════════════════════════════════════════════════

class _FakeClient:
    """Scriptable stand-in for CyberArkClient."""
    def __init__(self, passwords=None, fail_with=None):
        self.passwords = list(passwords or [])
        self.fail_with = fail_with
        self.fetch_calls = 0

    def fetch_password(self):
        self.fetch_calls += 1
        if self.fail_with is not None:
            raise self.fail_with
        return self.passwords.pop(0) if len(self.passwords) > 1 \
            else self.passwords[0]


def make_creds():
    return FINESIIICredentials(affiliation_code="12345",
                               application_id="1234567",
                               password="OLD00000")


class TestProvider:
    def test_refresh_updates_env_and_attached_credentials(self):
        fake = _FakeClient(passwords=["NEW@PW11"])
        p = CyberArkPasswordProvider(make_settings(), client=fake)
        creds = make_creds()
        p.attach_credentials(creds)

        p.refresh()
        assert os.environ["TEST_CYBERARK_PASSWORD"] == "NEW@PW11"
        assert creds.password == "NEW@PW11"              # updated in place
        assert p.status()["refresh_count"] == 1
        assert p.is_available() is True

    def test_get_password_serves_cache_without_refetch(self):
        fake = _FakeClient(passwords=["PW1"])
        p = CyberArkPasswordProvider(make_settings(), client=fake)
        p.refresh()
        assert p.get_password() == "PW1"
        assert p.get_password() == "PW1"
        assert fake.fetch_calls == 1                     # cached — API not hammered

    def test_failure_keeps_last_known_good(self):
        fake = _FakeClient(passwords=["GOOD@PW1"])
        p = CyberArkPasswordProvider(make_settings(), client=fake)
        creds = make_creds()
        p.attach_credentials(creds)
        p.refresh()

        fake.fail_with = CyberArkUnavailable("vault down")
        with pytest.raises(CyberArkUnavailable):
            p.refresh()

        assert p.is_available() is False                 # Inactive surfaced
        assert p.get_password() == "GOOD@PW1"            # last-known-good kept
        assert creds.password == "GOOD@PW1"
        assert os.environ["TEST_CYBERARK_PASSWORD"] == "GOOD@PW1"
        assert p.status()["failure_count"] == 1

    def test_outage_hooks_fire_on_transitions_only(self):
        events = []
        fake = _FakeClient(passwords=["PW1"])
        p = CyberArkPasswordProvider(
            make_settings(), client=fake,
            on_unavailable=lambda reason: events.append(("down", reason)),
            on_recovered=lambda: events.append(("up",)),
        )
        p.refresh()                                       # up (no event)

        fake.fail_with = CyberArkUnavailable("vault down")
        with pytest.raises(CyberArkError):
            p.refresh()                                   # down-transition → event
        with pytest.raises(CyberArkError):
            p.refresh()                                   # still down → NO new event

        fake.fail_with = None
        p.refresh()                                       # recovery → event

        assert [e[0] for e in events] == ["down", "up"]

    def test_start_falls_back_to_existing_env_password(self):
        os.environ["TEST_CYBERARK_PASSWORD"] = "OPERATOR1"
        fake = _FakeClient(fail_with=CyberArkError("boom"))
        p = CyberArkPasswordProvider(make_settings(), client=fake)
        p.start()                                         # degraded, not fatal
        try:
            assert p.get_password() == "OPERATOR1"
        finally:
            p.stop()

    def test_start_raises_without_any_password(self):
        fake = _FakeClient(fail_with=CyberArkError("boom"))
        p = CyberArkPasswordProvider(make_settings(), client=fake)
        with pytest.raises(RuntimeError, match="cannot start"):
            p.start()

    def test_status_contains_no_secrets(self):
        fake = _FakeClient(passwords=["S3CR3T@1"])
        p = CyberArkPasswordProvider(
            make_settings(pvwa_username="svc", pvwa_password="hunter2"),
            client=fake,
        )
        p.refresh()
        rendered = str(p.status())
        assert "S3CR3T@1" not in rendered
        assert "hunter2" not in rendered

    def test_maybe_start_returns_none_when_disabled(self, tmp_path,
                                                    monkeypatch):
        monkeypatch.delenv("CYBERARK_ENABLED", raising=False)
        cfg = tmp_path / "ca.yaml"
        cfg.write_text("cyberark:\n  enabled: false\n")
        assert maybe_start_cyberark(str(cfg)) is None
