"""QA fixes — background agent and entry point (BUG-004, BUG-050)."""
import threading
import time

import pytest

from tests.conftest import make_config


@pytest.fixture
def data_dir(tmp_path, monkeypatch):
    d = tmp_path / "data"
    d.mkdir()
    monkeypatch.setenv("FINESIII_DATA_DIR", str(d))
    return d


def _cfg(tmp_path):
    return make_config(tmp_path, terminal_driver="mock",
                       dispatcher_enabled=False,
                       log_dir=str(tmp_path / "logs"))


# ── BUG-004: a failed restart stops the agent instead of leaving it dead ─


class TestFailedRestart:
    def test_restart_failure_exits_with_1_and_cleans_up(self, tmp_path,
                                                        data_dir):
        from desktop import runtime
        from desktop.agent import AgentRunner, agent_lock_path
        from desktop.single_instance import SingleInstance

        def broken_factory():
            raise RuntimeError("settings could not be read")
        runner = AgentRunner(_cfg(tmp_path), cfg_factory=broken_factory,
                             poll_seconds=0.05)
        rc = {}
        t = threading.Thread(target=lambda: rc.setdefault("rc", runner.run()),
                             daemon=True)
        t.start()
        deadline = time.time() + 30
        while time.time() < deadline and runtime.find_running_agent() is None:
            time.sleep(0.05)
        assert runtime.find_running_agent() is not None
        runner.service._restart_requested.set()      # console: Restart
        t.join(timeout=30)
        assert not t.is_alive()
        assert rc["rc"] == 1
        assert runtime.read_runtime() is None
        lock = SingleInstance(agent_lock_path()).acquire()   # released
        lock.release()

    def test_restart_not_ready_counts_as_failure(self, tmp_path, data_dir,
                                                 monkeypatch):
        from desktop.agent import AgentRunner
        runner = AgentRunner(_cfg(tmp_path), cfg_factory=lambda: None)
        monkeypatch.setattr(runner.service, "restart", lambda: "url")
        monkeypatch.setattr(runner.service, "wait_until_ready",
                            lambda timeout=60.0: False)
        mounted = []
        monkeypatch.setattr(runner, "_mount", lambda: mounted.append(1))
        runner._restart()
        assert runner._exit_code == 1
        assert runner._stop.is_set()
        assert mounted == []


class TestStopUnresponsiveAgent:
    def test_is_held(self, tmp_path):
        from desktop.single_instance import SingleInstance
        path = tmp_path / "agent.lock"
        assert SingleInstance.is_held(path) is False     # no file
        lock = SingleInstance(path).acquire()
        try:
            assert SingleInstance.is_held(path) is True
            assert path.read_text().strip() != ""       # not truncated
        finally:
            lock.release()
        assert SingleInstance.is_held(path) is False

    def test_stop_reaches_agent_that_holds_the_lock_without_api(
            self, data_dir):
        from desktop import runtime
        from desktop.agent import agent_lock_path, stop_running_agent
        from desktop.single_instance import SingleInstance
        lock = SingleInstance(agent_lock_path()).acquire()

        def agent_loop():
            # What the agent's loop does: obey the stop file, release.
            deadline = time.time() + 10
            while time.time() < deadline and not runtime.stop_requested():
                time.sleep(0.05)
            runtime.clear_stop_request()
            lock.release()
        t = threading.Thread(target=agent_loop, daemon=True)
        t.start()
        try:
            assert stop_running_agent(timeout=10) == 0
        finally:
            t.join(timeout=10)
            lock.release()
        assert not SingleInstance.is_held(agent_lock_path())


# ── BUG-050: no option / unknown option → usage, not a stack trace ──


class TestEntryPointUsage:
    def test_unknown_option_prints_usage_and_exits_2(self, capsys):
        from desktop import app as app_module
        assert app_module.main(["--bogus"]) == 2
        out = capsys.readouterr()
        text = out.out + out.err
        assert "Unknown option '--bogus'" in text
        assert "--agent" in text and "--stop" in text
        assert "Traceback" not in text

    def test_help_exits_0(self, capsys):
        from desktop import app as app_module
        assert app_module.main(["--help"]) == 0
        assert app_module.main(["-h"]) == 0
        assert "--agent" in capsys.readouterr().out

    def test_no_option_without_window_support_prints_usage(
            self, monkeypatch, capsys):
        import importlib.util
        from desktop import app as app_module
        real = importlib.util.find_spec
        monkeypatch.setattr(
            importlib.util, "find_spec",
            lambda name, *a: None if name == "webview" else real(name, *a))
        monkeypatch.setattr(app_module, "run_window",
                            lambda: pytest.fail("window must not start"))
        assert app_module.main([]) == 2
        out = capsys.readouterr()
        text = out.out + out.err
        assert "not part of this delivery" in text
        assert "--agent" in text and "--stop" in text
        assert "requirements-desktop" not in text

    def test_no_option_with_window_support_opens_the_window(
            self, monkeypatch):
        import importlib.util
        from desktop import app as app_module
        real = importlib.util.find_spec
        monkeypatch.setattr(
            importlib.util, "find_spec",
            lambda name, *a: object() if name == "webview"
            else real(name, *a))
        monkeypatch.setattr(app_module, "run_window", lambda: 0)
        assert app_module.main([]) == 0
