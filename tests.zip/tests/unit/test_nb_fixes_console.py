"""Console fixes from the 28 September retest (NB-008, 012, 016, 018,
025, 029, 030, 031, 032 and the administrator-password help text).

The console has no build step and no browser test harness; the page
checks pin the contract between the page and the service (the
behaviour itself is checked in the browser)."""
import base64
import re
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

from src.modules.console import branding

UI = Path(__file__).resolve().parents[2] / "desktop" / "ui"
APP = (UI / "app.js").read_text(encoding="utf-8")
INDEX = (UI / "index.html").read_text(encoding="utf-8")
JST_OFFSET = timedelta(hours=9)


def _function(name: str) -> str:
    """The source of one top-level function of app.js."""
    start = re.search(rf"(async )?function {name}\(", APP).start()
    return APP[start:APP.index("\n}\n", start)]


# ── NB-008: audit date filters are Japan time on PostgreSQL ──────────

class _RecordingConnection:
    """Stands in for a PostgreSQL connection and records the parameters
    of every statement."""

    def __init__(self):
        self.params = []

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False

    def execute(self, sql, params=None):
        self.params.append(list(params or []))
        return self

    def fetchone(self):
        return {"c": 0}

    def fetchall(self):
        return []


class TestAuditBoundsAreJapanTime:
    def _backend(self):
        from src.modules.audit.trail_db import PostgresAuditBackend
        backend = PostgresAuditBackend("postgresql://unused")
        conn = _RecordingConnection()
        backend._connect = lambda: conn
        return backend, conn

    @staticmethod
    def _bounds(conn):
        return [p for params in conn.params for p in params
                if isinstance(p, datetime)]

    def _assert_all_jst(self, conn, expected):
        bounds = self._bounds(conn)
        assert len(bounds) == expected
        for b in bounds:
            assert b.tzinfo is not None, b
            assert b.utcoffset() == JST_OFFSET, b

    def test_query_events(self):
        backend, conn = self._backend()
        backend.query_events(date_from="2026-09-28", date_to="2026-09-28")
        self._assert_all_jst(conn, 2)
        start, end = self._bounds(conn)
        assert start.isoformat() == "2026-09-28T00:00:00+09:00"
        assert end.isoformat() == "2026-09-28T23:59:59.999999+09:00"

    def test_query_page(self):
        backend, conn = self._backend()
        backend.query_page(date_from="2026-09-01", date_to="2026-09-28")
        # The count and the page each carry both bounds.
        self._assert_all_jst(conn, 4)

    def test_aggregate(self):
        backend, conn = self._backend()
        backend.aggregate(date_from="2026-09-01", date_to="2026-09-28")
        self._assert_all_jst(conn, 2)


class TestBoundTs:
    def test_date_only_is_midnight_japan_time(self):
        from src.modules.audit.trail_db import _bound_ts
        assert _bound_ts("2026-09-28").isoformat() == \
            "2026-09-28T00:00:00+09:00"

    def test_naive_datetime_is_japan_time(self):
        from src.modules.audit.trail_db import _bound_ts
        dt = _bound_ts(datetime(2026, 9, 28, 12, 30))
        assert dt.utcoffset() == JST_OFFSET and dt.hour == 12

    def test_explicit_offset_is_kept(self):
        from src.modules.audit.trail_db import _bound_ts
        dt = _bound_ts("2026-09-28T00:00:00+00:00")
        assert dt.utcoffset() == timedelta(0)
        aware = datetime(2026, 9, 28, tzinfo=timezone.utc)
        assert _bound_ts(aware) is aware

    def test_insert_path_is_unchanged(self):
        from src.modules.audit.trail_db import _parse_ts
        assert _parse_ts("2026-09-28").tzinfo is None


# ── NB-029: ICO accepted for the browser icon only ───────────────────

ICO = b"\x00\x00\x01\x00\x01\x00" + b"\x10\x10\x00\x00" + b"\x00" * 40
CUR = b"\x00\x00\x02\x00\x01\x00" + b"\x10\x10\x00\x00" + b"\x00" * 40
PNG = b"\x89PNG\r\n\x1a\n" + b"\x00" * 40


def _url(kind: str, data: bytes) -> str:
    return f"data:image/{kind};base64," + base64.b64encode(data).decode()


class TestIcoBrowserIcon:
    @pytest.mark.parametrize("kind", ["x-icon", "vnd.microsoft.icon", "png"])
    def test_ico_favicon_is_stored_as_x_icon(self, kind):
        doc = branding.validate({"favicon": _url(kind, ICO)})
        assert doc["favicon"].startswith("data:image/x-icon;base64,")
        assert base64.b64decode(doc["favicon"].split(",", 1)[1]) == ICO

    def test_unchecked_vnd_icon_is_normalised(self):
        doc = branding.validate({"favicon": _url("vnd.microsoft.icon", ICO)},
                                content_keys=set())
        assert doc["favicon"].startswith("data:image/x-icon;base64,")

    @pytest.mark.parametrize("key", ["logo", "login_background",
                                     "email_logo", "email_banner"])
    @pytest.mark.parametrize("kind", ["x-icon", "png"])
    def test_ico_refused_for_other_images(self, key, kind):
        with pytest.raises(ValueError) as e:
            branding.validate({key: _url(kind, ICO)})
        assert "data URL" not in str(e.value)

    def test_ico_logo_message_is_plain(self):
        with pytest.raises(ValueError) as e:
            branding.validate({"logo": _url("png", ICO)})
        text = str(e.value)
        assert text.startswith("Logo ")
        assert "not a PNG, JPEG, GIF or WebP" in text
        assert "browser icon" in text

    def test_cursor_file_is_refused(self):
        with pytest.raises(ValueError, match="Browser icon is not a PNG, "
                                             "JPEG, GIF, WebP or ICO image"):
            branding.validate({"favicon": _url("x-icon", CUR)})

    def test_empty_icon_directory_is_refused(self):
        with pytest.raises(ValueError):
            branding.validate({"favicon": _url(
                "x-icon", b"\x00\x00\x01\x00\x00\x00" + b"\x00" * 20)})

    def test_favicon_messages_use_the_page_name(self):
        with pytest.raises(ValueError) as e:
            branding.validate({"favicon": "http://example.com/icon.ico"})
        assert str(e.value) == ("Browser icon must be a PNG, JPEG, GIF, WebP "
                                "or ICO image")
        with pytest.raises(ValueError) as e:
            branding.validate({"logo": "data:text/html;base64,PGI+"})
        assert str(e.value) == "Logo must be a PNG, JPEG, GIF or WebP image"

    def test_svg_stays_refused(self):
        with pytest.raises(ValueError, match="SVG"):
            branding.validate({"favicon": _url("svg+xml", b"<svg/>")})

    def test_png_favicon_unchanged(self):
        doc = branding.validate({"favicon": _url("png", PNG)})
        assert doc["favicon"].startswith("data:image/png;base64,")

    def test_page_offers_ico_for_the_icon_only(self):
        icon = re.search(r'<input id="br-icon"[^>]*accept="([^"]*)"', INDEX)
        assert "image/x-icon" in icon.group(1) and ".ico" in icon.group(1)
        assert "PNG, JPEG, GIF, WebP or ICO, up to 64 KB" in INDEX
        logo = re.search(r'<input id="br-logo"[^>]*accept="([^"]*)"', INDEX)
        assert "icon" not in logo.group(1)
        assert "data:image/x-icon;" in _function("readImage")


# ── NB-031: the operator role no longer holds users.view ─────────────

class TestOperatorUsersView:
    def test_operator_lacks_users_view(self):
        from src.modules.auth.permissions import BUILTIN_ROLES, PERMISSIONS
        assert "users.view" not in BUILTIN_ROLES["operator"]["permissions"]
        assert "users.view" in PERMISSIONS          # custom roles stay valid
        assert "users.view" in BUILTIN_ROLES["admin"]["permissions"]

    def test_existing_operator_role_is_resynced_on_start(self, tmp_path):
        from src.core.db import Database
        from src.modules.auth.store import UserStore
        db = Database("sqlite", sqlite_path=str(tmp_path / "r.db"))
        store = UserStore(db)
        store.ensure_builtin_roles()
        role = store.get_role("operator")
        role.permissions = role.permissions + ["users.view"]   # old release
        store.update_role(role)
        assert "users.view" in store.get_role("operator").permissions
        store.ensure_builtin_roles()                          # restart
        assert "users.view" not in store.get_role("operator").permissions

    def test_users_page_needs_users_manage(self):
        # Since 2026-10-03 (UR-05) users.view reads the page (access
        # reviews); changing anything still needs users.manage.
        assert ("show($('nav-users'), may('users.manage') || "
                "may('users.view'));") in APP
        loader = APP[APP.index("LOADERS.users = guard("):]
        loader = loader[:loader.index("\n});\n")]
        assert "show($('us-new'), may('users.manage'))" in loader
        # ...and, from F4 (UAT-L13), only on accounts this user may change.
        assert "if (!may('users.manage') || !mayChange(u)) return act;" in loader


# ── NB-012: numbers are typed into text fields ───────────────────────

class TestNumberFields:
    def test_no_number_type_fields(self):
        assert "type = 'number'" not in APP
        assert 'type="number"' not in APP and 'type="number"' not in INDEX
        assert "badInput" not in APP
        assert "valueAsNumber" not in APP

    def test_number_field_helper(self):
        helper = _function("numberField")
        assert "f.type = 'text'" in helper
        assert "inputMode" in helper and "'decimal'" in helper \
            and "'numeric'" in helper
        assert "autocomplete = 'off'" in helper
        assert "spellcheck = false" in helper
        assert "dataset.num = kind" in helper
        assert "numberField(field, 'int')" in _function("deployRow")
        assert "numberField(field, s.kind)" in _function("settingRow")

    def test_validation_reads_the_text(self):
        check = _function("invalidNumbers")
        assert "input[data-num]" in check
        assert "normalize('NFKC').trim()" in check
        assert "aria-invalid" in check
        assert "f.value = t" in check              # normalised text back
        assert "Nothing was saved." in _function("numbersMessage")


# ── NB-016: an unreachable audit database is not "turned off" ────────

def test_audit_errors_distinguish_unavailable_from_off():
    helper = _function("auditErrorText")
    assert "audit_unavailable" in helper and "e.status === 503" in helper
    assert "turned off on this service" in helper
    assert APP.count("'The audit trail is turned off on this service.'") == 1
    # The definition plus the audit page and the Reports page.
    assert APP.count("auditErrorText(e)") == 3


# ── NB-018: one message timer per box ────────────────────────────────

class TestMessageTimers:
    def test_msg_keeps_one_timer_per_box(self):
        helper = _function("msg")
        assert "clearTimeout(box._msgTimer)" in helper
        assert "box._msgTimer = setTimeout(" in helper

    @pytest.mark.parametrize("name", ["saveUser", "saveRole", "patchUser",
                                      "act1", "saveSettings", "testDatabase",
                                      "runWizardTest", "discoverFields",
                                      "wizardNext", "restartService"])
    def test_no_own_timers_or_direct_writes(self, name):
        body = _function(name)
        assert "setTimeout(" not in body
        assert "box.className =" not in body
        assert "box.textContent =" not in body

    def test_errors_stay_and_successes_clear(self):
        assert "msg('us-msg', 'err', e.message);" in _function("saveUser")
        assert "msg('rl-msg', 'err', e.message);" in _function("saveRole")
        assert re.search(r"msg\('us-msg', 'okmsg', .*6000\);",
                         _function("saveUser"), re.S)
        assert "msg('rl-msg', 'okmsg', 'Saved.', 6000);" in \
            _function("saveRole")


# ── NB-025: the PVWA password follows the CyberArk API ───────────────

def test_pvwa_password_shown_only_for_pvwa():
    assert ("CYBERARK_PVWA_PASSWORD: { key: 'CYBERARK_API_STYLE', "
            "value: ['pvwa'] }") in APP
    loader = _function("loadDeployment")
    assert "WIZARD_PAGES.map(p => p.secretShowWhen || {})" in loader


# ── NB-030: a revoked session on the password-change form ────────────

class TestPasswordChangeSessionEnded:
    def test_back_to_sign_in_button(self):
        form = INDEX[INDEX.index('<form id="form-change"'):]
        form = form[:form.index("</form>")]
        assert ('<button class="btn ghost" id="cp-back" type="button">'
                'Back to sign in</button>') in form
        assert "$('cp-back').onclick" in APP

    def test_401_returns_to_sign_in_with_a_reason(self):
        body = _function("doChange")
        assert "e.status === 401" in body
        assert body.index("await signOut()") < body.index("gateError(changed")
        assert "Your password was changed. Sign in with the new password." \
            in body
        assert "This session has ended. Sign in again." in body


# ── NB-032: a page saved with nothing entered counts as skipped ──────

def test_wizard_page_with_nothing_entered_is_skipped():
    body = _function("wizardNext")
    # A module set up earlier and left unchanged is "kept" (E2E-L02).
    assert ("WZ.state[id] = n ? 'saved' : (before === 'saved' ? 'saved' "
            ": kept ? 'kept' : 'skipped');") in body
    assert "Nothing was entered on that page — it counts as skipped." in body


# ── Initial administrator password help text ─────────────────────────

def test_initial_admin_password_help_says_it_is_removed():
    from src.modules.console.settings_help import tooltip
    text = tooltip("AUTH_DEFAULT_ADMIN_PASSWORD")
    assert "removed from the credential store automatically" in text
    assert "next start" in text
