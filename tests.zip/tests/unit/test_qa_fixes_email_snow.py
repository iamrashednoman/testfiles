"""QA fixes 2026-09-28 — e-mail / notifier and ServiceNow.

Pins, per bug:
  BUG-010  a configured account variable that is missing from the ticket
           holds the ticket instead of switching the cross-check off.
  BUG-067  an empty account after "for account:" never borrows the next
           line's first word.
  BUG-068  "an Entitlement Certification", "a Transfer".
"""
from scripts.run_mock_snow_server import TicketStore, multi_access_text
from src.integrations.servicenow import sailpoint
from src.integrations.servicenow.config import (
    SAILPOINT_FIELDS, load_servicenow_config,
)


def sp_settings(**kw):
    s = load_servicenow_config()
    s.instance_url = "https://mock.service-now.com"
    s.username, s.password = "finesiii.bot", "x"
    s.respect_service_health = False
    for k, v in kw.items():
        setattr(s, k, v)
    return s


def parse(store, task, s=None):
    ticket = {f: store.field(task, f) for f in SAILPOINT_FIELDS}
    return sailpoint.parse_ticket(ticket, store.variables[task["request_item"]],
                                  s or sp_settings())


# ── BUG-010 ──────────────────────────────────────────────────────

class TestAccountVariableLabel:
    def test_has_variable_ignores_the_value(self):
        rows = [{"label": "Account Name", "name": "account_name", "value": ""}]
        assert sailpoint.has_variable(rows, ["Account Name"]) is True
        assert sailpoint.has_variable(rows, ["account_name"]) is True
        assert sailpoint.has_variable(rows, ["Account ID"]) is False
        assert sailpoint.has_variable(rows, []) is False

    def test_wrong_account_label_holds_the_ticket(self):
        store = TicketStore()
        task = store.create_sailpoint("add", account="4821KQT",
                                      affiliation="01634", tracking="1")
        s = sp_settings()
        s.sp_variables = dict(s.sp_variables, account=["Account ID"])
        payloads, reason = parse(store, task, s)
        assert payloads is None
        assert "the account variable (Account ID) was not found" in reason
        assert "'Variable: account' setting" in reason

    def test_right_label_still_parses(self):
        store = TicketStore()
        task = store.create_sailpoint("add", account="4821KQT",
                                      affiliation="01634", tracking="1")
        payloads, reason = parse(store, task)
        assert reason == "" and payloads[0]["employee_code"] == "4821KQT"


# ── BUG-067 ──────────────────────────────────────────────────────

class TestEmptyAccountInText:
    def test_empty_account_is_missing_not_next_line(self):
        store = TicketStore()
        text = ("Access Request ID in myAIGaccess for tracking purpose is: 1\n"
                "Please provision/deprovision the below attributes for account:\n"
                "AttributeName=所属コード; Value=01634 | 部署; Operation=Add")
        task = store.create_sailpoint("add", account="", text=text)
        payloads, reason = parse(store, task)
        assert payloads is None
        assert reason == "the account name is missing"

    def test_account_on_the_same_line_still_read(self):
        m = sailpoint._ACCOUNT_RE.search("for account: \t4821KQT")
        assert m and m.group("account") == "4821KQT"


# ── BUG-068 ──────────────────────────────────────────────────────

class TestArticle:
    def test_an_entitlement_certification(self):
        store = TicketStore()
        text = multi_access_text("0000900099", "2099AAA",
                                 [("02099", "部署Z", "Add")],
                                 marker="Certification")
        task = store.create_sailpoint("certification", account="2099AAA",
                                      text=text)
        payloads, reason = parse(store, task)
        assert payloads is None
        assert reason.startswith("an Entitlement Certification can only "
                                 "remove access")

    def test_a_transfer_unchanged(self):
        store = TicketStore()
        text = multi_access_text("0000900098", "2098AAA",
                                 [("02098", "部署Y", "Add")], marker="Transfer")
        task = store.create_sailpoint("transfer", account="2098AAA", text=text)
        assert parse(store, task)[1].startswith("a Transfer can only remove")


# ── BUG-066 ──────────────────────────────────────────────────────

class TestInlinePasswordMasked:
    FLAT = {"operation": "u_operation", "affiliation_code": "u_aff",
            "employee_code": "u_emp", "ticket_number": "number"}

    def test_description_password_stored_masked(self):
        from src.integrations.servicenow.mapper import map_ticket
        ticket = {"number": "T1", "u_operation": "provision", "u_aff": "30822",
                  "u_emp": "1217036",
                  "description": "Please add.\nPassword: Abcd1234\nThanks",
                  "variables": {"note": "パスワード：Secret99 です"}}
        out = map_ticket(ticket, self.FLAT)
        details = out["metadata"]["snow_details"]
        assert "Abcd1234" not in details["description"]
        assert "Password: ****" in details["description"]
        assert "Secret99" not in details["variables"]["note"]
        # The input is never mutated.
        assert "Abcd1234" in ticket["description"]

    def test_ticket_supplied_password_still_reaches_the_request(self):
        from src.integrations.servicenow.mapper import enrich_ticket, map_ticket
        mapping = dict(self.FLAT, password="parsed.password")
        ticket = {"number": "T2", "u_operation": "provision", "u_aff": "30822",
                  "u_emp": "1217036", "description": "pwd: Zz9Q8w7e"}
        ticket = enrich_ticket(ticket, {"enabled": True, "labels": {
            "password": ["pwd"]}})
        out = map_ticket(ticket, mapping)
        assert out["password"] == "Zz9Q8w7e"
        assert "Zz9Q8w7e" not in str(out["metadata"])

    def test_sailpoint_variables_masked(self):
        store = TicketStore()
        text = ("Access Request ID in myAIGaccess for tracking purpose is: 7\n"
                "Please provision/deprovision the below attributes for "
                "account: 4821KQT\n"
                "AttributeName=所属コード; Value=01634 | 部署; Operation=Add\n"
                "Password: Abcd1234")
        task = store.create_sailpoint("add", account="4821KQT", text=text)
        payloads, reason = parse(store, task)
        assert reason == ""
        assert "Abcd1234" not in str(payloads[0]["metadata"])
        assert payloads[0]["password"] == ""

    def test_duplicate_comparison_is_symmetric(self):
        from src.integrations.servicenow import duplicates
        from src.integrations.servicenow.mapper import _redact_ticket
        raw = {"description": "Add me. Password: Abcd1234"}
        stored = _redact_ticket(raw)
        assert duplicates.matched_fields(stored, raw) == ["description"]
        assert "abcd1234" not in duplicates._scalar(raw["description"])


# ── e-mail helpers ───────────────────────────────────────────────

import logging
import time
from types import SimpleNamespace

from src.modules.notifications.config import NotificationSettings
from src.modules.notifications.notifier import EmailNotifier, valid_address


class _SMTP:
    def __init__(self, sink):
        self.sink = sink

    def send_message(self, msg, to_addrs=None):
        self.sink.append((msg, to_addrs))

    def quit(self):
        pass


def _notifier(sink, **kw):
    base = dict(enabled=True, smtp_host="smtp.test.local", smtp_port=587,
                use_starttls=True, use_ssl=False, username="",
                password="smtp-secret", mail_from="rpa@test.local",
                recipients_to=["dl@test.local"],
                environment_label="development", level="ERROR", mode="both",
                async_send=False, throttle_window_seconds=300.0,
                digest_interval_seconds=0.0, max_retries=0,
                backoff_base_seconds=0.0, backoff_max_seconds=0.0)
    base.update(kw)
    return EmailNotifier(NotificationSettings(**base),
                         smtp_factory=lambda: _SMTP(sink))


class _FakeNotifier:
    def __init__(self, delay=0.0):
        self.sent, self.delay = [], delay
        self.logger = None

    def send(self, subject, body, to=None, context=None, template_path=None,
             redact_body=True, cc=None, raw_subject=False, kind="",
             is_digest=False):
        if self.delay:
            time.sleep(self.delay)
        self.sent.append({"subject": subject, "body": body, "to": to,
                          "cc": cc, "redact": redact_body, "kind": kind,
                          "digest": is_digest, "context": context or {}})
        return True


def _txn(**kw):
    base = dict(transaction_id="txn_1", request_id="req_1",
                ticket_id="SCTASK100", operation="provision",
                affiliation_code="30822", employee_code="1217036",
                source="servicenow", status="done", result_code="O-0000",
                error_message="", attempt_count=1, submitted_at="",
                started_at="", completed_at="", duration_seconds=1.0,
                worker_id=0, evidence_path="evidence-store/txn_1",
                screenshot_count=3, operator="A1Z0835")
    base.update(kw)
    return SimpleNamespace(**base)


def _alerter(notifier, **kw):
    from src.modules.notifications.transaction_alerts import (
        TransactionAlerter, TransactionNotificationSettings,
    )
    return TransactionAlerter(notifier, TransactionNotificationSettings(
        enabled=True, **kw), bot_config={}, async_send=False)


# ── BUG-011 ──────────────────────────────────────────────────────

class TestNoticeWordingNotGarbled:
    def test_credentials_mail_without_password_reads_as_written(self):
        sink = []
        a = _alerter(_notifier(sink), include_password=False)
        a._send_user_credentials(_txn(), SimpleNamespace(
            password="FUJI@33F", metadata={"user_email": "taro@example.com"}))
        (msg, to), = sink
        body = msg.get_body(("plain",)).get_content()
        assert "Initial password: Will be provided to you separately." in body
        assert "FUJI@33F" not in body

    def test_credentials_mail_with_password_unchanged(self):
        sink = []
        a = _alerter(_notifier(sink), include_password=True)
        a._send_user_credentials(_txn(), SimpleNamespace(
            password="FUJI@33F", metadata={"user_email": "taro@example.com"}))
        # The password travels alone, in the client's password notice
        # (2026-09-29, E-16); the account-ready notice says so.
        ready, notice = (m for m, _ in sink)
        ready_body = ready.get_body(("plain",)).get_content()
        body = notice.get_body(("plain",)).get_content()
        assert "FUJI@33F" not in ready_body
        assert "Initial password: Sent to you in a separate e-mail." in ready_body
        assert "FUJI@33F" in body and "smtp-secret" not in body

    def _reporter(self, tmp_path, notifier, **kw):
        from src.modules.notifications.ticket_reports import (
            TicketReporter, TicketReportSettings,
        )
        base = dict(txn_enabled=True, report_enabled=True,
                    recipients_to=["support@example.com"],
                    contact_email="registration@example.com",
                    send_registration=True, send_password=False,
                    templates={"user_registration":
                               "email_templates/user_registration.txt",
                               "support_report":
                               "email_templates/support_report.txt"})
        base.update(kw)
        return TicketReporter(notifier, settings_loader=lambda:
                              TicketReportSettings(**base), async_send=False)

    def _request(self, email="kunal@example.com", password="ABCD@234",
                 name="Kunal Mittal"):
        return SimpleNamespace(
            request_id="r1", source="servicenow", operation="provision",
            affiliation_code="05001", employee_code="5004AAA",
            ticket_id="SCTASK9", password=password, status="done",
            result_code="O-0000", completed_at="x", error="",
            metadata={"category": "new_account", "user_email": email,
                      "affiliation_name": "営業部", "employee_name": name,
                      "parent_ticket": "SCTASK9", "parts": 1})

    def test_registration_notice_keeps_client_wording(self, tmp_path):
        sink = []
        r = self._reporter(tmp_path, _notifier(sink))
        req = self._request()
        r._user_notices(r._load(), _txn(), req)
        (msg, to), = sink
        body = msg.get_body(("plain",)).get_content()
        assert "Password: sent to you in a separate e-mail." in body
        assert "パスワード：別途メールにてお知らせいたします。" in body

    def test_request_password_in_context_is_masked(self, tmp_path):
        n = _FakeNotifier()
        r = self._reporter(tmp_path, n)
        # A person name that happens to carry the password text.
        req = self._request(name="ABCD@234")
        r._user_notices(r._load(), _txn(), req)
        reg = n.sent[0]
        assert reg["redact"] is False
        assert "ABCD@234" not in reg["body"] and "***" in reg["body"]


# ── BUG-012 ──────────────────────────────────────────────────────

class TestErrorAlertCc:
    RULES = {"LOGIN_PASSWORD_INCORRECT": {
        "to": ["identity-ops@example.com"],
        "cc": ["security-lead@example.com"],
        "subject": "FINESIII login rejected"}}

    def _alert(self, notifier):
        from src.modules.notifications.transaction_alerts import (
            ErrorAlertSettings,
        )
        a = _alerter(notifier, notify_on_failure=True)
        a.s.error_alerts = ErrorAlertSettings(enabled=True, rules=self.RULES)
        a.handle_completion(_txn(status="failed"), None,
                            {"error_id": "LOGIN_PASSWORD_INCORRECT"})

    def test_rule_cc_reaches_send(self):
        n = _FakeNotifier()
        self._alert(n)
        assert n.sent[0]["to"] == ["identity-ops@example.com"]
        assert n.sent[0]["cc"] == ["security-lead@example.com"]

    def test_real_notifier_puts_cc_in_header_and_envelope(self):
        sink = []
        self._alert(_notifier(sink))
        (msg, to_addrs), = sink
        assert msg["Cc"] == "security-lead@example.com"
        assert "security-lead@example.com" in to_addrs
        assert "identity-ops@example.com" in to_addrs


# ── BUG-013 ──────────────────────────────────────────────────────

class TestAlertsDrainedOnClose:
    def test_queued_alerts_and_final_digest_sent(self):
        from src.modules.notifications.log_handler import EmailAlertHandler
        n = _FakeNotifier(delay=0.05)
        settings = _notifier([], async_send=True, mode="both",
                             digest_interval_seconds=0.0, timeout_seconds=5).s
        h = EmailAlertHandler(n, settings)
        for word in ("alpha", "bravo", "charlie"):
            h.emit(logging.LogRecord("finesiii_rpa_v3", logging.ERROR, __file__,
                                     1, f"distinct failure {word}", None, None))
        h.close()
        alerts = [m for m in n.sent if not m["digest"]]
        digests = [m for m in n.sent if m["digest"]]
        assert len(alerts) == 3 and len(digests) == 1


# ── BUG-041 ──────────────────────────────────────────────────────

class TestUserAddressValidated:
    def test_valid_address(self):
        assert valid_address("taro.yamada@example.co.jp")
        for bad in ("not-an-email", "a@b", "a@@b.com", "a b@x.com",
                    "a@x.com\r\nBcc: evil@x.com", "a@x.com,b@x.com",
                    "<a@x.com>", "a;b@x.com", "", None, " a@x.com",
                    "a@-x.com"):
            assert not valid_address(bad), bad

    def test_credentials_mail_not_sent_to_invalid_address(self):
        for bad in ("not-an-email", "a@x.com\r\nBcc: evil@x.com"):
            n = _FakeNotifier()
            logs = []
            a = _alerter(n)
            a.logger = SimpleNamespace(info=logs.append, warning=logs.append)
            a._send_user_credentials(_txn(), SimpleNamespace(
                password="FUJI@33F", metadata={"user_email": bad}))
            assert n.sent == []
            assert any("not valid" in m for m in logs)
            assert all("evil@x.com" not in m for m in logs)

    def test_ticket_notices_not_sent_and_report_says_so(self, tmp_path):
        from src.modules.notifications.ticket_reports import NOTICE_MARK
        n = _FakeNotifier()
        t = TestNoticeWordingNotGarbled()
        r = t._reporter(tmp_path, n, send_password=True)
        req = t._request(email="kunal@@example.com")
        r._user_notices(r._load(), _txn(), req)
        assert n.sent == []
        assert req.metadata[NOTICE_MARK]["reason"] == "invalid e-mail address"
        r._support_report(r._load(), req)
        report = n.sent[-1]
        assert report["kind"] == "support_report"
        assert "address is not valid" in report["body"]
        assert "ABCD@234" not in report["body"]


# ── BUG-065 ──────────────────────────────────────────────────────

class TestNoEvidenceFolderInEmails:
    def test_failure_mail_has_no_evidence_path(self):
        sink = []
        a = _alerter(_notifier(sink, html_enabled=True))
        a.handle_completion(_txn(status="failed", error_message="boom"),
                            None, {})
        (msg, _), = sink
        plain = msg.get_body(("plain",)).get_content()
        html = msg.get_body(("html",)).get_content()
        for text in (plain, html):
            assert "evidence-store" not in text
            assert "Evidence path" not in text
        assert "Screenshots" in plain


# ── BUG-061 / BUG-062 : poller reasons and outage memory ─────────

class _FailingClient:
    def __init__(self, text):
        self.text = text

    def fetch_assigned_open(self):
        from src.integrations.servicenow.client import ServiceNowError
        raise ServiceNowError(self.text)


class TestPollerReasons:
    def _app(self, tmp_path, monkeypatch):
        from src import create_app
        from tests.conftest import make_config
        monkeypatch.setenv("FINESIII_DATA_DIR", str(tmp_path / "data"))
        (tmp_path / "data").mkdir(exist_ok=True)
        app = create_app(make_config(tmp_path, dispatcher_enabled=False,
                                     terminal_driver="mock",
                                     log_dir=str(tmp_path / "logs")))
        self.downs, self.ups = [], []
        test = self

        class Alerter:
            def component_down(self, component, reason):
                test.downs.append(reason)

            def component_recovered(self, component):
                test.ups.append(component)
        app.state.availability_alerter = Alerter()
        return app

    def _poller(self, app, text):
        from desktop.snow_poller import ServiceNowPoller
        from src.integrations.servicenow.connector import ServiceNowConnector
        poller = ServiceNowPoller(app, "http://127.0.0.1:1")
        poller.FAILURE_ALERT_THRESHOLD = 1
        settings = sp_settings()
        poller._build_connector = lambda: (
            ServiceNowConnector(settings, client=_FailingClient(text)),
            settings)
        return poller

    def test_explain_error(self):
        from src.integrations.servicenow.client import explain_error
        cases = {
            "GET https://x/api/now/table/sc_task failed: 401 {}": "sign-in rejected",
            "GET https://x/api/now/table/sc_task failed: 403 {}": "sign-in rejected",
            "OAuth token request failed: 400 invalid_client": "OAuth token",
            "OAuth token request failed (network): boom": "not reachable",
            "Network error after 1 attempts: [Errno 8] nodename": "not reachable",
            "ServiceNow answered GET /api with something other than data "
            "(HTTP 200, text/html) — it looks like a sign-in page": "sign-in page",
            "GET https://x/api/now/table/sc_tsk failed: 404 {}": "table not found",
            'GET https://x/api/now/table/sc_tsk failed: 400 '
            '{"error":{"message":"Invalid table sc_tsk"}}': "table not found",
            "Server error 503: retries exhausted": "server error",
            "Rate limited (429): retries exhausted": "rate limited",
        }
        for text, want in cases.items():
            assert want in explain_error(text), text
        assert explain_error("something odd") == ""
        assert explain_error("sysparm_limit=400 failed oddly") == ""

    def test_reason_on_system_card_and_outage_mail(self, tmp_path, monkeypatch):
        app = self._app(tmp_path, monkeypatch)
        poller = self._poller(app, "GET https://x/api/now/table/sc_task "
                                   "failed: 401 {\"error\":\"User Not Authenticated\"}")
        poller._poll_once()
        status = poller.status()
        assert "sign-in rejected" in status["last_error"]
        assert "User Not Authenticated" not in status["last_error"]
        assert "error_detail" not in status["last_stats"]
        assert len(self.downs) == 1 and "sign-in rejected" in self.downs[0]

    def test_outage_mail_not_repeated_after_restart(self, tmp_path, monkeypatch):
        app = self._app(tmp_path, monkeypatch)
        text = "Network error after 1 attempts: timed out"
        self._poller(app, text)._poll_once()
        assert len(self.downs) == 1
        # A new poller (agent restart) that fails once more: no second mail.
        again = self._poller(app, text)
        assert again._alerted_down is True
        again._poll_once()
        assert len(self.downs) == 1
        # Recovery is still announced.
        again._record({"fetched": 0}, "")
        assert self.ups == ["ServiceNow Polling"]
        assert self._poller(app, text)._alerted_down is False


# ── BUG-042 / BUG-063 : settings checks ──────────────────────────

class TestSettingChecks:
    def _coerce(self, key, raw):
        from src.modules.console.settings_catalogue import BY_KEY, coerce
        return coerce(BY_KEY[key], raw)

    def test_address_lists(self):
        import pytest
        assert self._coerce("ALERT_TO", "a@x.example, b@x.example") == \
            "a@x.example,b@x.example"
        assert self._coerce("SUPPORT_REPORT_CC", "") == ""
        for key in ("ALERT_TO", "ALERT_CC", "ERROR_ALERT_TO", "ERROR_ALERT_CC",
                    "SUPPORT_REPORT_TO", "SUPPORT_REPORT_CC"):
            with pytest.raises(ValueError, match="is not an e-mail address"):
                self._coerce(key, "a@x.exampleBcc: other@x.example")
            with pytest.raises(ValueError):
                self._coerce(key, "ok@x.example,not-an-email")

    def test_single_addresses(self):
        import pytest
        assert self._coerce("ALERT_FROM", "FINESIII Bot <bot@x.example>") == \
            "FINESIII Bot <bot@x.example>"
        assert self._coerce("ALERT_FROM", "bot@x.example") == "bot@x.example"
        assert self._coerce("EMAIL_CONTACT_ADDRESS", "") == ""
        for raw in ("Bot <bot@x.example>, evil@x.example", "not-an-email",
                    "Bot <bot@x.example> x"):
            with pytest.raises(ValueError):
                self._coerce("ALERT_FROM", raw)
        with pytest.raises(ValueError):
            self._coerce("EMAIL_CONTACT_ADDRESS", "Desk <desk@x.example>")

    def test_invalid_stored_value_skipped_with_warning(self, tmp_path, caplog):
        from src.core.db import Database
        from src.modules.console.settings_store import (
            SettingsStore, _restore_env_overrides, apply_hot_env,
        )
        from tests.conftest import make_config
        db = Database.from_config(make_config(tmp_path))
        store = SettingsStore(db)
        store.set("SUPPORT_REPORT_TO", "x@y.exampleBcc: z@y.example")
        try:
            with caplog.at_level(logging.WARNING, logger="finesiii_rpa_v3"):
                apply_hot_env(store)
            assert "SUPPORT_REPORT_TO" in caplog.text
            assert "z@y.example" not in caplog.text
        finally:
            _restore_env_overrides()
            db.close()

    def test_star_means_no_check(self, monkeypatch):
        import pytest
        from src.integrations.servicenow.config import load_servicenow_config
        for key in ("SNOW_APPLICATION_IDS", "SNOW_ACCEPTED_INSTANCES"):
            assert self._coerce(key, "*") == "*"
            with pytest.raises(ValueError, match="only value"):
                self._coerce(key, "*,2565")
        monkeypatch.delenv("SNOW_APPLICATION_IDS", raising=False)
        monkeypatch.delenv("SNOW_ACCEPTED_INSTANCES", raising=False)
        s = load_servicenow_config()
        assert s.sp_application_ids and s.sp_accepted_instances  # defaults
        monkeypatch.setenv("SNOW_APPLICATION_IDS", "*")
        monkeypatch.setenv("SNOW_ACCEPTED_INSTANCES", "*")
        s = load_servicenow_config()
        assert s.sp_application_ids == [] and s.sp_accepted_instances == []

    def test_star_accepts_any_application_and_instance(self, monkeypatch):
        store = TicketStore()
        task = store.create_sailpoint("add", account="4821KQT",
                                      affiliation="01634", tracking="1",
                                      application="Other App [9999]",
                                      instance="Dev")
        s = sp_settings()
        payloads, reason = parse(store, task, s)
        assert payloads is None                   # defaults refuse it
        monkeypatch.setenv("SNOW_APPLICATION_IDS", "*")
        monkeypatch.setenv("SNOW_ACCEPTED_INSTANCES", "*")
        payloads, reason = parse(store, task, sp_settings())
        assert reason == "" and payloads[0]["employee_code"] == "4821KQT"


# ── BUG-030 : the failure work note is written once ──────────────

class _SnowClient:
    def __init__(self):
        self.calls = []

    def get_records(self, table, query="", fields=None, limit=10):
        return [{"sys_id": "a" * 32}]

    def set_state(self, sys_id, state, note=None, table="", extra=None):
        self.calls.append(("close", note))

    def add_work_note(self, sys_id, note, table=""):
        self.calls.append(("note", note))


class TestFailureNoteOnce:
    def _setup(self, tmp_path):
        from src.core.db import Database
        from src.integrations.servicenow.writeback import TicketCloseout
        from src.modules.intake.models import ProcessingRequest
        from src.modules.queue.services import QueueStore
        from tests.conftest import make_config
        db = Database.from_config(make_config(tmp_path))
        store = QueueStore(db)
        s = load_servicenow_config()
        s.instance_url, s.username = "https://x", "finesiii.bot"
        client = _SnowClient()
        co = TicketCloseout(settings_loader=lambda: s,
                            client_factory=lambda st: client,
                            async_send=False, sleep_func=lambda d: None)
        co.queue_store = store
        co.GRACE_SECONDS = 0.0
        req = ProcessingRequest(
            operation="provision", affiliation_code="30822",
            employee_code="1217036", ticket_id="SCTASK0070",
            source="servicenow",
            metadata={"snow_details": {"sys_id": "a" * 32,
                                       "number": "SCTASK0070"}})
        store.enqueue(req)
        running = store.dequeue_oldest(worker_id=1)
        store.mark_complete(req.request_id, "failed", error="centre not ready")
        return db, store, co, client, running

    def test_stale_in_memory_request_then_reconcile(self, tmp_path):
        db, store, co, client, running = self._setup(tmp_path)
        try:
            assert running.status == "running"         # what the hook gets
            txn = _txn(status="failed", ticket_id="SCTASK0070",
                       request_id=running.request_id,
                       error_message="centre not ready")
            co.handle_completion(txn, running, {})
            assert [c[0] for c in client.calls] == ["note"]
            fresh = store.get(running.request_id)
            assert fresh.metadata["snow_writeback"]["outcome"].startswith(
                "failed:")
            assert co.reconcile(fresh) is False
            assert len(client.calls) == 1
        finally:
            db.close()

    def test_legacy_running_mark_counts_as_delivered(self, tmp_path):
        db, store, co, client, running = self._setup(tmp_path)
        try:
            store.set_metadata_value(running.request_id, "snow_writeback", {
                "outcome": "running:", "action": "failure_note",
                "pending": False, "rounds": 0, "note": ""})
            assert co.reconcile(store.get(running.request_id)) is False
            assert client.calls == []
            mark = store.get(running.request_id).metadata["snow_writeback"]
            assert mark["outcome"].startswith("failed:")
            assert mark["action"] == "failure_note"
            # And stays delivered on the next poll.
            assert co.reconcile(store.get(running.request_id)) is False
            assert client.calls == []
        finally:
            db.close()

    def test_retry_still_gets_a_new_note(self, tmp_path):
        db, store, co, client, running = self._setup(tmp_path)
        try:
            co.handle_completion(_txn(status="failed", ticket_id="SCTASK0070",
                                      request_id=running.request_id),
                                 running, {})
            store.retry(running.request_id)
            again = store.dequeue_oldest(worker_id=1)
            time.sleep(0.01)
            store.mark_complete(running.request_id, "failed", error="again")
            assert co.reconcile(store.get(running.request_id)) is True
            assert [c[0] for c in client.calls] == ["note", "note"]
            assert again.status == "running"
        finally:
            db.close()
