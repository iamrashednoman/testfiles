"""Desktop shell — single instance, service lifecycle, graceful drain.

The window itself needs a display and is exercised by hand; everything
underneath it is testable and is what actually protects a running
transaction.
"""
import threading
import time

import pytest

from desktop.server import EmbeddedService
from desktop.single_instance import AlreadyRunningError, SingleInstance
from tests.conftest import make_config


class TestSingleInstance:
    """Two dispatchers against one database would both claim work, and
    the platform's concurrency model is one terminal session."""

    def test_second_instance_is_refused(self, tmp_path):
        lock = tmp_path / "desktop.lock"
        first = SingleInstance(lock).acquire()
        try:
            with pytest.raises(AlreadyRunningError):
                SingleInstance(lock).acquire()
        finally:
            first.release()

    def test_lock_is_reusable_after_release(self, tmp_path):
        lock = tmp_path / "desktop.lock"
        SingleInstance(lock).acquire().release()
        second = SingleInstance(lock).acquire()
        second.release()

    def test_context_manager_releases(self, tmp_path):
        lock = tmp_path / "desktop.lock"
        with SingleInstance(lock):
            pass
        SingleInstance(lock).acquire().release()

    def test_pid_is_recorded_for_humans(self, tmp_path):
        import os
        lock = tmp_path / "desktop.lock"
        held = SingleInstance(lock).acquire()
        try:
            assert lock.read_text().strip() == str(os.getpid())
        finally:
            held.release()

    def test_release_is_idempotent(self, tmp_path):
        held = SingleInstance(tmp_path / "desktop.lock").acquire()
        held.release()
        held.release()          # must not raise


class TestPortSelection:
    def test_prefers_the_configured_port(self):
        import socket
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(("127.0.0.1", 0))
            free = s.getsockname()[1]
        assert EmbeddedService.pick_port(free) == free

    def test_falls_back_when_the_port_is_taken(self):
        """A desktop app must never fail to start because something
        else holds 8000."""
        import socket
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as taken:
            taken.bind(("127.0.0.1", 0))
            taken.listen(1)
            busy = taken.getsockname()[1]
            chosen = EmbeddedService.pick_port(busy)
            assert chosen != busy and chosen > 0


@pytest.fixture
def service(tmp_path):
    def build():
        return make_config(tmp_path, dispatcher_enabled=True,
                           terminal_driver="mock",
                           log_dir=str(tmp_path / "logs"))
    # cfg_factory: restart() must rebuild THIS test's configuration, not
    # re-read the process environment — the repo's .env is a deployment
    # copy (Postgres), which is not what the test is exercising.
    svc = EmbeddedService(build(), cfg_factory=build)
    yield svc
    svc.stop(drain_timeout=15)


class TestEmbeddedService:
    def test_starts_and_serves_the_existing_api(self, service):
        import json
        import urllib.request

        url = service.start()
        assert service.wait_until_ready(timeout=30), "never became ready"
        with urllib.request.urlopen(
                f"{url}/api/v1/health", timeout=5) as r:
            body = json.load(r)
        assert body["service"] == "up"

    def test_binds_only_to_loopback(self, service):
        """The embedded service must not be reachable from the network:
        it is a desktop app's private backend."""
        assert service.start().startswith("http://127.0.0.1:")

    def test_stop_is_clean_and_idempotent(self, service):
        service.start()
        assert service.wait_until_ready(timeout=30)
        assert service.stop(drain_timeout=30) is True
        assert service.stop() is True

    def test_restart_keeps_the_same_port(self, service):
        """Settings changes rebuild the app; the window must not have
        to reload a different URL."""
        first = service.start()
        assert service.wait_until_ready(timeout=30)
        second = service.restart()
        assert second == first
        assert service.wait_until_ready(timeout=30)

    def test_not_busy_when_idle(self, service):
        service.start()
        assert service.wait_until_ready(timeout=30)
        assert service.is_busy() is False

    def test_busy_is_safe_before_start(self, service):
        """Called from the window's close handler, which can fire at
        any point in the lifecycle."""
        assert service.is_busy() is False

    def test_wait_until_ready_reports_a_dead_server(self, service,
                                                    monkeypatch):
        """A startup crash must surface as 'not ready', not as a hang
        until the timeout."""
        service.start()
        service.wait_until_ready(timeout=30)
        service._thread = threading.Thread(target=lambda: None)
        service._thread.start()
        service._thread.join()
        started = time.time()
        assert service.wait_until_ready(timeout=10) is False
        assert time.time() - started < 5, "did not fail fast"


class TestGracefulDrain:
    def test_stop_waits_for_an_in_flight_transaction(self, tmp_path):
        """THE reason the shell exists in this shape: a transaction is
        a live session on the FINESIII terminal, and quitting must not
        abandon it half-finished."""
        cfg = make_config(tmp_path, dispatcher_enabled=True,
                          terminal_driver="mock",
                          log_dir=str(tmp_path / "logs"))
        service = EmbeddedService(cfg)
        service.start()
        assert service.wait_until_ready(timeout=30)

        drained = threading.Event()

        # Patch the dispatcher INSTANCE, not app.state: create_app's
        # lifespan closes over its own `dispatcher` local, so swapping
        # app.state.dispatcher would not be what shutdown calls. Same
        # object in production — this just makes the test patch the
        # reference the shutdown path actually uses.
        dispatcher = service.app.state.dispatcher
        original_stop = dispatcher.stop

        def slow_stop():
            time.sleep(0.4)          # stands in for finishing the txn
            drained.set()
            return original_stop()

        dispatcher.stop = slow_stop
        dispatcher.status = lambda: {"busy": not drained.is_set()}

        assert service.is_busy() is True
        assert service.stop(drain_timeout=30) is True
        assert drained.is_set(), "stopped without draining"

    def test_drain_timeout_is_reported_not_hidden(self, tmp_path):
        """If a transaction outlives the drain window the operator must
        be told, because the terminal is then in an unknown state."""
        cfg = make_config(tmp_path, dispatcher_enabled=True,
                          terminal_driver="mock",
                          log_dir=str(tmp_path / "logs"))
        service = EmbeddedService(cfg)
        service.start()
        assert service.wait_until_ready(timeout=30)

        dispatcher = service.app.state.dispatcher
        original_stop = dispatcher.stop
        dispatcher.stop = lambda: (time.sleep(2), original_stop())[-1]

        assert service.stop(drain_timeout=0.5) is False
        service.stop(drain_timeout=30)


def _fake_webview(monkeypatch, on_create=None):
    """Stand-in for pywebview.

    run() imports it first thing, and the control-plane venv has no GUI
    toolkit installed — faking it keeps the shell's ORDERING and
    SHUTDOWN logic testable on any machine, with or without a display.
    """
    import sys as _sys

    module = type(_sys)("webview")

    class _Events:
        closing = type("E", (), {"__iadd__": lambda s, o: s})()

    class _Window:
        events = _Events()

        def destroy(self):
            pass

    def create_window(*a, **kw):
        if on_create is not None:
            on_create()
        return _Window()

    module.create_window = create_window
    module.start = lambda: None
    monkeypatch.setitem(_sys.modules, "webview", module)
    return module


class TestSignalArmingOrder:
    """A signal mask is per-thread and INHERITED AT CREATION.

    Arming it after the uvicorn thread exists leaves that thread
    unmasked, so SIGTERM is delivered there and its default action
    kills the process with a transaction still live on the terminal.
    Found the hard way: the app had to be SIGKILLed.
    """

    def test_signals_are_armed_before_the_server_thread(self, tmp_path,
                                                        monkeypatch):
        """Ordering only — deliberately does NOT touch real signal
        masks: arming them for real would block SIGINT/SIGTERM for the
        whole pytest process and leave a sigwait thread swallowing
        Ctrl-C."""
        from desktop import shell as shell_module

        order = []

        monkeypatch.setattr(
            shell_module.DesktopShell, "_install_signal_handlers",
            lambda self: order.append("signals"))

        def spy_start(self, port=0):
            order.append("server")
            raise RuntimeError("stop here — we only need the ordering")

        monkeypatch.setattr(shell_module.EmbeddedService, "start",
                            spy_start)
        monkeypatch.setattr(shell_module, "_lock_path",
                            lambda: tmp_path / "desktop.lock")
        _fake_webview(monkeypatch)

        cfg = make_config(tmp_path, terminal_driver="mock",
                          log_dir=str(tmp_path / "logs"))
        with pytest.raises(RuntimeError):
            shell_module.DesktopShell(cfg, embedded=True).run()

        assert order == ["signals", "server"], (
            "signals must be armed BEFORE the uvicorn thread exists — a "
            "mask is inherited at thread creation, so arming late "
            "leaves that thread able to take SIGTERM and die by default "
            f"action (got {order})")

    def test_a_signal_during_startup_still_drains(self, tmp_path,
                                                  monkeypatch):
        """The window may not exist yet when the signal lands; the app
        must still shut the service down instead of hanging in
        webview.start()."""
        from desktop import shell as shell_module

        monkeypatch.setattr(shell_module, "_lock_path",
                            lambda: tmp_path / "desktop.lock")
        cfg = make_config(tmp_path, terminal_driver="mock",
                          log_dir=str(tmp_path / "logs"))
        shell = shell_module.DesktopShell(cfg, embedded=True)

        stopped = {}
        monkeypatch.setattr(shell.service, "start", lambda port=0: "u")
        monkeypatch.setattr(shell.service, "wait_until_ready",
                            lambda timeout=60: True)
        monkeypatch.setattr(shell, "_mount_ui", lambda: None)
        monkeypatch.setattr(
            shell.service, "stop",
            lambda drain_timeout=None: stopped.setdefault("yes", True))

        _fake_webview(
            monkeypatch,
            on_create=shell._closing.set)   # signal lands during startup

        assert shell.run() == 0
        assert stopped.get("yes"), "service was not stopped"
