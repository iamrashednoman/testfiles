"""`--configure` — the install-time step every installer calls (P4).

Supervisor registration touches schtasks/launchctl and is exercised on
the target machines; here it is stubbed. What IS pinned: the file it
writes, where secrets go (vault vs. hand-off file), that no secret is
taken from the command line or printed, that the database check gates
success, and that the agent imports the hand-off on first start.
"""
import json
import os

import pytest

from tests.conftest import make_config


@pytest.fixture
def data_dir(tmp_path, monkeypatch):
    d = tmp_path / "data"
    d.mkdir()
    monkeypatch.setenv("FINESIII_DATA_DIR", str(d))
    # An isolated sqlite DB for the check step.
    monkeypatch.setenv("SQLITE_PATH", str(d / "x.db"))
    return d


@pytest.fixture
def memory_vault(monkeypatch):
    from desktop import vault
    previous = vault._vault
    store = vault.MemoryVault()
    vault.use_vault(store)
    for k in vault.SECRET_KEYS:
        monkeypatch.delenv(k, raising=False)
    yield store
    vault.use_vault(previous)


class TestConfigure:
    def test_writes_file_stores_secrets_and_checks(self, data_dir,
                                                   memory_vault, monkeypatch,
                                                   capsys):
        from desktop import configure, deployment
        monkeypatch.setenv("INSTALL_DB_PW", "db-s3cret")
        monkeypatch.setenv("INSTALL_ADMIN_PW", "Adm1nProvisional!")
        rc = configure.main([
            "--db-url", f"sqlite:///{data_dir / 'x.db'}",
            "--driver", "simulator", "--environment", "development",
            "--ocr", "off", "--api-port", "8811", "--auth", "on",
            "--db-password-env", "INSTALL_DB_PW",
            "--admin-password-env", "INSTALL_ADMIN_PW"])
        assert rc == 0
        on_disk = deployment.read()
        assert on_disk["DATABASE_ENGINE"] == "sqlite"
        assert on_disk["TERMINAL_DRIVER"] == "simulator"
        assert on_disk["OCR_ENABLED"] == "false"
        assert on_disk["API_PORT"] == "8811"
        assert on_disk["AUTH_ENABLED"] == "true"
        assert on_disk["AUTH_CONSOLE_GRANTS_API"] == "true"
        assert memory_vault.get("DATABASE_PASSWORD") == "db-s3cret"
        assert memory_vault.get("AUTH_DEFAULT_ADMIN_PASSWORD") == \
            "Adm1nProvisional!"
        assert memory_vault.get("FINESIII_API_KEYS").startswith("installer:")
        text = deployment.deployment_file().read_text()
        out = capsys.readouterr().out
        for secret in ("db-s3cret", "Adm1nProvisional!"):
            assert secret not in text and secret not in out

    def test_password_in_url_is_split_out(self, data_dir, memory_vault):
        from desktop import configure, deployment
        rc = configure.main(["--db-url", "postgresql://app:Pw%40x@h:5/db",
                             "--no-check"])
        assert rc == 0
        assert deployment.read()["DATABASE_URL"] == "postgresql://app@h:5/db"
        assert memory_vault.get("DATABASE_PASSWORD") == "Pw@x"

    def test_failed_database_check_fails_the_step(self, data_dir,
                                                  memory_vault, capsys):
        import socket
        from desktop import configure
        with socket.socket() as s:
            s.bind(("127.0.0.1", 0))
            dead = s.getsockname()[1]
        rc = configure.main(["--db-url", f"postgresql://u@127.0.0.1:{dead}/x",
                             "--json"])
        assert rc == 3
        out = json.loads(capsys.readouterr().out)
        assert out["ok"] is False and out["check"]["ok"] is False

    def test_bad_arguments(self, data_dir, memory_vault):
        from desktop import configure
        assert configure.main(["--set", "NOT_A_KEY=1", "--no-check"]) == 2
        assert configure.main(["--api-port", "80", "--no-check"]) == 2
        # Real driver without OCR is refused up front.
        assert configure.main(["--driver", "pywinauto", "--ocr", "off",
                               "--no-check"]) == 2

    def test_stdin_json_secrets(self, data_dir, memory_vault, monkeypatch):
        import io
        from desktop import configure
        monkeypatch.setattr("sys.stdin", io.StringIO(json.dumps(
            {"db_password": "from-stdin", "admin_password": "AdminFromStdin1"})))
        rc = configure.main(["--stdin-json", "--db-engine", "sqlite",
                             "--no-check"])
        assert rc == 0
        assert memory_vault.get("DATABASE_PASSWORD") == "from-stdin"

    def test_supervisor_registration_is_called_and_failures_reported(
            self, data_dir, memory_vault, monkeypatch, capsys):
        from desktop import configure
        calls = []
        monkeypatch.setattr(configure, "register_supervisor",
                            lambda exe, user, now: calls.append(
                                (user, now)) or "stub supervisor")
        rc = configure.main(["--register-supervisor", "--bot-user", "CORP\\bot",
                             "--start-now", "--no-check"])
        assert rc == 0 and calls == [("CORP\\bot", True)]
        assert "stub supervisor" in capsys.readouterr().out

        def boom(*a):
            raise RuntimeError("schtasks said no")
        monkeypatch.setattr(configure, "register_supervisor", boom)
        assert configure.main(["--register-supervisor", "--no-check"]) == 4

    def test_schtasks_xml_shape(self):
        from desktop import configure
        xml = configure._schtasks_xml(r"C:\Program Files\F\finesiii-rpa.exe",
                                      r"CORP\bot")
        assert "<UserId>CORP\\bot</UserId>" in xml
        assert "<Arguments>--agent</Arguments>" in xml
        assert "<RestartOnFailure>" in xml and "PT0S" in xml
        assert "InteractiveToken" in xml
        # From source the command is the interpreter and the script.
        xml = configure._schtasks_xml('"C:\\py\\python.exe" "C:\\r\\app.py"',
                                      "bot")
        assert "<Command>C:\\py\\python.exe</Command>" in xml
        assert '"C:\\r\\app.py" --agent' in xml


class TestBootstrapHandoff:
    def test_written_then_imported_and_deleted(self, data_dir, memory_vault,
                                               monkeypatch):
        from desktop import vault
        vault.write_bootstrap_secrets({"DATABASE_PASSWORD": "pw",
                                       "FINESIII_API_KEYS": "k:v",
                                       "SMTP_PASSWORD": ""})   # skipped
        path = vault.bootstrap_path()
        assert path.is_file()
        imported = vault.import_bootstrap_secrets()
        assert sorted(imported) == ["DATABASE_PASSWORD", "FINESIII_API_KEYS"]
        assert memory_vault.get("DATABASE_PASSWORD") == "pw"
        assert not path.exists()
        assert vault.import_bootstrap_secrets() == []      # idempotent

    def test_only_vault_names_are_accepted(self, data_dir, memory_vault):
        from desktop import vault
        with pytest.raises(KeyError):
            vault.write_bootstrap_secrets({"ROOT_PW": "x"})

    def test_unavailable_vault_leaves_the_file(self, data_dir, monkeypatch):
        from desktop import vault

        class Broken:
            name = "broken"; available = False; error = "no store"

        previous = vault._vault
        vault.use_vault(vault.MemoryVault())
        vault.write_bootstrap_secrets({"DATABASE_PASSWORD": "pw"})
        vault.use_vault(Broken())
        try:
            assert vault.import_bootstrap_secrets() == []
            assert vault.bootstrap_path().is_file()
        finally:
            vault.use_vault(previous)

    def test_agent_start_imports_the_handoff(self, data_dir, memory_vault,
                                             monkeypatch):
        """The AGENT's _prepare_environment() runs the import before
        configuration is read, so an installer-provided DB password
        reaches the URL (other modes must not import — see
        test_release_fixes)."""
        from desktop import app as app_module, vault
        vault.write_bootstrap_secrets({"DATABASE_PASSWORD": "handoff-pw"})
        monkeypatch.delenv("DATABASE_PASSWORD", raising=False)
        app_module._prepare_environment(import_bootstrap=True)
        assert os.environ.get("DATABASE_PASSWORD") == "handoff-pw"
        assert not vault.bootstrap_path().exists()
        monkeypatch.delenv("DATABASE_PASSWORD", raising=False)
