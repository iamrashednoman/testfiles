"""OCR layer unit tests — engine-independent (FakeOcrEngine; the suite
never needs paddlepaddle installed).

Covers the contracts the enterprise design depends on:
  - normalization folds OCR variance (fullwidth, spaces, hyphens, O/0)
  - PathClassifier: success/failed-path classification + the
    upgrade-only rule (low confidence can never assert failure)
  - ObservedDriver: pure pass-through with the Null engine, OCR text
    enrichment, action trace with password masking, screen trace +
    printed .txt evidence, cache invalidation on input
  - ScreenState.check_transaction_result scans bottom-up and reports
    result_source
"""
from pathlib import Path

import pytest

from src.rpa.drivers.mock import MockDriver
from src.rpa.drivers.ocr_wrapper import ObservedDriver
from src.rpa.screens.state import ScreenState
from src.rpa.vision.keywords import (
    PATH_BUSINESS_ERROR, PATH_IN_PROGRESS, PATH_SUCCESS,
    PathClassifier, canonical_result_code, load_rules, mask_values,
    match_screen, normalize_text,
)
from src.rpa.vision.ocr import NullOcrEngine, OcrLine
from src.rpa.vision.screen_text import format_printed


class FakeOcrEngine:
    """Deterministic engine: returns preset lines, counts reads."""

    name = "fake"
    available = True

    def __init__(self, lines=None):
        self.lines = lines or []
        self.reads = 0

    def read_image(self, filepath):
        self.reads += 1
        return list(self.lines)


def make_observed(inner=None, engine=None, lines=None, **kwargs):
    inner = inner or MockDriver()
    inner.initialize({"mock_scenario": kwargs.pop("scenario", "success")})
    engine = engine if engine is not None else (
        FakeOcrEngine(lines) if lines is not None else NullOcrEngine())
    kwargs.setdefault("secrets", ("TEST0000", "FUJI@33F"))
    return ObservedDriver(inner, engine, PathClassifier(load_rules()),
                          {}, **kwargs)


# ── Normalization / code canonicalization ──

class TestNormalization:
    def test_fullwidth_code_canonicalized(self):
        assert canonical_result_code("Ｏ－００００") == "O-0000"
        assert canonical_result_code("Ｅ－９９０１ 所属誤り") == "E-9901"

    def test_zero_misread_of_o(self):
        assert canonical_result_code("0-0000") == "O-0000"

    def test_no_substring_false_positives(self):
        assert canonical_result_code("10-0000") is None
        assert canonical_result_code("CODE-9901") is None
        assert canonical_result_code("業務No. 00903") is None

    def test_normalize_strips_spaces_and_folds_width(self):
        assert normalize_text("Ｆ Ｉ Ｎ Ｅ Ｓ") == "FINES"
        assert "O-0000" in normalize_text("（Ｏ−００００）")

    def test_mask_values(self):
        out = mask_values("typed FUJI@33F then enter", ("FUJI@33F",))
        assert "FUJI@33F" not in out and "********" in out


# ── Path classification ──

class TestPathClassifier:
    def setup_method(self):
        self.clf = PathClassifier(load_rules(), min_confidence=0.75)

    def test_success_code(self):
        r = self.clf.classify("処理結果\nO-0000", 0.95)
        assert r["path"] == PATH_SUCCESS and r["code"] == "O-0000"

    def test_error_code_confident(self):
        r = self.clf.classify("E-9901 所属コード誤り", 0.9)
        assert r["path"] == PATH_BUSINESS_ERROR and r["code"] == "E-9901"

    def test_already_deleted_marker(self):
        r = self.clf.classify("エラーコメント\n削除済み", 0.9)
        assert r["path"] == PATH_BUSINESS_ERROR
        assert "削除済み" in r["matched"]

    def test_upgrade_only_low_confidence_cannot_fail(self):
        """The safety rule: a shaky read must never assert failure."""
        r = self.clf.classify("E-9901 所属コード誤り", 0.4)
        assert r["path"] != PATH_BUSINESS_ERROR

    def test_neutral_screen_is_in_progress(self):
        r = self.clf.classify("業務MENU\n業務ＮＯ", 0.9)
        assert r["path"] == PATH_IN_PROGRESS

    def test_match_screen_uses_identifiers(self):
        screens = {"business_menu":
                   {"identifiers": ["FINESⅢ", "業務MENU", "業務ＮＯ"]}}
        assert match_screen(screens, "FINESⅢ 業務MENU") == "business_menu"
        assert match_screen(screens, "unrelated") == ""


# ── ObservedDriver ──

class TestObservedDriver:
    def test_null_engine_is_pure_passthrough(self):
        inner = MockDriver()
        inner.initialize({"mock_scenario": "success"})
        obs = ObservedDriver(inner, NullOcrEngine(),
                             PathClassifier(load_rules()), {})
        assert obs.get_screen_text() == inner.get_screen_text()
        assert obs.wait_for_screen(["基幹業務"]) is True

    def test_ocr_lines_enrich_screen_text(self, tmp_path):
        lines = [OcrLine("処理結果", 0.99, (10, 10, 80, 16)),
                 OcrLine("Ｏ－００００", 0.97, (10, 40, 90, 16))]
        obs = make_observed(lines=lines)
        text = obs.get_screen_text()
        assert "Ｏ－００００" in text        # raw OCR line
        assert "O-0000" in text             # normalized copy

    def test_action_trace_records_and_masks(self):
        obs = make_observed()
        obs.launch_application()
        obs.submit_command("10")
        obs.type_text("FUJI@33F")
        actions = [e["action"] for e in obs.action_trace]
        assert actions[:3] == ["launch_application", "submit_command",
                               "type_text"]
        dump = str(obs.action_trace)
        assert "FUJI@33F" not in dump and "********" in dump

    def test_proxied_extra_methods_recorded_and_delegated(self):
        obs = make_observed()
        obs.launch_application()
        obs.goto_first_field_and_exit("99")
        assert "99" in obs.inner.commands       # delegated to MockDriver
        assert any(e["action"] == "goto_first_field_and_exit"
                   for e in obs.action_trace)

    def test_hasattr_mirrors_inner_driver(self):
        obs = make_observed()
        assert hasattr(obs, "clear_field")          # MockDriver has it
        assert not hasattr(obs, "no_such_method")   # and this stays False

    def test_ocr_cache_invalidated_by_input(self):
        class ChangingScreen(MockDriver):
            """Screenshot bytes change per capture — hash-based reuse
            must not kick in once an input marks the screen dirty."""
            def __init__(self):
                super().__init__()
                self.captures = 0

            def take_screenshot(self, filepath):
                self.captures += 1
                Path(filepath).write_bytes(b"frame-%d" % self.captures)

        engine = FakeOcrEngine([OcrLine("A", 0.9, (0, 0, 10, 10))])
        obs = make_observed(inner=ChangingScreen(), engine=engine)
        obs.get_screen_text()
        obs.get_screen_text()                       # cached (not dirty)
        first = engine.reads
        assert first == 1
        obs.type_text("x")                          # marks screen dirty
        obs.get_screen_text()
        assert engine.reads > first

    def test_screenshot_writes_classified_txt(self, tmp_path):
        lines = [OcrLine("確認画面", 0.98, (10, 8, 70, 16)),
                 OcrLine("削除済み", 0.96, (10, 40, 70, 16))]
        obs = make_observed(lines=lines, request_id="req_test1")
        png = tmp_path / "003_confirmation_screen_120000.png"
        obs.take_screenshot(str(png))

        txt = png.with_suffix(".txt")
        assert txt.exists(), "printed-pattern txt missing beside PNG"
        content = txt.read_text(encoding="utf-8")
        assert "req_test1" in content and "削除済み" in content
        assert "BUSINESS_ERROR" in content

        assert len(obs.screen_trace) == 1
        entry = obs.screen_trace[0]
        assert entry["path"] == "business_error"
        assert entry["file"] == png.name

    def test_txt_masks_password(self, tmp_path):
        lines = [OcrLine("パスワード FUJI@33F", 0.97, (10, 8, 140, 16))]
        obs = make_observed(lines=lines)
        png = tmp_path / "004_data_entered_120001.png"
        obs.take_screenshot(str(png))
        content = png.with_suffix(".txt").read_text(encoding="utf-8")
        assert "FUJI@33F" not in content and "********" in content

    def test_failure_recorded_and_reraised(self):
        class Exploding(MockDriver):
            def press_key(self, key):
                raise RuntimeError("boom")
        obs = make_observed(inner=Exploding())
        with pytest.raises(RuntimeError):
            obs.press_key("enter")
        entry = obs.action_trace[-1]
        assert entry["action"] == "press_key" and entry["ok"] is False

    def test_before_enter_hook_fires_pre_submit(self):
        """The evidence seam: the hook must see the PRE-advance screen
        (typed command still on it), on the bare driver and through
        the observer alike."""
        seen = []
        inner = MockDriver()
        inner.initialize({"mock_scenario": "success"})
        inner.launch_application()
        inner.submit_command("10",
                             before_enter=lambda: seen.append(inner.screen))
        assert seen == ["core_menu"]        # not yet advanced to login

        obs = make_observed()
        obs.launch_application()
        obs.submit_command("10",
                           before_enter=lambda: seen.append(
                               obs.inner.screen))
        assert seen[-1] == "core_menu"

    def test_before_enter_hook_failure_never_blocks_submit(self):
        inner = MockDriver()
        inner.initialize({"mock_scenario": "success"})
        inner.launch_application()
        inner.submit_command("10", before_enter=lambda: 1 / 0)
        assert inner.screen == "login"      # submit still went through

    def test_traces_shape_is_json_safe(self):
        import json
        obs = make_observed()
        obs.submit_command("10")
        json.dumps(obs.traces())                    # must not raise


# ── Screen content mirrors (evidence txt must carry the data) ──

class TestScreenContentMirror:
    def test_sim_task_table_contains_entered_values(self):
        from src.rpa.drivers import sim_terminal as st_mod
        drv = st_mod.SimTerminalDriver()      # windowless state only
        drv.screen = st_mod.SCREEN_TASK_903
        drv._login_fields = ["9930822", "12N3940", "TEST0000"]
        drv._task_values = {"101": "2", "104": "1", "105": "30822",
                            "106": "1217036", "107": "FUJI@33F"}
        content = drv.get_screen_content()
        for value in ("30822", "1217036", "FUJI@33F", "処理区分",
                      "社員コード", "インプット内容"):
            assert value in content
        # identifier contract untouched
        assert "1217036" not in drv.get_screen_text()

    def test_sim_login_screen_contains_credentials(self):
        from src.rpa.drivers import sim_terminal as st_mod
        drv = st_mod.SimTerminalDriver()
        drv.screen = st_mod.SCREEN_LOGIN
        drv._login_fields = ["9930822", "12N3940", "TEST0000"]
        content = drv.get_screen_content()
        assert "9930822" in content and "12N3940" in content

    def test_mock_content_includes_task_entries(self):
        drv = MockDriver()
        drv.initialize({"mock_scenario": "success"})
        drv.launch_application()
        drv.screen = "task_903"
        drv.type_text("30822")
        drv.type_text("1217036")
        assert "1217036" in drv.get_screen_content()
        assert "30822" in drv.get_screen_content()

    def test_txt_input_commands_section(self, tmp_path):
        """Every txt ends with an INPUT COMMANDS footer listing what
        the bot entered since the previous capture — masked, and
        windowed per capture (a later capture never repeats earlier
        inputs)."""
        obs = make_observed(secrets=("FUJI@33F",))
        obs.launch_application()
        obs.type_text("30822")
        obs.type_text("FUJI@33F")
        obs.submit_command("00")
        png1 = tmp_path / "001_data_entered_120000.png"
        obs.take_screenshot(str(png1))
        content = png1.with_suffix(".txt").read_text(encoding="utf-8")
        assert "INPUT COMMANDS" in content
        assert "30822" in content and "command         : 00" in content
        assert "FUJI@33F" not in content and "********" in content

        # No inputs between captures → explicit (none) marker
        png2 = tmp_path / "002_confirmation_120001.png"
        obs.take_screenshot(str(png2))
        content2 = png2.with_suffix(".txt").read_text(encoding="utf-8")
        assert "INPUT COMMANDS" in content2
        assert "(none" in content2
        assert "30822" not in content2.split("INPUT COMMANDS")[1]

    def test_before_enter_capture_sees_its_own_command(self, tmp_path):
        """The ordering fix: a before_enter evidence capture fires
        INSIDE submit_command — its INPUT COMMANDS section must show
        the very command being submitted (navigation '10's were
        landing one file late)."""
        obs = make_observed()
        obs.launch_application()
        png = tmp_path / "003_menu_selection_entered_120000.png"
        obs.submit_command(
            "10", before_enter=lambda: obs.take_screenshot(str(png)))
        content = png.with_suffix(".txt").read_text(encoding="utf-8")
        assert "command         : 10" in content

        # ...and the NEXT capture does not repeat it
        png2 = tmp_path / "004_menu_2_loaded_120001.png"
        obs.take_screenshot(str(png2))
        content2 = png2.with_suffix(".txt").read_text(encoding="utf-8")
        assert "command         : 10" not in content2
        assert "(none" in content2

    def test_observer_txt_uses_content_mirror(self, tmp_path):
        """Null engine: the .txt body must carry the account data the
        screenshot shows, with secret values masked."""
        inner = MockDriver()
        inner.initialize({"mock_scenario": "success"})
        inner.launch_application()
        inner.screen = "task_903"
        inner.type_text("1217036")
        inner.type_text("FUJI@33F")
        obs = ObservedDriver(inner, NullOcrEngine(),
                             PathClassifier(load_rules()), {},
                             secrets=("FUJI@33F",))
        png = tmp_path / "006_data_entered_120000.png"
        obs.take_screenshot(str(png))
        content = png.with_suffix(".txt").read_text(encoding="utf-8")
        assert "1217036" in content            # account data present
        assert "FUJI@33F" not in content       # password masked
        assert "********" in content


# ── Printed-pattern formatting ──

class TestScreenTextFormat:
    def test_columns_reconstructed_from_boxes(self):
        lines = [OcrLine("NO.", 0.9, (16, 10, 30, 16)),
                 OcrLine("項目名称", 0.9, (80, 10, 60, 16)),
                 OcrLine("101", 0.9, (16, 40, 30, 16)),
                 OcrLine("処理区分", 0.9, (80, 40, 60, 16))]
        out = format_printed(lines)
        rows = out.splitlines()
        assert len(rows) == 2
        assert rows[0].index("項目名称") == rows[1].index("処理区分")

    def test_plain_string_passthrough_with_masking(self):
        out = format_printed("パスワード TEST0000", secrets=("TEST0000",))
        assert "TEST0000" not in out


# ── Result check (bottom-up scan) ──

class TestCheckTransactionResult:
    def _state(self, text):
        class Reader(MockDriver):
            def get_screen_text(self):
                return text
        return ScreenState({}, Reader())

    def test_code_found_above_confirm_bar(self):
        """OCR reads append lines after the result line — the scan must
        still find the code (previously only the literal last line)."""
        state = self._state("処理結果\nO-0000\n【確認】 送信:70")
        result = state.check_transaction_result()
        assert result["success"] and result["code"] == "O-0000"
        assert result["result_source"] == "screen"

    def test_error_code_bottom_up(self):
        state = self._state("処理結果\nE-9901 所属コード誤り")
        result = state.check_transaction_result()
        assert not result["success"] and result["code"] == "E-9901"

    def test_unreadable_stays_unconfirmed(self):
        state = self._state("FINESⅢ")
        result = state.check_transaction_result()
        assert result["success"] and result["code"] == "UNCONFIRMED"
        assert result["result_source"] == "unconfirmed"

    def test_fullwidth_ocr_code_recognized(self):
        state = self._state("処理結果\nＯ－００００")
        result = state.check_transaction_result()
        assert result["success"] and result["code"] == "O-0000"
