"""ServiceNow group mode (2026-09-30): the Requested For filter and the
assignment to the bot account BEFORE a ticket is queued.

  R1-R3  Requested For in the query (sys_id or name, several values),
         group mode only, refused characters, YAML default and '*'.
  R4-R8  the ticket is assigned to the bot first (re-checked as free,
         the saved assignment verified); not queued when that fails;
         a person who took it keeps it; given back to the group when
         the intake refuses it; retried after a service error.
  R9     group mode needs a bot account; the connection test checks the
         bot account tickets are assigned to, its group membership and
         who each Requested For value names.
  R10    the read-only preview says the ticket would be assigned first.

The connector talks to the mock ServiceNow over the real client (wire
format included), with the tickets in the formats SailPoint creates.
"""
import random
from pathlib import Path

import pytest

from scripts.run_mock_snow_server import (
    GROUP, SAILPOINT_USER, TicketStore, create_mock_app, user_sys_id,
)
from src.integrations.servicenow.client import (
    ServiceNowClient, explain_error,
)
from src.integrations.servicenow.config import (
    ServiceNowSettings, load_servicenow_config,
)
from src.integrations.servicenow.connector import (
    ReportMemory, ServiceNowConnector,
)

ROOT = Path(__file__).resolve().parents[2]
BOT = "finesiii.bot"
SP_NAME = "SAILPOINT ADMIN MYAIGACCESS"


# ── R1-R3: the query ───────────────────────────────────────────────

def group_settings(**kw) -> ServiceNowSettings:
    base = dict(instance_url="https://x.service-now.com", username=BOT,
                password="pw", assignment_mode="assignment_group",
                assignment_group=GROUP, field_mapping={"ticket_number":
                                                       "number"})
    base.update(kw)
    return ServiceNowSettings(**base)


class TestQuery:
    """Requested For is checked by the bot on each ticket (display name
    or sys_id, in the field entered or - blank - the task's, request's
    and requested item's), never sent in the ServiceNow query."""

    def test_requested_for_is_not_in_the_query(self):
        q = group_settings(requested_for=[SP_NAME]).build_query()
        assert q == (f"assignment_group.name={GROUP}"
                     f"^active=true^ORDERBYsys_created_on")
        q = group_settings(requested_for=[SP_NAME],
                           assigned_to=BOT).build_query()
        assert q == (f"assignment_group.name={GROUP}"
                     f"^assigned_toISEMPTY^active=true^ORDERBYsys_created_on")

    def test_bot_account_is_ored_by_sys_id_only(self):
        s = group_settings(assigned_to=BOT)
        assert "assigned_toISEMPTY^active" in s.build_query()
        assert "assigned_to.user_name" not in s.build_query()
        s.bot_sys_id = "c" * 32
        assert f"^assigned_toISEMPTY^ORassigned_to={'c' * 32}^" in \
            s.build_query()

    def test_sys_id_list_and_mixed_values(self):
        a, b = "a" * 32, "b" * 32
        s = group_settings(requested_for=[a, b, SP_NAME, "Other User"],
                           assignment_group="")
        assert not s.selection_mismatch(
            {"request.requested_for": {"value": b, "display_value": "X"}})
        assert not s.selection_mismatch(
            {"request_item.requested_for": {"value": "f" * 32,
                                            "display_value": "other user"}})
        why = s.selection_mismatch(
            {"requested_for": {"value": "f" * 32, "display_value": "Nobody"}})
        assert "requested_for 'Nobody'" in why

    def test_field_is_configurable(self):
        s = group_settings(requested_for=[SP_NAME], assignment_group="",
                           requested_for_field="request.requested_for")
        assert s.requested_for_fields() == ["request.requested_for"]
        # Only the field entered counts.
        assert s.selection_mismatch(
            {"request_item.requested_for": {"value": "", "display_value":
                                            SP_NAME}})
        assert not s.selection_mismatch(
            {"request.requested_for": {"value": "", "display_value":
                                       SP_NAME}})

    def test_blank_field_reads_the_three_places(self):
        s = group_settings(requested_for=[SP_NAME], assignment_group="")
        assert s.requested_for_fields() == [
            "requested_for", "request.requested_for",
            "request_item.requested_for"]
        assert not s.selection_mismatch({"request.requested_for.name": SP_NAME})

    def test_every_filter_is_optional(self):
        s = group_settings(assignment_group="", assignment_mode="assigned_to")
        assert s.build_query() == "active=true^ORDERBYsys_created_on"
        assert s.validate()
        assert s.assigns_before_queueing
        s = group_settings(requested_for=[SP_NAME],
                           assignment_mode="assigned_to", assigned_to=BOT)
        assert s.build_query() == (
            f"assignment_group.name={GROUP}^assigned_to.user_name={BOT}"
            f"^active=true^ORDERBYsys_created_on")
        assert not s.assigns_before_queueing

    def test_close_out_ownership_clause_is_unchanged(self):
        s = group_settings(requested_for=[SP_NAME])
        assert "requested_for" not in s.assignment_clause()

    @pytest.mark.parametrize("value", ["x^ORactive=true", "a=b", "a\nb"])
    def test_widening_values_are_refused(self, value):
        s = group_settings(requested_for=[value])
        assert "requested_for" not in s.build_query()
        with pytest.raises(ValueError, match="Requested For"):
            s.validate()

    def test_bad_field_is_refused(self):
        s = group_settings(requested_for=[SP_NAME],
                           requested_for_field="x^ORactive=true")
        with pytest.raises(ValueError, match="Requested For field"):
            s.validate()

    def test_no_bot_account_is_valid(self):
        # Client credentials and no Bot account: the filters are all
        # optional, so the settings are valid; there is simply no
        # account to assign the tickets to.
        s = group_settings(auth_method="oauth_client_credentials",
                           username="", password="", client_id="c",
                           client_secret="s")
        assert s.validate()
        assert s.effective_assigned_to == ""
        s.assigned_to = BOT
        assert s.validate()
        assert group_settings(requested_for=[SP_NAME]).validate()


class TestLoader:
    def test_no_hidden_default(self, monkeypatch):
        """Blank on the Settings page = no filter: the group and Requested
        For in servicenow.yaml are not applied (S-01 / S-06, 2026-10-04)."""
        for k in ("SNOW_REQUESTED_FOR", "SNOW_REQUESTED_FOR_FIELD",
                  "SNOW_ASSIGNMENT_GROUP"):
            monkeypatch.delenv(k, raising=False)
        s = load_servicenow_config()
        assert s.requested_for == []
        assert s.assignment_group == ""
        assert s.requested_for_field == ""             # the three places
        assert s.assignment_mode == "assigned_to"      # default unchanged

    def test_console_values_and_no_filter(self, monkeypatch):
        monkeypatch.setenv("SNOW_REQUESTED_FOR", "a" * 32 + ", Other User")
        monkeypatch.setenv("SNOW_REQUESTED_FOR_FIELD", "requested_for")
        s = load_servicenow_config()
        assert s.requested_for == ["a" * 32, "Other User"]
        assert s.requested_for_field == "requested_for"
        monkeypatch.setenv("SNOW_REQUESTED_FOR", "*")
        assert load_servicenow_config().requested_for == []


# ── R4-R8, R10: the poll against the mock ServiceNow ───────────────

class Env:
    """Mock ServiceNow + a connector using the real client over it."""

    def __init__(self, mode="assignment_group", **kw):
        from tests.conftest import asgi_transport
        self.store = TicketStore(random.Random(7))
        self.store.bot = ""                  # routed to the group only
        self.app = create_mock_app(self.store)
        transport = asgi_transport(self.app)
        s = load_servicenow_config()
        s.instance_url = "http://testserver"
        s.username, s.password = BOT, "pw"
        s.auth_method = "basic"
        s.assignment_mode = mode
        # As entered on the Settings page (the YAML values are not
        # applied since 2026-10-04).
        s.assignment_group = GROUP
        s.requested_for = [SP_NAME]
        s.respect_service_health = False
        for k, v in kw.items():
            setattr(s, k, v)
        self.settings = s
        self.client = ServiceNowClient(s, transport=transport,
                                       sleep_func=lambda _s: None)
        self.audit = []
        self.submitted = []
        self.answer = "queued"
        self.c = ServiceNowConnector(s, client=self.client)
        self.c.audit_hook = lambda e, d: self.audit.append((e, d))
        self.c.reported = ReportMemory()
        self.c._submit = self._submit

    def _submit(self, payload):
        task = self.task(payload["ticket_id"].split("/")[0])
        # Recorded with who the task belonged to at that moment.
        self.submitted.append((payload["ticket_id"], task["assigned_to"],
                               task["state"]))
        if self.answer == "invalid":
            self.c._last_refusal = "employee_code: bad format"
        return self.answer

    def task(self, number):
        return next(t for t in self.store.tickets if t["number"] == number)

    def events(self, name):
        return [d for e, d in self.audit if e == name]

    def fresh(self):
        """A new connector for the next poll (as the poller builds one)."""
        memory = self.c.reported
        self.c = ServiceNowConnector(self.settings, client=self.client)
        self.c.audit_hook = lambda e, d: self.audit.append((e, d))
        self.c.reported = memory
        self.c._submit = self._submit


BOT_ID = user_sys_id(BOT)


class TestAssignBeforeQueueing:
    def test_only_sailpoint_tasks_are_fetched_and_assigned_first(self):
        env = Env()
        add = env.store.create_sailpoint("add", assigned_to="")
        remove = env.store.create_sailpoint("remove", assigned_to="")
        # Another requester (e.g. a person's own catalog request).
        other = env.store.create_sailpoint("add", assigned_to="",
                                           requested_for="")
        # A person in the group already took this one.
        taken = env.store.create_sailpoint(
            "add", assigned_to=user_sys_id("service.desk.agent"))
        stats = env.c.poll_once()

        # No Bot account entered: no assignee filter. The other
        # requester's task is skipped by the bot's Requested For check,
        # the task a person took is left to them.
        assert stats["fetched"] == 4
        assert stats["out_of_selection"] == 1
        numbers = {p[0].split("/")[0] for p in env.submitted}
        assert numbers == {add["number"], remove["number"]}
        # Assigned to the bot and in the claim state BEFORE submission.
        assert all(who == BOT_ID and state == "2"
                   for _, who, state in env.submitted)
        for t in (add, remove):
            assert env.task(t["number"])["assigned_to"] == BOT_ID
        assert env.task(other["number"])["assigned_to"] == ""
        assert env.task(taken["number"])["assigned_to"] == \
            user_sys_id("service.desk.agent")
        claimed = env.events("servicenow_ticket_claimed")
        assert len(claimed) == 2 and all(d["before_queue"] for d in claimed)
        assert claimed[0]["previous_state"] == "1"

    def test_preview_writes_nothing_and_says_assign_first(self):
        env = Env()
        add = env.store.create_sailpoint("add", assigned_to="")
        before = dict(env.task(add["number"]))
        stats = env.c.poll_once(dry_run=True)
        assert env.task(add["number"]) == before
        assert env.submitted == [] and env.audit == []
        (row,) = stats["tickets"]
        assert row["action"] == "queue" and row["assign_to"] == BOT_ID

    @pytest.mark.parametrize("rule, words", [
        ("forbidden", "403"), ("revert", "did not keep")])
    def test_refused_assignment_is_not_queued(self, rule, words):
        env = Env()
        env.store.assign_rule = rule
        add = env.store.create_sailpoint("add", assigned_to="")
        stats = env.c.poll_once()
        assert env.submitted == []
        assert stats["not_assigned"] == 1 and stats["errors"] == 1
        assert words in stats["error_detail"]
        assert "could not assign tickets to itself" in \
            explain_error(stats["error_detail"])
        assert env.task(add["number"])["assigned_to"] == ""
        assert env.task(add["number"])["state"] == "1"   # not left WIP
        # Reported once, tried again on every poll.
        env.fresh()
        stats = env.c.poll_once()
        assert stats["not_assigned"] == 1 and env.submitted == []
        assert len(env.events("servicenow_ticket_claim_failed")) == 1
        # Fixed on the instance: the next poll assigns and queues it.
        env.store.assign_rule = ""
        env.fresh()
        env.c.poll_once()
        assert [p[1] for p in env.submitted] == [BOT_ID]

    def test_bot_account_not_found(self):
        env = Env()
        env.store.create_sailpoint("add", assigned_to="")
        env.client.user_sys_id = lambda name: ""
        stats = env.c.poll_once()
        assert env.submitted == [] and stats["errors"] == 1
        assert "bot account was not found" in \
            explain_error(stats["error_detail"])
        preview = env.c.poll_once(dry_run=True)
        assert preview["tickets"][0]["action"] == "defer"

    def test_a_person_who_took_it_since_the_fetch_keeps_it(self):
        env = Env()
        add = env.store.create_sailpoint("add", assigned_to="")
        fetch = env.client.fetch_assigned_open

        def fetch_then_taken():
            rows = fetch()
            env.task(add["number"])["assigned_to"] = user_sys_id("agent.two")
            return rows
        env.client.fetch_assigned_open = fetch_then_taken
        stats = env.c.poll_once()
        assert env.submitted == [] and stats["errors"] == 0
        assert stats["not_assigned"] == 1
        assert env.task(add["number"])["assigned_to"] == \
            user_sys_id("agent.two")
        (event,) = env.events("servicenow_ticket_not_taken")
        assert event["reason"] == "a person took it"

    def test_refused_by_the_intake_goes_back_to_the_group(self):
        env = Env()
        env.answer = "invalid"
        add = env.store.create_sailpoint("add", assigned_to="")
        env.c.poll_once()
        task = env.task(add["number"])
        assert task["assigned_to"] == "" and task["state"] == "1"
        assert env.store.groups[task["assignment_group"]] == GROUP
        assert "refused by the intake check" in task["work_notes"]
        assert env.events("servicenow_ticket_released")
        # Unchanged: not assigned or submitted again on the next poll.
        env.fresh()
        env.submitted.clear()
        stats = env.c.poll_once()
        assert env.submitted == [] and stats["suppressed"] == 1
        assert env.task(add["number"])["assigned_to"] == ""

    def test_service_error_keeps_it_assigned_and_retries(self):
        env = Env()
        env.answer = "error"
        add = env.store.create_sailpoint("add", assigned_to="")
        env.c.poll_once()
        assert env.task(add["number"])["assigned_to"] == BOT_ID
        env.answer = "queued"
        env.fresh()
        env.submitted.clear()
        env.c.poll_once()                    # still the bot's: fetched
        assert [p[1] for p in env.submitted] == [BOT_ID]

    def test_rejected_and_deferred_tickets_stay_unassigned(self):
        env = Env(max_per_poll=1)
        first = env.store.create_sailpoint("add", assigned_to="")
        second = env.store.create_sailpoint("add", assigned_to="")
        bad = env.store.create_sailpoint(
            "add", assigned_to="", instance="Dev")    # not accepted
        stats = env.c.poll_once()
        assert stats["deferred"] == 1 and stats["skipped"] == 1
        assert env.task(first["number"])["assigned_to"] == BOT_ID
        assert env.task(second["number"])["assigned_to"] == ""
        assert env.task(bad["number"])["assigned_to"] == ""
        assert env.task(bad["number"])["work_notes"]   # the reason

    def test_bot_account_mode_is_unchanged(self):
        env = Env(mode="assigned_to", assigned_to=BOT)
        env.store.bot = BOT
        add = env.store.create_sailpoint("add")       # routed to the bot
        env.store.create_sailpoint("add", assigned_to="")   # group only
        env.c.poll_once()
        # Fetched by the bot account; claimed AFTER submission as before.
        assert len(env.submitted) == 1
        assert env.submitted[0][2] == "1"             # state at submit
        assert env.task(add["number"])["state"] == "2"
        claimed = env.events("servicenow_ticket_claimed")
        assert claimed and "before_queue" not in claimed[0]


# ── R9 / R10: the console ─────────────────────────────────────────

class TestConsole:
    APP = (ROOT / "desktop" / "ui" / "app.js").read_text(encoding="utf-8")

    def test_settings(self):
        from src.modules.console.settings_catalogue import SETTINGS
        by = {s["key"]: s for s in SETTINGS}
        # Every filter is shown in both modes: each one is optional.
        for key in ("SNOW_ASSIGNED_TO", "SNOW_ASSIGNMENT_GROUP",
                    "SNOW_REQUESTED_FOR", "SNOW_REQUESTED_FOR_FIELD"):
            assert by[key]["show_when"] is None
            assert "Empty" in by[key]["help"]

    def test_values_are_checked_when_saved(self):
        from src.modules.console.settings_catalogue import SETTINGS, coerce
        by = {s["key"]: s for s in SETTINGS}
        assert coerce(by["SNOW_REQUESTED_FOR"], f"{SP_NAME}, {'a' * 32}") \
            == f"{SP_NAME},{'a' * 32}"
        for bad in ("x^ORactive=true", "a=b"):
            with pytest.raises(ValueError):
                coerce(by["SNOW_REQUESTED_FOR"], bad)
        with pytest.raises(ValueError):
            coerce(by["SNOW_REQUESTED_FOR"], f"*, {SP_NAME}")
        with pytest.raises(ValueError):
            coerce(by["SNOW_REQUESTED_FOR_FIELD"], "a^ORb")

    def test_page_sends_the_selection_and_shows_the_assignment(self):
        assert "requested_for: wizardValue('SNOW_REQUESTED_FOR')" in self.APP
        assert "assigned_to: wizardValue('SNOW_ASSIGNED_TO')" in self.APP
        assert "'Assign to the bot, then queue'" in self.APP
