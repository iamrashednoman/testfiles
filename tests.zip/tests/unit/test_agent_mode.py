"""Background agent + attachable window (P1, approved 2026-09-26).

What these pin:

  • the agent publishes its address only once it is READY, and removes
    it on a clean stop;
  • a second agent on the same data directory is refused;
  • a stop REQUEST (the agent.stop file) drains and exits the agent —
    the mechanism `--stop` and the console use, which needs no signals
    and no network credentials;
  • the window ATTACHES to a running agent and closing it leaves the
    agent running — the whole point of the split;
  • with no agent running, the window launches one and attaches to it.

The agent is run on a thread here (no subprocess, no display): its
signal handlers are skipped off the main thread by design, so the stop
file is what the tests exercise — exactly as on Windows.
"""
import os
import sys
import threading
import time

import pytest

from tests.conftest import make_config


@pytest.fixture
def data_dir(tmp_path, monkeypatch):
    """Point the runtime files at a private directory. data_root()
    honours FINESIII_DATA_DIR everywhere."""
    d = tmp_path / "data"
    d.mkdir()
    monkeypatch.setenv("FINESIII_DATA_DIR", str(d))
    return d


def _cfg(tmp_path):
    return make_config(tmp_path, terminal_driver="mock",
                       dispatcher_enabled=False,
                       log_dir=str(tmp_path / "logs"))


class _AgentThread:
    """Run an AgentRunner on a thread and wait for it to publish."""

    def __init__(self, tmp_path):
        from desktop.agent import AgentRunner
        self.runner = AgentRunner(_cfg(tmp_path),
                                  cfg_factory=lambda: _cfg(tmp_path),
                                  poll_seconds=0.1)
        self.rc = None
        self.thread = threading.Thread(target=self._run, daemon=True)

    def _run(self):
        self.rc = self.runner.run()

    def start(self, timeout=30.0) -> str:
        from desktop import runtime
        self.thread.start()
        deadline = time.time() + timeout
        while time.time() < deadline:
            url = runtime.find_running_agent()
            if url:
                return url
            if not self.thread.is_alive():
                break
            time.sleep(0.1)
        raise AssertionError(f"agent never became ready (rc={self.rc})")

    def stop(self, timeout=30.0):
        from desktop import runtime
        runtime.request_stop()
        self.thread.join(timeout=timeout)
        assert not self.thread.is_alive(), "agent did not stop"
        return self.rc


def _fake_webview(monkeypatch, seen: dict, on_create=None):
    module = type(sys)("webview")

    class _Events:
        closing = type("E", (), {"__iadd__": lambda s, o: s})()

    class _Window:
        events = _Events()

        def destroy(self):
            pass

    def create_window(title, url, **kw):
        seen["title"], seen["url"] = title, url
        if on_create:
            on_create()
        return _Window()

    module.create_window = create_window
    module.start = lambda: seen.setdefault("started", True)
    monkeypatch.setitem(sys.modules, "webview", module)


class TestRuntimeFile:
    def test_roundtrip_and_removal(self, data_dir):
        from desktop import runtime
        path = runtime.write_runtime(8123, pid=42, version="3.0.0")
        assert path.parent == data_dir
        info = runtime.read_runtime()
        assert info["url"] == "http://127.0.0.1:8123"
        assert info["pid"] == 42 and info["version"] == "3.0.0"
        runtime.remove_runtime()
        assert runtime.read_runtime() is None
        runtime.remove_runtime()                  # idempotent

    def test_no_file_means_no_agent(self, data_dir):
        from desktop import runtime
        assert runtime.find_running_agent() is None

    def test_stale_file_is_not_trusted(self, data_dir):
        """A crash leaves agent.json behind; the port answers nothing."""
        import socket
        from desktop import runtime
        with socket.socket() as s:
            s.bind(("127.0.0.1", 0))
            dead_port = s.getsockname()[1]
        runtime.write_runtime(dead_port)
        assert runtime.find_running_agent(timeout=0.5) is None

    def test_stop_request_lifecycle(self, data_dir):
        from desktop import runtime
        assert not runtime.stop_requested()
        runtime.request_stop()
        assert runtime.stop_requested()
        runtime.clear_stop_request()
        assert not runtime.stop_requested()

    def test_agent_command_runs_this_app(self):
        from desktop import runtime
        cmd = runtime.agent_command()
        assert cmd[0] == sys.executable
        assert cmd[-1] == "--agent"
        assert cmd[1].endswith(os.path.join("desktop", "app.py"))


class TestAgentRunner:
    def test_publishes_when_ready_and_cleans_up_on_stop(self, tmp_path,
                                                        data_dir):
        from desktop import runtime
        agent = _AgentThread(tmp_path)
        url = agent.start()
        try:
            assert runtime.ping(url)
            info = runtime.read_runtime()
            assert info["pid"] == os.getpid()
            assert info["version"] == "3.0.0"
            # The console UI is served by the agent, like the old window.
            import urllib.request
            with urllib.request.urlopen(f"{url}/", timeout=5) as r:
                assert r.status == 200
                assert b"FINESIII" in r.read()
        finally:
            rc = agent.stop()
        assert rc == 0
        assert runtime.read_runtime() is None
        assert not runtime.stop_requested()
        assert runtime.find_running_agent() is None

    def test_second_agent_is_refused(self, tmp_path, data_dir):
        from desktop.agent import AgentRunner
        agent = _AgentThread(tmp_path)
        agent.start()
        try:
            assert AgentRunner(_cfg(tmp_path)).run() == 3
        finally:
            agent.stop()

    def test_stale_stop_request_does_not_stop_a_new_agent(self, tmp_path,
                                                          data_dir):
        from desktop import runtime
        runtime.request_stop()                   # left over from before
        agent = _AgentThread(tmp_path)
        url = agent.start()
        try:
            time.sleep(0.5)
            assert runtime.ping(url), "agent obeyed a stale stop file"
        finally:
            agent.stop()

    def test_stop_cli_with_nothing_running(self, data_dir):
        from desktop.agent import stop_running_agent
        assert stop_running_agent() == 0

    def test_stop_cli_drains_a_running_agent(self, tmp_path, data_dir):
        from desktop import runtime
        from desktop.agent import stop_running_agent
        agent = _AgentThread(tmp_path)
        agent.start()
        assert stop_running_agent(timeout=30) == 0
        agent.thread.join(timeout=10)
        assert agent.rc == 0
        assert runtime.find_running_agent() is None


class TestWindowAttaches:
    def test_attaches_to_the_running_agent_and_leaves_it_running(
            self, tmp_path, data_dir, monkeypatch):
        from desktop import runtime
        from desktop import shell as shell_module

        agent = _AgentThread(tmp_path)
        url = agent.start()
        try:
            seen = {}
            _fake_webview(monkeypatch, seen)
            spawned = []
            monkeypatch.setattr(runtime, "spawn_agent",
                                lambda: spawned.append(1))
            shell = shell_module.DesktopShell(_cfg(tmp_path),
                                              embedded=False)
            monkeypatch.setattr(shell, "_install_signal_handlers",
                                lambda: None)
            assert shell.run() == 0
            assert seen["url"] == url
            assert seen.get("started")
            assert not spawned, "must not launch a second agent"
            # The window is gone; the bot is not.
            assert runtime.ping(url)
            assert shell.service.app is None, \
                "the window must not host its own service"
        finally:
            agent.stop()

    def test_launches_an_agent_when_none_is_running(self, tmp_path,
                                                    data_dir, monkeypatch):
        from desktop import runtime
        from desktop import shell as shell_module

        agent = _AgentThread(tmp_path)

        class _Proc:                              # what Popen returns
            def poll(self):
                return None

        def fake_spawn():
            agent.thread.start()
            return _Proc()

        monkeypatch.setattr(runtime, "spawn_agent", fake_spawn)
        seen = {}
        _fake_webview(monkeypatch, seen)
        shell = shell_module.DesktopShell(_cfg(tmp_path), embedded=False)
        monkeypatch.setattr(shell, "_install_signal_handlers",
                            lambda: None)
        try:
            assert shell.run() == 0
            assert seen["url"] == runtime.find_running_agent()
            assert runtime.ping(seen["url"])
        finally:
            agent.stop()

    def test_reports_a_startup_failure_instead_of_hanging(
            self, tmp_path, data_dir, monkeypatch, capsys):
        from desktop import runtime
        from desktop import shell as shell_module

        class _DeadProc:
            def poll(self):
                return 1                          # exited immediately

        monkeypatch.setattr(runtime, "spawn_agent", lambda: _DeadProc())
        _fake_webview(monkeypatch, {})
        shell = shell_module.DesktopShell(_cfg(tmp_path), embedded=False)
        monkeypatch.setattr(shell, "_install_signal_handlers",
                            lambda: None)
        started = time.time()
        assert shell.run() == 1
        assert time.time() - started < 30
        assert "agent.log" in capsys.readouterr().err

    def test_embedded_mode_is_selected_by_environment(self, tmp_path,
                                                      monkeypatch):
        from desktop import shell as shell_module
        monkeypatch.setenv(shell_module.EMBEDDED_ENV, "1")
        assert shell_module.DesktopShell(_cfg(tmp_path)).embedded is True
        monkeypatch.delenv(shell_module.EMBEDDED_ENV)
        assert shell_module.DesktopShell(_cfg(tmp_path)).embedded is False


class TestEntryPointDispatch:
    def test_agent_and_stop_flags_are_routed(self, monkeypatch):
        from desktop import app as app_module
        calls = []
        monkeypatch.setattr(app_module, "run_agent",
                            lambda: calls.append("agent") or 0)
        monkeypatch.setattr(app_module, "stop_agent",
                            lambda: calls.append("stop") or 0)
        assert app_module.main(["--agent"]) == 0
        assert app_module.main(["--stop"]) == 0
        assert calls == ["agent", "stop"]
