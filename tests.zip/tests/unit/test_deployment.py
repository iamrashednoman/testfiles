"""finesiii.env — the installer-written deployment layer (P2).

Pins: the file is read by the SAME config loader as .env with lower
priority (so source/Docker runs are untouched); writes are atomic and
validated; secrets never land in it; the database check reports
plainly instead of raising; the vault password is injected into the
URL at config time and never stored beside it.
"""
import os

import pytest

from tests.conftest import make_config


@pytest.fixture
def data_dir(tmp_path, monkeypatch):
    d = tmp_path / "data"
    d.mkdir()
    monkeypatch.setenv("FINESIII_DATA_DIR", str(d))
    return d


class TestFile:
    def test_absent_file_reads_empty(self, data_dir):
        from desktop import deployment
        assert deployment.read() == {}
        assert not deployment.deployment_file().exists()

    def test_write_read_roundtrip_with_awkward_values(self, data_dir):
        from desktop import deployment
        deployment.write({"MAINFRAME_HOST": "host name #1",
                          "DATABASE_URL": "postgresql://u@h:5432/db",
                          "LOG_LEVEL": "DEBUG", "EMPTY": ""})
        got = deployment.read()
        assert got["MAINFRAME_HOST"] == "host name #1"
        assert got["DATABASE_URL"] == "postgresql://u@h:5432/db"
        assert got["EMPTY"] == ""
        text = deployment.deployment_file().read_text()
        assert text.startswith("# FINESIII RPA")
        assert not list(data_dir.glob("*.tmp")), "temp file left behind"

    def test_update_removes_on_none_or_empty(self, data_dir):
        from desktop import deployment
        deployment.write({"A": "1", "B": "2", "C": "3"})
        got = deployment.update({"A": None, "B": "", "D": "4"})
        assert got == {"C": "3", "D": "4"}
        assert deployment.read() == {"C": "3", "D": "4"}

    def test_config_reads_the_deployment_file(self, data_dir):
        """The whole point: an installed app's settings come from
        finesiii.env through pydantic-settings, nothing new interprets
        them."""
        from config.development import DevelopmentConfig
        from desktop import deployment
        deployment.write({"MAX_ATTEMPTS": "4", "API_PORT": "9123"})
        cfg = DevelopmentConfig()            # default env files
        assert cfg.max_attempts == 4
        assert cfg.api_port == 9123

    def test_environment_beats_the_deployment_file(self, data_dir,
                                                   monkeypatch):
        from config.development import DevelopmentConfig
        from desktop import deployment
        deployment.write({"MAX_ATTEMPTS": "4"})
        monkeypatch.setenv("MAX_ATTEMPTS", "2")
        assert DevelopmentConfig().max_attempts == 2

    def test_explicit_env_file_none_ignores_it(self, data_dir):
        """Tests and callers that opt out of env files stay isolated."""
        from desktop import deployment
        deployment.write({"MAX_ATTEMPTS": "4"})
        assert make_config(data_dir).max_attempts == 3


class TestValidation:
    def _spec(self, key):
        from desktop.deployment import BY_KEY
        return BY_KEY[key]

    def test_bool_choice_int(self):
        from desktop.deployment import coerce
        assert coerce(self._spec("OCR_ENABLED"), "Yes") == "true"
        assert coerce(self._spec("OCR_ENABLED"), False) == "false"
        with pytest.raises(ValueError):
            coerce(self._spec("OCR_ENABLED"), "maybe")
        assert coerce(self._spec("TERMINAL_DRIVER"), "Mock") == "mock"
        with pytest.raises(ValueError):
            coerce(self._spec("TERMINAL_DRIVER"), "vnc")
        assert coerce(self._spec("API_PORT"), " 8443 ") == "8443"
        with pytest.raises(ValueError):
            coerce(self._spec("API_PORT"), "80")          # below 1024
        with pytest.raises(ValueError):
            coerce(self._spec("API_PORT"), "eight")

    def test_url_must_look_like_one(self):
        from desktop.deployment import coerce
        with pytest.raises(ValueError):
            coerce(self._spec("DATABASE_URL"), "localhost:5432")
        assert coerce(self._spec("DATABASE_URL"),
                      "postgresql://u@h/db") == "postgresql://u@h/db"


class TestPasswordInjection:
    def test_vault_password_joins_the_url_at_config_time(self, monkeypatch):
        monkeypatch.setenv("DATABASE_PASSWORD", "p@ss/w:rd")
        cfg = make_config(__import__("pathlib").Path("/tmp"),
                          database_url="postgresql://app@db.internal:5432/x")
        assert cfg.database_url == \
            "postgresql://app:p%40ss%2Fw%3Ard@db.internal:5432/x"

    def test_url_with_its_own_password_is_left_alone(self, monkeypatch):
        monkeypatch.setenv("DATABASE_PASSWORD", "ignored")
        cfg = make_config(__import__("pathlib").Path("/tmp"),
                          database_url="postgresql://app:real@h/x")
        assert cfg.database_url == "postgresql://app:real@h/x"

    def test_no_vault_password_no_change(self, monkeypatch):
        monkeypatch.delenv("DATABASE_PASSWORD", raising=False)
        cfg = make_config(__import__("pathlib").Path("/tmp"),
                          database_url="postgresql://app@h/x")
        assert cfg.database_url == "postgresql://app@h/x"

    def test_strip_and_extract(self):
        from desktop.vault import strip_url_password, url_password
        url = "postgresql://app:p%40ss@h:5432/x?sslmode=require"
        assert strip_url_password(url) == \
            "postgresql://app@h:5432/x?sslmode=require"
        assert url_password(url) == "p@ss"
        assert url_password("postgresql://app@h/x") is None
        assert strip_url_password("sqlite:///a.db") == "sqlite:///a.db"


class TestDatabaseCheck:
    def test_sqlite_is_ok_even_before_tables_exist(self, tmp_path):
        from desktop.deployment import check_database
        r = check_database(f"sqlite:///{tmp_path / 'new.db'}")
        assert r["ok"] is True and r["engine"] == "sqlite"
        assert "request_queue" in r["missing_tables"]
        assert "created" in r["hint"]

    def test_unreachable_postgres_reports_plainly_and_fast(self):
        import socket
        import time
        from desktop.deployment import check_database
        with socket.socket() as s:
            s.bind(("127.0.0.1", 0))
            dead = s.getsockname()[1]
        t0 = time.time()
        r = check_database(f"postgresql://u@127.0.0.1:{dead}/db",
                           password="pw", timeout=3)
        assert r["ok"] is False
        assert r["engine"] == "postgres"
        assert r["error"] and "pw" not in r["error"]
        assert "unreachable" in r["hint"]
        assert time.time() - t0 < 15

    def test_check_db_cli_exit_codes(self, tmp_path, monkeypatch, capsys):
        from desktop import app as app_module
        monkeypatch.setenv("FINESIII_DATA_DIR", str(tmp_path))
        assert app_module.main(
            ["--check-db", f"sqlite:///{tmp_path / 'x.db'}"]) == 0
        assert "Result   : OK" in capsys.readouterr().out
        import socket
        with socket.socket() as s:
            s.bind(("127.0.0.1", 0))
            dead = s.getsockname()[1]
        assert app_module.main(
            ["--check-db", f"postgresql://u:pw@127.0.0.1:{dead}/db",
             "--json"]) == 1
        out = capsys.readouterr().out
        assert '"ok": false' in out and "pw" not in out
