"""QA fixes — terminal processing, queue/dispatcher, agent and CyberArk
(BUG-001, 002, 003, 004, 006, 007, 019, 020, 035, 050, 077)."""
from __future__ import annotations

import json

import pytest

from src.core.evidence import EvidenceCapture
from src.core.retry import RetryPolicy
from src.rpa.config import build_rpa_config
from src.rpa.credentials import FINESIIICredentials
from src.rpa.drivers.mock import MockDriver
from src.rpa.screens.navigator import Navigator
from src.rpa.workflows.deprovision import DeprovisionWorkflow
from src.rpa.workflows.provision import ProvisionWorkflow
from tests.conftest import make_config

CREDS = FINESIIICredentials("03325", "12N3940", "TEST0000")


@pytest.fixture(autouse=True)
def fast_sleep(monkeypatch):
    monkeypatch.setattr("time.sleep", lambda s: None)


def _rpa_config(tmp_path, scenario="success"):
    return build_rpa_config(driver="mock", environment="development",
                            evidence_dir=str(tmp_path / "evidence"),
                            scenario=scenario)


def _run(tmp_path, operation, scenario="success", config=None):
    config = config or _rpa_config(tmp_path, scenario)
    driver = MockDriver()
    driver.initialize(config["application"])
    evidence = EvidenceCapture(config["evidence"])
    if operation == "provision":
        wf = ProvisionWorkflow(driver, config, None, evidence)
        result = wf.execute(CREDS, "30822", "1217036", "FUJI@33F")
    else:
        wf = DeprovisionWorkflow(driver, config, None, evidence)
        result = wf.execute(CREDS, "30822", "1217036")
    return result, driver


def _boom(*a, **k):
    raise RuntimeError("print screen did not appear")


# ── BUG-001: a failure after the '70' commit is never retried ──────


class TestPostCommitFailureNeverRetried:
    @pytest.mark.parametrize("operation", ["provision", "deprovision"])
    def test_print_failure_after_commit_is_unconfirmed(
            self, tmp_path, monkeypatch, operation):
        monkeypatch.setattr(Navigator, "handle_print_screen", _boom)
        result, driver = _run(tmp_path, operation)
        assert driver.commands.count("70") == 1
        assert result["status"] == "success"
        assert result["result_code"] == "UNCONFIRMED"
        assert result["post_commit_error"] is True
        assert result["commit_sent"] is True
        assert result["confirmed_code"] == "O-0000"
        assert "manual check required" in result["error"]
        assert "print screen did not appear" in result["error"]
        decision = RetryPolicy(max_attempts=3).evaluate(1, result=result)
        assert decision.should_retry is False

    @pytest.mark.parametrize("operation", ["provision", "deprovision"])
    def test_result_read_failure_after_commit_has_no_confirmed_code(
            self, tmp_path, monkeypatch, operation):
        cls = (ProvisionWorkflow if operation == "provision"
               else DeprovisionWorkflow)
        monkeypatch.setattr(cls, "_check_result", _boom)
        result, _ = _run(tmp_path, operation)
        assert result["result_code"] == "UNCONFIRMED"
        assert result["post_commit_error"] is True
        assert "confirmed_code" not in result

    @pytest.mark.parametrize("operation", ["provision", "deprovision"])
    def test_failure_before_commit_is_still_retried(
            self, tmp_path, monkeypatch, operation):
        cls = (ProvisionWorkflow if operation == "provision"
               else DeprovisionWorkflow)
        monkeypatch.setattr(cls, "_generate_confirmation", _boom)
        result, driver = _run(tmp_path, operation)
        assert "70" not in driver.commands
        assert result["status"] == "failed"
        assert result["error_type"] == "system"
        assert not result.get("commit_sent")
        decision = RetryPolicy(max_attempts=3).evaluate(1, result=result)
        assert decision.should_retry is True

    def test_policy_never_retries_a_failed_result_with_commit_sent(self):
        decision = RetryPolicy(max_attempts=3).evaluate(
            1, result={"status": "failed", "error_type": "system",
                       "commit_sent": True})
        assert decision.should_retry is False
        assert "commit sent" in decision.reason

    def test_traces_failure_does_not_raise_from_executor(self, tmp_path,
                                                          monkeypatch):
        from src.modules.intake.models import ProcessingRequest
        from src.rpa import executor as ex_mod
        cfg = make_config(tmp_path, terminal_driver="mock",
                          ocr_enabled=False)
        executor = ex_mod.TerminalExecutor(cfg)

        class _Observed:
            def __init__(self, inner):
                self._inner = inner

            def __getattr__(self, name):
                return getattr(self._inner, name)

            def traces(self):
                raise RuntimeError("trace store gone")

        monkeypatch.setattr(executor, "_observe",
                            lambda d, r, c: _Observed(d))
        # The password intake gives every new account (no default one).
        req = ProcessingRequest(operation="provision",
                                affiliation_code="30822",
                                employee_code="1217036", password="Abc@1234")
        result = executor.execute(req)
        assert result["status"] == "success"

    def test_dispatcher_audits_post_commit_error(self, tmp_path):
        from src.core.db import Database
        from src.modules.audit.services import TransactionStore
        from src.modules.intake.models import ProcessingRequest
        from src.modules.queue.dispatcher import Dispatcher
        from src.modules.queue.services import QueueStore

        class _Audit:
            def __init__(self):
                self.events = []

            def event(self, category, action, **kw):
                self.events.append((action, kw.get("severity")))

            def transaction(self, txn):
                pass

        cfg = make_config(tmp_path)
        db = Database.from_config(cfg)
        try:
            q = QueueStore(db)
            audit = _Audit()

            class _Exec:
                def execute(self, request):
                    return {"status": "success", "result_code": "UNCONFIRMED",
                            "error": "'70' sent; a later step failed",
                            "post_commit_error": True, "commit_sent": True}

            d = Dispatcher(q, TransactionStore(db), RetryPolicy(max_attempts=3),
                           executor=_Exec(), cfg=cfg, audit=audit)
            r = ProcessingRequest(operation="provision",
                                  affiliation_code="30822",
                                  employee_code="1217036")
            q.enqueue(r)
            assert d._tick() is True
            row = q.get(r.request_id)
            assert row.status == "done"
            assert row.result_code == "UNCONFIRMED"
            assert ("post_commit_error", "ERROR") in audit.events
        finally:
            db.close()


# ── Dispatcher helpers ──────────────────────────────────────────────


class _Audit:
    def __init__(self):
        self.events = []

    def event(self, category, action, **kw):
        self.events.append((action, kw.get("severity")))

    def transaction(self, txn):
        pass


class _Exec:
    def __init__(self, result=None):
        self.result = result or {"status": "success",
                                 "result_code": "O-0000", "error": ""}
        self.calls = 0

    def execute(self, request):
        self.calls += 1
        return dict(self.result)


@pytest.fixture
def qenv(tmp_path):
    from src.core.db import Database
    from src.modules.audit.services import TransactionStore
    from src.modules.queue.services import QueueStore
    cfg = make_config(tmp_path)
    db = Database.from_config(cfg)
    try:
        yield cfg, QueueStore(db), TransactionStore(db)
    finally:
        db.close()


def _dispatcher(qenv, tmp_path, executor=None, **kw):
    from src.modules.queue.dispatcher import Dispatcher
    cfg, q, t = qenv
    kw.setdefault("pending_path", tmp_path / "pending_completions.jsonl")
    kw.setdefault("sleep", lambda s: None)
    return Dispatcher(q, t, kw.pop("retry_policy", RetryPolicy(max_attempts=3)),
                      executor=executor or _Exec(), cfg=cfg, **kw)


def _enqueue(q, employee_code="1217036"):
    from src.modules.intake.models import ProcessingRequest
    r = ProcessingRequest(operation="provision", affiliation_code="30822",
                          employee_code=employee_code, password="Abc@1234")
    q.enqueue(r)
    return r.request_id


# ── BUG-002: a completion the database refuses is never re-run ─────


class TestDurableCompletion:
    def test_transient_completion_error_is_retried(self, qenv, tmp_path,
                                                   monkeypatch):
        cfg, q, _ = qenv
        waits = []
        d = _dispatcher(qenv, tmp_path, sleep=waits.append)
        rid = _enqueue(q)
        real = q.mark_complete
        fails = {"n": 2}

        def flaky(*a, **k):
            if fails["n"]:
                fails["n"] -= 1
                raise RuntimeError("database connection lost")
            return real(*a, **k)
        monkeypatch.setattr(q, "mark_complete", flaky)
        assert d._tick() is True
        assert q.get(rid).status == "done"
        assert waits == [0.5, 2.0]
        assert not (tmp_path / "pending_completions.jsonl").exists()

    def test_persistent_error_is_journaled_and_applied_on_startup(
            self, qenv, tmp_path, monkeypatch):
        from src.modules.queue.dispatcher import recover_on_startup
        cfg, q, _ = qenv
        audit = _Audit()
        d = _dispatcher(qenv, tmp_path, audit=audit)
        rid = _enqueue(q)

        def down(*a, **k):
            raise RuntimeError("database unavailable")
        monkeypatch.setattr(q, "mark_complete", down)
        assert d._tick() is True
        journal = tmp_path / "pending_completions.jsonl"
        entry = json.loads(journal.read_text(encoding="utf-8").strip())
        assert entry["request_id"] == rid and entry["status"] == "done"
        assert "password" not in entry
        assert "Abc@1234" not in journal.read_text(encoding="utf-8")
        # History and hooks still ran.
        assert ("request_dispatched", None) in audit.events
        assert q.get(rid).status == "running"

        monkeypatch.undo()
        out = recover_on_startup(q, cfg, 1, pending_path=journal)
        row = q.get(rid)
        assert row.status == "done" and row.result_code == "O-0000"
        assert row.password == ""
        assert out["requeued"] == []
        assert not journal.exists()

    def test_tick_claims_nothing_while_journal_pending(self, qenv, tmp_path,
                                                        monkeypatch):
        cfg, q, _ = qenv
        executor = _Exec()
        d = _dispatcher(qenv, tmp_path, executor=executor)
        journal = tmp_path / "pending_completions.jsonl"
        journal.write_text(json.dumps({
            "request_id": "req_gone", "status": "done", "result_code": "",
            "error": "", "evidence_path": "", "completed_at": ""}) + "\n",
            encoding="utf-8")
        rid = _enqueue(q)

        def down(*a, **k):
            raise RuntimeError("database unavailable")
        monkeypatch.setattr(q, "complete_if_running", down)
        assert d._tick() is False
        assert executor.calls == 0
        assert q.get(rid).status == "queued"
        assert journal.exists()

        monkeypatch.undo()
        assert d._tick() is True          # journal applied, work resumes
        assert not journal.exists()
        assert executor.calls == 1

    def test_schedule_retry_is_retried(self, qenv, tmp_path, monkeypatch):
        cfg, q, _ = qenv
        d = _dispatcher(qenv, tmp_path, executor=_Exec(
            {"status": "failed", "error_type": "system", "error": "x"}))
        rid = _enqueue(q)
        real = q.schedule_retry
        fails = {"n": 1}

        def flaky(*a, **k):
            if fails["n"]:
                fails["n"] -= 1
                raise RuntimeError("database connection lost")
            return real(*a, **k)
        monkeypatch.setattr(q, "schedule_retry", flaky)
        assert d._tick() is True
        assert q.get(rid).status == "queued"

    def test_orphan_with_commit_evidence_is_unconfirmed(self, qenv,
                                                        tmp_path):
        from src.modules.queue.dispatcher import recover_on_startup
        cfg, q, _ = qenv
        rid = _enqueue(q)
        q.dequeue_oldest(worker_id=1)
        folder = tmp_path / "evidence" / rid
        folder.mkdir(parents=True)
        (folder / "017_commit_command_entered_101500.png").write_bytes(b"x")
        audit = _Audit()
        out = recover_on_startup(q, cfg, 424242,
                                 pending_path=tmp_path / "p.jsonl",
                                 audit=audit)
        assert out["unconfirmed"] == [rid]
        row = q.get(rid)
        assert row.status == "done" and row.result_code == "UNCONFIRMED"
        assert row.error == "interrupted after commit — manual check required"
        assert ("orphan_interrupted_after_commit", "ERROR") in audit.events

    def test_orphan_without_commit_evidence_is_requeued(self, qenv,
                                                        tmp_path):
        from src.modules.queue.dispatcher import recover_on_startup
        cfg, q, _ = qenv
        rid = _enqueue(q)
        q.dequeue_oldest(worker_id=1)
        folder = tmp_path / "evidence" / rid
        folder.mkdir(parents=True)
        (folder / "012_confirmation_screen_101400.png").write_bytes(b"x")
        out = recover_on_startup(q, cfg, 424242,
                                 pending_path=tmp_path / "p.jsonl")
        assert out["requeued"] == [rid]
        assert q.get(rid).status == "queued"

    def test_commit_evidence_from_an_earlier_attempt_does_not_count(
            self, qenv, tmp_path):
        import os
        from src.modules.queue.dispatcher import commit_evidence
        cfg, q, _ = qenv
        rid = _enqueue(q)
        req = q.dequeue_oldest(worker_id=1)
        folder = tmp_path / "evidence" / rid
        folder.mkdir(parents=True)
        old = folder / "017_commit_command_entered_101500.png"
        old.write_bytes(b"x")
        os.utime(old, (1_000_000, 1_000_000))
        assert commit_evidence(cfg.evidence_dir, req) == ""


# ── BUG-003: this installation's id on every claimed row ───────────


class TestInstallationId:
    def test_id_created_once_and_reused(self, tmp_path):
        from src.modules.queue.dispatcher import installation_id
        path = tmp_path / "instance.id"
        first = installation_id(path)
        assert 1000 <= first <= 2 ** 31 - 1
        assert installation_id(path) == first

    def test_dispatcher_claims_with_its_worker_id(self, qenv, tmp_path):
        cfg, q, _ = qenv
        d = _dispatcher(qenv, tmp_path, worker_id=424242)
        rid = _enqueue(q)
        seen = {}

        class _Spy(_Exec):
            def execute(self, request):
                seen["worker_id"] = request.worker_id
                return super().execute(request)
        d.executor = _Spy()
        assert d._tick() is True
        assert seen["worker_id"] == 424242
        assert q.get(rid).worker_id == 424242


# ── BUG-006: CyberArk refresh on every rejected attempt ────────────


class TestPasswordRejectedEveryAttempt:
    def test_hook_fires_on_each_rejected_attempt(self, qenv, tmp_path):
        cfg, q, _ = qenv
        fired = []
        d = _dispatcher(qenv, tmp_path, executor=_Exec(
            {"status": "failed", "error_type": "system", "error": "bad pw",
             "error_id": "LOGIN_PASSWORD_INCORRECT"}),
            on_password_rejected=lambda: fired.append(1))
        rid = _enqueue(q)
        from datetime import datetime
        from src.modules.intake.models import now_jst
        counts = []
        for _ in range(3):
            before = now_jst()
            assert d._tick() is True
            counts.append(len(fired))
            row = q.get(rid)
            if row.status == "queued":
                wait = (datetime.fromisoformat(row.next_attempt_at)
                        - before).total_seconds()
                assert wait >= 19.9       # refresh lands before the retry
                with q.db.connect() as conn:
                    conn.execute("UPDATE request_queue SET "
                                 "next_attempt_at = '' WHERE request_id = ?",
                                 (rid,))
        assert counts == [1, 2, 3]
        assert q.get(rid).status == "failed"

    def test_other_errors_keep_the_policy_delay(self, qenv, tmp_path):
        cfg, q, _ = qenv
        fired = []
        d = _dispatcher(qenv, tmp_path, executor=_Exec(
            {"status": "failed", "error_type": "system", "error": "x",
             "error_id": "CENTER_NOT_READY"}),
            on_password_rejected=lambda: fired.append(1),
            retry_policy=RetryPolicy(max_attempts=3, base_delay=1,
                                     max_delay=1, jitter=False))
        rid = _enqueue(q)
        from datetime import datetime
        from src.modules.intake.models import now_jst
        before = now_jst()
        d._tick()
        wait = (datetime.fromisoformat(q.get(rid).next_attempt_at)
                - before).total_seconds()
        assert fired == [] and wait < 5


# ── BUG-020: CyberArk fallback password pauses processing ──────────


class TestProcessingGate:
    def test_dispatcher_claims_nothing_while_gate_closed(self, qenv,
                                                         tmp_path):
        cfg, q, _ = qenv
        state = {"open": False}
        executor = _Exec()
        d = _dispatcher(qenv, tmp_path, executor=executor,
                        can_process=lambda: state["open"])
        rid = _enqueue(q)
        assert d._tick() is False
        assert executor.calls == 0 and q.get(rid).status == "queued"
        state["open"] = True              # CyberArk delivered: auto-resume
        assert d._tick() is True
        assert q.get(rid).status == "done"

    def test_gate_error_counts_as_closed(self, qenv, tmp_path):
        def broken():
            raise RuntimeError("status unavailable")
        d = _dispatcher(qenv, tmp_path, can_process=broken)
        _enqueue(qenv[1])
        assert d._tick() is False

    def _provider(self):
        from src.integrations.cyberark.provider import (
            CyberArkPasswordProvider,
        )
        from src.integrations.cyberark.client import CyberArkError

        class _Client:
            fail = True

            def fetch_password(self):
                if self.fail:
                    raise CyberArkError("vault unreachable")
                return "Vault@Pass1"

        class _S:
            enabled = True
            api_style = "ccp"
            target_env_var = "FINESIII_TEST_CYBERARK_PW"
            refresh_interval_hours = 4
            refresh_interval_seconds = 4 * 3600
        return CyberArkPasswordProvider(_S(), client=_Client())

    def test_fallback_flag_set_and_cleared(self, monkeypatch):
        monkeypatch.setenv("FINESIII_TEST_CYBERARK_PW", "Env@Pass1")
        p = self._provider()
        p.start()
        try:
            assert p.status()["using_fallback"] is True
            p.client.fail = False
            p.refresh()
            assert p.status()["using_fallback"] is False
        finally:
            p.stop()


# ── BUG-007: optional stop when the confirmation cannot be read ────


class TestRequireReadableConfirmation:
    def _config(self, tmp_path, required):
        return build_rpa_config(driver="mock", environment="development",
                                evidence_dir=str(tmp_path / "evidence"),
                                scenario="unreadable",
                                require_readable_confirmation=required)

    @pytest.mark.parametrize("operation", ["provision", "deprovision"])
    def test_unreadable_and_required_cancels_before_commit(
            self, tmp_path, operation):
        result, driver = _run(tmp_path, operation,
                              config=self._config(tmp_path, True))
        assert "70" not in driver.commands
        assert "99" in driver.commands
        assert result["status"] == "failed"
        assert result["error_type"] == "system"
        assert result["failed_step"] == "validate_confirmation"
        assert not result.get("commit_sent")
        assert RetryPolicy(max_attempts=3).evaluate(
            1, result=result).should_retry is True
        from pathlib import Path
        names = "|".join(p.name for p in
                         Path(result["evidence_path"]).glob("*.png"))
        assert "confirmation_unverifiable" in names

    @pytest.mark.parametrize("operation", ["provision", "deprovision"])
    def test_unreadable_not_required_proceeds(self, tmp_path, operation):
        result, driver = _run(tmp_path, operation,
                              config=self._config(tmp_path, False))
        assert "70" in driver.commands
        assert result["status"] == "success"
        assert result["result_code"] == "UNCONFIRMED"

    def test_setting_is_off_by_default_and_reaches_the_workflow(
            self, tmp_path):
        from config.production import ProductionConfig
        assert ProductionConfig.model_fields[
            "require_readable_confirmation"].default is False
        assert make_config(tmp_path).require_readable_confirmation is False
        from src.rpa.executor import TerminalExecutor
        cfg = make_config(tmp_path, terminal_driver="mock",
                          ocr_enabled=False,
                          require_readable_confirmation=True)
        assert TerminalExecutor(cfg).rpa_config[
            "require_readable_confirmation"] is True


# ── BUG-019: processing date in Japan time ──────────────────────────


class TestProcessingDateJst:
    def test_date_is_japan_date_regardless_of_host_zone(self, monkeypatch):
        from datetime import datetime as real_datetime, timezone
        from src.rpa.screens import field_mapper

        class _Frozen(real_datetime):
            @classmethod
            def now(cls, tz=None):
                utc = real_datetime(2026, 9, 26, 16, 0, tzinfo=timezone.utc)
                return utc.astimezone(tz) if tz else utc.replace(tzinfo=None)
        monkeypatch.setattr(field_mapper, "datetime", _Frozen)
        data = field_mapper.AccountData("2", "30822", "1217036", "FUJI@33F")
        assert data.processing_date == "260927"
        # Delete leaves the date empty, as before.
        assert field_mapper.AccountData("4", "30822", "1217036",
                                        audit_target="").processing_date == ""


# ── BUG-035: 'operator code not registered' is not retried ─────────


class TestOperatorNotRegisteredNotRetried:
    @pytest.mark.parametrize("scenario", ["invalid_staff_code",
                                          "invalid_affiliation_code"])
    def test_one_attempt_then_failed(self, qenv, tmp_path, scenario):
        from src.modules.intake.models import ProcessingRequest
        from src.rpa.executor import TerminalExecutor
        cfg, q, _ = qenv
        object.__setattr__(cfg, "terminal_driver", "mock")
        object.__setattr__(cfg, "ocr_enabled", False)
        d = _dispatcher(qenv, tmp_path, executor=TerminalExecutor(cfg))
        r = ProcessingRequest(operation="provision", affiliation_code="30822",
                              employee_code="1217036", password="Abc@1234",
                              metadata={"sim_scenario": scenario})
        q.enqueue(r)
        assert d._tick() is True
        row = q.get(r.request_id)
        assert row.status == "failed"
        assert row.attempt_count == 1
        assert "operator code not registered" in row.error

    def test_policy_honours_retryable_false(self):
        policy = RetryPolicy(max_attempts=3)
        failed = {"status": "failed", "error_type": "system"}
        assert policy.evaluate(1, result=failed).should_retry is True
        assert policy.evaluate(1, result=dict(failed, retryable=False)
                               ).should_retry is False

    def test_rules_that_allow_a_retry_still_retry(self):
        from src.rpa.screens.error_handler import build_exception
        from src.rpa.vision.error_catalog import ErrorCatalog, ErrorMatch
        rules = {r.id: r for r in ErrorCatalog.load("config/errors.yaml").rules}
        for rid, expected in (("LOGIN_PASSWORD_INCORRECT", True),
                              ("CENTER_NOT_READY", True),
                              ("LOGIN_OPERATOR_NOT_REGISTERED", False)):
            exc = build_exception(ErrorMatch(rule=rules[rid], matched=[],
                                             captured={}, confidence=1.0),
                                  "login_submitted")
            assert exc.retryable is expected, rid
