"""Console front end (QA 2026-09-28): the page elements and API fields
the fixes rely on are present. The console has no build step and no
browser test harness; this pins the contract between the page and the
service (the behaviour itself is checked in the browser)."""
import re
from pathlib import Path

UI = Path(__file__).resolve().parents[2] / "desktop" / "ui"
APP = (UI / "app.js").read_text(encoding="utf-8")
INDEX = (UI / "index.html").read_text(encoding="utf-8")


def test_assets_carry_the_new_version():
    versions = re.findall(r"\?v=([0-9.a-z]+)", INDEX)
    assert versions and set(versions) == {"2026.10.06"}


def test_new_elements_exist_once():
    for element_id in ("conn-banner", "no-pages", "dash-problems",
                       "sys-problems", "nav-dashboard"):
        assert INDEX.count(f'id="{element_id}"') == 1, element_id


def test_thumbnails_are_marked_and_full_view_is_not():
    """BUG-071: only the grid asks for thumbnails."""
    assert APP.count("?purpose=thumbnail") == 1
    viewer = APP[APP.index("async function showCapture"):]
    viewer = viewer[:viewer.index("\n}\n")]
    assert "purpose=thumbnail" not in viewer


def test_uploads_no_longer_offer_svg():
    """BUG-036: the file pickers do not offer SVG."""
    for accept in re.findall(r'accept="([^"]*)"', INDEX):
        assert "svg" not in accept and accept != "image/*", accept


def test_backend_fields_are_used():
    assert "r.restart_required !== false" in APP           # BUG-064
    assert "variables_empty" in APP                          # BUG-075
    assert "pending_restart" in APP                          # BUG-054
    assert "startup_problems" in APP                         # BUG-025
    assert "r.connected" in APP                              # BUG-048
    assert "expires_in" in APP                               # BUG-017


def test_smtp_password_has_no_settings_fallback():
    """BUG-005: the SMTP password is a credential only."""
    assert 'data-key="SMTP_PASSWORD"' not in APP
    assert "secrets: ['SMTP_PASSWORD']" in APP


def test_user_and_role_name_lengths_are_declared():
    """BUG-069."""
    assert re.search(r'id="nu-user"[^>]*minlength="3"', INDEX)
    assert re.search(r'id="nr-name"[^>]*minlength="2"', INDEX)
