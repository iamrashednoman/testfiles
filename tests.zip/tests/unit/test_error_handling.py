"""Screen error handling — catalogue matching and guard actions.

Covers the contract that makes the feature safe to ship:
  • rules are DATA and are validated at load (a typo fails loudly);
  • matching survives OCR variance and respects scope/priority/none;
  • the guard's actions do what the catalogue says;
  • UPGRADE-ONLY: a low-confidence read may never act;
  • a screen matching no rule leaves behaviour exactly as before.
"""
import pytest

from src.core.exceptions import (
    BusinessException, EnvironmentUnavailableError, SystemException,
)
from src.rpa.screens.error_handler import ScreenGuard, build_guard
from src.rpa.vision.error_catalog import ErrorCatalog, ErrorCatalogError

CATALOG_PATH = "config/errors.yaml"

# The client's Case 1 evidence, transcribed.
CENTER_DIALOG = (
    "エラーメッセージ\n F I N E S\n"
    "WRT   0000 0151 0000 00000000\nNDSUB\n"
    "センター準備中\n確認：ＥＮＴＥＲ\n"
    "FUJI INFORMATION NETWORK\n所属コード\n担当者コード\nパスワード"
)
HEALTHY = "FINESⅢ 業務MENU\n業務ＮＯ\n903 パスワードDBの更新と追加"


def _catalog(rows, settings=None, strict=True, tmp_path=None):
    """Build a catalogue from inline rows via a temp YAML file."""
    import yaml
    path = tmp_path / "errors.yaml"
    path.write_text(yaml.safe_dump(
        {"settings": settings or {}, "errors": rows},
        allow_unicode=True), encoding="utf-8")
    return ErrorCatalog.load(str(path), strict=strict)


class FakeDriver:
    """Minimal driver surface the guard touches."""

    def __init__(self, text=HEALTHY, confidence=1.0, dismiss=None):
        self.text = text
        self.last_read_confidence = confidence
        self.keys = []
        self.commands = []
        self._dismiss = dismiss
        self.dismiss_calls = []

    def get_screen_text(self):
        return self.text

    def press_key(self, key):
        self.keys.append(key)

    def submit_command(self, command, delay=0.5, before_enter=None):
        self.commands.append(command)


class DismissingDriver(FakeDriver):
    def dismiss_dialog(self, key="enter", title_hint=""):
        self.dismiss_calls.append((key, title_hint))
        return self._dismiss


class RecordingEvidence:
    def __init__(self):
        self.captured = []

    def capture(self, point, driver=None):
        self.captured.append(point)
        return point


def _guard(driver, catalog, **kw):
    kw.setdefault("acknowledge_wait", 0)
    kw.setdefault("retry_wait", 0)
    return ScreenGuard(driver, catalog, **kw)


# ── Catalogue loading + validation ──────────────────────────────────

class TestCatalogLoading:
    def test_shipped_catalogue_loads(self):
        catalog = ErrorCatalog.load(CATALOG_PATH)
        assert len(catalog) >= 3
        assert catalog.digest, "digest identifies the live rule set"
        assert {r.id for r in catalog.rules} >= {
            "CENTER_NOT_READY", "FINES_ERROR_DIALOG"}

    def test_rules_are_priority_ordered(self):
        catalog = ErrorCatalog.load(CATALOG_PATH)
        priorities = [r.priority for r in catalog.rules]
        assert priorities == sorted(priorities)

    def test_missing_file_is_loud_in_strict_mode(self):
        with pytest.raises(ErrorCatalogError):
            ErrorCatalog.load("config/does_not_exist.yaml", strict=True)

    def test_missing_file_degrades_when_not_strict(self):
        catalog = ErrorCatalog.load("config/nope.yaml", strict=False)
        assert len(catalog) == 0
        assert catalog.match(CENTER_DIALOG, 1.0) is None

    def test_unknown_action_rejected(self, tmp_path):
        with pytest.raises(ErrorCatalogError, match="unknown action"):
            _catalog([{"id": "X", "match": {"all": ["a"]},
                       "action": "self_destruct"}], tmp_path=tmp_path)

    def test_rule_without_matchers_rejected(self, tmp_path):
        with pytest.raises(ErrorCatalogError, match="match.all"):
            _catalog([{"id": "X", "match": {}}], tmp_path=tmp_path)

    def test_unknown_exception_class_rejected(self, tmp_path):
        with pytest.raises(ErrorCatalogError, match="unknown exception"):
            _catalog([{"id": "X", "match": {"all": ["a"]},
                       "exception": "NoSuchError"}], tmp_path=tmp_path)

    def test_classification_must_agree_with_exception(self, tmp_path):
        """A 'business' rule raising a SystemException would be retried
        against its own declaration — caught at load, not in prod."""
        with pytest.raises(ErrorCatalogError, match="contradicts"):
            _catalog([{"id": "X", "match": {"all": ["a"]},
                       "classification": "business",
                       "exception": "EnvironmentUnavailableError"}],
                     tmp_path=tmp_path)

    def test_duplicate_ids_rejected(self, tmp_path):
        with pytest.raises(ErrorCatalogError, match="Duplicate"):
            _catalog([{"id": "X", "match": {"all": ["a"]}},
                      {"id": "X", "match": {"all": ["b"]}}],
                     tmp_path=tmp_path)


# ── Matching ────────────────────────────────────────────────────────

class TestCatalogMatching:
    def test_case_1_screen_matches(self):
        match = ErrorCatalog.load(CATALOG_PATH).match(
            CENTER_DIALOG, 0.98, screen="finesiii_login")
        assert match.rule.id == "CENTER_NOT_READY"
        assert "センター準備中" in match.matched
        assert match.rule.action == "acknowledge"
        assert match.rule.acknowledge_key == "enter"
        assert match.rule.exit_from == "login_screen"

    def test_diagnostic_values_captured_for_the_host_team(self):
        match = ErrorCatalog.load(CATALOG_PATH).match(CENTER_DIALOG, 1.0)
        assert "0151" in match.captured["diagnostic"]
        assert match.captured["subsystem"] == "NDSUB"

    def test_healthy_screen_matches_nothing(self):
        assert ErrorCatalog.load(CATALOG_PATH).match(HEALTHY, 1.0) is None

    def test_ocr_variance_is_folded(self):
        """Fullwidth / spaced / hyphen-variant text still matches."""
        catalog = ErrorCatalog.load(CATALOG_PATH)
        assert catalog.match("エラーメッセージ　センター準備中　確認：ＥＮＴＥＲ",
                             1.0).rule.id == "CENTER_NOT_READY"

    def test_generic_dialog_is_the_fallback(self):
        """A garbled specific marker still trips the catch-all instead
        of leaving the bot typing into a blocked window."""
        catalog = ErrorCatalog.load(CATALOG_PATH)
        garbled = "エラーメッセージ\nNDSUB\nセソター準備中\n確認：ＥＮＴＥＲ"
        assert catalog.match(garbled, 1.0).rule.id == "FINES_ERROR_DIALOG"

    def test_none_markers_disambiguate(self):
        """削除済み is already-deleted and must NOT trip the generic
        error-comment rule."""
        catalog = ErrorCatalog.load(CATALOG_PATH)
        deleted = "確認画面\nエラーコメント\n所属・社員コード誤り？削除済み"
        match = catalog.match(deleted, 1.0, screen="account_management")
        assert match is None or match.rule.id != \
            "CONFIRMATION_ERROR_COMMENT"

        other = "確認画面\nエラーコメント\n所属コードに誤りがあります"
        assert catalog.match(
            other, 1.0, screen="account_management").rule.id == \
            "CONFIRMATION_ERROR_COMMENT"

    def test_scope_limits_a_rule_to_its_screen(self, tmp_path):
        catalog = _catalog([{"id": "SCOPED", "scope": "print_screen",
                             "match": {"all": ["boom"]}}],
                           tmp_path=tmp_path)
        assert catalog.match("boom", 1.0, screen="print_screen")
        assert catalog.match("boom", 1.0, screen="business_menu") is None

    def test_priority_decides_between_overlapping_rules(self, tmp_path):
        catalog = _catalog([
            {"id": "GENERIC", "priority": 900, "match": {"all": ["x"]}},
            {"id": "SPECIFIC", "priority": 10, "match": {"all": ["x"]}},
        ], tmp_path=tmp_path)
        assert catalog.match("x", 1.0).rule.id == "SPECIFIC"

    def test_disabled_rule_never_fires(self, tmp_path):
        catalog = _catalog([{"id": "OFF", "enabled": False,
                             "match": {"all": ["x"]}}],
                           tmp_path=tmp_path)
        assert catalog.match("x", 1.0) is None

    def test_result_code_matching(self, tmp_path):
        catalog = _catalog([{"id": "E9901", "match": {"code": "E-9901"},
                             "classification": "business"}],
                           tmp_path=tmp_path)
        assert catalog.match("処理結果 Ｅ－９９０１", 1.0).rule.id == "E9901"
        assert catalog.match("処理結果 E-9902", 1.0) is None


# ── Guard behaviour ─────────────────────────────────────────────────

class TestGuardSafety:
    def test_clean_screen_is_a_no_op(self):
        driver = FakeDriver(HEALTHY)
        guard = _guard(driver, ErrorCatalog.load(CATALOG_PATH))
        guard.check("anywhere")
        assert guard.trace == []
        assert driver.keys == [] and driver.commands == []

    def test_low_confidence_read_may_never_act(self):
        """UPGRADE-ONLY: a shaky OCR read is recorded but must not
        abort a transaction or touch the terminal."""
        driver = FakeDriver(CENTER_DIALOG, confidence=0.40)
        guard = _guard(driver, ErrorCatalog.load(CATALOG_PATH),
                       min_confidence=0.75)
        guard.check("finesiii_connect")          # must NOT raise
        assert driver.keys == [], "acted on an untrustworthy read"
        assert guard.trace[0]["acted"] is False
        assert guard.trace[0]["error_id"] == "CENTER_NOT_READY"

    def test_no_catalogue_means_no_guard(self):
        driver = FakeDriver(CENTER_DIALOG)
        guard = _guard(driver, ErrorCatalog())
        assert guard.active is False
        guard.check("finesiii_connect")          # must NOT raise

    def test_disabled_config_yields_inert_guard(self):
        guard = build_guard(FakeDriver(CENTER_DIALOG),
                            {"errors": {"enabled": False}})
        assert guard.active is False
        guard.check("finesiii_connect")

    def test_unreadable_screen_is_survivable(self):
        class Broken(FakeDriver):
            def get_screen_text(self):
                raise RuntimeError("terminal gone")

        guard = _guard(Broken(), ErrorCatalog.load(CATALOG_PATH))
        guard.check("anywhere")                  # must NOT raise


class TestGuardActions:
    def test_case_1_acknowledges_then_exits_from_login(self):
        driver = FakeDriver(CENTER_DIALOG)
        evidence = RecordingEvidence()
        guard = _guard(driver, ErrorCatalog.load(CATALOG_PATH),
                       evidence=evidence)

        with pytest.raises(EnvironmentUnavailableError) as excinfo:
            guard.check("finesiii_connect")

        error = excinfo.value
        # The client's instruction: press Enter…
        assert driver.keys == ["enter"]
        # …then exit from the LOGIN screen, not the full walk-back.
        assert error.exit_from_login is True
        assert error.rule_id == "CENTER_NOT_READY"
        assert error.error_status == "failed"
        # Retryable: the host is down, the request is fine.
        assert isinstance(error, SystemException)
        # Evidence of the error AND of the bot's reaction.
        assert evidence.captured == ["error_detected",
                                     "error_recovery_entered",
                                     "error_recovery_complete"]

    def test_dialog_is_focused_before_the_key_on_real_terminals(self):
        """A modal is a separate owned window: when the driver can
        focus it, the guard must not also send a stray key."""
        driver = DismissingDriver(CENTER_DIALOG, dismiss=True)
        guard = _guard(driver, ErrorCatalog.load(CATALOG_PATH))
        with pytest.raises(EnvironmentUnavailableError):
            guard.check("finesiii_connect")
        assert driver.dismiss_calls == [("enter", "エラーメッセージ")]
        assert driver.keys == [], "sent a duplicate keystroke"

    def test_falls_back_to_a_plain_key_when_the_dialog_is_not_found(self):
        driver = DismissingDriver(CENTER_DIALOG, dismiss=False)
        guard = _guard(driver, ErrorCatalog.load(CATALOG_PATH))
        with pytest.raises(EnvironmentUnavailableError):
            guard.check("finesiii_connect")
        assert driver.keys == ["enter"]

    def test_cancel_and_report_backs_out_before_committing(self):
        driver = FakeDriver(
            "確認画面\nエラーコメント\n所属コードに誤りがあります")
        guard = _guard(driver, ErrorCatalog.load(CATALOG_PATH),
                       nav_cfg={"cancel_command": "99"})
        with pytest.raises(BusinessException) as excinfo:
            guard.check("confirmation_screen",
                        expect="account_management")
        assert driver.commands == ["99"], "did not cancel"
        assert excinfo.value.rule_id == "CONFIRMATION_ERROR_COMMENT"
        # Business: a human must act, so it is never retried.
        assert not isinstance(excinfo.value, SystemException)

    def test_continue_action_only_audits(self, tmp_path):
        catalog = _catalog([{"id": "NOTICE", "match": {"all": ["お知らせ"]},
                             "action": "continue"}], tmp_path=tmp_path)
        driver = FakeDriver("お知らせ：定期メンテナンス")
        guard = _guard(driver, catalog)
        guard.check("business_menu")             # must NOT raise
        assert guard.trace[0]["error_id"] == "NOTICE"
        assert driver.keys == [] and driver.commands == []

    def test_retry_step_waits_for_a_transient_to_clear(self, tmp_path):
        catalog = _catalog([{"id": "FREEZE", "match": {"all": ["凍結"]},
                             "action": "retry_step"}], tmp_path=tmp_path)

        class Clearing(FakeDriver):
            def get_screen_text(self):
                text, self.text = self.text, HEALTHY
                return text

        guard = _guard(Clearing("画面が凍結しました"), catalog)
        guard.check("data_entered")              # clears → no raise
        assert guard.trace[0]["error_id"] == "FREEZE"

    def test_retry_step_escalates_when_it_never_clears(self, tmp_path):
        catalog = _catalog([{"id": "FREEZE", "match": {"all": ["凍結"]},
                             "action": "retry_step"}], tmp_path=tmp_path)
        guard = _guard(FakeDriver("画面が凍結しました"), catalog,
                       max_step_retries=2)
        with pytest.raises(SystemException):
            guard.check("data_entered")


class TestScreenExpectation:
    SCREENS = {"business_menu": {"identifiers": ["業務MENU", "業務ＮＯ"]},
               "print_screen": {"identifiers": ["用紙コード", "帳票名称"]}}

    def test_mismatch_is_recorded_but_not_fatal_by_default(self):
        """The real terminal's lenient wait proceeds on an unmatched
        screen; recording the mismatch must not change that."""
        guard = _guard(FakeDriver(HEALTHY), ErrorCatalog.load(CATALOG_PATH),
                       screens_cfg=self.SCREENS)
        guard.check("print_screen", expect="print_screen")
        assert guard.trace[0]["error_id"] == "SCREEN_MISMATCH"
        assert guard.trace[0]["acted"] is False

    def test_strict_mode_raises_on_the_wrong_screen(self):
        from src.core.exceptions import ScreenNotRecognizedError
        guard = _guard(FakeDriver(HEALTHY), ErrorCatalog.load(CATALOG_PATH),
                       screens_cfg=self.SCREENS,
                       strict_screen_detection=True)
        with pytest.raises(ScreenNotRecognizedError):
            guard.check("print_screen", expect="print_screen")

    def test_expected_screen_passes_quietly(self):
        guard = _guard(FakeDriver(HEALTHY), ErrorCatalog.load(CATALOG_PATH),
                       screens_cfg=self.SCREENS)
        guard.check("business_menu", expect="business_menu")
        assert guard.trace == []


# ── Case 2: login rejection + per-error email routing ───────────────

LOGIN_REJECTED = (
    "AIM2/V04/P200HAAPROC\nFUJI INFORMATION NETWORK\n"
    "EXTENSIBLE SYSTEM Ⅲ\n"
    "所属コード 9902783  サービスデリバリー部　サービスＭＧ１課\n"
    "(終了:99)\n"
    "担当者コード 1735393   パスワードが誤っています\n"
    "パスワード\n英字"
)


class TestLoginRejectionRule:
    def test_case_2_screen_matches(self):
        match = ErrorCatalog.load(CATALOG_PATH).match(
            LOGIN_REJECTED, 0.97, screen="finesiii_login")
        assert match.rule.id == "LOGIN_PASSWORD_INCORRECT"
        assert "パスワードが誤っています" in match.matched

    def test_rule_carries_no_retry_loop_of_its_own(self):
        """THE lockout guard, asserted on the rule itself: the retry is
        the dispatcher's (retry.whole_request), never a second loop
        inside the rule that would multiply with it."""
        rule = next(r for r in ErrorCatalog.load(CATALOG_PATH).rules
                    if r.id == "LOGIN_PASSWORD_INCORRECT")
        assert rule.action == "abort_exit", \
            "a retry_step action here would multiply password attempts"
        assert rule.retry_whole_request is True
        assert rule.classification == "system"    # dispatcher may retry
        assert rule.exit_from == "login_screen"

    def test_healthy_login_screen_does_not_match(self):
        healthy = ("AIM2/V04/P200HAAPROC\n所属コード 9902783\n"
                   "担当者コード 1735393\nパスワード")
        assert ErrorCatalog.load(CATALOG_PATH).match(
            healthy, 1.0, screen="finesiii_login") is None

    def test_guard_exits_from_the_login_screen(self):
        from src.core.exceptions import LoginFailedError
        driver = FakeDriver(LOGIN_REJECTED)
        guard = _guard(driver, ErrorCatalog.load(CATALOG_PATH))
        with pytest.raises(LoginFailedError) as excinfo:
            guard.check("login_submitted")
        error = excinfo.value
        assert error.rule_id == "LOGIN_PASSWORD_INCORRECT"
        assert error.exit_from_login is True
        # No keystrokes: nothing to acknowledge, nothing to re-type.
        assert driver.keys == [] and driver.commands == []


class FakeNotifier:
    def __init__(self):
        self.sent = []

    def send(self, subject, body, to=None, context=None,
             template_path=None, redact_body=True, **_kw):
        self.sent.append({"subject": subject, "body": body, "to": to,
                          "context": context or {},
                          "template": template_path})
        return True


def _txn(**kw):
    from types import SimpleNamespace
    base = dict(transaction_id="txn_1", request_id="req_1",
                ticket_id="SCTASK-1", operation="provision",
                affiliation_code="30822", employee_code="1217036",
                source="manual", status="failed", result_code="",
                error_message="FINESIII login rejected", attempt_count=3,
                submitted_at="", started_at="", completed_at="",
                duration_seconds=1.0, worker_id=1, evidence_path="/ev",
                screenshot_count=14, operator="12N3940")
    base.update(kw)
    return SimpleNamespace(**base)


def _alerter(rules, notifier=None, enabled=True, default_to=()):
    from src.modules.notifications.transaction_alerts import (
        ErrorAlertSettings, TransactionAlerter,
        TransactionNotificationSettings,
    )
    settings = TransactionNotificationSettings(
        enabled=True, notify_on_failure=True,
        error_alerts=ErrorAlertSettings(enabled=enabled, rules=rules,
                                        default_to=list(default_to)))
    return TransactionAlerter(notifier or FakeNotifier(), settings,
                              async_send=False), settings


class TestErrorAlertRouting:
    RULES = {"LOGIN_PASSWORD_INCORRECT": {
        "to": ["identity-ops@example.com"],
        "subject": "FINESIII login rejected — service account password",
        "action_required": "Verify the credential in CyberArk."}}

    def _result(self, **kw):
        base = {
            "error_id": "LOGIN_PASSWORD_INCORRECT",
            "failed_step": "login_submitted",
            "error_trace": [{
                "error_id": "LOGIN_PASSWORD_INCORRECT",
                "step": "login_submitted", "screen": "finesiii_login",
                "matched": ["パスワードが誤っています"], "acted": True,
                "captured": {}}],
        }
        base.update(kw)
        return base

    def test_error_routes_to_its_own_team(self):
        notifier = FakeNotifier()
        alerter, _ = _alerter(self.RULES, notifier)
        alerter.handle_completion(_txn(), None, self._result())

        assert len(notifier.sent) == 1, "expected exactly one email"
        mail = notifier.sent[0]
        assert mail["to"] == ["identity-ops@example.com"]
        assert "login rejected" in mail["subject"]
        assert "SCTASK-1" in mail["subject"]
        # Actionable on its own — no audit dive needed.
        assert "LOGIN_PASSWORD_INCORRECT" in mail["body"]
        assert "login_submitted" in mail["body"]
        assert "パスワードが誤っています" in mail["body"]
        assert "Attempts made: 3" in mail["body"]
        assert "Verify the credential in CyberArk." in mail["body"]
        assert mail["template"].endswith("error_screen_alert.html")

    def test_dedicated_alert_replaces_the_generic_failure_notice(self):
        """One email, not two — the routed team gets the detail and ops
        do not get a duplicate."""
        notifier = FakeNotifier()
        alerter, _ = _alerter(self.RULES, notifier)
        alerter.handle_completion(_txn(), None, self._result())
        assert len(notifier.sent) == 1
        assert "Transaction FAILED" not in notifier.sent[0]["subject"]

    def test_unrouted_error_keeps_the_generic_notice(self):
        """Existing behaviour is untouched for errors with no rule."""
        notifier = FakeNotifier()
        alerter, _ = _alerter(self.RULES, notifier)
        alerter.handle_completion(
            _txn(), None, self._result(error_id="SOMETHING_ELSE"))
        assert len(notifier.sent) == 1
        assert "Transaction FAILED" in notifier.sent[0]["subject"]

    def test_disabled_error_alerts_change_nothing(self):
        notifier = FakeNotifier()
        alerter, _ = _alerter(self.RULES, notifier, enabled=False)
        alerter.handle_completion(_txn(), None, self._result())
        assert len(notifier.sent) == 1
        assert "Transaction FAILED" in notifier.sent[0]["subject"]

    def test_default_recipients_when_a_rule_names_none(self):
        notifier = FakeNotifier()
        alerter, _ = _alerter({"CENTER_NOT_READY": {"subject": "Host"}},
                              notifier, default_to=["ops@example.com"])
        alerter.handle_completion(
            _txn(), None, self._result(error_id="CENTER_NOT_READY"))
        assert notifier.sent[0]["to"] == ["ops@example.com"]

    def test_success_never_triggers_an_error_alert(self):
        notifier = FakeNotifier()
        alerter, _ = _alerter(self.RULES, notifier)
        alerter.handle_completion(
            _txn(status="done"), None,
            {"error_id": "", "error_trace": []})
        assert all("login rejected" not in m["subject"]
                   for m in notifier.sent)

    def test_diagnostics_are_quoted_for_the_host_team(self):
        notifier = FakeNotifier()
        alerter, _ = _alerter({"CENTER_NOT_READY": {"to": ["mf@x.com"]}},
                              notifier)
        alerter.handle_completion(_txn(), None, {
            "error_id": "CENTER_NOT_READY",
            "error_trace": [{"error_id": "CENTER_NOT_READY",
                             "step": "finesiii_connect",
                             "screen": "finesiii_login",
                             "matched": ["センター準備中"], "acted": True,
                             "captured": {"diagnostic": "0000 0151",
                                          "subsystem": "NDSUB"}}]})
        body = notifier.sent[0]["body"]
        assert "Diagnostic (diagnostic): 0000 0151" in body
        assert "Diagnostic (subsystem): NDSUB" in body

    def test_shipped_yaml_is_disabled_by_default(self):
        """Zero behaviour change until the client opts in."""
        from src.modules.notifications.transaction_alerts import (
            load_transaction_notification_config,
        )
        settings = load_transaction_notification_config()
        assert settings.error_alerts.enabled is False
        assert settings.error_alerts.rule_for(
            "LOGIN_PASSWORD_INCORRECT") is None
        # …but the routing rules are shipped, ready to switch on.
        assert {"LOGIN_PASSWORD_INCORRECT", "CENTER_NOT_READY"} <= \
            set(settings.error_alerts.rules)


class TestEvidenceSurvivesRetries:
    def test_a_retry_does_not_overwrite_the_previous_attempt(self,
                                                             tmp_path):
        """A retried request reuses its pinned folder. The capture
        counter must RESUME, or attempt 2 overwrites attempt 1's
        evidence whenever both land in the same second."""
        from src.core.evidence import EvidenceCapture

        cfg = {"enabled": True, "output_dir": str(tmp_path),
               "capture_points": [], "format": "png"}

        class Shooter:
            def take_screenshot(self, path):
                from pathlib import Path as P
                P(path).write_bytes(b"x")

        first = EvidenceCapture(cfg, transaction_id="req_1")
        first.capture("login_credentials_entered", Shooter())
        first.capture("login_failed", Shooter())

        second = EvidenceCapture(cfg, transaction_id="req_1")
        second.capture("login_credentials_entered", Shooter())
        second.capture("login_failed", Shooter())

        files = sorted(p.name for p in tmp_path.glob("req_1/*.png"))
        assert len(files) == 4, files
        assert files[0].startswith("001_") and files[3].startswith("004_")
        # Both attempts' password entries survive — the count is what
        # proves how many times the account was actually tried.
        assert len([f for f in files
                    if "login_credentials_entered" in f]) == 2


# ── Cases 3 + 4: operator code not registered ───────────────────────
#
# FINESIII emits ONE message for BOTH root causes. Case 3 = valid staff
# code under the wrong affiliation; Case 4 = valid affiliation (the
# same one that works in Case 2) with a non-existent staff code. The
# screens are textually identical apart from the code VALUES, so one
# rule matches both and the two codes are reported as separate,
# labelled data points for a human to judge.

AFFILIATION_REJECTED = (
    "AIM2/V04/P200HAAPROC\nFUJI INFORMATION NETWORK\n"
    "EXTENSIBLE SYSTEM Ⅲ\n"
    "所属コード 9902784  システムサービス部　火災新種システムチー\n"
    "(終了:99)\n"
    "担当者コード 1735393   オペレーターコード未登録です\n"
    "パスワード\n英字"
)


STAFF_CODE_REJECTED = (
    "AIM2/V04/P200HAAPROC\nFUJI INFORMATION NETWORK\n"
    "EXTENSIBLE SYSTEM Ⅲ\n"
    "所属コード 9902783  サービスデリバリー部　サービスＭＧ１課\n"
    "(終了:99)\n"
    "担当者コード 1735340   オペレーターコード未登録です\n"
    "パスワード\n英字"
)


class TestOperatorNotRegisteredRule:
    def test_case_3_screen_matches(self):
        match = ErrorCatalog.load(CATALOG_PATH).match(
            AFFILIATION_REJECTED, 0.99, screen="finesiii_login")
        assert match.rule.id == "LOGIN_OPERATOR_NOT_REGISTERED"
        assert "オペレーターコード未登録です" in match.matched

    def test_the_two_login_rejections_never_cross_match(self):
        """Case 2 and Case 3 render on the SAME screen and differ only
        in the message — each must select its own rule."""
        catalog = ErrorCatalog.load(CATALOG_PATH)
        assert catalog.match(LOGIN_REJECTED, 0.99,
                             screen="finesiii_login").rule.id == \
            "LOGIN_PASSWORD_INCORRECT"
        assert catalog.match(AFFILIATION_REJECTED, 0.99,
                             screen="finesiii_login").rule.id == \
            "LOGIN_OPERATOR_NOT_REGISTERED"

    def test_message_quotes_the_screen_text(self):
        """The client chose an id that does NOT quote the on-screen
        wording, so the message must — otherwise the audit trail cannot
        be reconciled against the evidence PNG."""
        rule = next(r for r in ErrorCatalog.load(CATALOG_PATH).rules
                    if r.id == "LOGIN_OPERATOR_NOT_REGISTERED")
        assert "オペレーターコード未登録です" in rule.message

    def test_rule_carries_no_retry_loop_of_its_own(self):
        rule = next(r for r in ErrorCatalog.load(CATALOG_PATH).rules
                    if r.id == "LOGIN_OPERATOR_NOT_REGISTERED")
        assert rule.action == "abort_exit"
        # BUG-035: same codes → same rejection; the request is not rerun.
        assert rule.retry_whole_request is False
        assert rule.classification == "system"
        assert rule.exit_from == "login_screen"

    def test_guard_exits_from_the_login_screen(self):
        from src.core.exceptions import LoginFailedError
        driver = FakeDriver(AFFILIATION_REJECTED)
        guard = _guard(driver, ErrorCatalog.load(CATALOG_PATH))
        with pytest.raises(LoginFailedError) as excinfo:
            guard.check("login_submitted")
        assert excinfo.value.rule_id == "LOGIN_OPERATOR_NOT_REGISTERED"
        assert excinfo.value.exit_from_login is True
        assert driver.keys == [] and driver.commands == []

    def test_classifier_agrees_with_the_catalogue(self):
        """The evidence TXT header must not say IN_PROGRESS on a screen
        the catalogue treats as an error."""
        from src.rpa.vision.keywords import PathClassifier, load_rules
        classifier = PathClassifier(load_rules("config/ocr.yaml"), 0.75)
        assert classifier.classify(
            AFFILIATION_REJECTED, 0.99)["path"] == "system_error"
        # …and the upgrade-only rule still holds.
        assert classifier.classify(
            AFFILIATION_REJECTED, 0.40)["path"] != "system_error"

    def test_case_4_selects_the_same_rule(self):
        """Case 4: valid affiliation (9902783 — the one that works in
        Case 2), invalid staff code. Same message, so the same rule."""
        match = ErrorCatalog.load(CATALOG_PATH).match(
            STAFF_CODE_REJECTED, 0.99, screen="finesiii_login")
        assert match.rule.id == "LOGIN_OPERATOR_NOT_REGISTERED"

    def test_both_root_causes_are_indistinguishable_on_screen(self):
        """Documents WHY there is one rule for two causes: strip the
        code values and the two screens are the same text. Any future
        attempt to split them needs a new signal, not a new rule."""
        import re

        def without_codes(text):
            return re.sub(r"\d{6,}", "<code>", text)

        assert without_codes(AFFILIATION_REJECTED).split() != []
        c3 = [l.split("  ")[-1].strip()
              for l in without_codes(AFFILIATION_REJECTED).splitlines()]
        c4 = [l.split("  ")[-1].strip()
              for l in without_codes(STAFF_CODE_REJECTED).splitlines()]
        assert "オペレーターコード未登録です" in c3
        assert "オペレーターコード未登録です" in c4

    def test_rule_name_does_not_blame_either_code(self):
        """Renamed from LOGIN_INVALID_AFFILIATION_CODE once Case 4
        showed the same message with a PROVABLY VALID affiliation code —
        that id would have sent the team to check a correct value."""
        ids = {r.id for r in ErrorCatalog.load(CATALOG_PATH).rules}
        assert "LOGIN_OPERATOR_NOT_REGISTERED" in ids
        assert "LOGIN_INVALID_AFFILIATION_CODE" not in ids

    def test_routing_rule_is_shipped_for_case_3(self):
        from src.modules.notifications.transaction_alerts import (
            load_transaction_notification_config,
        )
        from src.modules.notifications import messages
        rules = load_transaction_notification_config().error_alerts.rules
        assert "LOGIN_OPERATOR_NOT_REGISTERED" in rules
        # The text is in the wording file since 2026-09-29 (Japanese and
        # English); the rule names the team that owns it.
        assert rules["LOGIN_OPERATOR_NOT_REGISTERED"]["audience"] == "accounts"
        action = messages.one("rule.LOGIN_OPERATOR_NOT_REGISTERED.action",
                              "en")
        # The bot cannot tell which code is wrong, so the mail must name
        # every cause and send the team to check BOTH.
        assert "affiliation" in action and "staff code" in action
        assert "CHECK BOTH" in action
        ja = messages.one("rule.LOGIN_OPERATOR_NOT_REGISTERED.action", "ja")
        assert "所属コード" in ja and "担当者コード" in ja


class TestSubmittedCodesAreReported:
    """Client note (2026-08-26): a bad affiliation code and a bad staff
    code show the SAME message, but they are different data points and
    must both reach the team. The bot reports what it SUBMITTED and
    never claims which value is at fault."""

    def _fire(self, screen_text, **context):
        from src.core.exceptions import LoginFailedError
        guard = _guard(FakeDriver(screen_text),
                       ErrorCatalog.load(CATALOG_PATH))
        if context:
            guard.set_context(**context)
        with pytest.raises(LoginFailedError):
            guard.check("login_submitted")
        return guard.trace[0]

    def test_both_codes_ride_along_as_separate_data_points(self):
        entry = self._fire(STAFF_CODE_REJECTED,
                           login_affiliation_code="9902783",
                           login_staff_code="1735340")
        context = entry["context"]
        assert context["login_affiliation_code"] == "9902783"
        assert context["login_staff_code"] == "1735340"

    def test_the_detection_never_names_a_culprit(self):
        """The message may say what the SCREEN said, never which code
        the bot decided was wrong — it cannot know."""
        entry = self._fire(STAFF_CODE_REJECTED,
                           login_affiliation_code="9902783",
                           login_staff_code="1735340")
        assert "オペレーターコード未登録です" in entry["message"]
        assert "check BOTH" in entry["message"]

    def test_context_is_absent_when_nothing_was_set(self):
        entry = self._fire(STAFF_CODE_REJECTED)
        assert "context" not in entry

    def test_navigator_supplies_the_codes_but_never_the_password(self):
        """The wiring that matters: the login checkpoint sets both
        codes, and the password is not among them."""
        import inspect

        import pytest

        from src.rpa.screens import navigator
        if not inspect.isfunction(navigator.Navigator.step_3_login):
            pytest.skip("source inspection is not possible on a natively "
                        "compiled module (packaging/compile.py); the "
                        "behaviour is covered by the context tests above")
        source = inspect.getsource(navigator.Navigator.step_3_login)
        assert "login_affiliation_code=login_affiliation" in source
        assert "login_staff_code=credentials.application_id" in source
        assert "credentials.password" not in source.split(
            "set_context")[1].split(")")[0]

    def test_email_renders_the_codes_as_labelled_data_points(self):
        notifier = FakeNotifier()
        alerter, _ = _alerter(
            {"LOGIN_OPERATOR_NOT_REGISTERED": {"to": ["id-ops@x.com"]}},
            notifier)
        alerter.handle_completion(_txn(), None, {
            "error_id": "LOGIN_OPERATOR_NOT_REGISTERED",
            "error_trace": [{
                "error_id": "LOGIN_OPERATOR_NOT_REGISTERED",
                "step": "login_submitted", "screen": "finesiii_login",
                "matched": ["オペレーターコード未登録です"], "acted": True,
                "context": {"login_affiliation_code": "9902783",
                            "login_staff_code": "1735340"}}]})
        body = notifier.sent[0]["body"]
        assert "Submitted by the bot (check each):" in body
        assert "Login affiliation code" in body and "9902783" in body
        assert "Login staff code" in body and "1735340" in body


class TestLoginErrorScenarioParity:
    """Every login-rejection scenario the drivers can produce must be
    matched by a catalogue rule — a scenario with no rule would look
    like a silent hang in QA."""

    @pytest.mark.parametrize("driver_module", [
        "src.rpa.drivers.mock", "src.rpa.drivers.sim_terminal"])
    def test_every_driver_login_error_has_a_rule(self, driver_module):
        import importlib
        from src.rpa.vision.keywords import normalize_text
        module = importlib.import_module(driver_module)
        catalog = ErrorCatalog.load(CATALOG_PATH)
        assert module.LOGIN_ERRORS, "driver defines no login errors"
        for scenario, message in module.LOGIN_ERRORS.items():
            screen = ("AIM2/V04/P200HAAPROC\n所属コード\n担当者コード\n"
                      f"パスワード\n{message}")
            match = catalog.match(screen, 0.99, screen="finesiii_login")
            assert match is not None, \
                f"scenario '{scenario}' has no catalogue rule"
            assert normalize_text(message) in normalize_text(
                " ".join(match.matched))

    def test_both_drivers_expose_the_same_scenarios(self):
        from src.rpa.drivers import mock, sim_terminal
        assert mock.LOGIN_ERRORS == sim_terminal.LOGIN_ERRORS

    def test_scenarios_are_reachable_through_the_api(self):
        """metadata.sim_scenario must accept every one of them, or QA
        cannot drive the case per request."""
        from src.rpa.drivers import mock
        from src.rpa.executor import TerminalExecutor
        assert set(mock.LOGIN_ERRORS) <= set(TerminalExecutor._SCENARIOS)
