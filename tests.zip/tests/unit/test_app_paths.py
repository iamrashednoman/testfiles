"""Path resolution — source behaviour must be byte-for-byte unchanged.

The whole point of Phase 1 is that a frozen desktop bundle stops
relying on the working directory, WITHOUT altering how `python run.py`,
Docker, or pytest resolve anything. These tests pin both halves.
"""
import os
import sys
from pathlib import Path

import pytest

from src.core import app_paths


REPO_ROOT = Path(__file__).resolve().parents[2]


@pytest.fixture
def unfrozen(monkeypatch):
    monkeypatch.delenv("FINESIII_DATA_DIR", raising=False)
    monkeypatch.setattr(sys, "frozen", False, raising=False)
    if hasattr(sys, "frozen"):
        monkeypatch.delattr(sys, "frozen", raising=False)
    return app_paths


class TestSourceBehaviourUnchanged:
    def test_not_frozen_by_default(self, unfrozen):
        assert app_paths.is_frozen() is False

    def test_resources_are_the_repo_root(self, unfrozen):
        assert app_paths.resource_root() == REPO_ROOT

    def test_data_root_is_the_working_directory(self, unfrozen):
        """Every relative default resolved against the CWD before this
        module existed — that must not change."""
        assert app_paths.data_root() == Path.cwd()

    def test_config_root_is_the_repo_config_dir(self, unfrozen):
        assert app_paths.config_root() == REPO_ROOT / "config"

    def test_relative_data_path_matches_the_old_meaning(self, unfrozen):
        assert app_paths.resolve("evidence") == str(Path.cwd() / "evidence")

    def test_shipped_config_files_resolve_to_real_files(self, unfrozen):
        for name in ("errors.yaml", "ocr.yaml", "notifications.yaml"):
            assert Path(app_paths.config_path(name)).is_file(), name


class TestResolution:
    def test_absolute_values_win(self, unfrozen):
        """An explicit path from the environment is never re-anchored."""
        assert app_paths.resolve("/etc/finesiii/errors.yaml",
                                 kind="config") == "/etc/finesiii/errors.yaml"

    def test_config_prefix_is_not_doubled(self, unfrozen):
        """Both the historical form and a bare filename land in the
        config root — never config/config/errors.yaml."""
        prefixed = app_paths.resolve("config/errors.yaml", kind="config")
        bare = app_paths.resolve("errors.yaml", kind="config")
        assert prefixed == bare
        assert "config/config" not in prefixed
        assert Path(prefixed).is_file()

    def test_kinds_use_different_roots(self, unfrozen):
        assert app_paths.resolve("x", kind="resource") != \
            app_paths.resolve("x", kind="config")

    def test_empty_value_passes_through(self, unfrozen):
        assert app_paths.resolve("") == ""

    def test_data_dir_env_override(self, monkeypatch, tmp_path):
        monkeypatch.setenv("FINESIII_DATA_DIR", str(tmp_path))
        assert app_paths.data_root() == tmp_path.resolve()
        assert app_paths.resolve("evidence") == str(tmp_path / "evidence")


class TestFrozenBehaviour:
    """Simulate a bundle without building one."""

    @pytest.fixture
    def frozen(self, monkeypatch, tmp_path):
        bundle, data = tmp_path / "bundle", tmp_path / "data"
        (bundle / "config").mkdir(parents=True)
        for name in app_paths.SEED_CONFIGS:
            # e-mail templates sit in a subfolder (2026-09-28)
            (bundle / "config" / name).parent.mkdir(parents=True, exist_ok=True)
            (bundle / "config" / name).write_text(f"# {name}\n")
        monkeypatch.setattr(sys, "frozen", True, raising=False)
        monkeypatch.setattr(sys, "_MEIPASS", str(bundle), raising=False)
        monkeypatch.setenv("FINESIII_DATA_DIR", str(data))
        return bundle, data

    def test_resources_come_from_the_bundle(self, frozen):
        bundle, _ = frozen
        assert app_paths.resource_root() == bundle
        assert app_paths.resource_path("config", "errors.yaml").is_file()

    def test_data_never_lands_inside_the_bundle(self, frozen):
        """_MEIPASS is deleted on exit — writing evidence there loses
        it. This is the defect Phase 1 exists to prevent."""
        bundle, data = frozen
        for field in ("evidence", "logs", "finesiii_v3.db",
                      "audit_spool.db"):
            resolved = Path(app_paths.resolve(field))
            assert data in resolved.parents or resolved.parent == data
            assert bundle not in resolved.parents

    def test_config_reads_from_the_seeded_data_dir(self, frozen):
        _, data = frozen
        app_paths.bootstrap_data_dir()
        assert app_paths.config_root() == data / "config"
        assert Path(app_paths.resolve("config/errors.yaml",
                                      kind="config")).is_file()

    def test_bootstrap_seeds_every_editable_config(self, frozen):
        _, data = frozen
        app_paths.bootstrap_data_dir()
        for name in app_paths.SEED_CONFIGS:
            assert (data / "config" / name).is_file(), name

    def test_bootstrap_never_clobbers_operator_edits(self, frozen):
        """An upgrade re-runs the seed; a hand-edited rule set must
        survive it."""
        _, data = frozen
        app_paths.bootstrap_data_dir()
        edited = data / "config" / "errors.yaml"
        edited.write_text("# OPERATOR EDIT\n")
        app_paths.bootstrap_data_dir()
        assert edited.read_text() == "# OPERATOR EDIT\n"

    def test_bootstrap_is_idempotent(self, frozen):
        first = app_paths.bootstrap_data_dir()
        assert app_paths.bootstrap_data_dir() == first


class TestConfigWiring:
    def test_every_path_setting_is_absolute(self):
        """The nine settings that used to be CWD-relative."""
        from config import get_config
        cfg = get_config()
        for field in ("sqlite_path", "evidence_dir", "log_dir",
                      "audit_spool_path", "audit_sqlite_path",
                      "error_catalog_path", "ocr_keywords_path",
                      "ocr_model_dir"):
            value = getattr(cfg, field)
            assert Path(value).is_absolute(), f"{field} is still relative"

    def test_config_files_actually_exist_where_resolved(self):
        from config import get_config
        cfg = get_config()
        assert Path(cfg.error_catalog_path).is_file()
        assert Path(cfg.ocr_keywords_path).is_file()

    def test_env_override_is_respected(self, monkeypatch):
        monkeypatch.setenv("EVIDENCE_DIR", "/custom/evidence")
        from config.base import BaseConfig
        assert BaseConfig().evidence_dir == "/custom/evidence"


class TestSimWorkerCommand:
    def test_source_uses_module_invocation(self, monkeypatch):
        from src.rpa.drivers import sim_launcher
        monkeypatch.setattr(sim_launcher, "is_frozen", lambda: False)
        cmd = sim_launcher._worker_command("req.json", "res.json")
        assert cmd[1:] == ["-m", "src.rpa.sim_terminal_app",
                           "req.json", "res.json"]

    def test_frozen_re_invokes_the_app_itself(self, monkeypatch):
        """`-m` does not exist in a bundle and sys.executable IS the
        app, so the worker must be started through the re-entry flag."""
        from src.rpa.drivers import sim_launcher
        monkeypatch.setattr(sim_launcher, "is_frozen", lambda: True)
        cmd = sim_launcher._worker_command("req.json", "res.json")
        assert "-m" not in cmd
        assert cmd[1] == sim_launcher.SIM_WORKER_ARG
        assert cmd[0] == sys.executable

    def test_entry_point_dispatches_the_marker(self):
        from desktop.app import SIM_WORKER_ARG
        from src.rpa.drivers.sim_launcher import (
            SIM_WORKER_ARG as launcher_arg,
        )
        assert SIM_WORKER_ARG == launcher_arg
