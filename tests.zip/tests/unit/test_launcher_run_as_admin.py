"""The FINESIII launcher shortcut opens as administrator by default
(right-click > Run as administrator), with a switch back to a plain open."""
import os

import pytest

from src.core.exceptions import ApplicationLaunchError
from src.rpa.config import build_rpa_config
from src.rpa.drivers.pywinauto_driver import PywinautoDriver


@pytest.fixture
def started(monkeypatch):
    calls = []

    def fake_startfile(path, *verb):
        calls.append((path, verb))

    # os.startfile exists on Windows only.
    monkeypatch.setattr(os, "startfile", fake_startfile, raising=False)
    return calls


def _driver(tmp_path, **application):
    shortcut = tmp_path / "オンライン業務.lnk"
    shortcut.write_text("")
    driver = PywinautoDriver()
    driver.config = {"shortcut_path": str(shortcut), **application}
    return driver, str(shortcut)


def test_shortcut_opens_as_administrator_by_default(tmp_path, started):
    driver, shortcut = _driver(tmp_path)
    driver._launch_via_shortcut("オンライン業務")
    assert started == [(shortcut, ("runas",))]


def test_run_as_admin_false_opens_normally(tmp_path, started):
    driver, shortcut = _driver(tmp_path, run_as_admin=False)
    driver._launch_via_shortcut("オンライン業務")
    assert started == [(shortcut, ())]


def test_refused_elevation_names_the_cause(tmp_path, monkeypatch):
    def refused(path, *verb):
        raise OSError("The operation was canceled by the user")

    monkeypatch.setattr(os, "startfile", refused, raising=False)
    driver, _ = _driver(tmp_path)
    with pytest.raises(ApplicationLaunchError, match="as administrator"):
        driver._launch_via_shortcut("オンライン業務")


def test_shipped_layout_turns_it_on(tmp_path):
    cfg = build_rpa_config(driver="pywinauto", environment="production",
                           evidence_dir=str(tmp_path))
    assert cfg["application"]["run_as_admin"] is True
