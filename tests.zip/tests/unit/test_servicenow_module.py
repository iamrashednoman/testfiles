"""ServiceNow module review fixes (2026-09-26).

Pins, per approved item:
  OAuth       password and client-credentials grants against oauth_token.do,
              token caching, refresh before expiry, one re-auth on 401,
              validation per type.
  Paging      every page is read (not the first max_per_poll rows); the
              cap applies to NEW submissions ("deferred" counts the rest).
  Duplicates  business-key duplicate blocked + rejection alert + audit +
              work note; requester/description match flagged only; queue
              lookups; field comparison ignores bookkeeping fields.
  Close-out   done → state + comment, already_deleted → review note,
              failed → failure note, templates rendered, retries then
              ERROR log + audit; non-ServiceNow requests ignored.
  Poller      wakes on demand, restarts when dead, persists the last poll,
              alerts after N consecutive failures and on recovery.
  Query       empty open states = active tickets only.
"""
import json
import threading
import time

import httpx
import pytest

from src.integrations.servicenow.client import ServiceNowClient, ServiceNowError
from src.integrations.servicenow.config import ServiceNowSettings
from src.integrations.servicenow.connector import ServiceNowConnector
from src.integrations.servicenow import duplicates
from tests.conftest import make_config

MAPPING = {"ticket_number": "number", "operation": "u_op",
           "affiliation_code": "u_aff", "employee_code": "u_emp",
           "user_email": "u_email"}


def settings(**kw):
    # Bot-account mode: the tickets are assigned to the bot account.
    base = dict(instance_url="https://dev.service-now.com", username="bot",
                assigned_to="bot",
                password="pw", table="sc_task", field_mapping=MAPPING,
                respect_service_health=False, max_retries=1,
                backoff_base_seconds=0.001, backoff_max_seconds=0.001)
    base.update(kw)
    return ServiceNowSettings(**base)


def ticket(n, emp="1217036", aff="30822", op="provision", **extra):
    t = {"sys_id": f"sid-{n}", "number": f"SCTASK{n:04d}", "u_op": op,
         "u_aff": aff, "u_emp": emp, "state": "1", "active": "true",
         "sys_created_on": f"2026-09-26 10:00:{n:02d}"}
    t.update(extra)
    return t


# ── OAuth ─────────────────────────────────────────────────────────

class _Instance:
    """MockTransport handler: a tiny ServiceNow with an OAuth endpoint."""

    def __init__(self, expires_in=1800, revoke_first=False):
        self.tokens = []
        self.issued = 0
        self.grants = []
        self.api_calls = []
        self.expires_in = expires_in
        self.revoke_first = revoke_first

    def __call__(self, request: httpx.Request) -> httpx.Response:
        if request.url.path == "/oauth_token.do":
            form = dict(p.split("=", 1) for p in request.content.decode().split("&"))
            self.grants.append(form)
            if not (form.get("client_id") and form.get("client_secret")):
                return httpx.Response(401, json={"error": "invalid_client"})
            if form["grant_type"] == "password" and not form.get("password"):
                return httpx.Response(400, json={"error": "invalid_grant"})
            self.issued += 1
            tok = f"tok{self.issued}"
            self.tokens.append(tok)
            return httpx.Response(200, json={
                "access_token": tok, "refresh_token": f"ref-{tok}",
                "expires_in": self.expires_in, "token_type": "Bearer"})
        auth = request.headers.get("authorization", "")
        self.api_calls.append(auth)
        if not auth.startswith("Bearer ") or auth[7:] not in self.tokens:
            return httpx.Response(401, json={"error": "User Not Authenticated"})
        if self.revoke_first and auth[7:] == "tok1":
            self.revoke_first = False
            self.tokens.remove("tok1")
            return httpx.Response(401, json={"error": "token revoked"})
        return httpx.Response(200, json={"result": [ticket(1)]})


class TestOAuth:
    def test_password_grant_then_bearer_and_cached(self):
        inst = _Instance()
        c = ServiceNowClient(settings(auth_method="oauth_password",
                                      client_id="cid", client_secret="sec"),
                             transport=httpx.MockTransport(inst),
                             sleep_func=lambda d: None)
        c.fetch_assigned_open()
        c.fetch_assigned_open()
        assert len(inst.grants) == 1                     # token cached
        assert inst.grants[0]["grant_type"] == "password"
        assert inst.grants[0]["username"] == "bot"
        assert inst.api_calls == ["Bearer tok1"] * 2

    def test_client_credentials_grant_has_no_user(self):
        inst = _Instance()
        c = ServiceNowClient(settings(auth_method="oauth_client_credentials",
                                      client_id="cid", client_secret="sec",
                                      username="", password=""),
                             transport=httpx.MockTransport(inst),
                             sleep_func=lambda d: None)
        c.fetch_assigned_open()
        assert inst.grants[0]["grant_type"] == "client_credentials"
        assert "username" not in inst.grants[0]

    def test_refresh_before_expiry_uses_refresh_token(self):
        inst = _Instance(expires_in=100)
        c = ServiceNowClient(settings(auth_method="oauth_password",
                                      client_id="cid", client_secret="sec"),
                             transport=httpx.MockTransport(inst),
                             sleep_func=lambda d: None)
        now = [1000.0]
        c._clock = lambda: now[0]
        c.fetch_assigned_open()
        now[0] += 50                                     # within the margin
        c.fetch_assigned_open()
        assert len(inst.grants) == 2
        assert inst.grants[1]["grant_type"] == "refresh_token"
        assert inst.grants[1]["refresh_token"] == "ref-tok1"

    def test_401_with_bearer_reauthenticates_once(self):
        inst = _Instance(revoke_first=True)
        c = ServiceNowClient(settings(auth_method="oauth_password",
                                      client_id="cid", client_secret="sec"),
                             transport=httpx.MockTransport(inst),
                             sleep_func=lambda d: None)
        out = c.fetch_assigned_open()
        assert out and len(inst.grants) == 2
        assert inst.api_calls[-1] == "Bearer tok2"

    def test_token_refusal_is_a_clear_error(self):
        inst = _Instance()
        c = ServiceNowClient(settings(auth_method="oauth_password",
                                      client_id="cid", client_secret="",
                                      max_retries=0),
                             transport=httpx.MockTransport(inst),
                             sleep_func=lambda d: None)
        with pytest.raises(ServiceNowError, match="OAuth token request failed"):
            c.fetch_assigned_open()

    def test_basic_never_calls_the_token_endpoint(self):
        inst = _Instance()

        def handler(request):
            if request.url.path == "/oauth_token.do":
                raise AssertionError("token endpoint used with basic auth")
            assert request.headers["authorization"].startswith("Basic ")
            return httpx.Response(200, json={"result": []})
        c = ServiceNowClient(settings(), transport=httpx.MockTransport(handler),
                             sleep_func=lambda d: None)
        assert c.fetch_assigned_open() == []

    def test_validation_per_type(self):
        s = settings(auth_method="oauth_password", client_id="c", client_secret="s")
        s.validate()
        s = settings(auth_method="oauth_password", client_id="c", client_secret="s",
                     password="")
        with pytest.raises(ValueError, match="SNOW_USERNAME / SNOW_PASSWORD"):
            s.validate()
        # Client credentials without a Bot account: valid - the filters
        # are optional - but no account to assign tickets to.
        s = settings(auth_method="oauth_client_credentials", client_id="c",
                     client_secret="s", username="", password="",
                     assigned_to="")
        s.validate()
        assert s.effective_assigned_to == ""
        s.assigned_to = "svc_bot"
        s.validate()
        assert s.effective_assigned_to == "svc_bot"
        assert settings(auth_method="oauth").oauth_grant == "password"
        with pytest.raises(ValueError, match="unknown auth_method"):
            settings(auth_method="saml").validate()

    def test_env_loader_reads_new_keys(self, monkeypatch):
        from src.integrations.servicenow.config import load_servicenow_config
        monkeypatch.setenv("SNOW_AUTH_METHOD", "OAuth_Client_Credentials")
        monkeypatch.setenv("SNOW_TOKEN_URL", "https://sso.example/token/")
        monkeypatch.setenv("SNOW_OPEN_STATES", "1, 2")
        monkeypatch.setenv("SNOW_DUPLICATE_WINDOW_DAYS", "7")
        monkeypatch.setenv("SNOW_CLOSE_ON_SUCCESS", "false")
        monkeypatch.setenv("SNOW_FAILURE_NOTE", "Failed: {error}")
        s = load_servicenow_config()
        assert s.auth_method == "oauth_client_credentials"
        assert s.effective_token_url == "https://sso.example/token"
        assert s.open_states == ["1", "2"]
        assert s.duplicate_window_days == 7
        assert s.close_on_success is False and s.failure_note == "Failed: {error}"
        monkeypatch.setenv("SNOW_OPEN_STATES", "")
        assert load_servicenow_config().open_states == []


class TestQuery:
    def test_empty_open_states_means_active_only(self):
        q = settings(open_states=[]).build_query()
        assert "stateIN" not in q and "active=true" in q
        assert "stateIN1,2" in settings(open_states=["1", "2"]).build_query()


# ── Paging and the submission cap ─────────────────────────────────

class TestPaging:
    def test_all_pages_are_read_and_new_tickets_behind_known_ones_are_found(self):
        tickets = [ticket(i, emp=str(1000 + i)) for i in range(1, 61)]
        pages = []

        def handler(request):
            offset = int(request.url.params["sysparm_offset"])
            limit = int(request.url.params["sysparm_limit"])
            assert request.url.params["sysparm_no_count"] == "true"
            pages.append(offset)
            return httpx.Response(200, json={"result": tickets[offset:offset + limit]})

        s = settings(max_per_poll=25)
        c = ServiceNowClient(s, transport=httpx.MockTransport(handler),
                             sleep_func=lambda d: None)
        c.PAGE_SIZE = 20
        out = c.fetch_assigned_open()
        # A full last page is followed by one empty read, as ServiceNow
        # gives no other end-of-list signal without a count.
        assert len(out) == 60 and pages == [0, 20, 40, 60]

        con = ServiceNowConnector(s, client=c)
        submitted = []
        con._submit = lambda p: submitted.append(p["ticket_id"]) or "queued"
        # The first 30 are already known (processed, still open in SNOW).
        con.known_ticket = lambda n: int(n[6:]) <= 30
        stats = con.poll_once()
        assert stats["known"] == 30
        assert stats["submitted"] == 25 and stats["deferred"] == 5
        assert submitted[0] == "SCTASK0031" and submitted[-1] == "SCTASK0055"

    def test_fetch_ceiling_bounds_the_read(self):
        def handler(request):
            offset = int(request.url.params["sysparm_offset"])
            limit = int(request.url.params["sysparm_limit"])
            return httpx.Response(200, json={
                "result": [ticket(offset + i) for i in range(limit)]})
        c = ServiceNowClient(settings(fetch_ceiling=50),
                             transport=httpx.MockTransport(handler),
                             sleep_func=lambda d: None)
        assert len(c.fetch_assigned_open()) == 50


# ── Duplicates ────────────────────────────────────────────────────

class _Client:
    def __init__(self, tickets):
        self.tickets, self.notes = tickets, []

    def fetch_assigned_open(self):
        return list(self.tickets)

    def add_work_note(self, sys_id, note, table=""):
        self.notes.append((sys_id, note))


class TestDuplicateHelpers:
    def test_business_key_normalises_affiliation(self):
        assert duplicates.business_key(
            {"operation": "Provision", "affiliation_code": "822",
             "employee_code": " 1217036 "}) == ("provision", "00822", "1217036")

    def test_matched_fields_ignore_bookkeeping_and_empty(self):
        a = ticket(1, u_email="a@x", short_description="Create user")
        b = ticket(2, u_email="a@x", short_description="Create user", u_extra="")
        m = duplicates.matched_fields(a, b)
        assert "u_email" in m and "short_description" in m and "u_op" in m
        assert "sys_id" not in m and "number" not in m and "u_extra" not in m
        assert duplicates.matched_fields(None, b) == []

    def test_possible_duplicate_needs_requester_and_description(self):
        a = ticket(1, u_email="a@x", description="Please create access")
        b = ticket(2, emp="999", u_email="a@x", description="please  create access")
        assert duplicates.is_possible_duplicate(a, b, "u_email")
        c = ticket(3, emp="999", u_email="b@x", description="Please create access")
        assert not duplicates.is_possible_duplicate(a, c, "u_email")
        assert not duplicates.is_possible_duplicate(a, ticket(4, u_email="a@x"), "u_email")


class TestConnectorDuplicates:
    def _connector(self, tickets, **kw):
        s = settings(writeback_enabled=True,
                     writeback={"on_duplicate": {"add_work_note":
                                "Duplicate of {original_ticket_id} ({ticket_id})"}},
                     **kw)
        client = _Client(tickets)
        rejected, audited = [], []
        c = ServiceNowConnector(s, client=client,
                                on_rejected=lambda t, r, d: rejected.append((t, r, d)))
        c.audit_hook = lambda e, d: audited.append((e, d))
        submitted = []
        c._submit = lambda p: submitted.append(p) or "queued"
        return c, client, rejected, audited, submitted

    def test_content_duplicate_is_skipped_alerted_audited_and_noted(self):
        c, client, rejected, audited, submitted = self._connector([ticket(2)])
        c.duplicate_of = lambda payload, t: {
            "request_id": "r-1", "ticket_id": "SCTASK0001", "status": "done",
            "matched_fields": ["u_aff", "u_emp", "u_op"]}
        stats = c.poll_once()
        assert stats["duplicate_content"] == 1 and submitted == []
        assert rejected[0][0] == "DUPLICATE REQUEST"
        assert "SCTASK0001" in rejected[0][1]
        assert rejected[0][2]["matching_fields"] == "u_aff, u_emp, u_op"
        assert audited[0][0] == "servicenow_duplicate_ticket"
        assert audited[0][1]["original_request_id"] == "r-1"
        assert client.notes == [("sid-2", "Duplicate of SCTASK0001 (SCTASK0002)")]

    def test_possible_duplicate_is_queued_but_flagged(self):
        c, client, rejected, audited, submitted = self._connector([ticket(2)])
        c.possible_duplicate_of = lambda payload, t: {
            "request_id": "r-1", "ticket_id": "SCTASK0001", "status": "done",
            "matched_fields": ["description"]}
        stats = c.poll_once()
        assert stats["possible_duplicate"] == 1 and stats["submitted"] == 1
        assert rejected == [] and client.notes == []
        assert audited[0][0] == "servicenow_possible_duplicate"
        assert submitted[0]["metadata"]["possible_duplicate_of"]["ticket_id"] == "SCTASK0001"

    def test_hook_failure_never_stops_the_poll(self):
        c, client, rejected, audited, submitted = self._connector([ticket(2)])

        def boom(p, t):
            raise RuntimeError("db")
        c.duplicate_of = boom
        assert c.poll_once()["submitted"] == 1


class TestQueueContentLookup:
    def test_find_content_duplicate_and_recent_by_source(self, tmp_path):
        from src.core.db import Database
        from src.modules.intake.models import ProcessingRequest
        from src.modules.queue.services import QueueStore
        db = Database.from_config(make_config(tmp_path))
        try:
            q = QueueStore(db)
            r = ProcessingRequest(operation="provision", affiliation_code="30822",
                                  employee_code="1217036", ticket_id="SCTASK1",
                                  source="servicenow",
                                  metadata={"snow_details": {"u_email": "a@x"}})
            assert q.enqueue(r)
            hit = q.find_content_duplicate("provision", "30822", "1217036",
                                           exclude_ticket_id="SCTASK2")
            assert hit is not None and hit.ticket_id == "SCTASK1"
            # Same ticket number is not a CONTENT duplicate of itself.
            assert q.find_content_duplicate("provision", "30822", "1217036",
                                            exclude_ticket_id="SCTASK1") is None
            # Different operation / employee → no match; short affiliation
            # matches through zero-padding.
            assert q.find_content_duplicate("deprovision", "30822", "1217036") is None
            assert q.find_content_duplicate("provision", "30822", "999") is None
            assert q.find_content_duplicate("provision", "30822", "1217036") is not None
            # Outside the window → no match.
            assert q.find_content_duplicate("provision", "30822", "1217036",
                                            since="2999-01-01") is None
            # Failed requests never block.
            q.dequeue_oldest(worker_id=1)
            q.mark_complete(r.request_id, "failed", error="x")
            assert q.find_content_duplicate("provision", "30822", "1217036") is None
            recent = q.list_recent_by_source("servicenow")
            assert [x.ticket_id for x in recent] == ["SCTASK1"]
            assert recent[0].metadata["snow_details"]["u_email"] == "a@x"
            assert q.list_recent_by_source("cli") == []
        finally:
            db.close()


# ── Ticket close-out ──────────────────────────────────────────────

class _Txn:
    def __init__(self, status, operation="provision", **kw):
        self.status = status
        self.operation = operation
        self.ticket_id = kw.get("ticket_id", "SCTASK0007")
        self.request_id = "req-7"
        self.affiliation_code = "30822"
        self.employee_code = "1217036"
        self.result_code = kw.get("result_code", "OK")
        self.completed_at = "2026-09-26T12:00:00+09:00"
        self.attempt_count = kw.get("attempt_count", 3)
        self.error_message = kw.get("error", "")


class _Req:
    source = "servicenow"

    def __init__(self, sys_id="abc123", source="servicenow"):
        self.source = source
        self.metadata = {"snow_details": {"sys_id": sys_id, "number": "SCTASK0007"}}


class _WBClient:
    def __init__(self, fail_times=0, owned=True):
        self.calls, self.fail_times = [], fail_times
        self.owned, self.lookups = owned, []

    def get_records(self, table, query="", fields=None, limit=10):
        # The ownership check made before any write (SN-02).
        self.lookups.append((table, query))
        return [{"sys_id": "abc123", "number": "SCTASK0007"}] if self.owned else []

    def _maybe_fail(self):
        if self.fail_times:
            self.fail_times -= 1
            raise ServiceNowError("503 busy")

    def set_state(self, sys_id, state, note=None, table="", extra=None):
        self._maybe_fail()
        self.calls.append(("state", sys_id, state, note))

    def add_work_note(self, sys_id, note, table=""):
        self._maybe_fail()
        self.calls.append(("note", sys_id, note))


class _Audit:
    def __init__(self):
        self.events = []

    def event(self, category, action, severity="INFO", detail=None, **fields):
        self.events.append((category, action, severity, fields, detail))


class _Log:
    def __init__(self):
        self.lines = []

    def __getattr__(self, level):
        return lambda msg: self.lines.append((level, msg))


class TestTicketCloseout:
    def _closeout(self, client, **overrides):
        from src.integrations.servicenow.writeback import TicketCloseout
        s = settings(**overrides)
        audit, log = _Audit(), _Log()
        co = TicketCloseout(logger=log, audit=audit, settings_loader=lambda: s,
                            client_factory=lambda st: client, async_send=False,
                            sleep_func=lambda d: None)
        return co, audit, log

    def test_done_closes_with_state_and_rendered_comment(self):
        client = _WBClient()
        co, audit, _ = self._closeout(
            client, close_state="3",
            close_comment_provision="Done for {employee_code} on {completed_at} ({request_id})")
        co.handle_completion(_Txn("done"), _Req(), {})
        assert client.calls == [("state", "abc123", "3",
                                 "Done for 1217036 on 2026-09-26 12:00:00 JST (req-7)")]
        assert audit.events[0][1] == "servicenow_ticket_updated"
        assert audit.events[0][3]["ticket_id"] == "SCTASK0007"

    def test_deprovision_uses_its_own_template_and_default_when_blank(self):
        client = _WBClient()
        co, _, _ = self._closeout(client, close_comment_deprovision="")
        co.handle_completion(_Txn("done", operation="deprovision"), _Req(), {})
        assert "Deprovisioning completed" in client.calls[0][3]

    def test_already_deleted_keeps_ticket_open_with_review_note(self):
        client = _WBClient()
        co, _, _ = self._closeout(client, review_note="Human review required: {employee_code}")
        co.handle_completion(_Txn("already_deleted", operation="deprovision"), _Req(), {})
        assert client.calls == [("note", "abc123", "Human review required: 1217036")]

    def test_failed_adds_failure_note_with_attempts_and_error(self):
        client = _WBClient()
        co, _, _ = self._closeout(client, failure_note="Failed after {attempts}: {error}")
        co.handle_completion(_Txn("failed", error="centre not ready"), _Req(), {})
        assert client.calls == [("note", "abc123", "Failed after 3: centre not ready")]

    def test_switches_off(self):
        client = _WBClient()
        co, _, _ = self._closeout(client, close_on_success=False,
                                  review_note_enabled=False,
                                  failure_note_enabled=False)
        for st in ("done", "already_deleted", "failed"):
            co.handle_completion(_Txn(st), _Req(), {})
        assert client.calls == []

    def test_non_servicenow_or_no_sys_id_is_ignored(self):
        client = _WBClient()
        co, _, _ = self._closeout(client)
        co.handle_completion(_Txn("done"), _Req(source="cli"), {})
        r = _Req(); r.metadata = {}
        co.handle_completion(_Txn("done"), r, {})
        assert client.calls == []

    def test_retries_then_error_log_and_audit(self):
        client = _WBClient(fail_times=2)
        co, audit, log = self._closeout(client)
        co.handle_completion(_Txn("done"), _Req(), {})
        assert len(client.calls) == 1                     # third attempt won
        assert audit.events[-1][1] == "servicenow_ticket_updated"
        client = _WBClient(fail_times=10)
        co, audit, log = self._closeout(client)
        co.handle_completion(_Txn("done"), _Req(), {})
        assert client.calls == []
        assert audit.events[-1][1] == "servicenow_ticket_update_failed"
        assert any(lvl == "error" and "SCTASK0007" in m for lvl, m in log.lines)

    def test_unconfigured_instance_is_skipped_quietly(self):
        client = _WBClient()
        co, audit, log = self._closeout(client, instance_url="")
        co.handle_completion(_Txn("done"), _Req(), {})
        assert client.calls == [] and audit.events == []

    def test_render_leaves_unknown_placeholders_blank(self):
        from src.integrations.servicenow.writeback import render
        assert render("a {ticket_id} b {nope} c", {"ticket_id": "T"}) == "a T b  c"
        # A template that cannot be rendered never posts raw braces.
        assert render("bad {", {}) == "bad "
        assert render("bad {", {"x": 1}, fallback="ok {x}") == "ok 1"

    def test_app_factory_wires_the_hook(self, tmp_path):
        from src import create_app
        cfg = make_config(tmp_path, dispatcher_enabled=False, terminal_driver="mock",
                          log_dir=str(tmp_path / "logs"))
        app = create_app(cfg)
        assert app.state.ticket_closeout is not None
        assert app.state.ticket_closeout.handle_completion in app.state.completion_hooks


# ── Poller ────────────────────────────────────────────────────────

class TestPoller:
    def _app(self, tmp_path):
        from src import create_app
        cfg = make_config(tmp_path, dispatcher_enabled=False, terminal_driver="mock",
                          log_dir=str(tmp_path / "logs"))
        return create_app(cfg)

    def test_wake_restart_persist_and_alert(self, tmp_path, monkeypatch):
        from desktop.snow_poller import ServiceNowPoller
        monkeypatch.setenv("FINESIII_DATA_DIR", str(tmp_path / "data"))
        (tmp_path / "data").mkdir()
        app = self._app(tmp_path)
        downs, ups = [], []

        class Alerter:
            def component_down(self, component, reason):
                downs.append((component, reason))

            def component_recovered(self, component):
                ups.append(component)
        app.state.availability_alerter = Alerter()
        poller = ServiceNowPoller(app, "http://127.0.0.1:1")
        poller.DISABLED_CHECK_SECONDS = 30      # would sleep long when off…
        poller.ERROR_BACKOFF_SECONDS = 30       # …and after an error
        poller.FAILURE_ALERT_THRESHOLD = 2
        monkeypatch.setenv("SNOW_ENABLED", "false")

        def unreachable(read_only=False):
            raise RuntimeError("Network error after 1 attempts: refused")
        # ServiceNow not answering (a configuration problem on this
        # machine is no longer an outage, UAT-10).
        monkeypatch.setattr(poller, "_build_connector", unreachable)
        poller.start()
        try:
            time.sleep(0.1)
            assert poller.status()["polls"] == 0
            # Turn on (unreachable → every poll fails) and WAKE: no wait
            # for the 30 s disabled check.
            app.state.settings_store.set("SNOW_ENABLED", "true")
            poller.poll_now()
            deadline = time.time() + 5
            while time.time() < deadline and poller.status()["polls"] < 1:
                time.sleep(0.02)
            assert poller.status()["polls"] == 1
            poller.poll_now()                     # second failure → alert
            while time.time() < deadline and poller.status()["polls"] < 2:
                time.sleep(0.02)
            assert poller.status()["consecutive_errors"] == 2
            assert downs and downs[0][0] == "ServiceNow Polling"
            # Persisted for the next start.
            saved = json.loads((tmp_path / "data" / "servicenow-poller.json").read_text())
            assert saved["consecutive_errors"] == 2 and saved["last_poll_at"]
            # A recovery clears the alert state.
            poller._record({"fetched": 0}, "")
            assert ups == ["ServiceNow Polling"]
            assert poller.status()["consecutive_errors"] == 0
        finally:
            poller.stop()
        # Dead thread → ensure_running restarts it; stopped → it does not.
        fresh = ServiceNowPoller(app, "http://127.0.0.1:1")
        assert fresh.status()["last_poll_at"]       # loaded from disk
        fresh._stop.clear()
        assert fresh.ensure_running() is True and fresh.restarts == 1
        fresh.stop()
        assert fresh.ensure_running() is False

    def test_connector_gets_rejection_and_duplicate_hooks(self, tmp_path, monkeypatch):
        from desktop.snow_poller import ServiceNowPoller
        app = self._app(tmp_path)
        seen = []
        app.state.rejection_alerter = type("R", (), {
            "request_rejected": lambda self, *a: seen.append(a)})()
        for k, v in {"SNOW_INSTANCE_URL": "https://x", "SNOW_USERNAME": "u",
                     "SNOW_PASSWORD": "p", "SNOW_AUTH_METHOD": "basic",
                     "FINESIII_API_KEYS": "installer:k"}.items():
            monkeypatch.setenv(k, v)
        poller = ServiceNowPoller(app, "http://127.0.0.1:1")
        connector, s = poller._build_connector()
        assert connector.on_rejected is not None
        assert connector.known_ticket is not None
        assert connector.duplicate_of is not None
        assert connector.possible_duplicate_of is not None
        assert connector.duplicate_of({"operation": "provision",
                                       "affiliation_code": "1", "employee_code": "2",
                                       "ticket_id": "T"}, {}) is None
        connector.on_rejected("X", "why", {})
        assert seen == [("X", "why", {})]


class TestAvailabilityComponent:
    def test_servicenow_component_has_texts(self):
        # The texts are in config/email_messages.yaml (2026-09-29).
        from src.modules.notifications import availability_alerts as a
        from src.modules.notifications import messages as m
        key = a._COMPONENTS[a.COMPONENT_SERVICENOW][0]
        for name in (f"avail.impact.{key}", f"avail.next.{key}",
                     f"component.{key}"):
            assert m.one(name, "ja") and m.one(name, "en"), name
