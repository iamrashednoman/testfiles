"""SailPoint catalog tasks (2026-09-28).

Pins, per approved item:
  S1  the three real ticket formats (Add, Remove, Certification) are read
      from the requested item's catalog variables; full-width punctuation
      and bullets are tolerated.
  S2  operation words; a certification is ALWAYS a removal.
  S3  bot-generated passwords: FINESIII rules, never reused (keyed
      fingerprint), a retry after the password was erased gets a new one.
  S4  every negative sample is refused with a reason in plain words and
      noted on the ticket once.
  S5  latest action wins (Add → Remove → Add is new work); same tracking
      ID blocks.
  S6  group pickup (unassigned or the bot's) and claim on pickup.
  S7  certification closing comment; a closed ticket is never written to.
  S11 a cleared console setting stops being in force.
  S12 a task closed or taken over after pickup is cancelled before it
      reaches the terminal.
"""
import time

import pytest

from scripts.run_mock_snow_server import (
    GROUP, TicketStore, access_text, create_mock_app, user_sys_id,
)
from src.integrations.servicenow import sailpoint
from src.integrations.servicenow.config import (
    ServiceNowSettings, load_servicenow_config,
)
from src.integrations.servicenow.connector import (
    ReportMemory, ServiceNowConnector,
)
from src.modules.intake import passwords
from src.modules.intake.models import ProcessingRequest
from tests.conftest import make_config


def sp_settings(**kw) -> ServiceNowSettings:
    """The shipped SailPoint settings, pointed at nothing."""
    s = load_servicenow_config()
    s.instance_url = "https://mock.service-now.com"
    s.username, s.password = "finesiii.bot", "x"
    # Bot-account mode: the tasks are routed to the bot account.
    s.assigned_to = "finesiii.bot"
    s.respect_service_health = False
    for k, v in kw.items():
        setattr(s, k, v)
    return s


def rows_of(store: TicketStore, task: dict) -> list:
    return store.variables[task["request_item"]]


def fetched(store: TicketStore, task: dict) -> dict:
    """The task as the connector receives it (the SailPoint fields)."""
    from src.integrations.servicenow.config import SAILPOINT_FIELDS
    return {f: store.field(task, f) for f in SAILPOINT_FIELDS}


# ── S1 / S2 : the three real formats ─────────────────────────────

class TestRealSamples:
    def setup_method(self):
        self.store = TicketStore()
        self.remove, self.cert, self.add = self.store.seed_real_samples()
        self.s = sp_settings()

    def parse(self, task):
        """The single request of a single-code ticket (or the reason)."""
        payloads, reason = sailpoint.parse_ticket(
            fetched(self.store, task), rows_of(self.store, task), self.s)
        return (payloads[0] if payloads else None), reason

    def test_remove(self):
        p, reason = self.parse(self.remove)
        who = self.store.sample_person
        assert reason == ""
        assert (p["operation"], p["affiliation_code"], p["employee_code"],
                p["ticket_id"]) == ("deprovision", "01634", who["account"],
                                    "SCTASK12130672")
        m = p["metadata"]
        assert (m["category"], m["tracking_id"], m["request_type"],
                m["requested_item"], m["request_number"]) == (
            "access_removal", "0000537400", "Modify", "RITM10244224",
            "REQ9084557")
        assert m["employee_id"] == who["employee_id"]
        assert m["employee_name"] == who["name"]
        assert (m["parts"], m["part"], m["parent_ticket"]) == \
            (1, 1, "SCTASK12130672")
        assert m["affiliation_name"] == "コンタクトセンター部スタッフ"
        assert m["snow_details"]["sys_id"] == self.remove["sys_id"]

    def test_certification_is_always_a_removal(self):
        p, reason = self.parse(self.cert)
        assert reason == ""
        assert (p["operation"], p["affiliation_code"], p["employee_code"]) \
            == ("deprovision", "01634", self.store.sample_person["account"])
        assert p["metadata"]["category"] == "entitlement_certification"
        assert p["metadata"]["tracking_id"] == ""
        assert p["metadata"]["entitlement"].startswith("01634 |")
        assert "Revoker" not in p["metadata"]["affiliation_name"]

    def test_add_never_carries_a_password(self):
        p, reason = self.parse(self.add)
        assert reason == ""
        assert (p["operation"], p["employee_code"], p["password"]) == \
            ("provision", self.store.sample_person["account"], "")
        assert p["metadata"]["category"] == "new_account"
        assert p["metadata"]["tracking_id"] == "0000537401"
        assert p["metadata"]["request_type"] == "Create"

    def test_full_width_punctuation_and_bullets(self):
        text = ("* Access Request ID in myAIAccess for tracking purpose is：0000537401\n"
                "* Please provision/deprovision the below attributes for account：4821KQT\n"
                "* AttributeName＝所属コード；Value＝０１６３４ ｜ 部署；Operation＝Add")
        task = self.store.create_sailpoint("add", account="4821KQT", text=text)
        p, reason = self.parse(task)
        assert reason == ""
        assert (p["operation"], p["affiliation_code"],
                p["metadata"]["tracking_id"]) == ("provision", "01634",
                                                  "0000537401")

    def test_words_are_settings(self):
        task = self.store.create_sailpoint(
            "add", account="4821KQT",
            text=access_text("1", "4821KQT", "01634", "Grant"))
        assert "unknown operation 'Grant'" in self.parse(task)[1]
        self.s.operation_words = dict(self.s.operation_words,
                                      provision=["Grant"])
        assert self.parse(task)[0]["operation"] == "provision"

    def test_termination_word(self):
        task = self.store.create_sailpoint(
            "remove", account="4821KQT",
            text=access_text("1", "4821KQT", "01634", "Termination"))
        p = self.parse(task)[0]
        assert p["operation"] == "deprovision"
        assert p["metadata"]["category"] == "termination"

    def test_certification_cannot_provision(self):
        task = self.store.create_sailpoint(
            "certification",
            text="SailPoint Certification process\n"
                 + access_text("1", "4821KQT", "01634", "Add"))
        assert "can only remove access" in self.parse(task)[1]


# ── B1 : the six request types, several codes per ticket ─────────

PROCESS = {  # type: (category, operation, codes)
    "New Account Provisioning": ("new_account", "provision", ["05001"]),
    "Access Removal": ("access_removal", "deprovision", ["05002"]),
    "Entitlement Certification": ("entitlement_certification", "deprovision",
                                  ["05031", "05032"]),
    "Account Certification": ("account_certification", "deprovision",
                              ["05041", "05042", "05043"]),
    "Transfer": ("transfer", "deprovision", ["05051", "05052"]),
    "Termination": ("termination", "deprovision", ["05061", "05062"]),
}


class TestRequestTypes:
    def test_each_type_and_its_codes(self):
        store = TicketStore()
        numbers = store.seed_process_samples()
        by_number = {t["number"]: t for t in store.tickets}
        s = sp_settings()
        for kind, (category, op, codes) in PROCESS.items():
            task = by_number[numbers[kind]]
            payloads, reason = sailpoint.parse_ticket(
                fetched(store, task), rows_of(store, task), s)
            assert reason == "", (kind, reason)
            assert [p["affiliation_code"] for p in payloads] == codes, kind
            assert {p["operation"] for p in payloads} == {op}, kind
            assert {p["metadata"]["category"] for p in payloads} == {category}
            n = task["number"]
            expected_ids = [n] if len(codes) == 1 else \
                [f"{n}/{i}" for i in range(1, len(codes) + 1)]
            assert [p["ticket_id"] for p in payloads] == expected_ids, kind
            for p in payloads:
                m = p["metadata"]
                assert m["parts"] == len(codes) and m["parent_ticket"] == n
                assert [e["code"] for e in m["entitlements"]] == codes
                assert m["affiliation_name"]           # name after "|"

    def test_semicolon_separated_entitlements_on_one_line(self):
        items = sailpoint._attribute_items(
            "AttributeName=所属コード; Value=01634|コンタクトセンター部スタッフ; "
            "Operation=Remove; AttributeName=所属コード; Value=01700|営業部; "
            "Operation=Remove")
        assert [(v, o) for _, v, o in items] == [
            ("01634|コンタクトセンター部スタッフ", "Remove"),
            ("01700|営業部", "Remove")]

    def test_type_words_are_settings(self):
        store = TicketStore()
        task = store.create_sailpoint(
            "remove", account="4821KQT",
            text=access_text("1", "4821KQT", "01634", "Remove")
            + "\nReason: Leaver")
        s = sp_settings()
        p = sailpoint.parse_ticket(fetched(store, task), rows_of(store, task), s)[0][0]
        assert p["metadata"]["category"] == "termination"     # "Leaver"
        s.request_type_words = dict(s.request_type_words, termination=[])
        p = sailpoint.parse_ticket(fetched(store, task), rows_of(store, task), s)[0][0]
        assert p["metadata"]["category"] == "access_removal"


# ── S4 : negative samples ────────────────────────────────────────

EXPECTED_REASONS = {
    "wrong application": "not for application [2565]",
    "instance Dev": "instance 'Dev' is not accepted",
    "account mismatch": "differs from the Account Name variable",
    "account not 7 characters": "is not 7 characters",
    "no instruction line": "no provisioning or removal instruction",
    "adds and removes in one ticket": "both adds and removes",
    "other attribute": "attribute 'ロール' is not supported",
    "affiliation not numeric": "is not a 5-digit code",
    "unknown operation": "unknown operation 'Suspend'",
    "Create with Remove": "Request Type 'Create' contradicts",
    "transfer asking to add": "a Transfer can only remove access",
    "no catalog variables": "catalog variables of the requested item",
}
# Refused with a note on the ticket: all but the task for another
# application, which is not the bot's and is skipped without one.
NOTED_REASONS = {k: v for k, v in EXPECTED_REASONS.items()
                 if k != "wrong application"}
NOT_FETCHED = ("taken by a person", "other group, unassigned",
               "already closed", "not approved")


class TestNegativeSamples:
    def test_each_case_has_its_reason(self):
        store = TicketStore()
        cases = store.seed_negative()
        by_number = {t["number"]: t for t in store.tickets}
        s = sp_settings()
        for case, expected in EXPECTED_REASONS.items():
            task = by_number[cases[case]]
            payload, reason = sailpoint.parse_ticket(
                fetched(store, task), rows_of(store, task), s)
            assert payload is None, case
            assert expected in reason, (case, reason)

    def test_query_leaves_other_tasks_alone(self):
        store = TicketStore()
        cases = store.seed_negative()
        store.seed_real_samples()
        s = sp_settings()
        assert s.assignment_mode == "assigned_to"           # the default
        assert "request_item.approval=approved" in s.build_query()
        found = {t["number"] for t in store.query(s.build_query())}
        for case in NOT_FETCHED:
            assert cases[case] not in found, case
        assert {"SCTASK12130672", "SCTASK12130674", "SCTASK12130683"} <= found
        # Group mode: unassigned or the bot's, in the group — never a
        # person's task, never another group's.
        s.assignment_mode = "assignment_group"
        s.assignment_group = GROUP          # entered on the Settings page
        # The connector looks the Bot account up before the fetch.
        s.bot_sys_id = user_sys_id("finesiii.bot")
        found = {t["number"] for t in store.query(s.build_query())}
        assert cases["taken by a person"] not in found
        assert cases["other group, unassigned"] not in found
        assert "SCTASK12130672" in found

    def test_approval_filter_is_a_setting(self):
        store = TicketStore()
        cases = store.seed_negative()
        s = sp_settings(require_approval=False)
        found = {t["number"] for t in store.query(s.build_query())}
        assert cases["not approved"] in found
        s = sp_settings(approval_filter="x^ORactive=true")
        assert "ORactive" not in s.build_query()
        with pytest.raises(ValueError):
            s.validate()

    def test_empty_instance_accepted_filled_one_checked(self):
        store = TicketStore()
        task = store.create_sailpoint("add", instance="")
        s = sp_settings()
        assert sailpoint.parse_ticket(fetched(store, task),
                                      rows_of(store, task), s)[1] == ""
        s.sp_accepted_instances = []          # blank setting = no check
        task = store.create_sailpoint("add", instance="Dev")
        assert sailpoint.parse_ticket(fetched(store, task),
                                      rows_of(store, task), s)[1] == ""


# ── Connector: pickup, claim, rejection notes, reported once ─────

class FakeClient:
    """The ServiceNow calls the connector makes, served from the mock
    store (no network)."""

    def __init__(self, store):
        self.store, self.notes, self.claims, self.handed = store, [], [], []

    def fetch_assigned_open(self):
        return [fetched(self.store, t)
                for t in self.store.query(self.settings.build_query())]

    def fetch_variables(self, ticket):
        return self.store.variables.get(ticket.get("request_item", ""), [])

    def get_records(self, table, query="", fields=None, limit=10):
        key, _, value = query.partition("=")
        if table == "sc_request":
            rows = [r for r in self.store.requests if r.get(key) == value]
        elif table == "sys_user":
            rows = [p for p in self.store.people.values() if p.get(key) == value]
        else:
            rows = []
        return [{f: r.get(f, "") for f in (fields or r.keys())} for r in rows][:limit]

    def user_sys_id(self, name):
        return user_sys_id(name)

    def claim(self, sys_id, user, state, table=""):
        self.claims.append((sys_id, user, state))
        self.store.update(sys_id, {"assigned_to": user, "state": state})

    def add_work_note(self, sys_id, note, table=""):
        self.notes.append((sys_id, note))

    def reassign(self, sys_id, group, note="", table=""):
        self.handed.append((sys_id, group, note))


def run_connector(store, settings, memory=None, submitted=None):
    client = FakeClient(store)
    client.settings = settings
    c = ServiceNowConnector(settings, client=client)
    c.reported = memory if memory is not None else ReportMemory()
    submitted = submitted if submitted is not None else []

    def submit(payload):
        submitted.append(payload)
        return "queued"
    c._submit = submit
    return c, client, submitted


class TestConnector:
    def test_samples_queued_claimed_negatives_noted_once(self):
        store = TicketStore()
        store.seed_real_samples()
        cases = store.seed_negative()
        s = sp_settings()
        memory = ReportMemory()
        c, client, submitted = run_connector(store, s, memory)
        stats = c.poll_once()
        assert [p["ticket_id"] for p in submitted] == [
            "SCTASK12130672", "SCTASK12130674", "SCTASK12130683"]
        assert stats["submitted"] == 3
        # A task for another application is not the bot's: skipped
        # without a note; every other refused task gets its reason.
        assert stats["skipped"] == len(NOTED_REASONS)
        assert stats["out_of_selection"] == 1
        # Claimed: assigned to the bot, Work in Progress.
        bot = user_sys_id("finesiii.bot")
        assert {(u, st) for _, u, st in client.claims} == {(bot, "2")}
        # One note per rejected task, with its reason.
        noted = {sid for sid, _ in client.notes}
        by_number = {t["number"]: t for t in store.tickets}
        for case in NOTED_REASONS:
            assert by_number[cases[case]]["sys_id"] in noted, case
        assert by_number[cases["wrong application"]]["sys_id"] not in noted
        note = next(n for sid, n in client.notes
                    if sid == by_number[cases["instance Dev"]]["sys_id"])
        assert note.startswith("Not processed by the FINESIII RPA bot: "
                               "instance 'Dev' is not accepted")
        # Second poll: nothing new — no new note.
        before = len(client.notes)
        c2, client2, submitted2 = run_connector(store, s, memory)
        stats2 = c2.poll_once()
        assert client2.notes == [] and before == len(NOTED_REASONS)
        assert stats2["suppressed"] == len(NOTED_REASONS)
        assert stats2["out_of_selection"] == 1

    def test_several_codes_submitted_together_claimed_once(self):
        store = TicketStore()
        numbers = store.seed_process_samples()
        c, client, submitted = run_connector(store, sp_settings())
        stats = c.poll_once()
        expected = sum(len(v[2]) for v in PROCESS.values()) + 1  # + no-mail account
        assert stats["submitted"] == expected == len(submitted)
        assert len(client.claims) == len(numbers)          # once per ticket
        term = [p for p in submitted
                if p["metadata"]["parent_ticket"] == numbers["Termination"]]
        assert [p["ticket_id"] for p in term] == [
            numbers["Termination"] + "/1", numbers["Termination"] + "/2"]

    def test_requester_and_user_looked_up(self):
        store = TicketStore()
        numbers = store.seed_process_samples()
        c, client, submitted = run_connector(store, sp_settings())
        c.poll_once()
        new = next(p for p in submitted
                   if p["ticket_id"] == numbers["New Account Provisioning"])
        m = new["metadata"]
        assert m["requester"] == {"name": store.requester["name"],
                                  "employee_number": store.requester["employee_id"],
                                  "email": store.requester["email"]}
        assert m["user_email"] == \
            store.process_people["New Account Provisioning"]["email"]
        nomail = next(p for p in submitted if p["ticket_id"] ==
                      numbers["New Account, user without e-mail"])
        assert "user_email" not in nomail["metadata"]
        # The requester source is a setting.
        c, client, submitted = run_connector(
            TicketStore(), sp_settings(requester_source="none"))
        store2 = client.store
        store2.seed_process_samples()
        c.poll_once()
        assert all("requester" not in p["metadata"] for p in submitted)

    def test_claim_can_be_switched_off(self):
        store = TicketStore()
        store.seed_real_samples()
        c, client, _ = run_connector(store, sp_settings(claim_on_pickup=False))
        c.poll_once()
        assert client.claims == []

    def test_hand_over_group_takes_the_note(self):
        store = TicketStore()
        store.seed_negative()
        s = sp_settings(reject_reassign_group="IAM Operations")
        c, client, _ = run_connector(store, s)
        c.poll_once()
        assert len(client.handed) == len(NOTED_REASONS)
        assert client.notes == []
        assert all(g == "IAM Operations" for _, g, _ in client.handed)

    def test_variables_read_failure_is_an_error_not_a_rejection(self):
        from src.integrations.servicenow.client import ServiceNowError
        store = TicketStore()
        store.seed_real_samples()
        c, client, submitted = run_connector(store, sp_settings())

        def boom(ticket):
            raise ServiceNowError("403 no read access to sc_item_option_mtom")
        client.fetch_variables = boom
        stats = c.poll_once()
        assert stats["errors"] == 3 and submitted == [] and client.notes == []


# ── S3 : passwords ───────────────────────────────────────────────

class TestPasswords:
    def test_rules(self):
        for _ in range(2000):
            pw = passwords.generate("@", True)
            assert len(pw) == 8 and pw.isascii()
            assert pw[0].isalpha() and pw[0].isupper()
            assert any(c.isdigit() for c in pw) and "@" in pw
            assert not set(pw) & passwords.LOOKALIKES
            assert set(pw) <= set("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@")

    def test_unsafe_symbols_are_never_used(self):
        for _ in range(200):
            pw = passwords.generate("@+^%~(){}", True)
            assert not set(pw) & set("+^%~(){}")

    def test_used_fingerprint_is_skipped(self, tmp_path, monkeypatch):
        monkeypatch.setenv("FINESIII_DATA_DIR", str(tmp_path))
        monkeypatch.delenv(passwords.FP_KEY_ENV, raising=False)
        seen = []

        def used(fp):
            seen.append(fp)
            return len(seen) < 3          # first two "already used"
        pw, fp = passwords.generate_unique(used)
        assert len(seen) == 3 and fp == seen[-1]
        assert passwords.fingerprint(pw) == fp
        # The key persists: same password, same fingerprint.
        assert (tmp_path / passwords.FP_KEY_FILE).is_file()


@pytest.fixture
def app_client(tmp_path, monkeypatch):
    from fastapi.testclient import TestClient
    from src import create_app
    monkeypatch.setenv("FINESIII_DATA_DIR", str(tmp_path / "data"))
    app = create_app(make_config(tmp_path, auth_console_enabled=False))
    with TestClient(app) as client:
        yield client, app


class TestIntakePasswords:
    def body(self, emp, **kw):
        b = {"operation": "provision", "affiliation_code": "30822",
             "employee_code": emp}
        b.update(kw)
        return b

    def test_generated_unique_and_fingerprinted(self, app_client):
        client, app = app_client
        store = app.state.queue_store
        pws = set()
        for i in range(30):
            r = client.post("/api/v1/requests", json=self.body(f"50000{i:02d}"))
            assert r.status_code == 202, r.text
            req = store.get(r.json()["request_id"])
            assert len(req.password) == 8 and req.password[0].isalpha()
            assert req.metadata["password_generated"] is True
            assert store.password_fingerprint_used(req.metadata["password_fp"])
            pws.add(req.password)
        assert len(pws) == 30
        # Never shown by the API.
        r = client.get(f"/api/v1/requests/{req.request_id}").json()
        assert r["password"] == "****"
        assert r["metadata"]["password_fp"] == "****"

    def test_supplied_password_kept_and_recorded(self, app_client):
        client, app = app_client
        r = client.post("/api/v1/requests",
                        json=self.body("5100001", password="FUJI@33F"))
        req = app.state.queue_store.get(r.json()["request_id"])
        assert req.password == "FUJI@33F"
        assert req.metadata["password_supplied"] is True
        assert app.state.queue_store.password_fingerprint_used(
            passwords.fingerprint("FUJI@33F"))

    def test_caller_cannot_preset_the_markers(self, app_client):
        client, app = app_client
        r = client.post("/api/v1/requests", json=self.body(
            "5200001", metadata={"password_fp": "0" * 64,
                                 "password_generated": False}))
        req = app.state.queue_store.get(r.json()["request_id"])
        assert req.metadata["password_generated"] is True
        assert req.metadata["password_fp"] != "0" * 64

    def test_deprovision_gets_no_password(self, app_client):
        client, app = app_client
        r = client.post("/api/v1/requests", json={
            "operation": "deprovision", "affiliation_code": "30822",
            "employee_code": "5300001"})
        req = app.state.queue_store.get(r.json()["request_id"])
        assert req.password == "" and "password_fp" not in req.metadata

    def test_retry_after_erasure_gets_a_new_password(self, app_client):
        client, app = app_client
        store = app.state.queue_store
        r = client.post("/api/v1/requests", json=self.body("5400001"))
        rid = r.json()["request_id"]
        first = store.get(rid).password
        store.dequeue_oldest(worker_id=1)
        store.mark_complete(rid, "failed", error="x")
        store.purge_failed_passwords("9999-12-31")      # retention passed
        assert store.get(rid).password == ""
        r = client.post(f"/api/v1/requests/{rid}/retry")
        assert r.status_code == 202, r.text
        again = store.get(rid)
        assert len(again.password) == 8 and again.password != first


# ── S5 : duplicates (poller hooks against the real queue) ────────

class TestDuplicateRules:
    def _connector(self, app, monkeypatch):
        from desktop.snow_poller import ServiceNowPoller
        for k, v in {"SNOW_INSTANCE_URL": "https://x", "SNOW_USERNAME": "u",
                     "SNOW_PASSWORD": "p", "FINESIII_API_KEYS": "installer:k"
                     }.items():
            monkeypatch.setenv(k, v)
        return ServiceNowPoller(app, "http://127.0.0.1:1")._build_connector()[0]

    def _done(self, store, ticket, op, created="", **meta):
        if created:
            meta["snow_details"] = {"sys_created_on": created}
        req = ProcessingRequest(operation=op, affiliation_code="01634",
                                employee_code="4821KQT", source="servicenow",
                                ticket_id=ticket, metadata=meta)
        store.enqueue(req)
        store.dequeue_oldest(worker_id=1)
        store.mark_complete(req.request_id, "done")
        time.sleep(0.01)                  # distinct enqueue times
        return req

    def payload(self, ticket, op, tracking=""):
        return {"operation": op, "affiliation_code": "01634",
                "employee_code": "4821KQT", "ticket_id": ticket,
                "metadata": {"tracking_id": tracking}}

    def test_latest_action_wins(self, app_client, monkeypatch):
        client, app = app_client
        store = app.state.queue_store
        c = self._connector(app, monkeypatch)
        self._done(store, "SCTASK1", "provision")
        # Add again while the Add is the latest action → duplicate.
        assert c.duplicate_of(self.payload("SCTASK9", "provision"), {})
        self._done(store, "SCTASK2", "deprovision")
        # Add → Remove → Add: new work.
        assert c.duplicate_of(self.payload("SCTASK3", "provision"), {}) is None
        # Remove → revoke again: duplicate of the Remove (decision D).
        hit = c.duplicate_of(self.payload("SCTASK4", "deprovision"), {})
        assert hit and hit["ticket_id"] == "SCTASK2"

    def test_older_ticket_never_undoes_a_newer_one(self, app_client, monkeypatch):
        """The real samples: Remove 06:57, Certification 07:02, Add 07:30.
        Once the Add has run, the older Certification must NOT run (it
        would remove the access just granted)."""
        client, app = app_client
        store = app.state.queue_store
        c = self._connector(app, monkeypatch)
        self._done(store, "SCTASK12130672", "deprovision",
                   created="2026-08-12 06:57:41")
        self._done(store, "SCTASK12130683", "provision",
                   created="2026-08-12 07:30:20")
        cert = {"sys_created_on": "2026-08-12 07:02:12"}
        hit = c.duplicate_of(self.payload("SCTASK12130674", "deprovision"), cert)
        # Still reported as the duplicate of the Remove (stable reason).
        assert hit and hit["ticket_id"] == "SCTASK12130672"
        assert not hit.get("superseded")

    def test_stale_ticket_without_earlier_match_is_superseded(self, app_client, monkeypatch):
        client, app = app_client
        c = self._connector(app, monkeypatch)
        self._done(app.state.queue_store, "SCTASK20", "deprovision",
                   created="2026-08-12 10:00:00")
        stale = {"sys_created_on": "2026-08-12 09:00:00"}
        hit = c.duplicate_of(self.payload("SCTASK19", "provision"), stale)
        assert hit["superseded"] is True and hit["ticket_id"] == "SCTASK20"
        assert "newer ticket SCTASK20" in hit["reason"]
        # A NEWER ticket than the Remove is new work.
        fresh = {"sys_created_on": "2026-08-12 11:00:00"}
        assert c.duplicate_of(self.payload("SCTASK21", "provision"), fresh) is None

    def test_same_tracking_id_blocks(self, app_client, monkeypatch):
        client, app = app_client
        c = self._connector(app, monkeypatch)
        self._done(app.state.queue_store, "SCTASK1", "deprovision",
                   tracking_id="0000537400")
        hit = c.duplicate_of(self.payload("SCTASK5", "provision",
                                          tracking="0000537400"), {})
        assert hit["ticket_id"] == "SCTASK1"
        assert "0000537400" in hit["reason"]

    # BUG-009: window 0 turns off only the same-request check.
    def test_window_zero_still_supersedes_older_ticket(self, app_client, monkeypatch):
        client, app = app_client
        monkeypatch.setenv("SNOW_DUPLICATE_WINDOW_DAYS", "0")
        c = self._connector(app, monkeypatch)
        self._done(app.state.queue_store, "SCTASK30", "provision",
                   created="2026-08-12 10:00:00")
        cert = {"sys_created_on": "2026-08-12 09:00:00"}
        hit = c.duplicate_of(self.payload("SCTASK29", "deprovision"), cert)
        assert hit and hit["superseded"] is True
        assert hit["ticket_id"] == "SCTASK30"
        # The possible-duplicate check stays windowed (off with 0).
        assert c.possible_duplicate_of is None

    def test_window_zero_still_holds_same_tracking_id(self, app_client, monkeypatch):
        client, app = app_client
        monkeypatch.setenv("SNOW_DUPLICATE_WINDOW_DAYS", "0")
        c = self._connector(app, monkeypatch)
        self._done(app.state.queue_store, "SCTASK31", "deprovision",
                   tracking_id="0000999900")
        hit = c.duplicate_of(self.payload("SCTASK32", "provision",
                                          tracking="0000999900"), {})
        assert hit and hit["ticket_id"] == "SCTASK31"

    def test_window_zero_queues_same_content_repeat(self, app_client, monkeypatch):
        client, app = app_client
        monkeypatch.setenv("SNOW_DUPLICATE_WINDOW_DAYS", "0")
        c = self._connector(app, monkeypatch)
        self._done(app.state.queue_store, "SCTASK33", "provision")
        assert c.duplicate_of(self.payload("SCTASK34", "provision"), {}) is None


# ── S7 / S12 : close-out ─────────────────────────────────────────

class _Req:
    source = "servicenow"

    def __init__(self, category="certification", sys_id="a" * 32):
        self.request_id, self.ticket_id = "req-1", "SCTASK12130674"
        self.operation, self.status = "deprovision", "done"
        self.metadata = {"snow_details": {"sys_id": sys_id,
                                          "number": "SCTASK12130674"},
                         "category": category, "tracking_id": "T1"}


class _Txn:
    status, ticket_id, request_id = "done", "SCTASK12130674", "req-1"
    operation, affiliation_code, employee_code = "deprovision", "01634", "4821KQT"
    result_code, completed_at, attempt_count, error_message = "O-0000", "2026-09-28T10:00:00", 1, ""


class _Client:
    def __init__(self, rows=None, fail=False):
        self.rows, self.fail, self.calls = rows, fail, []

    def get_records(self, table, query="", fields=None, limit=10):
        if self.fail:
            raise RuntimeError("unreachable")
        self.calls.append(query)
        return self.rows if self.rows is not None else [{"sys_id": "x"}]

    def user_sys_id(self, name):
        return user_sys_id(name)

    def set_state(self, sys_id, state, note=None, table="", extra=None):
        self.calls.append(("state", state, note))

    def add_work_note(self, sys_id, note, table=""):
        self.calls.append(("note", note))


def closeout(client, **kw):
    from src.integrations.servicenow.writeback import TicketCloseout
    s = sp_settings(**kw)
    return TicketCloseout(settings_loader=lambda: s,
                          client_factory=lambda st: client, async_send=False,
                          sleep_func=lambda d: None)


class TestCloseout:
    def test_certification_comment(self):
        client = _Client()
        closeout(client).handle_completion(_Txn(), _Req(), {})
        state = [c for c in client.calls if isinstance(c, tuple)][0]
        assert state[1] == "3"
        assert state[2].startswith("Certification revocation completed")
        assert "account 4821KQT" in state[2]
        assert client.calls[0].endswith("^active=true")

    def test_pre_execute_check(self):
        req = _Req()
        assert closeout(_Client([{"active": "true", "assigned_to": ""}])
                        ).pre_execute_check(req) == ""
        assert "closed" in closeout(_Client([{"active": "false", "state": "3"}])
                                    ).pre_execute_check(req)
        assert "no longer exists" in closeout(_Client([])).pre_execute_check(req)
        other = _Client([{"active": "true",
                          "assigned_to": user_sys_id("someone.else")}])
        assert "someone else" in closeout(other).pre_execute_check(req)
        mine = _Client([{"active": "true",
                         "assigned_to": user_sys_id("finesiii.bot")}])
        assert closeout(mine).pre_execute_check(req) == ""
        # Unreachable: the request runs (verified at pickup).
        assert closeout(_Client(fail=True)).pre_execute_check(req) == ""
        # Not a ServiceNow request: never checked.
        manual = _Req()
        manual.source = "manual"
        assert closeout(_Client([])).pre_execute_check(manual) == ""


class TestDispatcherPreExecute:
    def test_cancelled_without_terminal_or_emails(self, tmp_path):
        from src.core.db import Database
        from src.core.retry import RetryPolicy
        from src.modules.queue.dispatcher import Dispatcher
        from src.modules.queue.services import QueueStore
        from src.modules.audit.services import TransactionStore
        cfg = make_config(tmp_path)
        db = Database.from_config(cfg)
        store, txns = QueueStore(db), TransactionStore(db)
        req = ProcessingRequest(operation="provision", affiliation_code="01634",
                                employee_code="4821KQT", password="ABCD@234",
                                source="servicenow", ticket_id="SCTASK1")
        store.enqueue(req)

        class Executor:
            calls = 0

            def execute(self, request):
                Executor.calls += 1
                return {"status": "done"}
        completed = []
        d = Dispatcher(store, txns, RetryPolicy(max_attempts=3), Executor(),
                       cfg, on_complete=lambda *a: completed.append(a),
                       pre_execute=lambda r: "the ServiceNow ticket was closed")
        assert d._tick() is True
        after = store.get(req.request_id)
        assert after.status == "cancelled" and after.password == ""
        assert "closed" in after.error
        assert Executor.calls == 0 and completed == []
        db.close()


# ── S11 : clearing a live setting ────────────────────────────────

class TestClearedSetting:
    def test_clear_restores_the_environment(self, tmp_path, monkeypatch):
        from src.core.db import Database
        from src.modules.console.settings_store import (
            SettingsStore, apply_hot_env,
        )
        monkeypatch.setenv("SNOW_ASSIGNED_TO", "from-environment")
        monkeypatch.delenv("SNOW_OPEN_STATES", raising=False)
        db = Database.from_config(make_config(tmp_path))
        store = SettingsStore(db)
        store.set("SNOW_ASSIGNED_TO", "someone.else", actor="t")
        store.set("SNOW_OPEN_STATES", "2", actor="t")
        apply_hot_env(store)
        import os
        assert os.environ["SNOW_ASSIGNED_TO"] == "someone.else"
        assert load_servicenow_config().open_states == ["2"]
        store.clear("SNOW_ASSIGNED_TO")
        store.clear("SNOW_OPEN_STATES")
        apply_hot_env(store)
        assert os.environ["SNOW_ASSIGNED_TO"] == "from-environment"
        assert "SNOW_OPEN_STATES" not in os.environ
        assert load_servicenow_config().open_states == []
        db.close()


# ── Mock ServiceNow: the calls the bot makes, over HTTP ──────────

class TestMockServer:
    def test_group_or_query_variables_claim_and_close(self):
        from fastapi.testclient import TestClient
        store = TicketStore()
        store.seed_real_samples()
        store.seed_negative()
        client = TestClient(create_mock_app(store))
        auth = ("finesiii.bot", "x")
        s = sp_settings()
        r = client.get("/api/now/table/sc_task", auth=auth, params={
            "sysparm_query": s.build_query(),
            "sysparm_fields": ",".join(s.fields)})
        rows = r.json()["result"]
        numbers = [t["number"] for t in rows]
        assert numbers[:3] == ["SCTASK12130672", "SCTASK12130674",
                               "SCTASK12130683"]
        assert rows[0]["request_item.number"] == "RITM10244224"
        v = client.get("/api/now/table/sc_item_option_mtom", auth=auth,
                       params={"sysparm_query":
                               f"request_item={rows[0]['request_item']}"})
        labels = [x["sc_item_option.item_option_new.question_text"]
                  for x in v.json()["result"]]
        assert "Account Name" in labels and "Description / Work notes" in labels
        sid = rows[0]["sys_id"]
        client.patch(f"/api/now/table/sc_task/{sid}", auth=auth,
                     json={"assigned_to": user_sys_id("finesiii.bot"),
                           "state": "2"})
        client.patch(f"/api/now/table/sc_task/{sid}", auth=auth,
                     json={"state": "3", "work_notes": "done"})
        t = store.by_sys_id(sid)
        assert (t["state"], t["active"]) == ("3", "false")
        assert "done" in t["work_notes"]
        assert client.get("/api/now/table/sc_task").status_code == 401
        assert store.groups and GROUP in store.groups.values()
