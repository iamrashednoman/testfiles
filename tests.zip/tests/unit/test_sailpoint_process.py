"""SailPoint process design (2026-09-28).

Pins, per approved item:
  A1  one welcome banner for every way of starting.
  A3  evidence older than the retention setting is removed; nothing else.
  A4  a terminal driver whose prerequisites are missing is named.
  A5  a sign-in page from ServiceNow becomes a clear error.
  B2  a ticket with several codes is written to ONCE, when every code is
      finished, with one line per code; a failure keeps it open.
  C1  the support report is sent once per ticket, lists every code with
      its result, and names the requester.
  C2  the registration notice and the password notice are SEPARATE
      e-mails to the user; no address = no password sent anywhere.
  C5  a result that could not be confirmed never says "completed".
  C6  client templates keep their exact subject; a user e-mail never
      shows the internal CC list; every e-mail is audited.
"""
import os
import time

import httpx
import pytest

from src.core.db import Database
from src.modules.intake.models import ProcessingRequest
from src.modules.queue.services import QueueStore
from tests.conftest import make_config


# ── helpers ──────────────────────────────────────────────────────

def store_for(tmp_path):
    db = Database.from_config(make_config(tmp_path))
    return db, QueueStore(db)


def ticket_requests(store, parent="SCTASK9", codes=("05041", "05042"),
                    op="deprovision", category="account_certification",
                    **meta):
    """The requests a ticket with several codes becomes."""
    out = []
    for i, code in enumerate(codes, start=1):
        m = {"snow_details": {"sys_id": "a" * 32, "number": parent},
             "category": category, "parts": len(codes), "part": i,
             "parent_ticket": parent, "affiliation_name": f"部署{i}",
             "employee_name": "Mika Mori", "tracking_id": "T-1",
             "requester": {"name": "Daichi Morita",
                           "employee_number": "1712345",
                           "email": "d.morita@example.com"}}
        m.update(meta)
        req = ProcessingRequest(
            operation=op, affiliation_code=code, employee_code="5004AAA",
            source="servicenow", metadata=m,
            ticket_id=parent if len(codes) == 1 else f"{parent}/{i}",
            password="ABCD@234" if op == "provision" else "")
        store.enqueue(req)
        out.append(req)
    return out


def finish(store, req, status="done", result_code="O-0000", error=""):
    store.dequeue_oldest(worker_id=1)
    store.mark_complete(req.request_id, status, result_code=result_code,
                        error=error)
    time.sleep(0.01)
    return store.get(req.request_id)


class _Client:
    def __init__(self):
        self.calls, self.lookups = [], []

    def get_records(self, table, query="", fields=None, limit=10):
        self.lookups.append(query)
        return [{"sys_id": "a" * 32}]

    def set_state(self, sys_id, state, note=None, table="", extra=None):
        self.calls.append(("close", state, note))

    def add_work_note(self, sys_id, note, table=""):
        self.calls.append(("note", note))


def closeout(store, client):
    from src.integrations.servicenow.config import load_servicenow_config
    from src.integrations.servicenow.writeback import TicketCloseout
    s = load_servicenow_config()
    s.instance_url, s.username = "https://x", "finesiii.bot"
    co = TicketCloseout(settings_loader=lambda: s,
                        client_factory=lambda st: client, async_send=False,
                        sleep_func=lambda d: None)
    co.queue_store = store
    return co


# ── B2 : one update per ticket ───────────────────────────────────

class TestTicketCloseout:
    def test_written_once_when_every_code_is_finished(self, tmp_path):
        db, store = store_for(tmp_path)
        client = _Client()
        co = closeout(store, client)
        a, b = ticket_requests(store)
        co.handle_completion(None, finish(store, a), {})
        assert client.calls == []                  # b still queued
        co.handle_completion(None, finish(store, b), {})
        assert len(client.calls) == 1
        action, state, note = client.calls[0]
        assert (action, state) == ("close", "3")
        assert note.startswith("Certification revocation completed")
        assert "- 05041 部署1: completed" in note
        assert "- 05042 部署2: completed" in note
        # The ownership check uses the TICKET number, not a part.
        assert "number=SCTASK9^" in client.lookups[0]
        # Recorded on every part: the next poll does not write again.
        assert co.reconcile(store.get(a.request_id)) is False
        db.close()

    def test_one_failed_code_keeps_the_ticket_open(self, tmp_path):
        db, store = store_for(tmp_path)
        client = _Client()
        co = closeout(store, client)
        a, b = ticket_requests(store, category="termination")
        finish(store, a)
        co.handle_completion(None, finish(store, b, "failed", "",
                                          "E-9901 not found"), {})
        action, note = client.calls[0]
        assert action == "note" and "05042: E-9901 not found" in note
        assert "- 05041 部署1: completed" in note
        assert "- 05042 部署2: failed" in note
        db.close()

    def test_single_code_ticket_unchanged(self, tmp_path):
        db, store = store_for(tmp_path)
        client = _Client()
        co = closeout(store, client)
        (a,) = ticket_requests(store, codes=("05002",),
                               category="access_removal")
        done = finish(store, a)
        co.handle_completion(done, done, {})
        action, state, note = client.calls[0]
        assert note.startswith("Deprovisioning completed")
        assert "Result per affiliation code" not in note
        db.close()


# ── C : e-mails ──────────────────────────────────────────────────

class FakeNotifier:
    def __init__(self):
        self.sent = []

    def send(self, subject, body, to=None, cc=None, raw_subject=False,
             redact_body=True, kind="", **kw):
        self.sent.append({"subject": subject, "body": body, "to": to,
                          "cc": cc, "raw": raw_subject, "kind": kind,
                          "redact": redact_body})
        return True


def reporter(store, **settings):
    from src.modules.notifications.ticket_reports import (
        TicketReporter, TicketReportSettings,
    )
    base = dict(txn_enabled=True, report_enabled=True,
                recipients_to=["fines-support@example.com"],
                recipients_cc=["iam-lead@example.com"],
                contact_email="registration@example.com",
                send_registration=True, send_password=True,
                templates={"support_report": "email_templates/support_report.txt",
                           "user_registration": "email_templates/user_registration.txt",
                           "user_password": "email_templates/user_password.txt"})
    base.update(settings)
    n = FakeNotifier()
    r = TicketReporter(n, settings_loader=lambda: TicketReportSettings(**base),
                       async_send=False)
    r.queue_store = store
    return r, n


class TestTicketEmails:
    def test_new_account_three_emails(self, tmp_path):
        db, store = store_for(tmp_path)
        r, n = reporter(store)
        (a,) = ticket_requests(store, codes=("05001",), op="provision",
                               category="new_account",
                               user_email="kunal.mittal@example.com",
                               affiliation_name="営業部",
                               employee_name="Kunal Mittal")
        done = finish(store, a)
        done.password = "ABCD@234"          # still in memory at the hook
        r.handle_completion(done, done, {})
        kinds = [m["kind"] for m in n.sent]
        assert kinds == ["user_registration", "user_password", "support_report"]
        reg, pw, rep = n.sent
        # Registration: the ID, NOT the password.
        assert reg["to"] == ["kunal.mittal@example.com"] and reg["raw"]
        assert reg["subject"].startswith("FINESIIIアカウントの新規登録について")
        assert "05001" in reg["body"] and "5004AAA" in reg["body"]
        assert "ABCD@234" not in reg["body"]
        assert "registration@example.com" in reg["body"]
        # Password: separate e-mail, same user only, body not redacted.
        assert pw["to"] == ["kunal.mittal@example.com"]
        assert "ABCD@234" in pw["body"] and pw["redact"] is False
        # Support report: exact subject with the date, requester, target.
        assert rep["subject"].startswith("FINESIIIアカウント登録報告(20")
        assert rep["to"] == ["fines-support@example.com"]
        assert rep["cc"] == ["iam-lead@example.com"]
        assert "登録を行いました" in rep["body"]
        assert "Daichi Morita / 1712345" in rep["body"]
        assert "所属コード 05001：営業部" in rep["body"]
        assert "担当者コード 5004AAA：Kunal Mittal" in rep["body"]
        assert "完了 (Success)" in rep["body"]
        assert "ABCD@234" not in rep["body"]
        # Sent once: a second completion does nothing more.
        r.handle_completion(done, store.get(a.request_id), {})
        assert len(n.sent) == 3
        db.close()

    def test_no_user_address_no_password_anywhere(self, tmp_path):
        db, store = store_for(tmp_path)
        r, n = reporter(store)
        (a,) = ticket_requests(store, codes=("05007",), op="provision",
                               category="new_account")
        done = finish(store, a)
        done.password = "ABCD@234"
        r.handle_completion(done, done, {})
        assert [m["kind"] for m in n.sent] == ["support_report"]
        assert "ABCD@234" not in n.sent[0]["body"]
        assert "e-mail address was not found" in n.sent[0]["body"]
        db.close()

    def test_report_once_per_ticket_with_every_code(self, tmp_path):
        db, store = store_for(tmp_path)
        r, n = reporter(store)
        a, b, c = ticket_requests(store, codes=("05041", "05042", "05043"))
        r.handle_completion(None, finish(store, a), {})
        r.handle_completion(None, finish(store, b, "already_deleted", ""), {})
        assert n.sent == []                         # c still open
        r.handle_completion(None, finish(store, c, "failed", "", "timeout"), {})
        assert len(n.sent) == 1
        body = n.sent[0]["body"]
        assert "削除を行いました" in body
        assert "05041 部署1：完了 (Success)" in body
        assert "05042 部署2：削除済み (Already removed)" in body
        assert "05043 部署3：失敗 (Failed) — timeout" in body
        assert "Account Certification" in body
        db.close()

    def test_not_confirmed_never_announced(self, tmp_path):
        db, store = store_for(tmp_path)
        r, n = reporter(store)
        (a,) = ticket_requests(store, codes=("05001",), op="provision",
                               category="new_account",
                               user_email="u@example.com")
        done = finish(store, a, "done", "UNCONFIRMED")
        done.password = "ABCD@234"
        r.handle_completion(done, done, {})
        assert [m["kind"] for m in n.sent] == ["support_report"]
        assert "要確認" in n.sent[0]["body"]
        db.close()

    def test_switches(self, tmp_path):
        db, store = store_for(tmp_path)
        r, n = reporter(store, send_password=False, report_enabled=False)
        (a,) = ticket_requests(store, codes=("05001",), op="provision",
                               category="new_account",
                               user_email="u@example.com")
        done = finish(store, a)
        done.password = "ABCD@234"
        r.handle_completion(done, done, {})
        assert [m["kind"] for m in n.sent] == ["user_registration"]
        r2, n2 = reporter(store, txn_enabled=False)
        r2.handle_completion(done, done, {})
        assert n2.sent == []
        db.close()

    def test_templates_are_editable_files(self, tmp_path):
        from src.modules.notifications.ticket_reports import (
            TicketReportSettings, load_template,
        )
        f = tmp_path / "t.txt"
        f.write_text("Subject: Custom {ticket_id}\n\nHello {ffm_id}\n",
                     encoding="utf-8")
        s = TicketReportSettings(templates={"user_registration": str(f)})
        assert load_template(s, "user_registration") == \
            ("Custom {ticket_id}", "Hello {ffm_id}\n")
        s = TicketReportSettings(templates={"user_registration": "missing.txt"})
        assert "FINES III" in load_template(s, "user_registration")[0]


class TestNotifier:
    def _notifier(self, **kw):
        from src.modules.notifications.config import NotificationSettings
        from src.modules.notifications.notifier import EmailNotifier
        s = NotificationSettings(enabled=True, smtp_host="smtp", mail_from="bot@x",
                                 recipients_to=["ops@x"],
                                 recipients_cc=["internal-dl@x"], dry_run=True,
                                 **kw)
        return EmailNotifier(s)

    def test_raw_subject_and_cc(self):
        n = self._notifier()
        msg = n.build_message("報告(2026/09/28)", "body", to=["a@x"],
                              raw_subject=True, cc=["c@x"])
        assert msg["Subject"] == "報告(2026/09/28)"
        assert msg["Cc"] == "c@x"
        msg = n.build_message("Alert", "body")
        # The product name of the Branding page (2026-09-29, E-04).
        assert msg["Subject"].startswith("[FINES III RPA] [DEVELOPMENT]")
        assert msg["Cc"] == "internal-dl@x"

    def test_user_email_never_shows_internal_cc(self):
        n = self._notifier()
        msg = n.build_message("Notice", "body", to=["user@example.com"])
        assert msg["Cc"] is None

    def test_every_email_audited(self):
        events = []

        class Audit:
            def event(self, category, action, **kw):
                events.append((category, action, kw["detail"]))
        n = self._notifier()
        n.audit = Audit()
        n.send("Notice", "body", to=["kunal.mittal@example.com"],
               kind="user_registration")
        cat, action, detail = events[0]
        assert (cat, action, detail["kind"]) == \
            ("notification", "email_sent", "user_registration")
        assert detail["recipients"] == ["k***@example.com"]


class TestUnconfirmedEmail:
    def test_verification_instead_of_completed(self):
        from src.modules.notifications.transaction_alerts import (
            TransactionAlerter, TransactionNotificationSettings,
        )
        sent = []

        class N:
            def send(self, subject, body, **kw):
                sent.append(subject)
        s = TransactionNotificationSettings(enabled=True)
        t = TransactionAlerter(N(), s, async_send=False)

        class Txn:
            status, result_code, ticket_id, request_id = "done", "UNCONFIRMED", "T1", "r"
            operation, affiliation_code, employee_code = "provision", "1", "2"
            attempt_count, error_message = 1, ""
        t.handle_completion(Txn(), None, {})
        assert len(sent) == 1 and "NOT CONFIRMED" in sent[0]

    def test_sailpoint_success_left_to_the_ticket_report(self):
        from src.modules.notifications.transaction_alerts import (
            TransactionAlerter, TransactionNotificationSettings,
        )
        sent = []

        class N:
            def send(self, subject, body, **kw):
                sent.append(subject)
        t = TransactionAlerter(N(), TransactionNotificationSettings(enabled=True),
                               async_send=False)
        t.ticket_reports_active = True

        class Txn:
            status, result_code, ticket_id, request_id = "done", "O-0000", "T1", "r"
            operation, affiliation_code, employee_code = "deprovision", "1", "2"
            attempt_count, error_message = 1, ""

        class Req:
            metadata = {"category": "termination"}
            password = ""
        t.handle_completion(Txn(), Req(), {})
        assert sent == []
        Req.metadata = {}                  # not a SailPoint ticket
        t.handle_completion(Txn(), Req(), {})
        assert sent and "Deprovisioning completed" in sent[0]


# ── A1, A3, A4, A5 ───────────────────────────────────────────────

class TestStartBanner:
    def test_banner_and_summary(self, capsys, tmp_path):
        from src.core.banner import print_banner
        print_banner(make_config(tmp_path), "background agent starting",
                     extra=[("Console", "http://127.0.0.1:8765")])
        out = capsys.readouterr().out
        assert "Welcome to" in out and "|_|    |___||_|" in out
        assert "background agent starting" in out
        for label in ("Environment", "Driver", "Database", "Dispatcher",
                      "Audit trail", "OCR", "Error rules", "Console"):
            assert label in out

    def test_run_py_uses_the_same_banner(self):
        import run
        from src.core import banner
        assert run._WELCOME is banner.WELCOME


class TestEvidenceRetention:
    def test_only_old_folders_under_the_root(self, tmp_path):
        from src.core.evidence import purge_expired_evidence
        root = tmp_path / "evidence"
        old, new = root / "req_old", root / "req_new"
        for d in (old, new):
            d.mkdir(parents=True)
            (d / "001.png").write_bytes(b"x")
        outside = tmp_path / "keep"
        outside.mkdir()
        (root / "link").symlink_to(outside)
        long_ago = time.time() - 100 * 86400
        for p in (old, old / "001.png"):
            os.utime(p, (long_ago, long_ago))
        assert purge_expired_evidence(root, 90) == ["req_old"]
        assert new.is_dir() and not old.exists() and outside.is_dir()
        assert purge_expired_evidence(root, 0) == []          # 0 keeps all


class TestDriverCheck:
    def test_prerequisites(self, monkeypatch):
        from desktop import deployment
        assert deployment.driver_problem("mock") == ""
        assert deployment.driver_problem("simulator") == ""
        import shutil
        monkeypatch.setattr(shutil, "which", lambda name: None)
        assert "py3270" in deployment.driver_problem("tn3270")
        import sys
        if sys.platform != "win32":
            assert "Windows only" in deployment.driver_problem("pywinauto")
        assert "Unknown" in deployment.driver_problem("teleport")


class TestSignInPage:
    def test_html_answer_is_a_clear_error(self):
        from src.integrations.servicenow.client import (
            ServiceNowClient, ServiceNowError,
        )
        from src.integrations.servicenow.config import ServiceNowSettings

        def handler(request):
            return httpx.Response(200, text="<html>Sign in</html>",
                                  headers={"content-type": "text/html"})
        c = ServiceNowClient(
            ServiceNowSettings(instance_url="https://x", username="u",
                               password="p", max_retries=0),
            transport=httpx.MockTransport(handler), sleep_func=lambda s: None)
        with pytest.raises(ServiceNowError, match="sign-in page"):
            c.fetch_assigned_open()
