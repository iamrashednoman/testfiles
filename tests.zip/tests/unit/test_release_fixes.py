"""Release-readiness fixes from the pre-export review (2026-09-26).

Each test pins one confirmed defect so it cannot come back:
  A1  APP_ENV in finesiii.env selects the configuration class
  A3  --configure reads and DELETES the installer's answers file
  A7  --stop waits for the agent to FINISH, not for the API to go quiet
  A8  only the agent imports the installer's secret hand-off
  A9  the stored DB password is only ever sent to the configured server
  A10 a carriage return cannot inject a key into finesiii.env
  A11 Windows SSO is refused while the service runs as the agent
"""
import os
import threading
import time

import pytest

from tests.conftest import make_config


@pytest.fixture
def data_dir(tmp_path, monkeypatch):
    d = tmp_path / "data"
    d.mkdir()
    monkeypatch.setenv("FINESIII_DATA_DIR", str(d))
    return d


@pytest.fixture
def memory_vault(monkeypatch):
    from desktop import vault
    previous = vault._vault
    store = vault.MemoryVault()
    vault.use_vault(store)
    for k in vault.SECRET_KEYS:
        monkeypatch.delenv(k, raising=False)
    yield store
    vault.use_vault(previous)


class TestA1AppEnvFromDeploymentFile:
    def test_production_in_finesiii_env_selects_production_config(
            self, data_dir, monkeypatch):
        from config import _app_env, get_config
        from config.production import ProductionConfig
        from desktop import deployment
        monkeypatch.delenv("APP_ENV", raising=False)
        deployment.write({"APP_ENV": "production"})
        assert _app_env() == "production"
        get_config.cache_clear()
        try:
            assert isinstance(get_config(), ProductionConfig)
        finally:
            get_config.cache_clear()

    def test_environment_variable_still_wins(self, data_dir, monkeypatch):
        from config import _app_env
        from desktop import deployment
        deployment.write({"APP_ENV": "production"})
        monkeypatch.setenv("APP_ENV", "development")
        assert _app_env() == "development"

    def test_default_without_either(self, data_dir, monkeypatch):
        from config import _app_env
        monkeypatch.delenv("APP_ENV", raising=False)
        assert _app_env() == "development"


class TestA3AnswersFile:
    def test_read_once_and_deleted(self, data_dir, memory_vault):
        from desktop import configure
        ans = data_dir / "install-answers.ini"
        ans.write_text("[secrets]\ndb_password=Db#Secret1\n"
                       "admin_password=Adm1n!Secret\n", encoding="utf-8")
        rc = configure.main(["--answers-file", str(ans),
                             "--db-engine", "sqlite", "--no-check"])
        assert rc == 0
        assert not ans.exists()
        assert memory_vault.get("DATABASE_PASSWORD") == "Db#Secret1"
        assert memory_vault.get("AUTH_DEFAULT_ADMIN_PASSWORD") == "Adm1n!Secret"

    def test_missing_file_is_not_an_error(self, data_dir, memory_vault):
        from desktop import configure
        assert configure.main(["--answers-file", str(data_dir / "none.ini"),
                               "--no-check"]) == 0

    def test_data_dir_flag_sets_the_environment(self, tmp_path, memory_vault,
                                                monkeypatch):
        from desktop import configure, deployment
        target = tmp_path / "elsewhere"
        target.mkdir()
        monkeypatch.delenv("FINESIII_DATA_DIR", raising=False)
        assert configure.main(["--data-dir", str(target),
                               "--set", "LOG_LEVEL=INFO", "--no-check"]) == 0
        assert (target / "finesiii.env").is_file()
        assert deployment.deployment_file() == target / "finesiii.env"


class TestA7StopWaitsForCompletion:
    def test_not_stopped_while_runtime_file_exists(self, data_dir,
                                                   monkeypatch):
        """API quiet but agent.json still present = still draining."""
        from desktop import runtime
        from desktop.agent import stop_running_agent
        runtime.write_runtime(65000, pid=os.getpid())
        calls = {"n": 0}

        def fake_ping(url, timeout=2.0):
            calls["n"] += 1
            return calls["n"] == 1          # alive once, then "quiet"
        monkeypatch.setattr(runtime, "ping", fake_ping)

        def finish_later():
            time.sleep(1.2)
            # What the agent does LAST, in its finally block.
            runtime.remove_runtime()
            runtime.clear_stop_request()
        threading.Thread(target=finish_later, daemon=True).start()
        t0 = time.time()
        assert stop_running_agent(timeout=10) == 0
        assert time.time() - t0 >= 1.0, "reported stopped before the drain ended"

    def test_dead_process_with_stale_file_is_cleaned_up(self, data_dir,
                                                        monkeypatch):
        from desktop import runtime
        from desktop.agent import stop_running_agent
        runtime.write_runtime(65000, pid=2**22 + 12345)   # no such process
        monkeypatch.setattr(runtime, "ping", lambda url, timeout=2.0: True)
        assert stop_running_agent(timeout=5) == 0
        assert runtime.read_runtime() is None

    def test_pid_alive(self):
        from desktop import runtime
        assert runtime.pid_alive(os.getpid())
        assert not runtime.pid_alive(0)
        assert not runtime.pid_alive(2**22 + 12345)


class TestA8OnlyTheAgentImportsTheHandoff:
    def test_window_and_selftest_leave_the_file(self, data_dir, memory_vault,
                                                monkeypatch):
        from desktop import app as app_module, vault
        monkeypatch.delenv("DATABASE_PASSWORD", raising=False)
        vault.write_bootstrap_secrets({"DATABASE_PASSWORD": "for-the-bot"})
        app_module._prepare_environment()                 # window mode
        assert vault.bootstrap_path().exists()
        assert memory_vault.get("DATABASE_PASSWORD") is None
        app_module._prepare_environment(import_bootstrap=True)   # agent
        assert not vault.bootstrap_path().exists()
        assert memory_vault.get("DATABASE_PASSWORD") == "for-the-bot"
        monkeypatch.delenv("DATABASE_PASSWORD", raising=False)


def _client(tmp_path, **overrides):
    from fastapi.testclient import TestClient
    from desktop.server import mount_console_ui
    from src import create_app
    cfg = make_config(tmp_path, dispatcher_enabled=False,
                      terminal_driver="mock",
                      log_dir=str(tmp_path / "logs"), **overrides)
    app = create_app(cfg)
    mount_console_ui(app, mode=overrides.pop("_mode", "agent"))
    return TestClient(app)


def _admin(client):
    client.post("/api/v1/auth/bootstrap",
                json={"username": "alice", "password": "CorrectHorse42"})
    return client.post("/api/v1/auth/login", json={
        "username": "alice", "password": "CorrectHorse42"}
    ).json()["access_token"]


def _auth(t):
    return {"Authorization": f"Bearer {t}"}


class TestA9StoredPasswordStaysHome:
    def test_password_only_for_the_configured_server(self, tmp_path, data_dir,
                                                     memory_vault, monkeypatch):
        from desktop import deployment, system_api
        seen = []

        def fake_check(url, engine="", password="", timeout=5.0):
            seen.append((url, password))
            return {"ok": True, "engine": "postgres", "server": "x",
                    "user": "u", "missing_tables": [], "privileges": {},
                    "error": "", "hint": ""}
        monkeypatch.setattr(deployment, "check_database", fake_check)
        monkeypatch.setenv("DATABASE_PASSWORD", "our-secret")
        with _client(tmp_path, database_url="postgresql://app@db.internal/x"
                     ) as client:
            token = _admin(client)
            client.post("/api/v1/system/test-database", headers=_auth(token),
                        json={"url": "postgresql://app@db.internal/x"})
            client.post("/api/v1/system/test-database", headers=_auth(token),
                        json={"url": "postgresql://app@attacker.example/x"})
        assert seen[0][1] == "our-secret"         # same server: allowed
        assert seen[1][1] == ""                   # other host: never


class TestA10NoLineInjection:
    def test_cr_and_lf_rejected_everywhere(self):
        from desktop import deployment
        from src.modules.console.settings_catalogue import BY_KEY, coerce
        for bad in ("a\rB=1", "a\nB=1"):
            with pytest.raises(ValueError):
                deployment.coerce(deployment.BY_KEY["MAINFRAME_HOST"], bad)
            with pytest.raises(ValueError):
                deployment._quote(bad)
            with pytest.raises(ValueError):
                coerce(BY_KEY["SMTP_HOST"], bad)


class TestA11SsoRefusedUnderTheAgent:
    def test_status_and_route(self, tmp_path, data_dir, memory_vault):
        with _client(tmp_path, auth_windows_sso_enabled=True,
                     _mode="agent") as client:
            assert client.get("/api/v1/auth/status"
                              ).json()["windows_sso_available"] is False
            r = client.post("/api/v1/auth/login/windows")
            assert r.status_code == 403
            assert "background agent" in r.json()["detail"]

    def test_embedded_mode_keeps_the_existing_behaviour(self, tmp_path,
                                                        data_dir,
                                                        memory_vault):
        with _client(tmp_path, auth_windows_sso_enabled=True,
                     _mode="embedded") as client:
            r = client.post("/api/v1/auth/login/windows")
            assert r.status_code != 403 or "background agent" not in r.text

