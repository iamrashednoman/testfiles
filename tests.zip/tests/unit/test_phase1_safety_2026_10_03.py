"""Phase 1 of the console module review (2026-10-03): unsafe settings and
inputs are refused — addresses signed in to, ticket query values, the
mandatory screen reading, the CyberArk certificate check, test replies
and request sizes."""
import pytest

from src.core.urls import web_address_problem
from src.modules.console.settings_catalogue import BY_KEY, coerce


# ── X-07 / CA-01: addresses signed in to ──

@pytest.mark.parametrize("url", [
    "https://example.service-now.com", "https://example.service-now.com/",
    "http://127.0.0.1:8090", "http://localhost:8090", "http://[::1]:8090",
    ""])
def test_accepted_instance_addresses(url):
    assert web_address_problem(url, path_allowed=False) == ""


@pytest.mark.parametrize("url,why", [
    ("http://example.service-now.com", "https://"),
    ("https://user:pw@example.service-now.com", "user name"),
    ("https://example.service-now.com?x=1", "?"),
    ("https://example.service-now.com#frag", "?"),
    ("ftp://example.service-now.com", "https://host"),
    ("example.service-now.com", "https://host"),
    ("https://exa mple.com", "spaces"),
    ("https://example.service-now.com/path", "without a path"),
])
def test_refused_instance_addresses(url, why):
    assert why in web_address_problem(url, path_allowed=False)


def test_token_and_vault_addresses_may_have_a_path():
    assert web_address_problem("https://sn.example.com/oauth_token.do") == ""
    assert "https://" in web_address_problem("http://sn.example.com/x")


@pytest.mark.parametrize("key", ["SNOW_INSTANCE_URL", "SNOW_TOKEN_URL",
                                 "CYBERARK_BASE_URL"])
def test_saving_an_http_address_is_refused(key):
    with pytest.raises(ValueError, match="https://"):
        coerce(BY_KEY[key], "http://evil.example.com")
    assert coerce(BY_KEY[key], "http://127.0.0.1:8090") == \
        "http://127.0.0.1:8090"


# ── SN-01: values placed in the ticket query ──

@pytest.mark.parametrize("key", ["SNOW_ASSIGNED_TO", "SNOW_ASSIGNMENT_GROUP",
                                 "SNOW_REJECT_REASSIGN_GROUP"])
def test_query_values_refuse_operators(key):
    with pytest.raises(ValueError, match="without"):
        coerce(BY_KEY[key], "Group^NQactive=true")
    assert coerce(BY_KEY[key], "Policy Management - JPN") == \
        "Policy Management - JPN"


def test_open_states_and_table():
    assert coerce(BY_KEY["SNOW_OPEN_STATES"], "1, 2, -5") == "1,2,-5"
    with pytest.raises(ValueError):
        coerce(BY_KEY["SNOW_OPEN_STATES"], "1,x^y")
    assert coerce(BY_KEY["SNOW_TABLE"], "sc_task") == "sc_task"
    for bad in ("sc_task;x", "sc_task?a=b", "sc task"):
        with pytest.raises(ValueError, match="table name"):
            coerce(BY_KEY["SNOW_TABLE"], bad)


def _snow(**kw):
    from src.integrations.servicenow.config import ServiceNowSettings
    base = dict(instance_url="https://example.service-now.com",
                username="finesiii.bot", password="pw",
                assignment_mode="assignment_group",
                assignment_group="Policy Management - JPN",
                assigned_to="finesiii.bot", ticket_format="sailpoint")
    base.update(kw)
    return ServiceNowSettings(**base)


def test_settings_from_the_environment_are_checked_as_well():
    """A value set as an environment variable never passes through the
    console, so the connector checks it when it loads."""
    assert _snow().selection_problems() == []
    assert _snow().validate() is True
    for kw, text in (
            ({"instance_url": "http://example.service-now.com"}, "https://"),
            ({"token_url": "https://u:p@x.example/oauth"}, "user name"),
            ({"assignment_group": "G^NQactive=true"}, "not allowed"),
            ({"assigned_to": "bot^ORactive=true"}, "not allowed"),
            ({"reject_reassign_group": "R=1"}, "not allowed"),
            ({"open_states": ["1", "2^NQx"]}, "plain state"),
            ({"table": "sc_task?x"}, "table name")):
        settings = _snow(**kw)
        assert any(text in p for p in settings.selection_problems()), kw
        with pytest.raises(ValueError):
            settings.validate()


def test_the_stand_in_address_still_works():
    assert _snow(instance_url="http://127.0.0.1:8090").validate() is True


# ── CA-01: CyberArk ──

def _vault(**kw):
    from src.integrations.cyberark.config import CyberArkSettings
    base = dict(enabled=True, base_url="https://vault.example.com",
                app_id="A", safe="S", object_name="O")
    base.update(kw)
    return CyberArkSettings(**base)


def test_cyberark_address_and_certificate_check():
    assert _vault().validate(require_verified_tls=True) is True
    with pytest.raises(ValueError, match="https://"):
        _vault(base_url="http://vault.example.com").validate()
    # Certificate checking off: allowed outside production only.
    assert _vault(verify_tls=False).validate() is True
    with pytest.raises(ValueError, match="verify_tls"):
        _vault(verify_tls=False).validate(require_verified_tls=True)


# ── TM-01: screen reading on the real terminal ──

def test_ocr_rule():
    from src.rpa.vision.ocr import ocr_problem
    assert "mandatory" in ocr_problem("pywinauto", False)
    assert ocr_problem("pywinauto", True) == ""
    assert ocr_problem("mock", False) == ""


def test_real_driver_with_ocr_off_does_not_start():
    from src.rpa.vision.ocr import (
        NullOcrEngine, OcrUnavailableError, build_ocr_engine,
    )
    with pytest.raises(OcrUnavailableError, match="mandatory"):
        build_ocr_engine({"enabled": False}, "pywinauto")
    assert isinstance(build_ocr_engine({"enabled": False}, "mock"),
                      NullOcrEngine)


# ── X-08: what a connection test returns ──

def test_test_errors_leave_the_remote_reply_out():
    from desktop.system_api import public_error
    assert public_error("GET https://x/api/now/table/sc_task failed: 401 "
                        "<html>secret page</html>") == \
        "GET https://x/api/now/table/sc_task failed: 401"
    assert public_error("OAuth token request failed: 400 {\"error\": "
                        "\"x\"}") == "OAuth token request failed: 400"
    assert public_error("OAuth token response has no access_token: {'a': 1}"
                        ) == "OAuth token response has no access_token"
    assert public_error("(535, b'5.7.8 Authentication failed')") == \
        "(server reply 535)"
    text = "Network error after 1 attempts: [Errno 111] Connection refused"
    assert public_error(text) == text


# ── EM-02: the password e-mail switch ──

def test_password_switch_is_shown_with_outcome_emails():
    spec = BY_KEY["TXN_INCLUDE_PASSWORD"]
    assert spec["show_when"] == {"key": "TXN_NOTIFICATIONS_ENABLED",
                                 "value": "true"}
    assert "even while the registration notice" in spec["help"]


# ── X-09: request sizes ──

def _limited_app():
    from starlette.applications import Starlette
    from starlette.requests import Request
    from starlette.responses import JSONResponse
    from starlette.routing import Route

    from src.core.body_limit import BodySizeLimit

    async def echo(request: Request):
        return JSONResponse({"size": len(await request.body())})
    app = Starlette(routes=[Route("/api/v1/console/branding", echo,
                                  methods=["PUT"]),
                            Route("/api/v1/requests", echo,
                                  methods=["POST"])])
    app.add_middleware(BodySizeLimit)
    return app


def test_request_size_limits():
    from starlette.testclient import TestClient
    client = TestClient(_limited_app())
    assert client.post("/api/v1/requests", content=b"x" * 1000).json() == \
        {"size": 1000}
    r = client.post("/api/v1/requests", content=b"x" * (300 * 1024))
    assert r.status_code == 413 and "256 KB" in r.json()["detail"]
    # Branding images: up to 2 MB.
    assert client.put("/api/v1/console/branding",
                      content=b"x" * (1500 * 1024)).status_code == 200
    assert client.put("/api/v1/console/branding",
                      content=b"x" * (3 * 1024 * 1024)).status_code == 413


def test_a_body_without_a_length_is_counted_while_read():
    from starlette.testclient import TestClient
    client = TestClient(_limited_app())

    def chunks():
        for _ in range(40):
            yield b"x" * (10 * 1024)
    r = client.post("/api/v1/requests", content=chunks())
    assert r.status_code == 413
