"""Unit tests for the queue store, focused on the approved v3 fixes."""
import pytest

from src.core.db import IntegrityError
from src.modules.intake.models import ProcessingRequest, RequestStatus
from src.modules.queue.services import QueueStore


def make_request(**overrides) -> ProcessingRequest:
    defaults = dict(operation="provision", affiliation_code="30822",
                    employee_code="1217036", password="FUJI@33F")
    defaults.update(overrides)
    return ProcessingRequest(**defaults)


@pytest.fixture
def store(db):
    return QueueStore(db)


class TestFifoAndTransitions:
    def test_fifo_order(self, store):
        first = make_request(employee_code="1000001")
        second = make_request(employee_code="1000002")
        assert store.enqueue(first)
        assert store.enqueue(second)

        claimed = store.dequeue_oldest(worker_id=1)
        assert claimed.request_id == first.request_id
        assert claimed.status == RequestStatus.RUNNING.value
        assert claimed.attempt_count == 1

    def test_cancel_only_queued(self, store):
        req = make_request()
        store.enqueue(req)
        store.dequeue_oldest(worker_id=1)
        assert store.cancel(req.request_id) is False   # running now

    def test_recover_orphaned(self, store):
        req = make_request()
        store.enqueue(req)
        store.dequeue_oldest(worker_id=1)
        assert store.recover_orphaned() == 1
        assert store.get(req.request_id).status == RequestStatus.QUEUED.value

    # ── BUG-003: ownership of running rows per installation ──

    def _running(self, store, worker_id, employee_code, started_at=None):
        req = make_request(employee_code=employee_code)
        store.enqueue(req)
        store.dequeue_oldest(worker_id=worker_id)
        if started_at is not None:
            with store.db.connect() as conn:
                conn.execute("UPDATE request_queue SET started_at = ? "
                             "WHERE request_id = ?",
                             (started_at, req.request_id))
        return req.request_id

    def test_recover_skips_other_instance_recent_row(self, store):
        other = self._running(store, 555555, "1000001")
        out = store.recover_orphans(worker_id=777777, lease_seconds=7200)
        assert out["requeued"] == []
        assert [s["request_id"] for s in out["skipped"]] == [other]
        assert store.get(other).status == RequestStatus.RUNNING.value

    def test_recover_takes_own_and_legacy_rows(self, store):
        own = self._running(store, 777777, "1000001")
        legacy1 = self._running(store, 1, "1000002")
        legacy0 = self._running(store, 0, "1000003")
        assert store.recover_orphaned(worker_id=777777,
                                      lease_seconds=7200) == 3
        for rid in (own, legacy1, legacy0):
            assert store.get(rid).status == RequestStatus.QUEUED.value

    def test_recover_takes_other_instance_row_after_lease(self, store):
        from datetime import timedelta
        from src.modules.intake.models import now_jst
        old = (now_jst() - timedelta(hours=3)).isoformat()
        other = self._running(store, 555555, "1000001", started_at=old)
        assert store.recover_orphaned(worker_id=777777,
                                      lease_seconds=7200) == 1
        assert store.get(other).status == RequestStatus.QUEUED.value

    def test_recover_marks_committed_row_unconfirmed(self, store):
        rid = self._running(store, 1, "1000001")
        out = store.recover_orphans(worker_id=777777, lease_seconds=7200,
                                    committed=lambda r: "/ev/" + r.request_id)
        assert out["unconfirmed"] == [rid] and out["requeued"] == []
        row = store.get(rid)
        assert row.status == RequestStatus.DONE.value
        assert row.result_code == "UNCONFIRMED"
        assert "manual check required" in row.error
        assert row.evidence_path == "/ev/" + rid
        assert row.password == ""

    def test_complete_if_running_ignores_moved_on_row(self, store):
        req = make_request()
        store.enqueue(req)
        assert store.complete_if_running(req.request_id, "done") is False
        assert store.get(req.request_id).status == RequestStatus.QUEUED.value
        store.dequeue_oldest(worker_id=1)
        assert store.complete_if_running(req.request_id, "done",
                                         result_code="O-0000") is True
        assert store.get(req.request_id).status == RequestStatus.DONE.value


class TestIdempotencyFixes:
    def test_active_request_blocks_duplicate(self, store):
        req = make_request(ticket_id="SCTASK001")
        store.enqueue(req)
        dup = store.find_duplicate(make_request(ticket_id="SCTASK001"))
        assert dup is not None and dup.request_id == req.request_id

    def test_failed_request_does_not_block_resubmission(self, store):
        req = make_request(ticket_id="SCTASK002")
        store.enqueue(req)
        store.dequeue_oldest(worker_id=1)
        store.mark_complete(req.request_id, RequestStatus.FAILED.value,
                            error="boom")
        assert store.find_duplicate(make_request(ticket_id="SCTASK002")) is None

    def test_cancelled_request_does_not_block_resubmission(self, store):
        req = make_request(ticket_id="SCTASK003")
        store.enqueue(req)
        store.cancel(req.request_id)
        assert store.find_duplicate(make_request(ticket_id="SCTASK003")) is None

    def test_done_request_still_blocks(self, store):
        req = make_request(ticket_id="SCTASK004")
        store.enqueue(req)
        store.dequeue_oldest(worker_id=1)
        store.mark_complete(req.request_id, RequestStatus.DONE.value)
        assert store.find_duplicate(make_request(ticket_id="SCTASK004")) is not None

    def test_unique_index_blocks_concurrent_duplicate(self, store):
        """The DB constraint catches the TOCTOU race the app check misses."""
        assert store.enqueue(make_request(ticket_id="SCTASK005")) is True
        assert store.enqueue(make_request(ticket_id="SCTASK005")) is False

    def test_unique_index_allows_after_terminal(self, store):
        req = make_request(ticket_id="SCTASK006")
        store.enqueue(req)
        store.dequeue_oldest(worker_id=1)
        store.mark_complete(req.request_id, RequestStatus.FAILED.value)
        assert store.enqueue(make_request(ticket_id="SCTASK006")) is True


class TestPasswordHygiene:
    def test_password_cleared_on_completion(self, store):
        req = make_request(password="Secret88")
        store.enqueue(req)
        store.dequeue_oldest(worker_id=1)
        store.mark_complete(req.request_id, RequestStatus.DONE.value)
        assert store.get(req.request_id).password == ""

    def test_password_cleared_on_cancel(self, store):
        req = make_request(password="Secret88")
        store.enqueue(req)
        store.cancel(req.request_id)
        assert store.get(req.request_id).password == ""


class TestRetryTransition:
    def test_retry_requeues_failed(self, store):
        req = make_request()
        store.enqueue(req)
        store.dequeue_oldest(worker_id=1)
        store.mark_complete(req.request_id, RequestStatus.FAILED.value,
                            error="boom")
        assert store.retry(req.request_id) is True
        after = store.get(req.request_id)
        assert after.status == RequestStatus.QUEUED.value
        assert after.error == "" and after.attempt_count == 0

    def test_retry_rejects_non_failed(self, store):
        req = make_request()
        store.enqueue(req)
        assert store.retry(req.request_id) is False   # still queued
        store.dequeue_oldest(worker_id=1)
        store.mark_complete(req.request_id, RequestStatus.DONE.value)
        assert store.retry(req.request_id) is False   # done is final
