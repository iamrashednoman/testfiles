"""Unit tests for scripts/rpa_cli.py (port of v2 main.py).

Covers the v2 argparse defect fix (--dry-run in BOTH positions), the
provision path through the mock driver, input validation, and the
batch-delete CSV flow with Japanese headers and continue-on-error.
"""
import csv
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
SCRIPTS = ROOT / "scripts"
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))

import rpa_cli  # noqa: E402

from config.development import DevelopmentConfig  # noqa: E402


@pytest.fixture(autouse=True)
def fast_sleep(monkeypatch):
    """The ported workflows keep v2's real terminal pacing; against the
    mock driver those waits are pure wall-clock waste — no-op them."""
    monkeypatch.setattr("time.sleep", lambda s: None)


@pytest.fixture(autouse=True)
def clean_credentials(monkeypatch):
    """Force the sim/mock layouts-test-account credential fallback."""
    for var in ("FINESIII_AFFILIATION_CODE", "FINESIII_APPLICATION_ID",
                "FINESIII_PASSWORD"):
        monkeypatch.delenv(var, raising=False)


@pytest.fixture
def cli_cfg(tmp_path, monkeypatch):
    """Point the CLI at a throwaway config with the mock driver."""
    cfg = DevelopmentConfig(
        _env_file=None,
        terminal_driver="mock",
        evidence_dir=str(tmp_path / "evidence"),
        log_dir=str(tmp_path / "logs"),
        database_engine="sqlite",
        sqlite_path=str(tmp_path / "test.db"),
    )
    monkeypatch.setattr(rpa_cli, "get_config", lambda: cfg)
    return cfg


def forbid_driver(monkeypatch):
    monkeypatch.setattr(
        rpa_cli, "create_driver",
        lambda c: pytest.fail("driver created — workflow must not run"))


class TestDryRun:
    def test_dry_run_before_subcommand(self, cli_cfg, monkeypatch):
        forbid_driver(monkeypatch)
        rc = rpa_cli.main(
            ["--dry-run", "provision", "-a", "30822", "-e", "1217036"])
        assert rc == 0

    def test_dry_run_after_subcommand(self, cli_cfg, monkeypatch):
        """v2 defect: argparse exited 2 when --dry-run followed the
        subcommand. The v3 CLI accepts both positions."""
        forbid_driver(monkeypatch)
        rc = rpa_cli.main(
            ["provision", "-a", "30822", "-e", "1217036", "--dry-run"])
        assert rc == 0

    def test_dry_run_after_deprovision(self, cli_cfg, monkeypatch):
        forbid_driver(monkeypatch)
        rc = rpa_cli.main(
            ["deprovision", "-a", "30822", "-e", "1217036", "--dry-run"])
        assert rc == 0

    def test_dry_run_still_validates(self, cli_cfg, monkeypatch):
        forbid_driver(monkeypatch)
        rc = rpa_cli.main(
            ["--dry-run", "provision", "-a", "30822", "-e", "123"])
        assert rc == 1


class TestProvision:
    def test_success_via_mock_driver(self, cli_cfg, capsys):
        rc = rpa_cli.main(["provision", "-a", "30822", "-e", "1217036",
                           "-p", "FUJI@33F"])
        assert rc == 0
        assert "[OK] PROVISION completed successfully." in \
            capsys.readouterr().out

    def test_password_is_required(self, cli_cfg, monkeypatch):
        """No default password (UAT-L27, 2026-10-04): without -p nothing
        is typed on the terminal."""
        forbid_driver(monkeypatch)
        rc = rpa_cli.main(["provision", "-a", "30822", "-e", "1217036"])
        assert rc == 1

    def test_validation_failure_exits_1(self, cli_cfg, monkeypatch):
        forbid_driver(monkeypatch)
        assert rpa_cli.main(
            ["provision", "-a", "308221", "-e", "1217036"]) == 1  # aff > 5
        assert rpa_cli.main(
            ["provision", "-a", "30822", "-e", "12170"]) == 1     # emp != 7
        assert rpa_cli.main(
            ["provision", "-a", "30822", "-e", "1217036",
             "-p", "short"]) == 1                                 # pw != 8


def write_csv(path, header, rows):
    with open(path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        writer.writerow(header)
        writer.writerows(rows)


def read_results(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


class TestBatchDelete:
    def test_japanese_headers_via_mock_driver(self, cli_cfg, tmp_path,
                                              capsys):
        src = tmp_path / "sailpoint.csv"
        out = tmp_path / "results.csv"
        write_csv(src, ["所属コード", "担当者コード"], [
            ["30822", "1217036"],
            ["822", "1217037"],       # short code — zfilled to 00822
            ["", "1217038"],          # incomplete row — skipped
        ])
        rc = rpa_cli.main(["batch-delete", "-i", str(src), "-o", str(out)])
        assert rc == 0
        rows = read_results(out)
        assert len(rows) == 2
        assert all(r["status"] == "success" for r in rows)
        assert rows[1]["affiliation_code"] == "00822"
        assert rows[0]["employee_code"] == "1217036"
        assert "[OK] Batch: 2 ok, 0 skipped, 0 failed." in \
            capsys.readouterr().out

    def test_continue_on_error_appends_failure_row(self, cli_cfg,
                                                   tmp_path, monkeypatch):
        class FlakyWorkflow:
            def __init__(self, driver, config, logger, evidence):
                pass

            def execute(self, credentials, affiliation_code,
                        employee_code):
                if employee_code == "9999999":
                    raise RuntimeError("terminal hang")
                return {"status": "success", "operation": "deprovision",
                        "employee_code": employee_code,
                        "affiliation_code": affiliation_code,
                        "result_code": "O-0000", "evidence_path": "",
                        "error": None}

        monkeypatch.setattr(
            "src.rpa.workflows.deprovision.DeprovisionWorkflow",
            FlakyWorkflow)
        src = tmp_path / "batch.csv"
        out = tmp_path / "results.csv"
        write_csv(src, ["affiliation_code", "employee_code"], [
            ["30822", "1217036"],
            ["30822", "9999999"],     # raises — synthetic failure row
            ["30822", "1217038"],     # still processed (continue)
        ])
        rc = rpa_cli.main(["batch-delete", "-i", str(src), "-o", str(out)])
        assert rc == 1                # failures present
        rows = read_results(out)
        assert len(rows) == 3
        assert [r["status"] for r in rows] == \
            ["success", "failed", "success"]
        failed = rows[1]
        assert failed["employee_code"] == "9999999"
        assert failed["error"] == "terminal hang"
        assert failed["error_type"] == "system"

    def test_empty_csv_exits_1(self, cli_cfg, tmp_path, monkeypatch):
        forbid_driver(monkeypatch)
        src = tmp_path / "empty.csv"
        write_csv(src, ["affiliation_code", "employee_code"], [])
        with pytest.raises(SystemExit) as exc:
            rpa_cli.main(["batch-delete", "-i", str(src)])
        assert exc.value.code == 1
