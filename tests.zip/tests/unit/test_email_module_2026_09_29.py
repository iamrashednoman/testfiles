"""E-mail module review (2026-09-29): E-01 … E-27.

No network: SMTP is replaced by fakes. The shared test fixture pins
English; the tests of the installed default (Japanese and English) clear
that setting explicitly.
"""
from __future__ import annotations

import json
import logging
import re
import smtplib
import ssl
from datetime import datetime, timedelta
from pathlib import Path
from types import SimpleNamespace

import pytest
import yaml

from src.modules.notifications import audiences, messages
from src.modules.notifications import notifier as notifier_mod
from src.modules.notifications.availability_alerts import (
    COMPONENT_CYBERARK, COMPONENT_SERVICENOW, AvailabilityAlerter,
    DatabaseWatch,
)
from src.modules.notifications.config import (
    NotificationSettings, load_notification_config,
)
from src.modules.notifications.log_handler import (
    EmailAlertHandler, source_of, summary_of,
)
from src.modules.notifications.notifier import (
    EmailNotifier, EncryptionUnavailable, NotificationDeferred,
    NotificationError, template,
)
from src.modules.notifications.outbox import Outbox
from src.modules.notifications.transaction_alerts import (
    ErrorAlertSettings, TransactionAlerter, TransactionNotificationSettings,
)

ROOT = Path(__file__).resolve().parents[2]
I18N = ROOT / "src" / "modules" / "notifications" / "templates" / "i18n"


# ── helpers ─────────────────────────────────────────────────────────

class Sink:
    """A fake SMTP connection that records what is sent."""

    def __init__(self, fail=None, refused=None):
        self.sent, self.fail, self.refused = [], list(fail or []), refused

    def factory(self):
        return self

    def send_message(self, msg, to_addrs=None):
        if self.fail:
            raise self.fail.pop(0)
        self.sent.append((msg, list(to_addrs or [])))
        return self.refused or {}

    def quit(self):
        pass


def settings(**kw):
    base = dict(enabled=True, smtp_host="relay.example.com", smtp_port=25,
                mail_from="finesiii-rpa@example.com",
                recipients_to=["ops@example.com"],
                recipients_cc=["ops-lead@example.com"],
                environment_label="uat", async_send=False,
                digest_interval_seconds=0.0, max_retries=0,
                backoff_base_seconds=0.0, backoff_max_seconds=0.0)
    base.update(kw)
    return NotificationSettings(**base)


def notifier(sink=None, **kw):
    sink = sink or Sink()
    n = EmailNotifier(settings(**kw), smtp_factory=sink.factory,
                      sleep_func=lambda d: None)
    return n, sink


def plain(msg):
    return msg.get_body(("plain",)).get_content()


def html(msg):
    return [p for p in msg.walk()
            if p.get_content_type() == "text/html"][0].get_content()


def txn(**kw):
    base = dict(transaction_id="txn_1", request_id="req_1",
                ticket_id="SCTASK0101", operation="provision",
                affiliation_code="05007", employee_code="5007AAA",
                source="servicenow", status="done", result_code="O-0000",
                error_message="", attempt_count=1,
                submitted_at="2026-09-29T09:00:00+09:00",
                started_at="2026-09-29T09:01:00+09:00",
                completed_at="2026-09-29T09:02:30+09:00",
                duration_seconds=90.0, worker_id=0, screenshot_count=4,
                operator="OPR0001")
    base.update(kw)
    return SimpleNamespace(**base)


@pytest.fixture
def both_languages(monkeypatch):
    monkeypatch.delenv("EMAIL_LANGUAGE", raising=False)


# ── E-05 / E-26: wording file, Japanese and English ────────────────

class TestWording:
    def test_every_entry_has_both_languages_and_the_same_placeholders(self):
        raw = yaml.safe_load((ROOT / "config" / "email_messages.yaml")
                             .read_text(encoding="utf-8"))["email_messages"]
        assert raw["language"] == "ja_en"
        for key, entry in raw["messages"].items():
            assert entry.get("ja") and entry.get("en"), key
            ja = set(re.findall(r"{(\w+)}", entry["ja"]))
            en = set(re.findall(r"{(\w+)}", entry["en"]))
            assert ja == en, key

    def test_default_is_japanese_and_english(self, both_languages):
        assert messages.language() == "ja_en"
        assert messages.label("label.source") == "発生元 / Source"
        assert messages.text("avail.impact.recovered") == \
            "通常の運用を再開しました。\nNormal operation has resumed."
        assert messages.subject("txn.fail.subject", ref="T1") == \
            "処理失敗 / Transaction FAILED — T1"

    @pytest.mark.parametrize("lang,want", [
        ("ja", "処理失敗 — T1"), ("en", "Transaction FAILED — T1")])
    def test_single_language(self, monkeypatch, lang, want):
        monkeypatch.setenv("EMAIL_LANGUAGE", lang)
        assert messages.subject("txn.fail.subject", ref="T1") == want

    def test_an_edited_copy_is_used_and_missing_entries_fall_back(
            self, tmp_path, monkeypatch):
        edited = tmp_path / "email_messages.yaml"
        edited.write_text("email_messages:\n  messages:\n"
                          "    label.source: {ja: 送信元, en: Origin}\n",
                          encoding="utf-8")
        monkeypatch.setattr(messages, "config_path", lambda name: edited)
        assert messages.label("label.source", "en") == "Origin"
        # Not in the edited copy: the shipped wording.
        assert messages.label("label.time", "en") == "Time (JST)"

    def test_unknown_placeholder_is_blank_not_an_error(self):
        assert messages._fill("A {nope} B", "en", {}) == "A  B"


# ── E-01 / designs: every situation has its Japanese/English design ─

class TestDesigns:
    NAMES = ("alert.html", "digest.html", "availability_outage.html",
             "provision_success_ops.html", "deprovision_success_ops.html",
             "transaction_failure.html", "result_unconfirmed.html",
             "error_screen_alert.html", "request_rejected.html",
             "provision_user_credentials.html")

    def test_all_designs_exist_and_are_selected(self):
        for name in self.NAMES:
            assert (I18N / name).is_file(), name
            assert template(name) == str(I18N / name)

    def test_no_english_text_left_in_the_new_designs(self):
        for name in self.NAMES:
            body = (I18N / name).read_text(encoding="utf-8")
            body = re.sub(r"<!--.*?-->", "", body, flags=re.S)
            visible = re.sub(r"<[^>]+>|{{\s*\w+\s*}}|&\w+;", " ", body)
            words = [w for w in visible.split() if w.isalpha()]
            assert words == [], (name, words[:5])

    def test_html_is_on_by_default_on_the_branding_page(self):
        from src.modules.console.branding import DEFAULTS
        assert DEFAULTS["email_html_enabled"] is True

    def test_every_transaction_email_renders_in_both_languages(
            self, both_languages):
        n, sink = notifier()
        n.branding_source = lambda: {"email_html_enabled": True}
        a = TransactionAlerter(n, TransactionNotificationSettings(
            enabled=True, include_password=False), async_send=False)
        a.handle_completion(txn(), SimpleNamespace(
            password="", metadata={"user_email": "user@example.com"}), {})
        a.handle_completion(txn(operation="deprovision"), None, {})
        a.handle_completion(txn(status="failed", error_message="timeout",
                                attempt_count=3), None, {})
        a.handle_completion(txn(result_code="UNCONFIRMED"), None, {})
        assert len(sink.sent) == 5
        for msg, _ in sink.sent:
            body = html(msg)
            assert "{{" not in body and "<!--" not in body
            assert re.search(r"[぀-ヿ一-鿿]", body)
            assert re.search(r"[A-Za-z]{4,}", plain(msg))


# ── E-02: result not confirmed has its own design ──────────────────

class TestResultNotConfirmed:
    def test_own_design_and_never_asks_for_a_retry(self):
        n, sink = notifier()
        n.branding_source = lambda: {"email_html_enabled": True}
        a = TransactionAlerter(n, TransactionNotificationSettings(
            enabled=True), async_send=False)
        a.handle_completion(txn(result_code="UNCONFIRMED",
                                error_message="'70' sent; result not read"),
                            None, {})
        (msg, _), = sink.sent
        text = plain(msg)
        assert "NOT CONFIRMED" in msg["Subject"]
        assert "Do not retry this request" in text
        assert "retried from the console" not in text
        assert "result not read" in text
        assert "Change submitted, result not confirmed" in html(msg)


# ── E-04 / E-06 / E-07 / E-21: subject, environment, time, headers ──

class TestHeaders:
    def test_prefix_from_branding_and_environment_setting(self, monkeypatch):
        n, _ = notifier()
        n.branding_source = lambda: {"product_name": "FINES III RPA"}
        assert n.build_message("X", "b")["Subject"] == "[FINES III RPA] [UAT] X"
        monkeypatch.setenv("EMAIL_ENVIRONMENT_LABEL", "Non-Prod")
        assert n.build_message("X", "b")["Subject"] == \
            "[FINES III RPA] [Non-Prod] X"

    def test_a_prefix_written_in_the_yaml_is_kept(self):
        n, _ = notifier(subject_prefix="[AIG RPA]")
        assert n.build_message("X", "b")["Subject"].startswith("[AIG RPA]")

    def test_automatic_message_headers_and_message_id_domain(self):
        n, _ = notifier()
        msg = n.build_message("X", "b")
        assert msg["Auto-Submitted"] == "auto-generated"
        assert msg["X-Auto-Response-Suppress"] == "All"
        assert msg["Message-ID"].endswith("@example.com>")

    def test_times_in_jst(self):
        assert notifier_mod.fmt_time("2026-09-29T00:02:30+00:00") == \
            "2026-09-29 09:02:30"
        assert notifier_mod.fmt_time("not a time") == "not a time"


# ── E-25 / E-22: connection security, every mode ───────────────────

class FakeServer:
    """Stands in for smtplib.SMTP / SMTP_SSL."""
    instances = []

    def __init__(self, host, port, local_hostname=None, timeout=None,
                 context=None, offers_starttls=True, ssl_mode=False):
        self.host, self.port, self.name = host, port, local_hostname
        self.context, self.ssl_mode = context, ssl_mode
        self.offers = offers_starttls
        self.started = self.logged_in = self.closed = False
        self.esmtp_features = {"size": "10485760", "auth": "LOGIN PLAIN"}
        self.sock = SimpleNamespace(version=lambda: "TLSv1.3")
        FakeServer.instances.append(self)

    def ehlo_or_helo_if_needed(self):
        pass

    def ehlo(self):
        pass

    def has_extn(self, name):
        return name == "starttls" and self.offers

    def starttls(self, context=None):
        if not self.offers:
            raise smtplib.SMTPNotSupportedError(
                "STARTTLS extension not supported by server.")
        self.started = True

    def login(self, user, password):
        self.logged_in = True

    def noop(self):
        return (250, b"OK")

    def send_message(self, msg, to_addrs=None):
        return {}

    def quit(self):
        pass

    def close(self):
        self.closed = True


@pytest.fixture
def servers(monkeypatch):
    FakeServer.instances = []
    offers = {"starttls": True}

    def plain_server(host, port, local_hostname=None, timeout=None):
        return FakeServer(host, port, local_hostname, timeout,
                          offers_starttls=offers["starttls"])

    def ssl_server(host, port, local_hostname=None, timeout=None,
                   context=None):
        return FakeServer(host, port, local_hostname, timeout, context,
                          offers_starttls=False, ssl_mode=True)
    monkeypatch.setattr(notifier_mod.smtplib, "SMTP", plain_server)
    monkeypatch.setattr(notifier_mod.smtplib, "SMTP_SSL", ssl_server)
    return offers


def real(**kw):
    return EmailNotifier(settings(**kw), sleep_func=lambda d: None)


class TestConnectionSecurity:
    def test_loader_defaults_port_25_to_starttls_if_offered(
            self, tmp_path, monkeypatch):
        for k in ("SMTP_SECURITY", "SMTP_USE_STARTTLS", "SMTP_USE_SSL"):
            monkeypatch.delenv(k, raising=False)
        monkeypatch.setenv("SMTP_PORT", "25")
        s = load_notification_config()
        assert s.effective_security == "starttls_if_offered"
        monkeypatch.setenv("SMTP_PORT", "465")
        assert load_notification_config().effective_security == "ssl"
        monkeypatch.setenv("SMTP_PORT", "587")
        assert load_notification_config().effective_security == "starttls"

    def test_console_choice_wins(self, monkeypatch):
        monkeypatch.setenv("SMTP_PORT", "25")
        monkeypatch.setenv("SMTP_SECURITY", "none")
        s = load_notification_config()
        assert s.effective_security == "none"
        assert (s.use_ssl, s.use_starttls) == (False, False)

    def test_explicit_starttls_switch_on_port_25_stays_required(
            self, monkeypatch):
        monkeypatch.delenv("SMTP_SECURITY", raising=False)
        monkeypatch.setenv("SMTP_PORT", "25")
        monkeypatch.setenv("SMTP_USE_STARTTLS", "true")
        assert load_notification_config().effective_security == "starttls"

    def test_relay_offering_starttls_is_encrypted_without_login(
            self, servers):
        info = real(security="starttls_if_offered").check_connection()
        server = FakeServer.instances[-1]
        assert server.started and not server.logged_in
        assert info["encrypted"] and info["tls_version"] == "TLSv1.3"
        assert info["starttls_offered"] is True
        assert info["max_size"] == "10485760"

    def test_relay_without_starttls_still_sends_when_optional(self, servers):
        servers["starttls"] = False
        n = real(security="starttls_if_offered")
        assert n.send("S", "b") is True
        assert FakeServer.instances[-1].started is False

    def test_required_starttls_fails_when_not_offered(self, servers):
        servers["starttls"] = False
        with pytest.raises(smtplib.SMTPNotSupportedError):
            real(security="starttls").check_connection()
        assert FakeServer.instances[-1].closed

    def test_login_never_sent_unencrypted(self, servers):
        servers["starttls"] = False
        with pytest.raises(EncryptionUnavailable):
            real(security="starttls_if_offered", username="svc",
                 password="pw").check_connection()
        assert not FakeServer.instances[-1].logged_in
        with pytest.raises(ValueError):
            settings(security="none", username="svc").validate()

    def test_ssl_mode_and_login(self, servers):
        real(security="ssl", smtp_port=465, username="svc",
             password="pw").check_connection()
        server = FakeServer.instances[-1]
        assert server.ssl_mode and server.logged_in

    def test_certificate_check_can_be_switched_off(self):
        ctx = real(security="starttls", verify_tls=False)._tls_context()
        assert ctx.verify_mode == ssl.CERT_NONE and not ctx.check_hostname
        ctx = real(security="starttls")._tls_context()
        assert ctx.verify_mode == ssl.CERT_REQUIRED and ctx.check_hostname

    def test_ehlo_name_is_passed(self, servers):
        real(security="none", local_hostname="finesiii-bot.corp"
             ).check_connection()
        assert FakeServer.instances[-1].name == "finesiii-bot.corp"


# ── E-17: failures retrying cannot fix are not retried ─────────────

class TestRetries:
    def test_refused_login_is_tried_once(self):
        err = smtplib.SMTPAuthenticationError(535, b"5.7.8 bad credentials")
        n, sink = notifier(Sink(fail=[err] * 4), max_retries=3)
        with pytest.raises(NotificationError) as e:
            n.send("S", "b")
        assert "after 1 attempt" in str(e.value)
        assert isinstance(e.value.__cause__, smtplib.SMTPAuthenticationError)

    def test_temporary_failure_is_retried(self):
        n, sink = notifier(Sink(fail=[smtplib.SMTPServerDisconnected("x")]),
                           max_retries=2)
        assert n.send("S", "b") is True and len(sink.sent) == 1

    def test_partly_refused_recipients_are_recorded(self):
        events = []
        n, _ = notifier(Sink(refused={"gone@example.com": (550, b"no")}))
        n.audit = SimpleNamespace(event=lambda *a, **k: events.append(k))
        n.send("S", "b", to=["ok@example.com", "gone@example.com"])
        assert events[-1]["detail"]["refused"] == ["g***@example.com"]


# ── E-15 / E-18: outbox and delivery state ─────────────────────────

class TestOutbox:
    def _outbox(self, tmp_path, transport, **kw):
        box = Outbox(tmp_path / "outbox", transport, **kw)
        notifier_mod.set_outbox(box)
        return box

    def test_failed_email_is_kept_and_resent(self, tmp_path):
        down = Sink(fail=[OSError("connection refused")])
        n, _ = notifier(down)
        box = self._outbox(tmp_path, n)
        with pytest.raises(NotificationDeferred):
            n.send("Report", "body", kind="support_report")
        assert box.pending() == 1
        assert "E-mail delivery is failing" in notifier_mod.DELIVERY.problem()
        assert "1 e-mail(s) are waiting" in notifier_mod.DELIVERY.problem()
        # The server is back.
        assert box.run_once() == {"sent": 1, "given_up": 0, "waiting": 0}
        assert len(down.sent) == 1 and box.pending() == 0
        assert notifier_mod.DELIVERY.problem() == ""
        msg, to = down.sent[0]
        assert "Report" in msg["Subject"]
        assert to == ["ops@example.com", "ops-lead@example.com"]

    def test_password_email_is_never_written_to_disk(self, tmp_path):
        n, _ = notifier(Sink(fail=[OSError("down")]))
        box = self._outbox(tmp_path, n)
        with pytest.raises(NotificationError) as e:
            n.send("PW", "secret 1234", kind="user_password",
                   redact_body=False)
        assert not isinstance(e.value, NotificationDeferred)
        assert box.pending() == 0
        assert not list((tmp_path / "outbox").glob("*")) \
            if (tmp_path / "outbox").exists() else True

    def test_refused_recipient_is_not_kept(self, tmp_path):
        err = smtplib.SMTPRecipientsRefused({"x@example.com": (550, b"no")})
        n, _ = notifier(Sink(fail=[err]))
        box = self._outbox(tmp_path, n)
        with pytest.raises(NotificationError):
            n.send("S", "b")
        assert box.pending() == 0

    def test_given_up_after_the_window(self, tmp_path):
        events = []
        n, _ = notifier(Sink(fail=[OSError("down")] * 5))
        now = {"t": notifier_mod.now_jst()}
        box = self._outbox(tmp_path, n, keep_hours=24,
                           audit=SimpleNamespace(
                               event=lambda *a, **k: events.append((a, k))),
                           clock=lambda: now["t"])
        with pytest.raises(NotificationDeferred):
            n.send("S", "b")
        assert box.run_once()["waiting"] == 1          # still failing
        now["t"] += timedelta(hours=25)
        assert box.run_once()["given_up"] == 1
        assert box.pending() == 0
        assert events[-1][0][:2] == ("notification", "email_failed")

    def test_kept_across_a_restart(self, tmp_path):
        n, _ = notifier(Sink(fail=[OSError("down")]))
        self._outbox(tmp_path, n)
        with pytest.raises(NotificationDeferred):
            n.send("S", "b")
        up = Sink()
        n2, _ = notifier(up)
        fresh = Outbox(tmp_path / "outbox", n2)       # a new service start
        assert fresh.run_once()["sent"] == 1 and len(up.sent) == 1


# ── E-27: recipients by system ─────────────────────────────────────

class TestAudiences:
    def test_blank_audience_keeps_the_default_recipients(self, monkeypatch):
        monkeypatch.delenv("AUDIENCE_SERVICENOW_TO", raising=False)
        monkeypatch.delenv("AUDIENCE_SERVICENOW_CC", raising=False)
        assert audiences.route("servicenow", ["ops@x.com"], []) == (None, None)

    def test_team_added_to_default_recipients_with_semicolons(
            self, monkeypatch):
        monkeypatch.setenv("AUDIENCE_SERVICENOW_TO",
                           "snow1@example.com; snow2@example.com")
        monkeypatch.setenv("AUDIENCE_SERVICENOW_CC", "snow-lead@example.com")
        to, cc = audiences.route("servicenow", ["ops@example.com"],
                                 ["ops-lead@example.com"])
        assert to == ["snow1@example.com", "snow2@example.com",
                      "ops@example.com"]
        assert cc == ["snow-lead@example.com", "ops-lead@example.com"]

    def test_outage_notice_reaches_the_owning_team(self, monkeypatch):
        monkeypatch.setenv("AUDIENCE_CYBERARK_TO", "iam@example.com")
        n, sink = notifier()
        AvailabilityAlerter(n, async_send=False).cyberark_down("timeout")
        (msg, to), = sink.sent
        assert "iam@example.com" in to and "ops@example.com" in to
        assert "CyberArk Vault Not Available" in msg["Subject"]

    def test_error_rule_goes_to_its_team(self, monkeypatch):
        monkeypatch.setenv("AUDIENCE_FINESIII_TO", "mainframe@example.com")
        n, sink = notifier()
        a = TransactionAlerter(n, TransactionNotificationSettings(
            enabled=True, error_alerts=ErrorAlertSettings(
                enabled=True, rules={"CENTER_NOT_READY": {}})),
            async_send=False)
        a.handle_completion(txn(status="failed", attempt_count=3), None,
                            {"error_id": "CENTER_NOT_READY"})
        (msg, to), = sink.sent
        assert to[0] == "mainframe@example.com" and "ops@example.com" in to
        assert "centre not ready" in msg["Subject"]
        # The shipped rule text (no internal variable names) is used.
        assert "FINESIII_PASSWORD" not in plain(msg)

    def test_rule_text_written_by_the_client_is_kept(self):
        n, sink = notifier()
        a = TransactionAlerter(n, TransactionNotificationSettings(
            enabled=True, error_alerts=ErrorAlertSettings(
                enabled=True, rules={"CENTER_NOT_READY": {
                    "subject": "Host down", "action_required": "Call ops."}})),
            async_send=False)
        a.handle_completion(txn(status="failed"), None,
                            {"error_id": "CENTER_NOT_READY"})
        (msg, _), = sink.sent
        assert "Host down" in msg["Subject"] and "Call ops." in plain(msg)

    def test_shipped_rule_text_is_replaced_by_the_wording_file(self):
        n, sink = notifier()
        old = ("The FINESIII service-account password was rejected on every "
               "attempt. Verify the credential (CyberArk / FINESIII_PASSWORD) "
               "and confirm the account is not locked before re-queuing.")
        a = TransactionAlerter(n, TransactionNotificationSettings(
            enabled=True, error_alerts=ErrorAlertSettings(
                enabled=True, rules={"LOGIN_PASSWORD_INCORRECT": {
                    "action_required": old}})), async_send=False)
        a.handle_completion(txn(status="failed"), None,
                            {"error_id": "LOGIN_PASSWORD_INCORRECT"})
        assert "FINESIII_PASSWORD" not in plain(sink.sent[0][0])


# ── E-12 / E-13 / E-14: generic alerts and the summary ─────────────

def record(msg, path="src/integrations/cyberark/provider.py",
           module="provider", level=logging.ERROR):
    r = logging.LogRecord("finesiii_rpa_v3", level, path, 10, msg, (), None,
                          func="refresh")
    r.module = module
    # A fixed time (2026-10-04 12:34:56 JST): the e-mail shows it, and a
    # current time holding ":10" made the line-number check below fail
    # whenever the clock's minute or second was 10 (2026-10-04).
    r.created = 1791084896.0
    return r


class TestGenericAlerts:
    def test_friendly_subject_and_source(self):
        n, sink = notifier()
        h = EmailAlertHandler(n, n.s)
        h.emit(record("ServiceNow poll failed: HTTPSConnectionPool(host=x)",
                      path="desktop/snow_poller.py", module="snow_poller"))
        (msg, _), = sink.sent
        assert msg["Subject"].endswith("ERROR: ServiceNow poll failed")
        text = plain(msg)
        assert "Source: ServiceNow poller" in text
        assert "snow_poller." not in text and ":10" not in text
        assert "HTTPSConnectionPool" in text          # detail in the body

    def test_dedicated_notice_not_repeated(self):
        n, sink = notifier()
        h = EmailAlertHandler(n, n.s)
        h.dedicated_notices = True
        h.emit(record("CyberArk unavailable — vault Inactive"))
        h.emit(record("ServiceNow poll failed: timeout",
                      path="desktop/snow_poller.py", module="snow_poller"))
        assert sink.sent == []
        h.emit(record("Something else failed"))
        assert len(sink.sent) == 1

    def test_generic_alert_goes_to_the_owning_team(self, monkeypatch):
        monkeypatch.setenv("AUDIENCE_SERVICENOW_TO", "snow@example.com")
        n, sink = notifier()
        EmailAlertHandler(n, n.s).emit(record(
            "ServiceNow ticket SCTASK1 could not be updated",
            path="src/integrations/servicenow/writeback.py",
            module="writeback"))
        assert "snow@example.com" in sink.sent[0][1]

    def test_summary_helpers(self):
        assert summary_of("Dispatcher tick failed: db down") == \
            "Dispatcher tick failed"
        assert summary_of("short: x") == "short: x"
        assert source_of(record("x", path="src/modules/queue/dispatcher.py",
                                module="dispatcher"))[0] == "dispatcher"

    def test_daily_summary_waits_until_nine_jst(self, monkeypatch):
        n, _ = notifier(digest_schedule="daily", digest_time="09:00",
                        mode="both")
        h = EmailAlertHandler(n, n.s)
        fixed = datetime(2026, 9, 29, 8, 30, tzinfo=notifier_mod.JST)
        monkeypatch.setattr(
            "src.modules.notifications.log_handler.now_jst", lambda: fixed)
        assert h._digest_wait() == 1800.0
        h._stop.set()

    def test_summary_off_sends_no_summary(self):
        n, sink = notifier(digest_schedule="off", mode="both")
        h = EmailAlertHandler(n, n.s)
        h.emit(record("A failed"))
        h.close()
        assert len(sink.sent) == 1                    # the alert only


# ── E-10 / E-11: database watch and service notices ────────────────

class TestDatabaseAndService:
    def test_outage_after_two_failures_then_recovery(self):
        n, sink = notifier()
        alerter = AvailabilityAlerter(n, async_send=False)
        state = {"up": False}

        def probe():
            if not state["up"]:
                raise OSError("could not connect to server")
        watch = DatabaseWatch(probe, alerter)
        watch.check_once()
        assert sink.sent == []                        # one blip: no mail
        watch.check_once()
        assert watch.down and "Database Not Available" in \
            sink.sent[-1][0]["Subject"]
        state["up"] = True
        watch.check_once()
        assert not watch.down and "Database Recovered" in \
            sink.sent[-1][0]["Subject"]

    def test_start_with_problems_is_always_emailed(self, tmp_path):
        from src.modules.notifications.service import EmailServices
        n, sink = notifier(outbox_hours=0)
        h = EmailAlertHandler(n, n.s)
        services = EmailServices(h, AvailabilityAlerter(n, async_send=False))
        services.start(["CyberArk integration failed to start: timeout"])
        for t in __import__("threading").enumerate():
            if t.name == "service-notice":
                t.join(5)
        (msg, _), = sink.sent
        assert "started with problems" in msg["Subject"]
        assert "CyberArk integration failed to start" in plain(msg)
        services.stop()

    def test_database_errors_not_repeated_while_the_notice_is_out(self):
        from src.modules.notifications.service import EmailServices
        n, sink = notifier(outbox_hours=0)
        h = EmailAlertHandler(n, n.s)
        services = EmailServices(
            h, AvailabilityAlerter(n, async_send=False),
            queue_store=SimpleNamespace(queue_depth=lambda: {}))
        services.db_watch.down = True
        h.emit(record("Dispatcher tick failed: connection lost",
                      path="src/modules/queue/dispatcher.py",
                      module="dispatcher"))
        assert sink.sent == []


# ── E-16: user notices ─────────────────────────────────────────────

class TestUserNotices:
    def test_failed_password_notice_is_named_in_the_report(self, tmp_path):
        from src.modules.notifications.ticket_reports import (
            NOTICE_MARK, TicketReporter, TicketReportSettings,
        )

        class Picky:
            logger = None

            def __init__(self):
                self.sent = []

            def send(self, subject, body, kind="", **kw):
                if kind == "user_password":
                    raise NotificationError("down")
                self.sent.append((kind, body))
                return True
        n = Picky()
        rep = TicketReporter(n, settings_loader=lambda: TicketReportSettings(
            txn_enabled=True, recipients_to=["support@example.com"],
            send_registration=True, send_password=True), async_send=False)
        req = SimpleNamespace(
            request_id="r1", source="servicenow", operation="provision",
            affiliation_code="05001", employee_code="5004AAA",
            ticket_id="SCTASK9", password="ABCD@234", status="done",
            result_code="O-0000", error="", completed_at="t",
            metadata={"category": "new_account", "parts": 1,
                      "user_email": "user@example.com",
                      "parent_ticket": "SCTASK9"})
        rep.handle_completion(SimpleNamespace(
            status="done", result_code="O-0000", ticket_id="SCTASK9"),
            req, {})
        assert req.metadata[NOTICE_MARK]["password"] == "failed"
        report = [b for k, b in n.sent if k == "support_report"][0]
        assert "パスワード通知を送信できませんでした" in report
        assert "password notice could not be sent" in report


# ── E-19 / E-20: console tests ─────────────────────────────────────

class TestConsoleTests:
    def test_hints(self):
        from src.modules.notifications.diagnostics import explain
        assert "not trusted" in explain(ssl.SSLCertVerificationError(
            "certificate verify failed: unable to get local issuer"))
        assert "does not offer STARTTLS" in explain(
            smtplib.SMTPNotSupportedError("STARTTLS extension not supported"))
        assert "basic authentication" in explain(
            smtplib.SMTPAuthenticationError(535, b"5.7.139 Authentication "
                                                 b"unsuccessful"))
        assert "send-as" in explain(smtplib.SMTPDataError(
            554, b"5.7.60 SMTP; Client does not have permissions to send as "
                 b"this sender"))
        assert "relaying denied" in explain(smtplib.SMTPRecipientsRefused(
            {"a@x.com": (550, b"5.7.1 Unable to relay")}))
        assert "unreachable" in explain(OSError("timed out"))

    def test_test_email_in_the_language_in_force(self, both_languages):
        from src.modules.notifications.diagnostics import send_test_email
        n, sink = notifier(security="none")
        assert send_test_email(n, "admin", ["a@example.com",
                                            "b@example.com"]) is True
        (msg, to), = sink.sent
        assert to == ["a@example.com", "b@example.com"]
        assert "テストメール / Test e-mail" in msg["Subject"]
        assert "なし（暗号化なし）" in plain(msg)


class TestSettingsCatalogue:
    def test_new_email_settings(self):
        from src.modules.console.settings_catalogue import BY_KEY, coerce
        sec = BY_KEY["SMTP_SECURITY"]
        assert set(sec["choices"]) == {"starttls_if_offered", "starttls",
                                       "ssl", "none"}
        assert set(sec["choice_labels"]) == set(sec["choices"])
        assert BY_KEY["SMTP_USE_STARTTLS"]["show_when"] == {
            "key": "SMTP_SECURITY", "value": [""]}
        assert coerce(BY_KEY["AUDIENCE_DATABASE_TO"],
                      "dba1@example.com; dba2@example.com") == \
            "dba1@example.com,dba2@example.com"
        with pytest.raises(ValueError):
            coerce(BY_KEY["AUDIENCE_DATABASE_TO"], "not-an-email")
        assert BY_KEY["EMAIL_LANGUAGE"]["apply"] == "hot"


# ── ET1–ET5: checks for administrators ─────────────────────────────

class TestChecks:
    def test_every_kind_previews_in_every_language(self, monkeypatch):
        from src.modules.notifications import checks
        s = settings()
        for kind in checks.KINDS:
            for lang in ("ja_en", "ja", "en"):
                p = checks.preview(kind, lambda: {"email_html_enabled": True},
                                   language=lang, settings=s)
                assert p["subject"] and p["text"] and "{{" not in p["html"]
        # A preview never changes the language of the real e-mails.
        assert messages.language() == "en"

    def test_preview_leaves_the_delivery_banner_alone(self):
        from src.modules.notifications import checks
        notifier_mod.DELIVERY.failed("relay down")
        checks.preview("test_email", settings=settings())
        assert notifier_mod.DELIVERY.failing()

    def test_one_resend_round_at_a_time(self, tmp_path):
        n, _ = notifier()
        box = Outbox(tmp_path / "o", n)
        box._round.acquire()
        try:
            assert box.run_once()["busy"] is True
        finally:
            box._round.release()
        assert "busy" not in box.run_once()
