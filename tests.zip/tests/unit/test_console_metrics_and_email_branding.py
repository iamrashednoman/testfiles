"""Metrics computation, settings help coverage and e-mail branding
(U6, U8, U9, U12 — 2026-09-28)."""
import base64
from datetime import date

import pytest

from src.modules.console import metrics, settings_help
from src.modules.notifications.config import NotificationSettings
from src.modules.notifications.notifier import (
    BANNER_CID, LOGO_CID, EmailNotifier,
)

PNG = "data:image/png;base64," + base64.b64encode(
    b"\x89PNG\r\n\x1a\n" + b"\x00" * 40).decode()


class TestComputeMetrics:
    ROWS = [
        {"operation": "provision", "source": "servicenow", "status": "done",
         "result_code": "0-0000", "completed_at": "2026-09-27T10:00:00+09:00",
         "duration_seconds": 50, "attempt_count": 1,
         "metadata": '{"category": "new_account"}'},
        {"operation": "deprovision", "source": "servicenow",
         "status": "failed", "result_code": "E-1", "error_message": "x",
         "completed_at": "2026-09-28T11:00:00+09:00",
         "duration_seconds": 0, "attempt_count": 3,
         "metadata": '{"category": "termination"}'},
        {"operation": "provision", "source": "manual", "status": "done",
         "result_code": "UNCONFIRMED",
         "completed_at": "2026-09-28T11:30:00+09:00",
         "duration_seconds": 70, "attempt_count": 1, "metadata": "{}"},
    ]

    def test_figures(self):
        m = metrics.compute_metrics(self.ROWS, date(2026, 9, 27),
                                    date(2026, 9, 28), previous_rows=[])
        k = m["kpis"]
        assert (k["total"], k["succeeded"], k["failed"], k["unconfirmed"]) \
            == (3, 1, 1, 1)
        assert k["success_rate"] == pytest.approx(33.3)
        assert k["retried"] == 1
        assert k["avg_duration_seconds"] == 50.0
        assert [d["day"] for d in m["daily"]] == ["2026-09-27", "2026-09-28"]
        labels = {r["label"] for r in m["by_request_type"]}
        assert labels == {"New account", "Termination", "Provision"}
        assert {f["label"] for f in m["top_failures"]} == {"E-1", "UNCONFIRMED"}
        assert m["by_hour"][11]["count"] == 2
        assert m["kpis"]["previous"]["total"] == 0

    def test_no_rows(self):
        m = metrics.compute_metrics([], date(2026, 9, 28), date(2026, 9, 28))
        assert m["kpis"]["success_rate"] is None
        assert m["kpis"]["avg_duration_seconds"] is None

    def test_reports(self):
        rows = [{"day": "2026-09-28", "category": "auth",
                 "action": "login_failed", "severity": "WARNING", "n": 3},
                {"day": "2026-09-28", "category": "console",
                 "action": "settings_changed", "severity": "WARNING", "n": 1},
                {"day": "2026-09-27", "category": "notification",
                 "action": "email_sent", "severity": "INFO", "n": 5}]
        r = metrics.compute_reports(rows, date(2026, 9, 27), date(2026, 9, 28))
        assert r["kpis"]["failed_sign_ins"] == 3
        assert r["kpis"]["configuration_changes"] == 1
        assert r["kpis"]["emails_sent"] == 5
        assert r["kpis"]["events"] == 9 and r["kpis"]["warnings"] == 4

    def test_csv_guards_formulas(self):
        text = metrics.to_csv([{"a": "=HYPERLINK(1)", "b": {"x": 1}}],
                              ("a", "b"))
        assert text.startswith("﻿")
        assert "'=HYPERLINK(1)" in text


class TestSettingsHelpCoverage:
    def test_catalogue_deployment_and_secrets_all_explained(self):
        from src.modules.console.settings_catalogue import SETTINGS
        from desktop import deployment, vault
        missing = [s["key"] for s in SETTINGS
                   if not settings_help.tooltip(s["key"], s["help"])]
        missing += [d["key"] for d in deployment.DEPLOYMENT_KEYS
                    if not settings_help.tooltip(d["key"], d["help"])]
        missing += [k for k in vault.SECRET_KEYS
                    if not settings_help.tooltip(k)]
        assert not missing, missing

    def test_sections_only_name_known_settings(self):
        from src.modules.console.settings_catalogue import BY_KEY
        assert set(settings_help.SECTIONS) <= set(BY_KEY)


def _notifier(html=False, branding=None):
    s = NotificationSettings(enabled=True, smtp_host="smtp.example.com",
                             mail_from="bot@example.com",
                             recipients_to=["ops@example.com"],
                             html_enabled=html, dry_run=True)
    n = EmailNotifier(s)
    if branding is not None:
        n.branding_source = lambda: branding
    return n


class TestEmailBranding:
    def test_plain_text_only_when_both_switches_are_off(self):
        n = _notifier(branding={"email_html_enabled": False,
                                "email_banner": PNG})
        m = n.build_message("Subject", "Body")
        assert m.get_content_type() == "text/plain"

    def test_branding_page_switch_turns_html_on_with_embedded_banner(self):
        n = _notifier(branding={"email_html_enabled": True,
                                "email_banner": PNG,
                                "email_company_name": "Example Co.",
                                "email_footer_text": "Line 1\nLine 2"})
        m = n.build_message("Subject", "Body <b>not markup</b>")
        types = [p.get_content_type() for p in m.walk()]
        assert types[:2] == ["multipart/alternative", "text/plain"]
        assert "multipart/related" in types and "image/png" in types
        img = [p for p in m.walk() if p.get_content_type() == "image/png"][0]
        assert img["Content-ID"] == f"<{BANNER_CID}>"
        html = [p for p in m.walk()
                if p.get_content_type() == "text/html"][0].get_content()
        assert f"cid:{BANNER_CID}" in html
        assert "&lt;b&gt;not markup&lt;/b&gt;" in html
        assert "Line 1<br>Line 2" in html
        assert "<!--" not in html          # maintainer notes are not sent
        assert "{{" not in html

    def test_logo_is_embedded_only_when_used(self):
        n = _notifier(branding={"email_html_enabled": True,
                                "email_logo": PNG})
        m = n.build_message("Subject", "Body")
        cids = [p["Content-ID"] for p in m.walk()
                if p.get_content_type() == "image/png"]
        assert cids == [f"<{LOGO_CID}>"]

    def test_the_aig_logo_is_embedded_when_none_is_uploaded(self):
        from src.modules.notifications.notifier import DEFAULT_LOGO_PATH
        assert DEFAULT_LOGO_PATH.is_file()
        n = _notifier(branding={"email_html_enabled": True})
        m = n.build_message("Subject", "Body")
        imgs = [p for p in m.walk() if p.get_content_type() == "image/png"]
        assert [p["Content-ID"] for p in imgs] == [f"<{LOGO_CID}>"]
        assert imgs[0].get_content() == DEFAULT_LOGO_PATH.read_bytes()

    def test_a_logo_url_in_notifications_yaml_is_respected(self):
        n = _notifier(html=True)
        n.s.logo_url = "https://intranet.example.com/logo.png"
        m = n.build_message("Subject", "Body")
        assert "image/png" not in [p.get_content_type() for p in m.walk()]

    def test_yaml_switch_still_works_without_console_branding(self):
        m = _notifier(html=True).build_message("Subject", "Body")
        assert "text/html" in [p.get_content_type() for p in m.walk()]

    def test_branding_source_failure_never_blocks_an_email(self):
        n = _notifier(html=True)

        def broken():
            raise RuntimeError("database down")
        n.branding_source = broken
        m = n.build_message("Subject", "Body")
        assert "text/html" in [p.get_content_type() for p in m.walk()]

    def test_header_colour_is_validated(self):
        n = _notifier(branding={"email_html_enabled": True,
                                "email_header_color": "red;x:expression()"})
        html = [p for p in n.build_message("S", "B").walk()
                if p.get_content_type() == "text/html"][0].get_content()
        assert "expression" not in html

    @pytest.mark.parametrize("template", [
        "alert.html", "digest.html", "availability_outage.html",
        "provision_success_ops.html", "deprovision_success_ops.html",
        "transaction_failure.html", "error_screen_alert.html",
        "request_rejected.html", "provision_user_credentials.html",
        "notice.html"])
    def test_every_template_renders_branded(self, template):
        from src.modules.notifications.notifier import _TEMPLATES_DIR
        n = _notifier(branding={"email_html_enabled": True,
                                "email_logo": PNG,
                                "product_name": "FINES III RPA"})
        m = n.build_message("Subject", "Body",
                            template_path=str(_TEMPLATES_DIR / template))
        html = [p for p in m.walk()
                if p.get_content_type() == "text/html"][0].get_content()
        assert f"cid:{LOGO_CID}" in html and "FINES III RPA" in html
        assert "<!--" not in html and "{{" not in html
