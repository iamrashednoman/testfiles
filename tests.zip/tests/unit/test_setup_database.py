"""Setup_Database.py — the parts that need no database server.

The script itself is exercised against real PostgreSQL servers during
release verification; here we pin what decides WHAT it sends and WHAT
it writes: address handling, the statement splitter, the column list
read from scripts/schema.sql, and the settings-file update.
"""
import importlib.util
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location(
    "setup_database", ROOT / "Setup_Database.py")
setup_database = importlib.util.module_from_spec(spec)
spec.loader.exec_module(setup_database)

Address = setup_database.Address
SetupError = setup_database.SetupError


class TestAddress:
    def test_parts_and_defaults(self):
        a = Address("postgresql://finesiii@dbhost/finesiii_v3", "application")
        assert (a.user, a.host, a.port, a.database, a.password) == \
            ("finesiii", "dbhost", 5432, "finesiii_v3", "")

    def test_encoded_password_is_decoded_and_encoded_again(self):
        a = Address("postgresql://app:p%40ss%3Aw%2Frd@h:5433/db",
                    "application")
        assert a.password == "p@ss:w/rd"
        assert a.url() == "postgresql://app:p%40ss%3Aw%2Frd@h:5433/db"

    def test_shown_address_never_carries_the_password(self):
        a = Address("postgresql://app:secret@h:5432/db", "application")
        assert "secret" not in a.shown()
        assert a.shown() == "postgresql://app@h:5432/db"

    def test_options_are_kept(self):
        a = Address("postgresql://app@h:5432/db?sslmode=require",
                    "application")
        assert a.options == {"sslmode": "require"}
        assert a.url().endswith("/db?sslmode=require")

    def test_quotes_pasted_with_the_address_are_ignored(self):
        a = Address("'postgresql://app@h:5432/db'", "application")
        assert a.database == "db"

    def test_administrator_may_omit_the_database(self):
        assert Address("postgresql://postgres@h", "administrator"
                       ).database == "postgres"

    @pytest.mark.parametrize("url, words", [
        ("", "empty"),
        ("mysql://a@b/c", "must start with postgresql://"),
        ("postgresql://h:5432/db", "no login name"),
        ("postgresql://app@/db", "no host name"),
        ("postgresql://app@h:5432", "no database name"),
        ("postgresql://app@h:abc/db", "not a number"),
    ])
    def test_incomplete_addresses_are_refused(self, url, words):
        with pytest.raises(SetupError) as e:
            Address(url, "application")
        assert words in str(e.value)


class TestStatements:
    def test_comments_and_quoted_semicolons(self):
        sql = ("-- a comment; with a semicolon\n"
               "CREATE TABLE a (x TEXT DEFAULT ';');\n"
               "/* block; comment */\n"
               "DO $$ BEGIN PERFORM 1; END $$;\n"
               "SELECT 1")
        parts = setup_database.split_statements(sql)
        assert len(parts) == 3
        assert parts[0] == "CREATE TABLE a (x TEXT DEFAULT ';')"
        assert parts[1].startswith("DO $$") and parts[1].endswith("$$")
        assert parts[2] == "SELECT 1"

    def test_schema_script_yields_the_six_tables_and_no_grants(self):
        statements = setup_database.schema_statements(
            setup_database.CORE_SCHEMA)
        assert not any(s.upper().startswith(("GRANT", "REVOKE"))
                       for s in statements)
        tables = {setup_database.statement_table(s) for s in statements
                  if s.upper().startswith("CREATE TABLE")}
        assert tables == set(setup_database.REQUIRED_TABLES)

    def test_index_statements_name_their_table(self):
        assert setup_database.statement_table(
            "CREATE UNIQUE INDEX IF NOT EXISTS i ON request_queue (a) "
            "WHERE status IN ('queued')") == "request_queue"
        assert setup_database.statement_table(
            "CREATE INDEX IF NOT EXISTS i ON public.app_users (a)") == \
            "app_users"

    def test_expected_columns_match_what_the_application_reads(self):
        columns = setup_database.expected_columns(
            setup_database.schema_statements(setup_database.CORE_SCHEMA))
        assert set(columns) == set(setup_database.REQUIRED_TABLES)
        queue = columns["request_queue"]
        assert {"request_id", "password", "next_attempt_at",
                "metadata"} <= set(queue)
        assert queue["metadata"] == "TEXT DEFAULT '{}'"
        assert "primary" not in queue

    def test_privileges_cover_exactly_the_required_tables(self):
        assert set(setup_database.PRIVILEGES) == \
            set(setup_database.REQUIRED_TABLES)
        assert "DELETE" not in setup_database.PRIVILEGES["request_queue"]
        assert set(setup_database.PRIVILEGES["transaction_history"]) == \
            {"SELECT", "INSERT"}


class TestSettingsFile:
    def test_values_replaced_everything_else_kept(self, tmp_path):
        env = tmp_path / ".env"
        env.write_text("# settings\nAPP_ENV=development\n"
                       "DATABASE_ENGINE=sqlite\n"
                       "# DATABASE_URL=postgresql://old:<password>@h/db\n"
                       "OCR_ENABLED=false\n", encoding="utf-8")
        written = setup_database.update_env_file(env, {
            "DATABASE_ENGINE": "postgres",
            "DATABASE_URL": "postgresql://app:pw@h:5432/db"},
            after="DATABASE_ENGINE")
        assert written == ["DATABASE_ENGINE", "DATABASE_URL"]
        assert env.read_text(encoding="utf-8").splitlines() == [
            "# settings", "APP_ENV=development",
            "DATABASE_ENGINE=postgres",
            "DATABASE_URL=postgresql://app:pw@h:5432/db",
            "OCR_ENABLED=false"]

    def test_second_run_changes_nothing(self, tmp_path):
        env = tmp_path / ".env"
        changes = {"DATABASE_ENGINE": "postgres",
                   "DATABASE_URL": "postgresql://app:pw@h:5432/db"}
        setup_database.update_env_file(env, changes)
        before = env.read_bytes()
        assert setup_database.update_env_file(env, changes) == []
        assert env.read_bytes() == before

    def test_duplicates_collapse_and_line_endings_are_kept(self, tmp_path):
        env = tmp_path / ".env"
        env.write_bytes(b"DATABASE_ENGINE=sqlite\r\nA=1\r\n"
                        b"DATABASE_ENGINE=postgres\r\n")
        setup_database.update_env_file(env, {"DATABASE_ENGINE": "postgres"})
        assert env.read_bytes() == b"DATABASE_ENGINE=postgres\r\nA=1\r\n"

    def test_byte_order_mark_does_not_hide_the_first_key(self, tmp_path):
        env = tmp_path / ".env"
        env.write_bytes(b"\xef\xbb\xbfDATABASE_ENGINE=sqlite\n")
        setup_database.update_env_file(env, {"DATABASE_ENGINE": "postgres"})
        assert env.read_bytes() == b"DATABASE_ENGINE=postgres\n"

    def test_missing_file_is_created(self, tmp_path):
        env = tmp_path / ".env"
        setup_database.update_env_file(env, {"DATABASE_ENGINE": "postgres"})
        assert env.read_text(encoding="utf-8").strip() == \
            "DATABASE_ENGINE=postgres"


class TestExplanations:
    @pytest.mark.parametrize("message, words", [
        ('FATAL: password authentication failed for user "a"',
         "password of 'app' is not correct"),
        ('FATAL: no pg_hba.conf entry for host "10.0.0.1"',
         "pg_hba.conf"),
        ('FATAL: database "db" does not exist', "--admin-url"),
        ("connection refused", "cannot be reached"),
        ("server does not support SSL, but SSL was required", "sslmode"),
    ])
    def test_server_messages_get_a_plain_explanation(self, message, words):
        a = Address("postgresql://app:secret@h:5432/db", "application")
        text = setup_database.explain(Exception(message), a)
        assert words in text and "secret" not in text
