"""Sim terminal replica: state-machine and screen-text contract tests.

The Canvas visuals are presentational; what the bot logic depends on is
(a) the navigation state machine and (b) the identifier strings in
get_screen_text(). Both are pinned here.
"""
import pytest

from src.rpa.drivers.sim_terminal import SimTerminalDriver


@pytest.fixture(autouse=True)
def fast_sleep(monkeypatch):
    """The exit-sequence echo holds enforce absolute minimum pauses —
    no-op them so driver tests stay instant."""
    monkeypatch.setattr("time.sleep", lambda s: None)


def make_driver(scenario="success"):
    driver = SimTerminalDriver()
    driver.initialize({"mock_scenario": scenario,
                       "sim_action_delay": 0.0})
    return driver


class TestNavigationStateMachine:
    def test_double_10_matches_real_app(self):
        """Real app: launch → menu (7801) → '10' → menu again (7802)
        → '10' → FINESⅢ login (7803)."""
        d = make_driver()
        d.launch_application()
        assert d.screen == "core_menu"
        d.submit_command("10")
        assert d.screen == "menu_2"
        d.submit_command("10")
        assert d.screen == "login"

    def test_login_field_focus_and_submit(self):
        d = make_driver()
        d.launch_application()
        d.submit_command("10")
        d.submit_command("10")

        # Navigator sequence: type + Enter per credential field
        d.type_text("9903325")
        d.press_key("enter")
        d.type_text("12N3940")
        d.press_key("enter")
        d.type_text("TEST0000")
        d.press_key("enter")

        assert d._login_fields == ["9903325", "12N3940", "TEST0000"]
        assert d._login_focus == 3          # command line

        d.submit_command("00")
        assert d.screen == "business_menu"

    def test_task_table_tracks_deprovision_entry(self):
        """The FID table fills exactly like the real 006 photo:
        101=4, 104 skipped (blank for delete), 105=affiliation,
        106=employee, 107/111/112 skipped."""
        d = make_driver()
        d.launch_application()
        for cmd in ("10", "10", "00", "903"):
            d.submit_command(cmd)
        assert d.screen == "task_903"

        d.press_key("enter")            # FID 100 → row 101
        d.type_text("4")                # 処理区分 = 削除
        d.press_key("enter")
        d.press_key("enter")            # 104 audit — blank for delete
        d.type_text("30822")            # 105 所属コード
        d.press_key("enter")
        d.type_text("1558877")          # 106 社員コード
        d.press_key("enter")
        d.press_key("enter")            # 107 password — blank
        d.press_key("enter")            # 111 date — blank
        d.press_key("enter")            # 112 administrator — blank

        assert d._task_values == {"101": "4", "105": "30822",
                                  "106": "1558877"}

        # Values survive onto the confirmation screen; a cancel wipes
        d.submit_command("00")
        assert d.screen == "confirmation"
        assert d._task_values["106"] == "1558877"
        d.submit_command("99")
        assert d._task_values == {}

    def test_full_provision_path(self):
        d = make_driver()
        d.launch_application()
        for cmd in ("10", "10", "00", "903", "00", "70", "10", "10"):
            d.submit_command(cmd)
        assert d.screen == "print_done"

    def test_exit_sequence_walks_back_through_real_screens(self):
        """navigator.exit_application's 99s must be VISIBLE: print →
        fresh entry screen → 業務MENU → login (leftover affiliation)
        → menu window → XX → システム終了."""
        d = make_driver()
        d.launch_application()
        d.submit_command("10")
        d.submit_command("10")
        d.type_text("9903325")
        d.press_key("enter")
        d.type_text("12N3940")
        d.press_key("enter")
        d.type_text("TEST0000")
        d.press_key("enter")
        for cmd in ("00", "903"):
            d.submit_command(cmd)
        d.press_key("enter")
        d.type_text("4")                      # some entry data
        d.press_key("enter")
        for cmd in ("00", "70", "10"):
            d.submit_command(cmd)
        assert d.screen == "print_done"

        expected = ["task_903", "business_menu", "login",
                    "menu_2", "core_menu"]
        for want in expected:
            d.submit_command("99")
            assert d.screen == want, f"99 should land on {want}"

        # Entry data was wiped for the fresh entry screen on the way out
        assert d._task_values == {}
        # Leftover login affiliation still shown on the login screen
        assert d._login_fields[0] == "9903325"

        d.submit_command("99")                # extra 99 on the menu
        assert d.screen == "core_menu"        # harmless no-op
        d.submit_command("XX")
        assert d.screen == "logout"
        assert d._exit_caption == ""          # cleared for システム終了

    def test_exit_captions_narrate_each_step(self):
        d = make_driver()
        d.launch_application()
        for cmd in ("10", "10", "00", "903", "00", "70", "10"):
            d.submit_command(cmd)
        assert d._exit_caption == ""          # forward nav: no caption
        d.submit_command("99")
        assert "エントリー画面" in d._exit_caption
        d.submit_command("99")
        assert "業務MENU" in d._exit_caption
        d.submit_command("99")
        assert "ログイン画面" in d._exit_caption

    def test_goto_first_field_and_exit_animates_clear(self):
        """Fix A: the navigator's real-driver branch runs — the sim
        anchors to the affiliation field, clears the leftover code,
        types 99 there, and the menu window returns."""
        d = make_driver()
        d.launch_application()
        d.submit_command("10")
        d.submit_command("10")
        d.type_text("9903325")
        d.press_key("enter")
        d.type_text("12N3940")
        d.press_key("enter")
        d.type_text("TEST0000")
        d.press_key("enter")
        d.submit_command("00")
        # walk back to the login screen as exit_application does
        d.submit_command("903")
        d.submit_command("99")
        d.submit_command("99")
        assert d.screen == "login"
        assert d._login_fields[0] == "9903325"   # leftover code

        d.goto_first_field_and_exit("99", 7, 4)
        assert d.screen == "menu_2"              # FINESⅢ window closed
        assert d._login_fields[0] == "99"        # exit code was typed
        assert d.commands[-1] == "99"
        # navigator.exit_application will take this branch now
        assert hasattr(d, "goto_first_field_and_exit")


class TestScreenTextContract:
    """get_screen_text() must keep the ScreenState identifiers."""

    CASES = {
        "core_menu": ["基幹業務", "端末業務選択", "Z1966"],
        "menu_2": ["基幹業務", "端末業務選択", "Z1966"],
        "login": ["所属コード", "担当者コード", "パスワード",
                  "P200HAAPROC"],
        "business_menu": ["FINESⅢ", "業務MENU", "業務ＮＯ"],
        "task_903": ["00903", "パスワードDBの更新と追加", "処理確認"],
        "print": ["下記の用紙をセットして下さい", "用紙コード", "帳票名称"],
        "print_done": ["プリント済", "用紙コード"],
    }

    @pytest.mark.parametrize("screen,identifiers",
                             sorted(CASES.items()))
    def test_identifiers_present(self, screen, identifiers):
        d = make_driver()
        d.screen = screen
        text = d.get_screen_text()
        for ident in identifiers:
            assert ident in text, f"{screen} lost identifier {ident!r}"

    def test_result_codes(self):
        d = make_driver()
        d.screen = "result"
        assert "O-0000" in d.get_screen_text()
        d = make_driver(scenario="error")
        d.screen = "result"
        assert "E-9901" in d.get_screen_text()


class TestCanvasRendering:
    """Smoke test: every screen paints without error (skipped where no
    display is available)."""

    def test_all_screens_render(self):
        tk = pytest.importorskip("tkinter")
        import tkinter.font as tkfont
        from src.rpa.drivers import sim_screens

        try:
            root = tk.Tk()
        except tk.TclError:
            pytest.skip("no display available")
        try:
            root.withdraw()
            jp = sim_screens.pick_jp_font(tkfont)
            canvas = tk.Canvas(root, width=sim_screens.WINDOW_W,
                               height=sim_screens.WINDOW_H)
            for screen in ("blank", "core_menu", "menu_2", "login",
                           "business_menu", "task_903", "confirmation",
                           "result", "print", "print_done", "logout"):
                sim_screens.render(canvas, {
                    "screen": screen, "scenario": "success",
                    "input_buffer": "10", "status_line": "test",
                    "login_fields": ["9903325", "12N3940", "TEST0000"],
                    "login_focus": 2,
                    "last_affiliation": "30822",
                    "last_employee": "1217036",
                }, jp)
                assert canvas.find_all(), f"{screen} painted nothing"
            # already_deleted + error variants
            for scenario in ("already_deleted", "error"):
                sim_screens.render(canvas, {
                    "screen": "confirmation" if scenario ==
                    "already_deleted" else "result",
                    "scenario": scenario, "input_buffer": "",
                    "login_fields": ["", "", ""], "login_focus": 0,
                }, jp)
                assert canvas.find_all()
        finally:
            root.destroy()
