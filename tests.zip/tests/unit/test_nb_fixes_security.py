"""Security and configuration fixes of the 28 September retest (group 3):
NB-002, NB-005, NB-006, NB-009, NB-010, NB-019, NB-024 and the one-line
start-up errors."""
from __future__ import annotations

import pytest

from tests.conftest import make_config


@pytest.fixture
def data_dir(tmp_path, monkeypatch):
    d = tmp_path / "data"
    d.mkdir()
    monkeypatch.setenv("FINESIII_DATA_DIR", str(d))
    return d


@pytest.fixture
def memory_vault(monkeypatch):
    from desktop import vault
    previous = vault._vault
    store = vault.MemoryVault()
    vault.use_vault(store)
    for k in vault.SECRET_KEYS:
        monkeypatch.delenv(k, raising=False)
    yield store
    vault.use_vault(previous)


@pytest.fixture
def fresh_config():
    """get_config() is cached; every test here reads it anew."""
    from config import get_config
    get_config.cache_clear()
    yield get_config
    get_config.cache_clear()


# ── NB-006: masking of secrets in logs and diagnostics ──

LOG = "2026-09-28 10:00:00 | INFO     | "


class TestMaskSecrets:
    @pytest.mark.parametrize("text,expected", [
        ('password: "alpha beta gamma"', 'password: "*****"'),
        (LOG + "password='alpha beta' x=1", LOG + "password='*****' x=1"),
        (LOG + "password=abc;def next", LOG + "password=***** next"),
        (LOG + "password=abc&def", LOG + "password=*****"),
        ("Authorization: Basic dXNlcjpwYXNz", "Authorization: Basic *****"),
        ("{'Authorization': 'Basic dXNl'}", "{'Authorization': 'Basic *****'}"),
        ("初期パスワード：Secret123", "初期パスワード：*****"),
        ("暗証番号: 1234", "暗証番号: *****"),
        ("パスワード　：　Abc", "パスワード　：　*****"),
        ("passphrase=hello", "passphrase=*****"),
        (LOG + "db_pass: x1", LOG + "db_pass: *****"),
        ("pass=x", "pass=*****"),
        ("SNOW_PASS=abc", "SNOW_PASS=*****"),
        ("DB_PASSPHRASE=a b c", "DB_PASSPHRASE=*****"),
        ('{"password": "a \\"b\\" c", "user": "u"}',
         '{"password": "*****", "user": "u"}'),
    ])
    def test_masked(self, text, expected):
        from desktop.system_api import mask_secrets
        assert mask_secrets(text) == expected

    @pytest.mark.parametrize("text", [
        "compass=north", "bypass=1", "passed=3 failed=0", "COMPASS_DIR=/x",
        "BYPASS_PROXY=1", "Password rejected for user X",
        "HTTP Basic authentication failed", "Authorization failed for user x",
        "パスワードの変更に失敗しました",
        "Loaded 3 secret(s) from the keyring vault: DATABASE_PASSWORD, "
        "SMTP_PASSWORD",
        "Email alerts ACTIVE — enabled=True host=smtp.example.com:587 "
        "STARTTLS user=bot pw=*** from=a@example.com",
        "Ignoring stored setting ALERT_TO: the stored value is not valid "
        "(re-enter it on the settings page)",
    ])
    def test_left_alone(self, text):
        from desktop.system_api import mask_secrets
        assert mask_secrets(text) == text

    def test_structure_keys(self):
        from desktop.system_api import _mask_obj
        out = _mask_obj({"db_pass": "a", "passphrase": "b", "パスワード": "c",
                         "暗証番号": "d", "compass": "north",
                         "bypass": "yes"})
        assert out == {"db_pass": "*****", "passphrase": "*****",
                       "パスワード": "*****", "暗証番号": "*****",
                       "compass": "north", "bypass": "yes"}


# ── NB-002: a URL that cannot be read is masked all the same ──

class TestMaskUrl:
    @pytest.mark.parametrize("url", [
        "postgresql://u:Pw#9secret@db:5432/f",
        "postgresql://u:Pw?9secret@db:5432/f",
        "postgresql://u:Pw/9secret@db:5432/f",
    ])
    def test_unreadable_password_masked(self, url):
        from desktop.vault import mask_url
        out = mask_url(url)
        assert "9secret" not in out and "Pw" not in out
        assert out == "postgresql://*****@db:5432/f"

    def test_non_numeric_port_does_not_raise(self):
        from desktop.vault import mask_url
        out = mask_url("postgresql://u:hidden@db:abc/f")
        assert "hidden" not in out

    def test_normal_url(self):
        from desktop.vault import mask_url
        assert mask_url("postgresql://app:S3cret@db:5432/f") == \
            "postgresql://app@db:5432/f"
        assert mask_url("postgresql://app@db/f") == "postgresql://app@db/f"
        assert mask_url("") == ""

    def test_check_url_parts_is_public(self):
        from desktop import deployment
        with pytest.raises(ValueError) as e:
            deployment.check_url_parts("Database URL",
                                       "postgresql://u:Pw#9@h:5432/db")
        assert "percent-encode" in str(e.value)
        deployment.check_url_parts("Database URL",
                                   "postgresql://u:Pw%239@h:5432/db")


# ── NB-009: invalid configuration values named at start ──

class TestConfigValidation:
    @pytest.mark.parametrize("field,value,name,allowed", [
        ("terminal_driver", "foo", "TERMINAL_DRIVER", "pywinauto"),
        ("database_engine", "mysql", "DATABASE_ENGINE", "postgres, sqlite"),
    ])
    def test_unknown_value_names_setting(self, field, value, name, allowed):
        from pydantic import ValidationError

        from config.development import DevelopmentConfig
        with pytest.raises(ValidationError) as e:
            DevelopmentConfig(_env_file=None, **{field: value})
        text = str(e.value)
        assert f"{name} must be one of" in text and allowed in text
        assert repr(value) in text

    def test_audit_backend_checked_only_when_enabled(self):
        from pydantic import ValidationError

        from config.development import DevelopmentConfig
        cfg = DevelopmentConfig(_env_file=None, audit_enabled=False,
                                audit_backend="oracle")
        assert cfg.audit_backend == "oracle"
        with pytest.raises(ValidationError) as e:
            DevelopmentConfig(_env_file=None, audit_enabled=True,
                              audit_backend="oracle")
        assert "AUDIT_BACKEND must be one of: postgres, sqlite" in str(e.value)

    def test_window_across_midnight_refused(self):
        from pydantic import ValidationError

        from config.development import DevelopmentConfig
        with pytest.raises(ValidationError) as e:
            DevelopmentConfig(_env_file=None,
                              availability_window_start="22:00",
                              availability_window_end="06:00")
        text = str(e.value)
        assert "AVAILABILITY_WINDOW_START (22:00)" in text
        assert "AVAILABILITY_WINDOW_END (06:00)" in text
        assert "across midnight is not supported" in text

    def test_every_driver_list_is_the_same(self):
        from config.base import TERMINAL_DRIVERS
        from desktop import deployment
        assert deployment._DRIVERS == list(TERMINAL_DRIVERS)
        assert deployment.BY_KEY["TERMINAL_DRIVER"]["choices"] == \
            list(TERMINAL_DRIVERS)

    def test_get_config_raises_one_line(self, monkeypatch, data_dir,
                                        fresh_config):
        from config import ConfigError
        monkeypatch.setenv("APP_ENV", "development")
        monkeypatch.setenv("TERMINAL_DRIVER", "foo")
        with pytest.raises(ConfigError) as e:
            fresh_config()
        text = str(e.value)
        assert "\n" not in text
        assert text.startswith("Configuration is not valid: TERMINAL_DRIVER "
                               "must be one of:")
        assert "finesiii.env" in text
        assert isinstance(e.value, RuntimeError)

    def test_agent_start_prints_one_fatal_line(self, monkeypatch, capsys,
                                               data_dir, memory_vault,
                                               fresh_config):
        from desktop import agent, app
        monkeypatch.setenv("APP_ENV", "development")
        monkeypatch.setenv("TERMINAL_DRIVER", "foo")
        started = []
        monkeypatch.setattr(agent.AgentRunner, "run",
                            lambda self: started.append(1) or 0)
        assert app.main(["--agent"]) == 1
        assert started == []
        err = capsys.readouterr().err
        fatal = [line for line in err.splitlines() if "[FATAL]" in line]
        assert len(fatal) == 1 and "TERMINAL_DRIVER" in fatal[0]
        assert "Traceback" not in err


# ── NB-005: a database that cannot be reached, in one line ──

class TestStartupLine:
    def test_database_line_names_the_deployment_file(self, tmp_path,
                                                     monkeypatch, data_dir):
        from psycopg_pool import PoolTimeout

        from src.core.banner import startup_error_line
        monkeypatch.chdir(tmp_path)                 # no .env here
        monkeypatch.delenv("DATABASE_URL", raising=False)
        cfg = make_config(tmp_path, database_engine="postgres",
                          database_url="postgresql://u:hidden@db:5432/f")
        line = startup_error_line(
            PoolTimeout("couldn't get a connection after 30.00 sec"), cfg)
        assert "\n" not in line
        assert line.startswith("The database cannot be reached "
                               "(postgresql://u:***@db:5432/f): couldn't get")
        assert "DATABASE_URL in " in line and "finesiii.env" in line
        assert "--configure --db-url" in line and "hidden" not in line

    def test_environment_variable_named(self, tmp_path, monkeypatch):
        from src.core.banner import startup_error_line
        monkeypatch.setenv("DATABASE_URL", "postgresql://u@db:5432/f")
        cfg = make_config(tmp_path, database_engine="postgres",
                          database_url="postgresql://u@db:5432/f")
        line = startup_error_line(ConnectionRefusedError("refused"), cfg)
        assert "Correct the DATABASE_URL environment variable" in line

    def test_other_errors_first_line(self, tmp_path):
        from src.core.banner import startup_error_line
        assert startup_error_line(ValueError("bad thing\nmore"),
                                  make_config(tmp_path)) == "bad thing"


class TestAgentStart:
    def _runner(self, tmp_path, **overrides):
        from desktop.agent import AgentRunner
        cfg = make_config(tmp_path, terminal_driver="mock", **overrides)
        return AgentRunner(cfg, cfg_factory=lambda: cfg, poll_seconds=0.05)

    def test_start_failure_is_one_line(self, tmp_path, monkeypatch, capsys,
                                       data_dir):
        from psycopg_pool import PoolTimeout

        from desktop import runtime
        from desktop.server import EmbeddedService
        monkeypatch.chdir(tmp_path)
        monkeypatch.delenv("SQLITE_PATH", raising=False)

        def fail(self, port=0):
            raise PoolTimeout("couldn't get a connection after 30.00 sec")
        monkeypatch.setattr(EmbeddedService, "start", fail)
        runner = self._runner(tmp_path)
        assert runner.run() == 1
        err = capsys.readouterr().err
        fatal = [line for line in err.splitlines() if "[FATAL]" in line]
        assert len(fatal) == 1
        assert "The database cannot be reached" in fatal[0]
        assert "finesiii.env" in fatal[0]
        assert "Traceback" not in err
        # The lock is released: a second agent may start.
        from desktop.agent import agent_lock_path
        from desktop.single_instance import SingleInstance
        assert not SingleInstance.is_held(agent_lock_path())
        assert runtime.read_runtime() is None

    def test_unreachable_server_stops_before_the_service(self, tmp_path,
                                                         monkeypatch,
                                                         capsys, data_dir):
        from desktop.server import EmbeddedService
        monkeypatch.chdir(tmp_path)
        monkeypatch.delenv("DATABASE_URL", raising=False)
        monkeypatch.delenv("DATABASE_PASSWORD", raising=False)
        called = []
        monkeypatch.setattr(EmbeddedService, "start",
                            lambda self, port=0: called.append(1))
        runner = self._runner(tmp_path, database_engine="postgres",
                              database_url="postgresql://u@127.0.0.1:1/db")
        assert runner.run() == 1
        assert called == []
        err = capsys.readouterr().err
        assert err.count("[FATAL]") == 1
        assert "The database cannot be reached (postgresql://u@127.0.0.1:1/db)"\
            in err
        assert "Traceback" not in err


# ── NB-010: STARTTLS + implicit SSL stored by an earlier version ──

class TestTlsConflict:
    @pytest.fixture
    def store(self, cfg, monkeypatch):
        from src.core.db import Database
        from src.modules.console.settings_store import SettingsStore
        for k in ("SMTP_PORT", "SMTP_USE_SSL", "SMTP_USE_STARTTLS"):
            monkeypatch.delenv(k, raising=False)
        db = Database.from_config(cfg)
        yield SettingsStore(db)
        db.close()

    def _both(self, store):
        store.set("SMTP_USE_STARTTLS", "true")
        store.set("SMTP_USE_SSL", "true")

    def test_port_465_keeps_ssl(self, store, cfg, monkeypatch):
        import os

        from src.modules.console.settings_store import (
            apply_overrides, resolve_tls_conflict,
        )
        self._both(store)
        store.set("SMTP_PORT", "465")
        apply_overrides(cfg, store)
        fix = resolve_tls_conflict(store)
        assert fix == {"port": 465, "switched_off": "SMTP_USE_STARTTLS"}
        assert store.all()["SMTP_USE_STARTTLS"] == "false"
        assert store.all()["SMTP_USE_SSL"] == "true"
        assert os.environ["SMTP_USE_STARTTLS"] == "false"
        row = next(r for r in store.rows() if r["key"] == "SMTP_USE_STARTTLS")
        assert row["updated_by"] == "system (upgrade)"

    def test_port_587_keeps_starttls(self, store, cfg):
        import os

        from src.modules.console.settings_store import (
            apply_overrides, resolve_tls_conflict,
        )
        self._both(store)
        apply_overrides(cfg, store)
        fix = resolve_tls_conflict(store)
        assert fix == {"port": 587, "switched_off": "SMTP_USE_SSL"}
        assert store.all()["SMTP_USE_SSL"] == "false"
        assert os.environ["SMTP_USE_SSL"] == "false"

    def test_only_one_on_is_left_alone(self, store, cfg):
        from src.modules.console.settings_store import (
            apply_overrides, resolve_tls_conflict,
        )
        store.set("SMTP_USE_SSL", "true")
        store.set("SMTP_USE_STARTTLS", "false")
        apply_overrides(cfg, store)
        assert resolve_tls_conflict(store) is None
        assert store.all()["SMTP_USE_SSL"] == "true"

    def test_restored_environment_after_clear(self, store, cfg, monkeypatch):
        """The value from before the console changed it is still what a
        later apply restores (the override tracking stays correct)."""
        import os

        from src.modules.console.settings_store import (
            _restore_env_overrides, apply_overrides, resolve_tls_conflict,
        )
        monkeypatch.setenv("SMTP_USE_SSL", "true")
        self._both(store)
        apply_overrides(cfg, store)
        resolve_tls_conflict(store)
        assert os.environ["SMTP_USE_SSL"] == "false"
        _restore_env_overrides()
        assert os.environ["SMTP_USE_SSL"] == "true"


# ── NB-024: an invalid stored value is listed ──

class TestInvalidAtBuild:
    def test_listed_and_cleared_per_build(self, cfg, monkeypatch):
        from src.core.db import Database
        from src.modules.console.settings_store import (
            SettingsStore, apply_overrides, invalid_at_build,
        )
        monkeypatch.delenv("ALERT_TO", raising=False)
        db = Database.from_config(cfg)
        try:
            store = SettingsStore(db)
            store.set("ALERT_TO", "a@x.example Bcc: other@x.example")
            apply_overrides(cfg, store)
            assert invalid_at_build() == ["ALERT_TO"]
            store.clear("ALERT_TO")
            apply_overrides(cfg, store)
            assert invalid_at_build() == []
        finally:
            db.close()


# ── NB-019: the moved password leaves no trace in the database file ──

class TestPurge:
    def test_no_password_bytes_left(self, tmp_path, cfg, memory_vault,
                                    monkeypatch):
        from desktop import vault
        from src.core.db import Database
        from src.modules.console.settings_store import SettingsStore
        monkeypatch.delenv("SMTP_PASSWORD", raising=False)
        db = Database.from_config(cfg)
        try:
            store = SettingsStore(db)
            # Some other rows, so the page is shared as in a real install.
            for i in range(20):
                store.set(f"OTHER_{i}", f"value-{i}")
            store.set("SMTP_PASSWORD", "UNIQUE-Pw-123")
            assert vault.migrate_legacy_setting_secrets(store) == \
                ["SMTP_PASSWORD"]
            assert memory_vault.get("SMTP_PASSWORD") == "UNIQUE-Pw-123"
            assert "SMTP_PASSWORD" not in store.all()
            assert store.all()["OTHER_3"] == "value-3"
        finally:
            db.close()
        path = cfg.sqlite_path
        data = b""
        for suffix in ("", "-wal"):
            try:
                with open(path + suffix, "rb") as f:
                    data += f.read()
            except FileNotFoundError:
                pass
        assert data
        assert b"UNIQUE-Pw-123" not in data

    def test_postgres_uses_a_normal_delete(self):
        from src.modules.console.settings_store import SettingsStore
        store = SettingsStore.__new__(SettingsStore)

        class FakeDb:
            engine = "postgres"
            sqlite_path = ""
            def execute(self, sql, params=()):
                self.sql = sql
                return 1
        import threading
        store.db, store._lock = FakeDb(), threading.Lock()
        assert store.purge("SMTP_PASSWORD") is True
        assert store.db.sql.startswith("DELETE FROM app_settings")
