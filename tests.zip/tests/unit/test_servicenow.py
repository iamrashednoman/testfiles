"""Unit tests for the ServiceNow integration (port of v2).

Pure/no-network: the client is exercised through httpx.MockTransport with
an injected sleep function, mirroring the v2 test approach.
"""
import httpx
import pytest

from src.integrations.servicenow.config import ServiceNowSettings
from src.integrations.servicenow.client import ServiceNowClient, ServiceNowError
from src.integrations.servicenow.mapper import (
    map_ticket, reasons_skipped, parse_description, enrich_ticket,
    generate_initial_password, _normalize_operation, PASSWORD_LENGTH,
)

# Mapping mirroring the placeholder config/servicenow.yaml
FLAT_MAP = {
    "ticket_number": "number",
    "operation": "u_operation",
    "affiliation_code": "u_affiliation_code",
    "employee_code": "u_employee_code",
    "password": "u_initial_password",
}


def make_settings(**overrides):
    base = dict(
        instance_url="https://dev12345.service-now.com",
        auth_method="basic", username="svc_bot", password="secret",
        table="sc_task", open_states=["1", "2"], max_per_poll=25,
        order_by="sys_created_on", fields=["sys_id", "number", "u_operation"],
        field_mapping={"operation": "u_operation"},
        max_retries=3, backoff_base_seconds=0.01, backoff_max_seconds=0.05,
    )
    base.update(overrides)
    return ServiceNowSettings(**base)


class TestBuildQuery:
    def test_assigned_to_dot_walk_for_username(self):
        # Non-sys_id identity → dot-walk to the user record's user_name
        s = make_settings(assigned_to="rpa.bot.account")
        q = s.build_query()
        assert "assigned_to.user_name=rpa.bot.account" in q
        assert "active=true" in q
        assert "stateIN1,2" in q
        assert q.endswith("ORDERBYsys_created_on")

    def test_assigned_to_sys_id_uses_reference_match(self):
        s = make_settings(assigned_to="b" * 32)
        q = s.build_query()
        assert "assigned_to=" + "b" * 32 in q
        assert "assigned_to.user_name" not in q

    def test_blank_bot_account_is_no_assignee_filter(self):
        # An empty Bot account adds no condition on the assignee; the
        # sign-in user name is only who the tickets are assigned to.
        s = make_settings()
        assert "assigned_to" not in s.build_query()
        assert s.effective_assigned_to == "svc_bot"
        assert s.assigns_before_queueing

    def test_bot_account_entered_is_the_filter(self):
        s = make_settings()
        s.assigned_to = "svc_bot"
        assert "assigned_to.user_name=svc_bot" in s.build_query()
        s.bot_sys_id = "a" * 32
        assert f"assigned_to={'a' * 32}" in s.build_query()
        assert not s.assigns_before_queueing


class TestMapper:
    def test_happy_path_provision(self):
        ticket = {
            "number": "SCTASK0012345",
            "u_operation": "provision",
            "u_affiliation_code": "30822",
            "u_employee_code": "1217036",
            "u_initial_password": "FUJI@33F",
        }
        out = map_ticket(ticket, FLAT_MAP)
        assert out["operation"] == "provision"
        assert out["affiliation_code"] == "30822"
        assert out["employee_code"] == "1217036"
        assert out["password"] == "FUJI@33F"
        assert out["source"] == "servicenow"
        assert out["ticket_id"] == "SCTASK0012345"

    def test_happy_path_deprovision(self):
        ticket = {"number": "SCTASK0067890", "u_operation": "deprovision",
                  "u_affiliation_code": "02783", "u_employee_code": "A5Z1159"}
        out = map_ticket(ticket, FLAT_MAP)
        assert out["operation"] == "deprovision"
        assert out["affiliation_code"] == "02783"
        assert out["employee_code"] == "A5Z1159"
        assert out["password"] == ""          # not provided → empty

    def test_operation_synonyms(self):
        assert _normalize_operation("create") == "provision"
        assert _normalize_operation("add") == "provision"
        assert _normalize_operation("delete") == "deprovision"
        assert _normalize_operation("terminate") == "deprovision"
        assert _normalize_operation("frobnicate") == ""
        ticket = {"number": "T1", "u_operation": "create",
                  "u_affiliation_code": "30822", "u_employee_code": "1217036"}
        assert map_ticket(ticket, FLAT_MAP)["operation"] == "provision"

    def test_affiliation_zero_padded(self):
        ticket = {"number": "T1", "u_operation": "provision",
                  "u_affiliation_code": "822", "u_employee_code": "1217036"}
        assert map_ticket(ticket, FLAT_MAP)["affiliation_code"] == "00822"

    def test_missing_employee_code_returns_none_and_reason(self):
        ticket = {"number": "T1", "u_operation": "provision",
                  "u_affiliation_code": "30822"}
        assert map_ticket(ticket, FLAT_MAP) is None
        reason = reasons_skipped(ticket, FLAT_MAP)
        assert "employee_code" in reason
        assert "affiliation_code" not in reason

    def test_metadata_redacts_password_keys(self):
        ticket = {"number": "T1", "u_operation": "provision",
                  "u_affiliation_code": "30822", "u_employee_code": "1217036",
                  "u_initial_password": "FUJI@33F",
                  "variables": {"api_token_ref": "tok-123", "note": "keep"}}
        out = map_ticket(ticket, FLAT_MAP)
        details = out["metadata"]["snow_details"]
        assert details["u_initial_password"] == "****"
        assert details["variables"]["api_token_ref"] == "****"
        assert details["variables"]["note"] == "keep"
        assert out["password"] == "FUJI@33F"   # intact in the dedicated field


class TestDescriptionParsing:
    def test_full_width_colon_parsed(self):
        text = ("Operation：provision\n"
                "Affiliation Code：30822\n"
                "FFM Application ID：1217036\n")
        parsed = parse_description(text)
        assert parsed == {"operation": "provision",
                          "affiliation_code": "30822",
                          "employee_code": "1217036"}

    def test_enrich_then_map_via_parsed_namespace(self):
        parsed_map = {"ticket_number": "number",
                      "operation": "parsed.operation",
                      "affiliation_code": "parsed.affiliation_code",
                      "employee_code": "parsed.employee_code"}
        ticket = {"number": "INC0010001",
                  "description": "Operation: provision\n"
                                 "Affiliation Code: 822\n"
                                 "FFM ID: 1217036"}
        enriched = enrich_ticket(ticket, {"enabled": True})
        out = map_ticket(enriched, parsed_map)
        assert out["operation"] == "provision"
        assert out["affiliation_code"] == "00822"
        assert out["employee_code"] == "1217036"


class TestPasswordGeneration:
    def test_rules(self):
        for _ in range(50):
            pw = generate_initial_password()
            assert len(pw) == PASSWORD_LENGTH == 8
            assert pw[0].isalpha() and pw[0].isupper()
            assert any(c.isdigit() for c in pw)
            assert all(c.isupper() or c.isdigit() for c in pw)

    def test_generator_used_for_provision_without_password(self):
        ticket = {"number": "T1", "u_operation": "provision",
                  "u_affiliation_code": "30822", "u_employee_code": "1217036"}
        out = map_ticket(ticket, FLAT_MAP,
                         password_generator=generate_initial_password)
        assert len(out["password"]) == 8


class TestClientRetry:
    def test_429_honors_retry_after_then_succeeds(self):
        calls = {"n": 0}
        slept = []

        def handler(request: httpx.Request) -> httpx.Response:
            calls["n"] += 1
            if calls["n"] == 1:
                return httpx.Response(429, headers={"Retry-After": "2"},
                                      json={"error": "rate limited"})
            return httpx.Response(200, json={"result": [{"number": "OK"}]})

        client = ServiceNowClient(make_settings(),
                                  transport=httpx.MockTransport(handler),
                                  sleep_func=lambda d: slept.append(d))
        out = client.fetch_assigned_open()
        assert calls["n"] == 2
        assert out[0]["number"] == "OK"
        assert slept and slept[0] >= 2.0       # Retry-After respected

    def test_400_raises_immediately(self):
        calls = {"n": 0}

        def handler(request):
            calls["n"] += 1
            return httpx.Response(400, text="bad request")

        client = ServiceNowClient(make_settings(),
                                  transport=httpx.MockTransport(handler),
                                  sleep_func=lambda d: None)
        with pytest.raises(ServiceNowError):
            client.fetch_assigned_open()
        assert calls["n"] == 1                  # no retry on 4xx
