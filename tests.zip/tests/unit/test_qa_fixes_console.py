"""Console fixes (QA 2026-09-28): reports counting, branding upload
checks and messages, and the record of configuration overrides."""
import base64
from datetime import date

import pytest

from config.development import DevelopmentConfig
from src.core.db import Database
from src.modules.console import branding, metrics
from src.modules.console.settings_store import (
    SettingsStore, _restore_env_overrides, applied_at_build, apply_overrides,
    original_value,
)
from tests.conftest import make_config

PNG = b"\x89PNG\r\n\x1a\n" + b"\x00" * 40
JPEG = b"\xff\xd8\xff\xe0" + b"\x00" * 40
GIF = b"GIF89a" + b"\x00" * 40
WEBP = b"RIFF\x00\x00\x00\x00WEBPVP8 " + b"\x00" * 40


def _url(kind: str, data: bytes) -> str:
    return f"data:image/{kind};base64," + base64.b64encode(data).decode()


class TestReportsCountWhereEventsAreRecorded:
    """BUG-059: user and role events are recorded under 'auth', machine
    settings and credentials under 'system'."""

    def test_account_and_configuration_changes(self):
        rows = [{"day": "2026-09-28", "category": "auth",
                 "action": "user_created", "severity": "WARNING", "n": 2},
                {"day": "2026-09-28", "category": "system",
                 "action": "secret_changed", "severity": "WARNING", "n": 1}]
        k = metrics.compute_reports(rows, date(2026, 9, 28),
                                    date(2026, 9, 28))["kpis"]
        assert k["account_changes"] == 2
        assert k["configuration_changes"] == 1

    def test_roles_and_console_events_still_counted(self):
        rows = [{"day": "2026-09-28", "category": "auth",
                 "action": a, "severity": "WARNING", "n": 1}
                for a in ("role_created", "role_updated", "role_deleted",
                          "user_updated", "user_deleted")]
        rows += [{"day": "2026-09-28", "category": "console",
                  "action": "settings_changed", "severity": "WARNING",
                  "n": 1},
                 {"day": "2026-09-28", "category": "system",
                  "action": "deployment_changed", "severity": "WARNING",
                  "n": 1},
                 # A sign-in is not an account change.
                 {"day": "2026-09-28", "category": "auth",
                  "action": "login_succeeded", "severity": "INFO", "n": 4}]
        k = metrics.compute_reports(rows, date(2026, 9, 28),
                                    date(2026, 9, 28))["kpis"]
        assert k["account_changes"] == 5
        assert k["configuration_changes"] == 2


class TestBrandingContentCheck:
    """BUG-036: the image content decides, not the declared type."""

    def test_text_file_declared_png_is_refused(self):
        with pytest.raises(ValueError, match="not a PNG, JPEG, GIF or WebP"):
            branding.validate({"logo": _url("png", b"just some text")})

    def test_new_svg_is_refused(self):
        svg = _url("svg+xml", b"<svg onload='alert(1)'></svg>")
        with pytest.raises(ValueError, match="SVG"):
            branding.validate({"logo": svg})

    @pytest.mark.parametrize("kind,data", [("png", PNG), ("jpeg", JPEG),
                                           ("gif", GIF), ("webp", WEBP)])
    def test_each_raster_type_is_accepted(self, kind, data):
        doc = branding.validate({"login_background": _url(kind, data)})
        assert doc["login_background"].startswith(f"data:image/{kind};")

    def test_jpeg_declared_png_is_stored_as_jpeg(self):
        doc = branding.validate({"logo": _url("png", JPEG)})
        assert doc["logo"].startswith("data:image/jpeg;base64,")
        assert base64.b64decode(doc["logo"].split(",", 1)[1]) == JPEG

    def test_webp_content_refused_for_email_images(self):
        with pytest.raises(ValueError, match="e-mail"):
            branding.validate({"email_logo": _url("png", WEBP)})

    def test_unchecked_fields_keep_a_stored_svg(self):
        svg = _url("svg+xml", b"<svg></svg>")
        doc = branding.validate({"logo": svg, "tagline": "x"},
                                content_keys=set())
        assert doc["logo"] == svg


class TestBrandingSizeMessage:
    """BUG-076: the size is never rounded down to the limit."""

    def test_one_byte_over_shows_one_decimal_and_bytes(self):
        data = PNG + b"\x00" * (200 * 1024 + 1 - len(PNG))
        with pytest.raises(ValueError) as e:
            branding.validate({"logo": _url("png", data)})
        text = str(e.value)
        assert "at most 200 KB (204,800 bytes)" in text
        assert "this file is 200.1 KB (204,801 bytes)" in text

    def test_exactly_the_limit_is_accepted(self):
        data = PNG + b"\x00" * (200 * 1024 - len(PNG))
        assert branding.validate({"logo": _url("png", data)})["logo"]


class TestConfigOverrideRecord:
    """BUG-054: a configuration override applied to a configuration
    object is recorded, and undone by the next apply to that object."""

    @pytest.fixture
    def store(self, tmp_path):
        db = Database.from_config(make_config(tmp_path))
        yield SettingsStore(db)
        _restore_env_overrides()
        db.close()

    def test_record_and_restore(self, store):
        cfg = DevelopmentConfig(_env_file=None)
        store.set("max_attempts", "2")
        apply_overrides(cfg, store)
        assert cfg.max_attempts == 2
        assert applied_at_build(cfg) == {"max_attempts": 2}
        assert original_value(cfg, "max_attempts") == 3

        store.clear("max_attempts")
        apply_overrides(cfg, store)
        assert cfg.max_attempts == 3
        assert applied_at_build(cfg) == {}
        assert original_value(cfg, "max_attempts") == 3

    def test_unknown_object_has_no_record(self):
        cfg = DevelopmentConfig(_env_file=None)
        assert applied_at_build(cfg) == {}
        assert original_value(cfg, "max_attempts") == cfg.max_attempts
