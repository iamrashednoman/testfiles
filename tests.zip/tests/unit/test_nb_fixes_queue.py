"""Retest round 2 — queue and terminal (NB-001, NB-003, NB-004, NB-013)
and the commit detection of the sim-terminal launcher."""
from __future__ import annotations

import json
import threading
import time
from datetime import timedelta
from types import SimpleNamespace

import pytest

from src.core.evidence import EvidenceCapture
from src.core.retry import RetryPolicy
from src.modules.intake.models import ProcessingRequest, now_jst
from src.rpa.config import build_rpa_config
from src.rpa.credentials import FINESIIICredentials
from src.rpa.drivers.mock import MockDriver
from src.rpa.screens.navigator import Navigator
from src.rpa.workflows.deprovision import DeprovisionWorkflow
from src.rpa.workflows.provision import ProvisionWorkflow
from tests.conftest import make_config

CREDS = FINESIIICredentials("03325", "12N3940", "TEST0000")


@pytest.fixture(autouse=True)
def fast_sleep(monkeypatch):
    monkeypatch.setattr("time.sleep", lambda s: None)


@pytest.fixture
def qenv(tmp_path):
    from src.core.db import Database
    from src.modules.audit.services import TransactionStore
    from src.modules.queue.services import QueueStore
    cfg = make_config(tmp_path)
    db = Database.from_config(cfg)
    try:
        yield cfg, QueueStore(db), TransactionStore(db)
    finally:
        db.close()


class _Audit:
    def __init__(self):
        self.events, self.transactions = [], []

    def event(self, category, action, **kw):
        self.events.append((action, kw.get("severity")))

    def transaction(self, txn):
        self.transactions.append(txn)


class _Exec:
    def __init__(self, results=None):
        self.results = list(results or [])
        self.calls = []

    def execute(self, request):
        self.calls.append(request.request_id)
        if self.results:
            return dict(self.results.pop(0))
        return {"status": "success", "result_code": "O-0000", "error": ""}


def _dispatcher(qenv, tmp_path, executor=None, **kw):
    from src.modules.queue.dispatcher import Dispatcher
    cfg, q, t = qenv
    kw.setdefault("pending_path", tmp_path / "pending_completions.jsonl")
    kw.setdefault("sleep", lambda s: None)
    return Dispatcher(q, t, kw.pop("retry_policy", RetryPolicy(max_attempts=3)),
                      executor=executor or _Exec(), cfg=cfg, **kw)


def _enqueue(q, operation="provision", **kw):
    r = ProcessingRequest(operation=operation, affiliation_code="30822",
                          employee_code=kw.pop("employee_code", "1217036"),
                          password="Abc@1234", **kw)
    q.enqueue(r)
    return r.request_id


def _snow(ticket, created, sys_id="a1b2c3"):
    return {"source": "servicenow", "ticket_id": ticket,
            "metadata": {"snow_details": {"sys_id": sys_id, "number": ticket,
                                          "sys_created_on": created}}}


def _make_due(q, rid):
    with q.db.connect() as conn:
        conn.execute("UPDATE request_queue SET next_attempt_at = '' "
                     "WHERE request_id = ?", (rid,))


def _history(t):
    return t.list_transactions(limit=100)


class _Spy:
    def __init__(self, fn):
        self.fn, self.kwargs = fn, {}

    def __call__(self, *a, **kw):
        self.kwargs = kw
        return self.fn(*a, **kw)


# ── NB-001: an older ticket never undoes a newer one ─────────────────


def _closeout(q, **settings):
    from src.integrations.servicenow.config import ServiceNowSettings
    from src.integrations.servicenow.writeback import TicketCloseout
    s = ServiceNowSettings(instance_url="https://example.service-now.com",
                           **settings)
    co = TicketCloseout(settings_loader=lambda: s, async_send=False,
                        sleep_func=lambda d: None)
    co.queue_store = q
    return co, s


class TestSupersededBeforeExecution:
    def test_older_retry_after_newer_opposite_is_not_executed(
            self, qenv, tmp_path):
        cfg, q, t = qenv
        co, _ = _closeout(q)
        add = _enqueue(q, "provision", **_snow("SCTASK1", "2026-09-28 06:00:00"))
        remove = _enqueue(q, "deprovision",
                          **_snow("SCTASK2", "2026-09-28 06:30:00", "d4e5f6"))
        executor = _Exec([{"status": "failed", "error_type": "system",
                           "error": "centre not ready"}])
        superseded, audit = [], _Audit()
        d = _dispatcher(qenv, tmp_path, executor=executor, audit=audit,
                        superseded_check=co.superseded_reason,
                        on_superseded=lambda r, why: superseded.append(
                            (r.request_id, why)))
        assert d._tick() is True                  # older Add fails, retry
        assert q.get(add).status == "queued"
        assert d._tick() is True                  # newer Remove runs
        assert q.get(remove).status == "done"
        _make_due(q, add)
        assert d._tick() is True                  # older Add retried
        row = q.get(add)
        assert row.status == "cancelled"
        assert row.error.startswith("Superseded: a newer ticket SCTASK2 "
                                    "(deprovision)")
        assert row.password == ""
        assert executor.calls == [add, remove]    # terminal never reached
        assert superseded == [(add, row.error[len("Superseded: "):])]
        assert ("request_superseded_before_execution", "WARNING") \
            in audit.events

    def test_older_runs_while_newer_is_only_queued(self, qenv, tmp_path):
        cfg, q, t = qenv
        co, _ = _closeout(q)
        add = _enqueue(q, "provision", **_snow("SCTASK1", "2026-09-28 06:00:00"))
        _enqueue(q, "deprovision",
                 **_snow("SCTASK2", "2026-09-28 06:30:00", "d4e5f6"))
        executor = _Exec()
        d = _dispatcher(qenv, tmp_path, executor=executor,
                        superseded_check=co.superseded_reason)
        assert d._tick() is True
        assert executor.calls == [add]
        assert q.get(add).status == "done"

    def test_newer_ticket_is_not_superseded_by_an_older_one(self, qenv):
        cfg, q, t = qenv
        co, _ = _closeout(q)
        old = _enqueue(q, "provision", **_snow("SCTASK1", "2026-09-28 06:00:00"))
        q.dequeue_oldest(worker_id=1)
        q.mark_complete(old, "done", result_code="O-0000")
        new = _enqueue(q, "deprovision",
                       **_snow("SCTASK2", "2026-09-28 06:30:00", "d4e5f6"))
        assert co.superseded_reason(q.get(new)) == ""

    def test_manual_or_undated_requests_are_never_superseded(self, qenv):
        cfg, q, t = qenv
        co, _ = _closeout(q)
        newer = _enqueue(q, "deprovision",
                         **_snow("SCTASK2", "2026-09-28 06:30:00", "d4e5f6"))
        q.dequeue_oldest(worker_id=1)
        q.mark_complete(newer, "done", result_code="O-0000")
        manual = _enqueue(q, "provision", ticket_id="M-1",
                          metadata={"snow_details": {
                              "sys_created_on": "2026-09-28 06:00:00"}})
        undated = _enqueue(q, "provision", source="servicenow",
                           ticket_id="SCTASK3",
                           metadata={"snow_details": {"sys_id": "x"}})
        assert co.superseded_reason(q.get(manual)) == ""
        assert co.superseded_reason(q.get(undated)) == ""

    def test_check_never_raises(self, qenv):
        cfg, q, t = qenv
        co, _ = _closeout(q)

        class Broken:
            def find_content_duplicate(self, *a, **k):
                raise RuntimeError("database gone")
        co.queue_store = Broken()
        req = SimpleNamespace(**_snow("SCTASK1", "2026-09-28 06:00:00"),
                              operation="provision", affiliation_code="30822",
                              employee_code="1217036")
        assert co.superseded_reason(req) == ""

    def test_find_content_duplicate_statuses_default_unchanged(self, qenv):
        cfg, q, t = qenv
        rid = _enqueue(q, "provision", ticket_id="T1")
        assert q.find_content_duplicate("provision", "30822", "1217036") \
            .request_id == rid                                   # queued
        assert q.find_content_duplicate(
            "provision", "30822", "1217036",
            statuses=("running", "done")) is None

    def test_ticket_note_is_the_held_ticket_note(self, qenv):
        from src.integrations.servicenow.writeback import _RequestView
        cfg, q, t = qenv
        co, s = _closeout(q, reject_note_enabled=True)
        txn = SimpleNamespace(
            status="cancelled", ticket_id="SCTASK1", request_id="r1",
            operation="provision", affiliation_code="30822",
            employee_code="1217036", result_code="", completed_at="",
            attempt_count=2,
            error_message="Superseded: a newer ticket SCTASK2 (deprovision) "
                          "for the same account and affiliation code was "
                          "already processed; this older ticket is not "
                          "executed")
        action, note = co._plan_one(s, txn, SimpleNamespace(metadata={}), {})
        assert action == "reject_note"
        assert note.startswith("Not processed by the FINESIII RPA bot: a "
                               "newer ticket SCTASK2")
        assert "Cancelled" not in note and "Superseded:" not in note
        # A custom rejection note is used as at pickup.
        s.reject_note = "Held: {reason}"
        assert co._plan_one(s, txn, None, {})[1].startswith("Held: a newer")
        # Rejection note off: nothing (not the operator-cancel wording).
        s.reject_note_enabled = False
        assert co._plan_one(s, txn, None, {}) is None
        # A plain operator cancel keeps its note.
        s.reject_note_enabled = True
        plain = _RequestView(SimpleNamespace(status="cancelled",
                                             error="Cancelled: by operator"))
        assert co._plan_one(s, plain, None, {})[0] == "cancel_note"

    def test_poller_helpers_moved_unchanged(self):
        from desktop import snow_poller
        from src.integrations.servicenow import duplicates
        assert snow_poller._created is duplicates.ticket_created_on
        assert snow_poller._req_created is duplicates.request_created_on
        assert duplicates.ticket_created_on(
            {"sys_created_on": {"value": "2026-09-28 06:00:00"}}) \
            == "2026-09-28 06:00:00"
        assert duplicates.ticket_created_on(None) == ""
        req = SimpleNamespace(metadata={"snow_details": {
            "sys_created_on": "2026-09-28 06:00:00"}})
        assert duplicates.request_created_on(req) == "2026-09-28 06:00:00"
        assert duplicates.request_created_on(SimpleNamespace(metadata=None)) == ""

    def test_app_wires_the_check(self, tmp_path):
        from src import create_app
        cfg = make_config(tmp_path, dispatcher_enabled=True,
                          terminal_driver="simulator",
                          log_dir=str(tmp_path / "logs"))
        app = create_app(cfg)
        d = app.state.dispatcher
        closeout = app.state.ticket_closeout
        assert d.superseded_check == closeout.superseded_reason
        assert d.on_superseded is not None
        # The simulator executor has no commit hook and gets none.
        assert not hasattr(d.executor, "on_commit")

    def test_app_superseded_outputs(self, tmp_path, monkeypatch):
        import src
        from src import create_app
        mails = []
        fake = SimpleNamespace(
            notifier=SimpleNamespace(),
            request_rejected=lambda kind, reason, details: mails.append(
                (kind, reason, details)))
        monkeypatch.setattr(src, "build_rejection_alerter",
                            lambda **kw: fake)
        cfg = make_config(tmp_path, dispatcher_enabled=True,
                          terminal_driver="simulator",
                          log_dir=str(tmp_path / "logs"))
        app = create_app(cfg)
        q = app.state.queue_store
        closeout = app.state.ticket_closeout
        newer = _enqueue(q, "deprovision",
                         **_snow("SCTASK2", "2026-09-28 06:30:00", "d4e5f6"))
        q.dequeue_oldest(worker_id=1)
        q.mark_complete(newer, "done", result_code="O-0000")
        older = _enqueue(q, "provision",
                         **_snow("SCTASK1", "2026-09-28 06:00:00"))
        req = q.dequeue_oldest(worker_id=1)
        q.mark_complete(older, "cancelled", error="Superseded: why")
        notes = []
        closeout.handle_completion = lambda txn, r, res: notes.append(
            (txn.status, txn.error_message, r.request_id))
        app.state.dispatcher.on_superseded(req, "why")
        assert notes == [("cancelled", "Superseded: why", older)]
        assert len(mails) == 1
        kind, reason, details = mails[0]
        assert kind == "DUPLICATE REQUEST"
        assert reason == (f"Superseded by ticket SCTASK2 (request {newer}, "
                          f"status done): why")
        assert details["ticket_id"] == "SCTASK1"
        assert details["sys_id"] == "a1b2c3"
        assert details["original_ticket_id"] == "SCTASK2"
        assert details["original_request_id"] == newer
        assert details["original_status"] == "done"
        assert details["matching_fields"] == \
            "affiliation code, employee code (opposite operation)"


# ── NB-003: history for journaled and recovered completions ──────────


class TestHistoryDurability:
    def test_history_journaled_and_replayed_once(self, qenv, tmp_path,
                                                 monkeypatch):
        from src.modules.queue.dispatcher import (
            apply_pending_completions, recover_on_startup,
        )
        cfg, q, t = qenv
        hooks = []
        d = _dispatcher(qenv, tmp_path,
                        on_complete=lambda *a: hooks.append(a))
        rid = _enqueue(q, metadata={"note": "x", "api_token": "s3cr3t"})

        def down(*a, **k):
            raise RuntimeError("database unavailable")
        monkeypatch.setattr(q, "mark_complete", down)
        monkeypatch.setattr(t, "record", down)
        assert d._tick() is True
        journal = tmp_path / "pending_completions.jsonl"
        entries = [json.loads(x) for x in
                   journal.read_text(encoding="utf-8").splitlines()]
        assert [("status" in e, "history" in e) for e in entries] == \
            [(True, False), (False, True)]
        hist = entries[1]["history"]
        assert hist["request_id"] == rid and hist["status"] == "done"
        text = journal.read_text(encoding="utf-8")
        assert "Abc@1234" not in text and "s3cr3t" not in text
        assert len(hooks) == 1                     # hooks ran at the time

        monkeypatch.undo()
        saved = journal.read_text(encoding="utf-8")
        recover_on_startup(q, cfg, 1, pending_path=journal, transactions=t)
        assert q.get(rid).status == "done"
        rows = _history(t)
        assert len(rows) == 1 and rows[0]["request_id"] == rid
        assert rows[0]["transaction_id"] == hist["transaction_id"]
        assert not journal.exists()
        assert len(hooks) == 1                     # not replayed

        journal.write_text(saved, encoding="utf-8")  # replayed again
        assert apply_pending_completions(q, journal, transactions=t)
        assert len(_history(t)) == 1

    def test_history_only_entry_does_not_hold_up_work(self, qenv, tmp_path,
                                                      monkeypatch):
        cfg, q, t = qenv
        executor = _Exec()
        d = _dispatcher(qenv, tmp_path, executor=executor)
        rid = _enqueue(q)
        real = t.record
        fails = {"n": 4}

        def flaky(*a, **k):
            if fails["n"]:
                fails["n"] -= 1
                raise RuntimeError("history table locked")
            return real(*a, **k)
        monkeypatch.setattr(t, "record", flaky)
        assert d._tick() is True
        journal = tmp_path / "pending_completions.jsonl"
        assert q.get(rid).status == "done"
        assert _history(t) == []
        assert "history" in journal.read_text(encoding="utf-8")

        fails["n"] = 1                     # still refused on the next tick
        rid2 = _enqueue(q, employee_code="7654321")
        assert d._tick() is True           # new work is not held up
        assert executor.calls == [rid, rid2]
        assert journal.exists()
        d._tick()                          # database accepts it now
        assert not journal.exists()
        assert sorted(r["request_id"] for r in _history(t)) == \
            sorted([rid, rid2])

    def test_history_entry_without_store_stays_journaled(self, qenv,
                                                         tmp_path):
        from src.modules.queue.dispatcher import apply_pending_completions
        cfg, q, t = qenv
        journal = tmp_path / "p.jsonl"
        journal.write_text(json.dumps({"request_id": "r", "history": {
            "request_id": "r"}}) + "\n", encoding="utf-8")
        assert apply_pending_completions(q, journal) is False
        assert journal.exists()
        # A malformed record is discarded rather than blocking forever.
        assert apply_pending_completions(q, journal, transactions=t) is True
        assert not journal.exists()

    def test_recovered_unconfirmed_row_gets_history_and_hooks(self, qenv,
                                                              tmp_path):
        from src.modules.queue.dispatcher import recover_on_startup
        cfg, q, t = qenv
        committed = _enqueue(q)
        q.dequeue_oldest(worker_id=1)
        requeued = _enqueue(q, employee_code="7654321")
        q.dequeue_oldest(worker_id=1)
        folder = tmp_path / "evidence" / committed
        folder.mkdir(parents=True)
        (folder / "017_commit_command_entered_101500.png").write_bytes(b"x")
        hooks, audit = [], _Audit()

        class _Log:
            def __init__(self):
                self.lines = []

            def __getattr__(self, level):
                return lambda msg: self.lines.append((level, msg))
        log = _Log()
        out = recover_on_startup(q, cfg, 424242, pending_path=tmp_path / "p",
                                 audit=audit, logger=log, transactions=t,
                                 on_complete=lambda *a: hooks.append(a),
                                 operator="12N3940")
        assert out["unconfirmed"] == [committed]
        assert out["requeued"] == [requeued]
        rows = _history(t)
        assert len(rows) == 1
        assert rows[0]["request_id"] == committed
        assert rows[0]["status"] == "done"
        assert rows[0]["result_code"] == "UNCONFIRMED"
        assert rows[0]["operator"] == "12N3940"
        assert "interrupted after commit" in rows[0]["error_message"]
        assert len(hooks) == 1
        txn, req, result = hooks[0]
        assert req.request_id == committed and req.status == "done"
        assert result["result_code"] == "UNCONFIRMED"
        assert result["commit_sent"] is True
        assert len(audit.transactions) == 1
        # The dedicated unconfirmed e-mail covers it: no ERROR log line.
        assert not any(level == "error" for level, _ in log.lines)

    def test_app_start_writes_history_and_runs_hooks(self, tmp_path,
                                                     monkeypatch):
        import src
        from fastapi.testclient import TestClient
        from src import create_app
        from src.core.db import Database
        from src.modules.audit.services import TransactionStore
        from src.modules.queue.services import QueueStore
        cfg = make_config(tmp_path, log_dir=str(tmp_path / "logs"))
        db = Database.from_config(cfg)
        q = QueueStore(db)
        rid = _enqueue(q)
        q.dequeue_oldest(worker_id=1)
        db.close()
        folder = tmp_path / "evidence" / rid
        folder.mkdir(parents=True)
        (folder / "017_commit_command_entered_101500.png").write_bytes(b"x")
        spy = _Spy(src.recover_on_startup)
        monkeypatch.setattr(src, "recover_on_startup", spy)
        app = create_app(cfg)
        seen = []
        app.state.completion_hooks.append(lambda *a: seen.append(a))
        with TestClient(app):
            rows = TransactionStore(app.state.queue_store.db) \
                .list_transactions()
        assert [r["request_id"] for r in rows] == [rid]
        assert rows[0]["result_code"] == "UNCONFIRMED"
        assert len(seen) == 1 and seen[0][0].result_code == "UNCONFIRMED"
        assert spy.kwargs["transactions"] is app.state.transaction_store
        assert spy.kwargs["on_complete"] is not None

    def test_recovered_row_without_hooks_keeps_error_log(self, qenv,
                                                         tmp_path):
        from src.modules.queue.dispatcher import recover_on_startup
        cfg, q, t = qenv
        rid = _enqueue(q)
        q.dequeue_oldest(worker_id=1)
        folder = tmp_path / "evidence" / rid
        folder.mkdir(parents=True)
        (folder / "018_submission_result_101501.png").write_bytes(b"x")
        lines = []
        log = SimpleNamespace(
            error=lambda m: lines.append("error"),
            warning=lambda m: lines.append("warning"),
            info=lambda m: None)
        recover_on_startup(q, cfg, 424242, pending_path=tmp_path / "p",
                           logger=log)
        assert "error" in lines
        assert _history(t) == []          # no store given: nothing written

    def test_build_transaction_record_matches_dispatcher(self, qenv,
                                                         tmp_path):
        from src.modules.queue.dispatcher import build_transaction_record
        cfg, q, t = qenv
        d = _dispatcher(qenv, tmp_path)
        rid = _enqueue(q)
        assert d._tick() is True
        row = _history(t)[0]
        req = q.get(rid)
        rebuilt = build_transaction_record(
            req, "done", "O-0000", "", "", now_jst(), "")
        for key in ("request_id", "operation", "affiliation_code",
                    "employee_code", "source", "submitted_at", "started_at"):
            assert row[key] == getattr(rebuilt, key)


# ── NB-004: the commit flag in the row ───────────────────────────────


def _rpa_config(tmp_path, scenario="success"):
    return build_rpa_config(driver="mock", environment="development",
                            evidence_dir=str(tmp_path / "evidence"),
                            scenario=scenario)


def _workflow(tmp_path, operation, hook=None):
    config = _rpa_config(tmp_path)
    driver = MockDriver()
    driver.initialize(config["application"])
    evidence = EvidenceCapture(config["evidence"])
    cls = ProvisionWorkflow if operation == "provision" else DeprovisionWorkflow
    wf = cls(driver, config, None, evidence)
    wf.on_commit = hook
    return wf, driver


def _execute(wf, operation):
    if operation == "provision":
        return wf.execute(CREDS, "30822", "1217036", "FUJI@33F")
    return wf.execute(CREDS, "30822", "1217036")


def _boom(*a, **k):
    raise RuntimeError("print screen did not appear")


class TestCommitHook:
    @pytest.mark.parametrize("operation", ["provision", "deprovision"])
    def test_called_once_just_before_70(self, tmp_path, operation):
        seen = []
        wf, driver = _workflow(tmp_path, operation)
        wf.on_commit = lambda: seen.append(list(driver.commands))
        result = _execute(wf, operation)
        assert result["status"] == "success"
        assert len(seen) == 1
        assert "70" not in seen[0]
        assert driver.commands[len(seen[0])] == "70"

    @pytest.mark.parametrize("operation", ["provision", "deprovision"])
    def test_not_called_when_failing_before_commit(self, tmp_path,
                                                   monkeypatch, operation):
        cls = (ProvisionWorkflow if operation == "provision"
               else DeprovisionWorkflow)
        monkeypatch.setattr(cls, "_generate_confirmation", _boom)
        seen = []
        wf, driver = _workflow(tmp_path, operation, lambda: seen.append(1))
        result = _execute(wf, operation)
        assert result["status"] == "failed"
        assert seen == [] and "70" not in driver.commands

    @pytest.mark.parametrize("operation", ["provision", "deprovision"])
    def test_raising_or_hanging_hook_changes_nothing(self, tmp_path,
                                                     operation):
        wf, plain = _workflow(tmp_path / "a", operation)
        baseline = _execute(wf, operation)

        def raising():
            raise RuntimeError("database gone")
        wf, driver = _workflow(tmp_path / "b", operation, raising)
        result = _execute(wf, operation)
        assert driver.commands == plain.commands
        assert result["status"] == baseline["status"]
        assert result["result_code"] == baseline["result_code"]

        release = threading.Event()
        wf, driver = _workflow(tmp_path / "c", operation,
                               lambda: release.wait(30))
        wf.COMMIT_HOOK_TIMEOUT = 0.2
        started = time.monotonic()
        result = _execute(wf, operation)
        release.set()
        assert time.monotonic() - started < 5
        assert driver.commands == plain.commands
        assert result["result_code"] == baseline["result_code"]

    def test_hook_wait_is_bounded_at_two_seconds(self):
        assert ProvisionWorkflow.COMMIT_HOOK_TIMEOUT == 2.0
        assert DeprovisionWorkflow.COMMIT_HOOK_TIMEOUT == 2.0

    def test_dispatcher_records_commit_sent_at(self, qenv, tmp_path):
        from src.modules.queue.services import QueueStore
        cfg, q, t = qenv

        class _Terminal(_Exec):
            on_commit = None

            def execute(self, request):
                self.on_commit(request)
                return super().execute(request)
        executor = _Terminal()
        d = _dispatcher(qenv, tmp_path, executor=executor)
        assert executor.on_commit == d._record_commit_sent
        rid = _enqueue(q)
        before = now_jst().isoformat()
        assert d._tick() is True
        row = q.get(rid)
        assert row.status == "done"
        assert row.metadata[QueueStore.COMMIT_SENT_KEY] >= before

    def test_terminal_executor_end_to_end(self, qenv, tmp_path):
        from src.modules.queue.services import QueueStore
        from src.rpa.executor import TerminalExecutor
        cfg, q, t = qenv
        tcfg = make_config(tmp_path, terminal_driver="mock",
                           ocr_enabled=False)
        executor = TerminalExecutor(tcfg)
        d = _dispatcher(qenv, tmp_path, executor=executor)
        rid = _enqueue(q)
        assert d._tick() is True
        row = q.get(rid)
        assert row.status == "done" and row.result_code == "O-0000"
        assert QueueStore.COMMIT_SENT_KEY in row.metadata

    def test_mock_executor_left_alone(self, qenv, tmp_path):
        from src.modules.queue.dispatcher import MockExecutor
        executor = MockExecutor(delay_seconds=0)
        _dispatcher(qenv, tmp_path, executor=executor)
        assert not hasattr(executor, "on_commit")


class TestForeignRowRecovery:
    def _foreign_row(self, q, flag_offset=None):
        rid = _enqueue(q)
        q.dequeue_oldest(worker_id=5555)                 # installation B
        started = now_jst() - timedelta(hours=3)         # past the lease
        with q.db.connect() as conn:
            conn.execute("UPDATE request_queue SET started_at = ? "
                         "WHERE request_id = ?", (started.isoformat(), rid))
        if flag_offset is not None:
            q.set_metadata_value(
                rid, "commit_sent_at",
                (started + timedelta(seconds=flag_offset)).isoformat())
        return rid

    def test_flag_finishes_as_unconfirmed(self, qenv, tmp_path):
        from src.modules.queue.dispatcher import recover_on_startup
        cfg, q, t = qenv
        rid = self._foreign_row(q, flag_offset=60)
        out = recover_on_startup(q, cfg, 7777, pending_path=tmp_path / "p")
        assert out["unconfirmed"] == [rid]
        row = q.get(rid)
        assert row.status == "done" and row.result_code == "UNCONFIRMED"

    def test_no_flag_is_requeued(self, qenv, tmp_path):
        from src.modules.queue.dispatcher import recover_on_startup
        cfg, q, t = qenv
        rid = self._foreign_row(q)
        out = recover_on_startup(q, cfg, 7777, pending_path=tmp_path / "p")
        assert out["requeued"] == [rid]
        assert q.get(rid).status == "queued"

    def test_flag_of_an_earlier_attempt_is_ignored(self, qenv, tmp_path):
        from src.modules.queue.dispatcher import recover_on_startup
        cfg, q, t = qenv
        rid = self._foreign_row(q, flag_offset=-3600)
        out = recover_on_startup(q, cfg, 7777, pending_path=tmp_path / "p")
        assert out["requeued"] == [rid]

    def test_row_within_lease_is_left_alone(self, qenv, tmp_path):
        from src.modules.queue.dispatcher import recover_on_startup
        cfg, q, t = qenv
        rid = _enqueue(q)
        q.dequeue_oldest(worker_id=5555)
        q.set_metadata_value(rid, "commit_sent_at", now_jst().isoformat())
        out = recover_on_startup(q, cfg, 7777, pending_path=tmp_path / "p")
        assert out["skipped"][0]["request_id"] == rid
        assert q.get(rid).status == "running"

    def test_commit_flag_parsing(self):
        from src.modules.queue.dispatcher import commit_flag
        now = now_jst()
        req = SimpleNamespace(started_at=now.isoformat(), metadata={})
        assert commit_flag(req) is False
        req.metadata = {"commit_sent_at": "not a time"}
        assert commit_flag(req) is False
        req.metadata = {"commit_sent_at": (now + timedelta(seconds=1)).isoformat()}
        assert commit_flag(req) is True
        req.started_at = ""
        assert commit_flag(req) is True


# ── Sim-terminal launcher: commit seen from the worker's evidence ────


class _FakeProc:
    """Stands in for the worker process: 'types 70' (writes the commit
    evidence) on the first poll, then exits."""

    def __init__(self, cmd, evidence_folder, result=None, commit=True):
        self.res_path = cmd[-1]
        self.folder = evidence_folder
        self.result = result
        self.commit = commit
        self.polls = 0

    def wait(self, timeout=None):
        import subprocess
        self.polls += 1
        if self.polls == 1:
            if self.commit:
                self.folder.mkdir(parents=True, exist_ok=True)
                (self.folder / "017_commit_command_entered_1.png") \
                    .write_bytes(b"x")
            raise subprocess.TimeoutExpired("worker", timeout)
        if self.result is not None:
            with open(self.res_path, "w", encoding="utf-8") as f:
                json.dump(self.result, f)
        return 0


class TestSimLauncher:
    def _run(self, tmp_path, monkeypatch, result=None, commit=True):
        from src.rpa.drivers import sim_launcher
        config = _rpa_config(tmp_path)
        req = ProcessingRequest(operation="provision",
                                affiliation_code="30822",
                                employee_code="1217036")
        req.started_at = now_jst().isoformat()
        folder = tmp_path / "evidence" / req.request_id
        procs = []

        def popen(cmd, **kw):
            procs.append(_FakeProc(cmd, folder, result, commit))
            return procs[-1]
        monkeypatch.setattr(sim_launcher.subprocess, "Popen", popen)
        launcher = sim_launcher.SimTerminalSubprocessLauncher(config)
        launcher.POLL_SECONDS = 0.01
        fired = []
        launcher.on_commit = lambda: fired.append(1)
        out = launcher.run_request(req, CREDS)
        return out, fired

    def test_commit_fires_once_and_lost_result_is_unconfirmed(
            self, tmp_path, monkeypatch):
        out, fired = self._run(tmp_path, monkeypatch)
        assert fired == [1]
        assert out["status"] == "success"
        assert out["result_code"] == "UNCONFIRMED"
        assert out["commit_sent"] is True
        assert "manual check required" in out["error"]
        assert RetryPolicy(max_attempts=3).evaluate(1, result=out) \
            .should_retry is False

    def test_workflow_result_is_returned_unchanged(self, tmp_path,
                                                   monkeypatch):
        wf_result = {"status": "success", "operation": "provision",
                     "result_code": "O-0000", "error": None}
        out, fired = self._run(tmp_path, monkeypatch, result=wf_result)
        assert out == wf_result and fired == [1]

    def test_no_commit_keeps_the_failed_fallback(self, tmp_path,
                                                 monkeypatch):
        out, fired = self._run(tmp_path, monkeypatch, commit=False)
        assert fired == []
        assert out["status"] == "failed"
        assert not out.get("commit_sent")


# ── NB-013: what failed after the '70' is named ──────────────────────


class TestPostCommitDetail:
    @pytest.mark.parametrize("operation", ["provision", "deprovision"])
    def test_print_screen_failure_names_code_and_step(self, tmp_path,
                                                      monkeypatch, operation):
        monkeypatch.setattr(Navigator, "handle_print_screen", _boom)
        wf, _ = _workflow(tmp_path, operation)
        result = _execute(wf, operation)
        assert result["result_code"] == "UNCONFIRMED"
        assert "O-0000" in result["error"]
        assert "print_screen" in result["error"]
        assert result["failed_step"] == "print_screen"
        assert "manual check required" in result["error"]
        assert "print screen did not appear" in result["error"]

    @pytest.mark.parametrize("operation", ["provision", "deprovision"])
    def test_result_read_failure_says_not_read(self, tmp_path, monkeypatch,
                                               operation):
        cls = (ProvisionWorkflow if operation == "provision"
               else DeprovisionWorkflow)
        monkeypatch.setattr(cls, "_check_result", _boom)
        wf, _ = _workflow(tmp_path, operation)
        result = _execute(wf, operation)
        assert "result not read" in result["error"]
        assert "check_result" in result["error"]

    def _alerter(self):
        from src.modules.notifications.transaction_alerts import (
            TransactionAlerter, TransactionNotificationSettings,
        )
        sent = []
        t = TransactionAlerter(SimpleNamespace(send=lambda *a, **k: None),
                               TransactionNotificationSettings(enabled=True),
                               async_send=False)
        t._dispatch = lambda **kw: sent.append(kw)
        return t, sent

    @staticmethod
    def _txn(error):
        return SimpleNamespace(
            status="done", result_code="UNCONFIRMED", ticket_id="T1",
            request_id="r", operation="provision", affiliation_code="30822",
            employee_code="1217036", attempt_count=1, error_message=error,
            source="servicenow", submitted_at="", started_at="",
            completed_at="", duration_seconds=0, worker_id=1,
            evidence_path="", screenshot_count=0, operator="",
            transaction_id="t")

    def test_verification_email_carries_the_detail(self):
        t, sent = self._alerter()
        error = ("'70' sent; result O-0000 confirmed on screen; the later "
                 "step 'print_screen' failed: x — manual check required")
        t._send_verification(self._txn(error))
        assert f"Detail: {error}" in sent[0]["body"]
        assert "O-0000" in sent[0]["context"]["error_html"]
        assert "print_screen" in sent[0]["context"]["error_html"]

    def test_verification_email_without_detail_is_unchanged(self):
        t, sent = self._alerter()
        t._send_verification(self._txn(""))
        assert "Detail:" not in sent[0]["body"]
        assert "user.\n\n" in sent[0]["body"]
        assert sent[0]["context"]["error_html"] == (
            "Result not confirmed on screen — verify in FINESIII")

    def test_ticket_note_gets_the_detail_only_when_present(self, qenv):
        cfg, q, t = qenv
        co, s = _closeout(q)
        txn = SimpleNamespace(
            status="done", ticket_id="SCTASK1", request_id="r1",
            operation="provision", affiliation_code="30822",
            employee_code="1217036", result_code="UNCONFIRMED",
            completed_at="", attempt_count=1,
            error_message="'70' sent; result O-0000 confirmed on screen; "
                          "the later step 'print_screen' failed: x — "
                          "manual check required")
        action, note = co._plan_one(s, txn, None, {})
        assert action == "review_note"
        assert "could not confirm" in note
        assert note.endswith(f" Detail: {txn.error_message}")
        txn.error_message = ""
        assert "Detail:" not in co._plan_one(s, txn, None, {})[1]
        # A template that already shows {error} is not doubled.
        s.unconfirmed_note = "Check: {error}"
        txn.error_message = "boom"
        assert co._plan_one(s, txn, None, {})[1] == "Check: boom"
