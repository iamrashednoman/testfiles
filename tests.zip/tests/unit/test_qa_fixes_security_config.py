"""QA fixes — secrets, configuration, deployment and installation.

Covers the stored SMTP password (BUG-005), blank secrets (BUG-044), the
credential source shown in the console (BUG-053) and the retirement of
the initial administrator password (BUG-024), plus the configuration
and deployment checks of the same group.
"""
import logging
import os

import pytest

from src.core.db import Database
from tests.conftest import make_config


@pytest.fixture
def memory_vault(monkeypatch):
    from desktop import vault
    previous = vault._vault
    store = vault.MemoryVault()
    vault.use_vault(store)
    for k in vault.SECRET_KEYS:
        monkeypatch.delenv(k, raising=False)
    yield store
    vault.use_vault(previous)


@pytest.fixture
def settings_store(tmp_path):
    from src.modules.console.settings_store import SettingsStore
    db = Database.from_config(make_config(tmp_path))
    yield SettingsStore(db)
    db.close()


# ── BUG-005: SMTP password no longer kept in the settings table ──

class TestSmtpPasswordNotASetting:
    def test_catalogue_no_longer_contains_smtp_password(self):
        from src.modules.console import settings_help
        from src.modules.console.settings_catalogue import BY_KEY
        assert "SMTP_PASSWORD" not in BY_KEY
        assert settings_help.section("SMTP_PASSWORD") == ""
        # Still described for the Credentials section.
        assert settings_help.tooltip("SMTP_PASSWORD")

    def test_legacy_row_migrated_into_the_vault_and_deleted(
            self, memory_vault, settings_store, monkeypatch):
        from desktop import vault
        from src.modules.console.settings_store import apply_overrides
        monkeypatch.setenv("SMTP_PASSWORD", "from-environment")
        settings_store.set("SMTP_PASSWORD", "legacy-pw")
        apply_overrides(make_config_obj(), settings_store)
        assert os.environ["SMTP_PASSWORD"] == "legacy-pw"

        moved = vault.migrate_legacy_setting_secrets(settings_store)
        assert moved == ["SMTP_PASSWORD"]
        assert memory_vault.get("SMTP_PASSWORD") == "legacy-pw"
        assert "SMTP_PASSWORD" not in settings_store.all()
        assert os.environ["SMTP_PASSWORD"] == "legacy-pw"
        # A later rebuild does not put the old environment value back.
        apply_overrides(make_config_obj(), settings_store)
        assert os.environ["SMTP_PASSWORD"] == "legacy-pw"

    def test_blank_legacy_row_deleted_vault_untouched(
            self, memory_vault, settings_store):
        from desktop import vault
        settings_store.set("SMTP_PASSWORD", "  ")
        assert vault.migrate_legacy_setting_secrets(settings_store) == []
        assert memory_vault.get("SMTP_PASSWORD") is None
        assert "SMTP_PASSWORD" not in settings_store.all()

    def test_without_vault_the_legacy_value_still_applies_with_warning(
            self, settings_store, monkeypatch, caplog):
        from src.modules.console.settings_store import apply_overrides
        monkeypatch.delenv("SMTP_PASSWORD", raising=False)
        settings_store.set("SMTP_PASSWORD", "legacy-secret-value")
        logger = logging.getLogger("qa-fixes-b")
        with caplog.at_level(logging.WARNING, logger="qa-fixes-b"):
            applied = apply_overrides(make_config_obj(), settings_store,
                                      logger)
        assert os.environ["SMTP_PASSWORD"] == "legacy-secret-value"
        assert applied["SMTP_PASSWORD"] == "(set)"
        text = caplog.text
        assert "SMTP_PASSWORD is held in the settings table" in text
        assert "legacy-secret-value" not in text

    def test_blank_legacy_row_is_not_applied(self, settings_store,
                                             monkeypatch):
        from src.modules.console.settings_store import apply_overrides
        monkeypatch.setenv("SMTP_PASSWORD", "env-value")
        settings_store.set("SMTP_PASSWORD", "")
        apply_overrides(make_config_obj(), settings_store)
        assert os.environ["SMTP_PASSWORD"] == "env-value"


def make_config_obj():
    from config.development import DevelopmentConfig
    return DevelopmentConfig(_env_file=None)


# ── BUG-044: a blank secret is "not set" ──

class TestBlankSecret:
    def test_blank_secret_row_is_skipped_by_apply(self, settings_store,
                                                  monkeypatch):
        from src.modules.console import settings_catalogue
        from src.modules.console.settings_store import apply_overrides
        spec = settings_catalogue._s("QA_TEST_SECRET", "Test secret",
                                     "Email", "str", target="env",
                                     secret=True)
        monkeypatch.setitem(settings_catalogue.BY_KEY, "QA_TEST_SECRET",
                            spec)
        monkeypatch.delenv("QA_TEST_SECRET", raising=False)
        settings_store.set("QA_TEST_SECRET", "   ")
        applied = apply_overrides(make_config_obj(), settings_store)
        assert "QA_TEST_SECRET" not in applied
        assert "QA_TEST_SECRET" not in os.environ


# ── BUG-053: credential source ──

class TestCredentialSource:
    def test_loaded_from_store_reports_vault(self, memory_vault):
        from desktop import vault
        memory_vault.set("SNOW_PASSWORD", "stored")
        assert "SNOW_PASSWORD" in vault.load_secrets_into_env()
        assert vault.status()["SNOW_PASSWORD"]["source"] == "vault"
        os.environ.pop("SNOW_PASSWORD", None)

    def test_set_from_console_reports_vault(self, memory_vault):
        from desktop import vault
        vault.set_secret("SNOW_CLIENT_SECRET", "typed")
        assert vault.status()["SNOW_CLIENT_SECRET"] == {
            "label": vault.SECRET_KEYS["SNOW_CLIENT_SECRET"],
            "set": True, "source": "vault"}
        vault.delete_secret("SNOW_CLIENT_SECRET")
        assert vault.status()["SNOW_CLIENT_SECRET"]["set"] is False

    def test_real_environment_variable_reports_environment(
            self, memory_vault, monkeypatch):
        from desktop import vault
        memory_vault.set("JWT_SECRET", "stored")
        vault.load_secrets_into_env()
        # An operator-provided value replaces the one from the store.
        monkeypatch.setenv("JWT_SECRET", "operator-provided")
        assert vault.status()["JWT_SECRET"]["source"] == "environment"


# ── Confirmation-screen switch in the console catalogue ──

class TestRequireReadableConfirmationSetting:
    def test_catalogue_row_restart_config_bool(self):
        from src.modules.console import settings_help
        from src.modules.console.settings_catalogue import BY_KEY, coerce
        spec = BY_KEY["require_readable_confirmation"]
        assert spec["kind"] == "bool" and spec["target"] == "config"
        assert spec["apply"] == "restart"
        assert spec["label"] == "Stop when the confirmation cannot be read"
        assert settings_help.section("require_readable_confirmation") == \
            "Confirmation screen"
        assert "(99)" in settings_help.tooltip(
            "require_readable_confirmation", spec["help"])
        assert coerce(spec, "true") is True

    def test_stored_value_reaches_the_executor_config(self, settings_store):
        from src.modules.console.settings_store import apply_overrides
        settings_store.set("require_readable_confirmation", "true")
        cfg = make_config_obj()
        assert cfg.require_readable_confirmation is False
        apply_overrides(cfg, settings_store)
        assert cfg.require_readable_confirmation is True


# ── BUG-021: production on SQLite starts with a warning ──

class TestProductionOnSqlite:
    def test_warns_and_starts(self, tmp_path, monkeypatch, caplog):
        from config.production import ProductionConfig
        from src import create_app
        monkeypatch.setenv("FINESIII_API_KEYS", "svc:qa-key")
        cfg = ProductionConfig(
            _env_file=None, database_engine="sqlite",
            sqlite_path=str(tmp_path / "p.db"),
            evidence_dir=str(tmp_path / "ev"), log_dir=str(tmp_path / "lg"),
            terminal_driver="simulator", require_cyberark=False,
            dispatcher_enabled=False, auth_seed_default_admin=False)
        with caplog.at_level(logging.WARNING):
            app = create_app(cfg)
        assert app is not None
        assert "Production is running on SQLite" in caplog.text

    def test_docstring_no_longer_says_refused(self):
        import inspect

        import config.production as production
        from desktop import deployment
        assert "SQLite refused" not in inspect.getsource(production)
        assert "PostgreSQL only" not in deployment.BY_KEY["APP_ENV"]["help"]


# ── BUG-022: TLS required ──

class TestTlsProblem:
    def _cfg(self, **kw):
        from types import SimpleNamespace
        base = dict(require_tls=True, api_host="0.0.0.0", tls_certfile="",
                    tls_keyfile="")
        base.update(kw)
        return SimpleNamespace(**base)

    def test_off_is_fine(self):
        from run import tls_problem
        assert tls_problem(self._cfg(require_tls=False)) == ""

    @pytest.mark.parametrize("host", ["127.0.0.1", "::1", "localhost"])
    def test_loopback_is_fine(self, host):
        from run import tls_problem
        assert tls_problem(self._cfg(api_host=host)) == ""

    def test_network_bind_without_certificate_refused(self):
        from run import tls_problem
        text = tls_problem(self._cfg())
        assert "API_HOST" in text and "TLS_CERTFILE" in text

    def test_missing_key_file_named(self, tmp_path):
        from run import tls_problem
        cert = tmp_path / "c.pem"
        cert.write_text("x")
        text = tls_problem(self._cfg(tls_certfile=str(cert),
                                     tls_keyfile=str(tmp_path / "none")))
        assert "TLS_KEYFILE not found" in text

    def test_certificate_and_key_present(self, tmp_path):
        from run import tls_problem
        cert, key = tmp_path / "c.pem", tmp_path / "k.pem"
        cert.write_text("x")
        key.write_text("y")
        assert tls_problem(self._cfg(tls_certfile=str(cert),
                                     tls_keyfile=str(key))) == ""

    def test_config_fields_from_environment(self, monkeypatch):
        from config.development import DevelopmentConfig
        monkeypatch.setenv("TLS_CERTFILE", "/certs/c.pem")
        monkeypatch.setenv("TLS_KEYFILE", "/certs/k.pem")
        cfg = DevelopmentConfig(_env_file=None)
        assert cfg.tls_certfile == "/certs/c.pem"
        assert cfg.tls_keyfile == "/certs/k.pem"


# ── BUG-023: secrets masked in logs and diagnostics ──

class TestMaskSecrets:
    @pytest.mark.parametrize("text,secret", [
        ("snow_password=x1secret", "x1secret"),
        ("connect with password=x2secret now", "x2secret"),
        ("    SMTP_PASSWORD=x3secret", "x3secret"),
        ("export SMTP_PASSWORD=x4secret", "x4secret"),
        ('{"password": "x5secret", "user": "bot"}', "x5secret"),
        ("Authorization: Bearer abc.def.x6secret", "x6secret"),
        ("postgresql://app:x7secret@db:5432/finesiii", "x7secret"),
        ("FINESIII_API_KEYS=svc:x8secret,other:x9secret", "x9secret"),
        ("client_secret: x10secret", "x10secret"),
        ("api-key=x11secret", "x11secret"),
    ])
    def test_masked(self, text, secret):
        from desktop.system_api import mask_secrets
        out = mask_secrets(text)
        assert secret not in out
        assert "*****" in out

    def test_env_line_keeps_key_form(self):
        from desktop.system_api import mask_secrets
        assert mask_secrets("SMTP_PASSWORD=topsecret\nLOG_LEVEL=INFO") == \
            "SMTP_PASSWORD=*****\nLOG_LEVEL=INFO"

    def test_json_structure_stays_valid(self):
        import json

        from desktop.system_api import _mask_obj
        data = {"token_ok": True, "password_length": 8,
                "client_secret": "abc", "note": "password=zz",
                "items": [{"api_key": "k"}]}
        out = _mask_obj(data)
        json.dumps(out)
        assert out["token_ok"] is True and out["password_length"] == 8
        assert out["client_secret"] == "*****"
        assert out["note"] == "password=*****"
        assert out["items"][0]["api_key"] == "*****"


# ── BUG-043: invalid SMTP port reported ──

class TestSmtpPortValidation:
    @pytest.mark.parametrize("raw", ["abc", "0", "70000"])
    def test_enabled_invalid_port_names_smtp_port(self, monkeypatch, raw):
        from src.modules.notifications.config import load_notification_config
        monkeypatch.setenv("SMTP_ALERTS_ENABLED", "true")
        monkeypatch.setenv("SMTP_HOST", "smtp.example.com")
        monkeypatch.setenv("ALERT_FROM", "bot@example.com")
        monkeypatch.setenv("ALERT_TO", "ops@example.com")
        monkeypatch.setenv("SMTP_PORT", raw)
        s = load_notification_config()
        assert s.smtp_port == 587
        with pytest.raises(ValueError) as e:
            s.validate()
        assert "SMTP_PORT" in str(e.value) and raw in str(e.value)

    def test_disabled_does_not_raise(self, monkeypatch):
        from src.modules.notifications.config import load_notification_config
        monkeypatch.setenv("SMTP_ALERTS_ENABLED", "false")
        monkeypatch.setenv("SMTP_PORT", "abc")
        s = load_notification_config()
        assert s.config_error
        s.validate()

    def test_valid_port_has_no_error(self, monkeypatch):
        from src.modules.notifications.config import load_notification_config
        monkeypatch.setenv("SMTP_PORT", " 2525 ")
        s = load_notification_config()
        assert s.smtp_port == 2525 and s.config_error == ""


# ── BUG-046: un-encoded characters in the database password ──

class TestDatabaseUrlPassword:
    @pytest.mark.parametrize("url", [
        "postgresql://u:Qz#9@h:5432/db",
        "postgresql://u:Qz?9@h:5432/db",
        "postgresql://u:Qz/9@h:5432/db",
        "postgresql://u@h:port/db",
    ])
    def test_refused_with_advice(self, url):
        from desktop import deployment
        with pytest.raises(ValueError) as e:
            deployment.coerce(deployment.BY_KEY["DATABASE_URL"], url)
        assert "percent-encode" in str(e.value)
        assert "Qz" not in str(e.value)

    @pytest.mark.parametrize("url", [
        "postgresql://u:Pw%239@h:5432/db",
        "postgresql://u@h:5432/db?sslmode=require",
        "postgresql://u@[::1]:5432/db",
        "sqlite:///data/finesiii.db",
    ])
    def test_accepted(self, url):
        from desktop import deployment
        assert deployment.coerce(deployment.BY_KEY["DATABASE_URL"], url) == url


# ── BUG-047: the SQLite test never creates the file ──

class TestSqliteCheck:
    def test_missing_file_not_created(self, tmp_path):
        from desktop.deployment import REQUIRED_TABLES, check_database
        target = tmp_path / "later.db"
        r = check_database(f"sqlite:///{target}")
        assert not target.exists()
        assert r["ok"] is True and r["exists"] is False
        assert r["missing_tables"] == list(REQUIRED_TABLES)
        assert "does not exist yet" in r["hint"] and "created" in r["hint"]

    def test_missing_folder_is_not_ok(self, tmp_path):
        from desktop.deployment import check_database
        r = check_database(f"sqlite:///{tmp_path / 'nope' / 'x.db'}")
        assert r["ok"] is False
        assert "folder" in r["error"]
        assert not (tmp_path / "nope").exists()

    def test_existing_file_read_only(self, tmp_path):
        import sqlite3

        from desktop.deployment import check_database
        target = tmp_path / "have.db"
        with sqlite3.connect(target) as conn:
            conn.execute("CREATE TABLE request_queue (x)")
        before = target.stat().st_mtime_ns
        r = check_database(f"sqlite:///{target}")
        assert r["ok"] is True and r["exists"] is True
        assert "request_queue" not in r["missing_tables"]
        assert target.stat().st_mtime_ns == before


# ── BUG-048: database test messages ──

class _FakeCursor:
    def __init__(self, missing):
        self.missing = missing
        self._last = None

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    def execute(self, sql, params=None):
        self._last = (sql, params)

    def fetchone(self):
        sql, params = self._last
        if "version()" in sql:
            return ("PostgreSQL 17.2 on x86_64", "finesiii")
        if "to_regclass" in sql:
            return (None,) if self.missing else ("t",)
        return (True, True, True, True, False)


class _FakeConn:
    def __init__(self, missing):
        self.missing = missing

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    def cursor(self):
        return _FakeCursor(self.missing)


def _fake_psycopg(monkeypatch, *, missing=False, error=None):
    import sys
    import types
    mod = types.ModuleType("psycopg")

    def connect(url, **kw):
        if error is not None:
            raise error
        return _FakeConn(missing)
    mod.connect = connect
    monkeypatch.setitem(sys.modules, "psycopg", mod)


class TestDatabaseCheckMessages:
    def test_connected_but_tables_missing(self, monkeypatch):
        from desktop.deployment import check_database
        _fake_psycopg(monkeypatch, missing=True)
        r = check_database("postgresql://u@db.example:5432/x", password="pw")
        assert r["ok"] is False and r["connected"] is True
        assert r["error"].startswith("Connected to PostgreSQL 17.2")
        assert "application tables are missing" in r["error"]
        assert "Setup_Database.py" in r["hint"]

    @pytest.mark.parametrize("text", [
        'could not translate host name "dbx" to address: Name or service '
        'not known',
        "failed to resolve host 'dbx'",
        "[Errno 8] nodename nor servname provided, or not known",
        "No such host is known.",
    ])
    def test_unknown_host(self, monkeypatch, text):
        from desktop.deployment import check_database
        _fake_psycopg(monkeypatch, error=RuntimeError(text))
        r = check_database("postgresql://u@dbx:5432/x", password="pw")
        assert r["ok"] is False
        assert r["hint"] == ("The host name 'dbx' could not be found — "
                             "check the spelling or DNS.")

    def test_refused_still_unreachable(self, monkeypatch):
        from desktop.deployment import check_database
        _fake_psycopg(monkeypatch,
                      error=RuntimeError("connection refused"))
        r = check_database("postgresql://u@h:5432/x")
        assert "unreachable" in r["hint"]


# ── BUG-049: stray spaces and unreadable files ──

class TestConfigHygiene:
    def test_app_env_with_spaces(self, monkeypatch):
        import config
        from config.production import ProductionConfig
        monkeypatch.setenv("APP_ENV", " Production ")
        monkeypatch.setenv("FINESIII_API_KEYS", "svc:k")
        assert config._app_env() == "production"
        config.get_config.cache_clear()
        try:
            assert isinstance(config.get_config(), ProductionConfig)
        finally:
            config.get_config.cache_clear()

    def test_window_time_names_the_field(self):
        from pydantic import ValidationError

        from config.development import DevelopmentConfig
        with pytest.raises(ValidationError) as e:
            DevelopmentConfig(_env_file=None,
                              availability_window_start="25:00")
        assert "AVAILABILITY_WINDOW_START" in str(e.value)

    def test_window_time_normalised(self):
        from config.development import DevelopmentConfig
        cfg = DevelopmentConfig(_env_file=None,
                                availability_window_start=" 6:00 ")
        assert cfg.availability_window_start == "06:00"

    def test_engine_driver_backend_stripped_and_lowered(self):
        from config.development import DevelopmentConfig
        cfg = DevelopmentConfig(_env_file=None, database_engine=" SQLite ",
                                terminal_driver="Simulator ",
                                audit_backend=" Postgres")
        assert cfg.database_engine == "sqlite"
        assert cfg.terminal_driver == "simulator"
        assert cfg.audit_backend == "postgres"

    @pytest.mark.skipif(os.name == "nt" or (hasattr(os, "geteuid")
                                            and os.geteuid() == 0),
                        reason="file permissions are POSIX-only here")
    def test_unreadable_deployment_file(self, tmp_path, monkeypatch):
        import config
        monkeypatch.delenv("APP_ENV", raising=False)
        monkeypatch.setenv("FINESIII_DATA_DIR", str(tmp_path))
        monkeypatch.chdir(tmp_path)
        target = tmp_path / "finesiii.env"
        target.write_text("APP_ENV=production\n")
        target.chmod(0)
        try:
            with pytest.raises(RuntimeError) as e:
                config._app_env()
        finally:
            target.chmod(0o600)
        assert "Cannot read finesiii.env" in str(e.value)
        assert "permissions" in str(e.value)

    def test_availability_friendly_error(self):
        from src.modules.queue.availability import AvailabilityMonitor
        with pytest.raises(ValueError) as e:
            AvailabilityMonitor._parse_time("7")
        assert "HH:MM" in str(e.value)


# ── BUG-051: --configure ──

@pytest.fixture
def cfg_data_dir(tmp_path, monkeypatch):
    d = tmp_path / "data"
    d.mkdir()
    monkeypatch.setenv("FINESIII_DATA_DIR", str(d))
    monkeypatch.setenv("SQLITE_PATH", str(d / "x.db"))
    return d


class TestConfigureStep:
    def _answers(self, tmp_path):
        f = tmp_path / "answers.ini"
        f.write_text("[secrets]\ndb_password=plain-db-pw\n")
        return f

    def test_bad_driver_still_deletes_answers_file(self, tmp_path,
                                                   cfg_data_dir,
                                                   memory_vault):
        from desktop import configure
        f = self._answers(tmp_path)
        rc = configure.main(["--answers-file", str(f), "--driver", "bogus",
                             "--no-check"])
        assert rc == 2
        assert not f.exists()

    def test_bad_setting_still_deletes_answers_file(self, tmp_path,
                                                    cfg_data_dir,
                                                    memory_vault):
        from desktop import configure
        f = self._answers(tmp_path)
        assert configure.main(["--answers-file", str(f), "--set",
                               "NOT_A_KEY=1", "--no-check"]) == 2
        assert not f.exists()

    def test_failed_check_writes_neither_file_nor_secrets(
            self, tmp_path, cfg_data_dir, memory_vault, monkeypatch):
        from desktop import configure, deployment
        _fake_psycopg(monkeypatch, error=RuntimeError("connection refused"))
        monkeypatch.setenv("INSTALL_DB_PW", "db-pw")
        monkeypatch.setenv("INSTALL_ADMIN_PW", "AdminProvisional1!")
        rc = configure.main(["--db-url", "postgresql://u@h:5432/x",
                             "--db-password-env", "INSTALL_DB_PW",
                             "--admin-password-env", "INSTALL_ADMIN_PW",
                             "--auth", "on"])
        assert rc == 3
        assert not deployment.deployment_file().exists()
        assert memory_vault.get("DATABASE_PASSWORD") is None
        assert memory_vault.get("AUTH_DEFAULT_ADMIN_PASSWORD") is None
        assert memory_vault.get("FINESIII_API_KEYS") is None

    def test_check_uses_the_new_password(self, tmp_path, cfg_data_dir,
                                         memory_vault, monkeypatch):
        from desktop import configure, deployment
        seen = {}

        def fake_check(url, engine="", password="", timeout=5.0):
            seen.update(url=url, engine=engine, password=password)
            return {"ok": True, "error": "", "hint": "", "server": "pg"}
        monkeypatch.setattr(deployment, "check_database", fake_check)
        monkeypatch.setenv("INSTALL_DB_PW", "db-pw")
        rc = configure.main(["--db-url", "postgresql://u@h:5432/x",
                             "--db-password-env", "INSTALL_DB_PW"])
        assert rc == 0
        assert seen == {"url": "postgresql://u@h:5432/x",
                        "engine": "postgres", "password": "db-pw"}
        assert deployment.read()["DATABASE_URL"] == "postgresql://u@h:5432/x"
        assert memory_vault.get("DATABASE_PASSWORD") == "db-pw"

    def test_production_real_driver_needs_cyberark(self, cfg_data_dir,
                                                   memory_vault,
                                                   monkeypatch):
        from desktop import configure, deployment
        monkeypatch.delenv("CYBERARK_ENABLED", raising=False)
        result = configure.configure(["--environment", "production",
                                      "--driver", "pywinauto", "--ocr", "on",
                                      "--no-check"])
        assert result["exit"] == 2 and "CyberArk" in result["error"]
        assert not deployment.deployment_file().exists()
        monkeypatch.setenv("CYBERARK_ENABLED", "true")
        assert configure.configure(["--environment", "production",
                                    "--driver", "pywinauto", "--ocr", "on",
                                    "--no-check"])["exit"] == 0

    def test_task_xml_escapes_values(self):
        from xml.dom import minidom

        from desktop import configure
        text = configure._schtasks_xml(r"C:\A&B\<x>.exe", "CORP\\a&b<c>")
        assert "<UserId>CORP\\a&amp;b&lt;c&gt;</UserId>" in text
        assert r"<Command>C:\A&amp;B\&lt;x&gt;.exe</Command>" in text
        minidom.parseString(text.replace('encoding="UTF-16"', ""))


# ── BUG-078: removal requests never keep a password ──

class TestProductionPasswordRetention:
    def test_production_retention_is_zero(self):
        from config.development import DevelopmentConfig
        from config.production import ProductionConfig
        assert ProductionConfig.model_fields[
            "failed_password_retention_days"].default == 0
        assert DevelopmentConfig(
            _env_file=None).failed_password_retention_days == 7
