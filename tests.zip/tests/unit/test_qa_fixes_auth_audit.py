"""QA fixes — sign-in, accounts, intake validation, audit queries and
the error-rule file (group E): BUG-018, 031, 032, 033, 034, 039, 040,
052.
"""
from __future__ import annotations

import tempfile
import threading
from datetime import timedelta
from pathlib import Path

import pytest
import yaml

from src.core.db import Database
from src.modules.auth.models import AppUser, Role, now_jst
from src.modules.auth.services import AuthError, AuthService
from src.modules.auth.store import UserStore

PASSWORD = "CorrectHorse42"


class Cfg:
    jwt_secret = "test-signing-key-not-for-production-0123456789"
    jwt_ttl_seconds = 3600
    auth_min_password_length = 12
    auth_max_failed_attempts = 3
    auth_lockout_seconds = 900
    auth_windows_sso_enabled = False


class RecordingAudit:
    def __init__(self):
        self.events = []

    def event(self, category, action, severity="INFO", **fields):
        self.events.append({"category": category, "action": action,
                            "severity": severity, **fields})

    def actions(self, action):
        return [e for e in self.events if e["action"] == action]


@pytest.fixture
def store():
    return UserStore(Database("sqlite",
                              sqlite_path=tempfile.mktemp(suffix=".db")))


@pytest.fixture
def audit():
    return RecordingAudit()


@pytest.fixture
def auth(store, audit):
    return AuthService(store, Cfg(), audit=audit)


@pytest.fixture
def admin(store):
    user = AppUser(username="alice", role=Role.ADMIN.value)
    user.set_password(PASSWORD)
    return store.create(user)


# ── BUG-031: an expired lockout restarts the failure count ──────────

class TestExpiredLockout:
    def _expire(self, store):
        user = store.get_by_username("alice")
        user.locked_until = (now_jst() - timedelta(seconds=1)).isoformat()
        store.update(user)

    def test_one_mistake_after_expiry_does_not_relock(self, auth, store,
                                                      admin):
        for _ in range(Cfg.auth_max_failed_attempts):
            with pytest.raises(AuthError):
                auth.authenticate("alice", "wrong")
        assert store.get_by_username("alice").is_locked()
        self._expire(store)

        with pytest.raises(AuthError) as e:
            auth.authenticate("alice", "wrong")
        assert e.value.status_code == 401          # not 423
        user = store.get_by_username("alice")
        assert user.failed_attempts == 1
        assert not user.is_locked()
        assert user.locked_until == ""

    def test_correct_password_after_expiry_signs_in(self, auth, store,
                                                    admin):
        for _ in range(Cfg.auth_max_failed_attempts):
            with pytest.raises(AuthError):
                auth.authenticate("alice", "wrong")
        self._expire(store)
        token, user = auth.authenticate("alice", PASSWORD)
        assert auth.verify(token).user_id == admin.user_id
        assert store.get_by_username("alice").failed_attempts == 0

    def test_open_lockout_still_refuses(self, auth, store, admin):
        for _ in range(Cfg.auth_max_failed_attempts):
            with pytest.raises(AuthError):
                auth.authenticate("alice", "wrong")
        with pytest.raises(AuthError) as e:
            auth.authenticate("alice", PASSWORD)
        assert e.value.status_code == 401        # D-07: as a wrong password


# ── BUG-032: the new password must differ from the current one ──────

class TestSamePasswordRefused:
    def test_same_password_is_400_and_audited(self, auth, store, admin,
                                              audit):
        with pytest.raises(AuthError) as e:
            auth.change_password(admin, PASSWORD, PASSWORD)
        assert e.value.status_code == 400
        assert "differ" in str(e.value)
        failed = audit.actions("password_change_failed")
        assert failed and failed[-1]["detail"]["reason"] == "same_as_current"

    def test_provisional_password_stays_provisional(self, auth, store):
        user = AppUser(username="bob", role="operator")
        user.set_password(PASSWORD)
        user.must_change_password = True
        store.create(user)
        with pytest.raises(AuthError):
            auth.change_password(user, PASSWORD, PASSWORD)
        assert store.get_by_username("bob").must_change_password is True

    def test_a_different_password_is_accepted(self, auth, store, admin):
        auth.change_password(admin, PASSWORD, "AnotherHorse77")
        assert store.get_by_username("alice").check_password(
            "AnotherHorse77")


# ── BUG-033: every session, the caller's own included, ends ─────────

class TestPasswordChangeEndsEverySession:
    def test_all_sessions_revoked(self, auth, admin):
        first, _ = auth.authenticate("alice", PASSWORD)
        second, _ = auth.authenticate("alice", PASSWORD)
        auth.change_password(admin, PASSWORD, "AnotherHorse77")
        for token in (first, second):
            with pytest.raises(AuthError):
                auth.verify(token)


# ── BUG-034: one Windows account maps to one console account ────────

class TestWindowsMapping:
    def test_second_mapping_refused_on_create(self, store):
        store.create(AppUser(username="dave", windows_account="CORP\\Ops"))
        with pytest.raises(ValueError, match="already mapped to 'dave'"):
            store.create(AppUser(username="erin",
                                 windows_account=" corp\\OPS "))
        assert store.get_by_username("erin") is None

    def test_find_returns_every_holder(self, store):
        store.create(AppUser(username="dave", windows_account="CORP\\Ops"))
        erin = store.create(AppUser(username="erin", password_hash="x"))
        erin.windows_account = "corp\\ops"          # legacy duplicate
        store.update(erin)
        names = [u.username for u in store.find_by_windows_account(
            "CORP\\OPS")]
        assert names == ["dave", "erin"]
        # The single-result lookup keeps its contract.
        assert store.get_by_windows_account("corp\\ops").username == "dave"
        assert store.find_by_windows_account("") == []

    def test_ambiguous_mapping_refuses_sso(self, auth, store, audit):
        store.create(AppUser(username="dave", role="admin",
                             windows_account="CORP\\Ops"))
        erin = store.create(AppUser(username="erin", role="viewer"))
        erin.windows_account = "CORP\\ops"
        store.update(erin)
        with pytest.raises(AuthError) as e:
            auth.authenticate_windows("corp\\OPS")
        assert e.value.status_code == 403
        assert "more than one console account" in str(e.value)
        failed = audit.actions("login_failed")
        assert failed[-1]["detail"]["reason"] == "ambiguous_mapping"
        assert audit.actions("login_succeeded") == []

    def test_single_mapping_still_signs_in(self, auth, store):
        store.create(AppUser(username="dave", role="operator",
                             windows_account="CORP\\Dave"))
        _, user = auth.authenticate_windows("corp\\dave")
        assert user.username == "dave"


# ── BUG-018: only ASCII digits ──────────────────────────────────────

def _submit(**kw):
    from src.modules.intake.schemas import SubmitRequest
    body = {"operation": "provision", "affiliation_code": "30822",
            "employee_code": "1217036", "password": "FUJI@33F"}
    body.update(kw)
    return SubmitRequest(**body)


class TestAsciiDigits:
    @pytest.mark.parametrize("code", ["１２３４５", "1234²", "١٢٣٤٥"])
    def test_non_ascii_affiliation_rejected(self, code):
        from src.modules.intake.schemas import validate_request_format
        problems = validate_request_format(_submit(affiliation_code=code))
        assert any("half-width (ASCII) digits 0-9" in p for p in problems)

    @pytest.mark.parametrize("code", ["822", "30822", "00822"])
    def test_ascii_affiliation_still_accepted(self, code):
        from src.modules.intake.schemas import validate_request_format
        assert validate_request_format(_submit(affiliation_code=code)) == []

    def test_full_width_employee_code_rejected(self):
        from src.modules.intake.schemas import validate_request_format
        problems = validate_request_format(_submit(employee_code="１２１７０３６"))
        assert any("Employee code must use half-width" in p
                   for p in problems)

    def test_ascii_employee_code_accepted(self):
        from src.modules.intake.schemas import validate_request_format
        assert validate_request_format(_submit(employee_code="A217036")) == []

    def test_sailpoint_affiliation_rejects_other_unicode_digits(self):
        from src.integrations.servicenow.sailpoint import _affiliation
        code, _, problem = _affiliation("١٢٣٤٥ | Tokyo")
        assert code == "" and "not a 5-digit code" in problem

    def test_sailpoint_affiliation_keeps_ascii_and_padding(self):
        from src.integrations.servicenow.sailpoint import _affiliation
        assert _affiliation("822 | Tokyo")[0] == "00822"
        # Full-width digits in a ticket are normalised, as before.
        assert _affiliation("３０８２２ | Tokyo")[0] == "30822"


# ── BUG-039: date filters must be ISO dates ─────────────────────────

class TestIsoDate:
    @pytest.mark.parametrize("value", ["2026-09-26",
                                       "2026-09-26T10:00:00+09:00",
                                       "2026-09-26 10:00:00"])
    def test_valid(self, value):
        from src.modules.intake.schemas import validate_iso_date
        assert validate_iso_date("date_from", value) == value

    @pytest.mark.parametrize("value", ["26/09/2026", "garbage",
                                       "2026-13-01", "2026-02-30",
                                       "2026-09-26Tnonsense"])
    def test_invalid(self, value):
        from src.modules.intake.schemas import validate_iso_date
        with pytest.raises(ValueError,
                           match="date_to must be an ISO date YYYY-MM-DD"):
            validate_iso_date("date_to", value)

    @pytest.mark.parametrize("value", [None, "", "  "])
    def test_empty_is_no_filter(self, value):
        from src.modules.intake.schemas import validate_iso_date
        assert validate_iso_date("date_from", value) is None


# ── BUG-040: a date-only end date includes the whole day ────────────

class TestAuditEndOfDay:
    def test_today_to_today_returns_todays_events(self, tmp_path):
        from src.modules.audit.trail import AuditTrail
        from src.modules.audit.trail_db import SQLiteAuditBackend
        backend = SQLiteAuditBackend(str(tmp_path / "audit.db"))
        backend.ensure_schema()
        trail = AuditTrail(backend, spool_path=str(tmp_path / "spool.db"),
                           flush_interval=0.05)
        try:
            trail.event("api", "request_submitted", request_id="req_a")
            assert trail.flush(timeout=5)
            today = now_jst().date().isoformat()
            events = backend.query_events(date_from=today, date_to=today)
            assert [e["request_id"] for e in events] == ["req_a"]
            # An explicit timestamp is still used as given.
            yesterday = (now_jst() - timedelta(days=1)).date().isoformat()
            assert backend.query_events(
                date_to=f"{yesterday}T23:59:59+09:00") == []
        finally:
            trail.close()


# ── BUG-052: the error-rule toggle is locked and atomic ─────────────

_RULES_TEXT = "# Reviewed catalogue — comments must survive.\nerrors:\n" + "".join(
    f"  # rule {i} — why it exists\n  - id: RULE_{i:02d}\n"
    f"    name: Rule {i}\n    markers: [\"M{i}\"]\n" for i in range(20))


class TestRuleFileToggle:
    def _file(self, tmp_path, text=_RULES_TEXT):
        path = tmp_path / "errors.yaml"
        path.write_text(text, encoding="utf-8")
        return path

    def test_same_bytes_as_before_and_no_temp_file_left(self, tmp_path):
        from src.modules.console.yaml_edit import (
            set_rule_enabled, toggle_rule_file,
        )
        path = self._file(tmp_path)
        expected = tmp_path / "expected.yaml"
        expected.write_text(set_rule_enabled(_RULES_TEXT, "RULE_03", False),
                            encoding="utf-8")
        toggle_rule_file(path, "RULE_03", False)
        assert path.read_bytes() == expected.read_bytes()
        assert sorted(p.name for p in tmp_path.iterdir()) == [
            "errors.yaml", "expected.yaml"]
        assert "# rule 3 — why it exists" in path.read_text(encoding="utf-8")

    def test_unknown_rule_leaves_the_file_alone(self, tmp_path):
        from src.modules.console.yaml_edit import (
            RuleNotFound, toggle_rule_file,
        )
        path = self._file(tmp_path)
        with pytest.raises(RuleNotFound):
            toggle_rule_file(path, "NOPE", False)
        assert path.read_text(encoding="utf-8") == _RULES_TEXT
        assert [p.name for p in tmp_path.iterdir()] == ["errors.yaml"]

    def test_failed_replace_keeps_the_original(self, tmp_path, monkeypatch):
        from src.modules.console import yaml_edit
        path = self._file(tmp_path)

        def boom(src, dst):
            raise OSError("disk full")
        monkeypatch.setattr(yaml_edit.os, "replace", boom)
        with pytest.raises(OSError):
            yaml_edit.toggle_rule_file(path, "RULE_01", False)
        assert path.read_text(encoding="utf-8") == _RULES_TEXT
        assert [p.name for p in tmp_path.iterdir()] == ["errors.yaml"]

    def test_windows_replace_is_retried(self, tmp_path, monkeypatch):
        from src.modules.console import yaml_edit
        src = tmp_path / "new.tmp"
        dst = tmp_path / "errors.yaml"
        src.write_text("new", encoding="utf-8")
        dst.write_text("old", encoding="utf-8")
        real_replace = yaml_edit.os.replace
        calls = []

        def flaky(a, b):
            calls.append(1)
            if len(calls) < 3:
                raise PermissionError("in use")
            real_replace(a, b)
        monkeypatch.setattr(yaml_edit.os, "replace", flaky)
        monkeypatch.setattr(yaml_edit.sys, "platform", "win32")
        monkeypatch.setattr(yaml_edit.time, "sleep", lambda s: None)
        yaml_edit._replace(str(src), dst)
        assert len(calls) == 3
        assert dst.read_text(encoding="utf-8") == "new"

    def test_concurrent_toggles_are_all_applied(self, tmp_path):
        from src.modules.console.yaml_edit import toggle_rule_file
        path = self._file(tmp_path)
        errors = []

        def disable(i):
            try:
                toggle_rule_file(path, f"RULE_{i:02d}", False)
            except Exception as e:           # pragma: no cover
                errors.append(e)

        threads = [threading.Thread(target=disable, args=(i,))
                   for i in range(20)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=10)
        assert errors == []
        data = yaml.safe_load(path.read_text(encoding="utf-8"))
        assert len(data["errors"]) == 20
        assert all(rule["enabled"] is False for rule in data["errors"])
        assert [p.name for p in Path(tmp_path).iterdir()] == ["errors.yaml"]
