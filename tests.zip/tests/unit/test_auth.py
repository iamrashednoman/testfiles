"""Console authentication — accounts, sessions, roles, lockout.

The machine API key (FINESIII_API_KEYS) authenticates SERVICES and is
deliberately untouched by all of this; there are tests below pinning
that the two schemes stay independent.
"""
import sys
import tempfile

import pytest

from src.core.db import Database
from src.modules.auth.models import (
    AppUser, Role, hash_password, password_problems, verify_password,
)
from src.modules.auth.services import AuthError, AuthService
from src.modules.auth.store import UserStore


class Cfg:
    """Minimal config stand-in."""
    jwt_secret = "test-signing-key-not-for-production-0123456789"
    jwt_ttl_seconds = 3600
    auth_min_password_length = 12
    auth_max_failed_attempts = 3
    auth_lockout_seconds = 900
    auth_windows_sso_enabled = False


@pytest.fixture
def store():
    return UserStore(Database("sqlite",
                              sqlite_path=tempfile.mktemp(suffix=".db")))


@pytest.fixture
def auth(store):
    return AuthService(store, Cfg())


@pytest.fixture
def admin(store):
    user = AppUser(username="alice", role=Role.ADMIN.value)
    user.set_password("CorrectHorse42")
    return store.create(user)


# ── Password hashing ────────────────────────────────────────────────

class TestPasswordHashing:
    def test_round_trip(self):
        h, s = hash_password("CorrectHorse42")
        assert verify_password("CorrectHorse42", h, s)
        assert not verify_password("wrong", h, s)

    def test_salted_uniquely(self):
        """Two users with the SAME password must not share a hash."""
        h1, s1 = hash_password("CorrectHorse42")
        h2, s2 = hash_password("CorrectHorse42")
        assert s1 != s2 and h1 != h2

    def test_plaintext_is_never_stored(self):
        user = AppUser(username="bob")
        user.set_password("CorrectHorse42")
        assert "CorrectHorse42" not in str(user.to_dict())

    def test_empty_hash_never_verifies(self):
        """An SSO-only account has no password and must never be
        password-authenticated."""
        assert not verify_password("anything", "", "")
        assert not AppUser(username="sso").check_password("anything")

    def test_malformed_salt_is_rejected_not_raised(self):
        assert verify_password("x", "deadbeef", "not-hex") is False

    def test_policy(self):
        assert password_problems("CorrectHorse42") == []
        assert "at least 12 characters" in " ".join(
            password_problems("Short1"))
        assert "must contain a digit" in " ".join(
            password_problems("NoDigitsHereAtAll"))


# ── Roles ───────────────────────────────────────────────────────────

class TestRoles:
    @pytest.mark.parametrize("role,required,allowed", [
        ("admin", "admin", True), ("admin", "operator", True),
        ("admin", "viewer", True),
        ("operator", "admin", False), ("operator", "operator", True),
        ("operator", "viewer", True),
        ("viewer", "admin", False), ("viewer", "operator", False),
        ("viewer", "viewer", True),
    ])
    def test_rank_ordering(self, role, required, allowed):
        assert AppUser(username="u", role=role).can(required) is allowed

    def test_inactive_user_can_do_nothing(self):
        user = AppUser(username="u", role="admin", is_active=False)
        assert not user.can("viewer")

    def test_a_role_must_be_named(self):
        with pytest.raises(ValueError, match="must have a role"):
            AppUser(username="u", role="")

    def test_custom_role_names_are_accepted(self):
        """Roles are DATA now: a custom role is as valid as a built-in
        one. Whether it EXISTS is the store's business, checked when a
        user is created or updated."""
        assert AppUser(username="u", role="auditor").role == "auditor"


# ── Store ───────────────────────────────────────────────────────────

class TestUserStore:
    def test_fresh_install_has_no_users(self, store):
        assert store.count() == 0

    def test_usernames_are_case_insensitive(self, store, admin):
        assert store.get_by_username("ALICE").user_id == admin.user_id

    def test_duplicate_username_rejected(self, store, admin):
        with pytest.raises(ValueError, match="already exists"):
            store.create(AppUser(username="Alice"))

    def test_last_admin_is_countable(self, store, admin):
        assert store.count_active_admins() == 1
        assert store.count_active_admins(excluding=admin.user_id) == 0

    def test_windows_lookup_is_case_insensitive(self, store):
        user = AppUser(username="dave", windows_account="CORP\\Dave")
        store.create(user)
        assert store.get_by_windows_account("corp\\dave") is not None
        assert store.get_by_windows_account("") is None


# ── Sign-in ─────────────────────────────────────────────────────────

class TestAuthentication:
    def test_successful_login_returns_a_usable_token(self, auth, admin):
        token, user = auth.authenticate("alice", "CorrectHorse42")
        assert user.username == "alice"
        assert auth.verify(token).user_id == admin.user_id

    def test_wrong_password_rejected(self, auth, admin):
        with pytest.raises(AuthError):
            auth.authenticate("alice", "wrong")

    def test_unknown_user_and_wrong_password_are_indistinguishable(
            self, auth, admin):
        """Different messages would be a user-enumeration oracle."""
        with pytest.raises(AuthError) as unknown:
            auth.authenticate("nobody", "whatever")
        with pytest.raises(AuthError) as wrong:
            auth.authenticate("alice", "wrong")
        assert str(unknown.value) == str(wrong.value)

    def test_inactive_account_cannot_sign_in(self, auth, store, admin):
        admin.is_active = False
        store.update(admin)
        with pytest.raises(AuthError):
            auth.authenticate("alice", "CorrectHorse42")

    def test_lockout_after_repeated_failures(self, auth, store, admin):
        for _ in range(Cfg.auth_max_failed_attempts):
            with pytest.raises(AuthError):
                auth.authenticate("alice", "wrong")
        # Even the CORRECT password is refused while locked.
        with pytest.raises(AuthError) as e:
            auth.authenticate("alice", "CorrectHorse42")
        # The same answer as a wrong password (D-07, 2026-10-05).
        assert e.value.status_code == 401
        assert str(e.value) == "Invalid username or password"
        assert store.get_by_username("alice").is_locked()

    def test_successful_login_clears_the_failure_count(
            self, auth, store, admin):
        with pytest.raises(AuthError):
            auth.authenticate("alice", "wrong")
        auth.authenticate("alice", "CorrectHorse42")
        assert store.get_by_username("alice").failed_attempts == 0

    def test_login_records_the_timestamp(self, auth, store, admin):
        auth.authenticate("alice", "CorrectHorse42")
        assert store.get_by_username("alice").last_login_at


# ── Sessions ────────────────────────────────────────────────────────

class TestSessions:
    def test_garbage_token_rejected(self, auth):
        for bad in ("", "not-a-token", "a.b.c"):
            with pytest.raises(AuthError):
                auth.verify(bad)

    def test_token_signed_with_another_key_rejected(self, auth, admin):
        import jwt
        forged = jwt.encode({"sub": admin.user_id, "role": "admin",
                             "sid": "ses_x", "exp": 9999999999},
                            "a-different-key-of-sufficient-length-000000",
                            algorithm="HS256")
        with pytest.raises(AuthError):
            auth.verify(forged)

    def test_logout_revokes_immediately(self, auth, admin):
        token, _ = auth.authenticate("alice", "CorrectHorse42")
        auth.logout(token)
        with pytest.raises(AuthError, match="no longer valid"):
            auth.verify(token)

    def test_deactivation_kills_a_live_session(self, auth, store, admin):
        """Revocation must not wait for the token to expire."""
        token, _ = auth.authenticate("alice", "CorrectHorse42")
        admin.is_active = False
        store.update(admin)
        store.revoke_all_for_user(admin.user_id)
        with pytest.raises(AuthError):
            auth.verify(token)

    def test_password_change_signs_out_other_sessions(
            self, auth, store, admin):
        old_token, _ = auth.authenticate("alice", "CorrectHorse42")
        auth.change_password(store.get_by_username("alice"),
                             "CorrectHorse42", "BrandNewSecret99")
        with pytest.raises(AuthError):
            auth.verify(old_token)
        auth.authenticate("alice", "BrandNewSecret99")

    def test_password_change_requires_the_current_one(
            self, auth, store, admin):
        with pytest.raises(AuthError) as e:
            auth.change_password(admin, "wrong", "BrandNewSecret99")
        assert e.value.status_code == 403

    def test_password_change_enforces_policy(self, auth, admin):
        with pytest.raises(AuthError, match="at least 12"):
            auth.change_password(admin, "CorrectHorse42", "short1")


# ── First-run bootstrap ─────────────────────────────────────────────

class TestBootstrap:
    def test_fresh_install_needs_bootstrap(self, auth):
        assert auth.needs_bootstrap()

    def test_bootstrap_creates_an_admin(self, auth):
        user = auth.bootstrap_admin("root", "CorrectHorse42", "Root")
        assert user.role == Role.ADMIN.value
        assert not auth.needs_bootstrap()
        auth.authenticate("root", "CorrectHorse42")

    def test_bootstrap_refused_once_initialised(self, auth, admin):
        """Otherwise it would be an unauthenticated admin-creation
        endpoint."""
        with pytest.raises(AuthError) as e:
            auth.bootstrap_admin("mallory", "CorrectHorse42")
        assert e.value.status_code == 409

    def test_bootstrap_enforces_password_policy(self, auth):
        with pytest.raises(AuthError, match="at least 12"):
            auth.bootstrap_admin("root", "weak")


# ── Signing key ─────────────────────────────────────────────────────

class TestSigningKey:
    def test_configured_secret_wins(self, store):
        assert AuthService(store, Cfg()).secret == Cfg.jwt_secret

    def test_generated_key_is_stable_and_private(self, store, tmp_path,
                                                 monkeypatch):
        """A desktop install has no env to set JWT_SECRET in, so the key
        is generated once and REUSED — regenerating it on every start
        would invalidate every session on restart."""
        monkeypatch.setenv("FINESIII_DATA_DIR", str(tmp_path))

        class NoSecret(Cfg):
            jwt_secret = ""

        first = AuthService(store, NoSecret()).secret
        second = AuthService(store, NoSecret()).secret
        assert first and first == second
        key_file = tmp_path / ".jwt_secret"
        assert key_file.is_file()
        if sys.platform != "win32":
            assert oct(key_file.stat().st_mode)[-3:] == "600"

    def test_no_hardcoded_fallback(self, store, tmp_path, monkeypatch):
        monkeypatch.setenv("FINESIII_DATA_DIR", str(tmp_path))

        class NoSecret(Cfg):
            jwt_secret = ""

        assert len(AuthService(store, NoSecret()).secret) >= 32


# ── Windows SSO ─────────────────────────────────────────────────────

class TestWindowsSso:
    def test_identity_comes_from_the_os_not_the_request(self):
        """The whole safety argument: the account is read from the
        operating system, so there is no request field to forge."""
        import ast
        import inspect

        import pytest

        from src.modules.auth.services import current_windows_account
        if not inspect.isfunction(current_windows_account):
            pytest.skip("source inspection is not possible on a natively "
                        "compiled module (packaging/compile.py); the "
                        "behaviour is covered by the SSO route tests")
        tree = ast.parse(inspect.getsource(current_windows_account))
        fn = tree.body[0]
        if (fn.body and isinstance(fn.body[0], ast.Expr)
                and isinstance(fn.body[0].value, ast.Constant)):
            fn.body.pop(0)              # drop the docstring, keep code
        code = ast.unparse(fn).lower()
        assert "request" not in code, code
        if sys.platform != "win32":
            assert current_windows_account() == ""

    def test_unmapped_account_refused(self, auth):
        with pytest.raises(AuthError) as e:
            auth.authenticate_windows("CORP\\stranger")
        assert e.value.status_code == 403

    def test_mapped_account_signs_in(self, auth, store):
        user = AppUser(username="dave", role="operator",
                       windows_account="CORP\\Dave", auth_source="windows")
        store.create(user)
        token, signed_in = auth.authenticate_windows("corp\\dave")
        assert signed_in.username == "dave"
        assert auth.verify(token).role == "operator"

    def test_inactive_mapped_account_refused(self, auth, store):
        user = AppUser(username="dave", windows_account="CORP\\Dave",
                       is_active=False)
        store.create(user)
        with pytest.raises(AuthError):
            auth.authenticate_windows("CORP\\Dave")
