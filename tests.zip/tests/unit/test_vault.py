"""OS credential vault overlay (P2) — with an in-memory store.

The keyring backends themselves are the OS's; what is ours is the
contract: only listed names, environment always wins, secrets are
applied to the process immediately, and nothing ever reports a value.
"""
import os

import pytest


@pytest.fixture
def memory_vault():
    from desktop import vault
    previous = vault._vault
    store = vault.MemoryVault()
    vault.use_vault(store)
    yield store
    vault.use_vault(previous)


class TestContract:
    def test_only_listed_names(self, memory_vault):
        from desktop import vault
        with pytest.raises(KeyError):
            vault.set_secret("ANYTHING", "x")
        with pytest.raises(KeyError):
            vault.delete_secret("ANYTHING")

    def test_set_applies_to_the_process_immediately(self, memory_vault,
                                                    monkeypatch):
        from desktop import vault
        monkeypatch.delenv("SMTP_PASSWORD", raising=False)
        vault.set_secret("SMTP_PASSWORD", "s3cret")
        assert memory_vault.get("SMTP_PASSWORD") == "s3cret"
        assert os.environ["SMTP_PASSWORD"] == "s3cret"
        vault.delete_secret("SMTP_PASSWORD")
        assert "SMTP_PASSWORD" not in os.environ
        assert memory_vault.get("SMTP_PASSWORD") is None

    def test_load_never_overrides_the_environment(self, memory_vault,
                                                  monkeypatch):
        from desktop import vault
        monkeypatch.setenv("FINESIII_PASSWORD", "from-env")
        monkeypatch.delenv("DATABASE_PASSWORD", raising=False)
        memory_vault.set("FINESIII_PASSWORD", "from-vault")
        memory_vault.set("DATABASE_PASSWORD", "dbpw")
        loaded = vault.load_secrets_into_env()
        assert loaded == ["DATABASE_PASSWORD"]
        assert os.environ["FINESIII_PASSWORD"] == "from-env"
        assert os.environ["DATABASE_PASSWORD"] == "dbpw"
        monkeypatch.delenv("DATABASE_PASSWORD")

    def test_status_reports_presence_and_source_never_values(
            self, memory_vault, monkeypatch):
        from desktop import vault
        monkeypatch.setenv("JWT_SECRET", "env-value")
        monkeypatch.delenv("SMTP_PASSWORD", raising=False)
        monkeypatch.delenv("FINESIII_PASSWORD", raising=False)
        memory_vault.set("SMTP_PASSWORD", "vault-value")
        st = vault.status()
        assert st["JWT_SECRET"] == {"label": st["JWT_SECRET"]["label"],
                                    "set": True, "source": "environment"}
        assert st["SMTP_PASSWORD"]["source"] == "vault"
        assert st["FINESIII_PASSWORD"]["set"] is False
        assert "env-value" not in str(st) and "vault-value" not in str(st)

    def test_unavailable_vault_is_reported_not_fatal(self, monkeypatch):
        from desktop import vault

        class Broken:
            name = "broken"
            available = False
            error = "no store"

        previous = vault._vault
        vault.use_vault(Broken())
        try:
            assert vault.load_secrets_into_env() == []
            assert vault.vault_info()["available"] is False
        finally:
            vault.use_vault(previous)
