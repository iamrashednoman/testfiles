"""Module checks (2026-09-29, T1–T5).

  T1/T2  terminal check: launch and navigate on the mock terminal; the
         keystrokes never include '70'; failures are named with a hint
         and the terminal is always signed off; one check at a time.
  T3     ServiceNow preview: dry_run is read-only (no note, claim,
         hand-over, e-mail, audit or remembered report) and lists what
         the bot would do with each ticket.
  T5     the console offers the module tests on the Settings pages.
"""
from pathlib import Path
from types import SimpleNamespace

import pytest

from src.integrations.servicenow.config import ServiceNowSettings
from src.integrations.servicenow.connector import (
    ReportMemory, ServiceNowConnector,
)
from tests.conftest import make_config

ROOT = Path(__file__).resolve().parents[2]


# ── T1/T2: terminal check ──────────────────────────────────────────

@pytest.fixture
def check(tmp_path, monkeypatch):
    """A terminal check on the mock terminal, recording the driver."""
    import src.rpa.executor as executor_mod
    from src.modules.queue.dispatcher import build_executor
    from src.rpa.terminal_check import TerminalCheck
    monkeypatch.setattr("time.sleep", lambda s: None)
    cfg = make_config(tmp_path, terminal_driver="mock",
                      dispatcher_enabled=False)
    ex = build_executor(cfg)
    drivers = []
    real_create = executor_mod.create_driver

    def create(rpa_config):
        d = real_create(rpa_config)
        drivers.append(d)
        return d
    monkeypatch.setattr(executor_mod, "create_driver", create)

    def run(level, scenario="success"):
        ex.rpa_config["application"]["mock_scenario"] = scenario
        return TerminalCheck(ex).run(level), drivers[-1]
    return run


class TestTerminalCheck:
    def test_launch_never_signs_in(self, check):
        result, driver = check("launch")
        assert result["ok"] and result["sign_off"]["ok"]
        assert [s["step"] for s in result["steps"]] == ["launch", "sign_off"]
        assert driver.typed_values == []             # nothing typed
        assert driver.commands == ["99", "XX"]       # menu closed
        assert Path(result["evidence_folder"]).name.startswith(
            "terminal-check-")
        assert list(Path(result["evidence_folder"]).glob("*.png"))

    def test_navigate_reaches_903_and_submits_nothing(self, check):
        result, driver = check("navigate")
        assert result["ok"] and result["sign_off"]["ok"], result
        assert [s["step"] for s in result["steps"]] == [
            "launch", "open_login", "sign_in", "task_903", "sign_off"]
        assert "70" not in driver.commands
        # '00' only as the sign-in command, never at the execution field.
        assert driver.commands.count("00") == 1
        assert driver.commands.index("00") < driver.commands.index("903")
        assert "903" in driver.commands and driver.commands[-1] == "XX"

    def test_rejected_password_is_named_and_signed_off(self, check):
        result, driver = check("navigate", "login_password_incorrect")
        assert not result["ok"]
        assert result["failed_step"] == "sign_in"
        assert result["hint"]
        assert "903" not in driver.commands and "70" not in driver.commands
        assert result["steps"][-1]["step"] == "sign_off"

    def test_centre_not_ready_is_recognised(self, check):
        result, driver = check("navigate", "center_not_ready")
        assert not result["ok"]
        assert result["failed_step"] == "open_login"
        assert "CENTER_NOT_READY" in result["hint"]
        assert driver.typed_values == [] or "70" not in driver.commands

    def test_one_check_at_a_time(self, tmp_path):
        from src.rpa.terminal_check import TerminalCheck
        tc = TerminalCheck(SimpleNamespace(rpa_config={"driver": "mock"}))
        tc._lock.acquire()
        try:
            assert tc.running
            with pytest.raises(RuntimeError):
                tc.run("launch")
        finally:
            tc._lock.release()
        with pytest.raises(ValueError):
            tc.run("commit")


# ── T3: ServiceNow preview is read-only ────────────────────────────

MAPPING = {"ticket_number": "number", "operation": "u_op",
           "affiliation_code": "u_aff", "employee_code": "u_emp"}


def ticket(n, emp="1217036", aff="30822", op="provision"):
    return {"sys_id": f"sid-{n}", "number": f"SCTASK{n:04d}", "u_op": op,
            "u_aff": aff, "u_emp": emp, "state": "1", "active": "true",
            "sys_created_on": f"2026-09-26 10:00:{n:02d}"}


class RecordingClient:
    def __init__(self, tickets):
        self.tickets, self.writes = tickets, []

    def fetch_assigned_open(self):
        return list(self.tickets)

    def add_work_note(self, *a, **k):
        self.writes.append(("note", a))

    def claim(self, *a, **k):
        self.writes.append(("claim", a))

    def reassign(self, *a, **k):
        self.writes.append(("reassign", a))

    def set_state(self, *a, **k):
        self.writes.append(("state", a))

    def user_sys_id(self, *a):
        return "bot-sys-id"


class TestServiceNowPreview:
    def _connector(self, tickets, **kw):
        s = ServiceNowSettings(
            instance_url="https://dev.service-now.com", username="bot",
            assigned_to="bot",
            password="pw", table="sc_task", field_mapping=MAPPING,
            respect_service_health=False, claim_on_pickup=True,
            reject_note_enabled=True, reject_reassign_group="Service Desk",
            writeback_enabled=True, max_per_poll=2, **kw)
        client = RecordingClient(tickets)
        rejected, audited, submitted = [], [], []
        c = ServiceNowConnector(s, client=client,
                                on_rejected=lambda *a: rejected.append(a))
        c.audit_hook = lambda e, d: audited.append(e)
        c._submit = lambda p: submitted.append(p) or "queued"
        c.reported = ReportMemory({})
        return c, client, rejected, audited, submitted

    def test_dry_run_writes_nothing_and_explains_each_ticket(self):
        known = ticket(1)
        unmappable = dict(ticket(2), u_emp="")
        duplicate = ticket(3, emp="7777777")
        bad_format = ticket(4, emp="12")
        fine = ticket(5, emp="5555555")
        later = ticket(6, emp="6666666")
        c, client, rejected, audited, submitted = self._connector(
            [known, unmappable, duplicate, bad_format, fine, later])
        c.known_ticket = lambda number: number == "SCTASK0001"
        c.duplicate_of = lambda payload, t: (
            {"request_id": "r-9", "ticket_id": "SCTASK0009",
             "status": "done", "matched_fields": ["u_emp"]}
            if payload["employee_code"] == "7777777" else None)
        memory_before = dict(c.reported.data)

        stats = c.poll_once(dry_run=True)

        # Nothing written, sent, audited, submitted or remembered.
        assert client.writes == [] and rejected == [] and audited == []
        assert submitted == [] and c.reported.data == memory_before
        by = {t["ticket"]: t for t in stats["tickets"]}
        assert by["SCTASK0001"]["action"] == "skip"
        assert by["SCTASK0002"]["action"] == "reject"
        assert "missing" in by["SCTASK0002"]["reason"]
        assert by["SCTASK0003"]["action"] == "skip"
        assert "duplicate of SCTASK0009" in by["SCTASK0003"]["reason"]
        assert by["SCTASK0004"]["action"] == "reject"
        assert "Employee code" in by["SCTASK0004"]["reason"]
        assert by["SCTASK0005"]["action"] == "queue"
        assert by["SCTASK0005"]["requests"][0]["employee_code"] == "5555555"
        assert by["SCTASK0006"]["action"] == "defer"   # max 2 per poll

    def test_a_real_poll_still_writes(self):
        c, client, rejected, audited, submitted = self._connector(
            [dict(ticket(2), u_emp=""), ticket(5, emp="5555555")])
        stats = c.poll_once()
        assert "tickets" not in stats
        assert rejected and ("reassign" in [w[0] for w in client.writes])
        assert submitted and ("claim" in [w[0] for w in client.writes])

    def test_already_reported_is_shown_not_repeated(self):
        c, client, rejected, audited, submitted = self._connector(
            [dict(ticket(2), u_emp="")])
        c.poll_once()                                  # reported once
        writes = list(client.writes)
        stats = c.poll_once(dry_run=True)
        assert stats["tickets"][0]["already_reported"] is True
        assert client.writes == writes

    def test_known_ticket_update_not_delivered_by_the_preview(self):
        text = (ROOT / "desktop" / "snow_poller.py").read_text(
            encoding="utf-8")
        assert "if closeout is not None and not read_only:" in text


# ── T5: the console offers the tests on the Settings pages ─────────

class TestConsoleButtons:
    APP = (ROOT / "desktop" / "ui" / "app.js").read_text(encoding="utf-8")

    def test_settings_pages_offer_the_module_tests(self):
        for label in ("Test connection", "Discover fields", "Preview tickets",
                      "Test retrieval", "Test mainframe host",
                      "Test terminal launch", "Test sign-in and navigation"):
            assert f"'{label}'" in self.APP, label
        assert "const SETTINGS_TESTS" in self.APP
        assert "/system/test-terminal" in self.APP
        assert "/system/servicenow/preview" in self.APP
