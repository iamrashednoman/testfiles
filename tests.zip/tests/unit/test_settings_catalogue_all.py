"""Every dashboard setting and every drop-down choice (2026-09-28, A6).

For each setting of the catalogue:
  * every valid value (each choice of a drop-down, on and off, a value
    inside the range) is stored, applied, and read back by the part of
    the application that uses it;
  * clearing it puts the environment / configuration back as it was;
  * invalid values (outside the range, unknown choice, not on/off,
    unknown placeholder, unsafe text) are refused.
"""
import os

import pytest

from config.development import DevelopmentConfig
from src.core.db import Database
from src.modules.console.settings_catalogue import (
    BY_KEY, DEFAULT_SOURCES, EMAIL_KEYS, EMAIL_LIST_KEYS, SETTINGS,
    _load_default_source, coerce,
)
from src.modules.console.settings_store import (
    SettingsStore, _restore_env_overrides, apply_hot_env, apply_overrides,
)
from tests.conftest import make_config

ENV_KEYS = [s["key"] for s in SETTINGS if s["target"] == "env"]


def valid_values(spec) -> list:
    kind = spec["kind"]
    if kind == "bool":
        return ["true", "false"]
    if kind == "choice":
        return [c for c in spec["choices"]
                if c not in (spec.get("disabled_choices") or [])]
    if kind in ("int", "float"):
        lo = spec["min"] if spec["min"] is not None else 0
        hi = spec["cap"] if spec.get("cap") is not None else (
            spec["max"] if spec["max"] is not None else lo + 10)
        mid = lo + (hi - lo) / 2
        return [str(int(mid)) if kind == "int" else str(round(mid, 2))]
    if kind == "time":
        return ["07:15"]
    if kind == "csv":
        # Address lists hold e-mail addresses (checked when saved).
        if spec["key"] in EMAIL_LIST_KEYS:
            return ["alpha@example.com,beta@example.com"]
        return ["alpha,beta"]
    if kind == "template":
        return ["Ticket {ticket_id} done"]
    special = {"password_symbols": "#@", "SNOW_APPROVAL_FILTER":
               "request_item.approval=approved",
               "SNOW_USER_LOOKUP_FIELD": "employee_number",
               "SNOW_REQUESTED_FOR_FIELD": "request_item.requested_for",
               "SMTP_PORT": "2525",
               "ALERT_FROM": "FINESIII Bot <bot@example.com>",
               "EMAIL_CONTACT_ADDRESS": "registration@example.com",
               # Addresses signed in to: https and a plain host
               # (2026-10-03); the table is a table name.
               "SNOW_INSTANCE_URL": "https://example.service-now.com",
               "SNOW_TOKEN_URL": "https://example.service-now.com/oauth_token.do",
               "CYBERARK_BASE_URL": "https://vault.example.com",
               "SNOW_TABLE": "sc_task"}
    return [special.get(spec["key"], "sample-value")]


def invalid_values(spec) -> list:
    kind = spec["kind"]
    out = []
    if kind == "bool":
        out.append("maybe")
    if kind == "choice":
        out.append("not-a-choice")
    if kind in ("int", "float"):
        out.append("abc")
        if spec["min"] is not None:
            out.append(str(spec["min"] - 1))
        top = spec.get("cap") if spec.get("cap") is not None else spec["max"]
        if top is not None:
            out.append(str(top + 1))
    if kind == "time":
        out += ["25:00", "7"]
    if kind == "template":
        out.append("Done {no_such_placeholder}")
    if kind in ("str", "csv", "template"):
        out.append("two\nlines")
    if spec["key"] == "password_symbols":
        out.append("+")
    if spec["key"] == "SNOW_APPROVAL_FILTER":
        out.append("x^ORactive=true")
    if spec["key"] == "SNOW_REQUESTED_FOR_FIELD":
        out.append("requested_for^ORactive=true")
    if spec["key"] == "SNOW_REQUESTED_FOR":
        out.append("x^ORactive=true")
    if spec["key"] in EMAIL_LIST_KEYS | EMAIL_KEYS:
        out += ["not-an-email", "a@x.exampleBcc: other@x.example"]
    # 2026-10-03: addresses signed in to, and values in the ticket query.
    if spec["key"] in ("SNOW_INSTANCE_URL", "SNOW_TOKEN_URL",
                       "CYBERARK_BASE_URL"):
        out += ["http://evil.example.com", "https://user:pw@host.example",
                "https://host.example?x=1", "ftp://host.example"]
    if spec["key"] == "SNOW_INSTANCE_URL":
        out.append("https://host.example/some/path")
    if spec["key"] in ("SNOW_ASSIGNED_TO", "SNOW_ASSIGNMENT_GROUP",
                       "SNOW_REJECT_REASSIGN_GROUP"):
        out.append("Group^NQactive=true")
    if spec["key"] == "SNOW_TABLE":
        out += ["sc_task;x", "sc_task?sysparm_query=x"]
    if spec["key"] == "SNOW_OPEN_STATES":
        out.append("1,x^y")
    return out


@pytest.fixture
def store(tmp_path, monkeypatch):
    for key in ENV_KEYS:
        monkeypatch.delenv(key, raising=False)
    db = Database.from_config(make_config(tmp_path))
    yield SettingsStore(db)
    _restore_env_overrides()
    db.close()


def applied(store):
    cfg = DevelopmentConfig(_env_file=None)
    apply_overrides(cfg, store)
    apply_hot_env(store)
    return cfg


@pytest.mark.parametrize("spec", SETTINGS, ids=[s["key"] for s in SETTINGS])
def test_every_value_applies_and_clears(store, spec):
    key = spec["key"]
    default_cfg = DevelopmentConfig(_env_file=None)
    for raw in valid_values(spec):
        value = coerce(spec, raw)
        store.set(key, str(raw), actor="test")
        cfg = applied(store)
        if spec["target"] == "config":
            assert getattr(cfg, key) == value, (key, raw)
        else:
            expected = ("true" if value is True else "false"
                        if value is False else str(value))
            assert os.environ.get(key) == expected, (key, raw)
        store.clear(key)
        cfg = applied(store)
        if spec["target"] == "config":
            assert getattr(cfg, key) == getattr(default_cfg, key), key
        else:
            assert key not in os.environ, key


@pytest.mark.parametrize("spec", SETTINGS, ids=[s["key"] for s in SETTINGS])
def test_invalid_values_refused(spec):
    for raw in invalid_values(spec):
        with pytest.raises(ValueError):
            coerce(spec, raw)


@pytest.mark.parametrize("key", sorted(DEFAULT_SOURCES))
def test_value_reaches_its_consumer(store, key):
    """The loader the application uses reads the saved value."""
    spec = BY_KEY[key]
    source, attr = DEFAULT_SOURCES[key]
    attr, _, sub = attr.partition(".")
    for raw in valid_values(spec):
        store.set(key, raw, actor="test")
        applied(store)
        obj = _load_default_source(source)
        got = getattr(obj, attr)
        if sub:
            got = got.get(sub)
        want = coerce(spec, raw)
        if spec["kind"] == "csv":
            want = [p for p in want.split(",") if p]
            got = list(got) if isinstance(got, (list, tuple)) else \
                [p for p in str(got).split(",") if p]
        elif spec["kind"] in ("int", "float"):
            got = type(want)(got)
        assert got == want, (key, raw, got)
        store.clear(key)
        applied(store)


def test_every_dropdown_has_choices():
    for spec in SETTINGS:
        if spec["kind"] == "choice":
            assert spec["choices"], spec["key"]


@pytest.mark.parametrize("spec", [s for s in SETTINGS
                                  if s["target"] == "config"],
                         ids=[s["key"] for s in SETTINGS
                              if s["target"] == "config"])
def test_clear_then_apply_again_on_the_same_object(store, spec):
    """BUG-054: a cleared configuration override does not survive a
    second apply to the SAME configuration object (in-place rebuild)."""
    key = spec["key"]
    cfg = DevelopmentConfig(_env_file=None)
    default = getattr(cfg, key)
    for raw in valid_values(spec):
        store.set(key, str(raw), actor="test")
        apply_overrides(cfg, store)
        assert getattr(cfg, key) == coerce(spec, raw), (key, raw)
        store.clear(key)
        apply_overrides(cfg, store)
        assert getattr(cfg, key) == default, (key, raw)


def test_cleared_retry_attempts_back_to_three_on_the_same_object(store):
    cfg = DevelopmentConfig(_env_file=None)
    store.set("max_attempts", "2", actor="test")
    apply_overrides(cfg, store)
    assert cfg.max_attempts == 2
    store.clear("max_attempts")
    apply_overrides(cfg, store)
    assert cfg.max_attempts == 3
