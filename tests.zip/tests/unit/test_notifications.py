"""Unit tests for the ported v2 email-notification stack.

No network, no real SMTP: a fake SMTP object is injected through the
notifier's smtp_factory, and YAML configs live in tmp_path. Handlers
and alerters run with async_send=False so behavior is deterministic.
"""
from __future__ import annotations

import logging
from types import SimpleNamespace

import pytest

from src.modules.notifications import (
    attach_email_alerts, build_availability_alerter,
    build_rejection_alerter, build_transaction_alerter,
)
from src.modules.notifications.availability_alerts import (
    AVAILABILITY_TEMPLATE_PATH, AvailabilityAlerter, COMPONENT_FINESIII,
)
from src.modules.notifications.config import (
    NotificationSettings, load_notification_config,
)
from src.modules.notifications.log_handler import EmailAlertHandler, _signature
from src.modules.notifications.notifier import EmailNotifier
from src.modules.notifications.rejection_alerts import (
    REJECTION_TEMPLATE_PATH, RejectionAlerter, build_details_rows_html,
)
from src.modules.notifications.transaction_alerts import (
    DEPROVISION_OPS_TEMPLATE, FAILURE_TEMPLATE, PROVISION_OPS_TEMPLATE,
    PROVISION_USER_TEMPLATE, TransactionAlerter,
    TransactionNotificationSettings,
)


# ── shared fakes / factories ────────────────────────────────────────

class FakeSMTP:
    def __init__(self, sink):
        self.sink = sink

    def send_message(self, msg, to_addrs=None):
        self.sink.append((msg, to_addrs))

    def quit(self):
        pass


def make_settings(**overrides):
    base = dict(
        enabled=True, smtp_host="smtp.test.local", smtp_port=587,
        use_starttls=True, use_ssl=False, username="",
        password="smtp-secret", mail_from="rpa@test.local",
        recipients_to=["dl@test.local"], environment_label="development",
        level="ERROR", mode="both", async_send=False,
        throttle_window_seconds=300.0, digest_interval_seconds=0.0,
        max_retries=0, backoff_base_seconds=0.0, backoff_max_seconds=0.0,
    )
    base.update(overrides)
    return NotificationSettings(**base)


def make_notifier(sink, **overrides):
    return EmailNotifier(make_settings(**overrides),
                         smtp_factory=lambda: FakeSMTP(sink))


def make_txn(**overrides):
    base = dict(
        transaction_id="txn_1", request_id="req_1", ticket_id="SCTASK100",
        operation="provision", affiliation_code="30822",
        employee_code="1217036", source="servicenow", status="done",
        result_code="O-0000", error_message="", attempt_count=1,
        submitted_at="2026-08-03T09:00:00+09:00",
        started_at="2026-08-03T09:01:00+09:00",
        completed_at="2026-08-03T09:02:30+09:00", duration_seconds=90.0,
        worker_id=0, evidence_path="evidence/txn1", screenshot_count=9,
        operator="A1Z0835",
    )
    base.update(overrides)
    return SimpleNamespace(**base)


def make_request(user_email="taro.yamada@example.com", password="FUJI@33F"):
    return SimpleNamespace(password=password,
                           metadata={"user_email": user_email})


def make_txn_alerter(sink, **settings_overrides):
    settings = TransactionNotificationSettings(enabled=True,
                                               **settings_overrides)
    return TransactionAlerter(make_notifier(sink), settings,
                              bot_config={}, async_send=False)


def plain_body(msg):
    return msg.get_body(("plain",)).get_content()


def rec(msg, level=logging.ERROR):
    return logging.LogRecord(name="finesiii_rpa_v3", level=level,
                             pathname=__file__, lineno=10, msg=msg,
                             args=(), exc_info=None, func="fn")


ENV_YAML = """
notifications:
  enabled: false
  env_vars:
    enabled: SMTP_ALERTS_ENABLED
    smtp_host: SMTP_HOST
    smtp_port: SMTP_PORT
    password: SMTP_PASSWORD
    mail_from: ALERT_FROM
    recipients_to: ALERT_TO
  behavior:
    dry_run: true
    async_send: false
    digest_interval_seconds: 0
"""


# ── settings loader + builders ──────────────────────────────────────

class TestLoaderAndBuilders:
    def test_missing_yaml_yields_disabled_inert(self, tmp_path):
        s = load_notification_config(str(tmp_path / "missing.yaml"))
        assert s.enabled is False
        s.validate()                              # inert, must not raise

    def test_disabled_yaml_returns_none_builders(self, tmp_path):
        cfg = tmp_path / "n.yaml"
        cfg.write_text("notifications:\n  enabled: false\n")
        assert attach_email_alerts(config_path=str(cfg)) is None
        assert build_transaction_alerter(None) is None
        assert build_availability_alerter(None) is None
        assert build_rejection_alerter(notifications_yaml=str(cfg)) is None

    def test_env_vars_enable_and_configure(self, tmp_path, monkeypatch):
        monkeypatch.setenv("SMTP_ALERTS_ENABLED", "true")
        monkeypatch.setenv("SMTP_HOST", "relay.corp.local")
        monkeypatch.setenv("SMTP_PORT", "587")
        monkeypatch.setenv("SMTP_PASSWORD", "envpw")
        monkeypatch.setenv("ALERT_FROM", "bot@corp.local")
        monkeypatch.setenv("ALERT_TO", "ops@corp.local, mgr@corp.local")
        cfg = tmp_path / "n.yaml"
        cfg.write_text(ENV_YAML)
        s = load_notification_config(str(cfg))
        assert s.enabled is True                  # env beat YAML false
        assert s.smtp_host == "relay.corp.local"
        assert s.password == "envpw"
        assert s.recipients_to == ["ops@corp.local", "mgr@corp.local"]
        s.validate()                              # must not raise

    def test_attach_wires_both_v3_loggers(self, tmp_path, monkeypatch):
        monkeypatch.setenv("SMTP_ALERTS_ENABLED", "true")
        monkeypatch.setenv("SMTP_HOST", "relay.local")
        monkeypatch.setenv("ALERT_FROM", "bot@local")
        monkeypatch.setenv("ALERT_TO", "dl@local")
        cfg = tmp_path / "n.yaml"
        cfg.write_text(ENV_YAML)
        handler = attach_email_alerts(config_path=str(cfg),
                                      environment="uat")
        assert handler is not None
        app = logging.getLogger("finesiii_rpa_v3")
        rpa = logging.getLogger("finesiii_rpa_v3.rpa")
        try:
            assert handler in app.handlers
            assert handler in rpa.handlers        # same instance on both
            assert handler.s.environment_label == "uat"
            rpa.error("synthetic error")          # dry_run → no transmit
        finally:
            app.removeHandler(handler)
            rpa.removeHandler(handler)
            handler.close()


# ── validate() ──────────────────────────────────────────────────────

class TestValidate:
    @pytest.mark.parametrize("overrides", [
        dict(smtp_host=""), dict(mail_from=""), dict(recipients_to=[]),
        dict(use_ssl=True, use_starttls=True),
    ])
    def test_rejects_bad_enabled_config(self, overrides):
        with pytest.raises(ValueError):
            make_settings(**overrides).validate()


# ── dedup signature + throttle ──────────────────────────────────────

class TestSignatureAndThrottle:
    def _handler(self, clock):
        sink = []
        settings = make_settings()
        notifier = EmailNotifier(settings,
                                 smtp_factory=lambda: FakeSMTP(sink))
        handler = EmailAlertHandler(notifier, settings,
                                    clock_func=lambda: clock["t"])
        return handler, sink

    def test_digit_normalization_shares_signature(self):
        assert _signature(rec("Worker error on req-12345")) == \
            _signature(rec("Worker error on req-99999"))

    def test_throttle_suppresses_counts_and_notes(self):
        clock = {"t": 1000.0}
        handler, sink = self._handler(clock)
        handler.emit(rec("Worker error on req-1"))
        handler.emit(rec("Worker error on req-2"))   # same shape → suppressed
        assert len(sink) == 1
        clock["t"] += 400                            # past the 300s window
        handler.emit(rec("Worker error on req-3"))   # new window → sends
        assert len(sink) == 2
        body = plain_body(sink[1][0])
        assert "1 earlier identical alert(s)" in body
        assert "suppressed" in body


# ── dry_run ─────────────────────────────────────────────────────────

class TestDryRun:
    def test_dry_run_never_touches_smtp_factory(self):
        invoked = []

        def factory():
            invoked.append(True)
            return FakeSMTP([])

        logs = []
        logger = SimpleNamespace(info=lambda m: logs.append(m),
                                 warning=lambda m: logs.append(m))
        n = EmailNotifier(make_settings(dry_run=True), logger=logger,
                          smtp_factory=factory)
        assert n.send("subj", "body") is True
        assert invoked == []
        assert any("DRY-RUN" in m for m in logs)


# ── transaction alerter ─────────────────────────────────────────────

class TestTransactionAlerter:
    def test_provision_success_sends_user_credentials_and_ops(self):
        sink = []
        make_txn_alerter(sink).handle_completion(make_txn(),
                                                 make_request(), {})
        # Ops notice, account-ready notice, and (include_password=true)
        # the password in a SEPARATE e-mail (2026-09-29, E-16).
        assert len(sink) == 3
        ops_msg = next(m for m, to in sink if to == ["dl@test.local"])
        user_msgs = [m for m, to in sink if to == ["taro.yamada@example.com"]]
        ready = next(m for m in user_msgs if "account is ready" in m["Subject"])
        password_msg = next(m for m in user_msgs if m is not ready)
        # The account-ready notice never carries the password...
        assert "FUJI@33F" not in plain_body(ready)
        assert "Sent to you in a separate e-mail." in plain_body(ready)
        # ...the separate notice does (the client's password template)...
        assert "FUJI@33F" in plain_body(password_msg)
        # ...and the SMTP password is still always masked.
        assert "smtp-secret" not in str(password_msg) + str(ready)
        assert "Provisioning completed" in ops_msg["Subject"]
        assert "SCTASK100" in plain_body(ops_msg)

    def test_deprovision_already_deleted_sends_ops_note(self):
        sink = []
        make_txn_alerter(sink).handle_completion(
            make_txn(operation="deprovision", status="already_deleted"),
            make_request(), {})
        assert len(sink) == 1
        msg = sink[0][0]
        assert "Deprovisioning completed" in msg["Subject"]
        assert "already deleted" in plain_body(msg)

    def test_failure_sends_failure_notice(self):
        sink = []
        make_txn_alerter(sink).handle_completion(
            make_txn(status="failed", error_message="screen timeout",
                     attempt_count=3),
            make_request(), {})
        assert len(sink) == 1
        msg = sink[0][0]
        assert "Transaction FAILED" in msg["Subject"]
        body = plain_body(msg)
        assert "3 attempt(s)" in body
        assert "screen timeout" in body


# ── rejection alerter ───────────────────────────────────────────────

class TestRejectionAlerter:
    def test_fires_with_details_and_masks_secrets(self):
        sink = []
        a = RejectionAlerter(make_notifier(sink), async_send=False)
        a.request_rejected("DUPLICATE REQUEST", "already known",
                           {"ticket_id": "SCTASK7",
                            "employee_code": "1217036",
                            "password": "FUJI@33F"})
        assert len(sink) == 1
        msg = sink[0][0]
        assert "Request rejected" in msg["Subject"]
        assert "SCTASK7" in msg["Subject"]
        body = plain_body(msg)
        assert "1217036" in body
        assert "FUJI@33F" not in body
        # The alerter masks to "****"; the notifier's transport-level
        # redaction then rewrites "Password: ****" to "Password: ***".
        assert "Password: ***" in body

    def test_details_rows_mask_password_like_keys(self):
        rows = build_details_rows_html({"employee_code": "1217036",
                                        "password": "FUJI@33F",
                                        "api_key": "KKK"})
        assert "FUJI@33F" not in rows and "KKK" not in rows
        assert "1217036" in rows
        assert REJECTION_TEMPLATE_PATH.endswith("request_rejected.html")


# ── availability alerter ────────────────────────────────────────────

class TestAvailabilityAlerter:
    def test_down_floor_and_recovery(self):
        sink = []
        a = AvailabilityAlerter(make_notifier(sink, html_enabled=True),
                                min_realert_seconds=300, async_send=False)
        a.finesiii_down("probe failed")
        assert len(sink) == 1
        outage = sink[0][0]
        assert COMPONENT_FINESIII in outage["Subject"]
        assert "NOT AVAILABLE" in plain_body(outage)

        a.finesiii_down("probe failed again")     # within floor → suppressed
        assert len(sink) == 1

        a.finesiii_recovered()                    # different state → sends
        assert len(sink) == 2
        assert "RECOVERED" in plain_body(sink[1][0])
        assert AVAILABILITY_TEMPLATE_PATH.endswith("availability_outage.html")
