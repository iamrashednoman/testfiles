"""Unit tests for the availability gate (v2 parity port)."""
from datetime import timedelta

import pytest

from src.modules.intake.models import now_jst
from src.modules.queue.availability import AvailabilityMonitor
from tests.conftest import make_config


def _hhmm(dt) -> str:
    return dt.strftime("%H:%M")


def make_monitor(tmp_path, **overrides):
    cfg = make_config(tmp_path, **overrides)
    return AvailabilityMonitor(cfg)


class TestTimeWindow:
    def test_open_window_allows_work(self, tmp_path):
        mon = make_monitor(tmp_path,
                           availability_window_start="00:00",
                           availability_window_end="23:59",
                           shutdown_buffer_minutes=0,
                           health_check_enabled=False)
        mon.start()          # health off → forced healthy, no thread
        assert mon.can_start_new_work() is True
        assert mon.can_continue_work() is True

    def test_closed_window_blocks_new_work(self, tmp_path):
        now = now_jst()
        # A window that ended over an hour ago (wrap-safe: use fixed
        # midnight-to-past window unless we're right after midnight).
        start = (now - timedelta(hours=3))
        end = (now - timedelta(hours=2))
        if start.date() != now.date():
            pytest.skip("too close to midnight for this window shape")
        mon = make_monitor(tmp_path,
                           availability_window_start=_hhmm(start),
                           availability_window_end=_hhmm(end),
                           shutdown_buffer_minutes=0,
                           health_check_enabled=False)
        mon.start()
        assert mon.can_start_new_work() is False
        assert mon.can_continue_work() is False

    def test_shutdown_buffer_blocks_only_new_work(self, tmp_path):
        now = now_jst()
        start = now - timedelta(hours=2)
        end = now + timedelta(minutes=5)
        if start.date() != now.date() or end.date() != now.date():
            pytest.skip("too close to midnight for this window shape")
        # Window still open for 5 more minutes, but the 15-minute
        # buffer means no NEW work; in-flight work may continue.
        mon = make_monitor(tmp_path,
                           availability_window_start=_hhmm(start),
                           availability_window_end=_hhmm(end),
                           shutdown_buffer_minutes=15,
                           health_check_enabled=False)
        mon.start()
        assert mon.can_start_new_work() is False
        assert mon.can_continue_work() is True


class TestHealthProbe:
    def test_no_host_assumes_available(self, tmp_path):
        mon = make_monitor(tmp_path, health_check_enabled=True,
                           mainframe_host="",
                           availability_window_start="00:00",
                           availability_window_end="23:59",
                           shutdown_buffer_minutes=0)
        mon._run_tcp_probe()
        assert mon.is_health_ok() is True

    def test_login_probe_transitions_fire_hooks_once(self, tmp_path):
        events = []
        cfg = make_config(tmp_path, probe_method="login",
                          availability_window_start="00:00",
                          availability_window_end="23:59",
                          shutdown_buffer_minutes=0)
        results = iter([False, False, True, True])
        mon = AvailabilityMonitor(
            cfg,
            login_probe_func=lambda: next(results),
            on_unavailable=lambda reason: events.append(("down", reason)),
            on_recovered=lambda: events.append(("up",)),
        )
        # First failed probe alerts even without a prior healthy state
        mon._run_login_probe_if_due(force=True)
        # Steady failure: no repeat alert
        mon._run_login_probe_if_due(force=True)
        # Recovery fires exactly once
        mon._run_login_probe_if_due(force=True)
        mon._run_login_probe_if_due(force=True)

        assert [e[0] for e in events] == ["down", "up"]
        assert "Login probe failed" in events[0][1]

    def test_login_probe_defers_while_busy(self, tmp_path):
        cfg = make_config(tmp_path, probe_method="login",
                          availability_window_start="00:00",
                          availability_window_end="23:59",
                          shutdown_buffer_minutes=0)
        mon = AvailabilityMonitor(cfg, login_probe_func=lambda: True,
                                  busy_check=lambda: True)
        assert mon._login_probe_due() is False
        mon.busy_check = lambda: False
        assert mon._login_probe_due() is True   # deferral kept it due

    def test_login_mode_without_probe_falls_back_to_tcp(self, tmp_path):
        mon = make_monitor(tmp_path, probe_method="login",
                           health_check_enabled=True)
        mon.start()
        try:
            assert mon.probe_method == "tcp"
        finally:
            mon.stop()


class TestStatusAndGate:
    def test_status_shape(self, tmp_path):
        mon = make_monitor(tmp_path, health_check_enabled=False)
        mon.start()
        status = mon.status()
        for key in ("current_time_jst", "within_time_window",
                    "accepting_new_work", "health_probe_ok", "available",
                    "window", "shutdown_buffer_minutes", "probe_method"):
            assert key in status

    def test_dispatcher_gate_blocks_dequeue(self, tmp_path, db):
        """Gate 1: an unavailable mainframe means the queue is never
        touched — the request stays queued."""
        from src.core.retry import RetryPolicy
        from src.modules.intake.models import ProcessingRequest
        from src.modules.queue.dispatcher import Dispatcher, MockExecutor
        from src.modules.queue.services import QueueStore
        from src.modules.audit.services import TransactionStore

        cfg = make_config(tmp_path)
        store = QueueStore(db)
        store.enqueue(ProcessingRequest(
            operation="provision", affiliation_code="30822",
            employee_code="1217036", password="FUJI@33F"))

        class ClosedGate:
            def can_start_new_work(self):
                return False

        dispatcher = Dispatcher(
            queue=store, transactions=TransactionStore(db),
            retry_policy=RetryPolicy(), executor=MockExecutor(0.0),
            cfg=cfg, availability=ClosedGate())

        assert dispatcher._tick() is False
        assert store.queue_depth()["eligible"] == 1   # untouched
