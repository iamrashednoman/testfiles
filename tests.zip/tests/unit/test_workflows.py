"""Unit tests for the ported workflows, driven end-to-end through the
MockDriver (port of v2 tests/test_workflows.py plus the approved-fix
coverage)."""
import pytest

from src.core.evidence import EvidenceCapture
from src.rpa.config import build_rpa_config
from src.rpa.credentials import FINESIIICredentials
from src.rpa.drivers.mock import MockDriver
from src.rpa.workflows.deprovision import DeprovisionWorkflow
from src.rpa.workflows.provision import ProvisionWorkflow

CREDS = FINESIIICredentials("03325", "12N3940", "TEST0000")


@pytest.fixture(autouse=True)
def fast_sleep(monkeypatch):
    """The ported workflows keep v2's real terminal pacing (2s
    post-entry waits, 1.5s logout steps). Against MockDriver those
    delays are pure wall-clock waste — no-op them."""
    monkeypatch.setattr("time.sleep", lambda s: None)


def make_rpa_config(tmp_path, scenario="success"):
    return build_rpa_config(
        driver="mock",
        environment="development",
        evidence_dir=str(tmp_path / "evidence"),
        scenario=scenario,
    )


def run_provision(tmp_path, scenario="success", password="FUJI@33F"):
    config = make_rpa_config(tmp_path, scenario)
    driver = MockDriver()
    driver.initialize(config["application"])
    evidence = EvidenceCapture(config["evidence"])
    wf = ProvisionWorkflow(driver, config, None, evidence)
    result = wf.execute(CREDS, "30822", "1217036", password)
    return result, driver


def run_deprovision(tmp_path, scenario="success"):
    config = make_rpa_config(tmp_path, scenario)
    driver = MockDriver()
    driver.initialize(config["application"])
    evidence = EvidenceCapture(config["evidence"])
    wf = DeprovisionWorkflow(driver, config, None, evidence)
    result = wf.execute(CREDS, "30822", "1217036")
    return result, driver


class TestProvision:
    def test_success_returns_o0000(self, tmp_path):
        result, driver = run_provision(tmp_path)
        assert result["status"] == "success"
        assert result["result_code"] == "O-0000"
        assert result["error"] is None
        # 00 (confirm) then 70 (commit) were issued in order
        assert driver.commands.index("00", 1) < driver.commands.index("70")
        # Mandatory print flow: 10 → 10 after the commit
        commit_at = driver.commands.index("70")
        assert driver.commands[commit_at + 1:].count("10") >= 1

    def test_dev_login_prefix_and_account_affiliation(self, tmp_path):
        """Dev env: LOGIN affiliation gets '99' prepended; the account
        affiliation typed on FID 105 does not."""
        _, driver = run_provision(tmp_path)
        assert "9903325" in driver.typed_values     # login (99 + 03325)
        assert "30822" in driver.typed_values       # account, no prefix
        assert "9930822" not in driver.typed_values

    def test_error_scenario_fails_with_code(self, tmp_path):
        result, _ = run_provision(tmp_path, scenario="error")
        assert result["status"] == "failed"
        assert "E-9901" in result["error"]
        assert result["error_type"] == "business"

    def test_unreadable_screen_unconfirmed_success(self, tmp_path):
        """The real client terminal returns only the window title.
        The workflow must PROCEED (deterministic entry + commit) and
        report UNCONFIRMED, never a false failure."""
        result, _ = run_provision(tmp_path, scenario="unreadable")
        assert result["status"] == "success"
        assert result["result_code"] == "UNCONFIRMED"

    def test_evidence_captured(self, tmp_path):
        result, _ = run_provision(tmp_path)
        from pathlib import Path
        shots = list(Path(result["evidence_path"]).glob("*.png"))
        names = "|".join(p.name for p in shots)
        assert shots, "no evidence captured"
        # Approved fix: the confirmation screen is now a capture point
        assert "confirmation_screen" in names


class TestDeprovision:
    def test_success(self, tmp_path):
        result, driver = run_deprovision(tmp_path)
        assert result["status"] == "success"
        assert result["result_code"] == "O-0000"
        # Delete types "4", never a password
        assert "4" in driver.typed_values
        assert "FUJI@33F" not in driver.typed_values

    def test_already_deleted_detected(self, tmp_path):
        result, _ = run_deprovision(tmp_path, scenario="already_deleted")
        assert result["status"] == "already_deleted"
        assert result["error_type"] == "business"

    def test_already_deleted_evidence_captured(self, tmp_path):
        """Approved fix: already_deleted_screen is a capture point."""
        result, _ = run_deprovision(tmp_path, scenario="already_deleted")
        from pathlib import Path
        names = "|".join(
            p.name for p in Path(result["evidence_path"]).glob("*.png"))
        assert "already_deleted_screen" in names

    def test_unreadable_screen_unconfirmed_success(self, tmp_path):
        result, _ = run_deprovision(tmp_path, scenario="unreadable")
        assert result["status"] == "success"
        assert result["result_code"] == "UNCONFIRMED"
