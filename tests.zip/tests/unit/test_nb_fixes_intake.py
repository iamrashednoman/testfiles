"""New-bug fixes — intake and ServiceNow (round 2, 2026-09-28).

Pins, per bug:
  NB-007  the employee code is 7 half-width letters or digits; a space,
          tab or '-' inside it is refused at intake and on a SailPoint
          ticket (held with the reason).
  NB-011  a ServiceNow outage notice held back by the re-alert floor is
          not recorded as sent; it is sent on a later failed poll, and a
          Recovered notice follows only a notified outage.
  NB-014  the request source is one of the documented values.
  NB-021  the matching fields named for a superseded ticket and for the
          tracking-ID rule.
  NB-022  passwords written without a colon are masked in stored ticket
          text; ordinary wording is left alone.
"""
from __future__ import annotations

import time
from types import SimpleNamespace

import pytest

from scripts.run_mock_snow_server import TicketStore
from src.integrations.servicenow import sailpoint
from src.integrations.servicenow.config import (
    SAILPOINT_FIELDS, ServiceNowSettings, load_servicenow_config,
)
from src.integrations.servicenow.connector import ServiceNowConnector
from src.integrations.servicenow.mapper import mask_inline_secrets
from src.modules.intake.schemas import (
    KNOWN_SOURCES, SubmitRequest, validate_request_format,
)
from src.modules.notifications.availability_alerts import (
    COMPONENT_SERVICENOW, AvailabilityAlerter,
)


def sp_settings(**kw) -> ServiceNowSettings:
    s = load_servicenow_config()
    s.instance_url = "https://mock.service-now.com"
    s.username, s.password = "finesiii.bot", "x"
    s.respect_service_health = False
    for k, v in kw.items():
        setattr(s, k, v)
    return s


def parse(store, task, s=None):
    ticket = {f: store.field(task, f) for f in SAILPOINT_FIELDS}
    return sailpoint.parse_ticket(ticket, store.variables[task["request_item"]],
                                  s or sp_settings())


def body(**kw) -> SubmitRequest:
    base = dict(operation="deprovision", affiliation_code="30822",
                employee_code="1217036")
    base.update(kw)
    return SubmitRequest(**base)


# ── NB-007 ───────────────────────────────────────────────────────

class TestEmployeeCodeFormat:
    @pytest.mark.parametrize("code", ["123\t567", "123 567", "123-567",
                                      "12_4567", "1234.67"])
    def test_non_alphanumeric_is_refused(self, code):
        problems = validate_request_format(body(employee_code=code))
        assert problems == ["Employee code must be 7 half-width letters or "
                            "digits (A-Z, a-z, 0-9)"]

    @pytest.mark.parametrize("code", ["4821KQT", "1217036", " 1217036 ",
                                      "abcdefg"])
    def test_letters_and_digits_pass(self, code):
        assert validate_request_format(body(employee_code=code)) == []

    def test_existing_messages_unchanged(self):
        assert validate_request_format(body(employee_code="123456")) == [
            "Employee code must be 7 characters (got 6)"]
        assert validate_request_format(body(employee_code="１２３４５６７")) == [
            "Employee code must use half-width (ASCII) characters only"]

    @pytest.mark.parametrize("account", ["4821 QT", "4821-QT", "4821\tQT"])
    def test_sailpoint_account_is_held(self, account):
        store = TicketStore()
        task = store.create_sailpoint("certification", account=account)
        payloads, reason = parse(store, task)
        assert payloads is None
        assert reason == (f"the account '{account}' must be 7 half-width "
                          f"letters or digits")

    def test_sailpoint_valid_account_still_parses(self):
        store = TicketStore()
        task = store.create_sailpoint("certification", account="4821KQT")
        payloads, reason = parse(store, task)
        assert reason == "" and payloads[0]["employee_code"] == "4821KQT"


# ── NB-014 (source) ──────────────────────────────────────────────

class TestSourceValues:
    def test_known_sources(self):
        assert KNOWN_SOURCES == ("manual", "servicenow", "sailpoint",
                                 "api", "cli")

    @pytest.mark.parametrize("source", KNOWN_SOURCES)
    def test_each_known_source_passes(self, source):
        assert validate_request_format(body(source=source)) == []

    def test_default_source_passes(self):
        assert body().source == "manual"
        assert validate_request_format(body()) == []

    @pytest.mark.parametrize("source", ["foo", "ServiceNow", "", "manual "])
    def test_other_values_are_refused(self, source):
        problems = validate_request_format(body(source=source))
        assert problems == [
            f"source must be one of manual, servicenow, sailpoint, api, "
            f"cli (got '{source}')"]

    def test_servicenow_mappers_use_a_known_source(self):
        from src.integrations.servicenow.mapper import map_ticket
        mapping = {"ticket_number": "number", "operation": "op",
                   "affiliation_code": "aff", "employee_code": "emp"}
        out = map_ticket({"number": "T1", "op": "deprovision",
                          "aff": "30822", "emp": "1217036"}, mapping)
        assert out["source"] in KNOWN_SOURCES
        store = TicketStore()
        task = store.create_sailpoint("certification", account="4821KQT")
        payloads, _ = parse(store, task)
        assert payloads[0]["source"] in KNOWN_SOURCES


# ── NB-011 ───────────────────────────────────────────────────────

class _Notifier:
    def __init__(self):
        self.sent = []

    def send(self, subject, body, context=None, template_path=None):
        self.sent.append(subject)


class TestOutageNoticeAfterFloor:
    def _poller(self, tmp_path, monkeypatch):
        from desktop.snow_poller import ServiceNowPoller
        monkeypatch.setenv("FINESIII_DATA_DIR", str(tmp_path / "data"))
        (tmp_path / "data").mkdir(exist_ok=True)
        notifier = _Notifier()
        alerter = AvailabilityAlerter(notifier, async_send=False)
        app = SimpleNamespace(state=SimpleNamespace(
            availability_alerter=alerter))
        return ServiceNowPoller(app, "http://127.0.0.1:1"), alerter, notifier

    def test_component_down_reports_suppression(self):
        alerter = AvailabilityAlerter(_Notifier(), async_send=False)
        assert alerter.component_down(COMPONENT_SERVICENOW, "x") is True
        assert alerter.component_down(COMPONENT_SERVICENOW, "x") is False
        assert alerter.component_recovered(COMPONENT_SERVICENOW) is True
        assert alerter.component_recovered(COMPONENT_SERVICENOW) is False

    def test_second_outage_within_floor_then_after(self, tmp_path,
                                                   monkeypatch):
        poller, alerter, notifier = self._poller(tmp_path, monkeypatch)
        down = f"{COMPONENT_SERVICENOW} Not Available"
        up = f"{COMPONENT_SERVICENOW} Recovered"
        # First outage and recovery: both notified.
        poller._alerts(3, "not reachable")
        assert poller._alerted_down is True
        poller._alerts(0, "")
        assert poller._alerted_down is False
        assert notifier.sent == [down, up]
        # Second outage inside the 5-minute floor: held back, and NOT
        # recorded as notified.
        for n in (3, 4, 5):
            poller._alerts(n, "rate limited")
        assert notifier.sent == [down, up]
        assert poller._alerted_down is False
        # ServiceNow back before anything was sent: no Recovered e-mail.
        poller._alerts(0, "")
        assert notifier.sent == [down, up]
        # Failing again once the floor has passed: the notice goes out.
        key = (COMPONENT_SERVICENOW, True)
        alerter._last_sent[key] -= 301
        poller._alerts(3, "server error")
        assert notifier.sent == [down, up, down]
        assert poller._alerted_down is True
        # Recovery after the floor for Recovered has passed: sent.
        alerter._last_sent[(COMPONENT_SERVICENOW, False)] -= 301
        poller._alerts(0, "")
        assert notifier.sent == [down, up, down, up]
        assert poller._alerted_down is False

    def test_suppressed_recovery_is_tried_again(self, tmp_path, monkeypatch):
        poller, alerter, notifier = self._poller(tmp_path, monkeypatch)
        alerter._last_sent[(COMPONENT_SERVICENOW, False)] = time.time()
        poller._alerts(3, "not reachable")
        poller._alerts(0, "")                     # Recovered held back
        assert poller._alerted_down is True
        alerter._last_sent[(COMPONENT_SERVICENOW, False)] -= 301
        poller._alerts(0, "")
        assert poller._alerted_down is False
        assert notifier.sent[-1] == f"{COMPONENT_SERVICENOW} Recovered"

    def test_notified_state_survives_restart(self, tmp_path, monkeypatch):
        from desktop.snow_poller import ServiceNowPoller
        poller, alerter, notifier = self._poller(tmp_path, monkeypatch)
        poller._alerts(3, "not reachable")
        again = ServiceNowPoller(poller.app, "http://127.0.0.1:1")
        assert again._alerted_down is True


# ── NB-021 ───────────────────────────────────────────────────────

MAPPING = {"ticket_number": "number", "operation": "u_op",
           "affiliation_code": "u_aff", "employee_code": "u_emp"}


class _Client:
    def __init__(self, tickets):
        self.tickets, self.notes = tickets, []

    def fetch_assigned_open(self):
        return list(self.tickets)

    def add_work_note(self, sys_id, note, table=""):
        self.notes.append((sys_id, note))


class TestMatchingFieldsWording:
    def _run(self, hit):
        s = ServiceNowSettings(
            instance_url="https://dev.service-now.com", username="bot",
            password="pw", table="sc_task", field_mapping=MAPPING,
            respect_service_health=False, max_retries=1,
            backoff_base_seconds=0.001, backoff_max_seconds=0.001)
        rejected, audited = [], []
        c = ServiceNowConnector(
            s, client=_Client([{"sys_id": "sid-2", "number": "SCTASK0002",
                                "u_op": "deprovision", "u_aff": "30822",
                                "u_emp": "1217036", "state": "1"}]),
            on_rejected=lambda t, r, d: rejected.append((t, r, d)))
        c.audit_hook = lambda e, d: audited.append((e, d))
        c._submit = lambda p: "queued"
        c.duplicate_of = lambda payload, t: dict(hit)
        c.poll_once()
        return rejected[0][2], audited[0][1]

    def test_superseded_names_the_opposite_operation(self):
        details, audit = self._run({
            "request_id": "r-9", "ticket_id": "SCTASK0009", "status": "done",
            "matched_fields": [], "superseded": True,
            "reason": "a newer ticket SCTASK0009 (provision) …"})
        want = "affiliation code, employee code (opposite operation)"
        assert details["matching_fields"] == want
        assert audit["matching_fields"] == want

    def test_tracking_id_rule_shows_the_ticket_label(self):
        details, _ = self._run({
            "request_id": "r-8", "ticket_id": "SCTASK0008", "status": "done",
            "matched_fields": ["tracking_id"],
            "reason": "same access request ID 0000537400"})
        assert details["matching_fields"] == "Access Request ID"

    def test_other_cases_unchanged(self):
        details, _ = self._run({
            "request_id": "r-1", "ticket_id": "SCTASK0001", "status": "done",
            "matched_fields": ["u_aff", "u_emp"]})
        assert details["matching_fields"] == "u_aff, u_emp"
        details, _ = self._run({
            "request_id": "r-1", "ticket_id": "SCTASK0001", "status": "done",
            "matched_fields": []})
        assert details["matching_fields"] == \
            "operation, affiliation code, employee code"


# ── NB-022 ───────────────────────────────────────────────────────

class TestInlinePasswordMasking:
    @pytest.mark.parametrize("text,secret", [
        ("Password - Lmno3456", "Lmno3456"),
        ("Temp password is Hijk7890", "Hijk7890"),
        ("Password -X9", "X9"),
        ("Password- X9", "X9"),
        ("パスワード　Qrst1234", "Qrst1234"),
        ("Password: Abcd1234", "Abcd1234"),
        ("パスワード：Abcd1234", "Abcd1234"),
        ("password=Abcd1234", "Abcd1234"),
        ("PWD : Abcd1234", "Abcd1234"),
        ("passwd – Efgh5678", "Efgh5678"),
    ])
    def test_value_is_masked(self, text, secret):
        out = mask_inline_secrets(text)
        assert secret not in out and "****" in out

    @pytest.mark.parametrize("text", [
        "Password Reset request",
        "password-protected file",
        "Password\n- item",
        "Passwords are fine",
        "This password isn't",
    ])
    def test_ordinary_wording_is_unchanged(self, text):
        assert mask_inline_secrets(text) == text

    def test_sailpoint_ticket_with_both_lines(self):
        store = TicketStore()
        text = ("Access Request ID in myAIGaccess for tracking purpose is: 7\n"
                "Please provision/deprovision the below attributes for "
                "account: 4821KQT\n"
                "AttributeName=所属コード; Value=01634 | 部署; Operation=Add\n"
                "Password - Lmno3456\n"
                "Temp password is Hijk7890")
        task = store.create_sailpoint("add", account="4821KQT", text=text)
        payloads, reason = parse(store, task)
        assert reason == ""
        stored = str(payloads[0]["metadata"])
        assert "Lmno3456" not in stored and "Hijk7890" not in stored
        assert payloads[0]["password"] == ""
