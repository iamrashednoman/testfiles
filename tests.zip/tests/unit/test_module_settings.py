"""Module setup wizard — the settings plumbing underneath it (2026-09-26).

Pins: the catalogue's `choice` kind and unavailable choices; every new
env override leaves the YAML value in force when unset; the D15 default
(no password in the user email); the terminal-application overrides;
the connector's known-ticket skip; the queue lookup by ticket; the
CyberArk provider surviving an unexpected error and waking on request;
the dispatcher's password-rejected hook.
"""
import threading
import time

import pytest

from tests.conftest import make_config


class TestCatalogue:
    def test_choice_kind_and_unavailable_choice(self):
        from src.modules.console.settings_catalogue import BY_KEY, coerce
        spec = BY_KEY["SNOW_AUTH_METHOD"]
        assert coerce(spec, "Basic") == "basic"
        # OAuth is available since 2026-09-26 (two grant types).
        assert coerce(spec, "OAUTH_PASSWORD") == "oauth_password"
        assert coerce(spec, "oauth_client_credentials") == "oauth_client_credentials"
        with pytest.raises(ValueError):
            coerce(spec, "saml")
        assert coerce(BY_KEY["CYBERARK_API_STYLE"], "PVWA") == "pvwa"
        # disabled_choices still refuses when set.
        with pytest.raises(ValueError, match="not yet available"):
            coerce(dict(spec, disabled_choices=["basic"]), "basic")

    def test_new_groups_present_and_hot_keys_marked(self):
        from src.modules.console.settings_catalogue import (
            APPLY_HOT, BY_KEY, GROUPS,
        )
        for g in ("ServiceNow", "CyberArk", "FINESIII terminal", "Email"):
            assert g in GROUPS
        assert BY_KEY["SNOW_ENABLED"]["apply"] == APPLY_HOT
        assert BY_KEY["CYBERARK_ENABLED"]["apply"] == "restart"
        assert BY_KEY["CYBERARK_PVWA_USER"]["show_when"] == {
            "key": "CYBERARK_API_STYLE", "value": "pvwa"}
        # CyberArk enablement lives in the catalogue, not the deployment file.
        from desktop.deployment import BY_KEY as DEPLOY
        assert "CYBERARK_ENABLED" not in DEPLOY


class TestEnvOverrides:
    def test_smtp_transport_from_env(self, monkeypatch):
        from src.modules.notifications.config import load_notification_config
        monkeypatch.setenv("SMTP_PORT", "465")
        monkeypatch.delenv("SMTP_USE_SSL", raising=False)
        monkeypatch.delenv("SMTP_USE_STARTTLS", raising=False)
        monkeypatch.delenv("SMTP_SECURITY", raising=False)
        s = load_notification_config()
        # Nothing set on the console: port 465 is SSL/TLS from the start
        # (2026-09-29; STARTTLS was attempted there before and failed).
        assert s.use_ssl is True and s.use_starttls is False
        monkeypatch.setenv("SMTP_PORT", "587")
        s = load_notification_config()
        # Any other port: the file's switches (STARTTLS) stay in force.
        assert s.use_starttls is True and s.use_ssl is False
        monkeypatch.setenv("SMTP_PORT", "465")
        monkeypatch.setenv("SMTP_USE_SSL", "true")
        monkeypatch.setenv("SMTP_USE_STARTTLS", "false")
        s = load_notification_config()
        assert s.use_ssl is True and s.use_starttls is False

    def test_user_email_password_is_off_by_default_and_env_switchable(
            self, monkeypatch):
        from src.modules.notifications.transaction_alerts import (
            load_transaction_notification_config,
        )
        for k in ("TXN_INCLUDE_PASSWORD", "TXN_NOTIFICATIONS_ENABLED",
                  "TXN_SEND_USER_CREDENTIALS", "ERROR_ALERTS_ENABLED"):
            monkeypatch.delenv(k, raising=False)
        s = load_transaction_notification_config()
        assert s.include_password is False               # D15
        assert s.enabled is False
        monkeypatch.setenv("TXN_INCLUDE_PASSWORD", "true")
        monkeypatch.setenv("TXN_NOTIFICATIONS_ENABLED", "yes")
        monkeypatch.setenv("ERROR_ALERTS_ENABLED", "1")
        s = load_transaction_notification_config()
        assert s.include_password is True
        assert s.enabled is True
        assert s.error_alerts.enabled is True

    def test_cyberark_env_overrides(self, monkeypatch):
        from src.integrations.cyberark.config import load_cyberark_config
        for k in ("CYBERARK_API_STYLE", "CYBERARK_VERIFY_TLS",
                  "CYBERARK_REFRESH_HOURS", "CYBERARK_HEALTH_CHECK",
                  "CYBERARK_PVWA_AUTH_TYPE"):
            monkeypatch.delenv(k, raising=False)
        s = load_cyberark_config()
        assert (s.api_style, s.verify_tls, s.refresh_interval_hours,
                s.health_check_enabled) == ("ccp", True, 4.0, True)
        monkeypatch.setenv("CYBERARK_API_STYLE", "pvwa")
        monkeypatch.setenv("CYBERARK_VERIFY_TLS", "false")
        monkeypatch.setenv("CYBERARK_REFRESH_HOURS", "0.5")
        monkeypatch.setenv("CYBERARK_HEALTH_CHECK", "off")
        monkeypatch.setenv("CYBERARK_PVWA_AUTH_TYPE", "LDAP")
        s = load_cyberark_config()
        assert (s.api_style, s.verify_tls, s.refresh_interval_hours,
                s.health_check_enabled, s.pvwa_auth_type) == (
            "pvwa", False, 0.5, False, "LDAP")

    def test_servicenow_env_overrides_and_fields(self, monkeypatch):
        from src.integrations.servicenow.config import load_servicenow_config
        for k in ("SNOW_ASSIGNMENT_MODE", "SNOW_POLL_SECONDS",
                  "SNOW_WRITEBACK_ENABLED"):
            monkeypatch.delenv(k, raising=False)
        s = load_servicenow_config()
        # The process design picks up tickets assigned to the bot account
        # (default). The group is entered on the Settings page; the YAML
        # holds none (no hidden default, 2026-10-04).
        assert s.assignment_mode == "assigned_to"
        assert s.assignment_group == ""
        assert s.require_approval is True
        # Default cadence is 30 minutes since 2026-09-26.
        assert s.poll_interval_seconds == 1800 and s.writeback_enabled is False
        # The two fields the mapper reads are now requested (fix).
        assert {"u_initial_password", "u_requester_email"} <= set(s.fields)
        monkeypatch.setenv("SNOW_ASSIGNMENT_MODE", "assignment_group")
        monkeypatch.setenv("SNOW_POLL_SECONDS", "120")
        monkeypatch.setenv("SNOW_WRITEBACK_ENABLED", "true")
        s = load_servicenow_config()
        assert s.assignment_mode == "assignment_group"
        assert s.poll_interval_seconds == 120 and s.writeback_enabled is True

    def test_terminal_application_overrides(self, monkeypatch):
        from src.rpa.config import build_rpa_config
        for k in ("FINESIII_APP_SHORTCUT_PATH", "FINESIII_APP_WINDOW_TITLE",
                  "FINESIII_APP_WINDOW_CLASS", "FINESIII_APP_EXECUTABLE"):
            monkeypatch.delenv(k, raising=False)
        base = build_rpa_config(driver="mock", environment="development",
                                evidence_dir="e")["application"]
        assert base["terminal_window_class"] == "F3BJMD101"
        monkeypatch.setenv("FINESIII_APP_SHORTCUT_PATH", r"D:\lnk\fines.lnk")
        monkeypatch.setenv("FINESIII_APP_WINDOW_CLASS", "XCLASS")
        app = build_rpa_config(driver="mock", environment="development",
                               evidence_dir="e")["application"]
        assert app["shortcut_path"] == r"D:\lnk\fines.lnk"
        assert app["terminal_window_class"] == "XCLASS"
        assert app["window_title_pattern"] == base["window_title_pattern"]


class TestConnectorKnownTickets:
    class _FakeClient:
        def __init__(self, tickets):
            self._t = tickets

        def fetch_assigned_open(self):
            return list(self._t)

    def _settings(self):
        from src.integrations.servicenow.config import ServiceNowSettings
        return ServiceNowSettings(
            instance_url="https://x", username="u", password="p",
            assigned_to="u", respect_service_health=False,
            field_mapping={"ticket_number": "number", "operation": "u_op",
                           "affiliation_code": "u_aff",
                           "employee_code": "u_emp"})

    def test_known_tickets_are_not_resubmitted(self):
        from src.integrations.servicenow.connector import ServiceNowConnector
        tickets = [
            {"sys_id": "1", "number": "T1", "u_op": "provision",
             "u_aff": "30822", "u_emp": "1217036"},
            {"sys_id": "2", "number": "T2", "u_op": "provision",
             "u_aff": "30822", "u_emp": "1217037"},
        ]
        c = ServiceNowConnector(self._settings(),
                                client=self._FakeClient(tickets))
        submitted = []
        c._submit = lambda payload: submitted.append(payload["ticket_id"]) or "queued"
        c.known_ticket = lambda n: n == "T1"          # T1 already in the queue
        stats = c.poll_once()
        assert submitted == ["T2"]
        assert stats["known"] == 1 and stats["submitted"] == 1

    def test_lookup_failure_does_not_stop_the_poll(self):
        from src.integrations.servicenow.connector import ServiceNowConnector
        tickets = [{"sys_id": "1", "number": "T1", "u_op": "provision",
                    "u_aff": "30822", "u_emp": "1217036"}]
        c = ServiceNowConnector(self._settings(),
                                client=self._FakeClient(tickets))
        c._submit = lambda payload: "queued"

        def boom(n):
            raise RuntimeError("db down")
        c.known_ticket = boom
        assert c.poll_once()["submitted"] == 1

    def test_without_filter_behaviour_is_unchanged(self):
        from src.integrations.servicenow.connector import ServiceNowConnector
        tickets = [{"sys_id": "1", "number": "T1", "u_op": "provision",
                    "u_aff": "30822", "u_emp": "1217036"}]
        c = ServiceNowConnector(self._settings(),
                                client=self._FakeClient(tickets))
        c._submit = lambda payload: "duplicate"
        assert c.poll_once()["duplicate"] == 1


class TestQueueLookup:
    def test_find_by_ticket_any_status(self, tmp_path):
        from src.core.db import Database
        from src.modules.intake.models import ProcessingRequest
        from src.modules.queue.services import QueueStore
        db = Database.from_config(make_config(tmp_path))
        try:
            q = QueueStore(db)
            r = ProcessingRequest(operation="provision",
                                  affiliation_code="30822",
                                  employee_code="1217036", ticket_id="T9")
            assert q.enqueue(r)
            assert q.find_by_ticket("T9").request_id == r.request_id
            q.dequeue_oldest(worker_id=1)
            q.mark_complete(r.request_id, "failed", error="x")
            assert q.find_by_ticket("T9") is not None      # failed still known
            assert q.find_by_ticket("nope") is None
            assert q.find_by_ticket("") is None
        finally:
            db.close()


class TestCyberArkProviderRobustness:
    def _provider(self, client):
        from src.integrations.cyberark.config import CyberArkSettings
        from src.integrations.cyberark.provider import CyberArkPasswordProvider
        s = CyberArkSettings(enabled=True, base_url="https://v", app_id="a",
                             safe="s", object_name="o",
                             refresh_interval_hours=1.0)
        p = CyberArkPasswordProvider(s, client=client)
        p.RETRY_AFTER_FAILURE_SECONDS = 0.05
        return p

    def test_unexpected_error_does_not_kill_the_loop(self):
        class Client:
            calls = 0

            def fetch_password(self):
                Client.calls += 1
                if Client.calls == 2:
                    raise ValueError("Expecting value (non-JSON body)")
                return f"pw{Client.calls}"

        p = self._provider(Client())
        p.start()
        try:
            assert p.get_password() == "pw1"
            p.request_refresh()                     # → ValueError inside loop
            deadline = time.time() + 5
            while time.time() < deadline and Client.calls < 2:
                time.sleep(0.02)
            assert Client.calls >= 2
            assert p._thread.is_alive(), "loop died on an unexpected error"
            assert p.status()["available"] is False
            assert "ValueError" in p.status()["last_error"]
            # Fast retry after failure recovers without waiting 1 hour.
            deadline = time.time() + 5
            while time.time() < deadline and not p.is_available():
                time.sleep(0.02)
            assert p.is_available()
            assert p.get_password() == f"pw{Client.calls}"
        finally:
            p.stop()
        assert not p._thread.is_alive()

    def test_request_refresh_wakes_immediately(self):
        class Client:
            calls = 0

            def fetch_password(self):
                Client.calls += 1
                return "pw"

        p = self._provider(Client())
        p.start()
        try:
            before = Client.calls
            p.request_refresh()
            deadline = time.time() + 3
            while time.time() < deadline and Client.calls == before:
                time.sleep(0.02)
            assert Client.calls == before + 1
        finally:
            p.stop()


class TestDispatcherPasswordHook:
    def test_hook_fires_only_on_login_password_incorrect(self, tmp_path):
        from src.core.db import Database
        from src.core.retry import RetryPolicy
        from src.modules.audit.services import TransactionStore
        from src.modules.intake.models import ProcessingRequest
        from src.modules.queue.dispatcher import Dispatcher
        from src.modules.queue.services import QueueStore
        cfg = make_config(tmp_path)
        db = Database.from_config(cfg)
        try:
            q, t = QueueStore(db), TransactionStore(db)
            fired = []
            d = Dispatcher(q, t, RetryPolicy(max_attempts=1), executor=None,
                           cfg=cfg, on_password_rejected=lambda: fired.append(1))
            r = ProcessingRequest(operation="provision",
                                  affiliation_code="30822",
                                  employee_code="1217036")
            q.enqueue(r)
            req = q.dequeue_oldest(worker_id=1)
            d._complete(req, {"status": "failed", "error": "bad pw",
                              "error_type": "system",
                              "error_id": "LOGIN_PASSWORD_INCORRECT"},
                        None, "max attempts")
            assert fired == [1]
            r2 = ProcessingRequest(operation="provision",
                                   affiliation_code="30822",
                                   employee_code="1217037")
            q.enqueue(r2)
            req2 = q.dequeue_oldest(worker_id=1)
            d._complete(req2, {"status": "failed", "error": "other",
                               "error_id": "CENTER_NOT_READY"}, None, "x")
            assert fired == [1]
        finally:
            db.close()
