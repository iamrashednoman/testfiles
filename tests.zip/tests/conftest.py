"""Global pytest fixtures for the v3 control plane."""
from __future__ import annotations

import sys
from pathlib import Path

import httpx
import pytest

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

# Generated passwords are fingerprinted with a key; tests use a fixed
# one so no key file is ever written into the source tree.
import os  # noqa: E402
os.environ.setdefault("FINESIII_PASSWORD_FP_KEY", "test-only-fingerprint-key")

from config.development import DevelopmentConfig  # noqa: E402
from src.core.db import Database                  # noqa: E402


def make_config(tmp_path, **overrides) -> DevelopmentConfig:
    defaults = dict(
        database_engine="sqlite",
        sqlite_path=str(tmp_path / "test.db"),
        evidence_dir=str(tmp_path / "evidence"),
        # The service log is opened as the service is built; keep it
        # out of the source tree.
        log_dir=str(tmp_path / "logs"),
        dispatcher_enabled=False,       # opt in per test
        dispatch_poll_seconds=0.05,
        idle_poll_seconds=0.05,
        drain_seconds=5,
        mock_executor_delay_seconds=0.01,
        retry_backoff_base_seconds=1,
        retry_max_delay_seconds=1,
        # Tests start from an EMPTY install and create the accounts
        # they need, so seeding is opt-in per test. Production seeds a
        # default administrator (see TestDefaultAdmin), which would
        # otherwise make every "fresh install" assertion false.
        auth_seed_default_admin=False,
    )
    defaults.update(overrides)
    return DevelopmentConfig(_env_file=None, **defaults)


class ASGITransport(httpx.BaseTransport):
    """An httpx transport that runs an ASGI app in the test (T-01,
    2026-10-04).

    The tests used to hand Starlette's TestClient transport straight to
    the ServiceNow client. From Starlette 1.x the test client is built
    on a different HTTP library (httpx2), whose responses the httpx
    client the application uses does not accept. This runs each request
    through the test client and hands back an ordinary httpx response,
    whatever the test client is built on.
    """

    def __init__(self, app):
        from starlette.testclient import TestClient
        self._client = TestClient(app)

    def handle_request(self, request):
        r = self._client.request(
            request.method, str(request.url),
            headers=list(request.headers.multi_items()),
            content=request.read(), follow_redirects=False)
        # Cookies are kept by the httpx client under test, not here.
        self._client.cookies.clear()
        headers = [(k, v) for k, v in r.headers.multi_items()
                   if k.lower() != "content-encoding"]
        return httpx.Response(r.status_code, headers=headers,
                              content=r.content, request=request)

    def close(self):
        """The client under test closes its transport after each call;
        the app stays available for the next one."""


asgi_transport = ASGITransport


@pytest.fixture(autouse=True, scope="session")
def _runtime_files_outside_the_source_tree(tmp_path_factory):
    """The installation id and the completion journal live in the data
    folder, which is the working directory when run from source; keep
    them in a temporary folder so the test run leaves nothing behind."""
    from src.modules.queue import dispatcher
    base = tmp_path_factory.mktemp("runtime")
    saved = dispatcher.INSTANCE_ID_FILE, dispatcher.PENDING_COMPLETIONS_FILE
    dispatcher.INSTANCE_ID_FILE = str(base / "instance.id")
    dispatcher.PENDING_COMPLETIONS_FILE = str(base / "pending_completions.jsonl")
    yield
    dispatcher.INSTANCE_ID_FILE, dispatcher.PENDING_COMPLETIONS_FILE = saved


@pytest.fixture(autouse=True)
def _email_wording_in_english(monkeypatch):
    """The e-mail wording tests pin the English texts; the installed
    default (Japanese and English together) is tested explicitly in
    test_email_module_2026_09_29.py (2026-09-29). No outbox or delivery
    state carries over between tests."""
    monkeypatch.setenv("EMAIL_LANGUAGE", "en")
    from src.modules.notifications import notifier
    monkeypatch.setattr(notifier, "_OUTBOX", None)
    monkeypatch.setattr(notifier, "DELIVERY", notifier.DeliveryState())


@pytest.fixture(autouse=True)
def _no_wait_after_failed_sign_in(monkeypatch):
    """Tests that fail a sign-in several times in a row test the lockout
    itself; the wait between attempts (SEC-05, 2026-10-04) is tested
    explicitly in test_f7_security_2026_10_04.py."""
    from src.modules.auth.services import AuthService
    monkeypatch.setattr(AuthService, "FAILURE_WAIT_MAX_SECONDS", 0)


@pytest.fixture(autouse=True)
def _restore_console_env_overrides():
    """A console setting saved in one test is written into os.environ
    (live settings apply at once since 2026-09-28); put the environment
    back afterwards so it cannot leak into the next test."""
    yield
    try:
        from src.modules.console.settings_store import _restore_env_overrides
        _restore_env_overrides()
    except Exception:
        pass


@pytest.fixture
def cfg(tmp_path):
    return make_config(tmp_path)


@pytest.fixture
def db(cfg):
    database = Database.from_config(cfg)
    yield database
    database.close()


@pytest.fixture
def api_client(cfg):
    from fastapi.testclient import TestClient
    from src import create_app
    with TestClient(create_app(cfg)) as client:
        yield client
