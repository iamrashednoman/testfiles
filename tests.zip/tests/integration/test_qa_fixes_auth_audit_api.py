"""QA fixes wired through the application — accounts, intake limits,
date filters, evidence auditing and audit outages (group E): BUG-008,
033, 034, 038, 039, 071, 079.
"""
from __future__ import annotations

import pytest

from tests.conftest import make_config

PASSWORD = "CorrectHorse42"
VALID = {"operation": "provision", "affiliation_code": "30822",
         "employee_code": "1217036", "password": "FUJI@33F"}


@pytest.fixture(autouse=True)
def fast_sleep(monkeypatch):
    monkeypatch.setattr("time.sleep", lambda s: None)


def _client(tmp_path, audit=False, **overrides):
    from fastapi.testclient import TestClient
    from src import create_app
    if audit:
        overrides.update(
            audit_enabled=True, audit_backend="sqlite",
            audit_sqlite_path=str(tmp_path / "audit.db"),
            audit_spool_path=str(tmp_path / "spool.db"),
            audit_flush_interval_seconds=0.05)
    cfg = make_config(tmp_path, dispatcher_enabled=False,
                      terminal_driver="mock",
                      log_dir=str(tmp_path / "logs"), **overrides)
    return TestClient(create_app(cfg))


def _auth(t):
    return {"Authorization": f"Bearer {t}"}


def _admin(client):
    client.post("/api/v1/auth/bootstrap",
                json={"username": "alice", "password": PASSWORD})
    return client.post("/api/v1/auth/login", json={
        "username": "alice", "password": PASSWORD}).json()["access_token"]


def _user(client, admin_token, username, role, **extra):
    """Create a user AND complete their forced password change."""
    r = client.post("/api/v1/admin/users", headers=_auth(admin_token),
                    json={"username": username, "password": PASSWORD,
                          "role": role, **extra})
    assert r.status_code == 201, r.text
    t = client.post("/api/v1/auth/login", json={
        "username": username, "password": PASSWORD}).json()["access_token"]
    client.post("/api/v1/auth/password", headers=_auth(t),
                json={"current_password": PASSWORD,
                      "new_password": "TheirOwn7777"})
    return client.post("/api/v1/auth/login", json={
        "username": username,
        "password": "TheirOwn7777"}).json()["access_token"]


def _events(client, **filters):
    audit = client.app.state.audit
    assert audit.flush(timeout=5)
    return audit.backend.query_events(limit=500, **filters)


def _user_id(client, token, username):
    users = client.get("/api/v1/admin/users", headers=_auth(token)).json()
    return next(u["user_id"] for u in users["users"]
                if u["username"] == username)


# ── BUG-008: users.manage cannot delete an account holding more ─────

class TestDeleteRespectsPrivilege:
    def _setup(self, client):
        admin = _admin(client)
        client.post("/api/v1/admin/roles", headers=_auth(admin),
                    json={"name": "usermgr", "description": "Accounts",
                          "permissions": ["users.manage", "users.view"]})
        manager = _user(client, admin, "ursula", "usermgr")
        return admin, manager

    def test_cannot_delete_an_administrator(self, tmp_path):
        with _client(tmp_path, audit=True) as client:
            admin, manager = self._setup(client)
            _user(client, admin, "bob", "admin")
            bob = _user_id(client, admin, "bob")
            r = client.delete(f"/api/v1/admin/users/{bob}",
                              headers=_auth(manager))
            assert r.status_code == 403
            assert "delete an account holding" in r.json()["detail"]
            assert "bob" in {u["username"] for u in client.get(
                "/api/v1/admin/users", headers=_auth(admin)
            ).json()["users"]}
            refused = _events(client, action="privilege_escalation_refused")
            assert refused
            assert refused[0]["detail"]["actor"] == "ursula"
            assert refused[0]["detail"]["action"] == \
                "delete an account holding"
            assert _events(client, action="user_deleted") == []

    def test_can_delete_an_account_on_its_own_role(self, tmp_path):
        with _client(tmp_path) as client:
            admin, manager = self._setup(client)
            _user(client, admin, "uma", "usermgr")
            uma = _user_id(client, admin, "uma")
            r = client.delete(f"/api/v1/admin/users/{uma}",
                              headers=_auth(manager))
            assert r.status_code == 200
            assert r.json()["username"] == "uma"


# ── BUG-033: the message matches what happens ───────────────────────

class TestPasswordChangeMessage:
    def test_every_session_ends_and_the_note_says_so(self, tmp_path):
        with _client(tmp_path) as client:
            token = _admin(client)
            other = client.post("/api/v1/auth/login", json={
                "username": "alice",
                "password": PASSWORD}).json()["access_token"]
            r = client.post("/api/v1/auth/password", headers=_auth(token),
                            json={"current_password": PASSWORD,
                                  "new_password": "AnotherHorse77"})
            assert r.status_code == 200
            assert r.json()["status"] == "password changed"
            assert "including this one" in r.json()["note"]
            for t in (token, other):
                assert client.get("/api/v1/auth/me",
                                  headers=_auth(t)).status_code == 401

    def test_same_password_is_refused(self, tmp_path):
        with _client(tmp_path) as client:
            token = _admin(client)
            r = client.post("/api/v1/auth/password", headers=_auth(token),
                            json={"current_password": PASSWORD,
                                  "new_password": PASSWORD})
            assert r.status_code == 400
            assert "differ" in r.json()["detail"]


# ── BUG-034: duplicate Windows mappings ─────────────────────────────

class TestWindowsMappingApi:
    # Since 2026-10-03 (UR-13) an account needs a password unless
    # Windows sign-on is possible on the service; the mapping tests give
    # their accounts one.
    def test_password_less_account_needs_windows_sign_on(self, tmp_path):
        with _client(tmp_path) as client:
            admin = _admin(client)
            r = client.post("/api/v1/admin/users", headers=_auth(admin),
                            json={"username": "dave", "role": "operator",
                                  "windows_account": "CORP\\Ops"})
            assert r.status_code == 400
            assert "password is required" in r.json()["detail"]

    def test_create_with_a_taken_mapping_is_409(self, tmp_path):
        with _client(tmp_path) as client:
            admin = _admin(client)
            r = client.post("/api/v1/admin/users", headers=_auth(admin),
                            json={"username": "dave", "role": "operator",
                                  "password": PASSWORD,
                                  "windows_account": "CORP\\Ops"})
            assert r.status_code == 201
            r = client.post("/api/v1/admin/users", headers=_auth(admin),
                            json={"username": "erin", "role": "viewer",
                                  "password": PASSWORD,
                                  "windows_account": "corp\\OPS"})
            assert r.status_code == 409
            assert "already mapped to 'dave'" in r.json()["detail"]

    def test_update_taking_another_mapping_is_409(self, tmp_path):
        with _client(tmp_path) as client:
            admin = _admin(client)
            client.post("/api/v1/admin/users", headers=_auth(admin),
                        json={"username": "dave", "role": "operator",
                              "password": PASSWORD,
                              "windows_account": "CORP\\Ops"})
            client.post("/api/v1/admin/users", headers=_auth(admin),
                        json={"username": "erin", "role": "viewer",
                              "password": PASSWORD})
            erin = _user_id(client, admin, "erin")
            r = client.patch(f"/api/v1/admin/users/{erin}",
                             headers=_auth(admin),
                             json={"windows_account": " corp\\ops "})
            assert r.status_code == 409
            assert "already mapped to 'dave'" in r.json()["detail"]

    def test_resaving_own_mapping_is_allowed(self, tmp_path):
        with _client(tmp_path) as client:
            admin = _admin(client)
            client.post("/api/v1/admin/users", headers=_auth(admin),
                        json={"username": "dave", "role": "operator",
                              "password": PASSWORD,
                              "windows_account": "CORP\\Ops"})
            dave = _user_id(client, admin, "dave")
            r = client.patch(f"/api/v1/admin/users/{dave}",
                             headers=_auth(admin),
                             json={"windows_account": "corp\\ops",
                                   "display_name": "Dave"})
            assert r.status_code == 200
            assert r.json()["user"]["windows_account"] == "corp\\ops"


# ── BUG-038: metadata size limit ────────────────────────────────────

class TestMetadataLimit:
    def test_over_64_kb_is_413_and_audited(self, tmp_path):
        with _client(tmp_path, audit=True) as client:
            r = client.post("/api/v1/requests", json={
                **VALID, "metadata": {"blob": "x" * (70 * 1024)}})
            assert r.status_code == 413
            assert "metadata exceeds 64 KB" in r.json()["detail"]
            rejected = _events(client, action="request_rejected")
            assert rejected and rejected[0]["status"] == "too_large"
            assert client.get("/api/v1/requests").json()["count"] == 0

    def test_small_metadata_is_accepted(self, tmp_path):
        with _client(tmp_path) as client:
            r = client.post("/api/v1/requests", json={
                **VALID, "metadata": {"note": "y" * 1024}})
            assert r.status_code == 202


# ── BUG-039: invalid dates are 400, not an empty list ───────────────

class TestDateFilters:
    BAD = ("26/09/2026", "garbage")
    GOOD = ("2026-09-26", "2026-09-26T10:00:00+09:00")

    @pytest.mark.parametrize("path", ["/api/v1/requests",
                                      "/api/v1/transactions",
                                      "/api/v1/transactions/export",
                                      "/api/v1/audit/events"])
    def test_intake_routes(self, tmp_path, path):
        with _client(tmp_path, audit=True) as client:
            for bad in self.BAD:
                r = client.get(path, params={"date_from": bad})
                assert r.status_code == 400, (path, bad)
                assert r.json()["detail"] == \
                    "date_from must be an ISO date YYYY-MM-DD"
                r = client.get(path, params={"date_to": bad})
                assert r.status_code == 400
            for good in self.GOOD:
                assert client.get(path, params={
                    "date_from": good, "date_to": good}).status_code == 200

    @pytest.mark.parametrize("table", ["requests", "transactions", "audit"])
    def test_console_exports(self, tmp_path, table):
        with _client(tmp_path, audit=True) as client:
            token = _admin(client)
            path = f"/api/v1/console/export/{table}"
            r = client.get(path, headers=_auth(token),
                           params={"date_to": "26/09/2026"})
            assert r.status_code == 400
            assert "date_to must be an ISO date" in r.json()["detail"]
            # Both days: the audit trail needs a period (UAT-L03).
            assert client.get(path, headers=_auth(token), params={
                "date_from": "2026-09-26",
                "date_to": "2026-09-26"}).status_code == 200


# ── BUG-071: one audited listing covers its thumbnails ──────────────

def _evidence(tmp_path, request_id="req_evidence_1"):
    folder = tmp_path / "evidence" / request_id
    folder.mkdir(parents=True)
    for i in range(3):
        (folder / f"00{i}_step_{i}_x.png").write_bytes(b"\x89PNG" * 1000)
    (folder / "000_step_0_x.txt").write_text("screen", encoding="utf-8")
    return request_id


class TestEvidenceThumbnails:
    def test_listing_then_thumbnails_is_one_event(self, tmp_path):
        rid = _evidence(tmp_path)
        with _client(tmp_path, audit=True) as client:
            token = _admin(client)
            listing = client.get(f"/api/v1/console/evidence/{rid}",
                                 headers=_auth(token)).json()
            for c in listing["captures"]:
                r = client.get(
                    f"/api/v1/console/evidence/{rid}/{c['name']}",
                    headers=_auth(token), params={"purpose": "thumbnail"})
                assert r.status_code == 200
            listed = _events(client, action="evidence_listed")
            assert len(listed) == 1
            assert listed[0]["severity"] == "WARNING"
            assert sorted(listed[0]["detail"]["files"]) == sorted(
                c["name"] for c in listing["captures"])
            assert _events(client, action="evidence_viewed") == []

    def test_thumbnail_without_listing_is_audited(self, tmp_path):
        rid = _evidence(tmp_path)
        with _client(tmp_path, audit=True) as client:
            token = _admin(client)
            r = client.get(f"/api/v1/console/evidence/{rid}/000_step_0_x.png",
                           headers=_auth(token),
                           params={"purpose": "thumbnail"})
            assert r.status_code == 200
            viewed = _events(client, action="evidence_viewed")
            assert len(viewed) == 1 and viewed[0]["severity"] == "WARNING"

    def test_full_view_is_always_audited(self, tmp_path):
        rid = _evidence(tmp_path)
        with _client(tmp_path, audit=True) as client:
            token = _admin(client)
            client.get(f"/api/v1/console/evidence/{rid}",
                       headers=_auth(token))
            client.get(f"/api/v1/console/evidence/{rid}/001_step_1_x.png",
                       headers=_auth(token))
            client.get(f"/api/v1/console/evidence/{rid}/000_step_0_x.txt",
                       headers=_auth(token), params={"purpose": "thumbnail"})
            viewed = _events(client, action="evidence_viewed")
            assert sorted(e["detail"]["file"] for e in viewed) == [
                "000_step_0_x.txt", "001_step_1_x.png"]

    def test_listing_by_another_user_does_not_cover(self, tmp_path):
        rid = _evidence(tmp_path)
        with _client(tmp_path, audit=True) as client:
            admin = _admin(client)
            other = _user(client, admin, "olga", "admin")
            client.get(f"/api/v1/console/evidence/{rid}",
                       headers=_auth(admin))
            client.get(f"/api/v1/console/evidence/{rid}/000_step_0_x.png",
                       headers=_auth(other), params={"purpose": "thumbnail"})
            viewed = _events(client, action="evidence_viewed")
            assert [e["detail"]["actor"] for e in viewed] == ["olga"]

    def test_expired_listing_does_not_cover(self, tmp_path, monkeypatch):
        import src.modules.console.routes as console_routes
        rid = _evidence(tmp_path)
        clock = [1000.0]
        monkeypatch.setattr(console_routes.time, "monotonic",
                            lambda: clock[0])
        with _client(tmp_path, audit=True) as client:
            token = _admin(client)
            client.get(f"/api/v1/console/evidence/{rid}",
                       headers=_auth(token))
            clock[0] += console_routes._LISTING_TTL_SECONDS + 1
            client.get(f"/api/v1/console/evidence/{rid}/000_step_0_x.png",
                       headers=_auth(token), params={"purpose": "thumbnail"})
            assert len(_events(client, action="evidence_viewed")) == 1

    def test_unknown_purpose_is_rejected(self, tmp_path):
        rid = _evidence(tmp_path)
        with _client(tmp_path) as client:
            token = _admin(client)
            r = client.get(f"/api/v1/console/evidence/{rid}/000_step_0_x.png",
                           headers=_auth(token), params={"purpose": "other"})
            assert r.status_code == 422


# ── BUG-079: audit database down → 503 with the backlog ─────────────

class TestAuditUnavailable:
    def _break(self, client, monkeypatch):
        audit = client.app.state.audit

        def down(*a, **k):
            raise ConnectionError("audit database unreachable")
        monkeypatch.setattr(audit, "query", down)
        monkeypatch.setattr(audit, "query_page", down)
        monkeypatch.setattr(audit, "pending", lambda: 7)

    @pytest.mark.parametrize("params", [{}, {"offset": 0}])
    def test_audit_list_is_503(self, tmp_path, monkeypatch, params):
        with _client(tmp_path, audit=True) as client:
            self._break(client, monkeypatch)
            r = client.get("/api/v1/audit/events", params=params)
            assert r.status_code == 503
            detail = r.json()["detail"]
            assert detail["status"] == "audit_unavailable"
            assert detail["pending_delivery"] == 7
            assert "7 event(s) waiting" in detail["message"]

    def test_audit_export_is_503(self, tmp_path, monkeypatch):
        with _client(tmp_path, audit=True) as client:
            token = _admin(client)
            self._break(client, monkeypatch)
            r = client.get("/api/v1/console/export/audit",
                           headers=_auth(token),
                           params={"date_from": "2026-09-26",
                                   "date_to": "2026-09-26"})
            assert r.status_code == 503
            assert r.json()["detail"]["pending_delivery"] == 7
