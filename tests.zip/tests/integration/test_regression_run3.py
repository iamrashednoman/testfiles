"""Regression run 3 (2026-09-27) — one test per fixed defect.

  SN-01 / SEC-01..04  stored secrets reach ONLY the configured endpoint
  SN-02               close-out verifies the ticket with ServiceNow first
  SN-03               a stuck ticket is reported once, across restarts
  SN-04 / UI-STARTTLS settings API shows the default in force
  SN-11               discover on an empty table draws no conclusion
  SN-13 / SN-14       message grammar; comment templates validated on save
  AUTHZ-01            users.manage cannot grant or take over a higher role
  DATA-02 / AUD-01    retry: superseded → 409, and audited with the actor
  VAL-01              intake refuses passwords the terminal would refuse
  CFG-01..05          atomic save, booleans, window order, setup flag, env
  WIZ-MAIL / MAIL-TAG test email before recipients; one environment tag
"""
import pytest

from tests.conftest import make_config

PASSWORD = "CorrectHorse42"
NEW_PASSWORD = "TheirOwnSecret77"


@pytest.fixture
def data_dir(tmp_path, monkeypatch):
    d = tmp_path / "data"
    d.mkdir()
    monkeypatch.setenv("FINESIII_DATA_DIR", str(d))
    return d


@pytest.fixture
def memory_vault(monkeypatch):
    from desktop import vault
    previous = vault._vault
    store = vault.MemoryVault()
    vault.use_vault(store)
    for k in list(vault.SECRET_KEYS) + [
            "SNOW_ENABLED", "SNOW_INSTANCE_URL", "SNOW_USERNAME",
            "SNOW_AUTH_METHOD", "SNOW_CLIENT_ID", "SNOW_TOKEN_URL",
            "SNOW_CLOSE_ON_SUCCESS", "SNOW_POLL_SECONDS",
            "SNOW_DUPLICATE_WINDOW_DAYS", "SMTP_HOST", "SMTP_PORT",
            "SMTP_USE_STARTTLS", "SMTP_USE_SSL", "ALERT_FROM", "ALERT_TO",
            "SMTP_ALERTS_ENABLED", "CYBERARK_BASE_URL", "CYBERARK_ENABLED",
            "CYBERARK_API_STYLE", "APP_ENV"]:
        monkeypatch.delenv(k, raising=False)
    yield store
    vault.use_vault(previous)


def _client(tmp_path, **overrides):
    from fastapi.testclient import TestClient
    from desktop.server import mount_console_ui
    from src import create_app
    overrides.setdefault("dispatcher_enabled", False)
    cfg = make_config(tmp_path, terminal_driver="mock",
                      log_dir=str(tmp_path / "logs"), **overrides)
    app = create_app(cfg)
    mount_console_ui(app, mode="agent")
    return TestClient(app)


def _auth(t):
    return {"Authorization": f"Bearer {t}"}


def _admin(client):
    client.post("/api/v1/auth/bootstrap",
                json={"username": "alice", "password": PASSWORD})
    return client.post("/api/v1/auth/login", json={
        "username": "alice", "password": PASSWORD}).json()["access_token"]


# ── SN-01 / SEC-01..04 ────────────────────────────────────────────

class TestStoredSecretsStayHome:
    @pytest.fixture
    def snow_calls(self, monkeypatch):
        """Record the credentials every ServiceNow call would carry."""
        from src.integrations.servicenow import client as mod
        seen = []

        def fake_request(self, method, url, **kw):
            seen.append({"instance": self.s.instance_url,
                         "token_url": self.s.effective_token_url,
                         "password": self.s.password,
                         "client_secret": self.s.client_secret})
            raise mod.ServiceNowError("network: stop here")
        monkeypatch.setattr(mod.ServiceNowClient, "_request", fake_request)
        monkeypatch.setattr(mod.ServiceNowClient, "_ensure_token",
                            lambda self, force=False: seen.append({
                                "instance": self.s.instance_url,
                                "token_url": self.s.effective_token_url,
                                "password": self.s.password,
                                "client_secret": self.s.client_secret}))
        return seen

    def _configure(self, client, token, monkeypatch):
        r = client.put("/api/v1/console/settings", headers=_auth(token), json={
            "SNOW_INSTANCE_URL": "https://corp.service-now.com",
            "SNOW_USERNAME": "bot", "SNOW_CLIENT_ID": "cid",
            "SNOW_AUTH_METHOD": "oauth_password"})
        assert r.status_code == 200, r.text
        monkeypatch.setenv("SNOW_PASSWORD", "STORED-PW")
        monkeypatch.setenv("SNOW_CLIENT_SECRET", "STORED-SECRET")

    @pytest.mark.parametrize("route", ["test-servicenow", "discover-servicenow"])
    @pytest.mark.parametrize("body", [
        {"instance_url": "https://evil.example"},
        {"token_url": "https://evil.example/token"},
        {"instance_url": "https://evil.example", "auth_method": "basic"},
        {"token_url": "https://evil.example/t",
         "auth_method": "oauth_client_credentials"},
    ])
    def test_foreign_endpoint_never_gets_a_stored_secret(
            self, tmp_path, data_dir, memory_vault, monkeypatch, snow_calls,
            route, body):
        with _client(tmp_path) as client:
            token = _admin(client)
            self._configure(client, token, monkeypatch)
            r = client.post(f"/api/v1/system/{route}", headers=_auth(token),
                            json=body).json()
            assert r["ok"] is False
            assert "only used with the saved address" in r["error"]
            assert snow_calls == []                       # nothing was sent
            assert "STORED" not in str(r)

    def test_configured_endpoint_still_uses_the_vault(
            self, tmp_path, data_dir, memory_vault, monkeypatch, snow_calls):
        with _client(tmp_path) as client:
            token = _admin(client)
            self._configure(client, token, monkeypatch)
            # Blank body, and the same address typed with a trailing slash.
            for body in ({}, {"instance_url": "https://CORP.service-now.com/"}):
                snow_calls.clear()
                client.post("/api/v1/system/test-servicenow",
                            headers=_auth(token), json=body)
                assert snow_calls and snow_calls[0]["password"] == "STORED-PW"
                assert snow_calls[0]["client_secret"] == "STORED-SECRET"

    def test_typed_secret_goes_where_the_admin_points(
            self, tmp_path, data_dir, memory_vault, monkeypatch, snow_calls):
        with _client(tmp_path) as client:
            token = _admin(client)
            self._configure(client, token, monkeypatch)
            client.post("/api/v1/system/test-servicenow", headers=_auth(token),
                        json={"instance_url": "https://new.example",
                              "auth_method": "basic", "password": "TYPED"})
            assert snow_calls[0]["instance"] == "https://new.example"
            assert snow_calls[0]["password"] == "TYPED"

    def test_smtp_password_only_to_the_configured_relay(
            self, tmp_path, data_dir, memory_vault, monkeypatch):
        from src.modules.notifications import notifier as mod
        seen = []

        def fake_send(self, subject, body, to=None, **kw):
            seen.append((self.s.smtp_host, self.s.smtp_port, self.s.password,
                         list(self.s.recipients_to)))
            return True
        monkeypatch.setattr(mod.EmailNotifier, "send", fake_send)
        with _client(tmp_path) as client:
            token = _admin(client)
            client.put("/api/v1/console/settings", headers=_auth(token), json={
                "SMTP_HOST": "relay.corp.example", "SMTP_PORT": 587,
                "ALERT_FROM": "rpa@corp.example"})
            monkeypatch.setenv("SMTP_PASSWORD", "STORED-SMTP")
            post = lambda b: client.post(                       # noqa: E731
                "/api/v1/system/test-email", headers=_auth(token),
                json={"to": "me@corp.example", **b}).json()
            # WIZ-MAIL: works with no default recipients saved.
            assert post({})["ok"] is True
            assert seen[-1] == ("relay.corp.example", 587, "STORED-SMTP",
                                ["me@corp.example"])
            post({"host": "evil.example"})
            assert seen[-1][0] == "evil.example" and seen[-1][2] == ""
            post({"port": "2525"})
            assert seen[-1][1] == 2525 and seen[-1][2] == ""
            post({"host": "evil.example", "password": "TYPED"})
            assert seen[-1][2] == "TYPED"

    def test_pvwa_password_only_to_the_configured_vault(
            self, tmp_path, data_dir, memory_vault, monkeypatch):
        from src.integrations.cyberark import client as mod
        seen = []
        monkeypatch.setattr(mod.CyberArkClient, "check_availability",
                            lambda self: seen.append(
                                (self.s.base_url, self.s.pvwa_password)) or True)
        monkeypatch.setattr(mod.CyberArkClient, "fetch_password",
                            lambda self: "x" * 8)
        with _client(tmp_path) as client:
            token = _admin(client)
            r = client.put("/api/v1/console/settings", headers=_auth(token), json={
                "CYBERARK_BASE_URL": "https://vault.corp.example",
                "CYBERARK_API_STYLE": "pvwa", "CYBERARK_APP_ID": "app",
                "CYBERARK_SAFE": "safe", "CYBERARK_OBJECT": "obj",
                "CYBERARK_PVWA_USER": "svc"})
            assert r.status_code == 200, r.text
            monkeypatch.setenv("CYBERARK_PVWA_PASSWORD", "STORED-PVWA")
            post = lambda b: client.post(                       # noqa: E731
                "/api/v1/system/test-cyberark", headers=_auth(token),
                json=b).json()
            post({})
            assert seen and seen[-1] == ("https://vault.corp.example",
                                         "STORED-PVWA")
            n = len(seen)
            r = post({"base_url": "https://evil.example"})
            assert r["ok"] is False
            assert all(pw != "STORED-PVWA" for _, pw in seen[n:])


# ── SN-02 ─────────────────────────────────────────────────────────

class TestCloseoutOwnership:
    def _run(self, owned, **settings_kw):
        from src.integrations.servicenow.config import ServiceNowSettings
        from src.integrations.servicenow.writeback import TicketCloseout
        from tests.unit.test_servicenow_module import (
            _Audit, _Log, _Req, _Txn, _WBClient,
        )
        s = ServiceNowSettings(instance_url="https://x", username="bot",
                               password="p", table="sc_task", **settings_kw)
        client, audit = _WBClient(owned=owned), _Audit()
        co = TicketCloseout(logger=_Log(), audit=audit,
                            settings_loader=lambda: s,
                            client_factory=lambda st: client,
                            async_send=False, sleep_func=lambda d: None)
        return co, client, audit, _Txn, _Req

    def test_foreign_ticket_is_refused_and_audited(self):
        co, client, audit, Txn, Req = self._run(owned=False)
        for status in ("done", "already_deleted", "failed"):
            co.handle_completion(Txn(status), Req(), {})
        assert client.calls == []                      # nothing written
        assert [e[1] for e in audit.events] == \
            ["servicenow_ticket_update_refused"] * 3
        assert co.last_result["refused"] is True

    def test_check_asks_servicenow_for_number_and_assignment(self):
        co, client, audit, Txn, Req = self._run(owned=True)
        co.handle_completion(Txn("done"), Req(), {})
        table, query = client.lookups[0]
        assert table == "sc_task"
        # 2026-09-28: only an ACTIVE ticket is ever written to.
        assert query == ("sys_id=abc123^number=SCTASK0007"
                         "^assigned_to.user_name=bot^active=true")
        assert client.calls and client.calls[0][0] == "state"

    def test_group_mode_and_injection(self):
        co, client, audit, Txn, Req = self._run(
            owned=True, assignment_mode="assignment_group",
            assignment_group="FINESIII Bots")
        co.handle_completion(Txn("done"), Req(), {})
        # In the group and assigned to the bot: every ticket is assigned
        # to the bot account before it is queued.
        assert client.lookups[0][1].endswith(
            "^assignment_group.name=FINESIII Bots"
            "^assigned_to.user_name=bot^active=true")
        # A sys_id crafted to widen the query is refused before any call.
        co, client, audit, Txn, Req = self._run(owned=True)
        co.handle_completion(Txn("done"), Req(sys_id="x^ORactive=true"), {})
        assert client.lookups == [] and client.calls == []
        assert audit.events[0][1] == "servicenow_ticket_update_refused"


# ── SN-03 ─────────────────────────────────────────────────────────

class TestReportedOnce:
    def _connector(self, tickets, memory):
        from src.integrations.servicenow.connector import ServiceNowConnector
        from tests.unit.test_servicenow_module import _Client, settings
        s = settings(writeback_enabled=True, writeback={
            "on_duplicate": {"add_work_note": "dup of {original_ticket_id}"}})
        client = _Client(tickets)
        rejected, audited = [], []
        c = ServiceNowConnector(s, client=client,
                                on_rejected=lambda *a: rejected.append(a))
        c.audit_hook = lambda e, d: audited.append(e)
        c.reported = memory
        return c, client, rejected, audited

    def test_unmappable_and_duplicate_report_once_until_content_changes(self):
        from src.integrations.servicenow.connector import ReportMemory
        from tests.unit.test_servicenow_module import ticket
        bad = ticket(5, emp="")                           # unmappable
        dup = ticket(6)
        memory = ReportMemory()
        totals = {"mail": 0, "notes": 0, "audit": 0}
        for _ in range(12):                               # twelve polls
            c, client, rejected, audited = self._connector([bad, dup], memory)
            c.duplicate_of = lambda p, t: {
                "request_id": "r1", "ticket_id": "SCTASK0001",
                "status": "done", "matched_fields": []}
            stats = c.poll_once()
            totals["mail"] += len(rejected)
            totals["notes"] += len(client.notes)
            totals["audit"] += len(audited)
        assert totals == {"mail": 2, "notes": 1, "audit": 2}
        assert stats["suppressed"] == 2 and stats["skipped"] == 1
        # The ticket is edited → it is news again.
        bad["u_aff"] = "11111"
        c, client, rejected, audited = self._connector([bad], memory)
        c.poll_once()
        assert len(rejected) == 1
        # Closed tickets leave the memory.
        assert "SCTASK0006" not in memory.data

    def test_invalid_at_intake_is_not_resubmitted(self):
        from src.integrations.servicenow.connector import ReportMemory
        from tests.unit.test_servicenow_module import ticket
        memory, submits = ReportMemory(), []
        for _ in range(3):
            c, *_ = self._connector([ticket(7)], memory)
            c._submit = lambda p: submits.append(p["ticket_id"]) or "invalid"
            stats = c.poll_once()
        assert submits == ["SCTASK0007"] and stats["invalid"] == 1

    def test_memory_survives_a_restart(self, tmp_path, monkeypatch):
        from desktop.snow_poller import ServiceNowPoller
        from src import create_app
        monkeypatch.setenv("FINESIII_DATA_DIR", str(tmp_path))
        app = create_app(make_config(tmp_path, terminal_driver="mock",
                                     log_dir=str(tmp_path / "logs")))
        p = ServiceNowPoller(app, "http://127.0.0.1:1")
        p._notified = {"SCTASK0005": "unmappable:x:abc"}
        p._save_state()
        assert ServiceNowPoller(app, "http://127.0.0.1:1")._notified == \
            {"SCTASK0005": "unmappable:x:abc"}


# ── SN-04 / UI-STARTTLS / SN-13 / SN-14 / CFG-01..05 ──────────────

class TestSettings:
    def _items(self, client, token):
        return {i["key"]: i for i in client.get(
            "/api/v1/console/settings", headers=_auth(token)).json()["settings"]}

    def test_defaults_in_force_are_shown(self, tmp_path, data_dir, memory_vault):
        with _client(tmp_path) as client:
            token = _admin(client)
            s = self._items(client, token)
            for key in ("SNOW_CLOSE_ON_SUCCESS", "SNOW_REVIEW_NOTE_ENABLED",
                        "SNOW_FAILURE_NOTE_ENABLED", "SMTP_USE_STARTTLS"):
                assert s[key]["value"] == "true" and s[key]["is_default"], key
            assert s["SMTP_USE_SSL"]["value"] == "false"
            assert s["SNOW_POLL_SECONDS"]["value"] == "1800"
            assert s["SNOW_DUPLICATE_WINDOW_DAYS"]["value"] == "30"
            assert s["SNOW_CLOSE_STATE"]["value"] == "3"
            assert "Human review required" in s["SNOW_REVIEW_NOTE"]["value"]
            assert s["SNOW_CLOSE_ON_SUCCESS"]["overridden"] is False
            # Turning it off is a real change and is shown as such.
            client.put("/api/v1/console/settings", headers=_auth(token),
                       json={"SNOW_CLOSE_ON_SUCCESS": "false"})
            s = self._items(client, token)
            assert s["SNOW_CLOSE_ON_SUCCESS"]["value"] == "False" \
                or s["SNOW_CLOSE_ON_SUCCESS"]["value"] == "false"
            assert s["SNOW_CLOSE_ON_SUCCESS"]["is_default"] is False

    def test_save_is_atomic_and_strict(self, tmp_path, data_dir, memory_vault):
        with _client(tmp_path) as client:
            token = _admin(client)
            put = lambda b: client.put(                         # noqa: E731
                "/api/v1/console/settings", headers=_auth(token), json=b)
            before = self._items(client, token)["max_attempts"]["value"]
            r = put({"max_attempts": 4, "no_such_key": 1})          # CFG-01
            assert r.status_code == 400
            r = put({"max_attempts": 4, "SNOW_POLL_SECONDS": 5})
            assert r.status_code == 400
            assert "at least 1 minute" in r.json()["detail"]        # SN-13
            assert "minutes" not in r.json()["detail"].split("least")[1]
            assert self._items(client, token)["max_attempts"]["value"] == before
            assert put({"SNOW_ENABLED": "maybe"}).status_code == 400  # CFG-02
            r = put({"availability_window_start": "23:00",            # CFG-03
                     "availability_window_end": "01:00"})
            assert r.status_code == 400 and "midnight" in r.json()["detail"]
            assert put({"availability_window_start": "07:00",
                        "availability_window_end": "21:00"}).status_code == 200
            assert put({"availability_window_end": "06:00"}).status_code == 400
            r = put({"SNOW_FAILURE_NOTE": "Failed {error} {oops"})    # SN-14
            assert r.status_code == 400 and "brace" in r.json()["detail"]
            r = put({"SNOW_FAILURE_NOTE": "Failed {nope}"})
            assert r.status_code == 400 and "{nope}" in r.json()["detail"]
            assert put({"SNOW_FAILURE_NOTE":
                        "Failed after {attempts}: {error}"}).status_code == 200

    def test_setup_flag_and_environment(self, tmp_path, data_dir, memory_vault):
        (data_dir / "finesiii.env").write_text("APP_ENV=production\n")
        with _client(tmp_path) as client:
            token = _admin(client)
            put = lambda v: client.put(                         # noqa: E731
                "/api/v1/system/setup", headers=_auth(token),
                json={"complete": v}).json()
            assert put(True)["complete"] is True
            assert put("false")["complete"] is False                # CFG-04
            assert put("true")["complete"] is True
            assert put(False)["complete"] is False
            st = client.get("/api/v1/system/status",
                            headers=_auth(token)).json()
            assert st["environment"] == "production"                # CFG-05

    def test_discover_on_an_empty_table(self, tmp_path, data_dir, memory_vault,
                                        monkeypatch):
        from src.integrations.servicenow import client as mod
        monkeypatch.setattr(mod.ServiceNowClient, "fetch_raw_sample",
                            lambda self, limit=2: [])
        with _client(tmp_path) as client:
            token = _admin(client)
            r = client.post("/api/v1/system/discover-servicenow",
                            headers=_auth(token),
                            json={"instance_url": "https://x",
                                  "username": "u", "password": "p"}).json()
            assert r["ok"] and r["empty"] is True and r["mapped"] == {}


# ── MAIL-TAG ──────────────────────────────────────────────────────

class TestEnvironmentTag:
    def test_rejection_mail_carries_the_install_environment(self, monkeypatch):
        from src.modules.notifications.rejection_alerts import (
            build_rejection_alerter,
        )
        for k, v in {"SMTP_ALERTS_ENABLED": "true", "SMTP_HOST": "h",
                     "ALERT_FROM": "a@b", "ALERT_TO": "c@d",
                     "TXN_NOTIFICATIONS_ENABLED": "true"}.items():
            monkeypatch.setenv(k, v)
        a = build_rejection_alerter(environment="production")
        assert a is not None
        assert a.notifier.s.environment_label == "production"


# ── AUTHZ-01 ──────────────────────────────────────────────────────

class TestNoEscalationThroughUserManagement:
    def _setup(self, client):
        from src.modules.auth.permissions import BUILTIN_ROLES
        admin = _admin(client)
        # A viewer who may also manage users: can hand out viewer, and
        # nothing above it.
        r = client.post("/api/v1/admin/roles", headers=_auth(admin), json={
            "name": "helpdesk", "description": "viewer + user admin",
            "permissions": BUILTIN_ROLES["viewer"]["permissions"]
            + ["users.manage"]})
        assert r.status_code == 201, r.text
        r = client.post("/api/v1/admin/users", headers=_auth(admin), json={
            "username": "harry", "password": PASSWORD, "role": "helpdesk"})
        assert r.status_code == 201, r.text
        harry_id = r.json()["user"]["user_id"]
        t = client.post("/api/v1/auth/login", json={
            "username": "harry", "password": PASSWORD}).json()["access_token"]
        r = client.post("/api/v1/auth/password", headers=_auth(t), json={
            "current_password": PASSWORD, "new_password": NEW_PASSWORD})
        assert r.status_code == 200, r.text
        harry = client.post("/api/v1/auth/login", json={
            "username": "harry",
            "password": NEW_PASSWORD}).json()["access_token"]
        users = client.get("/api/v1/admin/users",
                           headers=_auth(admin)).json()["users"]
        alice_id = next(u["user_id"] for u in users if u["username"] == "alice")
        return admin, harry, harry_id, alice_id

    def test_helpdesk_cannot_reach_admin(self, tmp_path):
        from fastapi.testclient import TestClient
        from src import create_app
        cfg = make_config(tmp_path, dispatcher_enabled=False,
                          terminal_driver="mock",
                          log_dir=str(tmp_path / "logs"))
        with TestClient(create_app(cfg)) as client:
            admin, harry, harry_id, alice_id = self._setup(client)
            h = _auth(harry)
            # Promote yourself.
            r = client.patch(f"/api/v1/admin/users/{harry_id}", headers=h,
                             json={"role": "admin"})
            assert r.status_code == 403
            # Create a new administrator.
            r = client.post("/api/v1/admin/users", headers=h, json={
                "username": "mallory", "password": PASSWORD, "role": "admin"})
            assert r.status_code == 403
            # Take over an administrator by resetting the password.
            r = client.patch(f"/api/v1/admin/users/{alice_id}", headers=h,
                             json={"password": "AnotherSecret99"})
            assert r.status_code == 403
            # What the role IS for still works: same-or-lower roles.
            r = client.post("/api/v1/admin/users", headers=h, json={
                "username": "vera", "password": PASSWORD, "role": "viewer"})
            assert r.status_code == 201, r.text
            r = client.post("/api/v1/admin/users", headers=h, json={
                "username": "oscar", "password": PASSWORD, "role": "operator"})
            assert r.status_code == 403
            r = client.patch(f"/api/v1/admin/users/{harry_id}", headers=h,
                             json={"display_name": "Harry H."})
            assert r.status_code == 200, r.text
            # A real administrator is unaffected.
            r = client.patch(f"/api/v1/admin/users/{harry_id}",
                             headers=_auth(admin), json={"role": "admin"})
            assert r.status_code == 200, r.text


# ── DATA-02 / AUD-01 / VAL-01 ─────────────────────────────────────

VALID = {"operation": "provision", "affiliation_code": "30822",
         "employee_code": "1217036", "password": "FUJI@33F"}


class TestRetryAndValidation:
    def test_retry_superseded_is_409_not_500(self, api_client):
        body = {**VALID, "ticket_id": "SCTASK900"}
        rid = api_client.post("/api/v1/requests", json=body).json()["request_id"]
        store = api_client.app.state.queue_store
        store.dequeue_oldest(worker_id=1)
        store.mark_complete(rid, "failed", error="x")
        newer = api_client.post("/api/v1/requests", json=body)
        assert newer.status_code == 202                  # failed never blocks
        r = api_client.post(f"/api/v1/requests/{rid}/retry")
        assert r.status_code == 409, r.text
        d = r.json()["detail"]
        assert d["status"] == "superseded"
        assert d["newer_request_id"] == newer.json()["request_id"]
        assert store.get(rid).status == "failed"          # unchanged

    def test_retry_is_audited(self, tmp_path):
        from fastapi import FastAPI
        from fastapi.testclient import TestClient
        from src.core.db import Database
        from src.modules.audit.services import TransactionStore
        from src.modules.intake.routes import build_router
        from src.modules.queue.services import QueueStore
        events = []

        class Audit:
            def event(self, category, action, **kw):
                events.append((category, action, kw))
        cfg = make_config(tmp_path)
        db = Database.from_config(cfg)
        store = QueueStore(db)

        async def no_auth():
            return "test"

        async def actor():
            return "olivia"
        app = FastAPI()
        app.include_router(build_router(
            store, TransactionStore(db), None, no_auth, cfg, audit=Audit(),
            action_dep=actor))
        api_client = TestClient(app)
        rid = api_client.post("/api/v1/requests", json={
            **VALID, "ticket_id": "SCTASK901"}).json()["request_id"]
        store.dequeue_oldest(worker_id=1)
        store.mark_complete(rid, "failed", error="boom")
        assert api_client.post(
            f"/api/v1/requests/{rid}/retry").status_code == 202
        retried = [e for e in events if e[1] == "request_retried"]
        assert retried and retried[0][2]["request_id"] == rid
        assert retried[0][2]["actor"] == "olivia"
        assert retried[0][2]["detail"]["previous_error"] == "boom"
        db.close()

    @pytest.mark.parametrize("password,problem", [
        ("1UJI@33F", "start with a letter"),
        ("FUJI@３３F", "half-width"),
        ("ＦUJI@33F", "half-width"),
    ])
    def test_intake_refuses_what_the_terminal_refuses(self, api_client,
                                                      password, problem):
        r = api_client.post("/api/v1/requests",
                            json={**VALID, "password": password})
        assert r.status_code == 400 and problem in r.json()["detail"]

    def test_good_passwords_and_deprovision_unaffected(self, api_client):
        assert api_client.post("/api/v1/requests", json=VALID).status_code == 202
        assert api_client.post("/api/v1/requests", json={
            "operation": "deprovision", "affiliation_code": "30822",
            "employee_code": "1217037"}).status_code == 202


# ══ Decisions approved 2026-09-27 ═════════════════════════════════
# DATA-01  failed requests keep the ticket password (purged after N days)
# SN-02x   ticket details only from the connector's API client
# SN-03x   rejected tickets handed to a human group (off by default)
# SN-05    description fields fetched (possible-duplicate check works)
# SN-06    cancel note      SN-07  UNCONFIRMED keeps the ticket open
# SN-08    service messages in the log file
# SN-09    close-out delivered by reconciliation, never repeated
# ROLES    roles.manage cannot create/edit a role above its own

class TestRetryKeepsTheTicketPassword:
    def _store(self, tmp_path, **cfg_kw):
        from src.core.db import Database
        from src.modules.queue.services import QueueStore
        db = Database.from_config(make_config(tmp_path, **cfg_kw))
        return db, QueueStore(db)

    def _request(self, **kw):
        from src.modules.intake.models import ProcessingRequest
        base = dict(operation="provision", affiliation_code="30822",
                    employee_code="1217036", password="TICKET01",
                    ticket_id="SCTASK1", source="servicenow")
        base.update(kw)
        return ProcessingRequest(**base)

    def test_failed_keeps_success_and_cancel_erase(self, tmp_path):
        db, q = self._store(tmp_path)
        try:
            r = self._request()
            q.enqueue(r)
            q.dequeue_oldest(worker_id=1)
            q.mark_complete(r.request_id, "failed", error="x")
            assert q.get(r.request_id).password == "TICKET01"
            assert q.retry(r.request_id)
            again = q.dequeue_oldest(worker_id=1)
            assert again.password == "TICKET01"           # what the bot types
            q.mark_complete(r.request_id, "done", result_code="OK")
            assert q.get(r.request_id).password == ""
            c = self._request(ticket_id="SCTASK2", employee_code="1217037")
            q.enqueue(c)
            assert q.cancel(c.request_id)
            assert q.get(c.request_id).password == ""
        finally:
            db.close()

    def test_purge_after_retention_and_switch_off(self, tmp_path):
        db, q = self._store(tmp_path)
        try:
            r = self._request()
            q.enqueue(r)
            q.dequeue_oldest(worker_id=1)
            q.mark_complete(r.request_id, "failed", error="x")
            assert q.purge_failed_passwords("2000-01-01") == 0
            assert q.purge_failed_passwords("2999-01-01") == 1
            assert q.get(r.request_id).password == ""
            q.keep_failed_password = False                 # retention 0
            r2 = self._request(ticket_id="SCTASK3", employee_code="1217038")
            q.enqueue(r2)
            q.dequeue_oldest(worker_id=1)
            q.mark_complete(r2.request_id, "failed", error="x")
            assert q.get(r2.request_id).password == ""
        finally:
            db.close()

    def test_retry_refused_once_the_password_is_gone(self, api_client):
        rid = api_client.post("/api/v1/requests", json={
            **VALID, "ticket_id": "SCTASK950",
            "metadata": {"password_supplied": False}}).json()["request_id"]
        store = api_client.app.state.queue_store
        assert store.get(rid).metadata["password_supplied"] is True
        store.dequeue_oldest(worker_id=1)
        store.mark_complete(rid, "failed", error="x")
        store.purge_failed_passwords("2999-01-01")
        r = api_client.post(f"/api/v1/requests/{rid}/retry")
        assert r.status_code == 409
        assert r.json()["detail"]["status"] == "password_expired"
        # A deprovision (no password involved) is retried as before.
        rid2 = api_client.post("/api/v1/requests", json={
            "operation": "deprovision", "affiliation_code": "30822",
            "employee_code": "1217039"}).json()["request_id"]
        store.dequeue_oldest(worker_id=1)
        store.mark_complete(rid2, "failed", error="x")
        assert api_client.post(
            f"/api/v1/requests/{rid2}/retry").status_code == 202


class TestTicketDetailsOnlyFromTheConnector:
    def test_other_api_clients_are_refused(self, tmp_path, monkeypatch):
        from fastapi.testclient import TestClient
        from src import create_app
        monkeypatch.setenv("FINESIII_API_KEYS", "connector:k-snow,cli:k-cli")
        cfg = make_config(tmp_path, auth_enabled=True, terminal_driver="mock",
                          log_dir=str(tmp_path / "logs"))
        body = {**VALID, "source": "servicenow", "ticket_id": "SCTASK77",
                "metadata": {"snow_details": {"sys_id": "abc"}}}
        with TestClient(create_app(cfg)) as client:
            r = client.post("/api/v1/requests", json=body,
                            headers={"X-API-Key": "k-cli"})
            assert r.status_code == 403 and "connector" in r.json()["detail"]
            r = client.post("/api/v1/requests", json=body,
                            headers={"X-API-Key": "k-snow"})
            assert r.status_code == 202, r.text
            # Without ticket details the other client works as before.
            r = client.post("/api/v1/requests",
                            json={**VALID, "employee_code": "1217040"},
                            headers={"X-API-Key": "k-cli"})
            assert r.status_code == 202, r.text


class TestCloseoutRulesAndReconciliation:
    def _closeout(self, client, queue_store=None, **settings_kw):
        from src.integrations.servicenow.config import ServiceNowSettings
        from src.integrations.servicenow.writeback import TicketCloseout
        from tests.unit.test_servicenow_module import _Audit, _Log
        s = ServiceNowSettings(instance_url="https://x", username="bot",
                               password="p", table="sc_task", **settings_kw)
        audit, log = _Audit(), _Log()
        co = TicketCloseout(logger=log, audit=audit, settings_loader=lambda: s,
                            client_factory=lambda st: client,
                            async_send=False, sleep_func=lambda d: None)
        co.queue_store = queue_store
        co.GRACE_SECONDS = 0
        return co, audit, log

    def test_unconfirmed_keeps_the_ticket_open(self):
        from tests.unit.test_servicenow_module import _Req, _Txn, _WBClient
        client = _WBClient()
        co, _, _ = self._closeout(client)
        co.handle_completion(_Txn("done", result_code="UNCONFIRMED"), _Req(), {})
        assert [c[0] for c in client.calls] == ["note"]
        assert "could not confirm" in client.calls[0][2]
        # …and says nothing when the review switch is off (never closes).
        client = _WBClient()
        co, _, _ = self._closeout(client, review_note_enabled=False)
        co.handle_completion(_Txn("done", result_code="UNCONFIRMED"), _Req(), {})
        assert client.calls == []

    def test_cancelled_gets_a_note(self):
        from tests.unit.test_servicenow_module import _Req, _Txn, _WBClient
        client = _WBClient()
        co, _, _ = self._closeout(client, cancel_note="Cancelled {ticket_id}")
        co.handle_completion(_Txn("cancelled"), _Req(), {})
        assert client.calls == [("note", "abc123", "Cancelled SCTASK0007")]

    def _queued(self, tmp_path):
        from src.core.db import Database
        from src.modules.intake.models import ProcessingRequest
        from src.modules.queue.services import QueueStore
        db = Database.from_config(make_config(tmp_path))
        q = QueueStore(db)
        r = ProcessingRequest(
            operation="provision", affiliation_code="30822",
            employee_code="1217036", ticket_id="SCTASK0007",
            source="servicenow",
            metadata={"snow_details": {"sys_id": "abc123",
                                       "number": "SCTASK0007"}})
        q.enqueue(r)
        q.dequeue_oldest(worker_id=1)
        return db, q, r

    def test_lost_closeout_is_delivered_once(self, tmp_path):
        from tests.unit.test_servicenow_module import _WBClient
        db, q, r = self._queued(tmp_path)
        try:
            q.mark_complete(r.request_id, "done", result_code="OK")
            client = _WBClient()
            co, audit, _ = self._closeout(client, queue_store=q)
            # The service stopped before the write-back: nothing recorded.
            assert co.reconcile(q.find_by_ticket("SCTASK0007")) is True
            assert [c[0] for c in client.calls] == ["state"]
            # Every later poll: already delivered → nothing.
            for _ in range(5):
                assert co.reconcile(q.find_by_ticket("SCTASK0007")) is False
            assert len(client.calls) == 1
            assert q.get(r.request_id).metadata["snow_writeback"]["action"] \
                == "close"
        finally:
            db.close()

    def test_cancel_is_noted_by_reconciliation_and_retry_gets_a_new_note(
            self, tmp_path):
        from tests.unit.test_servicenow_module import _WBClient
        db, q, r = self._queued(tmp_path)
        try:
            q.mark_complete(r.request_id, "failed", error="centre not ready")
            client = _WBClient()
            co, _, _ = self._closeout(client, queue_store=q)
            assert co.reconcile(q.find_by_ticket("SCTASK0007")) is True
            assert co.reconcile(q.find_by_ticket("SCTASK0007")) is False
            # Operator retries; it fails again → a NEW outcome, a new note.
            q.retry(r.request_id)
            assert co.reconcile(q.find_by_ticket("SCTASK0007")) is False  # queued
            q.dequeue_oldest(worker_id=1)
            import time
            time.sleep(0.01)
            q.mark_complete(r.request_id, "failed", error="again")
            assert co.reconcile(q.find_by_ticket("SCTASK0007")) is True
            assert [c[0] for c in client.calls] == ["note", "note"]
        finally:
            db.close()

    def test_failing_writeback_retries_on_later_polls_then_gives_up(
            self, tmp_path):
        from tests.unit.test_servicenow_module import _WBClient
        db, q, r = self._queued(tmp_path)
        try:
            q.mark_complete(r.request_id, "done", result_code="OK")
            client = _WBClient(fail_times=10_000)
            co, audit, log = self._closeout(client, queue_store=q)
            rounds = 0
            for _ in range(12):
                if co.reconcile(q.find_by_ticket("SCTASK0007")):
                    rounds += 1
            assert rounds == co.MAX_ROUNDS
            errors = [m for lvl, m in log.lines if lvl == "error"]
            assert len(errors) == 2           # first failure + giving up
            # ServiceNow comes back before giving up → delivered.
            db2, q2, r2 = None, None, None
        finally:
            db.close()

    def test_refused_ticket_is_not_asked_again(self, tmp_path):
        from tests.unit.test_servicenow_module import _WBClient
        db, q, r = self._queued(tmp_path)
        try:
            q.mark_complete(r.request_id, "done", result_code="OK")
            client = _WBClient(owned=False)
            co, audit, _ = self._closeout(client, queue_store=q)
            assert co.reconcile(q.find_by_ticket("SCTASK0007")) is True
            assert co.reconcile(q.find_by_ticket("SCTASK0007")) is False
            assert len(client.lookups) == 1 and client.calls == []
        finally:
            db.close()

    def test_poller_reconciles_known_tickets(self, tmp_path, monkeypatch):
        from desktop.snow_poller import ServiceNowPoller
        from src import create_app
        monkeypatch.setenv("FINESIII_DATA_DIR", str(tmp_path))
        for k, v in {"SNOW_INSTANCE_URL": "https://x", "SNOW_USERNAME": "u",
                     "SNOW_PASSWORD": "p", "SNOW_AUTH_METHOD": "basic",
                     "FINESIII_API_KEYS": "installer:k"}.items():
            monkeypatch.setenv(k, v)
        app = create_app(make_config(tmp_path, terminal_driver="mock",
                                     log_dir=str(tmp_path / "logs")))
        seen = []
        app.state.ticket_closeout.reconcile = \
            lambda request: seen.append(request.ticket_id)
        from src.modules.intake.models import ProcessingRequest
        app.state.queue_store.enqueue(ProcessingRequest(
            operation="provision", affiliation_code="30822",
            employee_code="1217036", ticket_id="SCTASK55",
            source="servicenow"))
        connector, _ = ServiceNowPoller(
            app, "http://127.0.0.1:1")._build_connector()
        assert connector.known_ticket("SCTASK55") is True
        assert connector.known_ticket("SCTASK56") is False
        assert seen == ["SCTASK55"]


class TestDescriptionFieldsAndHandOver:
    def test_description_fields_are_fetched(self, monkeypatch):
        from src.integrations.servicenow.config import (
            _with_description_fields, load_servicenow_config,
        )
        s = load_servicenow_config()
        assert {"short_description", "description"} <= set(s.fields)
        # A seeded file from before the change gets them too; "all
        # fields" (empty list) stays "all fields".
        assert _with_description_fields(["sys_id", "number"]) == \
            ["sys_id", "number", "short_description", "description"]
        assert _with_description_fields([]) == []

    def test_possible_duplicate_now_detected(self):
        from src.integrations.servicenow import duplicates
        from tests.unit.test_servicenow_module import ticket
        a = ticket(3, u_requester_email="a@x",
                   short_description="FINESIII access for new joiner")
        b = ticket(7, emp="7654321", u_requester_email="a@x",
                   short_description="FINESIII access for new joiner")
        assert duplicates.is_possible_duplicate(a, b, "u_requester_email")

    def test_rejected_ticket_is_handed_to_the_group_once(self):
        from src.integrations.servicenow.connector import (
            ReportMemory, ServiceNowConnector,
        )
        from tests.unit.test_servicenow_module import settings, ticket

        class Client:
            def __init__(self, tickets):
                self.tickets, self.moves, self.notes = tickets, [], []

            def fetch_assigned_open(self):
                return list(self.tickets)

            def reassign(self, sys_id, group, note="", table=""):
                self.moves.append((sys_id, group, note))

            def add_work_note(self, sys_id, note, table=""):
                self.notes.append((sys_id, note))
        memory = ReportMemory()
        client = Client([ticket(5, emp="")])
        for _ in range(3):
            c = ServiceNowConnector(
                settings(reject_reassign_group="Service Desk"), client=client)
            c.reported = memory
            c.poll_once()
        assert len(client.moves) == 1
        assert client.moves[0][:2] == ("sid-5", "Service Desk")
        assert "missing" in client.moves[0][2]
        # Off by default: nothing is moved.
        client = Client([ticket(6, emp="")])
        ServiceNowConnector(settings(), client=client).poll_once()
        assert client.moves == []

    def test_reassign_by_name_uses_display_value(self):
        import httpx
        from src.integrations.servicenow.client import ServiceNowClient
        from tests.unit.test_servicenow_module import settings
        seen = []

        def handler(request):
            seen.append((request.method, dict(request.url.params),
                         request.content.decode()))
            return httpx.Response(200, json={"result": {}})
        c = ServiceNowClient(settings(), transport=httpx.MockTransport(handler),
                             sleep_func=lambda d: None)
        c.reassign("sid-1", "Service Desk", "note")
        c.reassign("sid-1", "a" * 32)
        assert seen[0][1] == {"sysparm_input_display_value": "true"}
        assert '"assigned_to":""' in seen[0][2].replace(" ", "")
        assert seen[1][1] == {}


class TestServiceLogFile:
    def test_control_plane_messages_reach_the_file(self, tmp_path):
        import logging
        from src import create_app
        logs = tmp_path / "logs"
        create_app(make_config(tmp_path, terminal_driver="mock",
                               log_dir=str(logs)))
        logging.getLogger("finesiii_rpa_v3").info(
            "Poll complete: 1 submitted (marker-4711)")
        for h in logging.getLogger("finesiii_rpa_v3").handlers:
            h.flush()
        text = (logs / "finesiii_rpa_v3.log").read_text(encoding="utf-8")
        assert text.count("marker-4711") == 1
        # Building the app again does not stack handlers.
        create_app(make_config(tmp_path, terminal_driver="mock",
                               log_dir=str(logs)))
        logging.getLogger("finesiii_rpa_v3").info("second (marker-4712)")
        for h in logging.getLogger("finesiii_rpa_v3").handlers:
            h.flush()
        text = (logs / "finesiii_rpa_v3.log").read_text(encoding="utf-8")
        assert text.count("marker-4712") == 1


class TestNoEscalationThroughRoleManagement:
    def test_role_editor_cannot_exceed_own_permissions(self, tmp_path):
        from fastapi.testclient import TestClient
        from src import create_app
        from src.modules.auth.permissions import BUILTIN_ROLES
        cfg = make_config(tmp_path, dispatcher_enabled=False,
                          terminal_driver="mock",
                          log_dir=str(tmp_path / "logs"))
        with TestClient(create_app(cfg)) as client:
            admin = _admin(client)
            viewer = BUILTIN_ROLES["viewer"]["permissions"]
            r = client.post("/api/v1/admin/roles", headers=_auth(admin), json={
                "name": "roleeditor", "description": "",
                "permissions": viewer + ["roles.manage"]})
            assert r.status_code == 201, r.text
            client.post("/api/v1/admin/users", headers=_auth(admin), json={
                "username": "rita", "password": PASSWORD,
                "role": "roleeditor"})
            t = client.post("/api/v1/auth/login", json={
                "username": "rita", "password": PASSWORD}).json()["access_token"]
            client.post("/api/v1/auth/password", headers=_auth(t), json={
                "current_password": PASSWORD, "new_password": NEW_PASSWORD})
            rita = _auth(client.post("/api/v1/auth/login", json={
                "username": "rita",
                "password": NEW_PASSWORD}).json()["access_token"])
            r = client.patch("/api/v1/admin/roles/roleeditor", headers=rita,
                             json={"permissions": viewer + [
                                 "roles.manage", "users.manage"]})
            assert r.status_code == 403
            r = client.post("/api/v1/admin/roles", headers=rita, json={
                "name": "super", "description": "",
                "permissions": ["system.manage"]})
            assert r.status_code == 403
            r = client.post("/api/v1/admin/roles", headers=rita, json={
                "name": "readers", "description": "", "permissions": viewer})
            assert r.status_code == 201, r.text
