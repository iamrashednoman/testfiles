"""F3 of the fix plan (2026-10-04): ServiceNow and request intake.

UAT-03  The ServiceNow username is checked like the Bot account: with
        the Bot account blank the query uses it.
UAT-04  A console request is always recorded as entered by hand.
UAT-L07 ...and never carries a ServiceNow ticket's details.
UAT-09  "Mark setup complete" with a module on but not set up needs a
        confirmation, on the page and on the service.
UAT-10  A setting missing on this machine is "Not configured", not a
        ServiceNow outage: no count, no back-off, no outage e-mail.
UAT-L05 No internal error type ("ValueError:") in the texts shown.
UAT-L06 Discover names the file only; a server that is not ServiceNow
        gets the right hint.
UAT-L09 'manual' reads "Console or API (not specified)".
UAT-L17 While failing, the counts of the last good check are hidden.
UAT-L18 A refused ticket update is counted as "update by hand".
UAT-L19 A typed, unsaved password counts as an unsaved change; the
        preview says "the first N"."""
import http.server
import threading
from pathlib import Path
from types import SimpleNamespace

import pytest

from tests.conftest import make_config

PASSWORD = "CorrectHorse42"
ROOT = Path(__file__).resolve().parents[2]
UI = ROOT / "desktop" / "ui"
APP = (UI / "app.js").read_text(encoding="utf-8")
KIT = (UI / "ui-kit.js").read_text(encoding="utf-8")


@pytest.fixture
def data_dir(tmp_path, monkeypatch):
    from desktop import vault
    from src.modules.console.settings_catalogue import SETTINGS
    d = tmp_path / "data"
    d.mkdir()
    monkeypatch.setenv("FINESIII_DATA_DIR", str(d))
    previous = vault._vault
    vault.use_vault(vault.MemoryVault())
    for k in vault.SECRET_KEYS:
        monkeypatch.delenv(k, raising=False)
    for s in SETTINGS:
        if s["target"] == "env":
            monkeypatch.delenv(s["key"], raising=False)
    yield d
    vault.use_vault(previous)


def _client(tmp_path, **overrides):
    from fastapi.testclient import TestClient
    from desktop.server import mount_console_ui
    from src import create_app
    opts = dict(dispatcher_enabled=False, terminal_driver="mock",
                log_dir=str(tmp_path / "logs"), audit_enabled=True,
                audit_backend="sqlite",
                audit_sqlite_path=str(tmp_path / "audit.db"),
                audit_spool_path=str(tmp_path / "spool.db"),
                audit_flush_interval_seconds=0.05)
    opts.update(overrides)
    app = create_app(make_config(tmp_path, **opts))
    mount_console_ui(app, mode="agent", stop_hook=lambda: None)
    return TestClient(app)


def _token(client):
    client.post("/api/v1/auth/bootstrap",
                json={"username": "alice", "password": PASSWORD})
    return client.post("/api/v1/auth/login", json={
        "username": "alice", "password": PASSWORD}).json()["access_token"]


def _h(t):
    return {"Authorization": f"Bearer {t}"}


# ── UAT-03 ──

def test_username_with_query_characters_is_refused():
    from src.modules.console.settings_catalogue import BY_KEY, coerce
    spec = BY_KEY["SNOW_USERNAME"]
    with pytest.raises(ValueError, match=r"without \^ or ="):
        coerce(spec, "finesiii.bot^NQactive=true")
    assert coerce(spec, "finesiii.bot") == "finesiii.bot"


def test_username_used_as_bot_account_is_checked_at_start():
    from src.integrations.servicenow.config import ServiceNowSettings
    s = ServiceNowSettings(instance_url="https://dev.service-now.com",
                           username="finesiii.bot^NQactive=true",
                           assigned_to="")
    problems = s.selection_problems()
    assert any(p.startswith("username (used as the bot account)")
               for p in problems), problems
    s.assigned_to = "finesiii.bot"           # the Bot account set: fine
    assert not any("username" in p for p in s.selection_problems())


def test_saving_such_a_username_is_refused(tmp_path, data_dir):
    with _client(tmp_path) as client:
        r = client.put("/api/v1/console/settings", headers=_h(_token(client)),
                       json={"SNOW_USERNAME": "finesiii.bot^NQactive=true"})
        assert r.status_code == 400
        assert "without ^ or =" in r.text


# ── UAT-04 / UAT-L07 ──

def test_console_request_is_always_entered_by_hand(tmp_path, data_dir):
    with _client(tmp_path) as client:
        h = _h(_token(client))
        r = client.post("/api/v1/console/requests", headers=h, json={
            "operation": "deprovision", "affiliation_code": "31234",
            "employee_code": "77UAT04", "ticket_id": "UAT-F3-001",
            "source": "servicenow",
            "metadata": {"snow_details": {"sys_id": "a" * 32},
                         "note": "kept"}})
        assert r.status_code == 202, r.text
        rid = r.json()["request_id"]
        row = client.app.state.queue_store.get(rid)
        assert row.source == "manual"
        assert "snow_details" not in (row.metadata or {})
        assert (row.metadata or {}).get("note") == "kept"
        import time
        events = []
        for _ in range(60):
            events = client.get(
                "/api/v1/console/audit/events?action=console_request_adjusted",
                headers=h).json().get("events", [])
            if events:
                break
            time.sleep(0.05)
        assert events, "the change is noted in the audit trail"
        detail = events[0].get("detail") or {}
        assert detail.get("source_sent") == "servicenow"
        assert detail.get("ticket_details_removed") is True


def test_an_ordinary_console_request_is_not_noted(tmp_path, data_dir):
    with _client(tmp_path) as client:
        h = _h(_token(client))
        r = client.post("/api/v1/console/requests", headers=h, json={
            "operation": "deprovision", "affiliation_code": "31234",
            "employee_code": "77UAT05", "ticket_id": "UAT-F3-002"})
        assert r.status_code == 202, r.text
        import time
        time.sleep(0.3)
        events = client.get(
            "/api/v1/console/audit/events?action=console_request_adjusted",
            headers=h).json().get("events", [])
        assert events == []


# ── UAT-09 ──

def test_marking_setup_complete_with_a_module_half_set_up(tmp_path, data_dir,
                                                          monkeypatch):
    monkeypatch.setenv("SNOW_ENABLED", "true")       # on, nothing else set
    with _client(tmp_path) as client:
        h = _h(_token(client))
        r = client.put("/api/v1/system/setup", headers=h,
                       json={"complete": True})
        assert r.status_code == 409
        assert "ServiceNow" in r.json()["detail"]
        assert client.get("/api/v1/system/setup", headers=h).json()["complete"] is False
        r = client.put("/api/v1/system/setup", headers=h,
                       json={"complete": True, "confirm": True})
        assert r.status_code == 200 and r.json()["complete"] is True


def test_marking_setup_complete_when_nothing_is_half_set_up(tmp_path,
                                                            data_dir):
    with _client(tmp_path) as client:
        h = _h(_token(client))
        r = client.put("/api/v1/system/setup", headers=h,
                       json={"complete": True})
        assert r.status_code == 200 and r.json()["complete"] is True


# ── UAT-10 ──

class _Alerter:
    def __init__(self):
        self.down = []

    def component_down(self, component, text):
        self.down.append(text)

    def component_recovered(self, component):
        pass


def _poller(build):
    from desktop.snow_poller import ServiceNowPoller
    state = SimpleNamespace(availability_alerter=_Alerter(), audit=None,
                            queue_store=None)
    poller = ServiceNowPoller(SimpleNamespace(state=state),
                              "http://127.0.0.1:1")
    poller._build_connector = build
    poller._save_state = lambda: None
    poller.FAILURE_ALERT_THRESHOLD = 2
    return poller, state.availability_alerter


def test_a_setting_missing_here_is_not_an_outage(data_dir):
    from src.integrations.servicenow.config import ServiceNowConfigError

    def build(read_only=False):
        raise ServiceNowConfigError(["password is empty"])
    poller, alerter = _poller(build)
    for _ in range(4):
        wait = poller._poll_once()
    st = poller.status()
    assert st["not_configured"] is True
    assert st["last_error"] == "Not configured: password is empty"
    assert st["consecutive_errors"] == 0
    assert alerter.down == []                       # no outage e-mail
    assert wait == poller.ERROR_BACKOFF_SECONDS     # no growing back-off
    assert "ValueError" not in st["last_error"]


def test_servicenow_not_answering_is_still_an_outage(data_dir):
    def build(read_only=False):
        raise RuntimeError("something unexpected")
    poller, alerter = _poller(build)
    poller._poll_once()
    poller._poll_once()
    st = poller.status()
    assert st["consecutive_errors"] == 2 and st["not_configured"] is False
    assert alerter.down                              # the outage e-mail
    assert not st["last_error"].startswith("RuntimeError")


def test_config_error_is_still_a_value_error():
    """Every earlier caller that handles ValueError keeps working."""
    from src.integrations.servicenow.config import (
        ServiceNowConfigError, ServiceNowSettings,
    )
    with pytest.raises(ValueError, match="ServiceNow configuration invalid"):
        ServiceNowSettings(instance_url="", username="", password="").validate()
    assert issubclass(ServiceNowConfigError, ValueError)


# ── UAT-L06: a server that is not ServiceNow ──

class _NotFound(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(404)
        self.send_header("Content-Type", "text/plain")
        self.end_headers()
        self.wfile.write(b"not found")

    def log_message(self, *a):
        pass


def test_a_server_that_is_not_servicenow_gets_the_right_hint(tmp_path,
                                                             data_dir):
    server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), _NotFound)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    try:
        with _client(tmp_path) as client:
            r = client.post("/api/v1/system/test-servicenow",
                            headers=_h(_token(client)), json={
                                "instance_url":
                                    f"http://127.0.0.1:{server.server_port}",
                                "auth_method": "basic",
                                "username": "finesiii.bot",
                                "password": "pw"})
            assert r.status_code == 200, r.text
            body = r.json()
            assert body["ok"] is False
            assert "not as a ServiceNow instance" in body["hint"]
            assert "does not exist" not in body["hint"]
    finally:
        server.shutdown()


def test_discover_names_the_file_only():
    api = (ROOT / "desktop" / "system_api.py").read_text(encoding="utf-8")
    assert 'str(config_path("servicenow.yaml"))' not in api
    assert api.count('config_path("servicenow.yaml").name') == 2


def test_no_error_type_prefix_in_system_api():
    api = (ROOT / "desktop" / "system_api.py").read_text(encoding="utf-8")
    assert 'f"{type(e).__name__}: {e}"' not in api
    from desktop.system_api import plain_error
    assert plain_error(ValueError("Bad value")) == "Bad value"
    assert plain_error(RuntimeError()) == "RuntimeError"


def test_preview_reports_its_limit(tmp_path, data_dir):
    with _client(tmp_path) as client:
        h = _h(_token(client))
        client.app.state.snow_poller = SimpleNamespace(
            PREVIEW_MAX_TICKETS=50,
            preview=lambda: {"query": "q", "polling_enabled": True,
                             "fetched": 50, "error": "", "tickets": []})
        r = client.post("/api/v1/system/servicenow/preview", headers=h)
        assert r.status_code == 200, r.text
        assert r.json()["limit"] == 50 and r.json()["fetched"] == 50


def test_preview_when_not_configured(tmp_path, data_dir):
    from src.integrations.servicenow.config import ServiceNowConfigError

    def fail():
        raise ServiceNowConfigError(["password is empty"])
    with _client(tmp_path) as client:
        h = _h(_token(client))
        client.app.state.snow_poller = SimpleNamespace(
            PREVIEW_MAX_TICKETS=50, preview=fail)
        r = client.post("/api/v1/system/servicenow/preview", headers=h)
        assert r.status_code == 400
        assert r.json()["detail"] == "Not configured: password is empty"


# ── UAT-L18 ──

def test_refused_ticket_updates_are_counted(tmp_path):
    from src.core.db import Database
    from src.modules.intake.models import ProcessingRequest
    from src.modules.queue.services import QueueStore
    db = Database("sqlite", sqlite_path=str(tmp_path / "q.db"))
    store = QueueStore(db)
    for i, mark in enumerate([
            {"pending": True, "rounds": 1},
            {"pending": True, "rounds": 9},
            {"pending": False, "note": "refused: the ticket is assigned to "
                                       "someone else"},
            {"pending": False, "note": ""}]):
        req = ProcessingRequest(operation="deprovision", affiliation_code="31234",
                             employee_code=f"77UAT1{i}", source="servicenow",
                             ticket_id=f"SCTASK{i}",
                             metadata={"snow_writeback": mark})
        store.enqueue(req)
    assert store.writeback_backlog(6) == {"pending": 1, "given_up": 1,
                                          "refused": 1}


# ── the console page ──

def _function(source, signature):
    body = source[source.index(signature):]
    return body[:body.index("\n}\n") + 2]


def test_page_shows_not_configured_and_hides_stale_counts():
    assert "sn.not_configured ? 'Not configured'" in APP
    assert "stats.fetched != null && !troubled" in APP
    assert "(tu.given_up || 0) + (tu.refused || 0)" in APP
    assert "after about 30 seconds when ServiceNow does not answer" in APP


def test_page_confirms_an_incomplete_setup():
    assert "incompleteModules(SETUP)" in APP
    assert "confirm: missing.length > 0" in APP


def test_page_counts_typed_passwords_and_says_first_n():
    unsaved = _function(APP, "function unsavedIn(container)")
    assert "SETTING_FIELDS" in unsaved and "changedField" in unsaved
    assert "Preview of the first ${fmtNum(r.limit)} open tickets" in APP


def test_page_strips_validator_prefixes_and_relabels_manual():
    assert "replace(/^(Value|Assertion) error, /, '')" in APP
    assert "manual: 'Console or API (not specified)'" in KIT
    assert "['manual', 'Console or API (not specified)']" in APP
