"""ServiceNow connection test in group mode (2026-09-30, R9): the bot
account checked is the one tickets are assigned to, its membership of
the group is read, and each Requested For value is resolved to a user.
Against the mock ServiceNow over the real client."""
import pytest

from scripts.run_mock_snow_server import (
    GROUP, SAILPOINT_USER, TicketStore, create_mock_app, user_sys_id,
)
from tests.conftest import make_config

PASSWORD = "CorrectHorse42"


@pytest.fixture
def data_dir(tmp_path, monkeypatch):
    from desktop import vault
    d = tmp_path / "data"
    d.mkdir()
    monkeypatch.setenv("FINESIII_DATA_DIR", str(d))
    previous = vault._vault
    vault.use_vault(vault.MemoryVault())
    for k in vault.SECRET_KEYS:
        monkeypatch.delenv(k, raising=False)
    yield d
    vault.use_vault(previous)


@pytest.fixture
def mock_snow(monkeypatch):
    """Every ServiceNow client in this test talks to the mock."""
    from tests.conftest import asgi_transport
    from src.integrations.servicenow import client as client_mod
    store = TicketStore()
    transport = asgi_transport(create_mock_app(store))
    original = client_mod.ServiceNowClient.__init__

    def init(self, *a, **kw):
        kw["transport"] = transport
        original(self, *a, **kw)
    monkeypatch.setattr(client_mod.ServiceNowClient, "__init__", init)
    return store


def _client(tmp_path):
    from fastapi.testclient import TestClient
    from desktop.server import mount_console_ui
    from src import create_app
    app = create_app(make_config(tmp_path, terminal_driver="mock",
                                 dispatcher_enabled=False,
                                 log_dir=str(tmp_path / "logs")))
    mount_console_ui(app, mode="agent")
    return TestClient(app)


def _token(client):
    client.post("/api/v1/auth/bootstrap",
                json={"username": "alice", "password": PASSWORD})
    return client.post("/api/v1/auth/login", json={
        "username": "alice", "password": PASSWORD}).json()["access_token"]


# https: the address rules of 2026-10-03 apply to tests as well.
BODY = {"instance_url": "https://testserver", "auth_method": "basic",
        "username": "api.user", "password": "pw", "table": "sc_task",
        "assigned_to": "finesiii.bot", "assignment_mode": "assignment_group",
        "assignment_group": GROUP}


def _test(client, token, **extra):
    r = client.post("/api/v1/system/test-servicenow",
                    headers={"Authorization": f"Bearer {token}"},
                    json=dict(BODY, **extra))
    assert r.status_code == 200, r.text
    return r.json()


def test_group_mode_checks_membership_and_requested_for(tmp_path, data_dir,
                                                        mock_snow):
    with _client(tmp_path) as client:
        token = _token(client)
        r = _test(client, token, requested_for=SAILPOINT_USER)
        assert r["ok"] is True
        # F4: the account checked is the bot account, not the sign-in one.
        assert r["account"]["user_name"] == "finesiii.bot"
        assert r["group_member"] is True
        (found,) = r["requested_for"]
        assert found["matches"] == 1
        assert found["sys_id"] == mock_snow.sailpoint_user
        assert "not a member" not in r["hint"]


def test_hints_for_unknown_ambiguous_and_non_member(tmp_path, data_dir,
                                                    mock_snow):
    mock_snow.add_user("Sample Person", "1700001", "")
    mock_snow.add_user("Sample Person", "1700002", "")
    mock_snow.assign_rule = "forbidden"         # not a member here
    with _client(tmp_path) as client:
        token = _token(client)
        r = _test(client, token,
                  requested_for="Nobody Here, Sample Person")
        assert r["ok"] is True and r["group_member"] is False
        assert "not a member of the group" in r["hint"]
        assert "No ServiceNow user is named 'Nobody Here'" in r["hint"]
        assert "No ServiceNow user is named 'Nobody Here'" in r["notes"]\
            [[i for i, n in enumerate(r["notes"]) if "Nobody" in n][0]]
        assert "Several users are named 'Sample Person'" in r["hint"]


def test_filters_are_checked_in_both_modes(tmp_path, data_dir, mock_snow):
    # Every filter that is filled in applies whatever the mode: the
    # group and Requested For are checked with the bot account as well.
    with _client(tmp_path) as client:
        token = _token(client)
        r = _test(client, token, assignment_mode="assigned_to",
                  requested_for=SAILPOINT_USER)
        assert r["ok"] is True
        assert r["requested_for"][0]["matches"] == 1
        assert r["group_member"] is True
        assert r["account"]["sys_id"] == user_sys_id("finesiii.bot")
        steps = [c["step"] for c in r["selection_counts"]]
        assert steps == ["Open tickets in the table",
                         f"In the group '{GROUP}'",
                         "Assigned to the bot account", "Approved",
                         "Requested For"]
