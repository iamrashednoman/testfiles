"""F8 of the fix plan (2026-10-04): transparency, governance, tidy-up.

CFG-03  "Stored in: application database" with the last change; Export
        configuration; a warning for .env keys that are not read.
CFG-06  A save over a newer change by someone else is refused.
CFG-07  Recent changes from the audit trail, with Restore.
CFG-08  The configuration files in force: location, time, checksum.
SES-06  Active sessions on Users, with End session.
OPS-07  Read-only viewer for the configuration files.
UAT-L01 The Dashboard during a database outage.
UAT-L02 A range ending after today is a range ending today.
UAT-L03 Reversed dates refused; the audit export needs a period.
UAT-L04 "4 min", not "3 min 60 s".
UAT-L10 / L12 / L25 / L26 / L28  wording, banners, open figure tables,
        requester, whole numbers, audit search and the Evidence category."""
import csv
import io
import sqlite3
import time
from pathlib import Path

import pytest

from tests.conftest import make_config

PASSWORD = "CorrectHorse42"
ROOT = Path(__file__).resolve().parents[2]
APP = (ROOT / "desktop" / "ui" / "app.js").read_text(encoding="utf-8")
KIT = (ROOT / "desktop" / "ui" / "ui-kit.js").read_text(encoding="utf-8")
INDEX = (ROOT / "desktop" / "ui" / "index.html").read_text(encoding="utf-8")


@pytest.fixture
def data_dir(tmp_path, monkeypatch):
    from desktop import vault
    d = tmp_path / "data"
    d.mkdir()
    monkeypatch.setenv("FINESIII_DATA_DIR", str(d))
    previous = vault._vault
    vault.use_vault(vault.MemoryVault())
    yield d
    vault.use_vault(previous)


def _app(tmp_path, **overrides):
    from desktop.server import mount_console_ui
    from src import create_app
    opts = dict(terminal_driver="mock", ocr_enabled=False,
                log_dir=str(tmp_path / "logs"),
                sqlite_path=str(tmp_path / "shared.db"))
    opts.update(overrides)
    app = create_app(make_config(tmp_path, **opts))
    mount_console_ui(app, mode="agent", stop_hook=lambda: None)
    return app


def _audited(tmp_path, **overrides):
    return _app(tmp_path, audit_enabled=True, audit_backend="sqlite",
                audit_sqlite_path=str(tmp_path / "audit.db"),
                audit_spool_path=str(tmp_path / "spool.db"),
                audit_flush_interval_seconds=0.1, **overrides)


def _client(app):
    from fastapi.testclient import TestClient
    return TestClient(app)


def _login(client, username="alice", password=PASSWORD, first=False):
    if first:
        client.post("/api/v1/auth/bootstrap",
                    json={"username": username, "password": password})
    t = client.post("/api/v1/auth/login", json={
        "username": username, "password": password}).json()["access_token"]
    return {"Authorization": f"Bearer {t}"}


def _second_admin(client, h, username="uatbea", password="Second#Admin482"):
    client.post("/api/v1/admin/users", headers=h, json={
        "username": username, "role": "admin", "password": "Temporary#4821x"})
    t = client.post("/api/v1/auth/login", json={
        "username": username,
        "password": "Temporary#4821x"}).json()["access_token"]
    client.post("/api/v1/auth/password",
                headers={"Authorization": f"Bearer {t}"},
                json={"current_password": "Temporary#4821x",
                      "new_password": password})
    return _login(client, username, password)


def _wait(fn, seconds=10.0):
    deadline = time.time() + seconds
    while time.time() < deadline:
        value = fn()
        if value:
            return value
        time.sleep(0.2)
    return fn()


# ── CFG-06: a save over a newer change ──

def test_save_over_a_newer_change_is_refused(tmp_path, data_dir):
    with _client(_app(tmp_path)) as client:
        h1 = _login(client, first=True)
        h2 = _second_admin(client, h1)
        rev = client.get("/api/v1/console/settings",
                         headers=h1).json()["revision"]["rev"]
        # Both pages are open at `rev`. The second person saves first.
        r = client.put("/api/v1/console/settings", headers={
            **h2, "X-Settings-Revision": str(rev)},
            json={"max_attempts": 4})
        assert r.status_code == 200 and r.json()["revision"]["rev"] == rev + 1
        # The first person, on the old page, saves the same setting.
        r = client.put("/api/v1/console/settings", headers={
            **h1, "X-Settings-Revision": str(rev)},
            json={"max_attempts": 5})
        assert r.status_code == 409
        text = r.json()["detail"]
        assert "changed by uatbea at" in text and "nothing was saved" in text
        settings = {s["key"]: s for s in client.get(
            "/api/v1/console/settings", headers=h1).json()["settings"]}
        assert str(settings["max_attempts"]["value"]) == "4"
        # Another setting from the same old page is not blocked.
        assert client.put("/api/v1/console/settings", headers={
            **h1, "X-Settings-Revision": str(rev)},
            json={"retry_max_delay_seconds": 30}).status_code == 200
        # A caller that sends no revision (a script) works as before.
        assert client.put("/api/v1/console/settings", headers=h1,
                          json={"max_attempts": 5}).status_code == 200


def test_machine_settings_have_the_same_check(tmp_path, data_dir):
    with _client(_app(tmp_path)) as client:
        h1 = _login(client, first=True)
        h2 = _second_admin(client, h1)
        rev = client.get("/api/v1/system/deployment",
                         headers=h1).json()["revision"]["rev"]
        assert client.put("/api/v1/system/deployment", headers={
            **h2, "X-Machine-Revision": str(rev)},
            json={"LOG_LEVEL": "WARNING"}).status_code == 200
        r = client.put("/api/v1/system/deployment", headers={
            **h1, "X-Machine-Revision": str(rev)},
            json={"LOG_LEVEL": "ERROR"})
        assert r.status_code == 409
        assert "'Log level' changed by uatbea" in r.json()["detail"]
    assert "'X-Settings-Revision'" in APP and "'X-Machine-Revision'" in APP


# ── CFG-03: where settings are kept, export, .env keys not read ──

def test_settings_say_where_they_are_kept_and_who_changed_them(
        tmp_path, data_dir):
    with _client(_app(tmp_path)) as client:
        h = _login(client, first=True)
        client.put("/api/v1/console/settings", headers=h,
                   json={"max_attempts": 4})
        d = client.get("/api/v1/console/settings", headers=h).json()
        assert d["stored_in"] == "application database"
        item = {s["key"]: s for s in d["settings"]}["max_attempts"]
        assert item["changed_by"] == "alice" and item["changed_at"]
        # A cleared setting keeps who cleared it.
        client.put("/api/v1/console/settings", headers=h,
                   json={"max_attempts": ""})
        item = {s["key"]: s for s in client.get(
            "/api/v1/console/settings", headers=h).json()["settings"]
        }["max_attempts"]
        assert item["changed_by"] == "alice" and not item["overridden"]
    assert "'Stored in: application database'" in APP


def test_export_configuration(tmp_path, data_dir, monkeypatch):
    from desktop import vault
    monkeypatch.delenv("SMTP_PASSWORD", raising=False)
    vault.set_secret("SMTP_PASSWORD", "Uat-Smtp-Secret-7781")
    app = _audited(tmp_path)
    with _client(app) as client:
        h = _login(client, first=True)
        client.put("/api/v1/console/settings", headers=h,
                   json={"max_attempts": 4})
        r = client.get("/api/v1/system/configuration/export", headers=h)
        assert r.status_code == 200
        assert r.headers["content-type"].startswith("text/csv")
        assert "Uat-Smtp-Secret" not in r.text
        # The file starts with a byte-order mark, for Excel.
        rows = list(csv.DictReader(io.StringIO(r.text.lstrip("\ufeff"))))
        by_key = {row["key"]: row for row in rows if row["key"]}
        assert by_key["max_attempts"]["value"] == "4"
        assert by_key["max_attempts"]["source"] == "application database"
        assert by_key["max_attempts"]["changed_by"] == "alice"
        assert by_key["LOG_LEVEL"]["area"] == "This machine"
        assert by_key["SMTP_PASSWORD"]["value"] == "(set)"
        files = [row for row in rows if row["area"] == "Configuration file"]
        assert {"servicenow.yaml", "email_messages.yaml",
                "layouts.yaml"} <= {f["setting"] for f in files}
        assert any(f["value"].startswith("sha256 ") for f in files)
        assert not any(row["key"].startswith(("PASSWORD_HISTORY_",
                                              "SETTINGS_REVISION"))
                       for row in rows)
        assert _wait(lambda: [e for e in client.get(
            "/api/v1/audit/events?action=configuration_exported",
            headers=h).json()["events"]])
    vault.delete_secret("SMTP_PASSWORD")
    assert "'/system/configuration/export'" in APP
    assert 'id="set-export"' in INDEX


def test_env_keys_not_read_are_reported(tmp_path, data_dir, monkeypatch):
    from desktop import deployment, system_api
    monkeypatch.setattr(deployment, "read_app_env", lambda: {
        "SNOW_INSTANCE_URL": "https://example.service-now.com",
        "LOG_LEVEL": "INFO", "APP_ENV": "development",
        "DATABASE_PASSWORD": "x"})
    assert system_api.unread_app_env_keys() == ["DATABASE_PASSWORD",
                                                "SNOW_INSTANCE_URL"]
    with _client(_app(tmp_path)) as client:
        h = _login(client, first=True)
        warnings = client.get("/api/v1/system/status",
                              headers=h).json()["startup_warnings"]
        text = [w for w in warnings if ".env" in w][0]
        assert "DATABASE_PASSWORD, SNOW_INSTANCE_URL" in text
        assert "does not read from that file" in text


# ── CFG-07: recent changes and Restore ──

def test_recent_changes_with_restore(tmp_path, data_dir):
    with _client(_audited(tmp_path)) as client:
        h = _login(client, first=True)
        for value in (4, 2):
            assert client.put("/api/v1/console/settings", headers=h,
                              json={"max_attempts": value}).status_code == 200

        def two():
            rows = [c for c in client.get(
                "/api/v1/console/settings/changes",
                headers=h).json()["changes"] if c["key"] == "max_attempts"]
            return rows if len(rows) >= 2 else None
        newest, older = _wait(two)[:2]
        assert (newest["before"], newest["after"]) == ("4", 2)
        assert older["before"] is None and older["before_known"]
        assert newest["by"] == "alice" and newest["label"]
        # Restore = save the earlier value.
        assert client.put("/api/v1/console/settings", headers=h,
                          json={"max_attempts": newest["before"]}
                          ).status_code == 200
        value = {s["key"]: s for s in client.get(
            "/api/v1/console/settings", headers=h).json()["settings"]
        }["max_attempts"]["value"]
        assert str(value) == "4"
    assert "'/console/settings/changes?limit=50'" in APP
    assert "['History', ['Recent changes']]" in APP


def test_recent_changes_when_the_trail_is_off(tmp_path, data_dir):
    with _client(_app(tmp_path)) as client:
        h = _login(client, first=True)
        d = client.get("/api/v1/console/settings/changes", headers=h).json()
        assert d == {"enabled": False, "changes": []}


def test_secrets_are_not_settings_rows():
    """Passwords live in the credential store, never on these pages, so
    no value of one can reach Recent changes or the export."""
    from src.modules.console.settings_catalogue import SETTINGS
    assert not [s["key"] for s in SETTINGS if s["secret"]]


# ── CFG-08 / OPS-07: configuration files ──

def test_configuration_files_in_force(tmp_path, data_dir):
    with _client(_app(tmp_path)) as client:
        h = _login(client, first=True)
        files = {f["name"]: f for f in client.get(
            "/api/v1/system/config-files", headers=h).json()["files"]}
        for name in ("servicenow.yaml", "email_messages.yaml",
                     "notifications.yaml", "errors.yaml", "ocr.yaml",
                     "layouts.yaml", ".env", "finesiii.env"):
            assert name in files, name
        snow = files["servicenow.yaml"]
        assert snow["exists"] and len(snow["sha256"]) == 64
        assert snow["modified"] and snow["viewable"]
        assert not files[".env"]["viewable"]
        r = client.get("/api/v1/system/config-files/view",
                       params={"name": "servicenow.yaml"}, headers=h)
        assert r.status_code == 200 and r.json()["text"]
        for name in (".env", "finesiii.env", "../secrets.env", "x.yaml"):
            assert client.get("/api/v1/system/config-files/view",
                              params={"name": name},
                              headers=h).status_code == 404
    assert "'/system/config-files'" in APP and 'id="sys-files"' in INDEX


def test_viewer_masks_secrets(tmp_path, data_dir, monkeypatch):
    from desktop import system_api
    f = tmp_path / "servicenow.yaml"
    f.write_text("instance: https://x\npassword: Uat-Yaml-Secret-9\n",
                 encoding="utf-8")
    real = system_api.config_files
    monkeypatch.setattr(system_api, "config_files", lambda cfg: [
        dict(e, path=str(f), size=f.stat().st_size, exists=True)
        if e["name"] == "servicenow.yaml" else e for e in real(cfg)])
    with _client(_app(tmp_path)) as client:
        h = _login(client, first=True)
        text = client.get("/api/v1/system/config-files/view",
                          params={"name": "servicenow.yaml"},
                          headers=h).json()["text"]
        assert "Uat-Yaml-Secret" not in text and "instance" in text


# ── SES-06: active sessions ──

def test_active_sessions_and_end_session(tmp_path, data_dir):
    with _client(_audited(tmp_path)) as client:
        h1 = _login(client, first=True)
        h2 = _login(client)                     # a second window
        d = client.get("/api/v1/admin/sessions", headers=h1).json()
        assert d["count"] >= 2
        mine = [s for s in d["sessions"] if s["current"]]
        other = [s for s in d["sessions"] if not s["current"]][0]
        assert len(mine) == 1 and other["username"] == "alice"
        r = client.delete(f"/api/v1/admin/sessions/{other['session_id']}",
                          headers=h1)
        assert r.status_code == 200
        # That window is signed out; this one is not.
        assert client.get("/api/v1/auth/me", headers=h2).status_code == 401
        assert client.get("/api/v1/auth/me", headers=h1).status_code == 200
        assert client.delete(f"/api/v1/admin/sessions/{other['session_id']}",
                             headers=h1).status_code == 404
        assert _wait(lambda: [e for e in client.get(
            "/api/v1/audit/events?action=session_ended",
            headers=h1).json()["events"]])
    assert "'/admin/sessions'" in APP and 'id="us-sessions"' in INDEX


def test_ending_a_session_needs_user_management(tmp_path, data_dir):
    with _client(_app(tmp_path)) as client:
        h = _login(client, first=True)
        client.post("/api/v1/admin/users", headers=h, json={
            "username": "uatcora", "role": "viewer",
            "password": "Temporary#4821x"})
        t = client.post("/api/v1/auth/login", json={
            "username": "uatcora",
            "password": "Temporary#4821x"}).json()["access_token"]
        client.post("/api/v1/auth/password",
                    headers={"Authorization": f"Bearer {t}"},
                    json={"current_password": "Temporary#4821x",
                          "new_password": "Viewer#Own48213"})
        hv = _login(client, "uatcora", "Viewer#Own48213")
        sid = client.get("/api/v1/admin/sessions",
                         headers=h).json()["sessions"][0]["session_id"]
        assert client.get("/api/v1/admin/sessions",
                          headers=hv).status_code == 403
        assert client.delete(f"/api/v1/admin/sessions/{sid}",
                             headers=hv).status_code == 403


# ── UAT-L01: the Dashboard during a database outage ──

def test_dashboard_during_a_database_outage(tmp_path, data_dir,
                                            monkeypatch):
    app = _app(tmp_path)
    with _client(app) as client:
        h = _login(client, first=True)
        # A second window signed in, but it has not read the Dashboard.
        fresh = _login(client)
        assert client.get("/api/v1/console/summary",
                          headers=h).status_code == 200
        db = app.state.queue_store.db

        def down(*a, **k):
            raise sqlite3.OperationalError("database is unavailable")
        for name in ("fetchone", "fetchall", "execute"):
            monkeypatch.setattr(db, name, down)
        r = client.get("/api/v1/console/summary", headers=h)
        assert r.status_code == 200
        d = r.json()
        assert d["database"] == "down"
        assert d["queue"] is None and d["recent"] is None
        assert d["service"] == "up"
        # Only a session checked in full before the outage gets this.
        assert client.get("/api/v1/console/summary",
                          headers=fresh).status_code == 503
        # Other pages are not affected by this allowance.
        assert client.get("/api/v1/console/settings",
                          headers=h).status_code == 503


def test_error_screen_card_when_the_trail_cannot_be_read(tmp_path, data_dir,
                                                         monkeypatch):
    app = _audited(tmp_path)
    with _client(app) as client:
        h = _login(client, first=True)

        def down(*a, **k):
            raise ConnectionError("audit database unreachable")
        monkeypatch.setattr(app.state.audit, "query", down)
        d = client.get("/api/v1/console/summary", headers=h).json()
        assert d["errors_by_rule"] is None
    assert "d.errors_by_rule === null" in APP


# ── UAT-L02 / L03: periods and dates ──

def test_range_ending_after_today_is_a_range_ending_today():
    from datetime import timedelta
    from src.modules.console.metrics import resolve_period
    from src.modules.intake.models import now_jst
    today = now_jst().date()
    start, end = resolve_period(
        "custom", (today - timedelta(days=2)).isoformat(),
        (today + timedelta(days=5)).isoformat())
    assert (start, end) == (today - timedelta(days=2), today)
    with pytest.raises(ValueError, match="starts after today"):
        resolve_period("custom", (today + timedelta(days=1)).isoformat(),
                       (today + timedelta(days=3)).isoformat())


def test_reversed_dates_and_the_audit_export(tmp_path, data_dir):
    with _client(_audited(tmp_path)) as client:
        h = _login(client, first=True)
        for table in ("requests", "transactions", "audit"):
            r = client.get(f"/api/v1/console/export/{table}", headers=h,
                           params={"date_from": "2026-10-03",
                                   "date_to": "2026-10-01"})
            assert r.status_code == 400
            assert r.json()["detail"] == \
                "The end date is before the start date"
        r = client.get("/api/v1/console/export/audit", headers=h)
        assert r.status_code == 400
        assert "Choose the first and last day" in r.json()["detail"]
        assert client.get("/api/v1/console/export/audit", headers=h,
                          params={"ticket_id": "UAT-1"}).status_code == 200
        assert client.get("/api/v1/console/export/audit", headers=h,
                          params={"date_from": "2026-10-01",
                                  "date_to": "2026-10-03"}).status_code == 200
    assert APP.count("p.date_to < p.date_from") == 2


# ── UAT-L11: the reply while paused ──

def test_reply_mentions_the_pause(tmp_path, data_dir):
    with _client(_app(tmp_path, dispatcher_enabled=True)) as client:
        h = _login(client, first=True)
        client.post("/api/v1/system/dispatcher/pause", headers=h)
        r = client.post("/api/v1/requests", json={
            "operation": "deprovision", "affiliation_code": "31234",
            "employee_code": "77UAT81", "ticket_id": "UAT-F8-001"})
        assert r.status_code == 202
        assert "Processing is paused" in r.json()["message"]
        client.post("/api/v1/system/dispatcher/resume", headers=h)


# ── UAT-L28 and the wording items ──

def test_whole_number_settings_refuse_fractions(tmp_path, data_dir):
    from src.modules.console.settings_catalogue import BY_KEY, coerce
    spec = BY_KEY["max_attempts"]
    with pytest.raises(ValueError, match="whole number"):
        coerce(spec, 1.5)
    with pytest.raises(ValueError, match="whole number"):
        coerce(spec, "2.5")
    assert coerce(spec, 3.0) == 3 and coerce(spec, "4") == 4
    with pytest.raises(ValueError, match="must be a number"):
        coerce(spec, "three")
    with _client(_app(tmp_path)) as client:
        h = _login(client, first=True)
        r = client.put("/api/v1/console/settings", headers=h,
                       json={"max_attempts": 1.5})
        assert r.status_code == 400 and "whole number" in r.json()["detail"]


def test_audit_search_matches_the_words_shown():
    from src.modules.audit.trail_db import _page_where
    where, params = _page_where("?", {}, "poll failed", "detail")
    assert "%poll failed%" in params and "%poll_failed%" in params
    where, params = _page_where("?", {"category": "evidence"}, None,
                                "detail")
    assert "action IN" in where
    assert params == ["evidence", "evidence_listed", "evidence_viewed"]


def test_audit_search_and_evidence_category_end_to_end(tmp_path, data_dir):
    with _client(_audited(tmp_path)) as client:
        h = _login(client, first=True)
        audit = client.app.state.audit
        audit.event("evidence", "evidence_purged", detail={"count": 1})
        audit.event("console", "evidence_viewed", actor="alice",
                    detail={"file": "x.png"})
        found = _wait(lambda: client.get(
            "/api/v1/console/audit/events",
            params={"q": "evidence purged", "limit": 50, "offset": 0},
            headers=h).json()["events"])
        assert [e["action"] for e in found] == ["evidence_purged"]
        both = _wait(lambda: (lambda ev: ev if len(ev) == 2 else None)(
            client.get("/api/v1/console/audit/events",
                       params={"category": "evidence", "limit": 50,
                               "offset": 0}, headers=h).json()["events"]))
        assert {e["action"] for e in both} == {"evidence_purged",
                                               "evidence_viewed"}
    assert '<option value="evidence">Evidence</option>' in INDEX
    assert "evidence: 'Evidence'" in KIT


def test_page_wording_items():
    # UAT-L04: whole seconds first, "4 min" with no "0 s".
    assert "const total = Math.round(s)" in KIT
    assert "return r ? `${m} min ${r} s` : `${m} min`;" in KIT
    # UAT-L10: the audit trail turned off, said as such.
    assert "'The audit trail is turned off, so no events are recorded.'" in APP
    # UAT-L12: "(1 row)", and refusals without ".;".
    assert "row${Number(info.rows) === 1 ? '' : 's'}" in APP
    assert "String(e.message).replace(/[.\\s]+$/, '')" in APP
    # UAT-L25: the waiting notice clears at 0.
    assert "else if (/waiting to be written/.test($('au-msg').textContent))" in APP
    # UAT-L26: unchanged figures are not redrawn; open tables stay open.
    assert "if (sig === DASH_METRICS_SIG" in APP
    assert "d.open = true" in APP
    # UAT-L28: the requester as text.
    assert "[v.name, v.employee_number, v.email].filter(Boolean)" in APP
    assert set(__import__("re").findall(r"\?v=([0-9.a-z]+)", INDEX)) == \
        {"2026.10.06"}


def test_fmtsecs_when_node_is_available():
    import shutil
    import subprocess
    node = shutil.which("node")
    if not node:
        pytest.skip("node is not installed")
    script = ("const s = require('fs').readFileSync(process.argv[1], 'utf8');"
              "const m = s.slice(s.indexOf('function fmtSecs'),"
              " s.indexOf('function fmtPct'));"
              "const f = new Function(m + '; return fmtSecs;')();"
              "console.log([f(239.6), f(185), f(59.7), f(42), f(3725)]"
              ".join('|'));")
    out = subprocess.run([node, "-e", script, str(ROOT / "desktop" / "ui"
                                                   / "ui-kit.js")],
                         capture_output=True, text=True, timeout=30)
    assert out.stdout.strip() == "4 min|3 min 5 s|1 min|42 s|1 h 2 min"
