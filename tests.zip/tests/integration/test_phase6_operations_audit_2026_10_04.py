"""Phase 6 of the console module review (2026-10-04): the clean-up runs
whatever the bot is doing, the service log rotates and can be filtered,
masking covers more forms, the System page tells what holds work back,
lead time and the oldest waiting request are measured, and the audit
trail says whether it is protected and what is still to be written."""
import logging
import os
import time
from datetime import date, timedelta
from pathlib import Path
from types import SimpleNamespace

import pytest

from tests.conftest import make_config

PASSWORD = "CorrectHorse42"
UI = Path(__file__).resolve().parents[2] / "desktop" / "ui"
_real_sleep = time.sleep


@pytest.fixture
def data_dir(tmp_path, monkeypatch):
    from desktop import vault
    d = tmp_path / "data"
    d.mkdir()
    monkeypatch.setenv("FINESIII_DATA_DIR", str(d))
    previous = vault._vault
    vault.use_vault(vault.MemoryVault())
    for k in vault.SECRET_KEYS:
        monkeypatch.delenv(k, raising=False)
    yield d
    vault.use_vault(previous)


def _app(tmp_path, audit=False, **overrides):
    from desktop.server import mount_console_ui
    from src import create_app
    if audit:
        overrides.update(
            audit_enabled=True, audit_backend="sqlite",
            audit_sqlite_path=str(tmp_path / "audit.db"),
            audit_spool_path=str(tmp_path / "spool.db"),
            audit_flush_interval_seconds=0.05)
    overrides.setdefault("dispatcher_enabled", False)
    app = create_app(make_config(tmp_path, terminal_driver="mock",
                                 log_dir=str(tmp_path / "logs"),
                                 **overrides))
    mount_console_ui(app, mode="agent")
    return app


def _client(app):
    from fastapi.testclient import TestClient
    return TestClient(app)


def _token(client):
    client.post("/api/v1/auth/bootstrap",
                json={"username": "alice", "password": PASSWORD})
    return client.post("/api/v1/auth/login", json={
        "username": "alice", "password": PASSWORD}).json()["access_token"]


def _h(t):
    return {"Authorization": f"Bearer {t}"}


# ── SY-01: clean-up without processing ──

def test_clean_up_runs_while_processing_is_off(tmp_path, data_dir):
    app = _app(tmp_path, dispatcher_enabled=False)
    with _client(app):
        assert app.state.dispatcher is None
        keeper = app.state.housekeeper
        assert keeper._thread is not None and keeper._thread.is_alive()
    assert not keeper._thread.is_alive()             # stopped with it


def test_housekeeper_runs_the_three_steps(tmp_path):
    from src.modules.queue.housekeeping import Housekeeper
    done = []
    queue = SimpleNamespace(
        purge_failed_passwords=lambda cutoff: done.append("pw") or 1)
    users = SimpleNamespace(
        purge_expired_sessions=lambda: done.append("sessions") or 0)
    cfg = SimpleNamespace(failed_password_retention_days=7,
                          evidence_retention_days=90,
                          evidence_dir=str(tmp_path / "evidence"))
    keeper = Housekeeper(queue, cfg, user_store=users,
                         busy=lambda: False)
    keeper.run_once()
    assert sorted(done) == ["pw", "sessions"]
    keeper.run_once()                                # rate-limited
    assert sorted(done) == ["pw", "sessions"]


def test_evidence_is_not_removed_during_a_transaction(tmp_path,
                                                      monkeypatch):
    from src.core import evidence
    from src.modules.queue.housekeeping import Housekeeper
    calls = []
    monkeypatch.setattr(evidence, "purge_expired_evidence",
                        lambda folder, days: calls.append(days) or [])
    cfg = SimpleNamespace(failed_password_retention_days=0,
                          evidence_retention_days=90,
                          evidence_dir=str(tmp_path))
    Housekeeper(None, cfg, busy=lambda: True).run_once()
    assert calls == []
    Housekeeper(None, cfg, busy=lambda: False).run_once()
    assert calls == [90]


def test_the_dispatcher_loop_no_longer_cleans_up():
    import inspect
    from src.modules.queue.dispatcher import Dispatcher
    loop = inspect.getsource(Dispatcher._loop)
    assert "_maybe_purge" not in loop
    # The methods remain for direct callers.
    assert hasattr(Dispatcher, "_maybe_purge_sessions")


# ── SY-02: rotation, one handle, filters ──

def test_service_log_rotates_daily_with_retention(tmp_path):
    from src.core.logging import TransactionLogger, attach_service_log
    handler = attach_service_log(tmp_path / "logs", retention_days=12)
    assert isinstance(handler, logging.handlers.TimedRotatingFileHandler)
    assert handler.when == "MIDNIGHT" and handler.backupCount == 12
    tl = TransactionLogger({"log_dir": str(tmp_path / "logs"),
                            "console_output": False})
    assert handler in tl.logger.handlers             # the same open file


def test_agent_console_log_is_capped(tmp_path):
    from desktop.runtime import rotate_agent_log
    log = tmp_path / "agent.log"
    log.write_bytes(b"x" * 2048)
    assert rotate_agent_log(log, max_bytes=1024) is True
    assert (tmp_path / "agent.log.1").stat().st_size == 2048
    assert not log.exists()
    assert rotate_agent_log(log, max_bytes=1024) is False


def test_log_view_filters(tmp_path, data_dir, monkeypatch):
    from desktop import system_api
    log = tmp_path / "service.log"
    log.write_text("\n".join([
        "2026-10-03 10:00:00 | INFO     | poll ok",
        "2026-10-03 10:00:01 | WARNING  | ticket SCTASK1 skipped",
        "2026-10-03 10:00:02 | ERROR    | ServiceNow fetch failed",
        "2026-10-03 10:00:03 | INFO     | password=Hunter22 used",
    ]), encoding="utf-8")
    app = _app(tmp_path)
    monkeypatch.setattr(system_api.runtime, "agent_log_path", lambda: log)
    with _client(app) as client:
        h = _h(_token(client))
        rows = client.get("/api/v1/system/logs?file=agent&level=WARNING",
                          headers=h).json()["lines"]
        assert len(rows) == 2 and "ERROR" in rows[1]
        rows = client.get("/api/v1/system/logs?file=agent&q=sctask",
                          headers=h).json()["lines"]
        assert rows == ["2026-10-03 10:00:01 | WARNING  | ticket SCTASK1 "
                        "skipped"]
        # The search runs on the masked text: a secret cannot be probed.
        assert client.get("/api/v1/system/logs?file=agent&q=hunter22",
                          headers=h).json()["lines"] == []


# ── SY-03: masking ──

@pytest.mark.parametrize("raw,masked", [
    ("login PW=Secret99 ok", "login PW=***** ok"),
    ("db_pw: hunter22", "db_pw: *****"),
    ("パスワードAbc12345 を設定", "パスワード***** を設定"),
    ("ＰＡＳＳＷＯＲＤ＝Ｓｅｃｒｅｔ９９", "PASSWORD=*****"),
    ('{"Content": "VaultPw#1", "UserName": "x"}',
     '{"Content": "*****", "UserName": "x"}'),
])
def test_more_forms_are_masked(raw, masked):
    from desktop.system_api import mask_secrets
    assert mask_secrets(raw) == masked


def test_secrets_in_use_are_masked_wherever_they_appear(monkeypatch):
    from desktop.system_api import mask_secrets
    monkeypatch.setenv("SNOW_PASSWORD", "Very$ecret-77")
    monkeypatch.setenv("FINESIII_API_KEYS", "snow:key-0123456789")
    text = mask_secrets("sent Very$ecret-77 and key-0123456789 to x")
    assert "Very$ecret-77" not in text and "key-0123456789" not in text


def test_tail_drops_the_cut_first_line_and_long_lines(tmp_path):
    from desktop.system_api import MAX_LINE_CHARS, _tail
    log = tmp_path / "x.log"
    log.write_text("A" * 9000 + "\n" + "\n".join(
        f"line {i}" for i in range(10)), encoding="utf-8")
    text = _tail(log, 3)
    assert text.splitlines() == ["line 7", "line 8", "line 9"]
    log.write_text("start\n" + "B" * (MAX_LINE_CHARS + 50),
                   encoding="utf-8")
    assert _tail(log, 5).endswith("...(cut)")


# ── SY-04: what holds work back ──

def test_status_names_the_gates(tmp_path, data_dir):
    app = _app(tmp_path, dispatcher_enabled=True)
    with _client(app) as client:
        h = _h(_token(client))
        s = client.get("/api/v1/system/status", headers=h).json()
        assert s["dispatcher"]["gate_open"] is True
        assert "accepting" in s["dispatcher"]
        assert s["availability"]["window"]
        assert s["email"] == {"enabled": False, "problem": "", "waiting": 0}
        r = client.post("/api/v1/system/cyberark/refresh-now", headers=h)
        assert r.status_code == 409                  # not in use here
        asked = []
        app.state.cyberark = SimpleNamespace(
            request_refresh=lambda: asked.append(1),
            status=lambda: {"available": True})
        r = client.post("/api/v1/system/cyberark/refresh-now", headers=h)
        assert r.status_code == 200 and asked == [1]


# ── SY-06 ──

def test_retention_settings_and_dead_switch():
    from config.base import BaseConfig
    from src.modules.console.settings_catalogue import BY_KEY
    assert "failed_password_retention_days" in BY_KEY
    assert "log_retention_days" in BY_KEY
    assert "ocr_log_text" not in BaseConfig.model_fields


def test_old_provision_without_a_password_is_not_retried(tmp_path,
                                                         data_dir):
    from src.modules.intake.models import ProcessingRequest
    app = _app(tmp_path)
    with _client(app) as client:
        h = _h(_token(client))
        store = app.state.queue_store
        req = ProcessingRequest(operation="provision",
                                affiliation_code="31234",
                                employee_code="8812399", source="api")
        store.enqueue(req)
        store.db.execute("UPDATE request_queue SET status = 'failed', "
                         "password = '' WHERE request_id = ?",
                         (req.request_id,))
        r = client.post(f"/api/v1/console/requests/{req.request_id}/retry",
                        headers=h)
        assert r.status_code == 409
        assert r.json()["detail"]["status"] == "password_expired"


# ── DR-04: lead time and the oldest waiting request ──

def test_lead_time_and_oldest_waiting(tmp_path, data_dir):
    from src.modules.console.metrics import compute_metrics
    rows = [{"status": "done", "result_code": "O-0000",
             "submitted_at": "2026-10-03T09:00:00+09:00",
             "completed_at": "2026-10-03T09:02:00+09:00",
             "duration_seconds": 60},
            {"status": "done", "result_code": "O-0000",
             "submitted_at": "2026-10-03T09:00:00+09:00",
             "completed_at": "2026-10-03T09:10:00+09:00",
             "duration_seconds": 60}]
    k = compute_metrics(rows, date(2026, 10, 3), date(2026, 10, 3))["kpis"]
    assert k["avg_lead_time_seconds"] == 360.0
    assert k["p95_lead_time_seconds"] == 600.0
    app = _app(tmp_path)
    with _client(app) as client:
        client.post("/api/v1/requests", json={
            "operation": "deprovision", "affiliation_code": "31234",
            "employee_code": "8812345"})
        q = app.state.queue_store.queue_depth()
        assert q["oldest_queued_at"]


# ── DR-05 / DR-06 / DR-07: the audit trail ──

def test_reports_say_protection_and_waiting_events(tmp_path, data_dir):
    app = _app(tmp_path, audit=True)
    with _client(app) as client:
        h = _h(_token(client))
        r = client.get("/api/v1/console/reports?period=today",
                       headers=h).json()
        assert r["protection"]["protected"] is False   # a local file
        assert r["pending_delivery"] is not None
        s = client.get("/api/v1/console/summary", headers=h).json()
        assert s["audit"]["enabled"] is True and "pending" in s["audit"]


def test_submitter_is_recorded_and_exported(tmp_path, data_dir):
    app = _app(tmp_path, audit=True)
    with _client(app) as client:
        h = _h(_token(client))
        r = client.post("/api/v1/console/requests", headers=h, json={
            "operation": "deprovision", "affiliation_code": "31234",
            "employee_code": "8812345", "ticket_id": "P6-AUDIT"})
        assert r.status_code == 202
        deadline = time.time() + 5
        events = []
        while time.time() < deadline and not events:
            events = [e for e in client.get(
                "/api/v1/console/audit/events?category=api&limit=50",
                headers=h).json()["events"]
                if e["action"] == "request_submitted"]
            _real_sleep(0.1)
        assert events[0]["detail"]["actor"] == "user:alice"
        csv_text = client.get(
            "/api/v1/console/export/audit?ticket_id=P6-AUDIT",
            headers=h).content.decode("utf-8")
        header, *lines = csv_text.lstrip("﻿").splitlines()
        for col in ("actor", "event_id", "transaction_id"):
            assert col in header.split(",")
        assert lines and all("P6-AUDIT" in line for line in lines)
        assert "user:alice" in lines[0]


def test_sqlite_audit_backend_is_not_protected():
    from src.modules.audit.trail_db import SQLiteAuditBackend
    assert SQLiteAuditBackend.protection(None)["protected"] is False


# ── The console page ──

def test_page_changes():
    js = (UI / "app.js").read_text(encoding="utf-8")
    kit = (UI / "ui-kit.js").read_text(encoding="utf-8")
    html = (UI / "index.html").read_text(encoding="utf-8")
    for mid in ("req-msg", "hi-msg", "au-msg", "us-msg", "rl-msg"):
        assert f'id="{mid}" role="status"' in html
    assert "function trapFocus(container)" in kit and "rowLabel" in kit
    assert "trapFocus($('viewer')); trapFocus($('wizard'));" in js
    assert "DASH_SIG" in js and "function processingCard(disp)" in js
    assert "'Refresh CyberArk now'" in js and "'Lead time'" in js
    assert 'id="log-level"' in html and 'id="log-q"' in html
    assert "Audit trail NOT protected" in js
