"""ServiceNow ticket selection fixes (fix list of 4 October 2026).

S-01  No hidden default: a blank Requested For is no filter; the group
      and Requested For in servicenow.yaml are not applied. Every
      ticket filter is optional (revised 6 October 2026).
S-02  Test connection counts the open tickets after each part of the
      selection and shows what the Requested For field holds.
S-03  Group mode: every fetched ticket is checked against the selection
      before anything is done with it (ServiceNow ignores a condition on
      a field that does not exist).
S-04  ';' separates Requested For names that contain a comma.
S-05  The ServiceNow stand-in ignores an unknown field like ServiceNow.
S-06  (revised 6 October 2026) A blank group is a filter not applied:
      it can be saved in either mode.
V-01  A locked account is told so at once."""
import os
import random
import time
from pathlib import Path

import pytest

from scripts.run_mock_snow_server import (
    GROUP, SAILPOINT_USER, TicketStore, create_mock_app, user_sys_id,
)
from src.integrations.servicenow.client import ServiceNowClient
from src.integrations.servicenow.config import (
    ServiceNowSettings, load_servicenow_config, split_requested_for,
)
from src.integrations.servicenow.connector import (
    ReportMemory, ServiceNowConnector,
)
from tests.conftest import make_config

PASSWORD = "CorrectHorse42"
BOT = "finesiii.bot"
ROOT = Path(__file__).resolve().parents[2]
APP = (ROOT / "desktop" / "ui" / "app.js").read_text(encoding="utf-8")


@pytest.fixture
def data_dir(tmp_path, monkeypatch):
    from desktop import vault
    d = tmp_path / "data"
    d.mkdir()
    monkeypatch.setenv("FINESIII_DATA_DIR", str(d))
    previous = vault._vault
    vault.use_vault(vault.MemoryVault())
    for k in vault.SECRET_KEYS:
        monkeypatch.delenv(k, raising=False)
    yield d
    vault.use_vault(previous)


@pytest.fixture
def mock_snow(monkeypatch):
    from tests.conftest import asgi_transport
    from src.integrations.servicenow import client as client_mod
    store = TicketStore(random.Random(11))
    store.bot = ""
    transport = asgi_transport(create_mock_app(store))
    original = client_mod.ServiceNowClient.__init__

    def init(self, *a, **kw):
        kw["transport"] = transport
        original(self, *a, **kw)
    monkeypatch.setattr(client_mod.ServiceNowClient, "__init__", init)
    return store


def _client(tmp_path):
    from fastapi.testclient import TestClient
    from desktop.server import mount_console_ui
    from src import create_app
    app = create_app(make_config(tmp_path, terminal_driver="mock",
                                 dispatcher_enabled=False,
                                 log_dir=str(tmp_path / "logs")))
    mount_console_ui(app, mode="agent")
    return TestClient(app)


def _h(client):
    client.post("/api/v1/auth/bootstrap",
                json={"username": "alice", "password": PASSWORD})
    t = client.post("/api/v1/auth/login", json={
        "username": "alice", "password": PASSWORD}).json()["access_token"]
    return {"Authorization": f"Bearer {t}"}


BODY = {"instance_url": "https://testserver", "auth_method": "basic",
        "username": "api.user", "password": "pw", "table": "sc_task",
        "assigned_to": BOT, "assignment_mode": "assignment_group",
        "assignment_group": GROUP}


def _seed(store):
    """3 SailPoint tasks and 1 whose requested item is for nobody, all
    unassigned in the group."""
    for _ in range(3):
        store.create_sailpoint("add", assigned_to="")
    return store.create_sailpoint("add", assigned_to="", requested_for="")


# ── S-01: no hidden default ──

def test_blank_requested_for_is_no_filter(monkeypatch):
    for k in ("SNOW_REQUESTED_FOR", "SNOW_ASSIGNMENT_GROUP"):
        monkeypatch.delenv(k, raising=False)
    s = load_servicenow_config()
    assert s.requested_for == [] and s.assignment_group == ""
    monkeypatch.setenv("SNOW_ASSIGNMENT_MODE", "assignment_group")
    monkeypatch.setenv("SNOW_ASSIGNMENT_GROUP", GROUP)
    s = load_servicenow_config()
    assert "requested_for" not in s.build_query()
    assert s.selection_fields() == ["assignment_group",
                                    "assignment_group.name"]
    monkeypatch.setenv("SNOW_REQUESTED_FOR", SAILPOINT_USER)
    s = load_servicenow_config()
    # Checked by the bot on each ticket, never in the query.
    assert "requested_for" not in s.build_query()
    assert "request.requested_for" in s.selection_fields()
    monkeypatch.setenv("SNOW_REQUESTED_FOR", "*")      # still no filter
    assert load_servicenow_config().requested_for == []


def test_settings_page_shows_no_default(tmp_path, data_dir, monkeypatch):
    for k in ("SNOW_REQUESTED_FOR", "SNOW_ASSIGNMENT_GROUP"):
        monkeypatch.delenv(k, raising=False)
    with _client(tmp_path) as client:
        h = _h(client)
        items = {s["key"]: s for s in client.get(
            "/api/v1/console/settings", headers=h).json()["settings"]}
        assert items["SNOW_REQUESTED_FOR"]["value"] in ("", None)
        assert items["SNOW_ASSIGNMENT_GROUP"]["value"] in ("", None)
        assert "Empty: no filter" in items["SNOW_REQUESTED_FOR"]["tooltip"]
    shipped = (ROOT / "config" / "servicenow.yaml").read_text(encoding="utf-8")
    if 'assignment_group: ""' not in shipped and "requested_for: []" not in shipped:
        # A server's own copy, which the updates keep: the package copy
        # (new installations) is the one checked here.
        pytest.skip("config/servicenow.yaml is this server's own copy")
    assert "requested_for: []" in shipped and 'assignment_group: ""' in shipped


# ── S-06 (revised): every filter optional ──

def test_every_filter_can_be_left_empty(tmp_path, data_dir, monkeypatch):
    monkeypatch.delenv("SNOW_ASSIGNMENT_GROUP", raising=False)
    with _client(tmp_path) as client:
        h = _h(client)
        assert client.put("/api/v1/console/settings", headers=h, json={
            "SNOW_ASSIGNMENT_MODE": "assignment_group"}).status_code == 200
        assert client.put("/api/v1/console/settings", headers=h, json={
            "SNOW_ASSIGNMENT_GROUP": GROUP}).status_code == 200
        assert client.put("/api/v1/console/settings", headers=h, json={
            "SNOW_ASSIGNMENT_GROUP": ""}).status_code == 200
    s = ServiceNowSettings(instance_url="https://x.service-now.com",
                           username=BOT, password="pw",
                           assignment_mode="assignment_group",
                           field_mapping={"ticket_number": "number"})
    assert s.validate()
    assert s.build_query() == "active=true^ORDERBYsys_created_on"


# ── S-04: names with a comma ──

def test_names_with_a_comma():
    assert split_requested_for("Admin, SailPoint;") == ["Admin, SailPoint"]
    assert split_requested_for("A; Admin, SailPoint") == ["A",
                                                         "Admin, SailPoint"]
    assert split_requested_for("a,b") == ["a", "b"]           # as before
    s = ServiceNowSettings(assignment_mode="assignment_group",
                           requested_for=["Admin, SailPoint", "Other"])
    assert s.requested_for_problems() == []
    # The name with a comma is matched as one name.
    assert not s.selection_mismatch({"request_item.requested_for": {
        "value": "f" * 32, "display_value": "Admin, SailPoint"}})
    assert s.selection_mismatch({"request_item.requested_for": {
        "value": "f" * 32, "display_value": "Admin"}})


def test_names_with_a_comma_are_saved_and_explained(tmp_path, data_dir,
                                                    mock_snow):
    comma = mock_snow.system_user("Admin, SailPoint", "sp.comma")
    with _client(tmp_path) as client:
        h = _h(client)
        r = client.put("/api/v1/console/settings", headers=h, json={
            "SNOW_ASSIGNMENT_MODE": "assignment_group",
            "SNOW_ASSIGNMENT_GROUP": GROUP,
            "SNOW_REQUESTED_FOR": "Admin, SailPoint;"})
        assert r.status_code == 200
        assert r.json()["changed"]["SNOW_REQUESTED_FOR"] == "Admin, SailPoint;"
        assert load_servicenow_config().requested_for == ["Admin, SailPoint"]
        # Typed with a comma only: split, and Test connection says why.
        d = client.post("/api/v1/system/test-servicenow", headers=h,
                        json=dict(BODY, requested_for="Admin, SailPoint")
                        ).json()
        assert "'Admin, SailPoint' is one user" in d["hint"]
        d = client.post("/api/v1/system/test-servicenow", headers=h,
                        json=dict(BODY, requested_for="Admin, SailPoint;")
                        ).json()
        assert d["requested_for"][0]["sys_id"] == comma
    assert "is one user" not in d["hint"]


# ── S-02: Test connection counts the selection ──

def test_connection_test_counts_each_step(tmp_path, data_dir, mock_snow):
    _seed(mock_snow)
    group_step = f"In the group '{GROUP}'"
    with _client(tmp_path) as client:
        h = _h(client)
        d = client.post("/api/v1/system/test-servicenow", headers=h,
                        json=dict(BODY, requested_for=SAILPOINT_USER)).json()
        counts = {c["step"]: c["count"] for c in d["selection_counts"]}
        assert counts[group_step] == 4
        assert counts["Unassigned or the bot account's"] == 4
        assert counts["Approved"] == 4
        # Checked by the bot in the three places: the fourth task's
        # requested item is for nobody.
        assert counts["Requested For"] == 3 and d["would_read"] == 3
        by = {c["step"]: c for c in d["selection_counts"]}
        assert by["Requested For"]["by"] == "bot"
        assert by["Requested For"]["of"] == 4
        values = {(v["field"], v["value"]): v["tickets"]
                  for v in d["requested_for_sample"]}
        assert values[("request_item.requested_for", SAILPOINT_USER)] == 3
        names = {f["name"]: f["value"] for f in d["filters"]}
        assert names["Assignment group"] == GROUP
        assert names["Requested For"].startswith(SAILPOINT_USER)
        # A field that holds the employee, not the requesting account.
        d = client.post("/api/v1/system/test-servicenow", headers=h,
                        json=dict(BODY, requested_for=SAILPOINT_USER,
                                  requested_for_field="request.requested_for")
                        ).json()
        counts = {c["step"]: c["count"] for c in d["selection_counts"]}
        assert counts["Requested For"] == 0
        assert "None of these tickets is requested for" in d["hint"]
        # A field that does not exist holds nothing: no ticket matches
        # (the bot reads the field itself, nothing is ignored).
        d = client.post("/api/v1/system/test-servicenow", headers=h,
                        json=dict(BODY, requested_for=SAILPOINT_USER,
                                  requested_for_field="request_item.u_rf")
                        ).json()
        counts = {c["step"]: c["count"] for c in d["selection_counts"]}
        assert counts["Requested For"] == 0
        # Nothing filled in: every open ticket of the table, with a note.
        d = client.post("/api/v1/system/test-servicenow", headers=h,
                        json=dict(BODY, assigned_to="", assignment_group="",
                                  requested_for="")).json()
        steps = [c["step"] for c in d["selection_counts"]]
        assert steps == ["Open tickets in the table", "Approved"]
        assert "every open ticket of the table is read" in d["hint"]
        assert all(f["value"] == "" for f in d["filters"]
                   if f["name"] != "Only approved requests")
    assert "requested_for_field: wizardValue('SNOW_REQUESTED_FOR_FIELD')" in APP
    assert "'Open tickets after each filter'" in APP


# ── S-03 / S-05: each ticket checked again ──

def _connector(store, **kw):
    from tests.conftest import asgi_transport
    s = load_servicenow_config()
    s.instance_url, s.username, s.password = "http://testserver", BOT, "pw"
    s.auth_method = "basic"
    s.assignment_mode = "assignment_group"
    s.assignment_group = GROUP
    s.respect_service_health = False
    for k, v in kw.items():
        setattr(s, k, v)
    client = ServiceNowClient(s, transport=asgi_transport(
        create_mock_app(store)), sleep_func=lambda _s: None)
    c = ServiceNowConnector(s, client=client)
    c.reported = ReportMemory()
    audit, submitted = [], []
    c.audit_hook = lambda e, d: audit.append((e, d))
    c._submit = lambda payload: submitted.append(payload["ticket_id"]) \
        or "queued"
    return c, audit, submitted


def test_stand_in_ignores_an_unknown_field():
    store = TicketStore(random.Random(3))
    store.bot = ""
    _seed(store)
    q = (f"assignment_group.name={GROUP}^request_item.u_rf.name=Nobody"
         f"^active=true")
    assert len(store.query(q)) == 4                    # condition ignored
    q = f"assignment_group.name={GROUP}^request.requested_for.name=Nobody"
    assert store.query(q) == []                         # known field


def test_tickets_outside_the_selection_are_left_alone():
    store = TicketStore(random.Random(5))
    store.bot = ""
    other = _seed(store)
    # The Requested For field does not exist: ServiceNow (and now the
    # stand-in) ignores the condition and returns all four tickets.
    c, audit, submitted = _connector(
        store, requested_for=[SAILPOINT_USER],
        requested_for_field="request_item.u_rf")
    stats = c.poll_once()
    assert stats["fetched"] == 4
    assert stats["out_of_selection"] == 4 and submitted == []
    for t in store.tickets:
        assert t.get("assigned_to", "") == ""        # nothing assigned
        assert not t.get("work_notes")                # nothing written
    assert [e for e, _d in audit
            if e == "servicenow_ticket_out_of_selection"]
    # No field entered: the three places are read - the three SailPoint
    # tickets, not the fourth.
    c, audit, submitted = _connector(store, requested_for=[SAILPOINT_USER])
    stats = c.poll_once()
    assert stats["out_of_selection"] == 1 and stats["fetched"] == 4
    assert other["number"] not in {n.split("/")[0] for n in submitted}
    assert len({n.split("/")[0] for n in submitted}) == 3



def test_skipped_ticket_is_reported_once():
    store = TicketStore(random.Random(17))
    store.bot = ""
    store.create_sailpoint("add", assigned_to="")
    c, audit, submitted = _connector(
        store, requested_for=[SAILPOINT_USER],
        requested_for_field="request_item.u_rf")
    for _ in range(3):
        assert c.poll_once()["out_of_selection"] == 1
    assert len([e for e, _d in audit
                if e == "servicenow_ticket_out_of_selection"]) == 1


def test_preview_says_why_a_ticket_is_skipped():
    store = TicketStore(random.Random(9))
    store.bot = ""
    _seed(store)
    c, audit, submitted = _connector(
        store, requested_for=[SAILPOINT_USER],
        requested_for_field="request_item.u_rf")
    stats = c.poll_once(dry_run=True)
    reasons = [t["reason"] for t in stats["tickets"]]
    assert len(reasons) == 4 and all(
        r.startswith("not in the selection: its Requested For (empty)")
        for r in reasons)
    assert audit == [] and submitted == []


def test_bot_account_mode_checks_the_filters_entered():
    store = TicketStore(random.Random(13))
    store.create_sailpoint("add")                     # routed to the bot
    c, audit, submitted = _connector(store, assignment_mode="assigned_to",
                                     assigned_to=BOT)
    stats = c.poll_once()
    assert stats["out_of_selection"] == 0 and stats["fetched"] == 1
    # The group entered is checked in this mode as well.
    assert c.s.selection_fields() == ["assignment_group",
                                      "assignment_group.name"]
    assert c.s.bot_ref == user_sys_id(BOT)            # looked up


# ── V-01, revised by D-07 (2026-10-05): a locked account answers like
# a wrong password, after the same wait ──

def test_locked_account_answers_like_a_wrong_password(tmp_path, monkeypatch):
    import logging
    from src.core.db import Database
    from src.modules.auth.services import AuthError, AuthService
    from src.modules.auth.store import UserStore
    monkeypatch.setattr(AuthService, "FAILURE_WAIT_MAX_SECONDS", 30)
    cfg = make_config(tmp_path)
    store = UserStore(Database.from_config(cfg))
    store.ensure_builtin_roles()
    auth = AuthService(store, cfg, logger=logging.getLogger("v01"))
    auth.bootstrap_admin("uatkate", "Lantern#4821x")
    for _ in range(5):
        while True:
            try:
                auth.authenticate("uatkate", "Wrong#4821x")
            except AuthError as e:
                if e.status_code == 429:
                    auth._failures["uatkate"][1] = time.monotonic() - 1
                    continue
                break
    with pytest.raises(AuthError) as e:
        auth.authenticate("uatkate", "Lantern#4821x")
    assert e.value.status_code == 429                  # the same wait
    auth._failures["uatkate"][1] = time.monotonic() - 1
    with pytest.raises(AuthError) as e:
        auth.authenticate("uatkate", "Lantern#4821x")
    assert e.value.status_code == 401
    assert str(e.value) == "Invalid username or password"
    assert store.get_by_username("uatkate").is_locked()
    # An account that is not locked still waits after a failure.
    user = store.get_by_username("uatkate")
    user.clear_lock()
    store.update(user)
    auth._failures.clear()
    with pytest.raises(AuthError):
        auth.authenticate("uatkate", "Wrong#4821x")
    with pytest.raises(AuthError) as e:
        auth.authenticate("uatkate", "Lantern#4821x")
    assert e.value.status_code == 429
