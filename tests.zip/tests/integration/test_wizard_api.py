"""Module setup wizard — the routes behind its pages (2026-09-26).

Real app + desktop extras. Pins the module status payload, each Test
button's failure reporting (no secret echoed, fast), the D16 rule on
the deployment write, and degraded start: a real-driver install with no
executor still serves the console and says why.
"""
import socket
import time

import pytest

from tests.conftest import make_config

PASSWORD = "CorrectHorse42"


@pytest.fixture
def data_dir(tmp_path, monkeypatch):
    d = tmp_path / "data"
    d.mkdir()
    monkeypatch.setenv("FINESIII_DATA_DIR", str(d))
    return d


@pytest.fixture
def memory_vault(monkeypatch):
    from desktop import vault
    previous = vault._vault
    store = vault.MemoryVault()
    vault.use_vault(store)
    for k in vault.SECRET_KEYS:
        monkeypatch.delenv(k, raising=False)
    for k in ("SNOW_ENABLED", "SNOW_INSTANCE_URL", "SNOW_USERNAME",
              "SMTP_HOST", "ALERT_FROM", "CYBERARK_ENABLED",
              "CYBERARK_BASE_URL", "CYBERARK_APP_ID", "CYBERARK_SAFE",
              "SMTP_ALERTS_ENABLED", "APP_ENV"):
        monkeypatch.delenv(k, raising=False)
    yield store
    vault.use_vault(previous)


def _client(tmp_path, **overrides):
    from fastapi.testclient import TestClient
    from desktop.server import mount_console_ui
    from src import create_app
    cfg = make_config(tmp_path, dispatcher_enabled=False,
                      terminal_driver="mock",
                      log_dir=str(tmp_path / "logs"), **overrides)
    app = create_app(cfg)
    mount_console_ui(app, mode="agent")
    return TestClient(app)


def _auth(t):
    return {"Authorization": f"Bearer {t}"}


def _admin(client):
    client.post("/api/v1/auth/bootstrap",
                json={"username": "alice", "password": PASSWORD})
    return client.post("/api/v1/auth/login", json={
        "username": "alice", "password": PASSWORD}).json()["access_token"]


def _dead_port():
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


class TestSetupModules:
    def test_module_status_reflects_stored_overrides(self, tmp_path, data_dir,
                                                     memory_vault):
        with _client(tmp_path) as client:
            token = _admin(client)
            s = client.get("/api/v1/system/setup", headers=_auth(token)).json()
            m = s["modules"]
            assert m["servicenow"] == {"enabled": False, "configured": False}
            assert m["cyberark"]["required"] is False       # mock driver
            assert m["finesiii"]["credential_source"] == "none"
            # Saving on the ServiceNow page (same route the wizard uses)
            # shows as configured BEFORE any restart.
            r = client.put("/api/v1/console/settings", headers=_auth(token),
                           json={"SNOW_INSTANCE_URL": "https://x.service-now.com",
                                 "SNOW_USERNAME": "bot", "SNOW_ENABLED": True,
                                 "SNOW_AUTH_METHOD": "basic"})
            assert r.status_code == 200, r.text
            # Configured needs the password as well (SN-04, 2026-10-03).
            m = client.get("/api/v1/system/setup",
                           headers=_auth(token)).json()["modules"]
            assert m["servicenow"] == {"enabled": True, "configured": False}
            r = client.put("/api/v1/system/secrets/SNOW_PASSWORD",
                           headers=_auth(token), json={"value": "pw"})
            assert r.status_code == 200, r.text
            m = client.get("/api/v1/system/setup",
                           headers=_auth(token)).json()["modules"]
            assert m["servicenow"] == {"enabled": True, "configured": True}

    def test_oauth_types_are_accepted_and_drive_configured(
            self, tmp_path, data_dir, memory_vault):
        with _client(tmp_path) as client:
            token = _admin(client)
            r = client.put("/api/v1/console/settings", headers=_auth(token),
                           json={"SNOW_AUTH_METHOD": "oauth_client_credentials",
                                 "SNOW_INSTANCE_URL": "https://x.service-now.com"})
            assert r.status_code == 200, r.text
            m = client.get("/api/v1/system/setup",
                           headers=_auth(token)).json()["modules"]
            assert m["servicenow"]["configured"] is False      # no client id yet
            client.put("/api/v1/console/settings", headers=_auth(token),
                       json={"SNOW_CLIENT_ID": "abc"})
            m = client.get("/api/v1/system/setup",
                           headers=_auth(token)).json()["modules"]
            # ... and its client secret (SN-04, 2026-10-03).
            assert m["servicenow"]["configured"] is False
            client.put("/api/v1/system/secrets/SNOW_CLIENT_SECRET",
                       headers=_auth(token), json={"value": "s3cret"})
            m = client.get("/api/v1/system/setup",
                           headers=_auth(token)).json()["modules"]
            assert m["servicenow"]["configured"] is True
            # The settings API now carries everything the UI renders.
            items = client.get("/api/v1/console/settings",
                               headers=_auth(token)).json()["settings"]
            auth = next(i for i in items if i["key"] == "SNOW_AUTH_METHOD")
            assert auth["choices"] == ["basic", "oauth_password",
                                       "oauth_client_credentials"]
            poll = next(i for i in items if i["key"] == "SNOW_POLL_SECONDS")
            assert poll["scale"] == 60 and poll["unit"] == "minutes"
            user = next(i for i in items if i["key"] == "SNOW_USERNAME")
            assert "oauth_password" in user["show_when"]["value"]
            r = client.put("/api/v1/console/settings", headers=_auth(token),
                           json={"SNOW_AUTH_METHOD": "saml"})
            assert r.status_code == 400

    def test_status_carries_module_and_problem_fields(self, tmp_path,
                                                      data_dir, memory_vault):
        with _client(tmp_path) as client:
            s = client.get("/api/v1/system/status",
                           headers=_auth(_admin(client))).json()
            assert s["startup_problems"] == []
            assert s["cyberark"] is None and "servicenow" in s


class TestConnectionTests:
    def test_mainframe(self, tmp_path, data_dir, memory_vault):
        with _client(tmp_path) as client:
            token = _admin(client)
            r = client.post("/api/v1/system/test-mainframe", json={},
                            headers=_auth(token)).json()
            assert r["ok"] is True and "note" in r         # no host configured
            t0 = time.time()
            r = client.post("/api/v1/system/test-mainframe",
                            json={"host": "127.0.0.1", "port": _dead_port()},
                            headers=_auth(token)).json()
            assert r["ok"] is False and r["hint"]
            assert time.time() - t0 < 10

    def test_servicenow_requires_fields_and_reports_unreachable(
            self, tmp_path, data_dir, memory_vault):
        with _client(tmp_path) as client:
            token = _admin(client)
            r = client.post("/api/v1/system/test-servicenow", json={},
                            headers=_auth(token)).json()
            assert r["ok"] is False and "required" in r["error"]
            t0 = time.time()
            r = client.post("/api/v1/system/test-servicenow", json={
                "instance_url": f"http://127.0.0.1:{_dead_port()}",
                "username": "bot", "password": "pw-secret"},
                headers=_auth(token)).json()
            assert r["ok"] is False and r["error"]
            assert "pw-secret" not in str(r)
            assert time.time() - t0 < 20

    def test_email_validation_and_unreachable_host(self, tmp_path, data_dir,
                                                   memory_vault):
        with _client(tmp_path) as client:
            token = _admin(client)
            r = client.post("/api/v1/system/test-email", json={"to": "x"},
                            headers=_auth(token)).json()
            assert r["ok"] is False
            t0 = time.time()
            r = client.post("/api/v1/system/test-email", json={
                "to": "ops@example.com", "host": "127.0.0.1",
                "port": _dead_port(), "from": "bot@example.com",
                "password": "smtp-secret"}, headers=_auth(token)).json()
            assert r["ok"] is False and r["error"]
            assert "smtp-secret" not in str(r)
            assert time.time() - t0 < 20

    def test_cyberark_reports_validation_and_never_a_value(self, tmp_path,
                                                          data_dir,
                                                          memory_vault):
        with _client(tmp_path) as client:
            token = _admin(client)
            r = client.post("/api/v1/system/test-cyberark",
                            json={"base_url": "https://vault.example"},
                            headers=_auth(token)).json()
            assert r["ok"] is False and "app_id" in r["error"]
            r = client.post("/api/v1/system/test-cyberark", json={
                "base_url": f"http://127.0.0.1:{_dead_port()}",
                "app_id": "A", "safe": "S", "object_name": "O",
                "verify_tls": False}, headers=_auth(token)).json()
            # The password length is never returned (X-08, 2026-10-03).
            assert r["ok"] is False and r["retrieved"] is False
            assert "password_length" not in r
            assert set(r) >= {"available", "error", "hint"}


class TestRequireCyberArkOnDeployment:
    def test_production_real_driver_needs_cyberark(self, tmp_path, data_dir,
                                                   memory_vault, monkeypatch):
        # The deployment rules, not this machine's drivers (2026-09-28).
        from desktop import deployment
        monkeypatch.setattr(deployment, "driver_problem", lambda d: "")
        with _client(tmp_path) as client:
            token = _admin(client)
            body = {"APP_ENV": "production", "TERMINAL_DRIVER": "pywinauto",
                    "OCR_ENABLED": "true"}
            r = client.put("/api/v1/system/deployment", headers=_auth(token),
                           json=body)
            assert r.status_code == 400 and "CyberArk" in r.json()["detail"]
            # Enabling the module (stored, not yet restarted) unblocks it.
            client.put("/api/v1/console/settings", headers=_auth(token),
                       json={"CYBERARK_ENABLED": True})
            r = client.put("/api/v1/system/deployment", headers=_auth(token),
                           json=body)
            assert r.status_code == 200, r.text
            # Development never needs it.
            r = client.put("/api/v1/system/deployment", headers=_auth(token),
                           json={"APP_ENV": "development",
                                 "TERMINAL_DRIVER": "pywinauto",
                                 "OCR_ENABLED": "true"})
            assert r.status_code == 200


class TestDegradedStart:
    def test_real_driver_without_executor_still_serves_the_console(
            self, tmp_path, data_dir, memory_vault, monkeypatch):
        """On this machine pywinauto is absent and no credentials are
        set: a server would refuse to start; the desktop agent starts in
        API-only mode and reports why, so the setup can be finished."""
        from fastapi.testclient import TestClient
        from desktop.server import mount_console_ui
        from src import create_app
        for k in ("FINESIII_AFFILIATION_CODE", "FINESIII_APPLICATION_ID",
                  "FINESIII_PASSWORD"):
            monkeypatch.delenv(k, raising=False)
        cfg = make_config(tmp_path, dispatcher_enabled=True,
                          terminal_driver="pywinauto", require_cyberark=True,
                          log_dir=str(tmp_path / "logs"))
        with pytest.raises(Exception):
            create_app(cfg)                       # server posture: fail fast
        object.__setattr__(cfg, "startup_degraded_mode", True)
        app = create_app(cfg)
        assert app.state.dispatcher is None
        problems = app.state.startup_problems
        assert any("executor" in p.lower() for p in problems)
        assert any("CyberArk" in p for p in problems)     # D16
        mount_console_ui(app, mode="agent")
        with TestClient(app) as client:
            token = _admin(client)
            s = client.get("/api/v1/system/status", headers=_auth(token)).json()
            assert len(s["startup_problems"]) == 2
            setup = client.get("/api/v1/system/setup", headers=_auth(token)).json()
            assert setup["modules"]["cyberark"]["required"] is True
            # Intake still works — requests queue up for later.
            assert client.post("/api/v1/requests", json={
                "operation": "provision", "affiliation_code": "30822",
                "employee_code": "1217036", "password": "FUJI@33F"}
            ).status_code == 202


class TestSnowPoller:
    def test_idles_when_disabled_records_errors_when_misconfigured(
            self, tmp_path, data_dir, memory_vault, monkeypatch):
        from desktop.snow_poller import ServiceNowPoller, _first_api_key
        from src import create_app
        monkeypatch.setenv("FINESIII_API_KEYS", "installer:k-1,other:k-2")
        assert _first_api_key() == "k-1"
        cfg = make_config(tmp_path, dispatcher_enabled=False,
                          terminal_driver="mock",
                          log_dir=str(tmp_path / "logs"))
        app = create_app(cfg)
        poller = ServiceNowPoller(app, "http://127.0.0.1:1")
        poller.DISABLED_CHECK_SECONDS = 0.05
        poller.ERROR_BACKOFF_SECONDS = 0.05
        monkeypatch.setenv("SNOW_ENABLED", "false")
        poller.start()
        try:
            time.sleep(0.2)
            st = poller.status()
            assert st["running"] and st["polls"] == 0 and st["enabled"] is False
            # Enabled through the console store (hot) but not configured:
            # every cycle is recorded as "Not configured" and the thread
            # survives. It is not a ServiceNow outage (UAT-10, 2026-10-04).
            app.state.settings_store.set("SNOW_ENABLED", "true")
            deadline = time.time() + 5
            while time.time() < deadline and not poller.status()["last_error"]:
                time.sleep(0.05)
            st = poller.status()
            assert st["enabled"] is True
            assert st["last_error"].startswith("Not configured: ")
            assert st["running"] and st["not_configured"] is True
            assert st["consecutive_errors"] == 0
        finally:
            t0 = time.time()
            poller.stop()
            assert time.time() - t0 < 5
