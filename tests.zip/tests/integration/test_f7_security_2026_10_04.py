"""F7 of the fix plan (2026-10-04): security hardening.

SEC-01  A red System page notice while the request API is open on a
        real terminal driver.
SEC-02  The audit trail is on by default for the installed service
        (SQLite without an audit database); a notice when it is off.
SEC-03  The account whose credential store is used is shown; a start as
        another account is reported, and can be accepted.
SEC-04  Browser security headers; no inline handlers on the page.
SEC-05  Locked until / Unlock on Users; a wait after each failed
        sign-in; an alert line when an account is locked.
SEC-06  The set-up script creates a one-time administrator password and
        shows it once; a notice while the seeded password is unchanged.
SEC-07  Password history (last 5), no username in the password,
        optional expiry (off by default).
SEC-08  The database password goes to the credential store unless the
        settings file is explicitly chosen and confirmed.
UAT-L22 Secrets are masked before a long log line is cut; replaced
        secret values stay masked.
UAT-L27 No default password for new accounts."""
import json
import logging
import re
import sys
import time
from datetime import timedelta
from pathlib import Path
from types import SimpleNamespace

import pytest

from tests.conftest import make_config

PASSWORD = "CorrectHorse42"
ROOT = Path(__file__).resolve().parents[2]
APP = (ROOT / "desktop" / "ui" / "app.js").read_text(encoding="utf-8")
INDEX = (ROOT / "desktop" / "ui" / "index.html").read_text(encoding="utf-8")


@pytest.fixture
def data_dir(tmp_path, monkeypatch):
    from desktop import vault
    d = tmp_path / "data"
    d.mkdir()
    monkeypatch.setenv("FINESIII_DATA_DIR", str(d))
    previous = vault._vault
    vault.use_vault(vault.MemoryVault())
    yield d
    vault.use_vault(previous)


@pytest.fixture
def waits(monkeypatch):
    """The wait after a failed sign-in, as in production."""
    from src.modules.auth.services import AuthService
    monkeypatch.setattr(AuthService, "FAILURE_WAIT_MAX_SECONDS", 30)


def _app(tmp_path, **overrides):
    from desktop.server import mount_console_ui
    from src import create_app
    opts = dict(terminal_driver="mock", ocr_enabled=False,
                log_dir=str(tmp_path / "logs"),
                sqlite_path=str(tmp_path / "shared.db"))
    opts.update(overrides)
    app = create_app(make_config(tmp_path, **opts))
    mount_console_ui(app, mode="agent", stop_hook=lambda: None)
    return app


def _client(app):
    from fastapi.testclient import TestClient
    return TestClient(app)


def _h(client, first=True, username="alice", password=PASSWORD):
    if first:
        client.post("/api/v1/auth/bootstrap",
                    json={"username": username, "password": password})
    t = client.post("/api/v1/auth/login", json={
        "username": username, "password": password}).json()["access_token"]
    return {"Authorization": f"Bearer {t}"}


def _security(client, h):
    return {n["code"]: n for n in client.get(
        "/api/v1/system/status", headers=h).json()["security"]}


class _Recorder:
    def __init__(self):
        self.events = []

    def event(self, category, action, **kw):
        self.events.append((category, action, kw))

    def actions(self):
        return [a for _, a, _ in self.events]


def _auth(tmp_path, **cfg_overrides):
    from src.core.db import Database
    from src.modules.auth.services import AuthService
    from src.modules.auth.store import UserStore
    from src.modules.console.settings_store import SettingsStore
    cfg = make_config(tmp_path, **cfg_overrides)
    db = Database.from_config(cfg)
    store = UserStore(db)
    store.ensure_builtin_roles()
    service = AuthService(store, cfg, logger=logging.getLogger("f7test"))
    service.audit = _Recorder()
    service.settings = SettingsStore(db)
    service.bootstrap_admin("alice", PASSWORD)
    return service


# ── SEC-04: security headers ──

def test_every_answer_carries_the_security_headers(tmp_path, data_dir):
    from src.core.security_headers import CONTENT_SECURITY_POLICY
    with _client(_app(tmp_path)) as client:
        for path in ("/", "/app.js", "/api/v1/auth/status"):
            r = client.get(path)
            assert r.status_code == 200, path
            assert r.headers["content-security-policy"] == \
                CONTENT_SECURITY_POLICY
            assert "frame-ancestors 'none'" in CONTENT_SECURITY_POLICY
            assert "script-src 'self';" in CONTENT_SECURITY_POLICY
            assert r.headers["x-content-type-options"] == "nosniff"
            assert r.headers["referrer-policy"] == "no-referrer"
            assert r.headers["x-frame-options"] == "DENY"
        # API answers are not kept in the browser cache; the page files
        # keep their own "no-cache" (revalidated, still cached).
        assert client.get("/api/v1/auth/status").headers[
            "cache-control"] == "no-store"
        assert client.get("/app.js").headers["cache-control"] == "no-cache"
        # Refusals carry them too.
        r = client.get("/api/v1/system/status")
        assert r.status_code == 401
        assert r.headers["x-frame-options"] == "DENY"


def test_api_description_pages_have_no_policy(tmp_path, data_dir):
    """The development-only API pages load their page from a CDN."""
    with _client(_app(tmp_path, debug=True, auth_enabled=False)) as client:
        r = client.get("/api/docs")
        assert r.status_code == 200
        assert "content-security-policy" not in r.headers
        assert r.headers["x-content-type-options"] == "nosniff"


def test_page_has_no_inline_script_or_handler():
    assert not re.search(r"\son[a-z]+\s*=", INDEX)
    for m in re.finditer(r"<script([^>]*)>(.*?)</script>", INDEX, re.S):
        assert "src=" in m.group(1) and not m.group(2).strip()
    assert "addEventListener('submit', e => e.preventDefault())" in APP
    assert set(re.findall(r"\?v=([0-9.a-z]+)", INDEX)) == {"2026.10.06"}


# ── SEC-05: wait after failures, lockout, unlock ──

def test_wait_after_a_failed_sign_in(tmp_path, waits):
    from src.modules.auth.services import AuthError
    auth = _auth(tmp_path)
    with pytest.raises(AuthError) as e:
        auth.authenticate("alice", "wrong-password-1")
    assert e.value.status_code == 401
    # Even the right password is not looked at during the wait.
    with pytest.raises(AuthError) as e:
        auth.authenticate("alice", PASSWORD)
    assert e.value.status_code == 429 and e.value.retry_after == 2
    assert "Wait 2 second(s)" in str(e.value)
    with pytest.raises(AuthError):
        auth.authenticate("alice", PASSWORD)
    # Recorded once per wait, not for every refused attempt.
    assert auth.audit.actions().count("login_throttled") == 1
    # The count is not raised by the refused attempts.
    assert auth.store.get_by_username("alice").failed_attempts == 1
    # After the wait the password is checked again; success clears it.
    auth._failures["alice"][1] = time.monotonic() - 1
    token, user = auth.authenticate("alice", PASSWORD)
    assert token and "alice" not in auth._failures
    # The wait grows with each failure in a row: 2, 4, 8, 16, 30 s.
    for expected in (2, 4, 8):
        with pytest.raises(AuthError):
            auth.authenticate("alice", "wrong-password-1")
        assert auth._wait_left("alice") == expected
        auth._failures["alice"][1] = time.monotonic() - 1


def test_unknown_names_wait_the_same(tmp_path, waits):
    from src.modules.auth.services import AuthError
    auth = _auth(tmp_path)
    with pytest.raises(AuthError) as e:
        auth.authenticate("nobody", "x")
    assert e.value.status_code == 401
    with pytest.raises(AuthError) as e:
        auth.authenticate("NoBody ", "x")
    assert e.value.status_code == 429


def test_the_sign_in_route_says_how_long_to_wait(tmp_path, data_dir, waits):
    with _client(_app(tmp_path)) as client:
        _h(client)
        client.post("/api/v1/auth/login",
                    json={"username": "alice", "password": "nope-nope-1"})
        r = client.post("/api/v1/auth/login",
                        json={"username": "alice", "password": PASSWORD})
        assert r.status_code == 429
        assert r.headers["retry-after"] == "2"
        assert "Wait 2 second(s)" in r.json()["detail"]


def test_lockout_is_reported_and_audited(tmp_path, caplog):
    from src.modules.auth.services import AuthError
    auth = _auth(tmp_path)
    with caplog.at_level(logging.ERROR, logger="f7test"):
        for _ in range(5):
            with pytest.raises(AuthError):
                auth.authenticate("alice", "wrong-password-1")
    assert auth.store.get_by_username("alice").is_locked()
    assert "account_locked" in auth.audit.actions()
    errors = [r.getMessage() for r in caplog.records
              if r.levelno == logging.ERROR]
    assert len(errors) == 1
    assert "Console account 'alice' was locked after 5 failed" in errors[0]
    assert "unlock it on the Users page" in errors[0]


def test_lockout_alert_can_be_switched_off(tmp_path, caplog):
    from src.modules.auth.services import AuthError
    auth = _auth(tmp_path, auth_lockout_alert=False)
    with caplog.at_level(logging.ERROR, logger="f7test"):
        for _ in range(5):
            with pytest.raises(AuthError):
                auth.authenticate("alice", "wrong-password-1")
    assert not [r for r in caplog.records if r.levelno == logging.ERROR]
    assert "account_locked" in auth.audit.actions()


def test_users_list_shows_the_lock_and_unlock_lifts_it(tmp_path, data_dir):
    with _client(_app(tmp_path)) as client:
        h = _h(client)
        r = client.post("/api/v1/admin/users", headers=h, json={
            "username": "uatbob", "role": "viewer",
            "password": "Temporary#4821x"})
        uid = r.json()["user"]["user_id"]
        for _ in range(5):
            client.post("/api/v1/auth/login", json={
                "username": "uatbob", "password": "wrong-password-1"})
        users = {u["username"]: u for u in client.get(
            "/api/v1/admin/users", headers=h).json()["users"]}
        assert users["uatbob"]["locked"] is True
        assert users["uatbob"]["locked_until"]
        # Locked: the same answer as a wrong password (D-07).
        assert client.post("/api/v1/auth/login", json={
            "username": "uatbob",
            "password": "Temporary#4821x"}).status_code == 401
        r = client.post(f"/api/v1/admin/users/{uid}/unlock", headers=h)
        assert r.status_code == 200 and r.json()["status"] == "unlocked"
        assert r.json()["user"]["locked"] is False
        assert client.post("/api/v1/auth/login", json={
            "username": "uatbob",
            "password": "Temporary#4821x"}).status_code == 200
        # A second unlock has nothing to lift.
        assert client.post(f"/api/v1/admin/users/{uid}/unlock",
                           headers=h).json()["status"] == "not locked"
        assert client.post("/api/v1/admin/users/usr_missing/unlock",
                           headers=h).status_code == 404


def test_unlock_needs_user_management(tmp_path, data_dir):
    with _client(_app(tmp_path)) as client:
        h = _h(client)
        uid = client.post("/api/v1/admin/users", headers=h, json={
            "username": "uatcarl", "role": "viewer",
            "password": "Temporary#4821x"}).json()["user"]["user_id"]
        t = client.post("/api/v1/auth/login", json={
            "username": "uatcarl",
            "password": "Temporary#4821x"}).json()["access_token"]
        client.post("/api/v1/auth/password",
                    headers={"Authorization": f"Bearer {t}"},
                    json={"current_password": "Temporary#4821x",
                          "new_password": "ViewerOwn#4821"})
        hv = _h(client, first=False, username="uatcarl",
                password="ViewerOwn#4821")
        assert client.post(f"/api/v1/admin/users/{uid}/unlock",
                           headers=hv).status_code == 403


def test_unlock_is_audited(tmp_path):
    from src.modules.auth.routes import build_auth_router
    auth = _auth(tmp_path)
    recorder = _Recorder()
    from fastapi import FastAPI
    from fastapi.testclient import TestClient
    app = FastAPI()
    app.include_router(build_auth_router(auth, auth.store, auth.cfg,
                                         audit=recorder))
    with TestClient(app) as client:
        t = client.post("/api/v1/auth/login", json={
            "username": "alice", "password": PASSWORD}).json()["access_token"]
        user = auth.store.get_by_username("alice")
        user.lock_for(600)
        auth.store.update(user)
        r = client.post(f"/api/v1/admin/users/{user.user_id}/unlock",
                        headers={"Authorization": f"Bearer {t}"})
        assert r.status_code == 200
    (cat, action, kw), = [e for e in recorder.events
                          if e[1] == "user_unlocked"]
    assert kw["actor"] == "alice" and kw["severity"] == "WARNING"
    assert kw["detail"]["was_locked_until"] and kw["detail"]["changed"]


def test_users_page_has_locked_until_and_unlock():
    assert "'Locked until ' + fmtTime(u.locked_until)" in APP
    assert "'/admin/users/' + u.user_id + '/unlock'" in APP


# ── SEC-07: password rules ──

def test_password_may_not_contain_the_username(tmp_path):
    from src.modules.auth.models import password_problems
    from src.modules.auth.services import AuthError
    assert "must not contain the username" in password_problems(
        "MyAlice#Pass42", 12, username="alice")
    assert password_problems("MyAl1ce#Pass42", 12, username="alice") == []
    # A name under 3 characters is not checked.
    assert password_problems("MyAbPass#4821", 12, username="ab") == []
    auth = _auth(tmp_path)
    user = auth.store.get_by_username("alice")
    with pytest.raises(AuthError) as e:
        auth.change_password(user, PASSWORD, "NewALICEpass42")
    assert e.value.status_code == 400
    assert "must not contain the username" in str(e.value)
    with pytest.raises(AuthError):
        auth.bootstrap_admin("bootadmin", "Bootadmin#4821")


def test_admin_set_passwords_follow_the_username_rule(tmp_path, data_dir):
    with _client(_app(tmp_path)) as client:
        h = _h(client)
        r = client.post("/api/v1/admin/users", headers=h, json={
            "username": "uatdina", "role": "viewer",
            "password": "UatDina#48213"})
        assert r.status_code == 400
        assert "must not contain the username" in r.json()["detail"]
        uid = client.post("/api/v1/admin/users", headers=h, json={
            "username": "uatdina", "role": "viewer",
            "password": "Temporary#4821x"}).json()["user"]["user_id"]
        r = client.patch(f"/api/v1/admin/users/{uid}", headers=h,
                         json={"password": "xxUATDINAxx#4821"})
        assert r.status_code == 400


def test_recent_passwords_are_refused(tmp_path):
    from src.modules.auth.services import AuthError
    auth = _auth(tmp_path)
    user = auth.store.get_by_username("alice")
    passwords = [PASSWORD, "SecondPass#4821", "ThirdPass#4821",
                 "FourthPass#4821", "FifthPass#4821"]
    for old, new in zip(passwords, passwords[1:]):
        auth.change_password(auth.store.get_by_username("alice"), old, new)
    user = auth.store.get_by_username("alice")
    # The first password is the fifth from now: still remembered.
    with pytest.raises(AuthError) as e:
        auth.change_password(user, passwords[-1], PASSWORD)
    assert e.value.status_code == 400
    assert "last 5 passwords" in str(e.value)
    assert "password_change_failed" in auth.audit.actions()
    # A sixth change pushes it out.
    auth.change_password(user, passwords[-1], "SixthPass#4821")
    auth.change_password(auth.store.get_by_username("alice"),
                         "SixthPass#4821", PASSWORD)
    # Only hashes are kept, in the settings table, at most 5.
    raw = auth.settings.all()[f"PASSWORD_HISTORY_{user.user_id}"]
    entries = json.loads(raw)
    assert len(entries) == 5
    assert all(set(e) == {"h", "s", "at"} for e in entries)
    assert PASSWORD not in raw


def test_history_of_zero_only_refuses_the_current_one(tmp_path):
    from src.modules.auth.services import AuthError
    auth = _auth(tmp_path, auth_password_history=0)
    user = auth.store.get_by_username("alice")
    auth.change_password(user, PASSWORD, "SecondPass#4821")
    user = auth.store.get_by_username("alice")
    with pytest.raises(AuthError):
        auth.change_password(user, "SecondPass#4821", "SecondPass#4821")
    auth.change_password(user, "SecondPass#4821", PASSWORD)


def test_history_is_removed_with_the_account(tmp_path, data_dir):
    with _client(_app(tmp_path)) as client:
        h = _h(client)
        uid = client.post("/api/v1/admin/users", headers=h, json={
            "username": "uateve", "role": "viewer",
            "password": "Temporary#4821x"}).json()["user"]["user_id"]
        store = client.app.state.settings_store
        assert f"PASSWORD_HISTORY_{uid}" in store.all()
        assert client.delete(f"/api/v1/admin/users/{uid}",
                             headers=h).status_code == 200
        assert f"PASSWORD_HISTORY_{uid}" not in store.all()


def test_expiry_is_off_by_default_and_works_when_set(tmp_path):
    from src.modules.auth.models import now_jst
    auth = _auth(tmp_path)
    assert auth.max_age_days == 0
    user = auth.store.get_by_username("alice")
    key = f"PASSWORD_HISTORY_{user.user_id}"
    old = json.loads(auth.settings.all()[key])
    old[0]["at"] = (now_jst() - timedelta(days=400)).isoformat()
    auth.settings.set(key, json.dumps(old))
    _, user = auth.authenticate("alice", PASSWORD)
    assert user.must_change_password is False
    auth.max_age_days = 90
    _, user = auth.authenticate("alice", PASSWORD)
    assert user.must_change_password is True
    assert "password_expired" in auth.audit.actions()
    # Changing it clears the requirement and starts the count again.
    auth.change_password(user, PASSWORD, "Renewed#Pass4821")
    _, user = auth.authenticate("alice", "Renewed#Pass4821")
    assert user.must_change_password is False


def test_rules_are_start_up_settings():
    from config.base import BaseConfig
    from desktop import deployment
    for key in ("AUTH_PASSWORD_HISTORY", "AUTH_PASSWORD_MAX_AGE_DAYS",
                "AUTH_LOCKOUT_ALERT"):
        assert deployment.BY_KEY[key]["group"] == "Security"
    cfg = BaseConfig(_env_file=None)
    assert (cfg.auth_password_history, cfg.auth_password_max_age_days,
            cfg.auth_lockout_alert) == (5, 0, True)
    with pytest.raises(Exception):
        BaseConfig(_env_file=None, auth_password_history=25)
    with pytest.raises(Exception):
        BaseConfig(_env_file=None, auth_password_max_age_days=-1)


# ── SEC-01 / 02 / 03 / 06: System page notices ──

def test_open_request_api_on_a_real_driver_is_red(tmp_path, data_dir):
    app = _app(tmp_path)
    with _client(app) as client:
        h = _h(client)
        # Mock driver: shown as a warning (D-01, 2026-10-05).
        assert _security(client, h)["intake_open"]["level"] == "warning"
        object.__setattr__(app.state.config, "terminal_driver", "pywinauto")
        notice = _security(client, h)["intake_open"]
        assert notice["level"] == "danger"
        assert "without an API key" in notice["text"]
        object.__setattr__(app.state.config, "auth_enabled", True)
        assert "intake_open" not in _security(client, h)


def test_audit_off_is_reported(tmp_path, data_dir):
    with _client(_app(tmp_path)) as client:
        h = _h(client)
        assert "Audit event trail" in _security(client, h)["audit_off"]["text"]
    with _client(_app(tmp_path / "b", audit_enabled=True,
                      audit_backend="sqlite")) as client:
        h = _h(client)
        assert "audit_off" not in _security(client, h)


def test_installed_service_turns_the_audit_trail_on(tmp_path, monkeypatch):
    from config.base import BaseConfig
    from desktop.deployment import apply_service_defaults, effective_value
    for name in ("AUDIT_ENABLED", "AUDIT_BACKEND", "AUDIT_DATABASE_URL"):
        monkeypatch.delenv(name, raising=False)
    cfg = apply_service_defaults(BaseConfig(_env_file=None))
    assert cfg.audit_enabled is True and cfg.audit_backend == "sqlite"
    assert cfg.startup_degraded_mode is True
    # The This machine page shows what is in force.
    monkeypatch.setenv("FINESIII_DATA_DIR", str(tmp_path))
    assert effective_value("AUDIT_ENABLED", cfg) == "true"
    # A value set anywhere wins.
    monkeypatch.setenv("AUDIT_ENABLED", "false")
    cfg = apply_service_defaults(BaseConfig(_env_file=None))
    assert cfg.audit_enabled is False
    monkeypatch.delenv("AUDIT_ENABLED")
    env = tmp_path / "x.env"
    env.write_text("AUDIT_DATABASE_URL=postgresql://a@db:5432/audit\n")
    cfg = apply_service_defaults(BaseConfig(_env_file=str(env)))
    assert cfg.audit_enabled is True and cfg.audit_backend == "postgres"
    # The troubleshooting start keeps failing fast.
    cfg = apply_service_defaults(BaseConfig(_env_file=None), degraded=False)
    assert cfg.startup_degraded_mode is False and cfg.audit_enabled is True


def test_a_restart_keeps_the_service_posture(monkeypatch):
    import config
    from config.base import BaseConfig
    from desktop.server import EmbeddedService
    for name in ("AUDIT_ENABLED", "AUDIT_BACKEND", "AUDIT_DATABASE_URL"):
        monkeypatch.delenv(name, raising=False)
    fresh = BaseConfig(_env_file=None)
    fake = lambda: fresh                                   # noqa: E731
    fake.cache_clear = lambda: None
    monkeypatch.setattr(config, "get_config", fake)
    cfg = EmbeddedService._fresh_process_config()
    assert cfg.startup_degraded_mode is True and cfg.audit_enabled is True


def test_start_as_another_account_is_reported(tmp_path, data_dir,
                                              monkeypatch):
    from desktop import system_api, vault
    app = _app(tmp_path)
    store = app.state.settings_store
    me = vault.store_account()
    assert me and store.all()[system_api.SERVICE_ACCOUNT_KEY] == me
    with _client(app) as client:
        h = _h(client)
        assert client.get("/api/v1/system/status", headers=h).json()[
            "vault"]["account"] == me
        assert "account_changed" not in _security(client, h)
        store.set(system_api.SERVICE_ACCOUNT_KEY, "CORP\\uat.botacct")
        text = _security(client, h)["account_changed"]["text"]
        assert f"runs as {me}" in text and "CORP\\uat.botacct" in text
        r = client.post("/api/v1/system/service-account/accept", headers=h)
        assert r.status_code == 200 and r.json()["account"] == me
        assert "account_changed" not in _security(client, h)
    assert "'Stored for Windows account: '" in APP
    assert "'/system/service-account/accept'" in APP


def test_seeded_administrator_is_reported_until_changed(tmp_path, data_dir):
    """Read by another administrator: the seeded account itself can do
    nothing but change its password."""
    from src.modules.auth.models import AppUser
    app = _app(tmp_path, auth_seed_default_admin=True)
    other = AppUser(username="uatfrank", role="admin", created_by="test")
    other.set_password("Frank#Own48213")
    app.state.user_store.create(other)
    with _client(app) as client:
        h = _h(client, first=False, username="uatfrank",
               password="Frank#Own48213")
        notice = _security(client, h)["initial_admin"]
        assert notice["level"] == "warning"
        assert "'admin' has not chosen its own password yet" in notice["text"]
        assert "published default" in notice["text"]
        # A password reset by another administrator: still reported, but
        # it is not the published default.
        admin_id = app.state.user_store.get_by_username("admin").user_id
        assert client.patch(f"/api/v1/admin/users/{admin_id}", headers=h,
                            json={"password": "Reset#Given4821"}
                            ).status_code == 200
        text = _security(client, h)["initial_admin"]["text"]
        assert "published default" not in text
        t = client.post("/api/v1/auth/login", json={
            "username": "admin",
            "password": "Reset#Given4821"}).json()["access_token"]
        assert client.post("/api/v1/auth/password",
                           headers={"Authorization": f"Bearer {t}"},
                           json={"current_password": "Reset#Given4821",
                                 "new_password": "SiteChosen#4821"}
                           ).status_code == 200
        assert "initial_admin" not in _security(client, h)


# ── UAT-L22: masking in the log view ──

def test_secret_across_the_cut_is_masked(tmp_path, monkeypatch, data_dir):
    from desktop import system_api
    secret = "Zq9-UatSecretValue-7741"
    monkeypatch.setenv("SMTP_PASSWORD", secret)
    log = tmp_path / "service.log"
    line = "x" * (system_api.MAX_LINE_CHARS - 8) + secret + " tail"
    log.write_text("first\n" + line + "\nlast\n", encoding="utf-8")
    text = system_api._tail(log, 10)
    assert secret[:6] not in text and secret[-6:] not in text
    assert "...(cut)" in text and text.endswith("last")
    # A labelled value across the cut as well.
    monkeypatch.delenv("SMTP_PASSWORD")
    line = "y" * (system_api.MAX_LINE_CHARS - 12) + "password=Lbl-UatValue-99"
    log.write_text(line + "\n", encoding="utf-8")
    assert "Lbl-Ua" not in system_api._tail(log, 5)


def test_replaced_secrets_stay_masked(tmp_path, monkeypatch, data_dir):
    from desktop import system_api, vault
    monkeypatch.delenv("SMTP_PASSWORD", raising=False)
    vault.set_secret("SMTP_PASSWORD", "OldUatSecret-5511")
    vault.set_secret("SMTP_PASSWORD", "NewUatSecret-5512")
    log = tmp_path / "service.log"
    log.write_text("sent with OldUatSecret-5511 and NewUatSecret-5512\n",
                   encoding="utf-8")
    text = system_api._tail(log, 5)
    assert "OldUatSecret" not in text and "NewUatSecret" not in text
    vault.delete_secret("SMTP_PASSWORD")
    assert "NewUatSecret" not in system_api._tail(log, 5)
    assert "OldUatSecret-5511" in vault.retired_values()


# ── UAT-L27: no default password ──

def test_provision_without_a_password_types_nothing(tmp_path):
    from src.rpa.config import build_rpa_config
    from src.rpa.drivers.mock import MockDriver
    from src.rpa.credentials import FINESIIICredentials
    from src.rpa.workflows.provision import ProvisionWorkflow
    config = build_rpa_config(driver="mock", environment="development",
                              evidence_dir=str(tmp_path / "ev"))
    assert "initial_password" not in (config.get("defaults") or {})
    driver = MockDriver()
    driver.initialize(config["application"])
    wf = ProvisionWorkflow(driver, config, None, None)
    creds = FINESIIICredentials(affiliation_code="99999",
                                application_id="UATBOT1",
                                password="Uat@1234")
    result = wf.execute(creds, "30822", "1217036", None)
    assert result["status"] == "failed"
    assert result["retryable"] is False
    assert "never used" in result["error"]
    assert driver.typed_values == []
    layouts = (ROOT / "src" / "rpa" / "screens" / "layouts.yaml").read_text(
        encoding="utf-8")
    assert "initial_password" not in layouts
    for path in ("src/rpa/workflows/provision.py",
                 "src/rpa/screens/field_mapper.py", "scripts/rpa_cli.py"):
        assert "FUJI@33F" not in (ROOT / path).read_text(encoding="utf-8")


# ── SEC-06 / SEC-08: the database set-up script ──

def _setup_module():
    if str(ROOT) not in sys.path:
        sys.path.insert(0, str(ROOT))
    import Setup_Database
    return Setup_Database


class _FakeAddress:
    password = "db-secret-1"

    def __init__(self, accounts=0):
        self.accounts = accounts

    def connect(self, **kw):
        accounts = self.accounts

        class _Conn:
            def __enter__(self):
                return self

            def __exit__(self, *a):
                return False

            def execute(self, sql):
                return SimpleNamespace(fetchone=lambda: (accounts,))
        return _Conn()


def _args(**kw):
    base = dict(password_store="auto", no_prompt=True, env_file="x.env",
                console_admin="generate", new_admin_password=False,
                timeout=5)
    base.update(kw)
    return SimpleNamespace(**base)


def test_setup_keeps_the_password_in_the_credential_store(data_dir):
    sd = _setup_module()
    report = sd.Report()
    args = _args()
    assert sd.resolve_password_store(report, args, _FakeAddress(), None)
    assert args.password_store == "vault"


def test_setup_refuses_the_settings_file_unless_chosen(data_dir,
                                                      monkeypatch):
    from desktop import vault
    sd = _setup_module()
    monkeypatch.setattr(vault, "vault_info", lambda: {
        "available": False, "error": "no store", "account": "x"})
    report = sd.Report()
    assert not sd.resolve_password_store(report, _args(), _FakeAddress(),
                                         None)
    assert report.rows[-1][0] == "FAIL"
    assert "--password-store env-file" in report.rows[-1][2]
    # Chosen explicitly (scripted run): written, with a warning.
    report = sd.Report()
    args = _args(password_store="env-file")
    assert sd.resolve_password_store(report, args, _FakeAddress(), None)
    assert report.rows[-1][0] == "WARN"
    # Asked at the keyboard: anything but YES stops.
    monkeypatch.setattr(sys.stdin, "isatty", lambda: True, raising=False)
    monkeypatch.setattr("builtins.input", lambda prompt: "yes")
    report = sd.Report()
    assert not sd.resolve_password_store(
        report, _args(password_store="env-file", no_prompt=False),
        _FakeAddress(), None)


def test_setup_creates_a_one_time_admin_password(data_dir, capsys):
    from desktop import vault
    sd = _setup_module()
    report = sd.Report()
    sd.initial_admin_password(report, _args(), _FakeAddress(accounts=0))
    password = vault.vault().get("AUTH_DEFAULT_ADMIN_PASSWORD")
    assert re.fullmatch(r"([A-Za-z2-9]{4}-){3}[A-Za-z2-9]{4}", password)
    assert sd.admin_password_problems(password, "admin") == []
    out = capsys.readouterr().out
    assert out.count(password) == 1                 # shown once
    assert password not in "\n".join(report.lines)  # not in the log file
    assert report.rows[-1][0] == "CREATED"
    # A second run keeps it and does not show it again.
    report = sd.Report()
    sd.initial_admin_password(report, _args(), _FakeAddress(accounts=0))
    assert report.rows[-1][0] == "OK"
    assert password not in capsys.readouterr().out
    # Once accounts exist there is nothing to do.
    report = sd.Report()
    sd.initial_admin_password(report, _args(new_admin_password=True),
                              _FakeAddress(accounts=2))
    assert "nothing to set" in report.rows[-1][2]
    assert vault.vault().get("AUTH_DEFAULT_ADMIN_PASSWORD") == password
    vault.delete_secret("AUTH_DEFAULT_ADMIN_PASSWORD")


def test_setup_options_and_defaults():
    sd = _setup_module()
    args = sd.parse_arguments(["postgresql://app@db:5432/finesiii_v3"])
    assert args.password_store == "auto"
    assert args.console_admin == "generate"
