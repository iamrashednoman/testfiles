"""/api/v1/system/* — the installed service managed from the console (P2).

Runs the real app with the desktop extras mounted the way the agent
mounts them. Pins the permission gate, atomic deployment writes with
the database password diverted to the vault, the never-return-a-secret
rule, pause/resume, and that Stop reaches the agent's stop hook.
"""
import io
import zipfile

import pytest

from tests.conftest import make_config

PASSWORD = "CorrectHorse42"


@pytest.fixture
def data_dir(tmp_path, monkeypatch):
    d = tmp_path / "data"
    d.mkdir()
    monkeypatch.setenv("FINESIII_DATA_DIR", str(d))
    return d


@pytest.fixture
def memory_vault(monkeypatch):
    from desktop import vault
    previous = vault._vault
    store = vault.MemoryVault()
    vault.use_vault(store)
    for k in vault.SECRET_KEYS:
        monkeypatch.delenv(k, raising=False)
    yield store
    vault.use_vault(previous)


def _client(tmp_path, stop_hook=None, mode="agent", **overrides):
    from fastapi.testclient import TestClient
    from desktop.server import mount_console_ui
    from src import create_app
    cfg = make_config(tmp_path, dispatcher_enabled=True,
                      terminal_driver="mock",
                      log_dir=str(tmp_path / "logs"), **overrides)
    app = create_app(cfg)
    mount_console_ui(app, mode=mode, stop_hook=stop_hook)
    return TestClient(app)


def _auth(t):
    return {"Authorization": f"Bearer {t}"}


def _admin(client):
    client.post("/api/v1/auth/bootstrap",
                json={"username": "alice", "password": PASSWORD})
    return client.post("/api/v1/auth/login", json={
        "username": "alice", "password": PASSWORD}).json()["access_token"]


def _viewer(client, admin_token):
    client.post("/api/v1/admin/users", headers=_auth(admin_token),
                json={"username": "vic", "password": PASSWORD,
                      "role": "viewer"})
    tok = client.post("/api/v1/auth/login", json={
        "username": "vic", "password": PASSWORD}).json()["access_token"]
    client.post("/api/v1/auth/password", headers=_auth(tok),
                json={"current_password": PASSWORD,
                      "new_password": "ViewerOwnPass99"})
    return client.post("/api/v1/auth/login", json={
        "username": "vic", "password": "ViewerOwnPass99"}
    ).json()["access_token"]


class TestGate:
    def test_requires_sign_in_and_permission(self, tmp_path, data_dir,
                                             memory_vault):
        with _client(tmp_path) as client:
            assert client.get("/api/v1/system/status").status_code == 401
            admin = _admin(client)
            viewer = _viewer(client, admin)
            # viewer holds neither system permission
            assert client.get("/api/v1/system/status",
                              headers=_auth(viewer)).status_code == 403
            r = client.get("/api/v1/system/status", headers=_auth(admin))
            assert r.status_code == 200
            body = r.json()
            assert body["mode"] == "agent"
            assert body["dispatcher"]["paused"] is False
            assert body["can_stop"] is False        # no hook given here

    def test_absent_when_console_is_disabled(self, tmp_path, data_dir):
        with _client(tmp_path, auth_console_enabled=False) as client:
            assert client.get("/api/v1/system/status").status_code == 404


class TestDeployment:
    def test_lists_effective_values_without_url_passwords(
            self, tmp_path, data_dir, memory_vault, monkeypatch):
        monkeypatch.setenv("DATABASE_URL", "postgresql://u:pw@h/x")
        with _client(tmp_path) as client:
            body = client.get("/api/v1/system/deployment",
                              headers=_auth(_admin(client))).json()
            by_key = {s["key"]: s for s in body["settings"]}
            assert by_key["DATABASE_URL"]["value"] == "postgresql://u@h/x"
            assert by_key["DATABASE_URL"]["from_environment"] is True
            assert "pw" not in str(body)
            assert body["vault"]["available"] is True
            assert "DATABASE_PASSWORD" in body["secrets"]

    def test_write_is_atomic_and_diverts_the_password(self, tmp_path,
                                                      data_dir,
                                                      memory_vault):
        from desktop import deployment
        with _client(tmp_path) as client:
            token = _admin(client)
            # One bad key → nothing written at all.
            r = client.put("/api/v1/system/deployment", headers=_auth(token),
                           json={"LOG_LEVEL": "DEBUG", "API_PORT": "80"})
            assert r.status_code == 400
            assert deployment.read() == {}

            # force: the host 'db' does not exist here, and a database
            # server that cannot be reached is refused otherwise (NB-005).
            r = client.put("/api/v1/system/deployment?force=true",
                           headers=_auth(token),
                           json={"LOG_LEVEL": "debug",
                                 "DATABASE_ENGINE": "postgres",
                                 "DATABASE_URL":
                                     "postgresql://app:S3cret@db:5432/f",
                                 "OCR_ENABLED": False})
            assert r.status_code == 200, r.text
            body = r.json()
            assert body["restart_required"] is True
            assert body["secrets_stored"] == ["DATABASE_PASSWORD"]
            on_disk = deployment.read()
            assert on_disk["DATABASE_URL"] == "postgresql://app@db:5432/f"
            assert on_disk["LOG_LEVEL"] == "DEBUG"
            assert on_disk["OCR_ENABLED"] == "false"
            text = deployment.deployment_file().read_text()
            assert "S3cret" not in text
            assert memory_vault.get("DATABASE_PASSWORD") == "S3cret"

            # Clearing removes the key.
            r = client.put("/api/v1/system/deployment", headers=_auth(token),
                           json={"LOG_LEVEL": ""})
            assert r.json()["cleared"] == ["LOG_LEVEL"]
            assert "LOG_LEVEL" not in deployment.read()

    def test_real_driver_needs_ocr(self, tmp_path, data_dir, memory_vault,
                                   monkeypatch):
        # The deployment rules, not this machine's drivers (2026-09-28).
        from desktop import deployment
        monkeypatch.setattr(deployment, "driver_problem", lambda d: "")
        with _client(tmp_path) as client:
            token = _admin(client)
            r = client.put("/api/v1/system/deployment", headers=_auth(token),
                           json={"TERMINAL_DRIVER": "pywinauto",
                                 "OCR_ENABLED": "false"})
            assert r.status_code == 400
            assert "OCR" in r.json()["detail"]
            r = client.put("/api/v1/system/deployment", headers=_auth(token),
                           json={"TERMINAL_DRIVER": "pywinauto",
                                 "OCR_ENABLED": "true"})
            assert r.status_code == 200

    def test_viewer_cannot_write(self, tmp_path, data_dir, memory_vault):
        with _client(tmp_path) as client:
            admin = _admin(client)
            viewer = _viewer(client, admin)
            assert client.put("/api/v1/system/deployment",
                              headers=_auth(viewer),
                              json={"LOG_LEVEL": "DEBUG"}).status_code == 403


class TestSecrets:
    def test_write_only(self, tmp_path, data_dir, memory_vault):
        import os
        with _client(tmp_path) as client:
            token = _admin(client)
            r = client.put("/api/v1/system/secrets/SMTP_PASSWORD",
                           headers=_auth(token), json={"value": "hunter2"})
            assert r.status_code == 200 and r.json()["set"] is True
            assert memory_vault.get("SMTP_PASSWORD") == "hunter2"
            assert os.environ["SMTP_PASSWORD"] == "hunter2"
            dep = client.get("/api/v1/system/deployment",
                             headers=_auth(token)).json()
            assert dep["secrets"]["SMTP_PASSWORD"]["set"] is True
            assert "hunter2" not in dep.__repr__()
            r = client.delete("/api/v1/system/secrets/SMTP_PASSWORD",
                              headers=_auth(token))
            assert r.json()["set"] is False
            assert "SMTP_PASSWORD" not in os.environ

    def test_unknown_secret_name_is_refused(self, tmp_path, data_dir,
                                            memory_vault):
        with _client(tmp_path) as client:
            r = client.put("/api/v1/system/secrets/ROOT_PASSWORD",
                           headers=_auth(_admin(client)), json={"value": "x"})
            assert r.status_code == 400


class TestSetupChecklist:
    def test_checklist_until_marked_complete(self, tmp_path, data_dir,
                                             memory_vault, monkeypatch):
        monkeypatch.delenv("FINESIII_PASSWORD", raising=False)
        with _client(tmp_path) as client:
            token = _admin(client)
            s = client.get("/api/v1/system/setup", headers=_auth(token)).json()
            assert s["complete"] is False
            assert s["checks"]["database"]["value"] == "sqlite"
            # Mock driver: its built-in test account, nothing to set up
            # (E2E-M04).
            assert s["checks"]["service_account"]["ok"] is True
            assert s["checks"]["service_account"]["needed"] is False
            assert s["checks"]["ocr"]["ok"] is True   # mock driver: fine
            r = client.put("/api/v1/system/setup", headers=_auth(token),
                           json={"complete": True})
            assert r.json()["complete"] is True
            assert client.get("/api/v1/system/setup", headers=_auth(token)
                              ).json()["complete"] is True

    def test_setup_row_is_ignored_by_configuration(self, tmp_path, data_dir,
                                                   memory_vault):
        db = str(tmp_path / "shared.db")
        with _client(tmp_path, sqlite_path=db) as client:
            client.put("/api/v1/system/setup", headers=_auth(_admin(client)),
                       json={"complete": True})
        from src import create_app
        cfg = make_config(tmp_path, sqlite_path=db, terminal_driver="mock",
                          dispatcher_enabled=False,
                          log_dir=str(tmp_path / "logs"))
        create_app(cfg)
        assert cfg.max_attempts == 3


class TestChecksAndControl:
    def test_database_test_uses_running_config_by_default(
            self, tmp_path, data_dir, memory_vault):
        with _client(tmp_path) as client:
            r = client.post("/api/v1/system/test-database",
                            headers=_auth(_admin(client)), json={})
            assert r.status_code == 200
            assert r.json()["ok"] is True and r.json()["engine"] == "sqlite"

    def test_pause_and_resume(self, tmp_path, data_dir, memory_vault):
        with _client(tmp_path) as client:
            token = _admin(client)
            r = client.post("/api/v1/system/dispatcher/pause",
                            headers=_auth(token))
            assert r.json()["dispatcher"]["paused"] is True
            assert client.get("/api/v1/system/status", headers=_auth(token)
                              ).json()["dispatcher"]["paused"] is True
            r = client.post("/api/v1/system/dispatcher/resume",
                            headers=_auth(token))
            assert r.json()["dispatcher"]["paused"] is False

    def test_paused_dispatcher_claims_nothing(self, tmp_path, data_dir,
                                              memory_vault):
        import time
        with _client(tmp_path) as client:
            token = _admin(client)
            client.post("/api/v1/system/dispatcher/pause",
                        headers=_auth(token))
            r = client.post("/api/v1/requests", json={
                "operation": "provision", "affiliation_code": "30822",
                "employee_code": "1217036", "password": "FUJI@33F"})
            rid = r.json()["request_id"]
            time.sleep(0.5)
            assert client.get(f"/api/v1/requests/{rid}"
                              ).json()["status"] == "queued"
            client.post("/api/v1/system/dispatcher/resume",
                        headers=_auth(token))
            deadline = time.time() + 20
            while time.time() < deadline:
                st = client.get(f"/api/v1/requests/{rid}").json()["status"]
                if st != "queued":
                    break
                time.sleep(0.2)
            assert st in ("running", "done", "failed")

    def test_stop_reaches_the_agent_hook(self, tmp_path, data_dir,
                                         memory_vault):
        stopped = []
        with _client(tmp_path, stop_hook=lambda: stopped.append(1)) as c:
            token = _admin(c)
            assert c.get("/api/v1/system/status", headers=_auth(token)
                         ).json()["can_stop"] is True
            r = c.post("/api/v1/system/stop", headers=_auth(token))
            assert r.status_code == 202
        assert stopped == [1]

    def test_stop_is_501_in_embedded_mode(self, tmp_path, data_dir,
                                          memory_vault):
        with _client(tmp_path, mode="embedded") as client:
            r = client.post("/api/v1/system/stop",
                            headers=_auth(_admin(client)))
            assert r.status_code == 501

    def test_selftest_logs_and_diagnostics(self, tmp_path, data_dir,
                                           memory_vault, monkeypatch):
        monkeypatch.setenv("SMTP_PASSWORD", "topsecret")
        from desktop import deployment
        deployment.write({"DATABASE_URL": "postgresql://u@h/x",
                          "LOG_LEVEL": "INFO"})
        with _client(tmp_path) as client:
            token = _admin(client)
            r = client.post("/api/v1/system/selftest", headers=_auth(token))
            assert r.status_code == 200
            names = {c["name"] for c in r.json()["checks"]}
            assert {"error catalogue", "database",
                    "credential vault"} <= names

            r = client.get("/api/v1/system/logs?lines=50",
                           headers=_auth(token))
            assert r.status_code == 200 and "lines" in r.json()

            r = client.get("/api/v1/system/diagnostics",
                           headers=_auth(token))
            assert r.status_code == 200
            assert r.headers["content-type"] == "application/zip"
            z = zipfile.ZipFile(io.BytesIO(r.content))
            assert {"status.json", "selftest.json", "finesiii.env",
                    "environment.txt"} <= set(z.namelist())
            env_txt = z.read("environment.txt").decode()
            assert "SMTP_PASSWORD=*****" in env_txt
            assert "topsecret" not in env_txt
