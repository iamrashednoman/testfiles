"""Full-stack e2e: intake API → queue → dispatcher → TerminalExecutor
→ ported workflows on MockDriver → normalized status → audit trail.

Same flow as the visible sim_terminal mode, headless (the sim swaps
only the driver, not the path under test)."""
import importlib.util
import time
from pathlib import Path

import pytest

from tests.conftest import make_config

VALID = {"operation": "provision", "affiliation_code": "30822",
         "employee_code": "1217036", "password": "FUJI@33F"}
DELETE = {"operation": "deprovision", "affiliation_code": "30822",
          "employee_code": "1217036"}

_real_sleep = time.sleep

# How long a transaction may take before a test gives up.
#
# With the null OCR engine (the control-plane venv) a mock transaction
# is near-instant. In the BUILD venv paddleocr is installed, so the
# observer runs real inference on all 26 evidence captures and the same
# transaction takes tens of seconds. The fixed 10s deadline made nine
# e2e tests fail there — which looks like a broken build to anyone
# running the suite where they build the app.
_OCR_INSTALLED = importlib.util.find_spec("paddleocr") is not None
TERMINAL_TIMEOUT = 90.0 if _OCR_INSTALLED else 10.0


@pytest.fixture(autouse=True)
def fast_sleep(monkeypatch):
    """No-op the workflows' terminal pacing delays (they run on the
    dispatcher thread in-process); keep a tiny real yield in the test's
    own polling loop via _wait_for_terminal."""
    monkeypatch.setattr("time.sleep", lambda s: None)


def _client(tmp_path, **overrides):
    from fastapi.testclient import TestClient
    from src import create_app
    cfg = make_config(tmp_path, dispatcher_enabled=True,
                      terminal_driver="mock",
                      log_dir=str(tmp_path / "logs"), **overrides)
    return TestClient(create_app(cfg))


def _wait_for_terminal(client, rid, timeout=None):
    deadline = time.time() + (TERMINAL_TIMEOUT if timeout is None
                              else timeout)
    status = ""
    while time.time() < deadline:
        status = client.get(f"/api/v1/requests/{rid}").json()["status"]
        if status not in ("queued", "running"):
            return status
        _real_sleep(0.02)
    return status


class TestTerminalExecutorE2E:
    def test_provision_through_real_stack(self, tmp_path):
        with _client(tmp_path) as client:
            rid = client.post("/api/v1/requests",
                              json=VALID).json()["request_id"]
            assert _wait_for_terminal(client, rid) == "done"

            row = client.get(f"/api/v1/requests/{rid}").json()
            assert row["result_code"] == "O-0000"
            assert row["password"] == ""             # cleared

            # Evidence really exists on disk, keyed by request id
            assert row["evidence_path"]
            shots = list(Path(row["evidence_path"]).glob("*.png"))
            assert shots, "workflow produced no evidence screenshots"

            # Compliance: every PNG has a printed-pattern .txt mirror
            # with the classification header, and no secret leaks into
            # the text files.
            txts = list(Path(row["evidence_path"]).glob("*.txt"))
            assert {p.stem for p in txts} == {p.stem for p in shots}
            for txt in txts:
                content = txt.read_text(encoding="utf-8")
                assert "FINESIII SCREEN CAPTURE" in content
                assert VALID["password"] not in content

            # The account data visible in the screenshots must be in
            # the text mirrors too (compliance fix 2026-08-17) — the
            # data_entered txt carries the employee code, the password
            # only as its mask.
            entered = next(t for t in txts if "data_entered" in t.name)
            content = entered.read_text(encoding="utf-8")
            assert VALID["employee_code"] in content
            assert "********" in content

            # Before/after data-entry pairs (approved 2026-08-17): the
            # typed state of every input is evidenced, not only the
            # empty screens.
            steps = {p.stem[4:].rsplit("_", 1)[0] for p in shots}
            assert {"menu_selection_entered", "menu_2_loaded",
                    "login_credentials_entered", "task_number_entered",
                    "confirm_command_entered",
                    "commit_command_entered"} <= steps, steps

            # The logout sequence is evidenced too (approved
            # 2026-08-17): each 99 walk-back step, the login screen
            # before the exit walk, the menu return, and the XX
            # shutdown.
            assert {"logout_step_entered", "logout_login_screen",
                    "logout_menu_returned",
                    "logout_shutdown_entered"} <= steps, steps

            # Exactly ONE folder per request, named by request id — no
            # orphan timestamp folders (evidence pin regression)
            evidence_root = Path(row["evidence_path"]).parent
            folders = [p.name for p in evidence_root.iterdir()
                       if p.is_dir()]
            assert folders == [rid], f"unexpected folders: {folders}"

            txns = client.get("/api/v1/transactions").json()
            assert txns["count"] == 1
            txn = txns["transactions"][0]
            assert txn["status"] == "done"
            # P1 parity fields: screenshot tally + executing account
            assert txn["screenshot_count"] == len(shots)
            assert txn["operator"] == "12N3940"     # sim test account
            assert txns["statistics"]["by_status"]["done"] == 1

            csv_text = client.get("/api/v1/transactions/export").text
            assert "screenshot_count" in csv_text.splitlines()[0]
            assert "operator" in csv_text.splitlines()[0]

    def test_deprovision_already_deleted(self, tmp_path):
        with _client(tmp_path, sim_scenario="already_deleted") as client:
            rid = client.post("/api/v1/requests",
                              json=DELETE).json()["request_id"]
            assert _wait_for_terminal(client, rid) == "already_deleted"
            txns = client.get("/api/v1/transactions").json()
            assert txns["transactions"][0]["status"] == "already_deleted"

    def test_error_scenario_fails_without_retry_storm(self, tmp_path):
        """E-9901 is a business failure: terminal, never retried."""
        with _client(tmp_path, sim_scenario="error") as client:
            rid = client.post("/api/v1/requests",
                              json=VALID).json()["request_id"]
            assert _wait_for_terminal(client, rid) == "failed"
            row = client.get(f"/api/v1/requests/{rid}").json()
            assert row["attempt_count"] == 1         # no retries burned
            assert "E-9901" in row["error"]

    def test_unreadable_terminal_reports_done_unconfirmed(self, tmp_path):
        """The real client terminal's body is unreadable — the platform
        must record done/UNCONFIRMED, not a false failure."""
        with _client(tmp_path, sim_scenario="unreadable") as client:
            rid = client.post("/api/v1/requests",
                              json=VALID).json()["request_id"]
            assert _wait_for_terminal(client, rid) == "done"
            row = client.get(f"/api/v1/requests/{rid}").json()
            assert row["result_code"] == "UNCONFIRMED"

    def test_per_request_scenario_override(self, tmp_path):
        """metadata.sim_scenario drives the outcome per request — the
        service default stays 'success', yet one request fails with
        E-9901 and the next deprovision reports already_deleted."""
        with _client(tmp_path) as client:
            rid = client.post("/api/v1/requests", json={
                **VALID, "ticket_id": "SCTASK-ERR",
                "metadata": {"sim_scenario": "error"},
            }).json()["request_id"]
            assert _wait_for_terminal(client, rid) == "failed"
            assert "E-9901" in client.get(
                f"/api/v1/requests/{rid}").json()["error"]

            rid = client.post("/api/v1/requests", json={
                **DELETE, "ticket_id": "SCTASK-DEL",
                "metadata": {"sim_scenario": "already_deleted"},
            }).json()["request_id"]
            assert _wait_for_terminal(client, rid) == "already_deleted"

            # Unknown scenario is ignored — request still succeeds
            rid = client.post("/api/v1/requests", json={
                **VALID, "ticket_id": "SCTASK-BOGUS",
                "metadata": {"sim_scenario": "frobnicate"},
            }).json()["request_id"]
            assert _wait_for_terminal(client, rid) == "done"


class TestErrorScreenHandlingE2E:
    """Case 1 (client evidence): a modal 「エラーメッセージ」 dialog with
    センター準備中 blocks the FINESIII connection. The bot must
    recognise it, press ENTER, run the exit sequence FROM THE LOGIN
    SCREEN, and report a retryable system failure — not grind on
    typing into a window that swallows every keystroke."""

    def test_connection_error_is_recognised_and_handled(self, tmp_path):
        with _client(tmp_path, max_attempts=1) as client:
            rid = client.post("/api/v1/requests", json={
                **VALID, "metadata": {"sim_scenario": "center_not_ready"},
            }).json()["request_id"]
            assert _wait_for_terminal(client, rid) == "failed"

            row = client.get(f"/api/v1/requests/{rid}").json()
            assert "センター準備中" in row["error"]

            shots = sorted(Path(row["evidence_path"]).glob("*.png"))
            ordered = [p.stem[4:].rsplit("_", 1)[0] for p in shots]
            steps = set(ordered)

            # The error AND the bot's reaction to it are evidenced.
            assert {"error_detected", "error_recovery_entered",
                    "error_recovery_complete"} <= steps, steps

            # The app was still shut down cleanly.
            assert {"logout_login_screen", "logout_menu_returned",
                    "logout_shutdown_entered",
                    "logout_complete"} <= steps, ordered

            # …but from the LOGIN screen: the three walk-back '99's
            # that step through POST-login screens never ran (the bot
            # never got past login, so they would have been typed into
            # the credential fields). The only '99' step left is the
            # menu window's, which comes AFTER the login screen.
            assert ordered.count("logout_step_entered") == 1, ordered
            assert ordered.index("logout_step_entered") > \
                ordered.index("logout_login_screen"), ordered

            # The dialog text reached the printed evidence mirror.
            detected = next(p for p in
                            Path(row["evidence_path"]).glob("*.txt")
                            if "error_detected" in p.name)
            content = detected.read_text(encoding="utf-8")
            assert "センター準備中" in content
            assert "エラーメッセージ" in content

    def test_connection_error_is_retried_as_a_system_failure(self, tmp_path):
        """The request is fine, the host is down — so it retries,
        unlike a business failure which is terminal."""
        with _client(tmp_path, max_attempts=2,
                     retry_backoff_base_seconds=0) as client:
            rid = client.post("/api/v1/requests", json={
                **VALID, "metadata": {"sim_scenario": "center_not_ready"},
            }).json()["request_id"]
            assert _wait_for_terminal(client, rid, timeout=TERMINAL_TIMEOUT * 3) == "failed"
            row = client.get(f"/api/v1/requests/{rid}").json()
            assert row["attempt_count"] == 2, "system failure not retried"

    def test_error_is_queryable_in_the_audit_trail(self, tmp_path):
        with _client(tmp_path, max_attempts=1,
                     audit_enabled=True,
                     audit_backend="sqlite",
                     audit_sqlite_path=str(tmp_path / "audit.db"),
                     audit_spool_path=str(tmp_path / "spool.db"),
                     audit_flush_interval_seconds=0.05) as client:
            rid = client.post("/api/v1/requests", json={
                **VALID, "metadata": {"sim_scenario": "center_not_ready"},
            }).json()["request_id"]
            assert _wait_for_terminal(client, rid) == "failed"

            deadline = time.time() + 5
            events = []
            while time.time() < deadline and not events:
                events = client.get(
                    f"/api/v1/audit/events?category=rpa_error"
                    f"&request_id={rid}&limit=100").json()["events"]
                _real_sleep(0.1)

            assert events, "no rpa_error_detected event"
            detail = events[0]["detail"]
            assert detail["error_id"] == "CENTER_NOT_READY"
            assert detail["step"] == "finesiii_connect"
            assert detail["acted"] is True
            assert detail["action"] == "acknowledge"
            # Host diagnostics captured for the FINESIII team
            assert "0151" in detail["captured"]["diagnostic"]
            assert events[0]["severity"] == "ERROR"

            # The failure analysis names the rule, so a developer
            # starts from the cause, not from a log dive.
            analysis = client.get(
                f"/api/v1/audit/events?action="
                f"transaction_failure_analysis&request_id={rid}"
            ).json()["events"]
            assert analysis[0]["detail"]["error_id"] == "CENTER_NOT_READY"
            assert analysis[0]["detail"]["failed_step"] == \
                "finesiii_connect"

    def test_healthy_transaction_is_unaffected_by_the_catalogue(
            self, tmp_path):
        """Regression guard: with the catalogue live, a screen matching
        no rule must behave exactly as it did before."""
        with _client(tmp_path) as client:
            rid = client.post("/api/v1/requests",
                              json=VALID).json()["request_id"]
            assert _wait_for_terminal(client, rid) == "done"
            row = client.get(f"/api/v1/requests/{rid}").json()
            assert row["result_code"] == "O-0000"

            steps = {p.stem[4:].rsplit("_", 1)[0] for p in
                     Path(row["evidence_path"]).glob("*.png")}
            assert not any(s.startswith("error_") for s in steps), steps


class TestLoginRejectionE2E:
    """Case 2 (client evidence): the login screen answers with
    パスワードが誤っています. The bot must recognise it, exit from that
    screen, and let the EXISTING dispatcher retry own the retrying —
    so the account sees exactly max_attempts password attempts, never
    a multiplied count."""

    @staticmethod
    def _password_attempts(evidence_path) -> int:
        """One 'login_credentials_entered' capture == one password
        attempt against the mainframe."""
        return len([p for p in Path(evidence_path).glob("*.png")
                    if "login_credentials_entered" in p.name])

    def test_rejected_login_is_recognised_and_exits(self, tmp_path):
        with _client(tmp_path, max_attempts=1) as client:
            rid = client.post("/api/v1/requests", json={
                **VALID,
                "metadata": {"sim_scenario": "login_password_incorrect"},
            }).json()["request_id"]
            assert _wait_for_terminal(client, rid) == "failed"

            row = client.get(f"/api/v1/requests/{rid}").json()
            assert "パスワードが誤っています" in row["error"]

            shots = sorted(Path(row["evidence_path"]).glob("*.png"))
            ordered = [p.stem[4:].rsplit("_", 1)[0] for p in shots]
            steps = set(ordered)

            # Recognised as an error screen, and the login_failed
            # capture still fires (existing behaviour preserved).
            assert "error_detected" in steps, ordered
            assert "login_failed" in steps, ordered

            # Exit ran from the login screen — (終了:99) is available
            # there, and the post-login walk-back never applies.
            assert ordered.count("logout_step_entered") == 1, ordered
            assert {"logout_login_screen", "logout_menu_returned",
                    "logout_shutdown_entered",
                    "logout_complete"} <= steps, ordered

            # The rejection reached the printed evidence mirror.
            detected = next(p for p in
                            Path(row["evidence_path"]).glob("*.txt")
                            if "error_detected" in p.name)
            assert "パスワードが誤っています" in detected.read_text(
                encoding="utf-8")

    @pytest.mark.parametrize("max_attempts", [1, 2, 3])
    def test_password_attempts_never_multiply(self, tmp_path,
                                              max_attempts):
        """THE lockout guard. The catalogue rule deliberately carries no
        retry loop of its own: if it did, its attempts would multiply
        with the dispatcher's (3 x 3 = 9) and lock the real service
        account. Password attempts must equal max_attempts exactly."""
        with _client(tmp_path, max_attempts=max_attempts,
                     retry_backoff_base_seconds=0,
                     retry_max_delay_seconds=0) as client:
            rid = client.post("/api/v1/requests", json={
                **VALID,
                "metadata": {"sim_scenario": "login_password_incorrect"},
            }).json()["request_id"]
            assert _wait_for_terminal(client, rid, timeout=TERMINAL_TIMEOUT * 3) == "failed"

            row = client.get(f"/api/v1/requests/{rid}").json()
            assert row["attempt_count"] == min(max_attempts, 2)
            # The same password is never typed again once rejected
            # (D-04, 2026-10-05): one password attempt, whatever the
            # retry policy allows.
            assert self._password_attempts(row["evidence_path"]) == 1, \
                "password attempts multiplied — LOCKOUT RISK"
            assert "Not retried" in row["error"] or max_attempts == 1

    def test_rejection_is_queryable_in_the_audit_trail(self, tmp_path):
        with _client(tmp_path, max_attempts=1,
                     audit_enabled=True,
                     audit_backend="sqlite",
                     audit_sqlite_path=str(tmp_path / "audit.db"),
                     audit_spool_path=str(tmp_path / "spool.db"),
                     audit_flush_interval_seconds=0.05) as client:
            rid = client.post("/api/v1/requests", json={
                **VALID,
                "metadata": {"sim_scenario": "login_password_incorrect"},
            }).json()["request_id"]
            assert _wait_for_terminal(client, rid) == "failed"

            deadline = time.time() + 5
            events = []
            while time.time() < deadline and not events:
                events = client.get(
                    f"/api/v1/audit/events?category=rpa_error"
                    f"&request_id={rid}&limit=100").json()["events"]
                _real_sleep(0.1)

            assert events, "no rpa_error_detected event"
            detail = events[0]["detail"]
            assert detail["error_id"] == "LOGIN_PASSWORD_INCORRECT"
            assert detail["step"] == "login_submitted"
            assert detail["acted"] is True
            assert detail["classification"] == "system"

            analysis = client.get(
                f"/api/v1/audit/events?action="
                f"transaction_failure_analysis&request_id={rid}"
            ).json()["events"]
            assert analysis[0]["detail"]["error_id"] == \
                "LOGIN_PASSWORD_INCORRECT"

    def test_invalid_affiliation_pairing_is_handled_the_same_way(
            self, tmp_path):
        """Case 3: same screen, different message. It must select its
        OWN rule and follow the same exit path."""
        with _client(tmp_path, max_attempts=1) as client:
            rid = client.post("/api/v1/requests", json={
                **VALID,
                "metadata": {"sim_scenario": "invalid_affiliation_code"},
            }).json()["request_id"]
            assert _wait_for_terminal(client, rid) == "failed"

            row = client.get(f"/api/v1/requests/{rid}").json()
            assert "オペレーターコード未登録です" in row["error"]
            # Not mistaken for the password rejection.
            assert "パスワードが誤っています" not in row["error"]

            shots = sorted(Path(row["evidence_path"]).glob("*.png"))
            ordered = [p.stem[4:].rsplit("_", 1)[0] for p in shots]
            assert "error_detected" in ordered, ordered
            assert ordered.count("logout_step_entered") == 1, ordered
            assert {"logout_login_screen", "logout_shutdown_entered",
                    "logout_complete"} <= set(ordered), ordered

            detected = next(p for p in
                            Path(row["evidence_path"]).glob("*.txt")
                            if "error_detected" in p.name)
            assert "オペレーターコード未登録です" in detected.read_text(
                encoding="utf-8")

    def test_invalid_affiliation_respects_the_retry_count(self, tmp_path):
        with _client(tmp_path, max_attempts=2,
                     retry_backoff_base_seconds=0,
                     retry_max_delay_seconds=0) as client:
            rid = client.post("/api/v1/requests", json={
                **VALID,
                "metadata": {"sim_scenario": "invalid_affiliation_code"},
            }).json()["request_id"]
            assert _wait_for_terminal(client, rid, timeout=TERMINAL_TIMEOUT * 3) == "failed"
            row = client.get(f"/api/v1/requests/{rid}").json()
            # BUG-035: the rule says the whole request is not run again
            # (same codes → same rejection), whatever max_attempts is.
            assert row["attempt_count"] == 1
            assert self._password_attempts(row["evidence_path"]) == 1

    def test_invalid_affiliation_names_its_rule_in_the_audit(self,
                                                             tmp_path):
        with _client(tmp_path, max_attempts=1,
                     audit_enabled=True,
                     audit_backend="sqlite",
                     audit_sqlite_path=str(tmp_path / "audit.db"),
                     audit_spool_path=str(tmp_path / "spool.db"),
                     audit_flush_interval_seconds=0.05) as client:
            rid = client.post("/api/v1/requests", json={
                **VALID,
                "metadata": {"sim_scenario": "invalid_affiliation_code"},
            }).json()["request_id"]
            assert _wait_for_terminal(client, rid) == "failed"

            deadline = time.time() + 5
            events = []
            while time.time() < deadline and not events:
                events = client.get(
                    f"/api/v1/audit/events?category=rpa_error"
                    f"&request_id={rid}&limit=100").json()["events"]
                _real_sleep(0.1)

            assert events
            detail = events[0]["detail"]
            assert detail["error_id"] == "LOGIN_OPERATOR_NOT_REGISTERED"
            assert detail["step"] == "login_submitted"
            # The id does not quote the screen; the trail must.
            assert "オペレーターコード未登録です" in detail["matched"]

    def test_invalid_staff_code_reports_both_codes_to_the_team(
            self, tmp_path):
        """Case 4 end to end. Same screen as Case 3, different root
        cause — so the audit must carry BOTH submitted codes as
        separate data points, and must not name a culprit."""
        with _client(tmp_path, max_attempts=1,
                     audit_enabled=True,
                     audit_backend="sqlite",
                     audit_sqlite_path=str(tmp_path / "audit.db"),
                     audit_spool_path=str(tmp_path / "spool.db"),
                     audit_flush_interval_seconds=0.05) as client:
            rid = client.post("/api/v1/requests", json={
                **VALID,
                "metadata": {"sim_scenario": "invalid_staff_code"},
            }).json()["request_id"]
            assert _wait_for_terminal(client, rid) == "failed"

            deadline = time.time() + 5
            events = []
            while time.time() < deadline and not events:
                events = client.get(
                    f"/api/v1/audit/events?category=rpa_error"
                    f"&request_id={rid}&limit=100").json()["events"]
                _real_sleep(0.1)

            assert events
            detail = events[0]["detail"]
            assert detail["error_id"] == "LOGIN_OPERATOR_NOT_REGISTERED"

            # Both data points, queryable per request.
            context = detail["context"]
            assert context["login_affiliation_code"]
            assert context["login_staff_code"] == "12N3940"
            # …and never the password.
            assert VALID["password"] not in str(context)
            assert "TEST0000" not in str(context)

    def test_both_pairing_scenarios_report_one_rule(self, tmp_path):
        """Cases 3 and 4 are different root causes that FINESIII reports
        identically. Both must land on the one rule — a split would
        need a signal the terminal does not give."""
        seen = set()
        for scenario in ("invalid_affiliation_code", "invalid_staff_code"):
            workdir = tmp_path / scenario
            workdir.mkdir()          # each run needs its own sqlite/evidence
            with _client(workdir, max_attempts=1) as client:
                rid = client.post("/api/v1/requests", json={
                    **VALID, "metadata": {"sim_scenario": scenario},
                }).json()["request_id"]
                assert _wait_for_terminal(client, rid) == "failed"
                row = client.get(f"/api/v1/requests/{rid}").json()
                assert "オペレーターコード未登録です" in row["error"]
                seen.add(row["error"])
        assert len(seen) == 1, "the two scenarios must be indistinguishable"

    def test_credentials_never_leak_into_the_evidence(self, tmp_path):
        """A failed login is exactly where a password would leak."""
        with _client(tmp_path, max_attempts=1) as client:
            rid = client.post("/api/v1/requests", json={
                **VALID,
                "metadata": {"sim_scenario": "login_password_incorrect"},
            }).json()["request_id"]
            assert _wait_for_terminal(client, rid) == "failed"
            row = client.get(f"/api/v1/requests/{rid}").json()
            for txt in Path(row["evidence_path"]).glob("*.txt"):
                assert VALID["password"] not in txt.read_text(
                    encoding="utf-8"), txt.name


class TestAuditTrailE2E:
    def test_disabled_audit_returns_503(self, tmp_path):
        with _client(tmp_path) as client:
            assert client.get("/api/v1/audit/events").status_code == 503

    def test_events_flow_submit_dispatch_complete(self, tmp_path):
        with _client(tmp_path,
                     audit_enabled=True,
                     audit_backend="sqlite",
                     audit_sqlite_path=str(tmp_path / "audit.db"),
                     audit_spool_path=str(tmp_path / "spool.db"),
                     audit_flush_interval_seconds=0.05) as client:
            rid = client.post("/api/v1/requests",
                              json=VALID).json()["request_id"]
            assert _wait_for_terminal(client, rid) == "done"

            # limit high enough to span the per-action rpa events that
            # now share the stream (~60-100 per transaction)
            deadline = time.time() + 5
            actions = set()
            while time.time() < deadline:
                body = client.get(
                    "/api/v1/audit/events?limit=500").json()
                actions = {e["action"] for e in body["events"]}
                if {"request_submitted", "request_dispatched",
                        "transaction_completed"} <= actions:
                    break
                _real_sleep(0.1)

            assert "request_submitted" in actions
            assert "request_dispatched" in actions
            assert "transaction_completed" in actions

            # Filtered query narrows to the dispatch category
            dispatch = client.get(
                "/api/v1/audit/events?category=dispatch").json()
            assert all(e["category"] == "dispatch"
                       for e in dispatch["events"])

            # Every bot action of the transaction is in the audit DB —
            # the complete ordered interaction log, queryable per
            # request (client compliance requirement). The trace flushes
            # asynchronously after completion — poll for it.
            expected = {"launch_application", "type_text",
                        "submit_command"}
            deadline = time.time() + 5
            performed = set()
            while time.time() < deadline and not expected <= performed:
                actions_log = client.get(
                    f"/api/v1/audit/events?category=rpa_action"
                    f"&request_id={rid}&limit=500").json()["events"]
                performed = {e["action"] for e in actions_log}
                _real_sleep(0.1)
            assert expected <= performed

            # Screen classifications are persisted too
            screens_log = client.get(
                f"/api/v1/audit/events?category=rpa_screen"
                f"&request_id={rid}&limit=500").json()["events"]
            assert screens_log and all(
                e["action"] == "screen_classified" for e in screens_log)

    def test_failure_analysis_event_pinpoints_step(self, tmp_path):
        """A failed transaction leaves an ERROR analysis event stating
        WHAT failed and WHERE — debuggable from the audit trail alone."""
        with _client(tmp_path,
                     audit_enabled=True,
                     audit_backend="sqlite",
                     audit_sqlite_path=str(tmp_path / "audit.db"),
                     audit_spool_path=str(tmp_path / "spool.db"),
                     audit_flush_interval_seconds=0.05) as client:
            rid = client.post("/api/v1/requests", json={
                **VALID, "metadata": {"sim_scenario": "error"},
            }).json()["request_id"]
            assert _wait_for_terminal(client, rid) == "failed"

            deadline = time.time() + 5
            analysis = []
            while time.time() < deadline and not analysis:
                analysis = client.get(
                    f"/api/v1/audit/events?action="
                    f"transaction_failure_analysis&request_id={rid}"
                ).json()["events"]
                _real_sleep(0.1)

            assert analysis, "failure analysis event missing"
            detail = analysis[0]["detail"]
            assert detail["failed_step"] == "check_result"
            assert detail["result_code"] == "E-9901"
            assert detail["last_actions"], "no action tail recorded"
            assert analysis[0]["severity"] == "ERROR"


class TestAvailabilityGateE2E:
    def test_availability_surfaced_in_api(self, tmp_path):
        with _client(tmp_path) as client:
            health = client.get("/api/v1/health").json()
            assert health["availability"]["available"] is True
            queue = client.get("/api/v1/queue").json()
            assert queue["availability"]["window"] == "00:00-23:59 JST"

            resp = client.post("/api/v1/requests", json=VALID).json()
            assert resp["mainframe_available"] is True
            assert "processing shortly" in resp["message"]

    def test_closed_window_queues_without_processing(self, tmp_path):
        """Outside the operating window the request is accepted but the
        dispatcher never claims it (v2 Gate 1 parity)."""
        from datetime import timedelta

        from src.modules.intake.models import now_jst
        # A window that closed earlier today (an empty 00:00-00:00 window
        # is refused by the configuration since NB-009).
        now = now_jst()
        start, end = now - timedelta(hours=3), now - timedelta(hours=2)
        if start.date() != now.date():
            pytest.skip("too close to midnight for this window shape")
        with _client(tmp_path,
                     availability_window_start=start.strftime("%H:%M"),
                     availability_window_end=end.strftime("%H:%M"),
                     shutdown_buffer_minutes=0) as client:
            resp = client.post("/api/v1/requests", json=VALID).json()
            assert resp["mainframe_available"] is False
            assert "offline" in resp["message"]

            _real_sleep(0.3)     # several dispatcher ticks
            status = client.get(
                f"/api/v1/requests/{resp['request_id']}").json()["status"]
            assert status == "queued"
