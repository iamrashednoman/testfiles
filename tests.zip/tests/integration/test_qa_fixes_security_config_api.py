"""QA fixes wired through the application — secrets, configuration,
deployment (group B)."""
from __future__ import annotations

import os

import pytest

from tests.conftest import make_config

PASSWORD = "CorrectHorse42"


@pytest.fixture(autouse=True)
def fast_sleep(monkeypatch):
    monkeypatch.setattr("time.sleep", lambda s: None)


@pytest.fixture
def data_dir(tmp_path, monkeypatch):
    d = tmp_path / "data"
    d.mkdir()
    monkeypatch.setenv("FINESIII_DATA_DIR", str(d))
    return d


@pytest.fixture
def memory_vault(monkeypatch):
    from desktop import vault
    previous = vault._vault
    store = vault.MemoryVault()
    vault.use_vault(store)
    for k in vault.SECRET_KEYS:
        monkeypatch.delenv(k, raising=False)
    yield store
    vault.use_vault(previous)


def _desktop_app(tmp_path, **overrides):
    from desktop.server import mount_console_ui
    from src import create_app
    cfg = make_config(tmp_path, terminal_driver="mock",
                      log_dir=str(tmp_path / "logs"), **overrides)
    app = create_app(cfg)
    mount_console_ui(app, mode="agent")
    return app


def _auth(t):
    return {"Authorization": f"Bearer {t}"}


def _admin(client):
    client.post("/api/v1/auth/bootstrap",
                json={"username": "alice", "password": PASSWORD})
    return client.post("/api/v1/auth/login", json={
        "username": "alice", "password": PASSWORD}).json()["access_token"]


# ── BUG-005: the SMTP password goes to the credential store ──

class TestSmtpPasswordStore:
    def test_console_settings_refuse_smtp_password(self, tmp_path):
        from fastapi.testclient import TestClient
        from src import create_app
        cfg = make_config(tmp_path, log_dir=str(tmp_path / "logs"))
        with TestClient(create_app(cfg)) as client:
            r = client.put("/api/v1/console/settings",
                           headers=_auth(_admin(client)),
                           json={"SMTP_PASSWORD": "never-stored-pw"})
            assert r.status_code == 400
            assert "not an editable setting" in r.json()["detail"]
            assert "never-stored-pw" not in r.text

    def test_credentials_path_stores_it_write_only(self, tmp_path, data_dir,
                                                   memory_vault):
        from fastapi.testclient import TestClient
        with TestClient(_desktop_app(tmp_path)) as client:
            token = _admin(client)
            r = client.put("/api/v1/system/secrets/SMTP_PASSWORD",
                           headers=_auth(token),
                           json={"value": "vault-only-pw"})
            assert r.status_code == 200
            assert memory_vault.get("SMTP_PASSWORD") == "vault-only-pw"
            dep = client.get("/api/v1/system/deployment",
                             headers=_auth(token))
            assert "vault-only-pw" not in dep.text
            assert dep.json()["secrets"]["SMTP_PASSWORD"]["set"] is True
            assert "SMTP_PASSWORD" not in \
                client.app.state.settings_store.all()

    def test_legacy_row_moved_when_the_agent_mounts(self, tmp_path,
                                                    data_dir, memory_vault):
        from src.core.db import Database
        from src.modules.console.settings_store import SettingsStore
        cfg = make_config(tmp_path)
        db = Database.from_config(cfg)
        SettingsStore(db).set("SMTP_PASSWORD", "legacy-db-pw")
        db.close()
        app = _desktop_app(tmp_path)
        assert memory_vault.get("SMTP_PASSWORD") == "legacy-db-pw"
        assert "SMTP_PASSWORD" not in app.state.settings_store.all()
        assert os.environ.get("SMTP_PASSWORD") == "legacy-db-pw"


# ── BUG-044: a blank secret changes nothing ──

class TestBlankSecretPut:
    def test_blank_secret_stores_no_row(self, tmp_path, monkeypatch):
        from fastapi.testclient import TestClient
        from src import create_app
        from src.modules.console import settings_catalogue
        spec = settings_catalogue._s("QA_TEST_SECRET", "Test secret",
                                     "Email", "str", target="env",
                                     secret=True)
        monkeypatch.setitem(settings_catalogue.BY_KEY, "QA_TEST_SECRET",
                            spec)
        cfg = make_config(tmp_path, log_dir=str(tmp_path / "logs"))
        with TestClient(create_app(cfg)) as client:
            token = _admin(client)
            for blank in ("", "   "):
                r = client.put("/api/v1/console/settings",
                               headers=_auth(token),
                               json={"QA_TEST_SECRET": blank})
                assert r.status_code == 200
                assert r.json()["changed"] == {}
            assert "QA_TEST_SECRET" not in \
                client.app.state.settings_store.all()


# ── BUG-024: initial administrator password retired ──

class TestInitialAdminPassword:
    def _app(self, tmp_path):
        return _desktop_app(tmp_path, auth_seed_default_admin=True,
                            auth_default_admin_username="admin",
                            auth_default_admin_password="Provisional!2026")

    def test_kept_while_change_pending_removed_after(self, tmp_path,
                                                     data_dir, memory_vault):
        from fastapi.testclient import TestClient
        memory_vault.set("AUTH_DEFAULT_ADMIN_PASSWORD", "Provisional!2026")
        with TestClient(self._app(tmp_path)) as client:
            # Seeded, must change: the stored value is kept.
            assert memory_vault.get("AUTH_DEFAULT_ADMIN_PASSWORD") == \
                "Provisional!2026"
            token = client.post("/api/v1/auth/login", json={
                "username": "admin", "password": "Provisional!2026"}
            ).json()["access_token"]
            r = client.post("/api/v1/auth/password", headers=_auth(token),
                            json={"current_password": "Provisional!2026",
                                  "new_password": "SiteOwnPass2026"})
            assert r.status_code == 200
            assert memory_vault.get("AUTH_DEFAULT_ADMIN_PASSWORD") is None
            assert "AUTH_DEFAULT_ADMIN_PASSWORD" not in os.environ

    def test_removed_at_mount_when_already_changed(self, tmp_path, data_dir,
                                                   memory_vault):
        from fastapi.testclient import TestClient
        with TestClient(self._app(tmp_path)) as client:
            token = client.post("/api/v1/auth/login", json={
                "username": "admin", "password": "Provisional!2026"}
            ).json()["access_token"]
            client.post("/api/v1/auth/password", headers=_auth(token),
                        json={"current_password": "Provisional!2026",
                              "new_password": "SiteOwnPass2026"})
        # Left behind (e.g. restored by hand), then the agent restarts.
        memory_vault.set("AUTH_DEFAULT_ADMIN_PASSWORD", "Provisional!2026")
        self._app(tmp_path)
        assert memory_vault.get("AUTH_DEFAULT_ADMIN_PASSWORD") is None


# ── BUG-023: the log view masks secrets ──

class TestLogViewMasked:
    def test_logs_masked(self, tmp_path, data_dir, memory_vault):
        from fastapi.testclient import TestClient
        app = _desktop_app(tmp_path)
        log = tmp_path / "logs" / "finesiii_rpa_v3.log"
        log.parent.mkdir(parents=True, exist_ok=True)
        log.write_text(
            "INFO connecting with password=log-secret-1\n"
            'DEBUG payload {"client_secret": "log-secret-2"}\n'
            "DEBUG Authorization: Bearer log-secret-3\n"
            "INFO db postgresql://app:log-secret-4@db/x\n", encoding="utf-8")
        with TestClient(app) as client:
            token = _admin(client)
            r = client.get("/api/v1/system/logs?lines=50",
                           headers=_auth(token))
            assert r.status_code == 200
            text = "\n".join(r.json()["lines"])
            for n in range(1, 5):
                assert f"log-secret-{n}" not in text
            assert "password=*****" in text

            import io
            import zipfile
            r = client.get("/api/v1/system/diagnostics",
                           headers=_auth(token))
            z = zipfile.ZipFile(io.BytesIO(r.content))
            for name in z.namelist():
                body = z.read(name).decode("utf-8", errors="replace")
                for n in range(1, 5):
                    assert f"log-secret-{n}" not in body, name


# ── BUG-037: health answers 503 while the database is down ──

class TestHealthStatus:
    def test_503_when_database_down(self, tmp_path):
        from fastapi.testclient import TestClient
        from src import create_app
        app = create_app(make_config(tmp_path))
        with TestClient(app) as client:
            assert client.get("/api/v1/health").status_code == 200
            db = app.state.queue_store.db
            original = db.fetchone

            def broken(sql, *a, **kw):
                if "SELECT 1" in sql:
                    raise RuntimeError("database gone")
                return original(sql, *a, **kw)
            db.fetchone = broken
            try:
                r = client.get("/api/v1/health")
            finally:
                db.fetchone = original
            assert r.status_code == 503
            assert r.json()["database"] == "down"
            assert r.json()["service"] == "up"


# ── BUG-045 / BUG-046: deployment save ──

class TestDeploymentSave:
    def test_encoded_password_split_to_credential_store(self, tmp_path,
                                                        data_dir,
                                                        memory_vault):
        from fastapi.testclient import TestClient
        from desktop import deployment
        with TestClient(_desktop_app(tmp_path)) as client:
            r = client.put("/api/v1/system/deployment",
                           headers=_auth(_admin(client)),
                           json={"DATABASE_URL":
                                 "postgresql://u:Pw%239@h:5432/db"})
            assert r.status_code == 200, r.text
        assert memory_vault.get("DATABASE_PASSWORD") == "Pw#9"
        assert deployment.read()["DATABASE_URL"] == \
            "postgresql://u@h:5432/db"

    def test_unencoded_hash_refused(self, tmp_path, data_dir, memory_vault):
        from fastapi.testclient import TestClient
        from desktop import deployment
        with TestClient(_desktop_app(tmp_path)) as client:
            r = client.put("/api/v1/system/deployment",
                           headers=_auth(_admin(client)),
                           json={"DATABASE_URL":
                                 "postgresql://u:Pw#9@h:5432/db"})
            assert r.status_code == 400
            assert "%23" in r.json()["detail"]
            assert "Pw#9" not in r.text
        assert "DATABASE_URL" not in deployment.read()
        assert memory_vault.get("DATABASE_PASSWORD") is None

    def test_file_write_failure_changes_nothing(self, tmp_path, data_dir,
                                                memory_vault, monkeypatch):
        from fastapi.testclient import TestClient
        from desktop import deployment
        memory_vault.set("DATABASE_PASSWORD", "old-pw")

        def fail(changes):
            raise PermissionError(13, "Permission denied")
        with TestClient(_desktop_app(tmp_path)) as client:
            token = _admin(client)
            monkeypatch.setattr(deployment, "update", fail)
            r = client.put("/api/v1/system/deployment", headers=_auth(token),
                           json={"DATABASE_URL":
                                 "postgresql://u:new-pw@h:5432/db"})
        assert r.status_code == 500
        assert "nothing was changed" in r.json()["detail"]
        assert memory_vault.get("DATABASE_PASSWORD") == "old-pw"
        assert os.environ.get("DATABASE_PASSWORD") != "new-pw"

    def test_vault_failure_rolls_the_file_back(self, tmp_path, data_dir,
                                               memory_vault, monkeypatch):
        from fastapi.testclient import TestClient
        from desktop import deployment, vault
        deployment.write({"LOG_LEVEL": "INFO",
                          "DATABASE_URL": "postgresql://u@old:5432/db"})
        before = deployment.read()

        def fail(key, value):
            raise vault.VaultUnavailableError("vault write failed: locked")
        with TestClient(_desktop_app(tmp_path)) as client:
            token = _admin(client)
            monkeypatch.setattr(memory_vault, "set", fail)
            r = client.put("/api/v1/system/deployment", headers=_auth(token),
                           json={"DATABASE_URL":
                                 "postgresql://u:new-pw@new:5432/db",
                                 "LOG_LEVEL": "DEBUG"})
        assert r.status_code == 503
        assert "nothing was changed" in r.json()["detail"]
        assert deployment.read() == before
        assert memory_vault.get("DATABASE_PASSWORD") is None
        assert "DATABASE_PASSWORD" not in os.environ


# ── BUG-078: passwords held only where needed ──

class TestRequestPasswords:
    def _client(self, tmp_path, **kw):
        from fastapi.testclient import TestClient
        from src import create_app
        return TestClient(create_app(make_config(tmp_path, **kw)))

    def test_removal_never_stores_a_password(self, tmp_path):
        with self._client(tmp_path) as client:
            r = client.post("/api/v1/requests", json={
                "operation": "deprovision", "affiliation_code": "30822",
                "employee_code": "1217036", "password": "FUJI@33F"})
            assert r.status_code == 202, r.text
            req = client.app.state.queue_store.get(r.json()["request_id"])
            assert req.password == ""
            assert "password_supplied" not in req.metadata

    def test_zero_retention_erases_on_failure_and_retry_issues_new(
            self, tmp_path):
        with self._client(tmp_path,
                          failed_password_retention_days=0) as client:
            store = client.app.state.queue_store
            assert store.keep_failed_password is False
            rid = client.post("/api/v1/requests", json={
                "operation": "provision", "affiliation_code": "30822",
                "employee_code": "1217036"}).json()["request_id"]
            first = store.get(rid).password
            assert first
            store.dequeue_oldest(worker_id=1)
            store.mark_complete(rid, "failed", error="boom")
            assert store.get(rid).password == ""
            r = client.post(f"/api/v1/requests/{rid}/retry")
            assert r.status_code == 202, r.text
            again = store.get(rid).password
            assert again and again != first

    def test_zero_retention_supplied_password_needs_resubmission(
            self, tmp_path):
        with self._client(tmp_path,
                          failed_password_retention_days=0) as client:
            store = client.app.state.queue_store
            rid = client.post("/api/v1/requests", json={
                "operation": "provision", "affiliation_code": "30822",
                "employee_code": "1217037", "password": "FUJI@33F"}
            ).json()["request_id"]
            store.dequeue_oldest(worker_id=1)
            store.mark_complete(rid, "failed", error="boom")
            assert store.get(rid).password == ""
            r = client.post(f"/api/v1/requests/{rid}/retry")
            assert r.status_code == 409
            assert r.json()["detail"]["status"] == "password_expired"


# ── BUG-080: API description only without sign-in requirements ──

class TestApiDescription:
    def test_hidden_when_api_key_required(self, tmp_path, monkeypatch):
        from fastapi.testclient import TestClient
        from src import create_app
        monkeypatch.setenv("FINESIII_API_KEYS", "svc:qa-key")
        app = create_app(make_config(tmp_path, auth_enabled=True))
        with TestClient(app) as client:
            for path in ("/openapi.json", "/api/docs", "/redoc", "/docs"):
                assert client.get(path).status_code == 404, path

    def test_hidden_when_not_debug(self, tmp_path):
        from fastapi.testclient import TestClient
        from src import create_app
        app = create_app(make_config(tmp_path, debug=False))
        with TestClient(app) as client:
            assert client.get("/openapi.json").status_code == 404

    def test_development_without_key_keeps_docs(self, tmp_path):
        from fastapi.testclient import TestClient
        from src import create_app
        app = create_app(make_config(tmp_path))
        with TestClient(app) as client:
            assert client.get("/openapi.json").status_code == 200
            assert client.get("/api/docs").status_code == 200
