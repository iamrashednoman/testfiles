"""Integration tests: full CRUD lifecycle through the FastAPI app."""
import time

import pytest

from tests.conftest import make_config

VALID = {"operation": "provision", "affiliation_code": "30822",
         "employee_code": "1217036", "password": "FUJI@33F"}


class TestCrudLifecycle:
    def test_submit_returns_202(self, api_client):
        resp = api_client.post("/api/v1/requests", json=VALID)
        assert resp.status_code == 202
        body = resp.json()
        assert body["status"] == "queued" and body["request_id"]

    def test_get_and_list(self, api_client):
        rid = api_client.post("/api/v1/requests", json=VALID).json()["request_id"]
        assert api_client.get(f"/api/v1/requests/{rid}").status_code == 200
        listed = api_client.get("/api/v1/requests?status=queued").json()
        assert listed["count"] == 1
        # password never leaks through the API
        assert listed["requests"][0]["password"] == "****"

    def test_invalid_operation_400(self, api_client):
        resp = api_client.post("/api/v1/requests",
                               json={**VALID, "operation": "delete"})
        assert resp.status_code == 400

    def test_strict_validation_400(self, api_client):
        resp = api_client.post("/api/v1/requests",
                               json={**VALID, "employee_code": "123"})
        assert resp.status_code == 400
        assert "Employee code" in resp.json()["detail"]

    def test_duplicate_409(self, api_client):
        body = {**VALID, "ticket_id": "SCTASK100"}
        assert api_client.post("/api/v1/requests", json=body).status_code == 202
        resp = api_client.post("/api/v1/requests", json=body)
        assert resp.status_code == 409
        assert resp.json()["detail"]["status"] == "duplicate"

    def test_cancel_then_resubmit_allowed(self, api_client):
        body = {**VALID, "ticket_id": "SCTASK101"}
        rid = api_client.post("/api/v1/requests", json=body).json()["request_id"]
        assert api_client.delete(f"/api/v1/requests/{rid}").status_code == 200
        # approved fix: cancelled history never blocks resubmission
        assert api_client.post("/api/v1/requests", json=body).status_code == 202

    def test_invalid_status_filter_400(self, api_client):
        assert api_client.get("/api/v1/requests?status=nope").status_code == 400

    def test_unknown_request_404(self, api_client):
        assert api_client.get("/api/v1/requests/req_missing").status_code == 404

    def test_health(self, api_client):
        body = api_client.get("/api/v1/health").json()
        assert body["service"] == "up" and body["database"] == "up"


class TestRetryEndpoint:
    def test_retry_only_failed(self, api_client):
        rid = api_client.post("/api/v1/requests", json=VALID).json()["request_id"]
        resp = api_client.post(f"/api/v1/requests/{rid}/retry")
        assert resp.status_code == 409          # queued, not failed

        store = api_client.app.state.queue_store
        store.dequeue_oldest(worker_id=1)
        store.mark_complete(rid, "failed", error="boom")

        resp = api_client.post(f"/api/v1/requests/{rid}/retry")
        assert resp.status_code == 202
        assert api_client.get(f"/api/v1/requests/{rid}").json()["status"] == "queued"


class TestAuth:
    def test_auth_off_by_default(self, api_client):
        assert api_client.get("/api/v1/health").status_code == 200

    def test_auth_enforced_when_enabled(self, tmp_path, monkeypatch):
        from fastapi.testclient import TestClient
        from src import create_app
        monkeypatch.setenv("FINESIII_API_KEYS", "snow:key-abc123")
        cfg = make_config(tmp_path, auth_enabled=True)
        with TestClient(create_app(cfg)) as client:
            assert client.get("/api/v1/health").status_code == 401
            assert client.get(
                "/api/v1/health", headers={"X-API-Key": "wrong"}
            ).status_code == 401
            assert client.get(
                "/api/v1/health", headers={"X-API-Key": "key-abc123"}
            ).status_code == 200

    def test_auth_enabled_without_keys_fails_closed(self, tmp_path, monkeypatch):
        from src import create_app
        monkeypatch.delenv("FINESIII_API_KEYS", raising=False)
        with pytest.raises(RuntimeError):
            create_app(make_config(tmp_path, auth_enabled=True))


class TestEndToEndProcessing:
    def _wait_for_status(self, client, rid, target, timeout=5.0):
        deadline = time.time() + timeout
        while time.time() < deadline:
            status = client.get(f"/api/v1/requests/{rid}").json()["status"]
            if status == target:
                return status
            time.sleep(0.05)
        return status

    def test_mock_executor_processes_to_done(self, tmp_path):
        """Submit → dispatcher → MockExecutor('success') → normalized
        'done' → transaction recorded → password cleared."""
        from fastapi.testclient import TestClient
        from src import create_app
        cfg = make_config(tmp_path, dispatcher_enabled=True)
        with TestClient(create_app(cfg)) as client:
            rid = client.post("/api/v1/requests", json=VALID).json()["request_id"]
            assert self._wait_for_status(client, rid, "done") == "done"

            row = client.get(f"/api/v1/requests/{rid}").json()
            assert row["result_code"] == "O-0000"
            assert row["password"] == ""       # cleared, not just masked

            txns = client.get("/api/v1/transactions").json()
            assert txns["count"] == 1
            assert txns["transactions"][0]["status"] == "done"
            assert txns["transactions"][0]["affiliation_code"] == "30822"
            assert txns["statistics"]["by_status"]["done"] == 1

    def test_csv_export_formula_guard(self, tmp_path):
        from fastapi.testclient import TestClient
        from src import create_app
        cfg = make_config(tmp_path, dispatcher_enabled=True)
        with TestClient(create_app(cfg)) as client:
            rid = client.post("/api/v1/requests", json=VALID).json()["request_id"]
            self._wait_for_status(client, rid, "done")
            csv_text = client.get("/api/v1/transactions/export").text
            # The console's export writer since 2026-10-03 (X-04): a
            # byte-order mark first, so Excel reads Japanese correctly.
            assert csv_text.startswith("\ufefftransaction_id,")
            assert "evidence_path" not in csv_text.splitlines()[0]
            assert rid in csv_text
