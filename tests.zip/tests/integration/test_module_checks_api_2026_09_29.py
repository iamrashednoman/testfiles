"""Module checks through the console API (2026-09-29, T1–T3): the
terminal check's safeguards and results, Resume held while a check runs,
and the read-only ServiceNow preview."""
import pytest

from tests.conftest import make_config

PASSWORD = "CorrectHorse42"


@pytest.fixture(autouse=True)
def fast_sleep(monkeypatch):
    monkeypatch.setattr("time.sleep", lambda s: None)


@pytest.fixture
def data_dir(tmp_path, monkeypatch):
    from desktop import vault
    d = tmp_path / "data"
    d.mkdir()
    monkeypatch.setenv("FINESIII_DATA_DIR", str(d))
    previous = vault._vault
    vault.use_vault(vault.MemoryVault())
    for k in vault.SECRET_KEYS:
        monkeypatch.delenv(k, raising=False)
    yield d
    vault.use_vault(previous)


def _client(tmp_path, **overrides):
    from fastapi.testclient import TestClient
    from desktop.server import mount_console_ui
    from src import create_app
    base = dict(terminal_driver="mock", dispatcher_enabled=True,
                log_dir=str(tmp_path / "logs"))
    base.update(overrides)
    app = create_app(make_config(tmp_path, **base))
    mount_console_ui(app, mode="agent")
    return TestClient(app)


def _auth(t):
    return {"Authorization": f"Bearer {t}"}


def _admin(client):
    client.post("/api/v1/auth/bootstrap",
                json={"username": "alice", "password": PASSWORD})
    return client.post("/api/v1/auth/login", json={
        "username": "alice", "password": PASSWORD}).json()["access_token"]


class TestTerminalCheckApi:
    def test_refused_until_processing_is_paused(self, tmp_path, data_dir):
        with _client(tmp_path) as client:
            token = _admin(client)
            r = client.post("/api/v1/system/test-terminal",
                            headers=_auth(token), json={"level": "launch"})
            assert r.status_code == 409 and "Pause processing" in r.text
            client.post("/api/v1/system/dispatcher/pause",
                        headers=_auth(token))
            r = client.post("/api/v1/system/test-terminal",
                            headers=_auth(token), json={"level": "launch"})
            assert r.status_code == 200, r.text
            body = r.json()
            assert body["ok"] is True and body["sign_off"]["ok"] is True
            assert [s["step"] for s in body["steps"]] == ["launch",
                                                          "sign_off"]

    def test_navigate_needs_confirmation_then_opens_903(self, tmp_path,
                                                        data_dir):
        with _client(tmp_path) as client:
            token = _admin(client)
            client.post("/api/v1/system/dispatcher/pause",
                        headers=_auth(token))
            client.app.state.availability.is_within_time_window = \
                lambda check_buffer=False: True
            r = client.post("/api/v1/system/test-terminal",
                            headers=_auth(token), json={"level": "navigate"})
            assert r.status_code == 400 and "confirm" in r.text
            r = client.post("/api/v1/system/test-terminal",
                            headers=_auth(token),
                            json={"level": "navigate", "confirm": True})
            assert r.status_code == 200, r.text
            steps = [s["step"] for s in r.json()["steps"]]
            assert steps == ["launch", "open_login", "sign_in", "task_903",
                             "sign_off"]

    def test_navigate_refused_outside_the_operating_window(self, tmp_path,
                                                           data_dir):
        with _client(tmp_path) as client:
            token = _admin(client)
            client.post("/api/v1/system/dispatcher/pause",
                        headers=_auth(token))
            client.app.state.availability.is_within_time_window = \
                lambda check_buffer=False: False
            r = client.post("/api/v1/system/test-terminal",
                            headers=_auth(token),
                            json={"level": "navigate", "confirm": True})
            assert r.status_code == 409 and "operating window" in r.text

    def test_resume_held_while_a_check_runs(self, tmp_path, data_dir):
        with _client(tmp_path) as client:
            token = _admin(client)
            client.post("/api/v1/system/dispatcher/pause",
                        headers=_auth(token))
            check = client.app.state.terminal_check
            check._lock.acquire()
            try:
                r = client.post("/api/v1/system/dispatcher/resume",
                                headers=_auth(token))
                assert r.status_code == 409
                assert "terminal check is running" in r.text
                r = client.post("/api/v1/system/test-terminal",
                                headers=_auth(token),
                                json={"level": "launch"})
                assert r.status_code == 409
            finally:
                check._lock.release()
            r = client.post("/api/v1/system/dispatcher/resume",
                            headers=_auth(token))
            assert r.status_code == 200

    def test_simulator_driver_is_refused(self, tmp_path, data_dir):
        with _client(tmp_path) as client:
            token = _admin(client)
            client.post("/api/v1/system/dispatcher/pause",
                        headers=_auth(token))
            client.app.state.terminal_check.executor.rpa_config = dict(
                client.app.state.terminal_check.executor.rpa_config,
                driver="sim_terminal")
            r = client.post("/api/v1/system/test-terminal",
                            headers=_auth(token), json={"level": "launch"})
            assert r.status_code == 409 and "sim_terminal" in r.text


class TestServiceNowPreviewApi:
    def test_preview_answers_from_the_poller(self, tmp_path, data_dir):
        from types import SimpleNamespace
        with _client(tmp_path, dispatcher_enabled=False) as client:
            token = _admin(client)
            r = client.post("/api/v1/system/servicenow/preview",
                            headers=_auth(token))
            assert r.status_code == 404                # no poller here
            client.app.state.snow_poller = SimpleNamespace(preview=lambda: {
                "query": "active=true", "polling_enabled": False,
                "fetched": 1, "error": "",
                "tickets": [{"ticket": "SCTASK0001", "action": "queue",
                             "reason": "", "requests": []}]})
            r = client.post("/api/v1/system/servicenow/preview",
                            headers=_auth(token))
            assert r.status_code == 200
            assert r.json()["ok"] is True
            assert r.json()["tickets"][0]["action"] == "queue"
