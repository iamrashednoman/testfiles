"""Branding — public read, settings.edit write, validated, one row (P3)."""
import base64

import pytest

from tests.conftest import make_config

PASSWORD = "CorrectHorse42"
PNG_1x1 = base64.b64encode(
    b"\x89PNG\r\n\x1a\n" + b"\x00" * 60).decode()


@pytest.fixture(autouse=True)
def fast_sleep(monkeypatch):
    monkeypatch.setattr("time.sleep", lambda s: None)


def _client(tmp_path, **overrides):
    from fastapi.testclient import TestClient
    from src import create_app
    cfg = make_config(tmp_path, dispatcher_enabled=False,
                      terminal_driver="mock",
                      log_dir=str(tmp_path / "logs"), **overrides)
    return TestClient(create_app(cfg))


def _auth(t):
    return {"Authorization": f"Bearer {t}"}


def _admin(client):
    client.post("/api/v1/auth/bootstrap",
                json={"username": "alice", "password": PASSWORD})
    return client.post("/api/v1/auth/login", json={
        "username": "alice", "password": PASSWORD}).json()["access_token"]


class TestBranding:
    def test_public_read_returns_defaults(self, tmp_path):
        with _client(tmp_path) as client:
            r = client.get("/api/v1/console/branding")      # no token
            assert r.status_code == 200
            b = r.json()["branding"]
            # AIG brand defaults (2026-09-28).
            assert b["product_name"] == "FINES III RPA"
            assert b["accent_color"] == "#001871"
            assert b["secondary_color"] == "#00a4e4"
            assert b["link_color"] == "#1352de"
            assert b["logo"] == ""          # "" = the built-in AIG logo
            # Branded HTML e-mail on by default since 2026-09-29 (D1).
            assert b["email_html_enabled"] is True
            assert set(b) == {"product_name", "tagline", "logo", "favicon",
                              "login_background", "accent_color",
                              "secondary_color", "link_color", "nav_color",
                              "background_color", "panel_color",
                              "text_color", "font", "footer_text",
                              "support_contact", "signin_notice",
                              "email_html_enabled", "email_banner",
                              "email_logo", "email_header_color",
                              "email_accent_color", "email_company_name",
                              "email_footer_text"}

    def test_write_requires_settings_edit_and_persists(self, tmp_path):
        db = str(tmp_path / "shared.db")
        with _client(tmp_path, sqlite_path=db) as client:
            assert client.put("/api/v1/console/branding",
                              json={"product_name": "x"}).status_code == 401
            token = _admin(client)
            r = client.put("/api/v1/console/branding", headers=_auth(token),
                           json={"product_name": "AIG Provisioning Bot",
                                 "accent_color": "#FF8800",
                                 "logo": f"data:image/png;base64,{PNG_1x1}"})
            assert r.status_code == 200, r.text
            b = r.json()["branding"]
            assert b["product_name"] == "AIG Provisioning Bot"
            assert b["accent_color"] == "#ff8800"       # normalised
            assert b["logo"].startswith("data:image/png;base64,")
            # A later partial update keeps the rest.
            client.put("/api/v1/console/branding", headers=_auth(token),
                       json={"tagline": "IAM automation"})
            b = client.get("/api/v1/console/branding").json()["branding"]
            assert b["product_name"] == "AIG Provisioning Bot"
            assert b["tagline"] == "IAM automation"

        # Survives a rebuild: it is in the database, not in memory.
        with _client(tmp_path, sqlite_path=db) as client:
            b = client.get("/api/v1/console/branding").json()["branding"]
            assert b["product_name"] == "AIG Provisioning Bot"

    def test_validation(self, tmp_path):
        with _client(tmp_path) as client:
            token = _admin(client)
            bad = [
                {"accent_color": "red"},
                {"logo": "http://example.com/logo.png"},
                {"logo": "data:text/html;base64,PGI+"},
                {"product_name": "x" * 61},
                {"unknown_field": "1"},
                {"favicon": "data:image/png;base64,"
                            + base64.b64encode(b"\x00" * 70000).decode()},
                # 2026-09-28 fields
                {"secondary_color": "sand"},
                {"font": "Comic Sans; color:red"},
                {"email_html_enabled": "maybe"},
                # Outlook does not show SVG / WebP in e-mail.
                {"email_banner": "data:image/svg+xml;base64,PHN2Zz4="},
                {"email_logo": "data:image/webp;base64,UklGRg=="},
                {"email_banner": "data:image/png;base64,"
                                 + base64.b64encode(
                                     b"\x00" * 310_000).decode()},
                {"tagline": "two\nlines"},
                {"signin_notice": "x" * 601},
            ]
            for body in bad:
                r = client.put("/api/v1/console/branding",
                               headers=_auth(token), json=body)
                assert r.status_code == 400, body

    def test_reset_returns_to_defaults(self, tmp_path):
        with _client(tmp_path) as client:
            token = _admin(client)
            client.put("/api/v1/console/branding", headers=_auth(token),
                       json={"product_name": "Temp"})
            r = client.delete("/api/v1/console/branding",
                              headers=_auth(token))
            assert r.json()["branding"]["product_name"] == "FINES III RPA"
            assert client.get("/api/v1/console/branding"
                              ).json()["branding"]["product_name"] \
                == "FINES III RPA"

    def test_branding_row_does_not_disturb_configuration(self, tmp_path):
        """apply_overrides must skip the BRANDING row silently."""
        db = str(tmp_path / "shared.db")
        with _client(tmp_path, sqlite_path=db) as client:
            client.put("/api/v1/console/branding",
                       headers=_auth(_admin(client)),
                       json={"product_name": "Whatever"})
        from src import create_app
        cfg = make_config(tmp_path, sqlite_path=db, terminal_driver="mock",
                          dispatcher_enabled=False,
                          log_dir=str(tmp_path / "logs"))
        create_app(cfg)
        assert cfg.max_attempts == 3


class TestBrandingAdditions:
    """Branding fields added 2026-09-28 (U2, U8)."""

    def test_new_fields_are_saved(self, tmp_path):
        with _client(tmp_path) as client:
            token = _admin(client)
            r = client.put("/api/v1/console/branding", headers=_auth(token),
                           json={"secondary_color": "#AABBCC",
                                 "font": "meiryo",
                                 "signin_notice": "Line one\nLine two",
                                 "email_html_enabled": "true",
                                 "email_banner":
                                     f"data:image/png;base64,{PNG_1x1}",
                                 "email_company_name": "Example Co.",
                                 "email_footer_text": "Footer\nsecond"})
            assert r.status_code == 200, r.text
            b = client.get("/api/v1/console/branding").json()["branding"]
            assert b["secondary_color"] == "#aabbcc"
            assert b["font"] == "meiryo"
            assert b["signin_notice"] == "Line one\nLine two"
            assert b["email_html_enabled"] is True
            assert b["email_banner"].startswith("data:image/png")

    def test_old_dark_defaults_read_as_not_chosen(self, tmp_path):
        """A document saved before the new theme held the old dark
        colours as values; they must not paint dark on light."""
        import json
        from src.modules.console import branding

        class Store:
            def all(self):
                return {branding.KEY: json.dumps({
                    "product_name": "FINESIII RPA",
                    "accent_color": "#2f81f7",
                    "background_color": "#0f1419",
                    "panel_color": "#171d24", "text_color": "#e6edf3",
                    "tagline": "Kept", "footer_text": "Kept too"})}

        doc = branding.load(Store())
        assert doc["accent_color"] == "#001871"
        assert doc["background_color"] == branding.DEFAULTS[
            "background_color"]
        assert doc["product_name"] == "FINES III RPA"
        assert doc["tagline"] == "Kept"
        assert doc["footer_text"] == "Kept too"

    def test_interim_navy_and_sand_defaults_read_as_not_chosen(self):
        import json
        from src.modules.console import branding

        class Store:
            def all(self):
                return {branding.KEY: json.dumps({
                    "accent_color": "#10183c", "secondary_color": "#e2d6ba",
                    "background_color": "#f5f3ee", "text_color": "#1b2233",
                    "email_accent_color": "#e2d6ba",
                    "nav_color": "#123456"})}

        doc = branding.load(Store())
        assert doc["accent_color"] == "#001871"
        assert doc["secondary_color"] == "#00a4e4"
        assert doc["email_accent_color"] == "#00a4e4"
        assert doc["nav_color"] == "#123456"      # a real choice is kept
