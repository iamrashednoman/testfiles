"""Console data tables, metrics, reports and the audited export
(U11 / U12, 2026-09-28).

The list APIs gained OPTIONAL paging, sorting and search. Without the
new parameters every answer must be exactly what it was, so existing
callers (the ServiceNow connector, scripts) are unaffected.
"""
import time

import pytest

from tests.conftest import make_config

PASSWORD = "CorrectHorse42"
_real_sleep = time.sleep


@pytest.fixture(autouse=True)
def fast_sleep(monkeypatch):
    monkeypatch.setattr("time.sleep", lambda s: None)


def _client(tmp_path, **overrides):
    from fastapi.testclient import TestClient
    from src import create_app
    # The simulated terminal's screenshots have nothing to read: OCR off,
    # as in the other simulated runs, so a request finishes in time even
    # where the OCR models are installed (T-02, 2026-10-04).
    opts = dict(terminal_driver="mock", ocr_enabled=False,
                log_dir=str(tmp_path / "logs"))
    opts.update(overrides)
    return TestClient(create_app(make_config(tmp_path, **opts)))


def _audited(tmp_path, **overrides):
    return _client(tmp_path, audit_enabled=True, audit_backend="sqlite",
                   audit_sqlite_path=str(tmp_path / "audit.db"),
                   audit_spool_path=str(tmp_path / "spool.db"),
                   audit_flush_interval_seconds=0.05, **overrides)


def _auth(t):
    return {"Authorization": f"Bearer {t}"}


def _admin(client):
    client.post("/api/v1/auth/bootstrap",
                json={"username": "alice", "password": PASSWORD})
    return client.post("/api/v1/auth/login", json={
        "username": "alice", "password": PASSWORD}).json()["access_token"]


def _user_with(client, admin, username, permissions):
    client.post("/api/v1/admin/roles", headers=_auth(admin),
                json={"name": f"r_{username}", "description": "test",
                      "permissions": permissions})
    client.post("/api/v1/admin/users", headers=_auth(admin),
                json={"username": username, "password": PASSWORD,
                      "role": f"r_{username}"})
    t = client.post("/api/v1/auth/login", json={
        "username": username, "password": PASSWORD}).json()["access_token"]
    client.post("/api/v1/auth/password", headers=_auth(t),
                json={"current_password": PASSWORD,
                      "new_password": "TheirOwn7777"})
    return client.post("/api/v1/auth/login", json={
        "username": username,
        "password": "TheirOwn7777"}).json()["access_token"]


def _submit(client, employee, affiliation="30822", op="provision"):
    body = {"operation": op, "affiliation_code": affiliation,
            "employee_code": employee}
    if op == "provision":
        body["password"] = "FUJI@33F"
    r = client.post("/api/v1/requests", json=body)
    assert r.status_code == 202, r.text
    return r.json()["request_id"]


def _wait_done(client, token, rid):
    for _ in range(400):
        row = client.get(f"/api/v1/requests/{rid}",
                         headers=_auth(token)).json()
        if row["status"] not in ("queued", "running"):
            return row
        _real_sleep(0.02)
    raise AssertionError("request did not finish")


class TestRequestPaging:
    def test_without_new_parameters_the_answer_is_unchanged(self, tmp_path):
        with _client(tmp_path) as client:
            token = _admin(client)
            for e in ("1000001", "1000002", "1000003"):
                _submit(client, e)
            d = client.get("/api/v1/requests", headers=_auth(token)).json()
            assert set(d) == {"count", "requests"}
            assert d["count"] == 3

    def test_page_sort_search_and_total(self, tmp_path):
        with _client(tmp_path) as client:
            token = _admin(client)
            for e in ("1000003", "1000001", "1000002"):
                _submit(client, e)
            d = client.get("/api/v1/requests?offset=0&limit=2"
                           "&sort=employee_code&order=asc",
                           headers=_auth(token)).json()
            assert d["total"] == 3 and d["count"] == 2
            assert [r["employee_code"] for r in d["requests"]] == \
                ["1000001", "1000002"]
            d = client.get("/api/v1/requests?offset=2&limit=2"
                           "&sort=employee_code&order=asc",
                           headers=_auth(token)).json()
            assert [r["employee_code"] for r in d["requests"]] == ["1000003"]
            d = client.get("/api/v1/requests?q=000002",
                           headers=_auth(token)).json()
            assert d["total"] == 1
            assert d["requests"][0]["employee_code"] == "1000002"

    def test_unknown_sort_column_is_ignored_not_executed(self, tmp_path):
        with _client(tmp_path) as client:
            token = _admin(client)
            _submit(client, "1000001")
            r = client.get("/api/v1/requests",
                           params={"sort": "status; DROP TABLE request_queue",
                                   "offset": 0},
                           headers=_auth(token))
            assert r.status_code == 200 and r.json()["total"] == 1
            r = client.get("/api/v1/requests?order=sideways",
                           headers=_auth(token))
            assert r.status_code == 422
            # The table is still there.
            assert client.get("/api/v1/requests",
                              headers=_auth(token)).json()["count"] == 1

    def test_search_never_matches_the_password(self, tmp_path):
        with _client(tmp_path) as client:
            token = _admin(client)
            _submit(client, "1000001")
            d = client.get("/api/v1/requests?q=FUJI",
                           headers=_auth(token)).json()
            assert d["total"] == 0


class TestTransactionsMetricsAndExport:
    def test_history_paging_metrics_and_export(self, tmp_path):
        with _audited(tmp_path, dispatcher_enabled=True) as client:
            token = _admin(client)
            for e in ("1000001", "1000002"):
                _wait_done(client, token, _submit(client, e))

            d = client.get("/api/v1/transactions?offset=0&limit=1"
                           "&sort=employee_code&order=desc",
                           headers=_auth(token)).json()
            assert d["total"] == 2 and d["count"] == 1
            assert d["transactions"][0]["employee_code"] == "1000002"
            assert "statistics" in d

            m = client.get("/api/v1/console/metrics?period=7d",
                           headers=_auth(token)).json()
            assert m["kpis"]["total"] == 2
            assert m["kpis"]["succeeded"] == 2
            assert m["kpis"]["success_rate"] == 100.0
            assert len(m["daily"]) == 7 and len(m["by_hour"]) == 24
            assert m["backlog"]["by_status"].get("done") == 2
            # No personal field in the figures.
            assert "1000001" not in str(m)

            r = client.get("/api/v1/console/export/transactions",
                           headers=_auth(token))
            assert r.status_code == 200
            assert r.headers["content-type"].startswith("text/csv")
            text = r.content.decode("utf-8")
            assert text.startswith("﻿")          # Excel reads UTF-8
            assert "evidence_path" not in text.splitlines()[0]
            assert text.count("1000001") == 1

            r = client.get("/api/v1/console/export/requests?q=1000002",
                           headers=_auth(token))
            lines = r.content.decode("utf-8").strip().splitlines()
            assert len(lines) == 2 and "1000002" in lines[1]
            assert "FUJI" not in r.content.decode("utf-8")

            deadline = time.time() + 5
            exports = []
            while time.time() < deadline and len(exports) < 2:
                exports = [e for e in client.get(
                    "/api/v1/audit/events?category=console&limit=100",
                    headers=_auth(token)).json()["events"]
                    if e["action"] == "data_exported"]
                _real_sleep(0.1)
            assert len(exports) == 2, "exports were not audited"
            tables = sorted(e["detail"]["table"] for e in exports)
            assert tables == ["requests", "transactions"]
            assert all(e["detail"]["actor"] == "alice" for e in exports)

            # Audit paging, search and the audit report.
            d = client.get("/api/v1/audit/events?offset=0&limit=5"
                           "&q=data_exported", headers=_auth(token)).json()
            assert d["total"] >= 2 and d["count"] <= 5
            rep = client.get("/api/v1/console/reports?period=today",
                             headers=_auth(token)).json()
            assert rep["kpis"]["exports"] >= 2
            assert rep["kpis"]["sign_ins"] >= 1
            # A period is needed for the audit trail (UAT-L03).
            from src.modules.intake.models import now_jst
            today = now_jst().date().isoformat()
            r = client.get("/api/v1/console/export/audit",
                           headers=_auth(token),
                           params={"date_from": today, "date_to": today})
            assert r.status_code == 200 and "data_exported" in r.text

    def test_period_validation(self, tmp_path):
        with _client(tmp_path) as client:
            token = _admin(client)
            for q in ("period=forever", "date_from=2026-01-01&date_to=2025-01-01",
                      "date_from=2024-01-01&date_to=2026-01-01",
                      "date_from=yesterday&date_to=today"):
                r = client.get(f"/api/v1/console/metrics?{q}",
                               headers=_auth(token))
                assert r.status_code == 400, q
            r = client.get("/api/v1/console/metrics?date_from=2026-09-01"
                           "&date_to=2026-09-03", headers=_auth(token))
            assert r.status_code == 200 and len(r.json()["daily"]) == 3


class TestPermissions:
    def test_each_route_needs_its_permission(self, tmp_path):
        with _audited(tmp_path) as client:
            admin = _admin(client)
            for path in ("/api/v1/console/metrics", "/api/v1/console/reports",
                         "/api/v1/console/export/requests",
                         "/api/v1/console/export/audit"):
                assert client.get(path).status_code == 401, path
            dash = _user_with(client, admin, "dasha", ["dashboard.view"])
            assert client.get("/api/v1/console/metrics",
                              headers=_auth(dash)).status_code == 200
            for path in ("/api/v1/console/reports",
                         "/api/v1/console/export/audit",
                         "/api/v1/console/export/requests",
                         "/api/v1/console/export/transactions"):
                assert client.get(path, headers=_auth(dash)
                                  ).status_code == 403, path
            aud = _user_with(client, admin, "audra", ["audit.view"])
            assert client.get("/api/v1/console/reports",
                              headers=_auth(aud)).status_code == 200
            assert client.get("/api/v1/console/metrics",
                              headers=_auth(aud)).status_code == 403

    def test_reports_without_audit_trail(self, tmp_path):
        with _client(tmp_path) as client:
            token = _admin(client)
            assert client.get("/api/v1/console/reports",
                              headers=_auth(token)).status_code == 503


class TestSettingsHelp:
    def test_every_setting_has_a_tooltip_and_the_api_sends_it(self, tmp_path):
        with _client(tmp_path) as client:
            token = _admin(client)
            d = client.get("/api/v1/console/settings",
                           headers=_auth(token)).json()
            missing = [s["key"] for s in d["settings"]
                       if not (s.get("tooltip") or "").strip()]
            assert not missing, missing
            assert all("section" in s for s in d["settings"])
            snow = {s["key"]: s["section"] for s in d["settings"]
                    if s["group"] == "ServiceNow"}
            assert all(snow.values()), "every ServiceNow setting has a section"
