"""End-to-end QA of 5 October 2026, batches 2 to 4: the Medium and Low
findings (E2E-M01 … E2E-L33) and decisions D-01 … D-09, as approved.

Server behaviour is tested through the API or the class concerned; the
console page through its source, like the other console tests."""
import json
import logging
import re
import time
from pathlib import Path
from types import SimpleNamespace

import pytest

from tests.conftest import make_config

PASSWORD = "CorrectHorse42"
ROOT = Path(__file__).resolve().parents[2]
UI = ROOT / "desktop" / "ui"
APP = (UI / "app.js").read_text(encoding="utf-8")
KIT = (UI / "ui-kit.js").read_text(encoding="utf-8")
INDEX = (UI / "index.html").read_text(encoding="utf-8")
VALID = {"operation": "provision", "affiliation_code": "30822",
         "employee_code": "1217036", "password": "Abc@1234"}


@pytest.fixture(autouse=True)
def fast_sleep(monkeypatch):
    monkeypatch.setattr("time.sleep", lambda s: None)


@pytest.fixture
def data_dir(tmp_path, monkeypatch):
    from desktop import vault
    d = tmp_path / "data"
    d.mkdir()
    monkeypatch.setenv("FINESIII_DATA_DIR", str(d))
    previous = vault._vault
    vault.use_vault(vault.MemoryVault())
    for k in vault.SECRET_KEYS:
        monkeypatch.delenv(k, raising=False)
    yield d
    vault.use_vault(previous)


def _app(tmp_path, mount=True, **overrides):
    from desktop.server import mount_console_ui
    from src import create_app
    opts = dict(terminal_driver="mock", ocr_enabled=False,
                log_dir=str(tmp_path / "logs"))
    opts.update(overrides)
    app = create_app(make_config(tmp_path, **opts))
    if mount:
        mount_console_ui(app, mode="agent", stop_hook=lambda: None)
    return app


def _client(app):
    from fastapi.testclient import TestClient
    return TestClient(app)


def _h(t):
    return {"Authorization": f"Bearer {t}"}


def _admin(client):
    client.post("/api/v1/auth/bootstrap",
                json={"username": "alice", "password": PASSWORD})
    return client.post("/api/v1/auth/login", json={
        "username": "alice", "password": PASSWORD}).json()["access_token"]


def _user(client, admin, username, role):
    client.post("/api/v1/admin/users", headers=_h(admin),
                json={"username": username, "password": PASSWORD,
                      "role": role})
    t = client.post("/api/v1/auth/login", json={
        "username": username, "password": PASSWORD}).json()["access_token"]
    client.post("/api/v1/auth/password", headers=_h(t),
                json={"current_password": PASSWORD,
                      "new_password": "TheirOwn7777"})
    return client.post("/api/v1/auth/login", json={
        "username": username,
        "password": "TheirOwn7777"}).json()["access_token"]


def _function(src: str, name: str) -> str:
    start = src.index(f"function {name}(")
    nxt = re.search(r"\n(async )?function |\nLOADERS\.", src[start + 10:])
    return src[start:start + 10 + nxt.start()] if nxt else src[start:]


class _Audit:
    def __init__(self):
        self.events = []

    def event(self, category, action, severity="INFO", detail=None, **kw):
        self.events.append(SimpleNamespace(category=category, action=action,
                                           severity=severity, detail=detail,
                                           fields=kw))


class _Log:
    def __init__(self):
        self.lines = []

    def __getattr__(self, level):
        return lambda msg, *a, **k: self.lines.append((level, msg))


# ── E2E-M01 (D-03): the same account and operation while one is open ──

class TestOpenDuplicate:
    def test_refused_while_queued_and_accepted_after(self, tmp_path, data_dir):
        with _client(_app(tmp_path, mount=False,
                          dispatcher_enabled=False)) as client:
            r1 = client.post("/api/v1/requests",
                             json={**VALID, "ticket_id": "DEMO-001"})
            assert r1.status_code == 202
            r2 = client.post("/api/v1/requests",
                             json={**VALID, "ticket_id": "DEMO-002"})
            assert r2.status_code == 409
            assert r2.json()["detail"]["original_request_id"] == \
                r1.json()["request_id"]
            # The opposite operation is other work.
            r3 = client.post("/api/v1/requests", json={
                "operation": "deprovision", "affiliation_code": "30822",
                "employee_code": "1217036", "ticket_id": "DEMO-003"})
            assert r3.status_code == 202
            # Once the first has finished, the same work is new work.
            store = client.app.state.queue_store
            store.dequeue_oldest(worker_id=1)
            store.mark_complete(r1.json()["request_id"], "done",
                                result_code="O-0000")
            r4 = client.post("/api/v1/requests",
                             json={**VALID, "ticket_id": "DEMO-004"})
            assert r4.status_code == 202


# ── E2E-M03: the service account's codes are checked ──

class TestServiceAccountCodes:
    def test_codes_are_checked_before_the_vault(self, tmp_path, data_dir):
        from desktop import vault
        with _client(_app(tmp_path)) as client:
            h = _h(_admin(client))
            r = client.put("/api/v1/system/secrets/FINESIII_AFFILIATION_CODE",
                           headers=h, json={"value": "ABC"})
            assert r.status_code == 400 and "ABC" not in r.text
            assert "5 half-width digits" in r.json()["detail"]
            r = client.put("/api/v1/system/secrets/FINESIII_APPLICATION_ID",
                           headers=h, json={"value": "12-3940"})
            assert r.status_code == 400 and "12-3940" not in r.text
            assert not vault.vault().get("FINESIII_AFFILIATION_CODE")
            for name, value in (("FINESIII_AFFILIATION_CODE", "03325"),
                                ("FINESIII_APPLICATION_ID", "12N3940")):
                assert client.put(f"/api/v1/system/secrets/{name}", headers=h,
                                  json={"value": value}).status_code == 200


# ── E2E-M05: a console sign-in needs the route's permission ──

class TestPermissionWithoutKey:
    def test_viewer_cannot_submit_even_with_a_made_up_key(self, tmp_path,
                                                          data_dir):
        with _client(_app(tmp_path, dispatcher_enabled=False)) as client:
            admin = _admin(client)
            viewer = _user(client, admin, "vic", "viewer")
            r = client.post("/api/v1/requests", json=VALID,
                            headers={**_h(viewer), "X-API-Key": "junk"})
            assert r.status_code == 403
            assert client.get("/api/v1/requests",
                              headers=_h(viewer)).status_code == 200
            # Without a sign-in nothing changes until the key is required.
            assert client.post("/api/v1/requests",
                               json=VALID).status_code == 202


# ── E2E-M06: a held-back CyberArk outage notice is sent later ──

class TestCyberArkRealert:
    def _provider(self, down, up):
        from src.integrations.cyberark.client import CyberArkError
        from src.integrations.cyberark.config import CyberArkSettings
        from src.integrations.cyberark.provider import CyberArkPasswordProvider
        state = {"fail": True}

        class _Client:
            def fetch_password(self):
                if state["fail"]:
                    raise CyberArkError("unreachable")
                return "Pw@12345"

        p = CyberArkPasswordProvider(
            CyberArkSettings(enabled=True, base_url="https://v",
                             app_id="a", safe="s", object_name="o"),
            client=_Client(), on_unavailable=down, on_recovered=up)
        return p, state

    def test_suppressed_notice_is_sent_on_a_later_failure(self):
        sent = {"down": [], "up": []}
        answers = iter([False, True])            # floor, then sent
        p, state = self._provider(
            lambda r: sent["down"].append(r) or next(answers),
            lambda: sent["up"].append(1))
        for _ in range(2):
            with pytest.raises(Exception):
                p.refresh()
        assert len(sent["down"]) == 2            # tried again
        with pytest.raises(Exception):
            p.refresh()
        assert len(sent["down"]) == 2            # sent: not again
        state["fail"] = False
        p.refresh()
        assert sent["up"] == [1]

    def test_no_recovered_after_an_outage_nobody_was_told(self):
        sent = {"up": []}
        p, state = self._provider(lambda r: False,
                                  lambda: sent["up"].append(1))
        with pytest.raises(Exception):
            p.refresh()
        state["fail"] = False
        p.refresh()
        assert sent["up"] == []


# ── E2E-M07: an unexpected stop is shown for 24 hours ──

class TestRecoveryNotice:
    def test_shown_on_the_status_and_dropped_after_a_day(self, tmp_path,
                                                         data_dir):
        app = _app(tmp_path)
        with _client(app) as client:
            h = _h(_admin(client))
            app.state.recovery_notice = (
                time.time(), "The service stopped unexpectedly (test)")
            warnings = client.get("/api/v1/system/status",
                                  headers=h).json()["startup_warnings"]
            assert "The service stopped unexpectedly (test)" in warnings
            app.state.recovery_notice = (
                time.time() - 25 * 3600, "The service stopped unexpectedly (old)")
            warnings = client.get("/api/v1/system/status",
                                  headers=h).json()["startup_warnings"]
            assert not any("(old)" in w for w in warnings)

    def test_agent_keeps_the_notice_across_a_rebuild(self):
        from desktop.agent import AgentRunner
        runner = AgentRunner.__new__(AgentRunner)
        runner.logger = None
        runner.service = SimpleNamespace(app=SimpleNamespace(
            state=SimpleNamespace(audit=None)))
        runner._report_recovery({"started_at": "2026-10-05T07:00:00",
                                 "pid": 1})
        note = runner.service.app.state.recovery_notice
        assert "stopped unexpectedly" in note[1] and "JST" in note[1]
        runner.service.app = SimpleNamespace(state=SimpleNamespace())
        runner._show_recovery_notice()
        assert runner.service.app.state.recovery_notice == note


# ── E2E-M09, L17, L18, L27, L28, L31 (page) ──

class TestSystemAndDashboardPage:
    def test_dashboard_lists_servicenow_and_cyberark_trouble(self):
        body = _function(APP, "serviceAlerts")
        for text in ("ServiceNow is failing", "not written: update those tickets",
                     "CyberArk is unavailable", "polling is paused"):
            assert text in body
        assert "concat(serviceAlerts(st))" in _function(APP, "loadDashProblems")

    def test_system_page_reads_itself_again(self):
        assert "LOADERS.system({ auto: true })" in _function(APP, "switchView")
        assert "if (!auto) loadLog();" in APP

    def test_one_wording_for_the_mainframe_window(self):
        assert "(windowState(av))" in APP                # Dashboard
        assert "const ws = windowState(av);" in APP      # System page
        assert "'Closing'" in _function(APP, "windowState")

    def test_restart_wording_follows_pending_settings(self):
        body = _function(APP, "restartService")
        assert "'Restart the service?'" in body and "'Restarted.'" in body

    def test_configuration_files_show_no_server_path(self):
        body = _function(APP, "viewConfigFile")
        assert "f.path" not in body
        assert "'Location'" not in APP

    def test_resend_refreshes_the_banner_and_refresh_reports_cyberark(self):
        assert "LOADERS.system({ auto: true });" in APP
        assert "CyberArk did not deliver the password" in APP


class TestMailOutageIsAWarning:
    def test_delivery_problem_is_a_warning(self, tmp_path, data_dir):
        app = _app(tmp_path)
        app.state.live_warnings.append(lambda: "E-mail is not being delivered")
        with _client(app) as client:
            st = client.get("/api/v1/system/status",
                            headers=_h(_admin(client))).json()
            assert "E-mail is not being delivered" in st["startup_warnings"]
            assert "E-mail is not being delivered" not in st["startup_problems"]

    def test_outbox_keeps_attempts_and_error(self, tmp_path):
        from email.message import EmailMessage
        from src.modules.notifications.outbox import Outbox
        box = Outbox(tmp_path / "outbox", keep_hours=24, transport=None)
        msg = EmailMessage()
        msg["Subject"] = "s"
        msg.set_content("x")
        assert box.put(msg, ["a@example.com"], kind="t", attempts=4,
                       last_error="535 refused")
        meta = json.loads(next((tmp_path / "outbox").glob("*.json"))
                          .read_text(encoding="utf-8"))
        assert meta["attempts"] == 4 and meta["last_error"] == "535 refused"


class TestCyberArkCard:
    def test_plain_wording_and_tls_notice(self, tmp_path, data_dir):
        app = _app(tmp_path)
        app.state.cyberark = SimpleNamespace(
            s=SimpleNamespace(verify_tls=False, base_url="http://127.0.0.1"),
            status=lambda: {"available": False, "last_error":
                            "CyberArk availability check failed (Inactive) "
                            "— fetch skipped"})
        with _client(app) as client:
            st = client.get("/api/v1/system/status",
                            headers=_h(_admin(client))).json()
            assert "(Inactive)" not in st["cyberark"]["last_error"]
            assert "availability check" in st["cyberark"]["last_error"]
            codes = {n["code"] for n in st["security"]}
            assert "cyberark_tls" in codes


# ── E2E-M10 (D-05): polling waits after repeated sign-in rejections ──

class TestServiceNowSignInHold:
    def _poller(self, tmp_path, monkeypatch):
        from desktop import snow_poller
        monkeypatch.setattr(snow_poller.runtime, "data_path",
                            lambda name: tmp_path / name)
        return snow_poller.ServiceNowPoller(
            SimpleNamespace(state=SimpleNamespace()), "http://x")

    def test_third_rejection_holds_and_a_save_releases(self, tmp_path,
                                                       monkeypatch):
        p = self._poller(tmp_path, monkeypatch)
        reason = ("sign-in rejected — ServiceNow refused the bot account's "
                  "credentials (HTTP 401)")
        assert p._auth_check(reason, True) == reason
        p._auth_check(reason, True)
        held = p._auth_check(reason, True)
        assert p.auth_held and "polling paused" in held
        p._save_state()
        again = self._poller(tmp_path, monkeypatch)
        assert again.auth_held                       # survives a restart

    def test_a_403_or_a_network_error_never_holds(self, tmp_path,
                                                  monkeypatch):
        p = self._poller(tmp_path, monkeypatch)
        for _ in range(5):
            p._auth_check("sign-in rejected — ServiceNow refused the bot "
                          "account's credentials (HTTP 403)", True)
            p._auth_check("not reachable — the instance could not be "
                          "reached", True)
        assert not p.auth_held

    def test_a_success_resets_the_count(self, tmp_path, monkeypatch):
        p = self._poller(tmp_path, monkeypatch)
        reason = "sign-in rejected — (HTTP 401)"
        p._auth_check(reason, True)
        p._auth_check(reason, True)
        p._auth_check("", False)
        p._auth_check(reason, True)
        assert not p.auth_held

    def test_write_back_does_not_retry_a_rejected_sign_in(self):
        from src.integrations.servicenow.client import ServiceNowError
        from src.integrations.servicenow.config import ServiceNowSettings
        from src.integrations.servicenow.writeback import TicketCloseout
        from tests.unit.test_servicenow_module import _Req, _Txn

        class _Rejecting:
            calls = 0

            def get_records(self, *a, **k):
                _Rejecting.calls += 1
                raise ServiceNowError("ServiceNow answered 401")

        s = ServiceNowSettings(instance_url="https://x", username="bot",
                               password="p", table="sc_task")
        co = TicketCloseout(logger=_Log(), audit=None,
                            settings_loader=lambda: s,
                            client_factory=lambda st: _Rejecting(),
                            async_send=False, sleep_func=lambda d: None)
        co.handle_completion(_Txn("done"), _Req(), {})
        assert _Rejecting.calls == 1


# ── E2E-M11: a refused assignment is an error once, then a warning ──

class TestRefusedAssignment:
    def test_first_refusal_is_an_error(self):
        from src.integrations.servicenow.config import ServiceNowSettings
        from src.integrations.servicenow.connector import ServiceNowConnector

        class _Client:
            def user_sys_id(self, ident):
                return "b" * 32

            def get_records(self, *a, **k):
                return [{"sys_id": "a" * 32, "active": "true", "state": "1",
                         "assigned_to": ""}]

            def claim(self, *a, **k):
                raise Exception("ServiceNow answered 403 Forbidden")

        log = _Log()
        c = ServiceNowConnector(ServiceNowSettings(
            instance_url="https://x", username="bot", password="p",
            table="sc_task", assignment_mode="assignment_group",
            assignment_group="g"), client=_Client(), logger=log)
        audit = []
        c.audit_hook = lambda e, d: audit.append(e)
        seen = set()
        c.reported = SimpleNamespace(
            first_time=lambda n, f: (n, f) not in seen and not seen.add((n, f)))
        c._take("a" * 32, "SCTASK1", "fp")
        c._take("a" * 32, "SCTASK1", "fp")
        levels = [lvl for lvl, m in log.lines if "SCTASK1" in m
                  and "assign" in m and lvl in ("error", "warning")]
        assert levels[0] == "error" and levels[-1] == "warning"
        assert audit.count("servicenow_ticket_claim_failed") == 1

    def test_failures_are_never_information(self, tmp_path):
        from desktop.snow_poller import ServiceNowPoller
        audit = _Audit()
        p = ServiceNowPoller.__new__(ServiceNowPoller)
        p.app = SimpleNamespace(state=SimpleNamespace(audit=audit))
        p._audit_event("servicenow_ticket_claim_failed", {})
        p._audit_event("servicenow_ticket_claimed", {})
        assert [e.severity for e in audit.events] == ["WARNING", "INFO"]


# ── E2E-L12: the closing comment's time ──

class TestClosingTime:
    def test_completed_at_in_jst(self):
        from src.integrations.servicenow.writeback import TicketCloseout
        co = TicketCloseout(logger=None, audit=None)
        txn = SimpleNamespace(completed_at="2026-10-05T11:39:56+00:00")
        ctx = co._context(txn, SimpleNamespace(metadata={}), {})
        assert ctx["completed_at"] == "2026-10-05 20:39:56 JST"


# ── E2E-L13: preview applies the duplicate check within itself ──

class TestPreviewDuplicates:
    def test_second_ticket_with_the_same_work_is_a_duplicate(self):
        import random
        from tests.integration.test_snow_selection_fixes_2026_10_04 import (
            TicketStore, _connector)
        store = TicketStore(random.Random(7))
        same = dict(account="2003AAA", employee="Mika Mori",
                    employee_id="1712345", affiliation="01634")
        first = store.create_sailpoint("add", tracking="T-A", **same)
        second = store.create_sailpoint("add", tracking="T-B", **same)
        c, _, _ = _connector(store, assignment_mode="assigned_to")
        by = {t["ticket"]: t for t in c.poll_once(dry_run=True)["tickets"]}
        assert by[first["number"]]["action"] == "queue"
        assert by[second["number"]]["action"] == "skip"
        assert by[second["number"]]["reason"].startswith(
            f"duplicate of {first['number']}")
        # Without a duplicate window, both are new work, as in a poll.
        c.s.duplicate_window_days = 0
        actions = [t["action"] for t in c.poll_once(dry_run=True)["tickets"]]
        assert actions == ["queue", "queue"]


# ── E2E-L14: the cancel note now, and the hand-over ──

class TestCancelNote:
    def test_cancel_calls_the_ticket_hook(self, tmp_path):
        from fastapi.testclient import TestClient
        from src import create_app
        app = create_app(make_config(tmp_path, terminal_driver="mock",
                                     dispatcher_enabled=False,
                                     ocr_enabled=False))
        noted = []
        app.state.ticket_closeout.handle_completion = \
            lambda txn, req, res: noted.append(req.request_id)
        with TestClient(app) as client:
            rid = client.post("/api/v1/requests", json=VALID).json()["request_id"]
            assert client.delete(f"/api/v1/requests/{rid}").status_code == 200
        assert noted == [rid]

    def test_cancelled_ticket_is_handed_to_the_group(self):
        from src.integrations.servicenow.config import ServiceNowSettings
        from src.integrations.servicenow.writeback import TicketCloseout
        from tests.unit.test_servicenow_module import _Req, _Txn

        class _Client:
            calls = []

            def get_records(self, *a, **k):
                return [{"sys_id": "abc123"}]

            def reassign(self, sys_id, group, note=""):
                self.calls.append(("reassign", group, note))

            def add_work_note(self, sys_id, note, table=""):
                self.calls.append(("note", note))

        s = ServiceNowSettings(instance_url="https://x", username="bot",
                               password="p", table="sc_task",
                               cancel_note="Cancelled {ticket_id}",
                               reject_reassign_group="IAM Team")
        co = TicketCloseout(logger=_Log(), audit=None,
                            settings_loader=lambda: s,
                            client_factory=lambda st: _Client(),
                            async_send=False, sleep_func=lambda d: None)
        co.handle_completion(_Txn("cancelled"), _Req(), {})
        assert _Client.calls == [("reassign", "IAM Team", "Cancelled SCTASK0007")]


# ── E2E-L33 (D-06): a skipped check before execution is audited ──

class TestSkippedCheckIsAudited:
    def test_unreachable_servicenow_writes_a_warning(self):
        from src.integrations.servicenow.config import ServiceNowSettings
        from src.integrations.servicenow.writeback import TicketCloseout
        from tests.unit.test_servicenow_module import _Req

        class _Down:
            def get_records(self, *a, **k):
                raise Exception("Network error: timed out")

        audit = _Audit()
        s = ServiceNowSettings(instance_url="https://x", username="bot",
                               password="p", table="sc_task")
        co = TicketCloseout(logger=_Log(), audit=audit,
                            settings_loader=lambda: s,
                            client_factory=lambda st: _Down())
        assert co.pre_execute_check(_Req()) == ""        # still runs
        ev = [e for e in audit.events
              if e.action == "servicenow_ticket_check_skipped"]
        assert len(ev) == 1 and ev[0].severity == "WARNING"


# ── E2E-L08, L09, L10: console requests ──

class TestConsoleRequests:
    def test_ticket_number_required_on_the_console_only(self, tmp_path,
                                                        data_dir):
        with _client(_app(tmp_path, dispatcher_enabled=False)) as client:
            h = _h(_admin(client))
            r = client.post("/api/v1/console/requests", headers=h, json=VALID)
            assert r.status_code == 400
            assert "ticket number" in r.json()["detail"]
            assert client.post("/api/v1/console/requests", headers=h, json={
                **VALID, "ticket_id": "T-1"}).status_code == 202
            assert client.post("/api/v1/requests", json={
                **VALID, "employee_code": "7654321"}).status_code == 202

    def test_messages_use_the_form_labels(self):
        from src.modules.intake.schemas import (SubmitRequest,
                                                validate_request_format)
        problems = validate_request_format(SubmitRequest(
            operation="provision", affiliation_code="ABC",
            employee_code="123"))
        assert problems[0].startswith("Affiliation code must be")
        assert problems[1].startswith("Employee code must be")

    def test_console_typing_mistake_sends_no_e_mail(self, tmp_path, data_dir,
                                                    monkeypatch):
        import src as app_module
        sent = []
        monkeypatch.setattr(app_module, "build_rejection_alerter",
                            lambda **k: SimpleNamespace(
                                notifier=SimpleNamespace(audit=None),
                                request_rejected=lambda *a, **kw: sent.append(a[0])))
        with _client(_app(tmp_path, dispatcher_enabled=False)) as client:
            h = _h(_admin(client))
            r = client.post("/api/v1/console/requests", headers=h, json={
                **VALID, "ticket_id": "T-2", "affiliation_code": "ABC"})
            assert r.status_code == 400 and sent == []
            # A program's rejected request is still e-mailed.
            r = client.post("/api/v1/requests", json={
                **VALID, "affiliation_code": "ABC"})
            assert r.status_code == 400 and sent == ["VALIDATION FAILED"]

    def test_duration_is_rounded(self):
        from src.modules.notifications.transaction_alerts import audit_rows
        txn = SimpleNamespace(duration_seconds=28.847848)
        rows = dict(audit_rows(txn))
        assert "28.8" in rows.values()


# ── E2E-L10 (b): one e-mail per failed transaction ──

class TestTransactionFailureLines:
    def test_step_failure_lines_are_not_e_mailed_separately(self):
        src = (ROOT / "src" / "__init__.py").read_text(encoding="utf-8")
        assert "_transaction_failure_line" in src
        assert '"[NG] Failed: " in text' in src


# ── E2E-L15: the submitter in the history export ──

class TestSubmittedBy:
    def test_console_submission_is_exported_with_its_submitter(
            self, tmp_path, data_dir):
        with _client(_app(tmp_path, dispatcher_enabled=False)) as client:
            h = _h(_admin(client))
            rid = client.post("/api/v1/console/requests", headers=h, json={
                **VALID, "ticket_id": "T-9",
                "metadata": {"submitted_by": "user:mallory"}}).json()["request_id"]
            row = client.app.state.queue_store.get(rid)
            assert row.metadata["submitted_by"] == "user:alice"
        from src.modules.console.metrics import TRANSACTION_EXPORT_COLUMNS
        assert "submitted_by" in TRANSACTION_EXPORT_COLUMNS
        assert "operator" in TRANSACTION_EXPORT_COLUMNS        # name kept


# ── E2E-L16: test e-mail to the Default recipients ──

class TestTestMailRecipients:
    def test_blank_recipient_uses_the_default_recipients(self, tmp_path,
                                                         data_dir,
                                                         monkeypatch):
        monkeypatch.setenv("ALERT_TO", "ops@example.com")
        with _client(_app(tmp_path)) as client:
            r = client.post("/api/v1/system/test-email",
                            headers=_h(_admin(client)),
                            json={"send": True, "to": ""}).json()
            assert r.get("error") != "Enter a recipient address."
        assert "read('ALERT_TO')" in APP


# ── E2E-L19: a role grants something ──

class TestRoles:
    def test_empty_role_is_refused(self, tmp_path, data_dir):
        with _client(_app(tmp_path)) as client:
            h = _h(_admin(client))
            r = client.post("/api/v1/admin/roles", headers=h,
                            json={"name": "empty", "permissions": []})
            assert r.status_code == 400
            assert "at least one permission" in r.json()["detail"]
            assert client.post("/api/v1/admin/roles", headers=h, json={
                "name": "audit", "permissions": ["audit.view"]}
                ).status_code == 201
            assert client.patch("/api/v1/admin/roles/audit", headers=h,
                                json={"permissions": []}).status_code == 400
            r = client.post("/api/v1/admin/roles", headers=h,
                            json={"name": "a", "permissions": ["audit.view"]})
            assert r.status_code == 422
            assert "2 to 40 characters" in r.text
        assert "Choose at least one permission." in _function(APP, "saveRole")
        assert 'id="nr-name-rule"' in INDEX


# ── E2E-L24: a NUL in an evidence name ──

class TestEvidenceNames:
    def test_nul_is_not_found(self, tmp_path, data_dir):
        with _client(_app(tmp_path, dispatcher_enabled=False)) as client:
            h = _h(_admin(client))
            rid = client.post("/api/v1/requests", json=VALID).json()["request_id"]
            assert client.get(f"/api/v1/console/evidence/{rid}/a%00.png",
                              headers=h).status_code == 404
            assert client.get("/api/v1/console/evidence/a%00b",
                              headers=h).status_code == 404


# ── E2E-L26: a generated password is not kept after a failure ──

class TestGeneratedPassword:
    def test_generated_is_erased_supplied_is_kept(self, tmp_path):
        from src.core.db import Database
        from src.modules.intake.models import ProcessingRequest
        from src.modules.queue.services import QueueStore
        db = Database.from_config(make_config(tmp_path))
        try:
            q = QueueStore(db)
            gen = ProcessingRequest(operation="provision",
                                    affiliation_code="30822",
                                    employee_code="1217036",
                                    password="Gen@1234",
                                    metadata={"password_generated": True})
            sup = ProcessingRequest(operation="provision",
                                    affiliation_code="30823",
                                    employee_code="1217037",
                                    password="Sup@1234",
                                    metadata={"password_supplied": True})
            for r in (gen, sup):
                q.enqueue(r)
                q.dequeue_oldest(worker_id=1)
                q.mark_complete(r.request_id, "failed", error="x")
            assert q.get(gen.request_id).password == ""
            assert q.get(sup.request_id).password == "Sup@1234"
        finally:
            db.close()


# ── E2E-L29: the terminal check's own ID in the log ──

class TestTerminalCheckLogId:
    def test_check_sets_and_clears_its_id(self):
        src = (ROOT / "src" / "rpa" / "terminal_check.py").read_text(
            encoding="utf-8")
        assert "logger.set_transaction(check_id)" in src
        assert "logger.set_transaction(None)" in src


# ── E2E-L04: bot steps keep the time they ran ──

class TestStepTimes:
    def test_step_time_is_the_drivers_in_jst(self):
        from datetime import datetime
        from src.modules.queue.dispatcher import _step_time
        local = datetime(2026, 10, 5, 7, 49, 50).isoformat()
        out = _step_time(local)["occurred_at"]
        assert out.endswith("+09:00")
        assert datetime.fromisoformat(out) == \
            datetime.fromisoformat(local).astimezone()
        assert _step_time("") == {} and _step_time("garbage") == {}

    def test_traces_carry_their_own_time(self, tmp_path):
        from src.modules.queue.dispatcher import Dispatcher
        audit = _Audit()
        d = Dispatcher.__new__(Dispatcher)
        d.audit = audit
        d._audit_error_trace = lambda *a: None
        req = SimpleNamespace(request_id="r1", ticket_id="T", operation="p",
                              employee_code="1217036")
        d._audit_rpa_traces(req, {
            "action_trace": [{"action": "type", "at": "2026-10-05T07:49:50.123"}],
            "screen_trace": [{"path": "ok",
                              "captured_at": "2026-10-05T07:49:51"}]},
            "done")
        times = [e.fields.get("occurred_at") for e in audit.events
                 if e.category in ("rpa_action", "rpa_screen")]
        assert len(times) == 2 and all(t and t.endswith("+09:00")
                                       for t in times)


# ── E2E-L32: API description never with the real terminal ──

class TestApiDescription:
    def test_rule_excludes_the_real_drivers(self):
        src = (ROOT / "src" / "__init__.py").read_text(encoding="utf-8")
        block = src[src.index("expose_docs = ("):src.index("app = FastAPI(")]
        assert '"pywinauto", "pyautogui", "tn3270"' in block


# ── E2E-M08 (D-04): a rejected password is not typed again ──

class TestRejectedPasswordNotRetried:
    def _env(self, tmp_path):
        from src.core.db import Database
        from src.core.retry import RetryPolicy
        from src.modules.audit.services import TransactionStore
        from src.modules.intake.models import ProcessingRequest
        from src.modules.queue.dispatcher import Dispatcher
        from src.modules.queue.services import QueueStore
        cfg = make_config(tmp_path)
        db = Database.from_config(cfg)
        q = QueueStore(db)

        class _Exec:
            def __init__(self):
                self.calls = 0
                self.credentials = SimpleNamespace(password="Old@1234")

            def execute(self, request):
                self.calls += 1
                return {"status": "failed", "error_type": "system",
                        "error": "password rejected",
                        "error_id": "LOGIN_PASSWORD_INCORRECT"}

        ex = _Exec()
        d = Dispatcher(q, TransactionStore(db), RetryPolicy(max_attempts=3),
                       executor=ex, cfg=cfg,
                       pending_path=tmp_path / "pending.jsonl",
                       sleep=lambda s: None)
        r = ProcessingRequest(operation="provision", affiliation_code="30822",
                              employee_code="1217036", password="Abc@1234")
        q.enqueue(r)
        return db, q, d, ex, r.request_id

    def _due(self, q, rid):
        with q.db.connect() as conn:
            conn.execute("UPDATE request_queue SET next_attempt_at = '' "
                         "WHERE request_id = ?", (rid,))

    def test_same_password_fails_at_once(self, tmp_path):
        db, q, d, ex, rid = self._env(tmp_path)
        try:
            d._tick()
            assert q.get(rid).status == "queued"
            self._due(q, rid)
            d._tick()
            row = q.get(rid)
            assert ex.calls == 1 and row.status == "failed"
            assert "Not retried" in row.error
        finally:
            db.close()

    def test_a_new_password_is_tried(self, tmp_path):
        db, q, d, ex, rid = self._env(tmp_path)
        try:
            d._tick()
            ex.credentials.password = "New@5678"         # CyberArk delivered
            self._due(q, rid)
            d._tick()
            assert ex.calls == 2
        finally:
            db.close()


# ── E2E-M04: the service account check with the simulated terminal ──
# (test_system_api.py: "needed" is False and the check is ok.)

class TestSetupChecklistPage:
    def test_not_needed_is_shown(self):
        assert "c.needed === false ? 'Not needed'" in APP


# ── E2E-L01, L02: the setup assistant ──

class TestSetupAssistant:
    def test_host_probe_and_terminal_test_are_told_apart(self):
        assert "'no-host'" in APP
        assert "WZ.tests.terminal" in APP
        assert "host probe only" in APP

    def test_unchanged_page_is_kept_and_steps_open(self):
        assert "kept as configured" in APP
        body = _function(APP, "renderWizardSteps")
        assert "el('button', 'wzstep'" in body and "chip.onclick" in body


# ── E2E-L05, L06, L07, L20, L21, L22, L30: page wording ──

class TestPageWording:
    def test_audit_detail_and_product_names(self):
        assert "JSON.stringify(e.detail).slice" not in APP
        assert "eventDetailText(e.detail)" in APP
        assert "'ServiceNow'" in _function(KIT, "humanize")

    def test_request_drawer_in_words(self):
        assert "'Commit sent (JST)'" in APP
        assert "function noticesText(" in APP

    def test_needs_verification_and_waiting_to_retry(self):
        body = _function(APP, "statusTag")
        assert "Needs verification" in body and "Waiting to retry" in body
        assert APP.count("statusTag(r.status, r)") >= 2
        assert '<option value="unconfirmed">' in INDEX

    def test_read_only_without_settings_edit_and_no_access_message(self):
        assert "if (!may('settings.edit')) field.disabled = true;" in APP
        assert "You do not have access to that page" in APP
        assert 'id="route-msg"' in INDEX

    def test_delete_messages(self):
        assert "was deleted.`" in APP
        assert "async function act1(path, method, msgId, reload, btn, done)" in APP

    def test_ended_session_is_noticed_and_explained(self):
        body = _function(APP, "sessionTick")
        assert "api('/auth/me')" in body
        assert "Your session has ended. Sign in again." in _function(APP, "signOut")

    def test_screen_reading_titles_and_page_sizes(self):
        assert "'Machine: Screen reading': 'Screen reading (start-up)'" in APP
        assert ".sort((a, b) => a - b)" in KIT


# ── D-01: the open request API is shown for every driver ──
# (test_f7_security_2026_10_04.py: a warning with the mock driver.)

class TestStarterSettings:
    def test_setup_script_says_the_starter_is_for_testing(self):
        script = (ROOT / "Setup_Prerequisites.ps1").read_text(encoding="utf-8")
        assert "Starter settings for TESTING" in script
        assert "Add-Result 'Production' 'INFO'" in script


# ── D-02 / E2E-M02: the registration notice and the password e-mail ──

class TestPasswordNotice:
    def test_notice_when_the_password_e_mail_is_off(self, tmp_path, data_dir,
                                                    monkeypatch):
        from src.modules.notifications import ticket_reports
        monkeypatch.setattr(ticket_reports, "load_ticket_report_config",
                            lambda *a, **k: SimpleNamespace(
                                txn_enabled=True, send_registration=True,
                                send_password=False))
        with _client(_app(tmp_path)) as client:
            codes = {n["code"] for n in client.get(
                "/api/v1/system/status",
                headers=_h(_admin(client))).json()["security"]}
            assert "password_notice_off" in codes


# ── D-08: own password change; an administrator reset is reported ──

class TestPasswordChanges:
    def test_header_link(self):
        assert 'id="chpw"' in INDEX
        assert "showGate('change', { voluntary: true })" in APP

    def test_admin_reset_of_an_admin_is_reported(self, tmp_path, data_dir,
                                                 caplog):
        with _client(_app(tmp_path)) as client:
            admin = _admin(client)
            client.post("/api/v1/admin/users", headers=_h(admin), json={
                "username": "bob", "password": PASSWORD, "role": "admin"})
            bob = [u for u in client.get("/api/v1/admin/users",
                                         headers=_h(admin)).json()["users"]
                   if u["username"] == "bob"][0]
            with caplog.at_level(logging.ERROR):
                r = client.patch(f"/api/v1/admin/users/{bob['user_id']}",
                                 headers=_h(admin),
                                 json={"password": "Another#4821x"})
            assert r.status_code == 200
            assert any("reset the password of administrator 'bob'" in m
                       for m in caplog.messages)


# ── D-09: the service account's code stays out of the log ──

class TestServiceAccountCodeInLog:
    def test_log_line_has_no_code(self):
        src = (ROOT / "src" / "rpa" / "screens" / "navigator.py").read_text(
            encoding="utf-8")
        assert "login affiliation = " not in src


# ── E2E-L03: times in JST ──

class TestTimesInJst:
    def test_status_and_poller_times(self, tmp_path, data_dir):
        with _client(_app(tmp_path)) as client:
            st = client.get("/api/v1/system/status",
                            headers=_h(_admin(client))).json()
            assert st["started_at"].endswith("+09:00")

    def test_time_zone_warning(self, monkeypatch):
        import src
        monkeypatch.setattr("time.localtime",
                            lambda *a: SimpleNamespace(tm_gmtoff=9 * 3600))
        assert src.server_time_zone_warning() == ""
        monkeypatch.setattr("time.localtime",
                            lambda *a: SimpleNamespace(tm_gmtoff=-4 * 3600))
        assert "UTC-4" in src.server_time_zone_warning()
