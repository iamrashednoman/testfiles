"""Console read APIs: dashboard, error rules, evidence, and the role
and provisional-password gates on the routes that CHANGE work.

Evidence is the sensitive part. A provision screenshot shows the new
account's password in CLEAR TEXT — the terminal renders FID row 107
unmasked and the evidence replicates it — so these tests pin who may
read it, what may be served, and that every read is audited.
"""
import time

import pytest

from tests.conftest import make_config

VALID = {"operation": "provision", "affiliation_code": "30822",
         "employee_code": "1217036", "password": "FUJI@33F"}
PASSWORD = "CorrectHorse42"


_real_sleep = time.sleep


@pytest.fixture(autouse=True)
def fast_sleep(monkeypatch):
    """No-op the workflows' terminal pacing delays.

    Without this each mock transaction spends ~20s in post_entry_delay
    sleeps and this file alone takes seven minutes.
    """
    monkeypatch.setattr("time.sleep", lambda s: None)


def _client(tmp_path, **overrides):
    from fastapi.testclient import TestClient
    from src import create_app
    cfg = make_config(tmp_path, dispatcher_enabled=True,
                      terminal_driver="mock",
                      log_dir=str(tmp_path / "logs"), **overrides)
    return TestClient(create_app(cfg))


def _auth(t):
    return {"Authorization": f"Bearer {t}"}


def _admin(client):
    client.post("/api/v1/auth/bootstrap",
                json={"username": "alice", "password": PASSWORD})
    return client.post("/api/v1/auth/login", json={
        "username": "alice", "password": PASSWORD}).json()["access_token"]


def _user(client, admin_token, username, role):
    """Create a user AND complete their forced password change."""
    client.post("/api/v1/admin/users", headers=_auth(admin_token),
                json={"username": username, "password": PASSWORD,
                      "role": role})
    t = client.post("/api/v1/auth/login", json={
        "username": username, "password": PASSWORD}).json()["access_token"]
    client.post("/api/v1/auth/password", headers=_auth(t),
                json={"current_password": PASSWORD,
                      "new_password": "TheirOwn7777"})
    return client.post("/api/v1/auth/login", json={
        "username": username,
        "password": "TheirOwn7777"}).json()["access_token"]


def _run_one(client, token):
    rid = client.post("/api/v1/requests", json=VALID).json()["request_id"]
    for _ in range(400):
        row = client.get(f"/api/v1/requests/{rid}",
                         headers=_auth(token)).json()
        if row["status"] not in ("queued", "running"):
            return rid
        _real_sleep(0.02)
    return rid


class TestDashboard:
    def test_summary_is_one_round_trip(self, tmp_path):
        """The window polls this every few seconds against a service
        that is also driving a terminal — it must not need five
        calls."""
        with _client(tmp_path) as client:
            body = client.get("/api/v1/console/summary",
                              headers=_auth(_admin(client))).json()
            for key in ("service", "database", "engine", "driver",
                        "dispatcher", "availability", "queue",
                        "statistics", "result_codes", "recent", "user"):
                assert key in body, key

    def test_requires_a_session(self, tmp_path):
        with _client(tmp_path) as client:
            _admin(client)
            assert client.get(
                "/api/v1/console/summary").status_code == 401


class TestErrorRules:
    def test_lists_the_live_catalogue_with_its_hash(self, tmp_path):
        """Compliance has to prove WHICH rules were live."""
        with _client(tmp_path) as client:
            body = client.get("/api/v1/console/error-rules",
                              headers=_auth(_admin(client))).json()
            assert body["count"] >= 5
            assert body["digest"]
            ids = {r["id"] for r in body["rules"]}
            assert {"CENTER_NOT_READY", "LOGIN_PASSWORD_INCORRECT",
                    "LOGIN_OPERATOR_NOT_REGISTERED"} <= ids

    def test_rules_come_back_priority_ordered(self, tmp_path):
        with _client(tmp_path) as client:
            rules = client.get("/api/v1/console/error-rules",
                               headers=_auth(_admin(client))
                               ).json()["rules"]
            assert [r["priority"] for r in rules] == \
                sorted(r["priority"] for r in rules)


class TestEvidenceAccess:
    def test_lists_captures_with_their_text_mirrors(self, tmp_path):
        with _client(tmp_path) as client:
            token = _admin(client)
            rid = _run_one(client, token)
            body = client.get(f"/api/v1/console/evidence/{rid}",
                              headers=_auth(token)).json()
            assert body["count"] > 0
            assert all(c["text"] for c in body["captures"])
            assert all(c["step"] for c in body["captures"])

    def test_flags_blank_placeholder_captures(self, tmp_path):
        """A folder can LOOK complete while a capture is a 76-byte
        placeholder — the operator must be able to see that."""
        with _client(tmp_path) as client:
            token = _admin(client)
            rid = _run_one(client, token)
            body = client.get(f"/api/v1/console/evidence/{rid}",
                              headers=_auth(token)).json()
            # The mock driver writes placeholders by design.
            assert body["placeholders"] == body["count"]
            assert all(c["placeholder"] for c in body["captures"])

    def test_serves_the_png_and_the_txt(self, tmp_path):
        with _client(tmp_path) as client:
            token = _admin(client)
            rid = _run_one(client, token)
            first = client.get(f"/api/v1/console/evidence/{rid}",
                               headers=_auth(token)).json()["captures"][0]
            png = client.get(
                f"/api/v1/console/evidence/{rid}/{first['name']}",
                headers=_auth(token))
            assert png.status_code == 200
            assert png.headers["content-type"] == "image/png"
            txt = client.get(
                f"/api/v1/console/evidence/{rid}/{first['text']}",
                headers=_auth(token))
            assert txt.status_code == 200
            assert "FINESIII SCREEN CAPTURE" in txt.text

    def test_unauthenticated_access_is_refused(self, tmp_path):
        """Evidence contains PII and, on a provision, a password in
        clear text."""
        with _client(tmp_path) as client:
            token = _admin(client)
            rid = _run_one(client, token)
            assert client.get(
                f"/api/v1/console/evidence/{rid}").status_code == 401
            assert client.get(
                f"/api/v1/console/evidence/{rid}/001_x.png"
            ).status_code == 401

    @pytest.mark.parametrize("probe", [
        "../../../etc/passwd",
        "..%2f..%2fetc%2fpasswd",
        "....//....//etc/passwd",
        "%2e%2e%2f%2e%2e%2fetc%2fpasswd",
    ])
    def test_path_traversal_is_refused(self, tmp_path, probe):
        with _client(tmp_path) as client:
            token = _admin(client)
            rid = _run_one(client, token)
            r = client.get(f"/api/v1/console/evidence/{rid}/{probe}",
                           headers=_auth(token))
            assert r.status_code in (403, 404, 415), r.status_code
            assert b"root:" not in r.content

    def test_only_png_and_txt_are_served(self, tmp_path):
        """The folder is the transaction's own, but the endpoint must
        not become a general file reader."""
        with _client(tmp_path) as client:
            token = _admin(client)
            rid = _run_one(client, token)
            # The listing no longer names the server folder (RQ-09,
            # 2026-10-03); the request's recorded folder is used.
            assert "path" not in client.get(
                f"/api/v1/console/evidence/{rid}",
                headers=_auth(token)).json()
            import pathlib
            path = client.app.state.queue_store.get(rid).evidence_path
            # No folder recorded by the simulated run: the request's own
            # folder under the evidence root, never the working folder
            # (the file used to be left in the source tree, 2026-10-04).
            folder = (pathlib.Path(path) if path else
                      pathlib.Path(client.app.state.config.evidence_dir) / rid)
            folder.mkdir(parents=True, exist_ok=True)
            (folder / "secrets.env").write_text("KEY=value")
            r = client.get(
                f"/api/v1/console/evidence/{rid}/secrets.env",
                headers=_auth(token))
            assert r.status_code == 415
            assert b"KEY=value" not in r.content

    def test_unknown_request_is_404(self, tmp_path):
        with _client(tmp_path) as client:
            assert client.get("/api/v1/console/evidence/req_nope",
                              headers=_auth(_admin(client))
                              ).status_code == 404

    def test_every_read_is_audited(self, tmp_path):
        """Who looked at a screenshot containing a password, and
        when."""
        with _client(tmp_path, audit_enabled=True, audit_backend="sqlite",
                     audit_sqlite_path=str(tmp_path / "audit.db"),
                     audit_spool_path=str(tmp_path / "spool.db"),
                     audit_flush_interval_seconds=0.05) as client:
            token = _admin(client)
            rid = _run_one(client, token)
            first = client.get(f"/api/v1/console/evidence/{rid}",
                               headers=_auth(token)).json()["captures"][0]
            client.get(f"/api/v1/console/evidence/{rid}/{first['name']}",
                       headers=_auth(token))

            deadline = time.time() + 5
            events = []
            while time.time() < deadline and not events:
                events = [e for e in client.get(
                    "/api/v1/audit/events?category=console&limit=50"
                ).json()["events"] if e["action"] == "evidence_viewed"]
                _real_sleep(0.1)
            assert events, "evidence read was not audited"
            assert events[0]["detail"]["actor"] == "alice"
            assert events[0]["severity"] == "WARNING"


class TestActionRoles:
    """retry and cancel change queued work; viewers must not."""

    def test_viewer_cannot_retry(self, tmp_path):
        with _client(tmp_path) as client:
            admin = _admin(client)
            rid = _run_one(client, admin)
            viewer = _user(client, admin, "vic", "viewer")
            r = client.post(f"/api/v1/requests/{rid}/retry",
                            headers=_auth(viewer))
            assert r.status_code == 403
            # The message names the missing PERMISSION now, which is
            # more actionable than a role name once roles are custom.
            assert "requests.retry" in r.json()["detail"]
            assert "viewer" in r.json()["detail"]

    def test_viewer_cannot_cancel(self, tmp_path):
        with _client(tmp_path) as client:
            admin = _admin(client)
            rid = _run_one(client, admin)
            viewer = _user(client, admin, "vic", "viewer")
            assert client.delete(f"/api/v1/requests/{rid}",
                                 headers=_auth(viewer)).status_code == 403

    def test_operator_gets_past_the_role_check(self, tmp_path):
        with _client(tmp_path) as client:
            admin = _admin(client)
            rid = _run_one(client, admin)
            operator = _user(client, admin, "opr", "operator")
            r = client.post(f"/api/v1/requests/{rid}/retry",
                            headers=_auth(operator))
            # 409 = a BUSINESS answer (already done), so auth passed.
            assert r.status_code in (202, 409), r.text

    def test_a_provisional_password_grants_nothing(self, tmp_path):
        """An operator who has not yet chosen their own password must
        not be able to act — the role check alone would let them."""
        with _client(tmp_path) as client:
            admin = _admin(client)
            rid = _run_one(client, admin)
            client.post("/api/v1/admin/users", headers=_auth(admin),
                        json={"username": "opr", "password": PASSWORD,
                              "role": "operator"})
            provisional = client.post("/api/v1/auth/login", json={
                "username": "opr", "password": PASSWORD
            }).json()["access_token"]
            r = client.post(f"/api/v1/requests/{rid}/retry",
                            headers=_auth(provisional))
            assert r.status_code == 428, r.text

    def test_the_machine_api_key_is_unaffected(self, tmp_path,
                                               monkeypatch):
        """The ServiceNow connector and the CLI use the API key and
        must keep working exactly as before."""
        monkeypatch.setenv("FINESIII_API_KEYS", "svc:secret-key-value")
        with _client(tmp_path, auth_enabled=True) as client:
            _admin(client)
            key = {"X-API-Key": "secret-key-value"}
            rid = client.post("/api/v1/requests", json=VALID,
                              headers=key).json()["request_id"]
            r = client.delete(f"/api/v1/requests/{rid}", headers=key)
            assert r.status_code in (200, 409), r.text
