"""PostgreSQL-backed integration tests.

Runs only when a local PostgreSQL server is reachable (skipped
otherwise, so the suite stays green on machines without Postgres).
Uses a throwaway database `finesiii_v3_test` created/dropped around
the module — the real finesiii_v3 database is never touched.

Exercises exactly what SQLite cannot: the psycopg pool, ?→%s
translation, FOR UPDATE SKIP LOCKED claiming, and the partial unique
index race guard — then the full e2e flow on the postgres engine.
"""
import subprocess
import time

import pytest

from tests.integration.test_terminal_e2e import TERMINAL_TIMEOUT

TEST_DB = "finesiii_v3_test"
TEST_URL = f"postgresql:///{TEST_DB}"


def _postgres_available() -> bool:
    try:
        return subprocess.run(
            ["pg_isready", "-h", "localhost"],
            capture_output=True, timeout=5,
        ).returncode == 0
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False


pytestmark = pytest.mark.skipif(
    not _postgres_available(),
    reason="local PostgreSQL not reachable (pg_isready failed)",
)

_real_sleep = time.sleep


@pytest.fixture(autouse=True)
def fast_sleep(monkeypatch):
    """No-op the ported workflows' terminal pacing delays."""
    monkeypatch.setattr("time.sleep", lambda s: None)


@pytest.fixture(scope="module")
def test_database():
    subprocess.run(["dropdb", "--if-exists", TEST_DB],
                   capture_output=True)
    created = subprocess.run(["createdb", TEST_DB], capture_output=True)
    if created.returncode != 0:
        pytest.skip(f"could not create {TEST_DB}: "
                    f"{created.stderr.decode()}")
    yield TEST_URL
    subprocess.run(["dropdb", "--if-exists", TEST_DB],
                   capture_output=True)


@pytest.fixture
def pg_cfg(tmp_path, test_database):
    from tests.conftest import make_config
    cfg = make_config(tmp_path, database_engine="postgres",
                      database_url=test_database,
                      log_dir=str(tmp_path / "logs"))
    # Fresh tables per test — the stores recreate them at init
    import psycopg
    with psycopg.connect(test_database) as conn:
        conn.execute("DROP TABLE IF EXISTS request_queue")
        conn.execute("DROP TABLE IF EXISTS transaction_history")
    return cfg


class TestPostgresQueue:
    def test_fifo_claim_uses_skip_locked(self, pg_cfg):
        from src.core.db import Database
        from src.modules.intake.models import ProcessingRequest
        from src.modules.queue.services import QueueStore

        db = Database.from_config(pg_cfg)
        assert db.dequeue_lock_clause == " FOR UPDATE SKIP LOCKED"
        try:
            store = QueueStore(db)
            first = ProcessingRequest(operation="provision",
                                      affiliation_code="30822",
                                      employee_code="1000001",
                                      password="FUJI@33F")
            second = ProcessingRequest(operation="provision",
                                       affiliation_code="30822",
                                       employee_code="1000002",
                                       password="FUJI@33F")
            assert store.enqueue(first)
            assert store.enqueue(second)

            claimed = store.dequeue_oldest(worker_id=1)
            assert claimed.request_id == first.request_id
            assert claimed.status == "running"
        finally:
            db.close()

    def test_partial_unique_index_blocks_race(self, pg_cfg):
        """The DB constraint catches the concurrent-duplicate race the
        app-level check cannot."""
        from src.core.db import Database
        from src.modules.intake.models import ProcessingRequest
        from src.modules.queue.services import QueueStore

        db = Database.from_config(pg_cfg)
        try:
            store = QueueStore(db)

            def make():
                return ProcessingRequest(operation="provision",
                                         affiliation_code="30822",
                                         employee_code="1217036",
                                         password="FUJI@33F",
                                         ticket_id="SCTASK900")

            assert store.enqueue(make()) is True
            assert store.enqueue(make()) is False    # unique violation

            # Terminal status frees the key for resubmission
            req = store.dequeue_oldest(worker_id=1)
            store.mark_complete(req.request_id, "failed", error="boom")
            assert store.enqueue(make()) is True
        finally:
            db.close()


class TestPostgresE2E:
    def test_full_flow_on_postgres(self, pg_cfg, tmp_path):
        """Submit → dispatcher → TerminalExecutor(MockDriver) →
        done/O-0000 → audit row — all on the postgres engine."""
        from fastapi.testclient import TestClient
        from tests.conftest import make_config
        from src import create_app

        cfg = make_config(tmp_path, database_engine="postgres",
                          database_url=pg_cfg.database_url,
                          dispatcher_enabled=True,
                          terminal_driver="mock",
                          log_dir=str(tmp_path / "logs"))
        with TestClient(create_app(cfg)) as client:
            rid = client.post("/api/v1/requests", json={
                "operation": "provision", "affiliation_code": "30822",
                "employee_code": "1217036", "password": "FUJI@33F",
            }).json()["request_id"]

            # Real OCR (the build venv) runs inference on every evidence
            # capture, so the same transaction takes far longer there.
            deadline = time.time() + TERMINAL_TIMEOUT
            status = ""
            while time.time() < deadline:
                status = client.get(
                    f"/api/v1/requests/{rid}").json()["status"]
                if status not in ("queued", "running"):
                    break
                _real_sleep(0.02)

            assert status == "done"
            row = client.get(f"/api/v1/requests/{rid}").json()
            assert row["result_code"] == "O-0000"
            assert row["password"] == ""
            txns = client.get("/api/v1/transactions").json()
            assert txns["count"] == 1
            assert txns["statistics"]["by_status"]["done"] == 1
