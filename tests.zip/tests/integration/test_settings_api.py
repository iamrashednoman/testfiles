"""Administrator settings: the overlay, its bounds, and the restart.

The property that matters: an install with NO overrides resolves
exactly as it did before this table existed, and nothing the UI can
send may exceed a limit the catalogue declares.
"""
import pytest

from tests.conftest import make_config

PASSWORD = "CorrectHorse42"


@pytest.fixture(autouse=True)
def fast_sleep(monkeypatch):
    monkeypatch.setattr("time.sleep", lambda s: None)


def _client(tmp_path, **overrides):
    from fastapi.testclient import TestClient
    from src import create_app
    cfg = make_config(tmp_path, dispatcher_enabled=False,
                      terminal_driver="mock",
                      log_dir=str(tmp_path / "logs"), **overrides)
    return TestClient(create_app(cfg, **overrides.pop("_app", {})))


def _auth(t):
    return {"Authorization": f"Bearer {t}"}


def _admin(client):
    client.post("/api/v1/auth/bootstrap",
                json={"username": "alice", "password": PASSWORD})
    return client.post("/api/v1/auth/login", json={
        "username": "alice", "password": PASSWORD}).json()["access_token"]


class TestCatalogue:
    def test_lists_editable_settings_grouped(self, tmp_path):
        with _client(tmp_path) as client:
            body = client.get("/api/v1/console/settings",
                              headers=_auth(_admin(client))).json()
            assert body["editable"] is True
            assert len(body["settings"]) > 20
            keys = {s["key"] for s in body["settings"]}
            assert "max_attempts" in keys
            assert "ERROR_ALERT_TO" in keys

    def test_deployment_identity_is_not_editable(self, tmp_path):
        """A UI must not be able to repoint the database, change the
        terminal driver, or move the evidence."""
        with _client(tmp_path) as client:
            keys = {s["key"] for s in client.get(
                "/api/v1/console/settings",
                headers=_auth(_admin(client))).json()["settings"]}
            for forbidden in ("database_url", "sqlite_path", "jwt_secret",
                              "terminal_driver", "evidence_dir",
                              "api_port"):
                assert forbidden not in keys, forbidden

    def test_secrets_are_never_returned(self, tmp_path):
        """The SMTP password is no longer a console setting (BUG-005):
        it is refused here and belongs in the credential store."""
        with _client(tmp_path) as client:
            token = _admin(client)
            r = client.put("/api/v1/console/settings", headers=_auth(token),
                           json={"SMTP_PASSWORD": "hunter2-not-in-a-response"})
            assert r.status_code == 400
            assert "hunter2-not-in-a-response" not in r.text
            body = client.get("/api/v1/console/settings",
                              headers=_auth(token))
            assert "hunter2-not-in-a-response" not in body.text
            assert "SMTP_PASSWORD" not in {
                s["key"] for s in body.json()["settings"]}

    def test_each_setting_says_when_it_applies(self, tmp_path):
        with _client(tmp_path) as client:
            for s in client.get("/api/v1/console/settings",
                                headers=_auth(_admin(client))
                                ).json()["settings"]:
                assert s["apply"] in ("hot", "restart")


class TestOverrides:
    def test_a_stored_override_wins_on_rebuild(self, tmp_path):
        """The whole point: change it, rebuild, it is in force."""
        db = str(tmp_path / "shared.db")
        with _client(tmp_path, sqlite_path=db) as client:
            token = _admin(client)
            assert client.get("/api/v1/console/summary",
                              headers=_auth(token)).status_code == 200
            r = client.put("/api/v1/console/settings", headers=_auth(token),
                           json={"max_attempts": 2})
            assert r.status_code == 200
            assert r.json()["restart_required"] is True

        # A rebuild is what a restart does.
        from src import create_app
        cfg = make_config(tmp_path, sqlite_path=db, terminal_driver="mock",
                          dispatcher_enabled=False,
                          log_dir=str(tmp_path / "logs"))
        create_app(cfg)
        assert cfg.max_attempts == 2

    def test_no_overrides_changes_nothing(self, tmp_path):
        """An install that never touches Settings must resolve exactly
        as it did before this table existed."""
        from src import create_app
        baseline = make_config(tmp_path, terminal_driver="mock",
                               dispatcher_enabled=False,
                               log_dir=str(tmp_path / "logs"))
        before = {k: getattr(baseline, k) for k in
                  ("max_attempts", "drain_seconds", "jwt_ttl_seconds",
                   "ocr_min_confidence", "availability_window_start")}
        create_app(baseline)
        after = {k: getattr(baseline, k) for k in before}
        assert before == after

    def test_clearing_falls_back_to_the_environment(self, tmp_path):
        db = str(tmp_path / "shared.db")
        with _client(tmp_path, sqlite_path=db) as client:
            token = _admin(client)
            client.put("/api/v1/console/settings", headers=_auth(token),
                       json={"max_attempts": 2})
            r = client.put("/api/v1/console/settings", headers=_auth(token),
                           json={"max_attempts": ""})
            assert "max_attempts" in r.json()["cleared"]

        from src import create_app
        cfg = make_config(tmp_path, sqlite_path=db, terminal_driver="mock",
                          dispatcher_enabled=False,
                          log_dir=str(tmp_path / "logs"))
        create_app(cfg)
        assert cfg.max_attempts == 3          # the class default again

    def test_email_settings_reach_the_environment(self, tmp_path):
        """The notification stack resolves its own values from named
        environment variables — the overlay writes there so there is
        ONE precedence chain, not two."""
        import os
        db = str(tmp_path / "shared.db")
        with _client(tmp_path, sqlite_path=db) as client:
            client.put("/api/v1/console/settings",
                       headers=_auth(_admin(client)),
                       json={"ERROR_ALERT_TO": "ops@x.com, id@x.com"})

        os.environ.pop("ERROR_ALERT_TO", None)
        from src import create_app
        create_app(make_config(tmp_path, sqlite_path=db,
                               terminal_driver="mock",
                               dispatcher_enabled=False,
                               log_dir=str(tmp_path / "logs")))
        assert os.environ["ERROR_ALERT_TO"] == "ops@x.com,id@x.com"

        from src.modules.notifications.transaction_alerts import (
            load_transaction_notification_config,
        )
        settings = load_transaction_notification_config()
        assert settings.error_alerts.default_to == ["ops@x.com", "id@x.com"]
        os.environ.pop("ERROR_ALERT_TO", None)

    def test_a_corrupt_stored_value_is_ignored_not_fatal(self, tmp_path):
        """A value that no longer validates (a catalogue change, a hand
        edit) must not stop the service from starting."""
        from src.core.db import Database
        from src.modules.console.settings_store import SettingsStore

        db_path = str(tmp_path / "shared.db")
        cfg = make_config(tmp_path, sqlite_path=db_path,
                          terminal_driver="mock", dispatcher_enabled=False,
                          log_dir=str(tmp_path / "logs"))
        store = SettingsStore(Database("sqlite", sqlite_path=db_path))
        store.set("max_attempts", "not-a-number")

        from src import create_app
        create_app(cfg)                       # must not raise
        assert cfg.max_attempts == 3


class TestValidation:
    def test_the_retry_cap_cannot_be_exceeded(self, tmp_path):
        """A login rejection consumes one mainframe attempt per try —
        the cap exists so a UI cannot walk an account into lockout."""
        with _client(tmp_path) as client:
            r = client.put("/api/v1/console/settings",
                           headers=_auth(_admin(client)),
                           json={"max_attempts": 50})
            assert r.status_code == 400
            assert "cannot exceed 5" in r.json()["detail"]

    def test_bounds_are_enforced_server_side(self, tmp_path):
        with _client(tmp_path) as client:
            token = _admin(client)
            for key, bad in (("ocr_min_confidence", 5.0),
                             ("auth_min_password_length", 2),
                             ("drain_seconds", 1)):
                r = client.put("/api/v1/console/settings",
                               headers=_auth(token), json={key: bad})
                assert r.status_code == 400, key

    def test_time_format_is_validated(self, tmp_path):
        with _client(tmp_path) as client:
            token = _admin(client)
            assert client.put(
                "/api/v1/console/settings", headers=_auth(token),
                json={"availability_window_start": "25:00"}
            ).status_code == 400
            r = client.put("/api/v1/console/settings", headers=_auth(token),
                           json={"availability_window_start": "6:5"})
            assert r.json()["changed"]["availability_window_start"] == "06:05"

    def test_unknown_keys_are_rejected(self, tmp_path):
        with _client(tmp_path) as client:
            token = _admin(client)
            for key in ("database_url", "jwt_secret", "not_a_setting"):
                r = client.put("/api/v1/console/settings",
                               headers=_auth(token), json={key: "x"})
                assert r.status_code == 400, key
                assert "not an editable setting" in r.json()["detail"]


class TestPermissionsAndAudit:
    def _viewer(self, client, admin_token):
        client.post("/api/v1/admin/users", headers=_auth(admin_token),
                    json={"username": "vic", "password": PASSWORD,
                          "role": "viewer"})
        t = client.post("/api/v1/auth/login", json={
            "username": "vic", "password": PASSWORD}).json()["access_token"]
        client.post("/api/v1/auth/password", headers=_auth(t),
                    json={"current_password": PASSWORD,
                          "new_password": "WrenOwn1234567"})
        return client.post("/api/v1/auth/login", json={
            "username": "vic",
            "password": "WrenOwn1234567"}).json()["access_token"]

    def test_viewer_may_read_but_not_write(self, tmp_path):
        with _client(tmp_path) as client:
            viewer = self._viewer(client, _admin(client))
            assert client.get("/api/v1/console/settings",
                              headers=_auth(viewer)).status_code == 200
            r = client.put("/api/v1/console/settings", headers=_auth(viewer),
                           json={"max_attempts": 2})
            assert r.status_code == 403
            assert "settings.edit" in r.json()["detail"]

    def test_changes_are_audited_with_the_actor(self, tmp_path):
        import time
        with _client(tmp_path, audit_enabled=True, audit_backend="sqlite",
                     audit_sqlite_path=str(tmp_path / "audit.db"),
                     audit_spool_path=str(tmp_path / "spool.db"),
                     audit_flush_interval_seconds=0.05) as client:
            client.put("/api/v1/console/settings",
                       headers=_auth(_admin(client)),
                       json={"max_attempts": 2})
            deadline = time.time() + 5
            events = []
            while time.time() < deadline and not events:
                events = [e for e in client.get(
                    "/api/v1/audit/events?category=console&limit=50"
                ).json()["events"]
                    if e["action"] == "settings_changed"]
            assert events
            assert events[0]["detail"]["actor"] == "alice"
            assert events[0]["detail"]["changed"]["max_attempts"] == 2

    def test_a_secret_value_never_reaches_the_audit_trail(self, tmp_path):
        import time
        with _client(tmp_path, audit_enabled=True, audit_backend="sqlite",
                     audit_sqlite_path=str(tmp_path / "audit.db"),
                     audit_spool_path=str(tmp_path / "spool.db"),
                     audit_flush_interval_seconds=0.05) as client:
            r = client.put("/api/v1/console/settings",
                           headers=_auth(_admin(client)),
                           json={"SMTP_PASSWORD": "hunter2-secret-value"})
            assert r.status_code == 400
            assert "hunter2-secret-value" not in r.text
            time.sleep(0.5)
            body = client.get(
                "/api/v1/audit/events?category=console&limit=50").text
            assert "hunter2-secret-value" not in body


class TestRestart:
    def test_headless_says_it_cannot_restart_itself(self, tmp_path):
        """Rather than pretending, or half-restarting."""
        with _client(tmp_path) as client:
            r = client.post("/api/v1/console/restart",
                            headers=_auth(_admin(client)))
            assert r.status_code == 501
            assert "not running inside the desktop app" in \
                r.json()["detail"]

    def test_the_desktop_hook_is_invoked(self, tmp_path):
        from fastapi.testclient import TestClient
        from src import create_app

        called = []
        cfg = make_config(tmp_path, dispatcher_enabled=False,
                          terminal_driver="mock",
                          log_dir=str(tmp_path / "logs"))
        with TestClient(create_app(
                cfg, restart_hook=lambda: called.append(1))) as client:
            token = _admin(client)
            r = client.post("/api/v1/console/restart", headers=_auth(token))
            assert r.status_code == 202
            assert called == [1]

    def test_restart_needs_the_edit_permission(self, tmp_path):
        from fastapi.testclient import TestClient
        from src import create_app

        cfg = make_config(tmp_path, dispatcher_enabled=False,
                          terminal_driver="mock",
                          log_dir=str(tmp_path / "logs"))
        with TestClient(create_app(cfg,
                                   restart_hook=lambda: None)) as client:
            admin = _admin(client)
            viewer = TestPermissionsAndAudit()._viewer(client, admin)
            assert client.post("/api/v1/console/restart",
                               headers=_auth(viewer)).status_code == 403
