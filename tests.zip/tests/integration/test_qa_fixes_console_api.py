"""Console fixes (QA 2026-09-28) through the real application: the
settings page after a restart-type setting is changed or cleared, the
branding upload checks, and the branded test e-mail."""
import base64
import json
import os

import pytest

from tests.conftest import make_config

PASSWORD = "CorrectHorse42"
PNG = b"\x89PNG\r\n\x1a\n" + b"\x00" * 40
JPEG = b"\xff\xd8\xff\xe0" + b"\x00" * 40


def _url(kind: str, data: bytes) -> str:
    return f"data:image/{kind};base64," + base64.b64encode(data).decode()


@pytest.fixture(autouse=True)
def fast_sleep(monkeypatch):
    monkeypatch.setattr("time.sleep", lambda s: None)


def _client(tmp_path, **overrides):
    from fastapi.testclient import TestClient
    from src import create_app
    cfg = make_config(tmp_path, dispatcher_enabled=False,
                      terminal_driver="mock",
                      log_dir=str(tmp_path / "logs"), **overrides)
    return TestClient(create_app(cfg))


def _auth(t):
    return {"Authorization": f"Bearer {t}"}


def _admin(client):
    client.post("/api/v1/auth/bootstrap",
                json={"username": "alice", "password": PASSWORD})
    return client.post("/api/v1/auth/login", json={
        "username": "alice", "password": PASSWORD}).json()["access_token"]


def _setting(client, token, key):
    items = client.get("/api/v1/console/settings",
                       headers=_auth(token)).json()["settings"]
    return next(s for s in items if s["key"] == key)


class TestClearedRestartSettingShowsWhatApplies:
    """BUG-054."""

    def test_cleared_config_setting_shows_the_default_pending(self,
                                                              tmp_path):
        db = str(tmp_path / "shared.db")
        with _client(tmp_path, sqlite_path=db) as client:
            token = _admin(client)
            client.put("/api/v1/console/settings", headers=_auth(token),
                       json={"max_attempts": 2})
        # Built with the override in force (what a restart does).
        with _client(tmp_path, sqlite_path=db) as client:
            token = _admin(client)
            s = _setting(client, token, "max_attempts")
            assert str(s["value"]) == "2"
            assert s["pending_restart"] is False
            r = client.put("/api/v1/console/settings", headers=_auth(token),
                           json={"max_attempts": ""})
            assert r.json()["cleared"] == ["max_attempts"]
            s = _setting(client, token, "max_attempts")
            assert str(s["value"]) == "3"
            assert s["overridden"] is False
            assert s["pending_restart"] is True

    def test_saved_but_not_yet_applied_is_pending(self, tmp_path):
        with _client(tmp_path) as client:
            token = _admin(client)
            assert _setting(client, token,
                            "max_attempts")["pending_restart"] is False
            client.put("/api/v1/console/settings", headers=_auth(token),
                       json={"max_attempts": 2})
            s = _setting(client, token, "max_attempts")
            assert str(s["value"]) == "2" and s["pending_restart"] is True

    def test_cleared_environment_setting_shows_the_original(
            self, tmp_path, monkeypatch):
        monkeypatch.setenv("SMTP_HOST", "relay.example.com")
        db = str(tmp_path / "shared.db")
        with _client(tmp_path, sqlite_path=db) as client:
            client.put("/api/v1/console/settings",
                       headers=_auth(_admin(client)),
                       json={"SMTP_HOST": "other.example.com"})
        try:
            with _client(tmp_path, sqlite_path=db) as client:
                token = _admin(client)
                assert os.environ["SMTP_HOST"] == "other.example.com"
                s = _setting(client, token, "SMTP_HOST")
                assert s["value"] == "other.example.com"
                assert s["pending_restart"] is False
                client.put("/api/v1/console/settings", headers=_auth(token),
                           json={"SMTP_HOST": ""})
                s = _setting(client, token, "SMTP_HOST")
                assert s["value"] == "relay.example.com"
                assert s["pending_restart"] is True
        finally:
            from src.modules.console.settings_store import (
                _restore_env_overrides,
            )
            _restore_env_overrides()


class TestBrandingUploads:
    """BUG-036 and BUG-076."""

    def test_content_is_checked(self, tmp_path):
        with _client(tmp_path) as client:
            token = _admin(client)
            r = client.put("/api/v1/console/branding", headers=_auth(token),
                           json={"logo": _url("png", b"plain text file")})
            assert r.status_code == 400
            assert "not a PNG, JPEG, GIF or WebP image" in r.json()["detail"]
            r = client.put("/api/v1/console/branding", headers=_auth(token),
                           json={"logo": _url("svg+xml", b"<svg/>")})
            assert r.status_code == 400
            r = client.put("/api/v1/console/branding", headers=_auth(token),
                           json={"logo": _url("png", JPEG)})
            assert r.status_code == 200, r.text
            assert r.json()["branding"]["logo"].startswith(
                "data:image/jpeg;base64,")

    def test_a_stored_svg_does_not_block_other_changes(self, tmp_path):
        from src.core.db import Database
        from src.modules.console import branding
        from src.modules.console.settings_store import SettingsStore
        db = str(tmp_path / "shared.db")
        svg = _url("svg+xml", b"<svg></svg>")
        with _client(tmp_path, sqlite_path=db) as client:
            token = _admin(client)
            store = SettingsStore(Database("sqlite", sqlite_path=db))
            store.set(branding.KEY, json.dumps(
                dict(branding.DEFAULTS, logo=svg)))
            current = client.get("/api/v1/console/branding"
                                 ).json()["branding"]
            assert current["logo"] == svg
            # The console sends the whole document back.
            r = client.put("/api/v1/console/branding", headers=_auth(token),
                           json=dict(current, tagline="New tagline"))
            assert r.status_code == 200, r.text
            assert r.json()["branding"]["tagline"] == "New tagline"
            assert r.json()["branding"]["logo"] == svg

    def test_size_message_is_not_rounded_down(self, tmp_path):
        data = PNG + b"\x00" * (200 * 1024 + 1 - len(PNG))
        with _client(tmp_path) as client:
            r = client.put("/api/v1/console/branding",
                           headers=_auth(_admin(client)),
                           json={"logo": _url("png", data)})
            assert r.status_code == 400
            assert "this file is 200.1 KB (204,801 bytes)" in \
                r.json()["detail"]


class TestBrandedTestEmail:
    """BUG-058: the test e-mail follows the Branding page."""

    @pytest.fixture
    def sent(self, monkeypatch):
        from src.modules.notifications.notifier import EmailNotifier
        messages = []

        class FakeSMTP:
            def send_message(self, msg, to_addrs=None):
                messages.append(msg)

            def quit(self):
                pass

        monkeypatch.setattr(EmailNotifier, "_connect",
                            lambda self: FakeSMTP())
        return messages

    def _desktop_client(self, tmp_path, monkeypatch):
        from fastapi.testclient import TestClient
        from desktop import vault
        from desktop.server import mount_console_ui
        from src import create_app
        data = tmp_path / "data"
        data.mkdir()
        monkeypatch.setenv("FINESIII_DATA_DIR", str(data))
        previous = vault._vault
        vault.use_vault(vault.MemoryVault())
        for k in vault.SECRET_KEYS:
            monkeypatch.delenv(k, raising=False)
        cfg = make_config(tmp_path, dispatcher_enabled=False,
                          terminal_driver="mock",
                          log_dir=str(tmp_path / "logs"))
        app = create_app(cfg)
        mount_console_ui(app, mode="agent")
        return TestClient(app), previous

    def _send(self, client, token):
        return client.post("/api/v1/system/test-email", headers=_auth(token),
                           json={"to": "ops@example.com",
                                 "host": "127.0.0.1", "port": 2525,
                                 "from": "bot@example.com",
                                 "use_ssl": False,
                                 "use_starttls": False}).json()

    def test_branded_html_on_gives_an_html_part(self, tmp_path, monkeypatch,
                                                 sent):
        from desktop import vault
        client, previous = self._desktop_client(tmp_path, monkeypatch)
        try:
            with client:
                token = _admin(client)
                # On by default since 2026-09-29 (D1); switched off here
                # to see that the page's switch is followed both ways.
                client.put("/api/v1/console/branding", headers=_auth(token),
                           json={"email_html_enabled": False})
                r = self._send(client, token)
                assert r["ok"] is True, r
                assert "text/html" not in [
                    p.get_content_type() for p in sent[-1].walk()]
                client.put("/api/v1/console/branding", headers=_auth(token),
                           json={"email_html_enabled": True,
                                 "email_company_name": "Example Co"})
                r = self._send(client, token)
                assert r["ok"] is True, r
                parts = {p.get_content_type(): p for p in sent[-1].walk()}
                assert "text/html" in parts
                html = parts["text/html"].get_content()
                assert "Example Co" in html
        finally:
            vault.use_vault(previous)
