"""Security and configuration fixes of the 28 September retest wired
through the application (group 3): NB-002, NB-005, NB-010, NB-020,
NB-024, NB-026, NB-027, NB-028 and the start-up warnings."""
from __future__ import annotations

import logging
import os

import pytest

from tests.conftest import make_config

PASSWORD = "CorrectHorse42"


@pytest.fixture(autouse=True)
def fast_sleep(monkeypatch):
    monkeypatch.setattr("time.sleep", lambda s: None)


@pytest.fixture
def data_dir(tmp_path, monkeypatch):
    d = tmp_path / "data"
    d.mkdir()
    monkeypatch.setenv("FINESIII_DATA_DIR", str(d))
    for k in ("DATABASE_URL", "DATABASE_ENGINE", "AUDIT_DATABASE_URL",
              "AUDIT_BACKEND", "AUDIT_ENABLED"):
        monkeypatch.delenv(k, raising=False)
    return d


@pytest.fixture
def memory_vault(monkeypatch):
    from desktop import vault
    previous = vault._vault
    store = vault.MemoryVault()
    vault.use_vault(store)
    for k in vault.SECRET_KEYS:
        monkeypatch.delenv(k, raising=False)
    yield store
    vault.use_vault(previous)


class _NoVault:
    """A machine without a credential store."""
    name = "keyring"
    available = False
    error = "no OS credential store is available"

    def get(self, key):
        from desktop.vault import VaultUnavailableError
        raise VaultUnavailableError(self.error)

    set = delete = lambda self, *a: _NoVault.get(self, None)


@pytest.fixture
def no_vault(monkeypatch):
    from desktop import vault
    previous = vault._vault
    vault.use_vault(_NoVault())
    for k in vault.SECRET_KEYS:
        monkeypatch.delenv(k, raising=False)
    yield
    vault.use_vault(previous)


@pytest.fixture
def email_env(monkeypatch):
    for k in ("SMTP_ALERTS_ENABLED", "SMTP_HOST", "SMTP_PORT", "ALERT_FROM",
              "ALERT_TO", "SMTP_USE_SSL", "SMTP_USE_STARTTLS",
              "SMTP_PASSWORD"):
        monkeypatch.delenv(k, raising=False)
    yield
    # An active alert handler stays on the shared loggers; take it off.
    from src.modules.notifications.log_handler import (
        ALERT_LOGGER_NAMES, EmailAlertHandler,
    )
    for name in ALERT_LOGGER_NAMES:
        log = logging.getLogger(name)
        for h in list(log.handlers):
            if isinstance(h, EmailAlertHandler):
                log.removeHandler(h)


def _cfg(tmp_path, audit=False, **overrides):
    if audit:
        overrides.update(
            audit_enabled=True, audit_backend="sqlite",
            audit_sqlite_path=str(tmp_path / "audit.db"),
            audit_spool_path=str(tmp_path / "spool.db"),
            audit_flush_interval_seconds=0.05)
    return make_config(tmp_path, terminal_driver="mock",
                       log_dir=str(tmp_path / "logs"), **overrides)


def _store(cfg, rows: dict):
    """Rows in the settings table BEFORE the service is built — as an
    earlier version left them."""
    from src.core.db import Database
    from src.modules.console.settings_store import SettingsStore
    db = Database.from_config(cfg)
    try:
        store = SettingsStore(db)
        for k, v in rows.items():
            store.set(k, v)
    finally:
        db.close()


def _client(cfg):
    from fastapi.testclient import TestClient
    from desktop.server import mount_console_ui
    from src import create_app
    app = create_app(cfg)
    mount_console_ui(app, mode="agent", stop_hook=lambda: None)
    return TestClient(app)


def _auth(t):
    return {"Authorization": f"Bearer {t}"}


def _admin(client):
    client.post("/api/v1/auth/bootstrap",
                json={"username": "alice", "password": PASSWORD})
    return client.post("/api/v1/auth/login", json={
        "username": "alice", "password": PASSWORD}).json()["access_token"]


def _events(client, **filters):
    audit = client.app.state.audit
    assert audit.flush(timeout=5)
    return audit.backend.query_events(limit=500, **filters)


def _status(client, token):
    r = client.get("/api/v1/system/status", headers=_auth(token))
    assert r.status_code == 200, r.text
    return r.json()


# ── NB-002 ──

class TestDatabaseTestRefusesUnreadableUrl:
    def test_refused_and_not_audited_in_clear(self, tmp_path, data_dir,
                                              memory_vault, monkeypatch):
        from desktop import deployment
        called = []
        monkeypatch.setattr(deployment, "check_database",
                            lambda *a, **k: called.append(1))
        with _client(_cfg(tmp_path, audit=True)) as client:
            token = _admin(client)
            r = client.post("/api/v1/system/test-database",
                            headers=_auth(token),
                            json={"url": "postgresql://u:Pw#9xxxx@h:5432/db"})
            assert r.status_code == 200, r.text
            body = r.json()
            assert body["ok"] is False
            assert "percent-encode" in body["error"]
            assert "Pw#9" not in r.text
            assert called == []                 # never connected
            events = _events(client, action="database_tested")
        assert len(events) == 1
        detail = str(events[0])
        assert "Pw#9" not in detail and "xxxx" not in detail
        assert "refused" in detail

    def test_deployment_page_with_non_numeric_port(self, tmp_path, data_dir,
                                                   memory_vault):
        from desktop import deployment
        deployment.write({"DATABASE_URL": "postgresql://u:hidden@h:abc/db"})
        with _client(_cfg(tmp_path)) as client:
            r = client.get("/api/v1/system/deployment",
                           headers=_auth(_admin(client)))
        assert r.status_code == 200, r.text
        item = next(s for s in r.json()["settings"]
                    if s["key"] == "DATABASE_URL")
        assert "hidden" not in item["value"]


# ── NB-005 ──

class TestUnreachableDatabaseSave:
    BODY = {"DATABASE_ENGINE": "postgres",
            "DATABASE_URL": "postgresql://u@127.0.0.1:1/db"}

    def test_refused_unless_forced(self, tmp_path, data_dir, memory_vault):
        from desktop import deployment
        with _client(_cfg(tmp_path)) as client:
            token = _admin(client)
            r = client.put("/api/v1/system/deployment", headers=_auth(token),
                           json=self.BODY)
            assert r.status_code == 400, r.text
            detail = r.json()["detail"]
            assert detail["status"] == "database_unreachable"
            assert detail["message"].startswith(
                "The database server cannot be reached (")
            assert detail["message"].endswith(
                "Check the address, or save anyway.")
            assert "DATABASE_URL" not in deployment.read()
            r = client.put("/api/v1/system/deployment?force=true",
                           headers=_auth(token), json=self.BODY)
            assert r.status_code == 200, r.text
            assert deployment.read()["DATABASE_URL"] == \
                "postgresql://u@127.0.0.1:1/db"

    def test_rejected_sign_in_is_not_refused(self, tmp_path, data_dir,
                                             memory_vault, monkeypatch):
        from desktop import deployment
        monkeypatch.setattr(deployment, "check_database", lambda *a, **k: {
            "ok": False, "error": "password authentication failed",
            "hint": "The user name or password is wrong."})
        with _client(_cfg(tmp_path)) as client:
            r = client.put("/api/v1/system/deployment",
                           headers=_auth(_admin(client)), json=self.BODY)
        assert r.status_code == 200, r.text

    def test_other_settings_are_not_checked(self, tmp_path, data_dir,
                                            memory_vault, monkeypatch):
        from desktop import deployment
        called = []
        monkeypatch.setattr(deployment, "check_database",
                            lambda *a, **k: called.append(1) or {})
        with _client(_cfg(tmp_path)) as client:
            r = client.put("/api/v1/system/deployment",
                           headers=_auth(_admin(client)),
                           json={"LOG_LEVEL": "DEBUG"})
        assert r.status_code == 200 and called == []


# ── NB-010 ──

class TestStoredTlsConflict:
    def test_resolved_audited_and_reported(self, tmp_path, data_dir,
                                           memory_vault, email_env,
                                           monkeypatch):
        from src.modules.notifications.log_handler import EmailAlertHandler
        for k, v in {"SMTP_ALERTS_ENABLED": "true",
                     "SMTP_HOST": "smtp.invalid", "ALERT_FROM": "a@x.example",
                     "ALERT_TO": "b@x.example"}.items():
            monkeypatch.setenv(k, v)
        cfg = _cfg(tmp_path, audit=True)
        _store(cfg, {"SMTP_USE_STARTTLS": "true", "SMTP_USE_SSL": "true"})
        with _client(cfg) as client:
            token = _admin(client)
            warnings = _status(client, token)["startup_warnings"]
            assert any("Use implicit SSL (port 465) was switched Off "
                       "automatically" in w and "port 587" in w
                       for w in warnings), warnings
            assert client.app.state.settings_store.all()["SMTP_USE_SSL"] \
                == "false"
            events = _events(client, action="settings_migrated")
            assert len(events) == 1
            assert "SMTP_USE_SSL" in str(events[0])
            assert any(isinstance(h, EmailAlertHandler) for h in
                       logging.getLogger("finesiii_rpa_v3").handlers)

    def test_environment_conflict_reported_not_stored(self, tmp_path,
                                                      data_dir, memory_vault,
                                                      email_env, monkeypatch):
        for k, v in {"SMTP_ALERTS_ENABLED": "true",
                     "SMTP_HOST": "smtp.invalid", "ALERT_FROM": "a@x.example",
                     "ALERT_TO": "b@x.example", "SMTP_USE_SSL": "true",
                     "SMTP_USE_STARTTLS": "true"}.items():
            monkeypatch.setenv(k, v)
        with _client(_cfg(tmp_path)) as client:
            token = _admin(client)
            warnings = _status(client, token)["startup_warnings"]
            assert any(w.startswith("E-mail is switched off: ")
                       and "Settings > E-mail" in w for w in warnings), warnings
            stored = client.app.state.settings_store.all()
            assert "SMTP_USE_SSL" not in stored
            assert "SMTP_USE_STARTTLS" not in stored
            setup = client.get("/api/v1/system/setup",
                               headers=_auth(token)).json()
            assert setup["startup_warnings"] == warnings


# ── NB-020 ──

class TestLegacySecretWithoutStore:
    def test_status_remove_and_audit(self, tmp_path, data_dir, no_vault,
                                     email_env):
        cfg = _cfg(tmp_path, audit=True)
        _store(cfg, {"SMTP_PASSWORD": "legacy-smtp-pw"})
        with _client(cfg) as client:
            token = _admin(client)
            dep = client.get("/api/v1/system/deployment",
                             headers=_auth(token)).json()
            assert dep["secrets"]["SMTP_PASSWORD"]["source"] == \
                "settings_table"
            warnings = _status(client, token)["startup_warnings"]
            assert any("SMTP_PASSWORD is still stored in the application "
                       "database" in w for w in warnings), warnings
            r = client.delete("/api/v1/system/secrets/SMTP_PASSWORD",
                              headers=_auth(token))
            assert r.status_code == 200, r.text
            body = r.json()
            assert body["legacy"] is True and body["set"] is False
            assert "Removed from the application database" in body["note"]
            assert "SMTP_PASSWORD" not in \
                client.app.state.settings_store.all()
            assert "SMTP_PASSWORD" not in os.environ
            events = _events(client, action="secret_changed")
            assert any("settings_table" in str(e) for e in events)
            # Without the row and without a store: 503 as before.
            r = client.delete("/api/v1/system/secrets/SMTP_PASSWORD",
                              headers=_auth(token))
            assert r.status_code == 503

    def test_environment_value_back_in_force(self, tmp_path, data_dir,
                                             no_vault, email_env,
                                             monkeypatch):
        cfg = _cfg(tmp_path)
        _store(cfg, {"SMTP_PASSWORD": "legacy-smtp-pw"})
        monkeypatch.setenv("SMTP_PASSWORD", "real-env-pw")
        with _client(cfg) as client:
            token = _admin(client)
            assert os.environ["SMTP_PASSWORD"] == "legacy-smtp-pw"
            r = client.delete("/api/v1/system/secrets/SMTP_PASSWORD",
                              headers=_auth(token))
            assert r.status_code == 200, r.text
            assert r.json()["set"] is True
            assert os.environ["SMTP_PASSWORD"] == "real-env-pw"


# ── NB-024 ──

class TestIgnoredStoredValue:
    def test_reported_marked_and_logged(self, tmp_path, data_dir,
                                        memory_vault, email_env):
        cfg = _cfg(tmp_path)
        _store(cfg, {"ALERT_TO": "a@x.example Bcc: other@x.example"})
        with _client(cfg) as client:
            token = _admin(client)
            warnings = _status(client, token)["startup_warnings"]
            assert any("(ALERT_TO) is not valid and is ignored" in w
                       for w in warnings), warnings
            items = client.get("/api/v1/console/settings",
                               headers=_auth(token)).json()["settings"]
            row = next(s for s in items if s["key"] == "ALERT_TO")
            assert row["invalid"] is True and row["overridden"] is False
            assert row["value"] == "a@x.example Bcc: other@x.example"
            other = next(s for s in items if s["key"] == "ALERT_CC")
            assert other["invalid"] is False
        log = (tmp_path / "logs" / "finesiii_rpa_v3.log").read_text(
            encoding="utf-8")
        assert "Ignoring stored setting ALERT_TO" in log


# ── NB-026 ──

class TestSpacesOnlyCredential:
    def test_refused_and_kept(self, tmp_path, data_dir, memory_vault):
        with _client(_cfg(tmp_path)) as client:
            token = _admin(client)
            url = "/api/v1/system/secrets/SMTP_PASSWORD"
            assert client.put(url, headers=_auth(token),
                              json={"value": "real-pw"}).status_code == 200
            r = client.put(url, headers=_auth(token), json={"value": "   "})
            assert r.status_code == 400
            assert "only of spaces" in r.json()["detail"]
            assert memory_vault.get("SMTP_PASSWORD") == "real-pw"
            # A real value with spaces around it is kept as typed.
            assert client.put(url, headers=_auth(token),
                              json={"value": " pw x "}).status_code == 200
            assert memory_vault.get("SMTP_PASSWORD") == " pw x "
            r = client.put(url, headers=_auth(token), json={"value": ""})
            assert r.status_code == 200 and r.json()["set"] is False
            assert memory_vault.get("SMTP_PASSWORD") is None


# ── NB-027 ──

class TestStopNote:
    def test_wording(self, tmp_path, data_dir, memory_vault):
        with _client(_cfg(tmp_path)) as client:
            r = client.post("/api/v1/system/stop",
                            headers=_auth(_admin(client)))
        assert r.status_code == 202
        note = r.json()["note"]
        assert "Start menu" not in note and "logon" not in note
        assert "started again on this machine" in note
        assert "section 5" in note


# ── NB-028 ──

class TestTestDatabaseUsesSavedPassword:
    @pytest.fixture
    def captured(self, monkeypatch):
        from desktop import deployment
        calls = []

        def fake(url="", engine="", password="", timeout=5.0):
            calls.append({"url": url, "password": password})
            return {"ok": True, "engine": engine or "postgres", "server": "x",
                    "user": "u", "missing_tables": [], "privileges": {},
                    "error": "", "hint": ""}
        monkeypatch.setattr(deployment, "check_database", fake)
        return calls

    def test_saved_address_gets_the_stored_password(self, tmp_path,
                                                    data_dir, memory_vault,
                                                    captured):
        with _client(_cfg(tmp_path)) as client:
            token = _admin(client)
            r = client.put("/api/v1/system/deployment", headers=_auth(token),
                           json={"DATABASE_URL":
                                 "postgresql://app:Saved-Pw1@db1:5432/f",
                                 "AUDIT_DATABASE_URL":
                                 "postgresql://aud:Audit-Pw2@db2:5432/a"})
            assert r.status_code == 200, r.text
            captured.clear()

            def test(**body):
                r = client.post("/api/v1/system/test-database",
                                headers=_auth(token), json=body)
                assert r.status_code == 200, r.text
                return captured[-1]["password"]
            assert test(url="postgresql://app@db1:5432/f") == "Saved-Pw1"
            assert test(url="postgresql://app@other:5432/f") == ""
            assert test(key="AUDIT_DATABASE_URL",
                        url="postgresql://aud@db2:5432/a") == "Audit-Pw2"
            # The audit password never goes to the main address.
            assert test(url="postgresql://aud@db2:5432/a") == ""
            r = client.post("/api/v1/system/test-database",
                            headers=_auth(token),
                            json={"key": "SOMETHING", "url": "x"})
            assert r.status_code == 400
