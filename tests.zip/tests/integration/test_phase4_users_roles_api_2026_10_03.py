"""Phase 4 of the console module review (2026-10-03): Users, Roles and
Error rules — editing and resetting accounts, delegated and read-only
user administration, honest sign-in records, safe rule changes and the
break-glass password reset."""
import shutil
import time
from pathlib import Path

import pytest

from tests.conftest import make_config

PASSWORD = "CorrectHorse42"
ROOT = Path(__file__).resolve().parents[2]
UI = ROOT / "desktop" / "ui"
_real_sleep = time.sleep


@pytest.fixture
def data_dir(tmp_path, monkeypatch):
    from desktop import vault
    d = tmp_path / "data"
    d.mkdir()
    monkeypatch.setenv("FINESIII_DATA_DIR", str(d))
    previous = vault._vault
    vault.use_vault(vault.MemoryVault())
    for k in vault.SECRET_KEYS:
        monkeypatch.delenv(k, raising=False)
    yield d
    vault.use_vault(previous)


def _cfg(tmp_path, audit=False, **overrides):
    if audit:
        overrides.update(
            audit_enabled=True, audit_backend="sqlite",
            audit_sqlite_path=str(tmp_path / "audit.db"),
            audit_spool_path=str(tmp_path / "spool.db"),
            audit_flush_interval_seconds=0.05)
    return make_config(tmp_path, dispatcher_enabled=False,
                       terminal_driver="mock",
                       log_dir=str(tmp_path / "logs"), **overrides)


def _client(tmp_path, audit=False, **overrides):
    from fastapi.testclient import TestClient
    from src import create_app
    return TestClient(create_app(_cfg(tmp_path, audit, **overrides)))


def _h(t):
    return {"Authorization": f"Bearer {t}"}


def _admin(client):
    client.post("/api/v1/auth/bootstrap",
                json={"username": "alice", "password": PASSWORD})
    return client.post("/api/v1/auth/login", json={
        "username": "alice", "password": PASSWORD}).json()["access_token"]


def _login(client, username, password):
    return client.post("/api/v1/auth/login",
                       json={"username": username, "password": password})


def _user(client, admin, username, role):
    client.post("/api/v1/admin/users", headers=_h(admin),
                json={"username": username, "password": PASSWORD,
                      "role": role})
    t = _login(client, username, PASSWORD).json()["access_token"]
    client.post("/api/v1/auth/password", headers=_h(t),
                json={"current_password": PASSWORD,
                      "new_password": "TheirOwn7777"})
    return _login(client, username, "TheirOwn7777").json()["access_token"]


def _role(client, admin, name, permissions):
    r = client.post("/api/v1/admin/roles", headers=_h(admin), json={
        "name": name, "permissions": permissions})
    assert r.status_code == 201, r.text


def _uid(client, admin, username):
    return next(u["user_id"] for u in client.get(
        "/api/v1/admin/users", headers=_h(admin)).json()["users"]
        if u["username"] == username)


def _events(client, token, action, category="auth"):
    deadline = time.time() + 5
    found = []
    while time.time() < deadline and not found:
        found = [e for e in client.get(
            f"/api/v1/console/audit/events?category={category}&limit=200",
            headers=_h(token)).json()["events"] if e["action"] == action]
        _real_sleep(0.1)
    return found


# ── UR-01 / UR-03 / UR-04: reset a password ──

def test_reset_unlocks_and_is_recorded(tmp_path, data_dir):
    with _client(tmp_path, audit=True) as client:
        admin = _admin(client)
        _user(client, admin, "bob", "operator")
        for _ in range(6):
            _login(client, "bob", "wrong-password-1")
        assert _login(client, "bob", "TheirOwn7777").status_code != 200
        bob = _uid(client, admin, "bob")
        r = client.patch(f"/api/v1/admin/users/{bob}", headers=_h(admin),
                         json={"password": "ResetByAdmin42"})
        assert r.status_code == 200 and r.json()["user"]["locked"] is False
        r = _login(client, "bob", "ResetByAdmin42")
        assert r.status_code == 200 and r.json()["must_change_password"]
        (reset,) = _events(client, admin, "user_password_reset")
        assert reset["detail"]["username"] == "bob"
        assert reset["detail"]["user_id"] == bob
        assert _events(client, admin, "user_created")[0]["detail"][
            "user_id"]


def test_edit_fields_through_the_update_route(tmp_path, data_dir):
    with _client(tmp_path) as client:
        admin = _admin(client)
        _user(client, admin, "bob", "viewer")
        bob = _uid(client, admin, "bob")
        r = client.patch(f"/api/v1/admin/users/{bob}", headers=_h(admin),
                         json={"display_name": "Bob Sample",
                               "email": "bob@example.com"})
        assert r.status_code == 200
        assert r.json()["user"]["display_name"] == "Bob Sample"
        r = client.patch(f"/api/v1/admin/users/{bob}", headers=_h(admin),
                         json={"email": "not-an-address"})
        assert r.status_code == 422


# ── UR-02 / UR-05: delegated and read-only user administration ──

def test_user_administrator_without_role_management(tmp_path, data_dir):
    with _client(tmp_path) as client:
        admin = _admin(client)
        _role(client, admin, "compliance", ["dashboard.view",
                                            "evidence.view"])
        _role(client, admin, "usermgr", ["users.manage", "dashboard.view",
                                         "evidence.view"])
        mgr = _user(client, admin, "harry", "usermgr")
        assert client.get("/api/v1/admin/roles",
                          headers=_h(mgr)).status_code == 403
        names = {r["name"]: r for r in client.get(
            "/api/v1/admin/role-names", headers=_h(mgr)).json()["roles"]}
        assert names["compliance"]["assignable"] is True
        assert names["admin"]["assignable"] is False
        r = client.post("/api/v1/admin/users", headers=_h(mgr), json={
            "username": "carol", "password": PASSWORD,
            "role": "compliance"})
        assert r.status_code == 201, r.text


def test_read_only_access_review(tmp_path, data_dir):
    with _client(tmp_path, audit=True) as client:
        admin = _admin(client)
        _role(client, admin, "reviewer", ["users.view", "audit.view"])
        rev = _user(client, admin, "rita", "reviewer")
        assert client.get("/api/v1/admin/users",
                          headers=_h(rev)).status_code == 200
        assert client.post("/api/v1/admin/users", headers=_h(rev), json={
            "username": "dave", "password": PASSWORD,
            "role": "viewer"}).status_code == 403
        r = client.get("/api/v1/admin/users/export", headers=_h(rev))
        assert r.status_code == 200
        text = r.content.decode("utf-8")
        assert text.startswith("﻿username,")
        assert "rita" in text and "users.view" in text
        assert "password" not in text.splitlines()[0].replace(
            "must_change_password", "")
        (ev,) = _events(client, admin, "data_exported")
        assert ev["detail"]["table"] == "users"


# ── UR-09: renewing a session is not a sign-in ──

def test_session_renewal_is_not_a_sign_in(tmp_path, data_dir):
    with _client(tmp_path, audit=True) as client:
        admin = _admin(client)
        before = client.get("/api/v1/auth/me",
                            headers=_h(admin)).json()["user"]["last_login_at"]
        _real_sleep(1.1)
        r = client.post("/api/v1/auth/refresh", headers=_h(admin))
        assert r.status_code == 200
        new = r.json()["access_token"]
        after = client.get("/api/v1/auth/me",
                           headers=_h(new)).json()["user"]["last_login_at"]
        assert after == before
        assert _events(client, new, "session_renewed")
        signins = _events(client, new, "login_succeeded")
        assert len(signins) == 1


# ── UR-11 / UR-12 / UR-13 / UR-14 ──

def test_no_self_deactivation(tmp_path, data_dir):
    with _client(tmp_path) as client:
        admin = _admin(client)
        _user(client, admin, "bob", "admin")
        me = _uid(client, admin, "alice")
        r = client.patch(f"/api/v1/admin/users/{me}", headers=_h(admin),
                         json={"is_active": False})
        assert r.status_code == 409 and "signed in as" in r.json()["detail"]


@pytest.mark.parametrize("name", ["   ", "a b", "x/y", "Bad*Name"])
def test_usernames_are_checked(tmp_path, data_dir, name):
    with _client(tmp_path) as client:
        admin = _admin(client)
        r = client.post("/api/v1/admin/users", headers=_h(admin), json={
            "username": name, "password": PASSWORD, "role": "viewer"})
        assert r.status_code == 422


def test_role_names_are_checked(tmp_path, data_dir):
    with _client(tmp_path) as client:
        admin = _admin(client)
        for bad in ("  ", "a/b", "My Role"):
            r = client.post("/api/v1/admin/roles", headers=_h(admin),
                            json={"name": bad, "permissions": []})
            assert r.status_code == 422, bad


def test_role_editor_only_edits_roles_within_own_rights(tmp_path, data_dir):
    with _client(tmp_path) as client:
        admin = _admin(client)
        _role(client, admin, "roleeditor", ["roles.manage", "dashboard.view"])
        _role(client, admin, "strong", ["dashboard.view", "settings.edit"])
        _role(client, admin, "weak", ["dashboard.view"])
        editor = _user(client, admin, "erin", "roleeditor")
        r = client.patch("/api/v1/admin/roles/strong", headers=_h(editor),
                         json={"permissions": ["dashboard.view"]})
        assert r.status_code == 403
        r = client.delete("/api/v1/admin/roles/strong", headers=_h(editor))
        assert r.status_code == 403
        r = client.patch("/api/v1/admin/roles/weak", headers=_h(editor),
                         json={"description": "Dashboard only"})
        assert r.status_code == 200


# ── UR-06 / UR-07 / UR-10: error rules ──

def _catalog(tmp_path):
    target = tmp_path / "errors.yaml"
    shutil.copy(ROOT / "config" / "errors.yaml", target)
    return target


def test_rule_change_records_the_reason(tmp_path, data_dir):
    path = _catalog(tmp_path)
    with _client(tmp_path, audit=True,
                 error_catalog_path=str(path)) as client:
        admin = _admin(client)
        rule = client.get("/api/v1/console/error-rules",
                          headers=_h(admin)).json()["rules"][0]["id"]
        r = client.patch(f"/api/v1/console/error-rules/{rule}",
                         headers=_h(admin),
                         json={"enabled": False, "reason": "Test window"})
        assert r.status_code == 200
        (ev,) = _events(client, admin, "error_rule_toggled", "console")
        assert ev["detail"]["reason"] == "Test window"


def test_a_broken_catalogue_is_reported_and_never_written(tmp_path,
                                                           data_dir):
    path = _catalog(tmp_path)
    with _client(tmp_path, error_catalog_path=str(path)) as client:
        admin = _admin(client)
        rule = client.get("/api/v1/console/error-rules",
                          headers=_h(admin)).json()["rules"][0]["id"]
        text = path.read_text(encoding="utf-8")
        broken = text + "\n  - id: " + rule + "\n    name: duplicate\n"
        path.write_text(broken, encoding="utf-8")
        d = client.get("/api/v1/console/error-rules",
                       headers=_h(admin)).json()
        assert d["problems"]                  # the bot would refuse it
        r = client.patch(f"/api/v1/console/error-rules/{rule}",
                         headers=_h(admin), json={"enabled": False, "reason": "test"})
        assert r.status_code == 409 and "Not saved" in r.json()["detail"]
        assert path.read_text(encoding="utf-8") == broken


def test_only_the_rules_own_enabled_line_changes():
    from src.modules.console.yaml_edit import set_rule_enabled
    text = ("errors:\n"
            "  - id: A\n"
            "    capture:\n"
            "      enabled: true\n"
            "    name: x\n")
    out = set_rule_enabled(text, "A", False)
    assert "      enabled: true\n" in out          # nested one untouched
    assert "  - id: A\n    enabled: false\n" in out


def test_error_matches_carry_the_catalogue_version():
    from src.rpa.screens.error_handler import ScreenGuard
    from src.rpa.vision.error_catalog import ErrorCatalog

    class _Match:
        def audit_detail(self, step, acted):
            return {"error_id": "X", "step": step, "acted": acted}
    guard = ScreenGuard(None, None)
    guard.catalog = ErrorCatalog([], source="errors.yaml",
                                 digest="abc123def456")
    guard._remember(_Match(), "login", True)
    assert guard.trace[-1]["catalog_digest"] == "abc123def456"


# ── UR-16: branding ──

def test_branding_wins_in_e_mails():
    from src.modules.notifications.config import NotificationSettings
    from src.modules.notifications.notifier import EmailNotifier
    s = NotificationSettings(enabled=True, html_enabled=True,
                             support_contact="file@example.com")
    n = EmailNotifier(s)
    n.branding_source = lambda: {"support_contact": "brand@example.com",
                                 "email_html_enabled": False}
    assert n._base_context("x")["support_contact"] == "brand@example.com"
    assert n.html_enabled() is False
    n.branding_source = lambda: {}
    assert n._base_context("x")["support_contact"] == "file@example.com"
    assert n.html_enabled() is True


def test_sign_in_notice_never_blank(tmp_path, data_dir):
    from src.modules.console import branding
    with _client(tmp_path) as client:
        admin = _admin(client)
        r = client.put("/api/v1/console/branding", headers=_h(admin),
                       json={"signin_notice": ""})
        assert r.status_code == 200
        d = client.get("/api/v1/console/branding").json()
        assert d["branding"]["signin_notice"] == \
            branding.DEFAULTS["signin_notice"]
        assert "email_defaults" in d


# ── UR-08: break-glass reset ──

def test_break_glass_reset(tmp_path, data_dir, monkeypatch):
    import config
    from desktop import breakglass
    from src.core.db import Database
    from src.modules.auth.models import AppUser
    from src.modules.auth.store import UserStore
    cfg = _cfg(tmp_path)
    store = UserStore(Database.from_config(cfg))
    user = AppUser(username="alice", role="admin")
    user.set_password(PASSWORD)
    user.failed_attempts = 9
    user.locked_until = "2999-01-01T00:00:00+09:00"
    store.create(user)
    monkeypatch.setattr(config, "get_config", lambda: cfg)
    monkeypatch.setenv(breakglass.PASSWORD_ENV, "BreakGlass2026x")
    assert breakglass.reset_console_password(["nobody"]) == 1
    assert breakglass.reset_console_password([]) == 2
    assert breakglass.reset_console_password(["alice"]) == 0
    after = UserStore(Database.from_config(cfg)).get_by_username("alice")
    assert after.check_password("BreakGlass2026x")
    assert after.must_change_password and not after.is_locked()
    monkeypatch.setenv(breakglass.PASSWORD_ENV, "short")
    assert breakglass.reset_console_password(["alice"]) == 1


# ── The console page ──

def test_page_script_changes():
    js = (UI / "app.js").read_text(encoding="utf-8")
    html = (UI / "index.html").read_text(encoding="utf-8")
    assert 'id="su-pass2"' in html and 'id="cp-new2"' in html
    assert "body.password !== $('su-pass2').value" in js
    assert "body.new_password !== $('cp-new2').value" in js
    assert "function openUserEdit(u)" in js and "'Reset password'" in js
    assert "api('/admin/role-names')" in js
    assert "u.user_id === ME.user_id" in js
    assert "a reason is required" in js and "loadRuleHistory();" in js
    assert 'id="us-export"' in html and "'/admin/users/export'" in js
    assert "EMAIL_DEFAULTS.footer_text" in js
