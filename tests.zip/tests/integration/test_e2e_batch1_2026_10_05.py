"""End-to-end QA of 5 October 2026, batch 1 (E2E-H01, E2E-H02).

H01: a fresh sign-in counts as activity, so the first inactivity check
does not sign the person out; an automatic renewal still does not.
H02: a ticket with several codes is written by one writer at a time,
and a delivered write-back is never recorded again as "refused".
"""
import re
from pathlib import Path

from src.core.db import Database
from src.integrations.servicenow.client import ServiceNowError
from src.integrations.servicenow.config import ServiceNowSettings
from src.integrations.servicenow.writeback import (MARKER, TicketCloseout,
                                                   _TicketView)
from src.modules.queue.services import QueueStore
from tests.conftest import make_config
from tests.unit.test_sailpoint_process import finish, ticket_requests
from tests.unit.test_servicenow_module import _Audit, _Log

APP_JS = Path(__file__).resolve().parents[2] / "desktop" / "ui" / "app.js"


def _function(src: str, name: str) -> str:
    start = src.index(f"function {name}(")
    nxt = re.search(r"\n(async )?function ", src[start + 10:])
    return src[start:start + 10 + nxt.start()] if nxt else src[start:]


# ── E2E-H01 ──────────────────────────────────────────────────────

class TestSignInCountsAsActivity:
    def test_every_sign_in_path_records_activity(self):
        src = APP_JS.read_text(encoding="utf-8")
        for name in ("doWindowsLogin", "doLogin", "doChange"):
            body = _function(src, name)
            at = body.index("setSession(r)")
            assert "markActivity(true)" in body[at:at + 200], name

    def test_a_renewal_is_not_activity(self):
        src = APP_JS.read_text(encoding="utf-8")
        assert "markActivity" not in _function(src, "setSession")
        assert "markActivity" not in _function(src, "renewSession")


# ── E2E-H02 ──────────────────────────────────────────────────────

class _Snow:
    """A ServiceNow that is down until `down` is cleared, and whose
    ticket is no longer active once it was closed."""

    def __init__(self):
        self.down, self.closed, self.calls = True, False, []

    def _check(self):
        if self.down:
            raise ServiceNowError("not reachable")

    def get_records(self, table, query="", fields=None, limit=10):
        self._check()
        return [] if self.closed else [{"sys_id": "a" * 32}]

    def set_state(self, sys_id, state, note=None, table="", extra=None):
        self._check()
        self.calls.append(("close", state))
        self.closed = True

    def add_work_note(self, sys_id, note, table=""):
        self._check()
        self.calls.append(("note", note))


def _setup(tmp_path, client, on_sleep):
    db = Database.from_config(make_config(tmp_path))
    q = QueueStore(db)
    reqs = ticket_requests(q)
    done = [finish(q, r) for r in reqs]
    s = ServiceNowSettings(instance_url="https://x", username="bot",
                           password="p", table="sc_task")
    audit, log = _Audit(), _Log()
    co = TicketCloseout(logger=log, audit=audit, settings_loader=lambda: s,
                        client_factory=lambda st: client, async_send=False,
                        sleep_func=on_sleep)
    co.queue_store = q
    co.GRACE_SECONDS = 0
    return db, q, done, co, audit, log


class TestOneWriterPerTicket:
    def test_catch_up_starts_no_second_writer(self, tmp_path):
        client = _Snow()
        state = {}

        def on_sleep(delay):
            # ServiceNow is back while the first writer waits; the
            # poller's catch-up runs for the same ticket meanwhile.
            client.down = False
            q = state["q"]
            state["started"] = state["co"].reconcile(
                q.get(state["done"][0].request_id))
            state["calls_during_wait"] = list(client.calls)

        db, q, done, co, audit, log = _setup(tmp_path, client, on_sleep)
        state.update(q=q, co=co, done=done)
        try:
            co.handle_completion(done[-1], q.get(done[-1].request_id), {})
            assert state["calls_during_wait"] == []      # no second writer
            assert client.calls == [("close", co._load().close_state)]
            assert not [e for e in audit.events
                        if e[1] == "servicenow_ticket_update_refused"]
            assert not [m for lvl, m in log.lines if "REFUSED" in m]
            mark = q.get(done[0].request_id).metadata[MARKER]
            assert mark["action"] == "close" and not mark["pending"]
            assert not mark["note"].startswith("refused")
        finally:
            db.close()

    def test_both_paths_use_the_same_key(self, tmp_path):
        client = _Snow()
        db, q, done, co, _, _ = _setup(tmp_path, client, lambda d: None)
        try:
            seen = []

            def record(txn, req, res, sys_id, rid):
                seen.append(rid)
                co._inflight.discard(rid)
            co._run = record
            co.handle_completion(done[-1], q.get(done[-1].request_id), {})
            co.reconcile(q.get(done[0].request_id))
            assert seen == ["SCTASK9", "SCTASK9"]
        finally:
            db.close()

    def test_delivered_meanwhile_is_never_recorded_as_refused(self, tmp_path):
        client = _Snow()
        state = {}

        def on_sleep(delay):
            # Another writer delivered the close while this one waited.
            client.down = False
            client.closed = True
            members = [state["q"].get(r.request_id) for r in state["done"]]
            state["co"]._mark(_TicketView(members, "SCTASK9"), "close")

        db, q, done, co, audit, log = _setup(tmp_path, client, on_sleep)
        state.update(q=q, co=co, done=done)
        try:
            co.handle_completion(done[-1], q.get(done[-1].request_id), {})
            assert client.calls == []
            assert not [e for e in audit.events
                        if e[1] == "servicenow_ticket_update_refused"]
            assert not [lvl for lvl, m in log.lines if lvl == "error"]
            assert any("already written" in m for _, m in log.lines)
            for r in done:
                mark = q.get(r.request_id).metadata[MARKER]
                assert mark["action"] == "close" and not mark["pending"]
                assert not mark["note"].startswith("refused")
        finally:
            db.close()

    def test_a_note_is_not_written_twice(self, tmp_path):
        client = _Snow()
        state = {}

        def on_sleep(delay):
            client.down = False
            members = [state["q"].get(r.request_id) for r in state["done"]]
            state["co"]._mark(_TicketView(members, "SCTASK9"), "review_note")

        db, q, done, co, _, _ = _setup(tmp_path, client, on_sleep)
        q.mark_complete(done[0].request_id, "done", result_code="UNCONFIRMED")
        state.update(q=q, co=co, done=done)
        try:
            co.handle_completion(done[-1], q.get(done[-1].request_id), {})
            assert client.calls == []
        finally:
            db.close()

    def test_a_ticket_still_open_is_written_once(self, tmp_path):
        client = _Snow()
        client.down = False
        db, q, done, co, audit, _ = _setup(tmp_path, client, lambda d: None)
        try:
            co.handle_completion(done[-1], q.get(done[-1].request_id), {})
            assert co.reconcile(q.get(done[0].request_id)) is False
            assert len(client.calls) == 1
            assert [e[1] for e in audit.events] == ["servicenow_ticket_updated"]
        finally:
            db.close()
