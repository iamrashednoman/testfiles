"""Console auth through the real app: bootstrap, sign-in, roles, users.

Also pins the boundary that matters most: adding human accounts must
not change how the MACHINE API key works, because the ServiceNow
connector and the CLI depend on it.
"""
import pytest

from tests.conftest import make_config

VALID = {"operation": "provision", "affiliation_code": "30822",
         "employee_code": "1217036", "password": "FUJI@33F"}
PASSWORD = "CorrectHorse42"


def _client(tmp_path, **overrides):
    from fastapi.testclient import TestClient
    from src import create_app
    cfg = make_config(tmp_path, dispatcher_enabled=False,
                      terminal_driver="mock",
                      log_dir=str(tmp_path / "logs"), **overrides)
    return TestClient(create_app(cfg))


def _bootstrap(client, username="alice", password=PASSWORD):
    r = client.post("/api/v1/auth/bootstrap",
                    json={"username": username, "password": password})
    assert r.status_code == 201, r.text
    return r.json()["user"]


def _login(client, username="alice", password=PASSWORD):
    r = client.post("/api/v1/auth/login",
                    json={"username": username, "password": password})
    assert r.status_code == 200, r.text
    return r.json()["access_token"]


def _auth(token):
    return {"Authorization": f"Bearer {token}"}


NEW_PASSWORD = "TheirOwnSecret77"


def _activate(client, username, provisional=PASSWORD,
              chosen=NEW_PASSWORD):
    """Complete the first-sign-in flow for an admin-created account.

    An admin-set password is PROVISIONAL: every route answers 428 until
    the user picks their own. This is that exchange, so tests can get
    to the behaviour they actually mean to check.
    """
    token = _login(client, username, provisional)
    r = client.post("/api/v1/auth/password", headers=_auth(token),
                    json={"current_password": provisional,
                          "new_password": chosen})
    assert r.status_code == 200, r.text
    return _login(client, username, chosen)


class TestFirstRun:
    def test_fresh_install_reports_uninitialised(self, tmp_path):
        with _client(tmp_path) as client:
            body = client.get("/api/v1/auth/status").json()
            assert body["initialised"] is False

    def test_bootstrap_then_sign_in(self, tmp_path):
        with _client(tmp_path) as client:
            user = _bootstrap(client)
            assert user["role"] == "admin"
            assert "password_hash" not in user
            assert client.get("/api/v1/auth/status").json()["initialised"]

            token = _login(client)
            me = client.get("/api/v1/auth/me", headers=_auth(token))
            assert me.json()["user"]["username"] == "alice"

    def test_bootstrap_is_single_use(self, tmp_path):
        """It is unauthenticated by necessity — it must slam shut."""
        with _client(tmp_path) as client:
            _bootstrap(client)
            r = client.post("/api/v1/auth/bootstrap",
                            json={"username": "mallory",
                                  "password": PASSWORD})
            assert r.status_code == 409

    def test_weak_bootstrap_password_rejected(self, tmp_path):
        with _client(tmp_path) as client:
            r = client.post("/api/v1/auth/bootstrap",
                            json={"username": "alice", "password": "weak"})
            assert r.status_code == 400
            assert "12 characters" in r.json()["detail"]


class TestSignIn:
    def test_bad_credentials_rejected(self, tmp_path):
        with _client(tmp_path) as client:
            _bootstrap(client)
            r = client.post("/api/v1/auth/login",
                            json={"username": "alice", "password": "no"})
            assert r.status_code == 401

    def test_protected_routes_need_a_token(self, tmp_path):
        with _client(tmp_path) as client:
            _bootstrap(client)
            assert client.get("/api/v1/auth/me").status_code == 401
            assert client.get("/api/v1/admin/users").status_code == 401

    def test_logout_invalidates_the_token(self, tmp_path):
        with _client(tmp_path) as client:
            _bootstrap(client)
            token = _login(client)
            assert client.get("/api/v1/auth/me",
                              headers=_auth(token)).status_code == 200
            client.post("/api/v1/auth/logout", headers=_auth(token))
            assert client.get("/api/v1/auth/me",
                              headers=_auth(token)).status_code == 401

    def test_password_change_flow(self, tmp_path):
        with _client(tmp_path) as client:
            _bootstrap(client)
            token = _login(client)
            r = client.post("/api/v1/auth/password", headers=_auth(token),
                            json={"current_password": PASSWORD,
                                  "new_password": "BrandNewSecret99"})
            assert r.status_code == 200
            # The old session died with the old password.
            assert client.get("/api/v1/auth/me",
                              headers=_auth(token)).status_code == 401
            _login(client, password="BrandNewSecret99")


class TestRoles:
    def _make(self, client, token, username, role, password=PASSWORD):
        r = client.post("/api/v1/admin/users", headers=_auth(token),
                        json={"username": username, "password": password,
                              "role": role})
        assert r.status_code == 201, r.text
        return r.json()["user"]

    def test_viewer_cannot_manage_users(self, tmp_path):
        with _client(tmp_path) as client:
            _bootstrap(client)
            admin_token = _login(client)
            self._make(client, admin_token, "vic", "viewer")

            viewer_token = _activate(client, "vic")
            r = client.get("/api/v1/admin/users",
                           headers=_auth(viewer_token))
            assert r.status_code == 403
            # Names the missing PERMISSION, which stays accurate once
            # roles are custom (a role name would not). Reading the
            # accounts needs users.view (or users.manage) since
            # 2026-10-03 (UR-05).
            assert "users.view" in r.json()["detail"]
            assert "viewer" in r.json()["detail"]

    def test_viewer_can_read_own_identity(self, tmp_path):
        with _client(tmp_path) as client:
            _bootstrap(client)
            self._make(client, _login(client), "vic", "viewer")
            token = _activate(client, "vic")
            assert client.get("/api/v1/auth/me",
                              headers=_auth(token)).json()["user"]["role"] \
                == "viewer"

    def test_unknown_role_rejected(self, tmp_path):
        with _client(tmp_path) as client:
            _bootstrap(client)
            r = client.post("/api/v1/admin/users",
                            headers=_auth(_login(client)),
                            json={"username": "mallory",
                                  "password": PASSWORD,
                                  "role": "superuser"})
            assert r.status_code == 400
            assert "role must be one of" in r.json()["detail"]

    def test_short_username_rejected_by_schema(self, tmp_path):
        with _client(tmp_path) as client:
            _bootstrap(client)
            r = client.post("/api/v1/admin/users",
                            headers=_auth(_login(client)),
                            json={"username": "x", "password": PASSWORD,
                                  "role": "viewer"})
            assert r.status_code == 422

    def test_account_with_no_credentials_rejected(self, tmp_path):
        """Neither a password nor a Windows mapping = can never sign
        in."""
        with _client(tmp_path) as client:
            _bootstrap(client)
            r = client.post("/api/v1/admin/users",
                            headers=_auth(_login(client)),
                            json={"username": "ghost", "role": "viewer"})
            assert r.status_code == 400


class TestUserManagement:
    def test_duplicate_username_conflicts(self, tmp_path):
        with _client(tmp_path) as client:
            _bootstrap(client)
            token = _login(client)
            body = {"username": "bob", "password": PASSWORD,
                    "role": "operator"}
            assert client.post("/api/v1/admin/users", headers=_auth(token),
                               json=body).status_code == 201
            assert client.post("/api/v1/admin/users", headers=_auth(token),
                               json=body).status_code == 409

    def test_deactivating_a_user_kills_their_session(self, tmp_path):
        with _client(tmp_path) as client:
            _bootstrap(client)
            admin_token = _login(client)
            created = client.post(
                "/api/v1/admin/users", headers=_auth(admin_token),
                json={"username": "bob", "password": PASSWORD,
                      "role": "operator"}).json()["user"]
            bob_token = _activate(client, "bob")

            client.patch(f"/api/v1/admin/users/{created['user_id']}",
                         headers=_auth(admin_token),
                         json={"is_active": False})
            assert client.get("/api/v1/auth/me",
                              headers=_auth(bob_token)).status_code == 401

    def test_role_change_revokes_the_old_session(self, tmp_path):
        """A demoted operator must not keep operator rights until their
        token expires."""
        with _client(tmp_path) as client:
            _bootstrap(client)
            admin_token = _login(client)
            created = client.post(
                "/api/v1/admin/users", headers=_auth(admin_token),
                json={"username": "bob", "password": PASSWORD,
                      "role": "admin"}).json()["user"]
            bob_token = _activate(client, "bob")
            client.patch(f"/api/v1/admin/users/{created['user_id']}",
                         headers=_auth(admin_token),
                         json={"role": "viewer"})
            assert client.get("/api/v1/auth/me",
                              headers=_auth(bob_token)).status_code == 401

    def test_last_admin_cannot_be_demoted(self, tmp_path):
        """An install must never be left with nobody who can manage
        it."""
        with _client(tmp_path) as client:
            user = _bootstrap(client)
            token = _login(client)
            r = client.patch(f"/api/v1/admin/users/{user['user_id']}",
                             headers=_auth(token), json={"role": "viewer"})
            assert r.status_code == 409
            assert "last active administrator" in r.json()["detail"]

    def test_last_admin_cannot_be_deactivated_or_deleted(self, tmp_path):
        with _client(tmp_path) as client:
            user = _bootstrap(client)
            token = _login(client)
            assert client.patch(
                f"/api/v1/admin/users/{user['user_id']}",
                headers=_auth(token),
                json={"is_active": False}).status_code == 409
            assert client.delete(
                f"/api/v1/admin/users/{user['user_id']}",
                headers=_auth(token)).status_code == 409

    def test_demotion_allowed_once_another_admin_exists(self, tmp_path):
        with _client(tmp_path) as client:
            first = _bootstrap(client)
            token = _login(client)
            client.post("/api/v1/admin/users", headers=_auth(token),
                        json={"username": "bob", "password": PASSWORD,
                              "role": "admin"})
            r = client.patch(f"/api/v1/admin/users/{first['user_id']}",
                             headers=_auth(token), json={"role": "viewer"})
            assert r.status_code == 200

    def test_hashes_never_appear_in_any_response(self, tmp_path):
        with _client(tmp_path) as client:
            _bootstrap(client)
            token = _login(client)
            body = client.get("/api/v1/admin/users",
                              headers=_auth(token)).text
            assert "password_hash" not in body
            assert "password_salt" not in body
            assert PASSWORD not in body


class TestWindowsSsoRoute:
    def test_disabled_by_default(self, tmp_path):
        with _client(tmp_path) as client:
            _bootstrap(client)
            assert client.post(
                "/api/v1/auth/login/windows").status_code == 404

    def test_status_reports_availability(self, tmp_path):
        with _client(tmp_path) as client:
            assert client.get("/api/v1/auth/status").json()[
                "windows_sso_available"] is False


class TestMachineApiKeyUnaffected:
    """The intake contract must be byte-for-byte what it was."""

    def test_intake_still_open_when_api_auth_is_off(self, tmp_path):
        with _client(tmp_path) as client:
            assert client.post("/api/v1/requests",
                               json=VALID).status_code == 202
            assert client.get("/api/v1/health").status_code == 200

    def test_console_token_is_not_an_api_key(self, tmp_path,
                                             monkeypatch):
        """The two schemes are independent — a console session must not
        satisfy the machine API key."""
        monkeypatch.setenv("FINESIII_API_KEYS", "svc:secret-key-value")
        with _client(tmp_path, auth_enabled=True) as client:
            _bootstrap(client)
            token = _login(client)
            r = client.post("/api/v1/requests", json=VALID,
                            headers=_auth(token))
            assert r.status_code == 401

    def test_api_key_is_not_a_console_session(self, tmp_path,
                                              monkeypatch):
        monkeypatch.setenv("FINESIII_API_KEYS", "svc:secret-key-value")
        with _client(tmp_path, auth_enabled=True) as client:
            _bootstrap(client)
            assert client.post("/api/v1/requests", json=VALID,
                               headers={"X-API-Key": "secret-key-value"}
                               ).status_code == 202
            # …but it grants no console access.
            assert client.get("/api/v1/admin/users",
                              headers={"X-API-Key": "secret-key-value"}
                              ).status_code == 401

    def test_console_can_be_disabled_entirely(self, tmp_path):
        with _client(tmp_path, auth_console_enabled=False) as client:
            assert client.get("/api/v1/auth/status").status_code == 404
            assert client.post("/api/v1/requests",
                               json=VALID).status_code == 202


class TestConsoleNeverBlocksTheService:
    """The console is an ADDITION. The production Postgres role
    deliberately does not own its tables (append-only enforcement), so
    a fresh deployment of this feature cannot create them — and that
    must not stop the queue, dispatcher or intake API from starting.
    """

    def test_service_starts_when_console_tables_cannot_be_created(
            self, tmp_path, monkeypatch):
        from src.modules.auth import store as store_module

        def refuse(self):
            raise PermissionError("permission denied for schema public")

        # The DDL is split per table now, so refuse the first one.
        monkeypatch.setattr(store_module.UserStore, "_create_users",
                            staticmethod(refuse))

        with _client(tmp_path) as client:
            # The core contract is untouched…
            assert client.get("/api/v1/health").status_code == 200
            assert client.post("/api/v1/requests",
                               json=VALID).status_code == 202
            # …and the console is simply absent.
            assert client.get("/api/v1/auth/status").status_code == 404

    def test_schema_error_is_actionable(self, tmp_path, monkeypatch):
        from src.modules.auth.store import (
            SchemaUnavailableError, UserStore,
        )

        def refuse(conn):
            raise PermissionError("permission denied for schema public")

        monkeypatch.setattr(UserStore, "_create_users",
                            staticmethod(refuse))
        from src.core.db import Database
        with pytest.raises(SchemaUnavailableError) as e:
            UserStore(Database("sqlite",
                               sqlite_path=str(tmp_path / "x.db")))
        assert "app_users" in str(e.value)  # names what is missing
        assert "permission denied" in str(e.value)

    def test_existing_tables_are_never_recreated(self, tmp_path,
                                                 monkeypatch):
        """When a DBA has applied schema.sql the store must skip its
        bootstrap DDL entirely — even a no-op CREATE fails Postgres's
        ownership check.

        Patched with monkeypatch, NOT setattr: reading a staticmethod
        off the class hands back the plain function, so restoring it by
        hand turns it into an instance method and breaks every later
        test in the run.
        """
        from src.core.db import Database
        from src.modules.auth.store import UserStore

        db = Database("sqlite", sqlite_path=str(tmp_path / "y.db"))
        UserStore(db)                       # creates them
        calls = []
        for name in ("_create_users", "_create_sessions", "_create_roles"):
            monkeypatch.setattr(
                UserStore, name,
                staticmethod(lambda conn, n=name: calls.append(n)))
        UserStore(db)                       # second open: no DDL at all
        assert calls == []


class TestProvisionalPassword:
    """An admin-set password must be changed before it is usable.

    Phase 2 wrote the flag and never checked it, which made it purely
    decorative — a user could keep a credential someone else chose for
    them indefinitely.
    """

    def _create(self, client, admin_token, username="carol"):
        r = client.post("/api/v1/admin/users", headers=_auth(admin_token),
                        json={"username": username, "password": PASSWORD,
                              "role": "operator"})
        assert r.status_code == 201
        return r.json()["user"]

    def test_login_says_a_change_is_required(self, tmp_path):
        with _client(tmp_path) as client:
            _bootstrap(client)
            self._create(client, _login(client))
            body = client.post("/api/v1/auth/login",
                               json={"username": "carol",
                                     "password": PASSWORD}).json()
            assert body["must_change_password"] is True

    def test_every_other_route_is_refused_until_changed(self, tmp_path):
        with _client(tmp_path) as client:
            _bootstrap(client)
            self._create(client, _login(client))
            token = _login(client, "carol")
            r = client.get("/api/v1/console/summary", headers=_auth(token))
            assert r.status_code == 428
            assert "must be changed" in r.json()["detail"]

    def test_the_change_route_itself_stays_reachable(self, tmp_path):
        """Otherwise the user is locked out of the one action that
        unlocks them."""
        with _client(tmp_path) as client:
            _bootstrap(client)
            self._create(client, _login(client))
            token = _login(client, "carol")
            assert client.get("/api/v1/auth/me",
                              headers=_auth(token)).status_code == 200
            r = client.post("/api/v1/auth/password", headers=_auth(token),
                            json={"current_password": PASSWORD,
                                  "new_password": NEW_PASSWORD})
            assert r.status_code == 200

    def test_normal_access_resumes_after_the_change(self, tmp_path):
        with _client(tmp_path) as client:
            _bootstrap(client)
            self._create(client, _login(client))
            token = _activate(client, "carol")
            assert client.get("/api/v1/console/summary",
                              headers=_auth(token)).status_code == 200
            assert client.post("/api/v1/auth/login", json={
                "username": "carol", "password": NEW_PASSWORD
            }).json()["must_change_password"] is False

    def test_the_bootstrap_admin_is_not_provisional(self, tmp_path):
        """They chose their own password — nothing to force."""
        with _client(tmp_path) as client:
            _bootstrap(client)
            body = client.post("/api/v1/auth/login",
                               json={"username": "alice",
                                     "password": PASSWORD}).json()
            assert body["must_change_password"] is False
