"""New-bug fixes through the service interface — intake (round 2).

  NB-007  employee code with a tab, space or '-' → 400.
  NB-014  field length limits → 413 audited with shortened values;
          unknown source → 400.
  NB-015  database not reachable → 503 with Retry-After, not a bare 500.
  NB-017  the stop-accepting buffer before the window closes has its own
          submit message.
"""
from __future__ import annotations

import sqlite3

import pytest

from tests.conftest import make_config

VALID = {"operation": "deprovision", "affiliation_code": "30822",
         "employee_code": "1217036"}


@pytest.fixture(autouse=True)
def data_dir(tmp_path, monkeypatch):
    d = tmp_path / "data"
    d.mkdir()
    monkeypatch.setenv("FINESIII_DATA_DIR", str(d))
    return d


def _app(tmp_path, audit=False, **overrides):
    from src import create_app
    if audit:
        overrides.update(
            audit_enabled=True, audit_backend="sqlite",
            audit_sqlite_path=str(tmp_path / "audit.db"),
            audit_spool_path=str(tmp_path / "spool.db"),
            audit_flush_interval_seconds=0.05)
    return create_app(make_config(tmp_path, dispatcher_enabled=False,
                                  terminal_driver="mock",
                                  log_dir=str(tmp_path / "logs"),
                                  **overrides))


def _client(tmp_path, audit=False, **overrides):
    from fastapi.testclient import TestClient
    return TestClient(_app(tmp_path, audit=audit, **overrides))


def _events(client, **filters):
    audit = client.app.state.audit
    assert audit.flush(timeout=5)
    return audit.backend.query_events(limit=500, **filters)


# ── NB-007 ───────────────────────────────────────────────────────

class TestEmployeeCode:
    @pytest.mark.parametrize("code", ["123\t567", "123 567", "123-567"])
    def test_refused(self, tmp_path, code):
        with _client(tmp_path) as client:
            r = client.post("/api/v1/requests",
                            json={**VALID, "employee_code": code})
            assert r.status_code == 400
            assert "7 half-width letters or digits" in r.json()["detail"]
            assert client.get("/api/v1/requests").json()["count"] == 0

    @pytest.mark.parametrize("code", ["4821KQT", "1217036", " 1217036 "])
    def test_accepted(self, tmp_path, code):
        with _client(tmp_path) as client:
            r = client.post("/api/v1/requests",
                            json={**VALID, "employee_code": code})
            assert r.status_code == 202, r.text


# ── NB-014 ───────────────────────────────────────────────────────

class TestFieldLimits:
    def test_long_ticket_id_is_413_and_audited_shortened(self, tmp_path):
        with _client(tmp_path, audit=True) as client:
            r = client.post("/api/v1/requests",
                            json={**VALID, "ticket_id": "T" * 81})
            assert r.status_code == 413
            assert r.json()["detail"] == "ticket_id exceeds 80 characters"
            rejected = _events(client, action="request_rejected")
            assert rejected and rejected[0]["status"] == "too_large"
            assert rejected[0]["ticket_id"] == "T" * 80
            assert client.get("/api/v1/requests").json()["count"] == 0

    def test_huge_source_is_audited_shortened(self, tmp_path):
        with _client(tmp_path, audit=True) as client:
            r = client.post("/api/v1/requests",
                            json={**VALID, "source": "s" * 100_000})
            assert r.status_code == 413
            assert r.json()["detail"] == "source exceeds 40 characters"
            rejected = _events(client, action="request_rejected")
            assert rejected[0]["source"] == "s" * 40

    @pytest.mark.parametrize("field,limit", [
        ("source", 40), ("operation", 40), ("affiliation_code", 40),
        ("employee_code", 40), ("password", 128)])
    def test_each_limit(self, tmp_path, field, limit):
        with _client(tmp_path) as client:
            r = client.post("/api/v1/requests",
                            json={**VALID, field: "x" * (limit + 1)})
            assert r.status_code == 413
            assert r.json()["detail"] == f"{field} exceeds {limit} characters"

    def test_ticket_at_the_limit_is_accepted(self, tmp_path):
        with _client(tmp_path) as client:
            r = client.post("/api/v1/requests",
                            json={**VALID, "ticket_id": "T" * 80})
            assert r.status_code == 202

    def test_metadata_413_audits_shortened_values(self, tmp_path):
        with _client(tmp_path, audit=True) as client:
            r = client.post("/api/v1/requests", json={
                **VALID, "ticket_id": "SCTASK1",
                "metadata": {"blob": "x" * (70 * 1024)}})
            assert r.status_code == 413
            rejected = _events(client, action="request_rejected")
            assert rejected[0]["ticket_id"] == "SCTASK1"


class TestSource:
    def test_unknown_source_is_400(self, tmp_path):
        with _client(tmp_path) as client:
            r = client.post("/api/v1/requests",
                            json={**VALID, "source": "foo"})
            assert r.status_code == 400
            assert r.json()["detail"] == (
                "source must be one of manual, servicenow, sailpoint, api, "
                "cli (got 'foo')")

    @pytest.mark.parametrize("source", ["manual", "servicenow", "api"])
    def test_known_source_is_accepted(self, tmp_path, source):
        with _client(tmp_path) as client:
            r = client.post("/api/v1/requests", json={
                **VALID, "source": source, "ticket_id": f"T-{source}"})
            assert r.status_code == 202, r.text

    def test_default_source_is_accepted(self, tmp_path):
        with _client(tmp_path) as client:
            r = client.post("/api/v1/requests", json=VALID)
            assert r.status_code == 202
            rid = r.json()["request_id"]
            assert client.get(f"/api/v1/requests/{rid}").json()["source"] \
                == "manual"


# ── NB-015 ───────────────────────────────────────────────────────

def _down(*a, **kw):
    raise sqlite3.OperationalError("unable to open database file")


class TestDatabaseUnavailable:
    def test_submit_is_503_not_queued(self, tmp_path, caplog):
        import logging
        from fastapi.testclient import TestClient
        app = _app(tmp_path)
        with TestClient(app, raise_server_exceptions=False) as client:
            app.state.queue_store.find_duplicate = _down
            with caplog.at_level(logging.WARNING,
                                 logger="src.modules.intake.routes"):
                r = client.post("/api/v1/requests", json=VALID)
        lines = [rec for rec in caplog.records
                 if rec.name == "src.modules.intake.routes"]
        assert len(lines) == 1 and lines[0].exc_info is None
        assert lines[0].getMessage() == (
            "Database not reachable — POST /api/v1/requests: "
            "OperationalError: unable to open database file")
        assert r.status_code == 503
        assert r.headers["Retry-After"] == "30"
        detail = r.json()["detail"]
        assert detail["status"] == "database_unavailable"
        assert detail["message"] == ("Database not reachable — the request "
                                     "was not queued; try again later")

    def test_list_is_503(self, tmp_path):
        from fastapi.testclient import TestClient
        app = _app(tmp_path)
        with TestClient(app, raise_server_exceptions=False) as client:
            app.state.queue_store.list_requests = _down
            r = client.get("/api/v1/requests")
        assert r.status_code == 503
        assert r.headers["Retry-After"] == "30"
        assert r.json()["detail"]["message"] == \
            "Database not reachable — try again later"

    def test_generated_password_lookup_reaches_the_handler(self, tmp_path):
        from fastapi.testclient import TestClient
        app = _app(tmp_path)
        with TestClient(app, raise_server_exceptions=False) as client:
            app.state.queue_store.password_fingerprint_used = _down
            r = client.post("/api/v1/requests",
                            json={**VALID, "operation": "provision"})
        assert r.status_code == 503
        assert "not queued" in r.json()["detail"]["message"]

    def test_postgres_errors_are_covered(self):
        psycopg = pytest.importorskip("psycopg")
        psycopg_pool = pytest.importorskip("psycopg_pool")
        from src.modules.intake.routes import database_errors
        errors = database_errors()
        assert issubclass(psycopg_pool.PoolTimeout, errors)
        assert psycopg.InterfaceError in errors

    def test_other_errors_are_still_500(self, tmp_path):
        from fastapi.testclient import TestClient
        app = _app(tmp_path)

        def boom(*a, **kw):
            raise RuntimeError("bug")
        with TestClient(app, raise_server_exceptions=False) as client:
            app.state.queue_store.list_requests = boom
            r = client.get("/api/v1/requests")
        assert r.status_code == 500

    def test_health_keeps_its_own_answer(self, tmp_path):
        from fastapi.testclient import TestClient
        app = _app(tmp_path)
        with TestClient(app, raise_server_exceptions=False) as client:
            app.state.queue_store.db.fetchone = _down
            r = client.get("/api/v1/health")
        assert r.status_code == 503
        assert r.json()["database"] == "down"


# ── NB-017 ───────────────────────────────────────────────────────

class TestShutdownBufferMessage:
    def test_buffer_has_its_own_wording(self, tmp_path):
        from fastapi.testclient import TestClient
        app = _app(tmp_path)
        av = app.state.availability
        av.is_within_time_window = lambda check_buffer=False: not check_buffer
        start = av.window_start.strftime("%H:%M")
        end = av.window_end.strftime("%H:%M")
        with TestClient(app) as client:
            body = client.post("/api/v1/requests", json=VALID).json()
        assert body["mainframe_available"] is False
        assert body["message"] == (
            f"Request queued. The operating window closes at {end} JST; "
            f"new work starts again when it reopens at {start} JST.")
        assert "offline" not in body["message"]
