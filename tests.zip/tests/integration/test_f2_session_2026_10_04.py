"""F2 of the fix plan (2026-10-04): session and reload.

SES-01  The console's session is a cookie the page cannot read; a reload,
        a second tab or a restart carries on. Bearer and API-key callers
        are unchanged; a change made with the cookie needs the console
        header.
SES-02  The session lifetime is the inactivity limit (30 minutes by
        default); a session ends at its maximum length (12 hours by
        default) however active.
SES-05  "Skip for now" in the setup assistant is remembered per account.
SEC-09  The cookie has no expiry date: it goes when the browser closes.
UAT-L14 The account ID is on the sign-in failure, lock, password change
        and sign-out events.
UAT-L15 A renewal writes no "Logout" event.
UAT-L24 A console user is named "user:<name>" on submit, retry, cancel,
        also with the API key off."""
import re
import tempfile
import time
from pathlib import Path

import pytest

from tests.conftest import make_config

PASSWORD = "CorrectHorse42"
CONSOLE = {"X-FINESIII-Console": "1"}
UI = Path(__file__).resolve().parents[2] / "desktop" / "ui"
APP = (UI / "app.js").read_text(encoding="utf-8")
INDEX = (UI / "index.html").read_text(encoding="utf-8")


@pytest.fixture
def data_dir(tmp_path, monkeypatch):
    from desktop import vault
    d = tmp_path / "data"
    d.mkdir()
    monkeypatch.setenv("FINESIII_DATA_DIR", str(d))
    previous = vault._vault
    vault.use_vault(vault.MemoryVault())
    for k in vault.SECRET_KEYS:
        monkeypatch.delenv(k, raising=False)
    yield d
    vault.use_vault(previous)


def _client(tmp_path, base_url="http://testserver", **overrides):
    from fastapi.testclient import TestClient
    from desktop.server import mount_console_ui
    from src import create_app
    opts = dict(dispatcher_enabled=False, terminal_driver="mock",
                log_dir=str(tmp_path / "logs"))
    opts.update(overrides)
    app = create_app(make_config(tmp_path, **opts))
    mount_console_ui(app, mode="agent", stop_hook=lambda: None)
    return TestClient(app, base_url=base_url)


def _bootstrap(client, username="alice"):
    client.post("/api/v1/auth/bootstrap",
                json={"username": username, "password": PASSWORD})


def _console_login(client, username="alice", password=PASSWORD):
    return client.post("/api/v1/auth/login", headers=CONSOLE,
                       json={"username": username, "password": password})


def _set_cookie(r) -> str:
    return "; ".join(v for k, v in r.headers.multi_items()
                     if k.lower() == "set-cookie")


# ── SES-01: the cookie ──

def test_console_sign_in_sets_a_cookie_the_page_cannot_read(tmp_path,
                                                            data_dir):
    with _client(tmp_path) as client:
        _bootstrap(client)
        r = _console_login(client)
        assert r.status_code == 200, r.text
        body = r.json()
        assert "access_token" not in body          # nothing for page script
        assert body["session"] == "cookie"
        cookie = _set_cookie(r)
        assert cookie.startswith("finesiii_session_")
        assert "HttpOnly" in cookie
        assert "SameSite=strict" in cookie or "SameSite=Strict" in cookie
        assert "Path=/api" in cookie
        # SEC-09: no expiry date, so the browser drops it when it closes.
        assert "Max-Age" not in cookie and "expires" not in cookie.lower()
        assert "Secure" not in cookie               # plain http on this machine


def test_cookie_is_secure_over_https(tmp_path, data_dir):
    with _client(tmp_path, base_url="https://testserver") as client:
        _bootstrap(client)
        assert "Secure" in _set_cookie(_console_login(client))


def test_other_callers_still_get_the_token_and_no_cookie(tmp_path,
                                                         data_dir):
    with _client(tmp_path) as client:
        _bootstrap(client)
        r = client.post("/api/v1/auth/login",
                        json={"username": "alice", "password": PASSWORD})
        assert r.status_code == 200 and r.json()["access_token"]
        assert "set-cookie" not in {k.lower() for k in r.headers.keys()}
        token = r.json()["access_token"]
        me = client.get("/api/v1/auth/me",
                        headers={"Authorization": f"Bearer {token}"})
        assert me.status_code == 200


def test_a_reload_carries_on_with_the_cookie(tmp_path, data_dir):
    with _client(tmp_path) as client:
        _bootstrap(client)
        _console_login(client)
        me = client.get("/api/v1/auth/me", headers=CONSOLE)
        assert me.status_code == 200, me.text
        data = me.json()
        assert data["user"]["username"] == "alice"
        assert data["expires_in"] == 1800            # the inactivity limit
        assert 0 < data["session_remaining"] <= 1800
        assert data["max_session_hours"] == 12
        # A page without the console header reads too (GET is safe).
        assert client.get("/api/v1/auth/me").status_code == 200


def test_a_change_with_the_cookie_needs_the_console_header(tmp_path,
                                                           data_dir):
    with _client(tmp_path) as client:
        _bootstrap(client)
        _console_login(client)
        r = client.put("/api/v1/console/settings",
                       json={"max_attempts": "3"})
        assert r.status_code == 403
        assert "console page" in r.json()["detail"]
        r = client.put("/api/v1/console/settings", headers=CONSOLE,
                       json={"max_attempts": "3"})
        assert r.status_code == 200, r.text


def test_an_explicit_bearer_header_wins_over_the_cookie(tmp_path,
                                                        data_dir):
    with _client(tmp_path) as client:
        _bootstrap(client)
        _console_login(client)
        r = client.get("/api/v1/auth/me",
                       headers={"Authorization": "Bearer not-a-token"})
        assert r.status_code == 401


def test_sign_out_ends_the_session_and_clears_the_cookie(tmp_path,
                                                         data_dir):
    with _client(tmp_path) as client:
        _bootstrap(client)
        _console_login(client)
        name = next(iter(client.cookies.keys()))
        stolen = client.cookies.get(name)
        r = client.post("/api/v1/auth/logout", headers=CONSOLE)
        assert r.status_code == 200
        assert "Max-Age=0" in _set_cookie(r) or 'expires=' in _set_cookie(r).lower()
        assert client.get("/api/v1/auth/me").status_code == 401
        # The old value is refused even when presented again.
        r = client.get("/api/v1/auth/me",
                       headers={"Authorization": f"Bearer {stolen}"})
        assert r.status_code == 401


def test_renewal_replaces_the_cookie(tmp_path, data_dir):
    with _client(tmp_path) as client:
        _bootstrap(client)
        _console_login(client)
        name = next(iter(client.cookies.keys()))
        before = client.cookies.get(name)
        r = client.post("/api/v1/auth/refresh", headers=CONSOLE)
        assert r.status_code == 200, r.text
        assert "access_token" not in r.json()
        after = client.cookies.get(name)
        assert after and after != before
        assert client.get("/api/v1/auth/me").status_code == 200
        r = client.get("/api/v1/auth/me",
                       headers={"Authorization": f"Bearer {before}"})
        assert r.status_code == 401                 # the old one is revoked


def test_one_cookie_per_port():
    from src.modules.auth.cookie import cookie_name
    assert cookie_name({"server": ("127.0.0.1", 8000)}) == \
        "finesiii_session_8000"
    assert cookie_name({"server": ("127.0.0.1", 8001)}) != \
        cookie_name({"server": ("127.0.0.1", 8000)})


def test_api_key_callers_are_untouched_by_a_cookie(tmp_path, data_dir,
                                                   monkeypatch):
    """With the API key on, an intake call with the key passes and a
    stale console cookie beside it changes nothing."""
    monkeypatch.setenv("FINESIII_API_KEYS", "snow:k-123")
    with _client(tmp_path, auth_enabled=True) as client:
        _bootstrap(client)
        client.cookies.set("finesiii_session_80", "stale", path="/api")
        r = client.get("/api/v1/requests", headers={"X-API-Key": "k-123"})
        assert r.status_code == 200, r.text


# ── SES-02: inactivity limit and maximum length ──

class _Cfg:
    jwt_secret = "test-signing-key-not-for-production-0123456789"
    jwt_ttl_seconds = 1800
    auth_max_session_hours = 1
    auth_min_password_length = 12
    auth_max_failed_attempts = 3
    auth_lockout_seconds = 900


@pytest.fixture
def auth():
    from src.core.db import Database
    from src.modules.auth.models import AppUser, Role
    from src.modules.auth.services import AuthService
    from src.modules.auth.store import UserStore
    store = UserStore(Database("sqlite",
                               sqlite_path=tempfile.mktemp(suffix=".db")))
    user = AppUser(username="alice", role=Role.ADMIN.value)
    user.set_password(PASSWORD)
    store.create(user)
    service = AuthService(store, _Cfg())
    events = []
    service.audit = type("A", (), {"event": lambda self, *a, **k:
                                   events.append((a, k))})()
    service.events = events
    return service


def test_defaults_are_30_minutes_and_12_hours():
    from config.development import DevelopmentConfig
    cfg = DevelopmentConfig(_env_file=None)
    assert cfg.jwt_ttl_seconds == 1800
    assert cfg.auth_max_session_hours == 12
    from src.modules.console.settings_catalogue import BY_KEY
    assert BY_KEY["jwt_ttl_seconds"]["label"].startswith("Sign out after")
    assert BY_KEY["auth_max_session_hours"]["group"] == "Console sign-in"


def test_token_carries_the_sign_in_time_through_renewals(auth):
    import jwt
    token, _ = auth.authenticate("alice", PASSWORD)
    first = jwt.decode(token, auth.secret, algorithms=["HS256"])
    time.sleep(1.1)
    renewed, _ = auth.refresh(token)
    second = jwt.decode(renewed, auth.secret, algorithms=["HS256"])
    assert second["auth_time"] == first["auth_time"]
    assert second["iat"] > first["iat"]


def test_no_renewal_past_the_maximum_length(auth):
    import jwt
    token, user = auth.authenticate("alice", PASSWORD)
    # A session that started 59 minutes ago (limit 1 hour): renewed, but
    # its new expiry stops at the limit, not 30 minutes later.
    started = int(time.time()) - 59 * 60
    t2, _ = auth._issue(user, "", method="refresh", auth_time=started)
    exp = jwt.decode(t2, auth.secret, algorithms=["HS256"])["exp"]
    assert exp <= started + 3600
    # One that started an hour ago cannot be renewed or used.
    from src.modules.auth.services import AuthError
    with pytest.raises(AuthError, match="maximum length"):
        auth._issue(user, "", method="refresh",
                    auth_time=int(time.time()) - 3600)


def test_an_old_token_past_the_maximum_length_is_refused(auth):
    """A token whose sign-in is older than the maximum is refused even
    while its own expiry has not come (tokens from before the change)."""
    import jwt
    from src.modules.auth.services import AuthError
    token, _ = auth.authenticate("alice", PASSWORD)
    claims = jwt.decode(token, auth.secret, algorithms=["HS256"])
    claims["auth_time"] = int(time.time()) - 2 * 3600
    forged_old = jwt.encode(claims, auth.secret, algorithm="HS256")
    with pytest.raises(AuthError, match="maximum length"):
        auth.verify(forged_old)


# ── UAT-L15 / UAT-L14: audit events ──

def _actions(auth):
    return [a[1] for a, _ in auth.events]


def test_renewal_writes_no_logout_event(auth):
    token, _ = auth.authenticate("alice", PASSWORD)
    auth.events.clear()
    auth.refresh(token)
    assert "logout" not in _actions(auth)
    assert "session_renewed" in _actions(auth)


def test_account_id_on_failure_lock_change_and_sign_out(auth):
    from src.modules.auth.services import AuthError
    uid = auth.store.get_by_username("alice").user_id
    for _ in range(3):
        with pytest.raises(AuthError):
            auth.authenticate("alice", "wrong-password-1")
    with pytest.raises(AuthError):
        auth.authenticate("alice", PASSWORD)           # locked
    for action in ("login_failed", "login_blocked"):
        detail = [k.get("detail", {}) for a, k in auth.events
                  if a[1] == action]
        assert detail and all(d.get("user_id") == uid for d in detail), action
    user = auth.store.get_by_username("alice")
    user.clear_lock()
    auth.store.update(user)
    token, user = auth.authenticate("alice", PASSWORD)
    auth.logout(token)
    token, user = auth.authenticate("alice", PASSWORD)
    with pytest.raises(AuthError):
        auth.change_password(user, "not-the-current-1", "AnotherHorse99")
    auth.change_password(user, PASSWORD, "AnotherHorse99")
    for action in ("logout", "password_change_failed", "password_changed"):
        detail = [k.get("detail", {}) for a, k in auth.events
                  if a[1] == action]
        assert detail and detail[-1].get("user_id") == uid, action


# ── UAT-L24: one actor format ──

def test_console_user_is_named_with_the_api_key_off(tmp_path, data_dir):
    with _client(tmp_path, auth_enabled=False) as client:
        _bootstrap(client)
        token = client.post("/api/v1/auth/login", json={
            "username": "alice", "password": PASSWORD}).json()["access_token"]
        from src.modules.auth.services import build_auth_dependency
        dep = build_auth_dependency(client.app.state.config,
                                    client.app.state.auth_service)
        import asyncio
        from starlette.requests import Request
        req = Request({"type": "http", "method": "POST", "path": "/",
                       "headers": [(b"authorization",
                                    f"Bearer {token}".encode())]})
        assert asyncio.run(dep(req)) == "user:alice"
        anon = Request({"type": "http", "method": "POST", "path": "/",
                        "headers": []})
        assert asyncio.run(dep(anon)) == "anonymous"


def test_retry_and_cancel_name_the_user_like_submit():
    routes = (Path(__file__).resolve().parents[2] / "src" / "modules" /
              "intake" / "routes.py").read_text(encoding="utf-8")
    assert 'retry(request_id, f"user:{user.username}")' in routes
    assert 'cancel(request_id, f"user:{user.username}")' in routes
    services = (Path(__file__).resolve().parents[2] / "src" / "modules" /
                "auth" / "services.py").read_text(encoding="utf-8")
    assert 'return f"user:{user.username}"' in services


# ── SES-05: "Skip for now" per account ──

def test_skip_for_now_is_remembered_per_account(tmp_path, data_dir):
    with _client(tmp_path) as client:
        _bootstrap(client)
        a = client.post("/api/v1/auth/login", json={
            "username": "alice", "password": PASSWORD}).json()["access_token"]
        h = {"Authorization": f"Bearer {a}"}
        r = client.post("/api/v1/admin/users", headers=h, json={
            "username": "bob", "display_name": "Bob", "role": "admin",
            "password": "ProvisionalPw42"})
        assert r.status_code == 201, r.text
        b = client.post("/api/v1/auth/login", json={
            "username": "bob", "password": "ProvisionalPw42"}).json()["access_token"]
        client.post("/api/v1/auth/password",
                    headers={"Authorization": f"Bearer {b}"},
                    json={"current_password": "ProvisionalPw42",
                          "new_password": "OwnHorseKey42"})
        b = client.post("/api/v1/auth/login", json={
            "username": "bob", "password": "OwnHorseKey42"}).json()["access_token"]
        hb = {"Authorization": f"Bearer {b}"}

        assert client.get("/api/v1/system/setup", headers=h).json()["dismissed"] is False
        r = client.put("/api/v1/system/setup", headers=h,
                       json={"dismissed": True})
        assert r.status_code == 200 and r.json()["dismissed"] is True
        assert r.json()["complete"] is False         # set-up state unchanged
        assert client.get("/api/v1/system/setup", headers=h).json()["dismissed"] is True
        assert client.get("/api/v1/system/setup", headers=hb).json()["dismissed"] is False
        client.put("/api/v1/system/setup", headers=h, json={"dismissed": False})
        assert client.get("/api/v1/system/setup", headers=h).json()["dismissed"] is False


# ── The console page ──

def _function(source, signature):
    body = source[source.index(signature):]
    return body[:body.index("\n}\n") + 2]


def test_page_holds_no_token_and_sends_the_console_header():
    assert not re.search(r"\bTOKEN\b", APP) and "Authorization" not in APP
    assert "'X-FINESIII-Console': '1'" in APP
    fetch = _function(APP, "async function fetchAuthedRaw")
    assert "credentials: 'same-origin'" in fetch
    assert "CONSOLE_HEADER" in fetch


def test_page_resumes_on_load():
    boot = _function(APP, "async function boot()")
    assert boot.index("api('/auth/me')") < boot.index("api('/auth/status')")
    assert "enterConsole(me)" in boot


def test_page_watches_inactivity_and_renews_only_on_activity():
    tick = _function(APP, "async function sessionTick()")
    assert "signOut({ reason: 'idle' })" in tick
    assert "showIdlePrompt(" in tick
    assert "lastActivity() > renewed" in tick
    for ev in ("'pointerdown'", "'keydown'", "'wheel'", "'touchstart'"):
        assert ev in APP, ev
    for element in ("idle-box", "idle-stay", "idle-out", "idle-text"):
        assert INDEX.count(f'id="{element}"') == 1, element
    # The Dashboard refresh is not activity: it never calls markActivity.
    dash = APP[APP.index("LOADERS.dashboard = guard"):]
    dash = dash[:dash.index("\n});\n")]
    assert "markActivity" not in dash


def test_page_keeps_the_address_and_warns_about_unsaved_settings():
    assert "window.addEventListener('popstate'" in APP
    assert "history[replace ? 'replaceState' : 'pushState']" in APP
    assert "window.addEventListener('beforeunload'" in APP
    switch = _function(APP, "function switchView(name, opts = {})")
    assert "settingsUnsaved()" in switch and "confirm(" in switch
    sign_out = _function(APP, "async function signOut(opts = {})")
    assert "settingsUnsaved()" in sign_out
    assert "/auth/me" in sign_out                 # a renewal elsewhere is not a sign-out


def test_page_remembers_skip_per_account():
    close = _function(APP, "function closeWizard()")
    assert "dismissed: true" in close
    assert "!SETUP.dismissed" in APP
    clean = _function(APP, "function clearSensitive()")
    assert "WIZARD_DISMISSED = false" in clean


def test_assets_carry_one_version():
    """F2 changed the page files, so their version changed (2026.10.04d);
    the current one is pinned in test_qa_fixes_console_ui."""
    versions = re.findall(r"\?v=([0-9.a-z]+)", INDEX)
    assert versions and len(set(versions)) == 1
    assert versions[0] >= "2026.10.04d"
