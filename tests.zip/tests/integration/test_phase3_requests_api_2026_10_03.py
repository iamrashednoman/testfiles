"""Phase 3 of the console module review (2026-10-03): Requests, History,
Evidence and exports — the console's own routes, manual submission,
retry safeguards, the history filter, evidence by ticket and exports
that say what they hold."""
import time
from pathlib import Path

import pytest

from tests.conftest import make_config

PASSWORD = "CorrectHorse42"
API_KEY = "connector-key-0123456789abcdef"
VALID = {"operation": "provision", "affiliation_code": "30822",
         "employee_code": "1217036", "password": "FUJI@33F"}
UI = Path(__file__).resolve().parents[2] / "desktop" / "ui"
_real_sleep = time.sleep


@pytest.fixture(autouse=True)
def fast_sleep(monkeypatch):
    monkeypatch.setattr("time.sleep", lambda s: None)


@pytest.fixture
def data_dir(tmp_path, monkeypatch):
    from desktop import vault
    d = tmp_path / "data"
    d.mkdir()
    monkeypatch.setenv("FINESIII_DATA_DIR", str(d))
    previous = vault._vault
    vault.use_vault(vault.MemoryVault())
    for k in vault.SECRET_KEYS:
        monkeypatch.delenv(k, raising=False)
    yield d
    vault.use_vault(previous)


def _client(tmp_path, audit=False, **overrides):
    from fastapi.testclient import TestClient
    from src import create_app
    if audit:
        overrides.update(
            audit_enabled=True, audit_backend="sqlite",
            audit_sqlite_path=str(tmp_path / "audit.db"),
            audit_spool_path=str(tmp_path / "spool.db"),
            audit_flush_interval_seconds=0.05)
    overrides.setdefault("dispatcher_enabled", True)
    # OCR off for the simulated terminal (T-02, 2026-10-04).
    overrides.setdefault("ocr_enabled", False)
    cfg = make_config(tmp_path, terminal_driver="mock",
                      log_dir=str(tmp_path / "logs"), **overrides)
    return TestClient(create_app(cfg))


def _h(t):
    return {"Authorization": f"Bearer {t}"}


def _admin(client):
    client.post("/api/v1/auth/bootstrap",
                json={"username": "alice", "password": PASSWORD})
    return client.post("/api/v1/auth/login", json={
        "username": "alice", "password": PASSWORD}).json()["access_token"]


def _user(client, admin, username, role):
    client.post("/api/v1/admin/users", headers=_h(admin),
                json={"username": username, "password": PASSWORD,
                      "role": role})
    t = client.post("/api/v1/auth/login", json={
        "username": username, "password": PASSWORD}).json()["access_token"]
    client.post("/api/v1/auth/password", headers=_h(t),
                json={"current_password": PASSWORD,
                      "new_password": "TheirOwn7777"})
    return client.post("/api/v1/auth/login", json={
        "username": username,
        "password": "TheirOwn7777"}).json()["access_token"]


def _wait(client, token, rid):
    for _ in range(400):
        row = client.get("/api/v1/console/requests?q=" + rid,
                         headers=_h(token)).json()["requests"]
        if row and row[0]["status"] not in ("queued", "running"):
            return row[0]
        _real_sleep(0.02)
    raise AssertionError("request did not finish")


# ── RQ-01: the console works with the API key on and no grant ──

def test_console_routes_work_without_the_api_grant(tmp_path, data_dir,
                                                   monkeypatch):
    monkeypatch.setenv("FINESIII_API_KEYS", API_KEY)
    with _client(tmp_path, audit=True, auth_enabled=True,
                 dispatcher_enabled=False) as client:
        token = _admin(client)
        # The API routes still want the machine key (contract unchanged).
        assert client.get("/api/v1/requests",
                          headers=_h(token)).status_code == 401
        r = client.post("/api/v1/requests", json=VALID,
                        headers={"X-API-Key": API_KEY})
        assert r.status_code == 202
        rid = r.json()["request_id"]
        for path in ("/api/v1/console/requests",
                     "/api/v1/console/transactions",
                     "/api/v1/console/audit/events"):
            assert client.get(path, headers=_h(token)).status_code == 200, \
                path
        page = client.get("/api/v1/console/requests?limit=10",
                          headers=_h(token)).json()
        assert page["total"] == 1 and page["requests"][0]["request_id"] \
            == rid
        # Cancel through the console route, by permission.
        r = client.delete(f"/api/v1/console/requests/{rid}",
                          headers=_h(token))
        assert r.status_code == 200 and r.json()["status"] == "cancelled"
        # Without a sign-in nothing is answered.
        assert client.get("/api/v1/console/requests").status_code == 401


def test_the_connector_submits_with_its_key_as_before(tmp_path, data_dir,
                                                     monkeypatch):
    """The ServiceNow connector sends its key as X-API-Key and as a
    Bearer header; the submit permission check must let it through, with
    API keys on and off."""
    monkeypatch.setenv("FINESIII_API_KEYS", f"snow:{API_KEY}")
    headers = {"X-API-Key": API_KEY, "Authorization": f"Bearer {API_KEY}"}
    for auth_on in (True, False):
        with _client(tmp_path / str(auth_on), dispatcher_enabled=False,
                     auth_enabled=auth_on) as client:
            _admin(client)
            r = client.post("/api/v1/requests", json=VALID, headers=headers)
            assert r.status_code == 202, (auth_on, r.text)
            rid = r.json()["request_id"]
            r = client.delete(f"/api/v1/requests/{rid}", headers=headers)
            assert r.status_code == 200, (auth_on, r.text)


def test_console_actions_follow_permissions(tmp_path, data_dir):
    with _client(tmp_path, dispatcher_enabled=False) as client:
        admin = _admin(client)
        viewer = _user(client, admin, "vic", "viewer")
        operator = _user(client, admin, "olga", "operator")
        # A console request names its ticket (E2E-L08, 2026-10-05).
        r = client.post("/api/v1/console/requests",
                        json=dict(VALID, ticket_id="T-1"), headers=_h(viewer))
        assert r.status_code == 403
        r = client.post("/api/v1/console/requests",
                        json=dict(VALID, ticket_id="T-1"), headers=_h(operator))
        assert r.status_code == 202, r.text
        rid = r.json()["request_id"]
        assert client.delete(f"/api/v1/console/requests/{rid}",
                             headers=_h(viewer)).status_code == 403
        # RQ-12: a viewer signed into the console cannot submit through
        # the API route either, also with the API key off.
        r = client.post("/api/v1/requests", json=dict(
            VALID, employee_code="1217037"), headers=_h(viewer))
        assert r.status_code == 403
        # The machine (no console sign-in) is unaffected.
        r = client.post("/api/v1/requests", json=dict(
            VALID, employee_code="1217038"))
        assert r.status_code == 202


def test_manual_submission_has_the_usual_checks(tmp_path, data_dir):
    with _client(tmp_path, dispatcher_enabled=False) as client:
        admin = _admin(client)
        bad = client.post("/api/v1/console/requests", headers=_h(admin),
                          json=dict(VALID, affiliation_code="1234a",
                                    ticket_id="T-1"))
        assert bad.status_code in (400, 422)
        ok = client.post("/api/v1/console/requests", headers=_h(admin),
                         json=dict(VALID, password="", source="manual",
                                   ticket_id="T-1"))
        assert ok.status_code == 202
        row = client.app.state.queue_store.get(ok.json()["request_id"])
        assert row.source == "manual" and row.password  # generated
        dup = client.post("/api/v1/console/requests", headers=_h(admin),
                          json=dict(VALID, password="", ticket_id="T-1"))
        assert dup.status_code == 409
        # The same work under another ticket while the first is open
        # (E2E-M01, 2026-10-05).
        dup = client.post("/api/v1/console/requests", headers=_h(admin),
                          json=dict(VALID, password="", ticket_id="T-2"))
        assert dup.status_code == 409


# ── RQ-06 / RQ-07 ──

def test_needs_verification_filter(tmp_path, data_dir):
    from src.modules.intake.models import now_jst
    from src.modules.queue.dispatcher import build_transaction_record
    with _client(tmp_path, dispatcher_enabled=False) as client:
        admin = _admin(client)
        store = client.app.state.transaction_store
        for code, emp in (("UNCONFIRMED", "1000001"), ("O-0000", "1000002")):
            rid = client.post("/api/v1/requests", json=dict(
                VALID, employee_code=emp)).json()["request_id"]
            req = client.app.state.queue_store.get(rid)
            store.record(build_transaction_record(
                req, "done", code, "", "", now_jst()))
        d = client.get("/api/v1/console/transactions?status=done"
                       "&result_code=UNCONFIRMED", headers=_h(admin)).json()
        assert d["total"] == 1
        assert d["transactions"][0]["employee_code"] == "1000001"


def test_yes_no_flags_are_not_masked():
    from src.modules.intake.models import redact_secrets
    out = redact_secrets({"password_generated": True,
                          "password_supplied": False,
                          "password": "Secret1", "password_fp": 12345})
    assert out["password_generated"] is True
    assert out["password_supplied"] is False
    assert out["password"] == "****" and out["password_fp"] == "****"


# ── RQ-09: evidence by ticket number, times, no server folder ──

def test_evidence_by_ticket_number(tmp_path, data_dir):
    with _client(tmp_path) as client:
        admin = _admin(client)
        rid = client.post("/api/v1/requests", json=dict(
            VALID, ticket_id="SCTASK7700001")).json()["request_id"]
        _wait(client, admin, rid)
        d = client.get("/api/v1/console/evidence/SCTASK7700001",
                       headers=_h(admin)).json()
        assert d["request_id"] == rid and d["ticket_id"] == "SCTASK7700001"
        assert "path" not in d and d["count"] > 0
        assert all(c["taken_at"][:4].isdigit() for c in d["captures"])
        # A ticket split into several requests names them.
        for part in ("/1", "/2"):
            client.post("/api/v1/requests", json=dict(
                VALID, ticket_id="SCTASK7700002" + part,
                employee_code="12170" + part[-1] + "9"))
        r = client.get("/api/v1/console/evidence/SCTASK7700002",
                       headers=_h(admin))
        assert r.status_code == 409 and "2 requests" in r.json()["detail"]


# ── X-03 / X-04: exports say what they hold ──

def test_exports_report_total_truncation_and_audit(tmp_path, data_dir,
                                                   monkeypatch):
    from src.modules.console import metrics
    with _client(tmp_path, audit=True, dispatcher_enabled=False) as client:
        admin = _admin(client)
        for emp in ("1000001", "1000002", "1000003"):
            client.post("/api/v1/requests",
                        json=dict(VALID, employee_code=emp))
        r = client.get("/api/v1/console/export/requests", headers=_h(admin))
        assert r.headers["X-Export-Rows"] == "3"
        assert r.headers["X-Export-Total"] == "3"
        assert r.headers["X-Export-Truncated"] == "false"
        assert r.headers["X-Export-Audited"] == "true"
        monkeypatch.setattr(metrics, "EXPORT_MAX_ROWS", 2)
        r = client.get("/api/v1/console/export/requests", headers=_h(admin))
        assert r.headers["X-Export-Rows"] == "2"
        assert r.headers["X-Export-Total"] == "3"
        assert r.headers["X-Export-Truncated"] == "true"
        deadline = time.time() + 5
        events = []
        while time.time() < deadline and len(events) < 2:
            events = [e for e in client.get(
                "/api/v1/console/audit/events?category=console&limit=50",
                headers=_h(admin)).json()["events"]
                if e["action"] == "data_exported"]
            _real_sleep(0.1)
        cut = [e for e in events if e["detail"].get("truncated")]
        assert cut and cut[0]["detail"]["total"] == 3


def test_export_without_audit_says_not_audited(tmp_path, data_dir):
    with _client(tmp_path, dispatcher_enabled=False) as client:
        admin = _admin(client)
        r = client.get("/api/v1/console/export/transactions",
                       headers=_h(admin))
        assert r.headers["X-Export-Audited"] == "false"


def test_legacy_export_is_safe_and_audited(tmp_path, data_dir):
    with _client(tmp_path, audit=True) as client:
        admin = _admin(client)
        rid = client.post("/api/v1/requests", json=dict(
            VALID, ticket_id="=HYPERLINK(\"x\")")).json()["request_id"]
        _wait(client, admin, rid)
        # The history row is written just after the request finishes.
        for _ in range(250):
            if client.get("/api/v1/console/transactions?limit=1",
                          headers=_h(admin)).json()["total"]:
                break
            _real_sleep(0.02)
        r = client.get("/api/v1/transactions/export")
        text = r.content.decode("utf-8")
        assert text.startswith("﻿transaction_id,")
        assert "evidence_path" not in text.splitlines()[0]
        assert "'=HYPERLINK" in text            # formula neutralised
        assert r.headers["X-Export-Total"] == "1"
        deadline = time.time() + 5
        found = []
        while time.time() < deadline and not found:
            found = [e for e in client.get(
                "/api/v1/console/audit/events?category=api&limit=50",
                headers=_h(admin)).json()["events"]
                if e["action"] == "data_exported"]
            _real_sleep(0.1)
        assert found and found[0]["detail"]["route"] == "api"


# ── The console page ──

def _read(name):
    return (UI / name).read_text(encoding="utf-8")


def test_page_uses_console_routes_and_safeguards():
    js, html = _read("app.js"), _read("index.html")
    # RQ-01: no list or action through the API-key routes.
    for old in ("api('/requests'", "api('/transactions'",
                "api('/audit/events'", "act1('/requests/"):
        assert old not in js, old
    assert "'/console/requests'" in js and "'/console/transactions'" in js
    # RQ-08: confirmation, button disabled, server message, fresh list.
    assert "function canRetry(r)" in js and "confirmRetry(r)" in js
    act1 = js.split("async function act1(")[1][:900]
    assert "btn.disabled = true" in act1 and "r.message" in act1
    # RQ-06 / RQ-11 / RQ-12 / DR-09 / X-03.
    assert "'Needs verification (result not confirmed)'" in js
    assert "['sailpoint', 'SailPoint']" in js and "['cli', 'Command line']" in js
    assert 'id="req-refresh"' not in html and "$('req-refresh')" not in js
    assert 'id="req-form"' in html and "'New request'" in js
    assert "Retry the failed requests shown" in js
    assert "Show all on the Audit trail page" in js
    assert "function exportText(info)" in js
