"""ServiceNow ticket selection and reading (6 October 2026).

  F1  Every ticket filter is optional: a filled-in value is applied, an
      empty one adds no condition (group, Bot account, Requested For).
  F2  The Bot account is matched by sys_id; a user name or the name
      shown on a form is looked up first. No OR on a dot-walked field.
  F3  Requested For is checked by the bot on each ticket, in the field
      entered or - empty - in the task's, its request's and its
      requested item's Requested For.
  F4  The instruction text is read from the task's own fields when the
      catalog variable is empty or cannot be read.
  F5  A ticket for another application is skipped without a note.
  F6  Ticket checks "minimal" (testing) and "strict" (default).
  F7  Emptied application-ID / instance checks are saved as "no check".
  F8  Test connection and Preview tickets report the filters and counts.

Against the mock ServiceNow over the real client (wire format included),
with fictional data only."""
import random

import httpx
import pytest

from scripts.run_mock_snow_server import (
    GROUP, SAILPOINT_USER, TicketStore, create_mock_app, user_sys_id,
)
from src.integrations.servicenow.client import ServiceNowClient
from src.integrations.servicenow.config import (
    ServiceNowSettings, load_servicenow_config,
)
from src.integrations.servicenow.connector import (
    ReportMemory, ServiceNowConnector,
)
from src.integrations.servicenow import sailpoint

BOT = "finesiii.bot"
TASK_FIELD = "u_special_instructions"


def _connector(store, **kw):
    from tests.conftest import asgi_transport
    s = load_servicenow_config()
    s.instance_url, s.username, s.password = "http://testserver", BOT, "pw"
    s.auth_method = "basic"
    s.respect_service_health = False
    for k, v in kw.items():
        setattr(s, k, v)
    client = ServiceNowClient(s, transport=asgi_transport(
        create_mock_app(store)), sleep_func=lambda _s: None)
    c = ServiceNowConnector(s, client=client)
    c.reported = ReportMemory()
    logs, audit, submitted = [], [], []
    c.logger = type("L", (), {
        "__getattr__": lambda self, level:
            lambda msg: logs.append((level, msg))})()
    c.audit_hook = lambda e, d: audit.append((e, d))
    c._submit = lambda payload: submitted.append(payload) or "queued"
    return c, logs, audit, submitted


def _unreadable_variables(store, task, text_in_task=True):
    """The catalog variables come back with their labels but without
    values (no read access to the values); the same text sits in a
    field of the task itself."""
    text = next(v["value"] for v in store.variables[task["request_item"]]
                if v["name"] == "description")
    for v in store.variables[task["request_item"]]:
        v["value"] = ""
    if text_in_task:
        task[TASK_FIELD] = text
    return text


# ── F1 / F2: the query ───────────────────────────────────────────────

class TestOptionalFilters:
    def test_nothing_entered_reads_every_open_ticket(self):
        s = ServiceNowSettings(username=BOT, assignment_mode="assignment_group")
        assert s.build_query() == "active=true^ORDERBYsys_created_on"
        assert s.assigns_before_queueing
        assert s.effective_assigned_to == BOT       # who takes the tickets
        assert s.selection_fields() == []

    @pytest.mark.parametrize("mode", ["assigned_to", "assignment_group"])
    def test_each_filter_entered_is_applied(self, mode):
        s = ServiceNowSettings(username="api.user", assignment_mode=mode,
                               assignment_group=GROUP, assigned_to=BOT,
                               bot_sys_id="b" * 32,
                               require_approval=True,
                               approval_filter="request_item.approval=approved")
        q = s.build_query()
        assert q.startswith(f"assignment_group.name={GROUP}^")
        if mode == "assigned_to":
            assert f"^assigned_to={'b' * 32}^" in q
        else:
            assert f"^assigned_toISEMPTY^ORassigned_to={'b' * 32}^" in q
        assert q.endswith("^active=true^request_item.approval=approved"
                          "^ORDERBYsys_created_on")

    def test_no_or_on_a_dot_walked_field(self):
        s = ServiceNowSettings(assignment_mode="assignment_group",
                               assigned_to="Integration Account")
        assert "^ORassigned_to" not in s.build_query()
        assert "assigned_toISEMPTY" in s.build_query()

    def test_bot_account_by_user_name_or_shown_name(self):
        users = {"user_name=svc.bot": [{"sys_id": "1" * 32}],
                 "name=Integration Account": [{"sys_id": "2" * 32}],
                 "name=Twin Name": [{"sys_id": "3" * 32},
                                    {"sys_id": "4" * 32}]}

        def handler(request):
            q = request.url.params["sysparm_query"]
            return httpx.Response(200, json={"result": users.get(q, [])})
        s = ServiceNowSettings(instance_url="https://x.service-now.com",
                               username="u", password="p", max_retries=0)
        client = ServiceNowClient(s, transport=httpx.MockTransport(handler),
                                  sleep_func=lambda _s: None)
        assert client.user_sys_id("svc.bot") == "1" * 32
        assert client.user_sys_id("Integration Account") == "2" * 32
        assert client.user_sys_id("Twin Name") == ""     # not unique
        assert client.user_sys_id("5" * 32) == "5" * 32

    def test_poll_without_any_filter_takes_free_tickets_only(self):
        store = TicketStore(random.Random(21))
        store.bot = ""
        free = store.create_sailpoint("add", assigned_to="")
        taken = store.create_sailpoint(
            "add", assigned_to=user_sys_id("service.desk.agent"))
        c, logs, audit, submitted = _connector(
            store, assignment_mode="assignment_group", assignment_group="",
            assigned_to="", requested_for=[])
        stats = c.poll_once()
        assert stats["fetched"] == 2
        assert [p["ticket_id"] for p in submitted] == [free["number"]]
        # Assigned to the sign-in account before it was queued; the
        # person's ticket is left to them.
        assert free["assigned_to"] == user_sys_id(BOT)
        assert taken["assigned_to"] == user_sys_id("service.desk.agent")


# ── F3: Requested For on the bot's side ──────────────────────────────

class TestRequestedFor:
    def test_matched_in_any_of_the_three_places(self):
        store = TicketStore(random.Random(22))
        store.bot = ""
        ours = store.create_sailpoint("add", assigned_to="")
        other = store.create_sailpoint("add", assigned_to="",
                                       requested_for="")
        c, logs, audit, submitted = _connector(
            store, assignment_mode="assignment_group",
            assignment_group=GROUP, requested_for=[SAILPOINT_USER])
        stats = c.poll_once()
        assert "requested_for" not in c.client.s.build_query()
        assert stats["fetched"] == 2 and stats["out_of_selection"] == 1
        assert [p["ticket_id"] for p in submitted] == [ours["number"]]
        assert other["assigned_to"] == "" and not other["work_notes"]

    def test_by_sys_id_as_well(self):
        store = TicketStore(random.Random(23))
        store.bot = ""
        ours = store.create_sailpoint("add", assigned_to="")
        c, logs, audit, submitted = _connector(
            store, assignment_mode="assignment_group",
            assignment_group=GROUP, requested_for=[store.sailpoint_user])
        c.poll_once()
        assert [p["ticket_id"] for p in submitted] == [ours["number"]]


# ── F4: the instruction text from the task ───────────────────────────

class TestTaskText:
    def test_found_automatically_and_queued(self):
        store = TicketStore(random.Random(31))
        store.bot = ""
        task = store.create_sailpoint("remove", assigned_to="",
                                      affiliation="01634")
        _unreadable_variables(store, task)
        c, logs, audit, submitted = _connector(
            store, assignment_mode="assignment_group",
            assignment_group=GROUP)
        stats = c.poll_once()
        assert stats["submitted"] == 1 and stats["skipped"] == 0
        (p,) = submitted
        assert p["operation"] == "deprovision"
        assert p["affiliation_code"] == "01634"
        # The account from the instruction text ("for account: …").
        assert len(p["employee_code"]) == 7
        assert any(f"task field '{TASK_FIELD}'" in m for _l, m in logs)

    def test_field_entered_is_used(self):
        store = TicketStore(random.Random(32))
        store.bot = ""
        task = store.create_sailpoint("add", assigned_to="")
        _unreadable_variables(store, task)
        c, logs, audit, submitted = _connector(
            store, assignment_mode="assignment_group",
            assignment_group=GROUP, task_text_fields=[TASK_FIELD])
        assert c.poll_once()["submitted"] == 1
        c, logs, audit, submitted = _connector(
            store, assignment_mode="assignment_group",
            assignment_group=GROUP, task_text_fields=["u_other_field"])
        stats = c.poll_once()
        assert stats["submitted"] == 0 and stats["skipped"] == 1

    def test_no_text_anywhere_is_refused_with_the_reason(self):
        store = TicketStore(random.Random(33))
        store.bot = ""
        task = store.create_sailpoint("add", assigned_to="")
        _unreadable_variables(store, task, text_in_task=False)
        c, logs, audit, submitted = _connector(
            store, assignment_mode="assignment_group",
            assignment_group=GROUP)
        stats = c.poll_once()
        assert stats["skipped"] == 1 and submitted == []
        assert "instruction text" in task["work_notes"]
        assert any("no instruction text in the variables" in m
                   for _l, m in logs)

    def test_readable_variable_wins(self):
        rec = {"description": "AttributeName=x; Value=1; Operation=Add",
               "work_notes": "for account: AAAAAAA"}
        assert sailpoint.task_text(rec) == ("description", rec["description"])
        assert sailpoint.task_text({"work_notes": "for account: X"}) == \
            ("", "")
        assert sailpoint.task_text({"a": "plain", "b": {
            "display_value": "Please provision for account: ABC1234"}}) == \
            ("b", "Please provision for account: ABC1234")


# ── F5: another application ──────────────────────────────────────────

def test_other_application_is_skipped_without_a_note():
    store = TicketStore(random.Random(41))
    store.bot = ""
    task = store.create_sailpoint("add", assigned_to="",
                                  application="Another System [9999]")
    task["description"] = "Another System [9999]"
    c, logs, audit, submitted = _connector(
        store, assignment_mode="assignment_group", assignment_group=GROUP)
    for _ in range(2):
        stats = c.poll_once()
        assert stats["out_of_selection"] == 1 and stats["skipped"] == 0
    assert submitted == [] and not task["work_notes"]
    assert task["assigned_to"] == ""
    assert len([e for e, _d in audit
                if e == "servicenow_ticket_out_of_selection"]) == 1


# ── F6: ticket checks ────────────────────────────────────────────────

class TestChecks:
    def _ticket(self, **kw):
        store = TicketStore(random.Random(51))
        store.bot = ""
        task = store.create_sailpoint("add", assigned_to="", **kw)
        return store, task

    def test_minimal_skips_instance_and_request_type(self):
        store, task = self._ticket(instance="Dev", request_type="Remove")
        c, *_rest, submitted = _connector(
            store, assignment_mode="assignment_group",
            assignment_group=GROUP)
        assert c.poll_once()["skipped"] == 1          # strict: refused
        store, task = self._ticket(instance="Dev", request_type="Remove")
        c, *_rest, submitted = _connector(
            store, assignment_mode="assignment_group",
            assignment_group=GROUP, sp_checks="minimal")
        assert c.poll_once()["submitted"] == 1

    def test_minimal_keeps_what_a_run_needs(self):
        s = load_servicenow_config()
        s.sp_checks = "minimal"
        text = ("Please provision/deprovision the below attributes for "
                "account: ABC1234\nAttributeName=Role; Value=01634; "
                "Operation=Add")
        variables = [{"name": "description", "label": "Description / Work "
                      "notes", "value": text}]
        ticket = {"number": "T1", "description": "Sample [2565]"}
        payloads, reason = sailpoint.parse_ticket(ticket, variables, s)
        assert payloads is None and "attribute 'Role'" in reason
        bad = text.replace("Role", "所属コード").replace("01634", "1X")
        variables[0]["value"] = bad
        assert "5-digit" in sailpoint.parse_ticket(ticket, variables, s)[1]

    def test_unknown_value_is_refused(self):
        s = ServiceNowSettings(username="u", sp_checks="loose")
        with pytest.raises(ValueError, match="ticket checks"):
            s.validate()


# ── F7 / F8: the console ─────────────────────────────────────────────

PASSWORD = "CorrectHorse42"


@pytest.fixture
def data_dir(tmp_path, monkeypatch):
    from desktop import vault
    d = tmp_path / "data"
    d.mkdir()
    monkeypatch.setenv("FINESIII_DATA_DIR", str(d))
    previous = vault._vault
    vault.use_vault(vault.MemoryVault())
    for k in vault.SECRET_KEYS:
        monkeypatch.delenv(k, raising=False)
    yield d
    vault.use_vault(previous)


def _client(tmp_path):
    from fastapi.testclient import TestClient
    from desktop.server import mount_console_ui
    from src import create_app
    from tests.conftest import make_config
    app = create_app(make_config(tmp_path, terminal_driver="mock",
                                 dispatcher_enabled=False,
                                 log_dir=str(tmp_path / "logs")))
    mount_console_ui(app, mode="agent")
    return TestClient(app)


def _h(client):
    client.post("/api/v1/auth/bootstrap",
                json={"username": "alice", "password": PASSWORD})
    t = client.post("/api/v1/auth/login", json={
        "username": "alice", "password": PASSWORD}).json()["access_token"]
    return {"Authorization": f"Bearer {t}"}


def test_settings_new_keys_and_emptied_checks(tmp_path, data_dir,
                                              monkeypatch):
    for k in ("SNOW_APPLICATION_IDS", "SNOW_ACCEPTED_INSTANCES",
              "SNOW_TASK_TEXT_FIELDS", "SNOW_SAILPOINT_CHECKS"):
        monkeypatch.delenv(k, raising=False)
    with _client(tmp_path) as client:
        h = _h(client)
        items = {s["key"]: s for s in client.get(
            "/api/v1/console/settings", headers=h).json()["settings"]}
        # Shown with the values in force.
        assert items["SNOW_SAILPOINT_CHECKS"]["value"] == "strict"
        assert items["SNOW_APPLICATION_IDS"]["value"] == "2565"
        r = client.put("/api/v1/console/settings", headers=h, json={
            "SNOW_APPLICATION_IDS": "", "SNOW_ACCEPTED_INSTANCES": "",
            "SNOW_TASK_TEXT_FIELDS": TASK_FIELD,
            "SNOW_SAILPOINT_CHECKS": "minimal"})
        assert r.status_code == 200, r.text
        s = load_servicenow_config()
        assert s.sp_application_ids == [] and s.sp_accepted_instances == []
        assert s.task_text_fields == [TASK_FIELD]
        assert s.sp_checks == "minimal"
        assert client.put("/api/v1/console/settings", headers=h, json={
            "SNOW_TASK_TEXT_FIELDS": "a^ORb"}).status_code == 400
        assert client.put("/api/v1/console/settings", headers=h, json={
            "SNOW_SAILPOINT_CHECKS": "none"}).status_code == 400


def test_page_renders_the_reports():
    from pathlib import Path
    app = (Path(__file__).resolve().parents[2] / "desktop" / "ui" /
           "app.js").read_text(encoding="utf-8")
    for text in ("function snowTestReport(r)", "'Ticket filters'",
                 "'Open tickets after each filter'", "'Summary'",
                 "No (skipped)", "The next poll would read"):
        assert text in app, text
    # Text only: the report never builds HTML from ServiceNow values.
    report = app[app.index("function snowTestReport(r)"):
                 app.index("/* Preview tickets")]
    assert "innerHTML" not in report


def test_filter_summary_in_plain_words():
    s = ServiceNowSettings(assignment_mode="assignment_group",
                           assignment_group=GROUP, assigned_to=BOT,
                           requested_for=[SAILPOINT_USER])
    names = {f["name"]: f["value"] for f in s.filter_summary()}
    assert names["Assignment group"] == GROUP
    assert names["Bot account"] == \
        f"{BOT} (tickets unassigned or assigned to it)"
    assert names["Requested For"].startswith(SAILPOINT_USER + " (read from")
    assert names["Open states"] == ""


def test_ticket_update_checks_the_bot_owns_the_ticket():
    """Without any filter the ticket must still be assigned to the bot
    account before the bot writes to it (it takes every ticket before
    queueing)."""
    from src.integrations.servicenow.writeback import TicketCloseout
    from tests.unit.test_servicenow_module import (
        _Audit, _Log, _Req, _Txn, _WBClient,
    )
    s = ServiceNowSettings(instance_url="https://x", username="bot",
                           password="p", table="sc_task",
                           assignment_mode="assignment_group")
    client = _WBClient(owned=True)
    client.user_sys_id = lambda name: "9" * 32
    co = TicketCloseout(logger=_Log(), audit=_Audit(),
                        settings_loader=lambda: s,
                        client_factory=lambda st: client,
                        async_send=False, sleep_func=lambda d: None)
    co.handle_completion(_Txn("done"), _Req(), {})
    assert client.lookups[0][1] == (f"sys_id=abc123^number=SCTASK0007"
                                    f"^assigned_to={'9' * 32}^active=true")
    assert client.calls and client.calls[0][0] == "state"
