"""F6 of the fix plan (2026-10-04): operations and the terminal.

OPS-01  A pause set on the System page outlives a restart; who paused it
        and since when is shown.
OPS-03  Two badges: the service's environment and the mainframe's.
OPS-04  A different port than the configured one is shown; an option
        refuses to start on another port (off by default).
CFG-04  "Start the terminal as administrator" on Settings > FINESIII
        terminal; a read-only terminal summary.
OPS-09  The service reports a recovery after an unexpected stop.
UAT-L20 The wait after a failed sign-in check survives a restart.
UAT-L21 agent.log is size-checked while the agent runs; the level
        filter keeps continuation lines.
UAT-L23 The Dashboard and the System page say the same about
        processing; CyberArk's old error clears; repeated "Refresh
        CyberArk now" clicks make one fetch."""
import json
import os
import socket
import time
from pathlib import Path
from types import SimpleNamespace

import pytest

from tests.conftest import make_config

PASSWORD = "CorrectHorse42"
ROOT = Path(__file__).resolve().parents[2]
APP = (ROOT / "desktop" / "ui" / "app.js").read_text(encoding="utf-8")
INDEX = (ROOT / "desktop" / "ui" / "index.html").read_text(encoding="utf-8")


@pytest.fixture
def data_dir(tmp_path, monkeypatch):
    from desktop import vault
    d = tmp_path / "data"
    d.mkdir()
    monkeypatch.setenv("FINESIII_DATA_DIR", str(d))
    previous = vault._vault
    vault.use_vault(vault.MemoryVault())
    monkeypatch.delenv("FINESIII_APP_RUN_AS_ADMIN", raising=False)
    yield d
    vault.use_vault(previous)


def _app(tmp_path, **overrides):
    from desktop.server import mount_console_ui
    from src import create_app
    opts = dict(dispatcher_enabled=True, terminal_driver="mock",
                ocr_enabled=False, log_dir=str(tmp_path / "logs"),
                sqlite_path=str(tmp_path / "shared.db"))
    opts.update(overrides)
    app = create_app(make_config(tmp_path, **opts))
    mount_console_ui(app, mode="agent", stop_hook=lambda: None)
    return app


def _client(app):
    from fastapi.testclient import TestClient
    return TestClient(app)


def _h(client, first=True):
    if first:
        client.post("/api/v1/auth/bootstrap",
                    json={"username": "alice", "password": PASSWORD})
    t = client.post("/api/v1/auth/login", json={
        "username": "alice", "password": PASSWORD}).json()["access_token"]
    return {"Authorization": f"Bearer {t}"}


# ── OPS-01: pause outlives a restart ──

def test_pause_is_kept_across_a_rebuild(tmp_path, data_dir):
    with _client(_app(tmp_path)) as client:
        h = _h(client)
        r = client.post("/api/v1/system/dispatcher/pause", headers=h)
        assert r.status_code == 200
        disp = r.json()["dispatcher"]
        assert disp["paused"] and disp["paused_by"] == "alice"
        assert disp["paused_at"]
    # The service is built again on the same database (a restart).
    with _client(_app(tmp_path)) as client:
        h = _h(client, first=False)
        disp = client.get("/api/v1/system/status", headers=h).json()["dispatcher"]
        assert disp["paused"] is True and disp["paused_by"] == "alice"
        summary = client.get("/api/v1/console/summary", headers=h).json()
        assert summary["dispatcher"]["paused_by"] == "alice"
        assert client.post("/api/v1/system/dispatcher/resume",
                           headers=h).status_code == 200
    with _client(_app(tmp_path)) as client:
        h = _h(client, first=False)
        disp = client.get("/api/v1/system/status", headers=h).json()["dispatcher"]
        assert disp["paused"] is False and disp["paused_by"] == ""


def test_stopped_processing_names_the_reason(tmp_path, data_dir):
    with _client(_app(tmp_path, dispatcher_enabled=False)) as client:
        h = _h(client)
        disp = client.get("/api/v1/system/status", headers=h).json()["dispatcher"]
        assert disp["running"] is False
        assert "Process queued work is Off" in disp["reason"]
        summary = client.get("/api/v1/console/summary", headers=h).json()
        assert "Process queued work is Off" in summary["dispatcher"]["reason"]


# ── OPS-03 / OPS-04: environments and port ──

def test_both_environments_and_the_ports_are_reported(tmp_path, data_dir):
    with _client(_app(tmp_path, mainframe_environment="production")) as client:
        h = _h(client)
        st = client.get("/api/v1/system/status", headers=h).json()
        assert st["mainframe_environment"] == "production"
        assert st["environment"] in ("development", "production")
        assert st["configured_port"] == client.app.state.config.api_port
        summary = client.get("/api/v1/console/summary", headers=h).json()
        assert summary["environment"] == "production"
        assert summary["service_environment"] in ("development", "production")


def test_strict_port_refuses_to_start_on_another_port(tmp_path, data_dir):
    from desktop.server import EmbeddedService
    with socket.socket() as busy:
        busy.bind(("127.0.0.1", 0))
        busy.listen(1)
        taken = busy.getsockname()[1]
        cfg = make_config(tmp_path, api_port=taken, api_port_strict=True,
                          terminal_driver="mock", dispatcher_enabled=False)
        service = EmbeddedService(cfg)
        with pytest.raises(RuntimeError, match="Refuse another port"):
            service.start()
        # Off (the default): it starts on another free port as before.
        assert EmbeddedService.pick_port(taken) != taken


def test_strict_port_is_a_machine_setting_off_by_default():
    from config.development import DevelopmentConfig
    from desktop import deployment
    assert deployment.BY_KEY["API_PORT_STRICT"]["kind"] == "bool"
    assert DevelopmentConfig(_env_file=None).api_port_strict is False
    assert deployment.BY_KEY["APP_ENV"]["label"] == "Service environment"


# ── CFG-04: run as administrator ──

def test_run_as_admin_setting_reaches_the_driver(monkeypatch):
    from src.rpa.config import build_rpa_config
    from src.modules.console.settings_catalogue import BY_KEY, defaults_in_force
    spec = BY_KEY["FINESIII_APP_RUN_AS_ADMIN"]
    assert spec["group"] == "FINESIII terminal" and spec["kind"] == "bool"
    assert spec["apply"] == "restart"
    assert defaults_in_force(["FINESIII_APP_RUN_AS_ADMIN"]) == {
        "FINESIII_APP_RUN_AS_ADMIN": "true"}
    monkeypatch.delenv("FINESIII_APP_RUN_AS_ADMIN", raising=False)
    kw = dict(driver="pywinauto", environment="development",
              evidence_dir="/tmp")
    assert build_rpa_config(**kw)["application"].get("run_as_admin",
                                                     True) is True
    monkeypatch.setenv("FINESIII_APP_RUN_AS_ADMIN", "false")
    assert build_rpa_config(**kw)["application"]["run_as_admin"] is False
    monkeypatch.setenv("FINESIII_APP_RUN_AS_ADMIN", "true")
    assert build_rpa_config(**kw)["application"]["run_as_admin"] is True


def test_terminal_summary_data(tmp_path, data_dir, monkeypatch):
    monkeypatch.setenv("FINESIII_APP_RUN_AS_ADMIN", "false")
    with _client(_app(tmp_path)) as client:
        m = client.get("/api/v1/system/setup",
                       headers=_h(client)).json()["modules"]["finesiii"]
        assert m["run_as_admin"] is False
        assert m["service_elevated"] in (True, False, None)
        assert m["driver"] == "mock"


# ── OPS-09: recovery after an unexpected stop ──

def test_previous_run_without_stop_is_recognised(tmp_path, data_dir):
    from desktop import runtime
    assert runtime.previous_run_ended_unexpectedly() is None
    runtime.write_runtime(8000, pid=999999)          # a process long gone
    info = runtime.previous_run_ended_unexpectedly()
    assert info and info["pid"] == 999999
    runtime.write_runtime(8000, pid=os.getpid())     # alive: not judged
    assert runtime.previous_run_ended_unexpectedly() is None
    runtime.remove_runtime()                          # a clean stop
    assert runtime.previous_run_ended_unexpectedly() is None


def test_recovery_is_audited_and_logged_as_an_error():
    from desktop.agent import AgentRunner
    events, logged = [], []
    runner = AgentRunner.__new__(AgentRunner)
    runner.service = SimpleNamespace(app=SimpleNamespace(state=SimpleNamespace(
        audit=SimpleNamespace(event=lambda *a, **k: events.append((a, k))))))
    runner.logger = SimpleNamespace(error=lambda text: logged.append(text))
    runner._report_recovery({"pid": 4242, "started_at": "2026-10-04T09:00:00"})
    (args, kwargs), = events
    assert args[:2] == ("system", "service_recovered_after_unexpected_stop")
    assert kwargs["severity"] == "ERROR"
    assert logged and logged[0].startswith(
        "Service recovered after an unexpected stop")


# ── UAT-L20: the wait after a failed sign-in check ──

def test_sign_in_wait_survives_a_restart(tmp_path):
    from src.core.db import Database
    from src.modules.console.settings_store import SettingsStore
    from src.rpa.terminal_check import TerminalCheck
    store = SettingsStore(Database("sqlite",
                                   sqlite_path=str(tmp_path / "s.db")))
    check = TerminalCheck(executor=None, store=store)
    check._remember_sign_in_failure(time.time())
    assert check.sign_in_wait_seconds() > 590
    again = TerminalCheck(executor=None, store=store)       # after a restart
    assert again.sign_in_wait_seconds() > 590
    again._remember_sign_in_failure(0.0)                     # a good check
    assert TerminalCheck(executor=None,
                         store=store).sign_in_wait_seconds() == 0


# ── UAT-L21: agent.log and the log filter ──

def test_agent_log_is_emptied_in_place_while_written(tmp_path):
    from desktop import runtime
    log = tmp_path / "agent.log"
    with open(log, "ab") as writer:                    # as the agent holds it
        writer.write(b"x" * 300)
        writer.flush()
        assert runtime.truncate_agent_log(log, max_bytes=100) is True
        writer.write(b"after\n")
        writer.flush()
    assert (tmp_path / "agent.log.1").read_bytes() == b"x" * 300
    assert log.read_bytes() == b"after\n"             # appended at the start
    assert runtime.truncate_agent_log(log, max_bytes=100) is False


def test_agent_checks_its_log_while_running():
    source = (ROOT / "desktop" / "agent.py").read_text(encoding="utf-8")
    loop = source[source.index("while not self._should_stop():"):]
    loop = loop[:loop.index("self._stop.wait(self.poll_seconds)")]
    assert "runtime.truncate_agent_log(runtime.agent_log_path())" in loop


def test_level_filter_keeps_continuation_lines():
    from desktop.system_api import _filter_log
    text = "\n".join([
        "2026-10-04 10:00:00 | INFO | started",
        "2026-10-04 10:00:01 | ERROR | ServiceNow poll failed",
        "Traceback (most recent call last):",
        "  File \"x.py\", line 1",
        "2026-10-04 10:00:02 | INFO | fine",
        "  continuation of the info line",
    ])
    rows = _filter_log(text, "ERROR", None, 100)
    assert rows == ["2026-10-04 10:00:01 | ERROR | ServiceNow poll failed",
                    "Traceback (most recent call last):",
                    "  File \"x.py\", line 1"]


# ── UAT-L23: CyberArk ──

def test_cyberark_success_clears_the_old_error_and_clicks_make_one_fetch():
    from src.integrations.cyberark.provider import CyberArkPasswordProvider
    provider = CyberArkPasswordProvider.__new__(CyberArkPasswordProvider)
    import threading
    provider._lock = threading.Lock()
    provider._wake = threading.Event()
    provider._refreshing = False
    assert provider.request_refresh() is True
    assert provider.request_refresh() is False         # already asked for
    provider._wake.clear()
    provider._refreshing = True                        # a fetch is running
    assert provider.request_refresh() is False
    source = (ROOT / "src" / "integrations" / "cyberark" /
              "provider.py").read_text(encoding="utf-8")
    success = source[source.index("self._password = password"):]
    success = success[:success.index("credentials = self._credentials")]
    assert 'self._last_error = ""' in success


# ── the console page ──

def test_page_badges_card_and_summary():
    assert "function setEnvironment(service, mainframe)" in APP
    assert INDEX.count('id="mf-chip"') == 1
    assert "processingCard(d.dispatcher)," in APP
    assert "Paused by ${disp.paused_by}" in APP
    assert "Running on port ${d.port} instead of the configured" in APP
    assert "async function terminalSummary(host)" in APP
    assert "The password is already being fetched" in APP
