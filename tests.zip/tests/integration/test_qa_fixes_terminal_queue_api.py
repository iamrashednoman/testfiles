"""QA fixes wired through the application (BUG-020, BUG-077)."""
from __future__ import annotations

import pytest

from tests.conftest import make_config

VALID = {"operation": "provision", "affiliation_code": "30822",
         "employee_code": "1217036", "password": "FUJI@33F"}


@pytest.fixture
def data_dir(tmp_path, monkeypatch):
    d = tmp_path / "data"
    d.mkdir()
    monkeypatch.setenv("FINESIII_DATA_DIR", str(d))
    return d


# ── BUG-077: the submit message names the real reason ─────────────


class TestSubmitMessage:
    def _app(self, tmp_path):
        from src import create_app
        return create_app(make_config(tmp_path))

    def test_health_failure_inside_window(self, tmp_path, data_dir):
        from fastapi.testclient import TestClient
        app = self._app(tmp_path)
        av = app.state.availability
        av.is_within_time_window = lambda check_buffer=False: True
        av.is_health_ok = lambda: False
        with TestClient(app) as client:
            body = client.post("/api/v1/requests", json=VALID).json()
        assert body["message"] == ("Request queued. Mainframe not reachable "
                                   "at the moment. Will process when "
                                   "available.")

    def test_outside_window_unchanged(self, tmp_path, data_dir):
        from fastapi.testclient import TestClient
        app = self._app(tmp_path)
        av = app.state.availability
        av.is_within_time_window = lambda check_buffer=False: False
        with TestClient(app) as client:
            body = client.post("/api/v1/requests", json=VALID).json()
        assert body["message"].startswith(
            "Request queued. Mainframe offline (outside ")


# ── BUG-020: CyberArk required, fallback password → processing paused ─


class _FakeProvider:
    def __init__(self):
        self.fallback = True

    def status(self):
        return {"enabled": True, "available": False,
                "using_fallback": self.fallback}

    def attach_credentials(self, credentials):
        pass

    def request_refresh(self):
        pass

    def stop(self):
        pass


class TestCyberArkGate:
    def test_gate_closed_until_vault_delivers(self, tmp_path, data_dir,
                                              monkeypatch):
        import src as app_module
        from src.modules.queue.dispatcher import MockExecutor
        provider = _FakeProvider()
        monkeypatch.setattr(app_module, "maybe_start_cyberark",
                            lambda **kw: provider)
        monkeypatch.setattr(app_module, "build_executor",
                            lambda cfg: MockExecutor(delay_seconds=0))
        cfg = make_config(tmp_path, dispatcher_enabled=True,
                          terminal_driver="pywinauto", require_cyberark=True,
                          log_dir=str(tmp_path / "logs"))
        app = app_module.create_app(cfg)
        dispatcher = app.state.dispatcher
        assert dispatcher is not None
        assert dispatcher.can_process() is False
        problems = [c() for c in app.state.live_problems]
        assert any("CyberArk" in p for p in problems)
        assert app.state.startup_problems == []

        provider.fallback = False          # first successful refresh
        assert dispatcher.can_process() is True
        assert [c() for c in app.state.live_problems] == [""]

    def test_no_gate_when_cyberark_not_required(self, tmp_path, data_dir,
                                                monkeypatch):
        import src as app_module
        monkeypatch.setattr(app_module, "maybe_start_cyberark",
                            lambda **kw: _FakeProvider())
        cfg = make_config(tmp_path, dispatcher_enabled=True,
                          terminal_driver="mock", require_cyberark=False,
                          log_dir=str(tmp_path / "logs"))
        app = app_module.create_app(cfg)
        assert app.state.dispatcher.can_process is None
        assert app.state.live_problems == []

    def test_system_status_shows_live_problem(self, tmp_path, data_dir,
                                              monkeypatch):
        import src as app_module
        from fastapi.testclient import TestClient
        from desktop import vault
        from desktop.server import mount_console_ui
        from src.modules.queue.dispatcher import MockExecutor
        previous = vault._vault
        vault.use_vault(vault.MemoryVault())
        try:
            provider = _FakeProvider()
            monkeypatch.setattr(app_module, "maybe_start_cyberark",
                                lambda **kw: provider)
            monkeypatch.setattr(app_module, "build_executor",
                                lambda cfg: MockExecutor(delay_seconds=0))
            cfg = make_config(tmp_path, dispatcher_enabled=True,
                              terminal_driver="pywinauto",
                              require_cyberark=True,
                              log_dir=str(tmp_path / "logs"))
            app = app_module.create_app(cfg)
            mount_console_ui(app, mode="agent")
            with TestClient(app) as client:
                client.post("/api/v1/auth/bootstrap", json={
                    "username": "alice", "password": "CorrectHorse42"})
                token = client.post("/api/v1/auth/login", json={
                    "username": "alice", "password": "CorrectHorse42"}
                ).json()["access_token"]
                h = {"Authorization": f"Bearer {token}"}
                s = client.get("/api/v1/system/status", headers=h).json()
                assert any("CyberArk" in p for p in s["startup_problems"])
                provider.fallback = False
                s = client.get("/api/v1/system/status", headers=h).json()
                assert s["startup_problems"] == []
        finally:
            vault.use_vault(previous)
