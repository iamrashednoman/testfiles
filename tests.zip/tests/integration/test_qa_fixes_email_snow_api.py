"""QA fixes 2026-09-28 — e-mail and ServiceNow, through the console API.

  BUG-028  STARTTLS and implicit SSL cannot both be saved; the test
           e-mail names that case instead of a TLS mismatch.
  BUG-042  an address setting that is not an e-mail address is refused.
  BUG-063  '*' alone switches the application / instance check off.
  BUG-064  a ServiceNow credential applies without a restart.
  BUG-074  400 "Invalid table" is explained as a missing table.
  BUG-075  discover tells an empty variable from a missing one.
"""
import pytest

from tests.conftest import make_config

PASSWORD = "CorrectHorse42"
TLS_KEYS = ("SMTP_USE_STARTTLS", "SMTP_USE_SSL")


@pytest.fixture(autouse=True)
def fast_sleep(monkeypatch):
    monkeypatch.setattr("time.sleep", lambda s: None)


@pytest.fixture
def data_dir(tmp_path, monkeypatch):
    d = tmp_path / "data"
    d.mkdir()
    monkeypatch.setenv("FINESIII_DATA_DIR", str(d))
    return d


@pytest.fixture
def memory_vault(monkeypatch):
    from desktop import vault
    from src.modules.console.settings_store import _restore_env_overrides
    previous = vault._vault
    store = vault.MemoryVault()
    vault.use_vault(store)
    for k in list(vault.SECRET_KEYS) + [
            "SNOW_INSTANCE_URL", "SNOW_USERNAME", "SNOW_AUTH_METHOD",
            "SNOW_TABLE", "SNOW_TICKET_FORMAT", "SMTP_HOST", "SMTP_PORT",
            "SMTP_USE_STARTTLS", "SMTP_USE_SSL", "ALERT_FROM", "ALERT_TO",
            "SNOW_APPLICATION_IDS", "SNOW_ACCEPTED_INSTANCES"]:
        monkeypatch.delenv(k, raising=False)
    yield store
    vault.use_vault(previous)
    _restore_env_overrides()


def _client(tmp_path):
    from fastapi.testclient import TestClient
    from desktop.server import mount_console_ui
    from src import create_app
    cfg = make_config(tmp_path, terminal_driver="mock", dispatcher_enabled=False,
                      log_dir=str(tmp_path / "logs"))
    app = create_app(cfg)
    mount_console_ui(app, mode="agent")
    return TestClient(app)


def _auth(t):
    return {"Authorization": f"Bearer {t}"}


def _admin(client):
    client.post("/api/v1/auth/bootstrap",
                json={"username": "alice", "password": PASSWORD})
    return client.post("/api/v1/auth/login", json={
        "username": "alice", "password": PASSWORD}).json()["access_token"]


# ── BUG-028 ──────────────────────────────────────────────────────

class TestStartTlsOrSsl:
    def test_both_on_refused_and_nothing_stored(self, tmp_path, data_dir,
                                                memory_vault):
        with _client(tmp_path) as client:
            token = _admin(client)
            r = client.put("/api/v1/console/settings", headers=_auth(token),
                           json={"SMTP_USE_STARTTLS": True,
                                 "SMTP_USE_SSL": True, "SMTP_PORT": 465})
            assert r.status_code == 400
            assert "not both" in r.json()["detail"]
            stored = client.app.state.settings_store.all()
            assert not {"SMTP_USE_STARTTLS", "SMTP_USE_SSL",
                        "SMTP_PORT"} & set(stored)

    def test_resulting_pair_is_checked(self, tmp_path, data_dir, memory_vault):
        with _client(tmp_path) as client:
            token = _admin(client)
            put = lambda body: client.put(  # noqa: E731
                "/api/v1/console/settings", headers=_auth(token), json=body)
            # SSL alone while STARTTLS is on by default: both would be on.
            assert put({"SMTP_USE_SSL": True}).status_code == 400
            assert put({"SMTP_USE_SSL": True,
                        "SMTP_USE_STARTTLS": False}).status_code == 200
            # Turning STARTTLS back on while SSL is stored: refused.
            assert put({"SMTP_USE_STARTTLS": True}).status_code == 400
            # Clearing STARTTLS brings its default (on) back: refused too.
            assert put({"SMTP_USE_STARTTLS": ""}).status_code == 400
            # Switching over in one request is fine.
            assert put({"SMTP_USE_SSL": False,
                        "SMTP_USE_STARTTLS": True}).status_code == 200

    def test_test_email_hint(self, tmp_path, data_dir, memory_vault):
        with _client(tmp_path) as client:
            token = _admin(client)
            r = client.post("/api/v1/system/test-email", headers=_auth(token),
                            json={"to": "ops@example.com",
                                  "host": "smtp.example.com",
                                  "from": "bot@example.com", "port": 465,
                                  "use_ssl": True, "use_starttls": True}
                            ).json()
            assert r["ok"] is False
            assert r["hint"] == ("Choose STARTTLS (port 587) or implicit SSL "
                                 "(port 465), not both.")
            assert "TLS mismatch" not in r["hint"]


# ── BUG-042 ──────────────────────────────────────────────────────

class TestAddressSettings:
    def test_bad_address_refused_good_ones_kept(self, tmp_path, data_dir,
                                                memory_vault):
        with _client(tmp_path) as client:
            token = _admin(client)
            put = lambda body: client.put(  # noqa: E731
                "/api/v1/console/settings", headers=_auth(token), json=body)
            r = put({"ALERT_TO": "a@x.exampleBcc: other@x.example"})
            assert r.status_code == 400
            assert "is not an e-mail address" in r.json()["detail"]
            assert put({"ALERT_TO": "a@x.example, b@x.example"}
                       ).status_code == 200
            assert put({"ALERT_FROM": "FINESIII Bot <bot@x.example>"}
                       ).status_code == 200
            assert put({"EMAIL_CONTACT_ADDRESS": "not-an-email"}
                       ).status_code == 400


# ── BUG-064 ──────────────────────────────────────────────────────

class TestHotSecrets:
    def test_servicenow_credentials_need_no_restart(self, tmp_path, data_dir,
                                                    memory_vault):
        with _client(tmp_path) as client:
            token = _admin(client)
            for name, hot in (("SNOW_PASSWORD", True),
                              ("SNOW_CLIENT_SECRET", True),
                              ("SMTP_PASSWORD", False)):
                r = client.put(f"/api/v1/system/secrets/{name}",
                               headers=_auth(token), json={"value": "x1"})
                assert r.status_code == 200
                assert r.json()["restart_required"] is (not hot), name
                r = client.delete(f"/api/v1/system/secrets/{name}",
                                  headers=_auth(token))
                assert r.json()["restart_required"] is (not hot), name


# ── BUG-074 / BUG-075 ────────────────────────────────────────────

class TestServiceNowChecks:
    BODY = {"instance_url": "https://x.service-now.com", "username": "u",
            "password": "p", "auth_method": "basic", "table": "sc_tsk"}

    def test_invalid_table_hint(self, tmp_path, data_dir, memory_vault,
                                monkeypatch):
        from src.integrations.servicenow import client as mod

        def fail(self, table, query="", fields=None, limit=10):
            raise mod.ServiceNowError(
                f"GET https://x.service-now.com/api/now/table/{table} failed: "
                f'400 {{"error":{{"message":"Invalid table {table}"}}}}')
        monkeypatch.setattr(mod.ServiceNowClient, "get_records", fail)
        with _client(tmp_path) as client:
            token = _admin(client)
            r = client.post("/api/v1/system/test-servicenow",
                            headers=_auth(token), json=self.BODY).json()
            assert r["ok"] is False
            assert r["hint"] == "Table 'sc_tsk' does not exist."

    def test_discover_reports_empty_variable(self, tmp_path, data_dir,
                                             memory_vault, monkeypatch):
        from src.integrations.servicenow import client as mod
        monkeypatch.setenv("SNOW_TICKET_FORMAT", "sailpoint")
        monkeypatch.setattr(mod.ServiceNowClient, "fetch_raw_sample",
                            lambda self, limit=2: [{"sys_id": "a" * 32,
                                                    "number": "SCTASK1"}])
        rows = [{"label": "Account Name", "name": "account_name",
                 "value": "4821KQT"},
                {"label": "Instance", "name": "instance", "value": ""}]
        monkeypatch.setattr(mod.ServiceNowClient, "fetch_variables",
                            lambda self, t: rows)
        with _client(tmp_path) as client:
            token = _admin(client)
            r = client.post("/api/v1/system/discover-servicenow",
                            headers=_auth(token), json=self.BODY).json()
            assert r["ok"] is True
            assert r["variables_found"]["instance"] is True
            assert r["variables_found"]["account"] is True
            assert "instance" in r["variables_empty"]
            assert "account" not in r["variables_empty"]
            assert r["variables_found"]["text"] is False
            assert "text" not in r["variables_empty"]
