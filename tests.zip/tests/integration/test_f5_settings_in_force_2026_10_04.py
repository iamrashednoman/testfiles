"""F5 of the fix plan (2026-10-04): settings that actually take effect.

CFG-01  A start-up setting held in the application folder's .env is
        changed THERE (it wins over finesiii.env); with .env read-only it
        is locked with where to change it. Each value names its source.
CFG-02  APP_ENV follows the same order as every other setting (.env
        before finesiii.env); a disagreement is reported at start.
CFG-05  The wording about the order is corrected.
CFG-09  Saved settings waiting for a restart are counted.
CFG-10  The service listens on this machine only; API_HOST is gone from
        the starter file.
OPS-02  A restart waits for the service and carries on on the same page.
OPS-05  The "Machine settings" card counts every source.
UAT-07  Values stored before the cross-setting rules are re-checked at
        start.
UAT-L06 A corrected invalid value is shown as corrected before the
        restart."""
import os
from pathlib import Path

import pytest

from tests.conftest import make_config

PASSWORD = "CorrectHorse42"
ROOT = Path(__file__).resolve().parents[2]
APP = (ROOT / "desktop" / "ui" / "app.js").read_text(encoding="utf-8")
INDEX = (ROOT / "desktop" / "ui" / "index.html").read_text(encoding="utf-8")


@pytest.fixture
def folders(tmp_path, monkeypatch):
    """An application folder (the working folder, holding .env) and a
    data folder (holding finesiii.env), with none of the start-up keys
    in the environment."""
    from desktop import deployment, vault
    app_dir = tmp_path / "app"
    data = tmp_path / "data"
    app_dir.mkdir()
    data.mkdir()
    monkeypatch.chdir(app_dir)
    monkeypatch.setenv("FINESIII_DATA_DIR", str(data))
    for spec in deployment.DEPLOYMENT_KEYS:
        monkeypatch.delenv(spec["key"], raising=False)
    previous = vault._vault
    vault.use_vault(vault.MemoryVault())
    yield app_dir, data
    vault.use_vault(previous)


ENV_TEXT = ("# FINESIII RPA - application settings\r\n"
            "APP_ENV=development   # the posture\r\n"
            "TERMINAL_DRIVER=simulator\r\n"
            "DATABASE_ENGINE=sqlite\r\n"
            "SIM_SCENARIO=success\r\n")


# ── CFG-01: the application settings file ──

def test_dotenv_line_is_changed_in_place(folders):
    from desktop import deployment
    app_dir, _ = folders
    env = app_dir / ".env"
    env.write_bytes(ENV_TEXT.encode())
    deployment.update_app_env({"TERMINAL_DRIVER": "mock",
                               "APP_ENV": "production"})
    text = env.read_bytes().decode()
    assert "TERMINAL_DRIVER=mock\r\n" in text
    assert "APP_ENV=production   # the posture\r\n" in text     # comment kept
    assert text.startswith("# FINESIII RPA - application settings\r\n")
    assert "SIM_SCENARIO=success\r\n" in text                  # untouched
    backups = list(app_dir.glob(".env.bak-*"))
    assert len(backups) == 1 and backups[0].read_bytes() == ENV_TEXT.encode()


def test_clearing_a_dotenv_key_comments_it_out(folders):
    from desktop import deployment
    app_dir, _ = folders
    (app_dir / ".env").write_text(ENV_TEXT, encoding="utf-8")
    deployment.update_app_env({"DATABASE_ENGINE": None})
    assert "DATABASE_ENGINE" not in deployment.read_app_env()
    assert "# DATABASE_ENGINE=sqlite" in (app_dir / ".env").read_text()


def test_unknown_key_changes_nothing(folders):
    from desktop import deployment
    app_dir, _ = folders
    (app_dir / ".env").write_bytes(ENV_TEXT.encode())
    with pytest.raises(KeyError):
        deployment.update_app_env({"TERMINAL_DRIVER": "mock",
                                   "API_PORT": "9000"})
    assert (app_dir / ".env").read_bytes() == ENV_TEXT.encode()
    assert not list(app_dir.glob(".env.bak-*"))


def test_backups_are_limited(folders, monkeypatch):
    import time
    from desktop import deployment
    app_dir, _ = folders
    (app_dir / ".env").write_text(ENV_TEXT, encoding="utf-8")
    stamps = iter(f"20261004-1200{i:02d}" for i in range(20))
    real = time.strftime
    monkeypatch.setattr(time, "strftime", lambda fmt, *a: next(stamps)
                        if fmt == "%Y%m%d-%H%M%S" else real(fmt, *a))
    for driver in ("mock", "simulator") * 4:
        deployment.update_app_env({"TERMINAL_DRIVER": driver})
    assert len(list(app_dir.glob(".env.bak-*"))) == deployment.APP_ENV_BACKUPS


def test_order_is_environment_dotenv_machine_file_default(folders,
                                                         monkeypatch):
    from desktop import deployment
    app_dir, data = folders
    (data / "finesiii.env").write_text("TERMINAL_DRIVER=pyautogui\n"
                                       "LOG_LEVEL=WARNING\n")
    (app_dir / ".env").write_text("TERMINAL_DRIVER=simulator\n")
    assert deployment.effective_value("TERMINAL_DRIVER") == "simulator"
    assert deployment.source_of("TERMINAL_DRIVER") == "app_file"
    assert deployment.effective_value("LOG_LEVEL") == "WARNING"
    assert deployment.source_of("LOG_LEVEL") == "machine_file"
    assert deployment.source_of("API_PORT") == "default"
    monkeypatch.setenv("TERMINAL_DRIVER", "mock")
    assert deployment.effective_value("TERMINAL_DRIVER") == "mock"
    assert deployment.source_of("TERMINAL_DRIVER") == "environment"


# ── CFG-02: APP_ENV ──

def test_app_env_follows_the_same_order(folders):
    from config import _app_env, app_env_conflict
    app_dir, data = folders
    (data / "finesiii.env").write_text("APP_ENV=production\n")
    assert _app_env() == "production"            # only the machine file
    assert app_env_conflict() == ""
    (app_dir / ".env").write_text("APP_ENV=development\n")
    assert _app_env() == "development"           # .env wins, as for the rest
    warning = app_env_conflict()
    assert "'development' in the application settings file" in warning
    assert "'production' in the machine settings file" in warning


# ── API: GET and PUT /system/deployment ──

def _client(tmp_path, **overrides):
    from fastapi.testclient import TestClient
    from desktop.server import mount_console_ui
    from src import create_app
    opts = dict(dispatcher_enabled=False, terminal_driver="mock",
                log_dir=str(tmp_path / "logs"))
    opts.update(overrides)
    app = create_app(make_config(tmp_path, **opts))
    mount_console_ui(app, mode="agent", stop_hook=lambda: None)
    return TestClient(app)


def _h(client):
    client.post("/api/v1/auth/bootstrap",
                json={"username": "alice", "password": PASSWORD})
    t = client.post("/api/v1/auth/login", json={
        "username": "alice", "password": PASSWORD}).json()["access_token"]
    return {"Authorization": f"Bearer {t}"}


def _item(client, h, key):
    d = client.get("/api/v1/system/deployment", headers=h).json()
    return next(s for s in d["settings"] if s["key"] == key), d


def test_page_shows_the_dotenv_value_and_saves_it_there(tmp_path, folders):
    app_dir, data = folders
    (app_dir / ".env").write_text(ENV_TEXT, encoding="utf-8")
    (data / "finesiii.env").write_text("TERMINAL_DRIVER=pyautogui\n")
    with _client(tmp_path) as client:
        h = _h(client)
        item, d = _item(client, h, "TERMINAL_DRIVER")
        assert item["value"] == "simulator"           # what is in force
        assert item["source"] == "app_file" and item["locked"] is False
        assert item["pending_restart"] is False
        assert d["app_file"]["writable"] is True
        r = client.put("/api/v1/system/deployment", headers=h,
                       json={"TERMINAL_DRIVER": "mock",
                             "LOG_LEVEL": "WARNING"})
        assert r.status_code == 200, r.text
        assert r.json()["application_file"] == ["TERMINAL_DRIVER"]
        assert r.json()["machine_file"] == ["LOG_LEVEL"]
        assert "TERMINAL_DRIVER=mock" in (app_dir / ".env").read_text()
        machine = (data / "finesiii.env").read_text()
        assert "TERMINAL_DRIVER=pyautogui" in machine   # left as it was
        assert "LOG_LEVEL=WARNING" in machine
        item, _ = _item(client, h, "TERMINAL_DRIVER")
        assert item["value"] == "mock" and item["pending_restart"] is True
        st = client.get("/api/v1/system/status", headers=h).json()
        assert st["machine_settings_pending"] == 2
        files = st["settings_files"]
        assert files["app_file_keys"] == 3 and files["machine_file_keys"] == 2
        assert st["listens_on"].startswith("127.0.0.1")


def test_read_only_dotenv_is_locked(tmp_path, folders):
    app_dir, _ = folders
    env = app_dir / ".env"
    env.write_bytes(ENV_TEXT.encode())
    env.chmod(0o444)
    try:
        if os.access(env, os.W_OK):
            pytest.skip("this account can write read-only files")
        with _client(tmp_path) as client:
            h = _h(client)
            item, d = _item(client, h, "TERMINAL_DRIVER")
            assert item["locked"] is True and d["app_file"]["writable"] is False
            assert "application settings file" in item["locked_reason"]
            r = client.put("/api/v1/system/deployment", headers=h,
                           json={"TERMINAL_DRIVER": "mock"})
            assert r.status_code == 409
            assert "change it there" in r.json()["detail"]
            assert env.read_bytes() == ENV_TEXT.encode()
            # A key .env does not hold still goes to finesiii.env.
            r = client.put("/api/v1/system/deployment", headers=h,
                           json={"LOG_LEVEL": "WARNING"})
            assert r.status_code == 200
    finally:
        env.chmod(0o644)


def test_environment_variable_is_refused(tmp_path, folders, monkeypatch):
    monkeypatch.setenv("LOG_LEVEL", "INFO")
    with _client(tmp_path) as client:
        h = _h(client)
        item, _ = _item(client, h, "LOG_LEVEL")
        assert item["source"] == "environment" and item["locked"] is True
        r = client.put("/api/v1/system/deployment", headers=h,
                       json={"LOG_LEVEL": "WARNING"})
        assert r.status_code == 409


# ── UAT-07: re-checked at start ──

def test_buffer_as_long_as_the_window_is_ignored_at_start(tmp_path):
    from types import SimpleNamespace
    from config.development import DevelopmentConfig
    from src.modules.console.settings_store import startup_cross_checks
    cfg = DevelopmentConfig(_env_file=None,
                            availability_window_start="09:00",
                            availability_window_end="10:00")
    object.__setattr__(cfg, "shutdown_buffer_minutes", 240)
    warnings = startup_cross_checks(cfg)
    assert any("(240 min) is not shorter than the operating window "
               "(09:00 to 10:00, 60 min) and is ignored" in w
               for w in warnings), warnings
    assert cfg.shutdown_buffer_minutes < 60


def test_missing_certificate_file_is_reported_at_start(tmp_path, monkeypatch):
    from config.development import DevelopmentConfig
    from src.modules.console.settings_store import startup_cross_checks
    monkeypatch.setenv("CYBERARK_CERT_PATH", str(tmp_path / "gone.pem"))
    warnings = startup_cross_checks(DevelopmentConfig(_env_file=None))
    assert any("gone.pem" in w and "does not exist" in w for w in warnings)
    assert not any(str(tmp_path) in w for w in warnings)   # name only


def test_start_warnings_include_the_cross_checks(tmp_path, folders,
                                                  monkeypatch):
    monkeypatch.setenv("CYBERARK_CERT_PATH", str(tmp_path / "gone.pem"))
    with _client(tmp_path) as client:
        st = client.get("/api/v1/system/status", headers=_h(client)).json()
        assert any("gone.pem" in w for w in st["startup_warnings"])


# ── UAT-L06: corrected before the restart ──

def test_corrected_invalid_value_is_shown_as_corrected(tmp_path, folders):
    with _client(tmp_path) as client:
        h = _h(client)
        client.app.state.startup_warnings.append(
            "Stored setting 'Retry attempts' (max_attempts) is not valid "
            "and is ignored; enter it again under Settings.")
        client.app.state.settings_store.set("max_attempts", "abc")
        st = client.get("/api/v1/system/status", headers=h).json()
        assert any("is not valid and is ignored" in w
                   for w in st["startup_warnings"])
        client.app.state.settings_store.set("max_attempts", "3")
        st = client.get("/api/v1/system/status", headers=h).json()
        assert any("(max_attempts) was corrected; restart" in w
                   for w in st["startup_warnings"])


# ── CFG-05 / CFG-10: starter file wording ──

def test_starter_file_wording():
    script = (ROOT / "Setup_Prerequisites.ps1").read_text(encoding="utf-8")
    assert "'API_HOST=127.0.0.1'," not in script
    assert "then stored credentials" not in script
    assert "# Order: Windows environment variables, then this file" in script


# ── the console page ──

def test_page_names_sources_and_locks():
    assert "app_file: ['over', 'Application settings file']" in APP
    assert "machine_file: ['over', 'Machine settings file']" in APP
    assert "if (s.locked || s.from_environment || !may('system.manage')) field.disabled = true;" in APP
    assert "'Saved — applies after restart'" in APP
    assert "the application settings file (.env in" in APP


def test_page_counts_waiting_settings_and_saves_and_restarts():
    assert "async function refreshPendingRestart(force)" in APP
    assert INDEX.count('id="dash-restart"') == 1
    assert INDEX.count('id="sys-restart"') == 1
    assert INDEX.count('id="set-save-restart"') == 1
    assert "$('set-save-restart').onclick" in APP


def test_restart_waits_and_reloads_the_data_not_the_page():
    start = APP.index("async function restartService(opts = {})")
    body = APP[start:APP.index("\n}\n", start)]
    assert "waitForRestart(before)" in body
    assert "LOADERS[CURRENT_VIEW]()" in body
    assert "Restarted — the saved settings are now in force." in body
    assert "location.reload" not in body
    assert "reloads shortly" not in APP


def test_machine_settings_card_counts_every_source():
    assert "function machineSettingsCard(d)" in APP
    assert "from the application settings file" in APP
