"""Console fixes from the 28 September retest through the real
application: NB-016 (Reports while the audit database is out of reach),
NB-023 (a cleared restart setting shows its real default), NB-029 (ICO
browser icon), NB-030 (password change after the session ended) and
NB-031 (operators and the Users page)."""
import base64
import os

import pytest

from tests.conftest import make_config

PASSWORD = "CorrectHorse42"
ICO = b"\x00\x00\x01\x00\x01\x00" + b"\x10\x10\x00\x00" + b"\x00" * 40


@pytest.fixture(autouse=True)
def fast_sleep(monkeypatch):
    monkeypatch.setattr("time.sleep", lambda s: None)


def _client(tmp_path, audit=False, **overrides):
    from fastapi.testclient import TestClient
    from src import create_app
    if audit:
        overrides.update(
            audit_enabled=True, audit_backend="sqlite",
            audit_sqlite_path=str(tmp_path / "audit.db"),
            audit_spool_path=str(tmp_path / "spool.db"),
            audit_flush_interval_seconds=0.05)
    cfg = make_config(tmp_path, dispatcher_enabled=False,
                      terminal_driver="mock",
                      log_dir=str(tmp_path / "logs"), **overrides)
    return TestClient(create_app(cfg))


def _auth(t):
    return {"Authorization": f"Bearer {t}"}


def _admin(client):
    client.post("/api/v1/auth/bootstrap",
                json={"username": "alice", "password": PASSWORD})
    return client.post("/api/v1/auth/login", json={
        "username": "alice", "password": PASSWORD}).json()["access_token"]


def _login(client, username, password=PASSWORD):
    r = client.post("/api/v1/auth/login",
                    json={"username": username, "password": password})
    assert r.status_code == 200, r.text
    return r.json()["access_token"]


def _setting(client, token, key):
    items = client.get("/api/v1/console/settings",
                       headers=_auth(token)).json()["settings"]
    return next(s for s in items if s["key"] == key)


# ── NB-016 ───────────────────────────────────────────────────────────

class TestReportsWhileAuditUnreachable:
    def test_standard_unavailable_detail(self, tmp_path, monkeypatch):
        with _client(tmp_path, audit=True) as client:
            token = _admin(client)
            audit = client.app.state.audit

            def unreachable(**kw):
                raise ConnectionError("audit database down")

            monkeypatch.setattr(audit, "aggregate", unreachable)
            r = client.get("/api/v1/console/reports?period=today",
                           headers=_auth(token))
            assert r.status_code == 503
            detail = r.json()["detail"]
            assert detail["status"] == "audit_unavailable"
            assert isinstance(detail["pending_delivery"], int)
            assert "waiting to be written" in detail["message"]

    def test_turned_off_is_still_a_plain_message(self, tmp_path):
        with _client(tmp_path) as client:
            token = _admin(client)
            r = client.get("/api/v1/console/reports",
                           headers=_auth(token))
            assert r.status_code == 503
            assert isinstance(r.json()["detail"], str)


# ── NB-023 ───────────────────────────────────────────────────────────

class TestClearedRestartSettingShowsTheDefault:
    @pytest.mark.parametrize("key,stored,default", [
        ("SMTP_PORT", 2525, "587"),
        ("CYBERARK_API_STYLE", "pvwa", "ccp"),
        ("SMTP_ALERTS_ENABLED", "true", "false"),
    ])
    def test_default_not_the_old_override(self, tmp_path, monkeypatch,
                                          key, stored, default):
        monkeypatch.delenv(key, raising=False)
        db = str(tmp_path / "shared.db")
        with _client(tmp_path, sqlite_path=db) as client:
            r = client.put("/api/v1/console/settings",
                           headers=_auth(_admin(client)),
                           json={key: stored})
            assert r.status_code == 200, r.text
        try:
            # Built with the override in force (what a restart does).
            with _client(tmp_path, sqlite_path=db) as client:
                token = _admin(client)
                assert os.environ[key].lower() == str(stored).lower()
                r = client.put("/api/v1/console/settings",
                               headers=_auth(token), json={key: ""})
                assert r.json()["cleared"] == [key]
                s = _setting(client, token, key)
                assert str(s["value"]) == default
                assert s["is_default"] is True
                assert s["overridden"] is False
                assert s["pending_restart"] is True
        finally:
            from src.modules.console.settings_store import (
                _restore_env_overrides,
            )
            _restore_env_overrides()


# ── NB-029 ───────────────────────────────────────────────────────────

class TestIcoBrowserIcon:
    def test_ico_accepted_for_the_icon_only(self, tmp_path):
        url = "data:image/x-icon;base64," + base64.b64encode(ICO).decode()
        with _client(tmp_path) as client:
            token = _admin(client)
            r = client.put("/api/v1/console/branding", headers=_auth(token),
                           json={"favicon": url})
            assert r.status_code == 200, r.text
            b = client.get("/api/v1/console/branding").json()["branding"]
            assert b["favicon"].startswith("data:image/x-icon;base64,")
            for key in ("logo", "email_logo"):
                r = client.put("/api/v1/console/branding",
                               headers=_auth(token), json={key: url})
                assert r.status_code == 400, key
                assert "data URL" not in r.json()["detail"]
            cur = ("data:image/x-icon;base64," + base64.b64encode(
                b"\x00\x00\x02\x00" + ICO[4:]).decode())
            r = client.put("/api/v1/console/branding", headers=_auth(token),
                           json={"favicon": cur})
            assert r.status_code == 400
            assert r.json()["detail"].startswith("Browser icon ")


# ── NB-030 ───────────────────────────────────────────────────────────

def test_second_window_password_change_is_refused_with_401(tmp_path):
    with _client(tmp_path) as client:
        admin = _admin(client)
        r = client.post("/api/v1/admin/users", headers=_auth(admin),
                        json={"username": "bob", "password": PASSWORD,
                              "role": "viewer"})
        assert r.status_code == 201, r.text
        first, second = _login(client, "bob"), _login(client, "bob")
        r = client.post("/api/v1/auth/password", headers=_auth(first),
                        json={"current_password": PASSWORD,
                              "new_password": "TheirOwn7777"})
        assert r.status_code == 200, r.text
        # Changing the password ended every session, the second window's
        # too: the console takes that answer back to the sign-in screen.
        r = client.post("/api/v1/auth/password", headers=_auth(second),
                        json={"current_password": PASSWORD,
                              "new_password": "Another8888x"})
        assert r.status_code == 401
        assert _login(client, "bob", "TheirOwn7777")


# ── NB-031 ───────────────────────────────────────────────────────────

def test_operator_has_no_users_page(tmp_path):
    with _client(tmp_path) as client:
        admin = _admin(client)
        client.post("/api/v1/admin/users", headers=_auth(admin),
                    json={"username": "olga", "password": PASSWORD,
                          "role": "operator"})
        t = _login(client, "olga")
        client.post("/api/v1/auth/password", headers=_auth(t),
                    json={"current_password": PASSWORD,
                          "new_password": "TheirOwn7777"})
        t = _login(client, "olga", "TheirOwn7777")
        perms = client.get("/api/v1/auth/me",
                           headers=_auth(t)).json()["permissions"]
        assert "users.view" not in perms and "users.manage" not in perms
        assert "requests.retry" in perms
        assert client.get("/api/v1/admin/users",
                          headers=_auth(t)).status_code == 403
