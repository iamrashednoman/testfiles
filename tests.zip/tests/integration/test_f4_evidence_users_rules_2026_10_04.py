"""F4 of the fix plan (2026-10-04): evidence, users, error rules and the
clean-up.

UAT-11  A crafted evidence address ("..") lists nothing outside the
        evidence folder.
UAT-L08 The evidence of a split ticket ("SCTASK…/1") opens by its
        number, given as a query value.
UAT-05  The service requires a reason to turn an error rule off.
UAT-12  The catalogue version stays the same when a rule is switched off
        and on again; each attempt records its recognised error; the
        "before" state is read under the file lock.
UAT-06  "Keep the password of a failed request" = 0 erases the passwords
        already kept, with an audit event.
UAT-L13 A user administrator is offered only the accounts they may
        change.
UAT-L16 Display names are trimmed; a Windows account is DOMAIN\\user."""
import shutil
from pathlib import Path
from types import SimpleNamespace

import pytest

from tests.conftest import make_config

PASSWORD = "CorrectHorse42"
ROOT = Path(__file__).resolve().parents[2]
APP = (ROOT / "desktop" / "ui" / "app.js").read_text(encoding="utf-8")


def _client(tmp_path, **overrides):
    from fastapi.testclient import TestClient
    from src import create_app
    catalogue = tmp_path / "errors.yaml"
    shutil.copy(ROOT / "config" / "errors.yaml", catalogue)
    opts = dict(dispatcher_enabled=False, terminal_driver="mock",
                ocr_enabled=False, log_dir=str(tmp_path / "logs"),
                evidence_dir=str(tmp_path / "data" / "evidence"),
                error_catalog_path=str(catalogue),
                audit_enabled=True, audit_backend="sqlite",
                audit_sqlite_path=str(tmp_path / "audit.db"),
                audit_spool_path=str(tmp_path / "spool.db"),
                audit_flush_interval_seconds=0.05)
    opts.update(overrides)
    return TestClient(create_app(make_config(tmp_path, **opts)))


def _token(client, username="alice"):
    client.post("/api/v1/auth/bootstrap",
                json={"username": username, "password": PASSWORD})
    return client.post("/api/v1/auth/login", json={
        "username": username, "password": PASSWORD}).json()["access_token"]


def _h(t):
    return {"Authorization": f"Bearer {t}"}


# ── UAT-11 / UAT-L08: evidence ──

def test_dot_dot_lists_nothing_outside_the_evidence_folder(tmp_path):
    with _client(tmp_path) as client:
        h = _h(_token(client))
        root = Path(client.app.state.config.evidence_dir)
        root.mkdir(parents=True, exist_ok=True)
        (root.parent / "outside.png").write_bytes(b"\x89PNG" + b"0" * 200)
        for address in ("/api/v1/console/evidence/%2E%2E",
                        "/api/v1/console/evidence/..",
                        "/api/v1/console/evidence?ref=..",
                        "/api/v1/console/evidence?ref=.",
                        "/api/v1/console/evidence?ref=../data"):
            r = client.get(address, headers=h)
            assert r.status_code in (403, 404), (address, r.status_code)
            assert "outside.png" not in r.text, address


def _queued(client, ticket):
    from src.modules.intake.models import ProcessingRequest
    req = ProcessingRequest(operation="deprovision", affiliation_code="31234",
                            employee_code="77UAT40", source="servicenow",
                            ticket_id=ticket)
    client.app.state.queue_store.enqueue(req)
    return req.request_id


def test_split_ticket_evidence_opens_by_its_number(tmp_path):
    with _client(tmp_path) as client:
        h = _h(_token(client))
        rid = _queued(client, "SCTASK0040001/1")
        folder = Path(client.app.state.config.evidence_dir) / rid
        folder.mkdir(parents=True)
        (folder / "001_application_launched_120000.png").write_bytes(
            b"\x89PNG" + b"0" * 2000)
        r = client.get("/api/v1/console/evidence",
                       params={"ref": "SCTASK0040001/1"}, headers=h)
        assert r.status_code == 200, r.text
        body = r.json()
        assert body["request_id"] == rid and body["count"] == 1
        # The request ID in the path keeps working as before.
        assert client.get(f"/api/v1/console/evidence/{rid}",
                          headers=h).status_code == 200


# ── UAT-05 / UAT-12: error rules ──

def test_turning_a_rule_off_needs_a_reason(tmp_path):
    with _client(tmp_path) as client:
        h = _h(_token(client))
        url = "/api/v1/console/error-rules/CENTER_NOT_READY"
        for body in ({"enabled": False}, {"enabled": False, "reason": "   "}):
            r = client.patch(url, headers=h, json=body)
            assert r.status_code == 400, body
            assert "reason is required" in r.json()["detail"]
        r = client.patch(url, headers=h,
                         json={"enabled": False, "reason": "UAT check"})
        assert r.status_code == 200
        # Turning it back on needs none.
        assert client.patch(url, headers=h,
                            json={"enabled": True}).status_code == 200


def test_version_is_the_same_after_off_and_on(tmp_path):
    with _client(tmp_path) as client:
        h = _h(_token(client))
        first = client.get("/api/v1/console/error-rules",
                           headers=h).json()["digest"]
        url = "/api/v1/console/error-rules/CENTER_NOT_READY"
        off = client.patch(url, headers=h, json={
            "enabled": False, "reason": "UAT"}).json()["digest"]
        on = client.patch(url, headers=h, json={"enabled": True}).json()["digest"]
        assert off != first and on == first


def test_version_follows_the_rules_not_the_bytes(tmp_path):
    import yaml
    from src.rpa.vision.error_catalog import ErrorCatalog
    text = (ROOT / "config" / "errors.yaml").read_text(encoding="utf-8")
    base = ErrorCatalog.version_of(yaml.safe_load(text))
    commented = "# a comment added by hand\n" + text + "\n\n"
    assert ErrorCatalog.version_of(yaml.safe_load(commented)) == base
    changed = text.replace("CENTER_NOT_READY", "CENTER_NOT_READY_X", 1)
    assert ErrorCatalog.version_of(yaml.safe_load(changed)) != base
    p = tmp_path / "errors.yaml"
    p.write_text(commented, encoding="utf-8")
    assert ErrorCatalog.load(str(p)).digest == base


def test_before_state_is_read_under_the_lock(tmp_path):
    from src.modules.console.yaml_edit import toggle_rule_file
    from src.rpa.vision.error_catalog import ErrorCatalog
    p = tmp_path / "errors.yaml"
    shutil.copy(ROOT / "config" / "errors.yaml", p)
    seen = []
    toggle_rule_file(p, "CENTER_NOT_READY", False,
                     on_original=lambda t: seen.append(
                         ErrorCatalog.rule_enabled_in(t, "CENTER_NOT_READY")))
    toggle_rule_file(p, "CENTER_NOT_READY", True,
                     on_original=lambda t: seen.append(
                         ErrorCatalog.rule_enabled_in(t, "CENTER_NOT_READY")))
    assert seen == [True, False]
    assert ErrorCatalog.rule_enabled_in(p.read_text(), "NOPE") is None


def test_every_attempt_records_its_recognised_error():
    from src.modules.queue.dispatcher import Dispatcher
    events = []
    fake = SimpleNamespace(audit=SimpleNamespace(
        event=lambda *a, **k: events.append((a, k))))
    req = SimpleNamespace(request_id="req_1", ticket_id="T1",
                          operation="provision", employee_code="E000001",
                          attempt_count=2)
    Dispatcher._audit_error_trace(
        fake, req, {"error_trace": [{"rule": "CENTER_NOT_READY",
                                     "catalog_digest": "abc123def456",
                                     "acted": True, "message": "busy"}]})
    (args, kwargs), = events
    assert args[:2] == ("rpa_error", "rpa_error_detected")
    assert kwargs["detail"]["attempt"] == 2
    assert kwargs["detail"]["catalog_digest"] == "abc123def456"
    source = (ROOT / "src" / "modules" / "queue" /
              "dispatcher.py").read_text(encoding="utf-8")
    retry_branch = source[source.index("if decision.should_retry:"):
                          source.index("self._complete(request, result, "
                                       "exception, decision.reason)")]
    assert "self._audit_error_trace(request, result)" in retry_branch


# ── UAT-06: kept passwords at 0 days ──

def _failed_with_password(store, employee):
    from src.modules.intake.models import ProcessingRequest
    req = ProcessingRequest(operation="provision", affiliation_code="31234",
                            employee_code=employee, password="Fuji@33F",
                            source="servicenow", ticket_id="T-" + employee)
    store.enqueue(req)
    store.db.execute(
        "UPDATE request_queue SET status = 'failed', "
        "completed_at = '2026-10-04T09:00:00+09:00' WHERE request_id = ?",
        (req.request_id,))
    return req.request_id


@pytest.mark.parametrize("days, erased", [(7, False), (0, True)])
def test_zero_days_erases_the_passwords_already_kept(tmp_path, days, erased):
    from src.core.db import Database
    from src.modules.queue.housekeeping import Housekeeper
    from src.modules.queue.services import QueueStore
    store = QueueStore(Database("sqlite", sqlite_path=str(tmp_path / "q.db")))
    store.keep_failed_password = True
    rid = _failed_with_password(store, "77UAT41")
    assert store.get(rid).password
    events = []
    keeper = Housekeeper(
        store, SimpleNamespace(failed_password_retention_days=days),
        audit=SimpleNamespace(event=lambda *a, **k: events.append((a, k))))
    keeper._maybe_purge_failed_passwords()
    assert (store.get(rid).password == "") is erased
    names = [a[1] for a, _ in events]
    assert ("failed_passwords_erased" in names) is erased
    if erased:
        detail = [k["detail"] for a, k in events
                  if a[1] == "failed_passwords_erased"][0]
        assert detail == {"requests": 1, "retention_days": 0}


# ── UAT-L16: names and Windows accounts ──

def test_display_name_is_trimmed_and_windows_account_checked(tmp_path):
    with _client(tmp_path) as client:
        h = _h(_token(client))
        r = client.post("/api/v1/admin/users", headers=h, json={
            "username": "uatuser41", "display_name": "  UAT User  ",
            "role": "viewer", "password": "Uat41User#2026x"})
        assert r.status_code == 201, r.text
        uid = r.json()["user"]["user_id"]
        assert r.json()["user"]["display_name"] == "UAT User"
        r = client.patch(f"/api/v1/admin/users/{uid}", headers=h,
                         json={"display_name": "    "})
        assert r.status_code == 200
        assert r.json()["user"]["display_name"] == ""
        for bad in ("jdoe", "CORP\\j doe", "CORP\\a\\b"):
            r = client.patch(f"/api/v1/admin/users/{uid}", headers=h,
                             json={"windows_account": bad})
            assert r.status_code == 422, bad
            assert "DOMAIN" in r.text
        r = client.post("/api/v1/admin/users", headers=h, json={
            "username": "uatuser42", "role": "viewer",
            "windows_account": "jdoe"})
        assert r.status_code == 422
        r = client.patch(f"/api/v1/admin/users/{uid}", headers=h,
                         json={"windows_account": " CORP\\uatuser41 "})
        assert r.status_code == 200
        assert r.json()["user"]["windows_account"] == "CORP\\uatuser41"


# ── UAT-L13: the Users page ──

def test_users_page_offers_only_accounts_this_user_may_change():
    assert "function mayChange(u)" in APP
    assert "!may('users.manage') || !mayChange(u)) return act;" in APP
    assert "|| !ROLE_NAMES.includes(u.role) || !mayChange(u)) return humanize(u.role);" in APP


def test_evidence_page_sends_the_reference_as_a_query():
    assert "api('/console/evidence' + qs({ ref: id }))" in APP
