"""Phase 5 of the console module review (2026-10-04): ServiceNow polling
recovers quickly and reports the right cause, ticket updates that are not
written are visible, the setup assistant says what is really set up, the
e-mail outbox can be managed, and the terminal check keeps to one
session per service account."""
import time
from pathlib import Path
from types import SimpleNamespace

import pytest

from tests.conftest import make_config

PASSWORD = "CorrectHorse42"
UI = Path(__file__).resolve().parents[2] / "desktop" / "ui"


@pytest.fixture
def data_dir(tmp_path, monkeypatch):
    from desktop import vault
    d = tmp_path / "data"
    d.mkdir()
    monkeypatch.setenv("FINESIII_DATA_DIR", str(d))
    previous = vault._vault
    vault.use_vault(vault.MemoryVault())
    for k in vault.SECRET_KEYS:
        monkeypatch.delenv(k, raising=False)
    for k in ("SNOW_ENABLED", "SNOW_INSTANCE_URL", "SNOW_USERNAME",
              "SMTP_HOST", "ALERT_FROM", "SMTP_USERNAME",
              "SMTP_ALERTS_ENABLED"):
        monkeypatch.delenv(k, raising=False)
    yield d
    vault.use_vault(previous)


# ── SN-03: the poller ──

class _Connector:
    def __init__(self, stats):
        self.stats = stats
        self.reported = None

    def poll_once(self, dry_run=False):
        return dict(self.stats)


class _Alerter:
    def __init__(self):
        self.down, self.up = [], []

    def component_down(self, component, text):
        self.down.append(text)

    def component_recovered(self, component):
        self.up.append(component)


def _poller(monkeypatch, stats_seq):
    from desktop.snow_poller import ServiceNowPoller
    audit = []
    state = SimpleNamespace(
        availability_alerter=_Alerter(),
        audit=SimpleNamespace(event=lambda *a, **kw: audit.append((a, kw))),
        queue_store=None)
    poller = ServiceNowPoller(SimpleNamespace(state=state),
                              "http://127.0.0.1:1")
    seq = iter(stats_seq)
    settings = SimpleNamespace(poll_interval_seconds=1800)
    monkeypatch.setattr(poller, "_build_connector",
                        lambda read_only=False: (_Connector(next(seq)),
                                                 settings))
    return poller, state.availability_alerter, audit


FETCH_FAILED = {"fetched": 0, "errors": 1, "fetch_failed": True,
                "error_detail": "Network error after 1 attempts: refused"}
TICKET_ERROR = {"fetched": 5, "errors": 1, "submitted": 4}
OK = {"fetched": 5, "errors": 0, "submitted": 5}


def test_outage_backs_off_and_alerts_within_minutes(data_dir, monkeypatch):
    poller, alerter, audit = _poller(monkeypatch, [FETCH_FAILED] * 3 + [OK])
    waits = [poller._poll_once() for _ in range(3)]
    assert waits == [60.0, 120.0, 240.0]          # not 30 minutes
    assert len(alerter.down) == 1                 # third failure: e-mail
    # The same failure is written to the audit trail once, not per poll.
    failed = [a for a in audit if a[0][1] == "servicenow_poll_failed"]
    assert len(failed) == 1
    assert poller._poll_once() == 1800.0          # recovered: normal interval
    assert alerter.up and poller.last_success_at
    assert poller.status()["last_success_at"] == poller.last_success_at


def test_single_ticket_errors_are_not_an_outage(data_dir, monkeypatch):
    poller, alerter, _ = _poller(monkeypatch, [TICKET_ERROR] * 4)
    for _ in range(4):
        assert poller._poll_once() == 1800.0
    assert poller.consecutive_errors == 0 and not alerter.down
    assert poller.last_error                      # still reported
    assert poller.last_success_at                 # ServiceNow answered


def test_own_service_down_is_neutral(data_dir, monkeypatch):
    unavailable = {"fetched": 0, "errors": 0, "service_unavailable": True}
    poller, alerter, _ = _poller(monkeypatch,
                                 [FETCH_FAILED, unavailable, unavailable])
    poller._poll_once()
    poller._poll_once()
    poller._poll_once()
    assert poller.consecutive_errors == 1         # unchanged by the skips
    assert not alerter.down and not alerter.up


def test_preview_is_quick(data_dir, monkeypatch):
    from desktop.snow_poller import ServiceNowPoller
    seen = {}
    settings = SimpleNamespace(max_retries=4, http_timeout_seconds=30,
                               fetch_ceiling=1000,
                               build_query=lambda: "active=true",
                               filter_summary=lambda: [])

    class _C:
        reported = None

        def poll_once(self, dry_run=False):
            seen.update(retries=settings.max_retries,
                        timeout=settings.http_timeout_seconds,
                        ceiling=settings.fetch_ceiling, dry=dry_run)
            return {"fetched": 0}
    poller = ServiceNowPoller(SimpleNamespace(state=SimpleNamespace()),
                              "http://127.0.0.1:1")
    monkeypatch.setattr(poller, "_build_connector",
                        lambda read_only=False: (_C(), settings))
    poller.preview()
    assert seen == {"retries": 0, "timeout": 15.0, "ceiling": 50,
                    "dry": True}


# ── SN-02: ticket updates not written ──

def test_ticket_update_backlog(tmp_path, data_dir):
    from src.core.db import Database
    from src.modules.intake.models import ProcessingRequest
    from src.modules.queue.services import QueueStore
    store = QueueStore(Database.from_config(make_config(tmp_path)))
    marks = [{"pending": True, "rounds": 2}, {"pending": True, "rounds": 6},
             {"pending": False, "rounds": 0}]
    for i, mark in enumerate(marks):
        req = ProcessingRequest(
            operation="deprovision", affiliation_code="31234",
            employee_code=f"881000{i}", source="servicenow",
            ticket_id=f"SCTASK00{i}", metadata={"snow_writeback": mark})
        store.enqueue(req)
    assert store.writeback_backlog(6) == {"pending": 1, "given_up": 1,
                                          "refused": 0}


def test_refused_update_is_an_error_for_the_alert_mail():
    text = (Path(__file__).resolve().parents[2] / "src" / "integrations"
            / "servicenow" / "writeback.py").read_text(encoding="utf-8")
    import re
    block = text.split('if not ok:')[1][:1200]
    assert 'self._log("error"' in block
    assert re.search(r'"servicenow_ticket_update_refused",\s+"ERROR"', block)


# ── API: secret saved → poll; configured; outbox; terminal gates ──

def _client(tmp_path):
    from fastapi.testclient import TestClient
    from desktop.server import mount_console_ui
    from src import create_app
    app = create_app(make_config(tmp_path, dispatcher_enabled=False,
                                 terminal_driver="mock",
                                 log_dir=str(tmp_path / "logs")))
    mount_console_ui(app, mode="agent", stop_hook=lambda: None)
    return TestClient(app)


def _token(client):
    client.post("/api/v1/auth/bootstrap",
                json={"username": "alice", "password": PASSWORD})
    return client.post("/api/v1/auth/login", json={
        "username": "alice", "password": PASSWORD}).json()["access_token"]


def _h(t):
    return {"Authorization": f"Bearer {t}"}


def test_saving_the_snow_password_polls_at_once(tmp_path, data_dir):
    with _client(tmp_path) as client:
        token = _token(client)
        woken = []
        client.app.state.snow_poller = SimpleNamespace(
            poll_now=lambda: woken.append(1))
        r = client.put("/api/v1/system/secrets/SNOW_PASSWORD",
                       headers=_h(token), json={"value": "pw"})
        assert r.status_code == 200 and woken == [1]
        client.put("/api/v1/system/secrets/SMTP_PASSWORD",
                   headers=_h(token), json={"value": "pw"})
        assert woken == [1]                        # not for e-mail


def test_smtp_sign_in_needs_its_password(tmp_path, data_dir):
    with _client(tmp_path) as client:
        token = _token(client)
        client.put("/api/v1/console/settings", headers=_h(token), json={
            "SMTP_HOST": "smtp.example.com", "ALERT_FROM": "bot@example.com",
            "SMTP_USERNAME": "bot"})
        m = client.get("/api/v1/system/setup",
                       headers=_h(token)).json()["modules"]
        assert m["smtp"]["configured"] is False
        client.put("/api/v1/system/secrets/SMTP_PASSWORD",
                   headers=_h(token), json={"value": "pw"})
        m = client.get("/api/v1/system/setup",
                       headers=_h(token)).json()["modules"]
        assert m["smtp"]["configured"] is True


def test_outbox_delete_and_wait(tmp_path, data_dir, monkeypatch):
    from email.message import EmailMessage
    from src.modules.notifications import notifier
    from src.modules.notifications.outbox import Outbox
    box = Outbox(tmp_path / "mail_outbox", transport=None, keep_hours=24)
    msg = EmailMessage()
    msg["Subject"] = "Account registered"
    msg.set_content("x")
    assert box.put(msg, ["user@example.com"], kind="user_registration")
    monkeypatch.setattr(notifier, "get_outbox", lambda: box)
    with _client(tmp_path) as client:
        token = _token(client)
        (entry,) = client.get("/api/v1/system/email/outbox",
                              headers=_h(token)).json()["emails"]
        # Only an outbox entry name is accepted.
        assert client.delete("/api/v1/system/email/outbox/not-an-entry",
                             headers=_h(token)).status_code == 400
        assert client.delete("/api/v1/system/email/outbox/..%2Fx",
                             headers=_h(token)).status_code in (400, 404, 405)
        r = client.delete(f"/api/v1/system/email/outbox/{entry['id']}",
                          headers=_h(token))
        assert r.status_code == 200 and r.json()["waiting"] == 0
        assert not list((tmp_path / "mail_outbox").iterdir())
        # After a refused sign-in, "resend now" waits like the worker.
        box._next_round_at = time.time() + 600
        r = client.post("/api/v1/system/email/outbox/retry",
                        headers=_h(token)).json()
        assert r["paused_until_jst"] and r["sent"] == 0


def test_outbox_is_emptied_while_email_is_off(tmp_path, data_dir):
    folder = data_dir / "mail_outbox"
    folder.mkdir()
    (folder / "20261003120000_0123456789ab.json").write_text("{}")
    (folder / "20261003120000_0123456789ab.eml").write_text("x")
    with _client(tmp_path):
        pass
    assert not list(folder.iterdir())


def test_terminal_check_gates(tmp_path, data_dir):
    with _client(tmp_path) as client:
        token = _token(client)
        state = client.app.state
        # Restart and Stop wait for a running check.
        real = state.terminal_check
        state.terminal_check = SimpleNamespace(running=True)
        r = client.post("/api/v1/system/stop", headers=_h(token))
        assert r.status_code == 409 and "terminal check" in r.json()["detail"]
        state.terminal_check = real
        # No check while the sign-in health check runs.
        state.dispatcher = None
        state.availability.login_probe_running = True
        r = client.post("/api/v1/system/test-terminal", headers=_h(token),
                        json={"level": "launch"})
        assert r.status_code == 409 and "health check" in r.json()["detail"]
        state.availability.login_probe_running = False


def test_sign_in_check_waits_after_a_failed_sign_in():
    from src.rpa.terminal_check import TerminalCheck
    check = TerminalCheck(SimpleNamespace(rpa_config={"driver": "mock"}))
    check._run = lambda level: {"ok": False, "failed_step": "sign_in"}
    check.run("navigate")
    assert 0 < check.sign_in_wait_seconds() <= 600
    check._run = lambda level: {"ok": True, "failed_step": ""}
    check.run("navigate")
    assert check.sign_in_wait_seconds() == 0


def test_terminal_check_names_the_program_in_force():
    from src.rpa.terminal_check import TerminalCheck
    executor = SimpleNamespace(
        rpa_config={"driver": "no_such_driver",
                    "application": {"shortcut_path": r"C:\Users\Public\x.lnk",
                                    "window_title_pattern": "基幹業務"},
                    "evidence": {"enabled": False}},
        logger=None)
    result = TerminalCheck(executor).run("launch")
    assert result["application"]["shortcut"].endswith("x.lnk")
    assert result["application"]["window_title"] == "基幹業務"


def test_probe_flag_is_set_while_the_probe_runs():
    from src.modules.queue.availability import AvailabilityMonitor
    seen = []
    monitor = AvailabilityMonitor(
        make_config(Path("/tmp")), login_probe_func=lambda: seen.append(
            monitor.login_probe_running) or True)
    monitor._run_login_probe_if_due(force=True)
    assert seen == [True] and monitor.login_probe_running is False


# ── The console page ──

def test_page_script_changes():
    js = (UI / "app.js").read_text(encoding="utf-8")
    html = (UI / "index.html").read_text(encoding="utf-8")
    assert "function writebackText(m)" in js
    assert "last successful check" in js and "ticket update(s)" in js
    assert "function savedSettingsOnly(container, box)" in js
    assert "may('system.manage') && may('settings.edit') && !WIZARD_DISMISSED" in js
    assert "snowSecrets" in js and "function wizardIncomplete()" in js
    assert "(wizardSavedAny() || wizardSetUpAny()) && !missing.length" in js
    assert "e.partial ? e.message" in js
    assert 'id="sys-outbox"' in html and "async function loadOutbox()" in js
    assert "Used: ${a.shortcut" in js
