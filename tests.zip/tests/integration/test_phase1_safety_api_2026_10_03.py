"""Phase 1 of the console module review (2026-10-03), through the API:
settings that would be unsafe are refused when saved, the connection
tests keep to the same rules, and large requests are refused."""
import pytest

from scripts.run_mock_snow_server import TicketStore, create_mock_app
from tests.conftest import make_config

PASSWORD = "CorrectHorse42"


@pytest.fixture
def data_dir(tmp_path, monkeypatch):
    from desktop import vault
    d = tmp_path / "data"
    d.mkdir()
    monkeypatch.setenv("FINESIII_DATA_DIR", str(d))
    previous = vault._vault
    vault.use_vault(vault.MemoryVault())
    for k in vault.SECRET_KEYS:
        monkeypatch.delenv(k, raising=False)
    yield d
    vault.use_vault(previous)


@pytest.fixture
def mock_snow(monkeypatch):
    """Every ServiceNow client in this test talks to the mock."""
    from tests.conftest import asgi_transport
    from src.integrations.servicenow import client as client_mod
    store = TicketStore()
    transport = asgi_transport(create_mock_app(store))
    original = client_mod.ServiceNowClient.__init__

    def init(self, *a, **kw):
        kw["transport"] = transport
        original(self, *a, **kw)
    monkeypatch.setattr(client_mod.ServiceNowClient, "__init__", init)
    return store


def _client(tmp_path, monkeypatch=None, **cfg):
    from fastapi.testclient import TestClient
    from desktop.server import mount_console_ui
    import src as app_module
    if cfg.get("terminal_driver") in ("pywinauto", "pyautogui", "tn3270"):
        # No real terminal here: the executor is not what is tested.
        from src.modules.queue.dispatcher import MockExecutor
        monkeypatch.setattr(app_module, "build_executor",
                            lambda c: MockExecutor(delay_seconds=0))
    app = app_module.create_app(make_config(
        tmp_path, dispatcher_enabled=False,
        log_dir=str(tmp_path / "logs"), **cfg))
    mount_console_ui(app, mode="agent")
    return TestClient(app)


def _token(client):
    client.post("/api/v1/auth/bootstrap",
                json={"username": "alice", "password": PASSWORD})
    return client.post("/api/v1/auth/login", json={
        "username": "alice", "password": PASSWORD}).json()["access_token"]


def _put(client, token, **changes):
    return client.put("/api/v1/console/settings", json=changes,
                      headers={"Authorization": f"Bearer {token}"})


# ── Settings ──

def test_addresses_and_query_values_are_checked_when_saved(tmp_path,
                                                            data_dir):
    with _client(tmp_path) as client:
        token = _token(client)
        r = _put(client, token, SNOW_INSTANCE_URL="http://evil.example.com")
        assert r.status_code == 400 and "https://" in r.json()["detail"]
        r = _put(client, token,
                 SNOW_INSTANCE_URL="https://dev.service-now.com/x?a=b")
        assert r.status_code == 400
        r = _put(client, token, SNOW_ASSIGNMENT_GROUP="G^NQactive=true")
        assert r.status_code == 400
        r = _put(client, token, SNOW_TABLE="sc_task;x")
        assert r.status_code == 400
        # Nothing of a refused request is stored.
        r = _put(client, token, SNOW_INSTANCE_URL="http://127.0.0.1:8090",
                 SNOW_ASSIGNMENT_GROUP="Policy Management - JPN",
                 SNOW_OPEN_STATES="1, 2")
        assert r.status_code == 200, r.text


def test_screen_reading_stays_on_with_the_real_terminal(tmp_path, data_dir,
                                                        monkeypatch):
    with _client(tmp_path, monkeypatch, terminal_driver="pywinauto",
                 require_cyberark=False) as client:
        token = _token(client)
        r = _put(client, token, ocr_enabled="false")
        assert r.status_code == 400 and "mandatory" in r.json()["detail"]
        assert _put(client, token, ocr_enabled="true").status_code == 200


def test_screen_reading_may_be_off_with_the_simulator(tmp_path, data_dir):
    with _client(tmp_path, terminal_driver="mock") as client:
        token = _token(client)
        assert _put(client, token, ocr_enabled="false").status_code == 200


def test_cyberark_certificate_check_where_required(tmp_path, data_dir):
    with _client(tmp_path, require_cyberark=True) as client:
        token = _token(client)
        r = _put(client, token, CYBERARK_VERIFY_TLS="false")
        assert r.status_code == 400 and "CyberArk is required" in \
            r.json()["detail"]
    with _client(tmp_path, require_cyberark=False) as client:
        token = _token(client)
        assert _put(client, token,
                    CYBERARK_VERIFY_TLS="false").status_code == 200


def test_certificate_files_must_exist(tmp_path, data_dir):
    cert = tmp_path / "client.pem"
    cert.write_text("x")
    with _client(tmp_path) as client:
        token = _token(client)
        r = _put(client, token,
                 CYBERARK_CERT_PATH=str(tmp_path / "missing.pem"))
        assert r.status_code == 400 and "not found" in r.json()["detail"]
        r = _put(client, token, SMTP_CA_FILE=str(tmp_path / "nope.pem"))
        assert r.status_code == 400
        assert _put(client, token,
                    CYBERARK_CERT_PATH=str(cert)).status_code == 200


def test_stop_accepting_must_leave_part_of_the_window(tmp_path, data_dir):
    with _client(tmp_path) as client:
        token = _token(client)
        r = _put(client, token, availability_window_start="09:00",
                 availability_window_end="10:00",
                 shutdown_buffer_minutes="60")
        assert r.status_code == 400 and "shorter" in r.json()["detail"]
        assert _put(client, token, availability_window_start="09:00",
                    availability_window_end="10:00",
                    shutdown_buffer_minutes="30").status_code == 200
        # The buffer alone, against the stored window.
        r = _put(client, token, shutdown_buffer_minutes="90")
        assert r.status_code == 400


def test_error_rules_name_the_file_only(tmp_path, data_dir):
    with _client(tmp_path) as client:
        token = _token(client)
        r = client.get("/api/v1/console/error-rules",
                       headers={"Authorization": f"Bearer {token}"}).json()
        assert r["source"] == "errors.yaml"


# ── Request sizes (X-09) ──

def test_large_requests_are_refused(tmp_path, data_dir):
    with _client(tmp_path) as client:
        token = _token(client)
        h = {"Authorization": f"Bearer {token}"}
        r = client.put("/api/v1/console/branding", headers=h,
                       content=b"{" + b" " * (3 * 1024 * 1024) + b"}")
        assert r.status_code == 413
        r = client.post("/api/v1/requests", headers=h,
                        content=b"{" + b" " * (300 * 1024) + b"}")
        assert r.status_code == 413

        def chunks():
            yield b'{"operation": "provision", "x": "'
            for _ in range(40):
                yield b"x" * (10 * 1024)
            yield b'"}'
        r = client.post("/api/v1/requests", headers=h, content=chunks())
        assert r.status_code == 413
        # A normal request is not affected.
        r = client.post("/api/v1/requests", headers=h, json={
            "operation": "provision", "affiliation_code": "31234",
            "employee_code": "8812345", "ticket_id": "P1-SIZE",
            "password": "FUJI@33F"})
        assert r.status_code == 202, r.text


# ── Connection tests (X-08, SN-06, SN-08) ──

SNOW = {"instance_url": "https://testserver", "auth_method": "basic",
        "username": "api.user", "password": "pw", "table": "sc_task"}


def _test(client, token, path, **body):
    r = client.post(f"/api/v1/system/{path}", json=body,
                    headers={"Authorization": f"Bearer {token}"})
    assert r.status_code == 200, r.text
    return r.json()


def test_servicenow_test_keeps_to_the_address_rules(tmp_path, data_dir):
    with _client(tmp_path) as client:
        token = _token(client)
        r = _test(client, token, "test-servicenow",
                  **dict(SNOW, instance_url="http://evil.example.com"))
        assert r["ok"] is False and "https://" in r["error"]
        r = _test(client, token, "test-servicenow",
                  **dict(SNOW, table="sc_task?x=1"))
        assert r["ok"] is False and "table name" in r["error"]


def test_bot_account_by_sys_id_and_inactive(tmp_path, data_dir, mock_snow):
    from scripts.run_mock_snow_server import user_sys_id
    sid = user_sys_id("finesiii.bot")      # a user record on the stand-in
    with _client(tmp_path) as client:
        token = _token(client)
        r = _test(client, token, "test-servicenow",
                  **dict(SNOW, assigned_to=sid))
        assert r["ok"] is True
        assert r["account"]["sys_id"] == sid
        assert r["account"]["user_name"] == "finesiii.bot"
        assert r["account"]["name"] == "FINESIII Bot"
        mock_snow.people[sid]["active"] = "false"
        r = _test(client, token, "test-servicenow",
                  **dict(SNOW, assigned_to=sid))
        assert "inactive" in r["hint"]


def test_discover_returns_no_ticket_values(tmp_path, data_dir, mock_snow,
                                           monkeypatch):
    monkeypatch.setenv("SNOW_ASSIGNED_TO", "finesiii.bot")
    mock_snow.create_sailpoint("add")       # routed to the bot account
    with _client(tmp_path) as client:
        token = _token(client)
        r = _test(client, token, "discover-servicenow", **SNOW)
        assert r["ok"] is True and r["fields"], r
        assert r["sample"]
        for row in r["sample"]:
            assert all(isinstance(v, bool) for v in row.values())
        for rows in r.get("variables") or []:
            for v in rows:
                assert "value" not in v and isinstance(v["has_value"], bool)


def test_email_test_limits(tmp_path, data_dir):
    with _client(tmp_path) as client:
        token = _token(client)
        to = "; ".join(f"user{i}@example.com" for i in range(6))
        r = _test(client, token, "test-email", to=to, host="127.0.0.1",
                  port="2525", **{"from": "bot@example.com"})
        assert r["ok"] is False and "at most 5" in r["error"]


def test_email_test_keeps_the_stored_password_checked(tmp_path, data_dir,
                                                       monkeypatch):
    monkeypatch.setenv("SMTP_HOST", "smtp.example.com")
    monkeypatch.setenv("SMTP_PORT", "587")
    monkeypatch.setenv("SMTP_PASSWORD", "stored-secret")
    with _client(tmp_path) as client:
        token = _token(client)
        r = _test(client, token, "test-email", send=False,
                  host="smtp.example.com", port="587",
                  username="bot", verify_cert="false")
        assert r["ok"] is False and "Certificate checking" in r["error"]
