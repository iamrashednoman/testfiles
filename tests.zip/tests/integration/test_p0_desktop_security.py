"""P0 security fixes for the installable desktop app (approved 2026-09-26).

Pins four behaviours:

1. D4 — with auth_console_grants_api ON, a signed-in console session
   satisfies the machine API-key check on the intake routes, checked
   against the permission each route needs. With the flag OFF (the
   default, every server deployment) nothing changes: a Bearer token is
   still not an API key (test_auth_api.TestMachineApiKeyUnaffected).
2. Cancel is guarded by requests.cancel, retry by requests.retry — one
   shared dependency used to guard both, which made cancel dead.
3. /ping answers without credentials and reveals nothing, so the
   desktop shell can wait for an auth-enabled service to come up.
4. Restart-in-process: a CLEARED env-target override is restored to the
   environment value on the next apply_overrides, instead of the stale
   override living in os.environ for the rest of the process.
"""
import os

import pytest

from tests.conftest import make_config

VALID = {"operation": "provision", "affiliation_code": "30822",
         "employee_code": "1217036", "password": "FUJI@33F"}
PASSWORD = "CorrectHorse42"
API_KEY = "svc:machine-key-value"


@pytest.fixture(autouse=True)
def fast_sleep(monkeypatch):
    monkeypatch.setattr("time.sleep", lambda s: None)


def _client(tmp_path, **overrides):
    from fastapi.testclient import TestClient
    from src import create_app
    cfg = make_config(tmp_path, dispatcher_enabled=False,
                      terminal_driver="mock",
                      log_dir=str(tmp_path / "logs"), **overrides)
    return TestClient(create_app(cfg))


def _auth(token):
    return {"Authorization": f"Bearer {token}"}


def _bootstrap_admin(client):
    r = client.post("/api/v1/auth/bootstrap",
                    json={"username": "alice", "password": PASSWORD})
    assert r.status_code == 201, r.text
    return _login(client, "alice", PASSWORD)


def _login(client, username, password):
    r = client.post("/api/v1/auth/login",
                    json={"username": username, "password": password})
    assert r.status_code == 200, r.text
    return r.json()["access_token"]


def _user_with(client, admin_token, username, role, permissions=None):
    """Create an ACTIVATED account holding exactly `role` (creating the
    custom role with `permissions` first when given)."""
    if permissions is not None:
        r = client.post("/api/v1/admin/roles", headers=_auth(admin_token),
                        json={"name": role, "permissions": permissions})
        assert r.status_code == 201, r.text
    r = client.post("/api/v1/admin/users", headers=_auth(admin_token),
                    json={"username": username, "password": PASSWORD,
                          "role": role})
    assert r.status_code == 201, r.text
    token = _login(client, username, PASSWORD)
    chosen = "TheirOwnSecret77"
    r = client.post("/api/v1/auth/password", headers=_auth(token),
                    json={"current_password": PASSWORD,
                          "new_password": chosen})
    assert r.status_code == 200, r.text
    return _login(client, username, chosen)


class TestConsoleSessionGrantsApi:
    """D4: the desktop UI only ever holds a console session, so in
    desktop mode that session must reach the intake routes."""

    def test_flag_off_keeps_the_schemes_separate(self, tmp_path,
                                                 monkeypatch):
        monkeypatch.setenv("FINESIII_API_KEYS", API_KEY)
        with _client(tmp_path, auth_enabled=True) as client:
            token = _bootstrap_admin(client)
            assert client.get("/api/v1/requests",
                              headers=_auth(token)).status_code == 401

    def test_admin_session_reads_and_submits(self, tmp_path, monkeypatch):
        monkeypatch.setenv("FINESIII_API_KEYS", API_KEY)
        with _client(tmp_path, auth_enabled=True,
                     auth_console_grants_api=True) as client:
            token = _bootstrap_admin(client)
            assert client.get("/api/v1/requests",
                              headers=_auth(token)).status_code == 200
            assert client.get("/api/v1/health",
                              headers=_auth(token)).status_code == 200
            assert client.post("/api/v1/requests", json=VALID,
                               headers=_auth(token)).status_code == 202
            # And the machine key still works exactly as before.
            assert client.get("/api/v1/queue",
                              headers={"X-API-Key": "machine-key-value"}
                              ).status_code == 200

    def test_viewer_may_read_but_not_submit(self, tmp_path, monkeypatch):
        monkeypatch.setenv("FINESIII_API_KEYS", API_KEY)
        with _client(tmp_path, auth_enabled=True,
                     auth_console_grants_api=True) as client:
            admin = _bootstrap_admin(client)
            viewer = _user_with(client, admin, "vic", "viewer")
            assert client.get("/api/v1/transactions",
                              headers=_auth(viewer)).status_code == 200
            r = client.post("/api/v1/requests", json=VALID,
                            headers=_auth(viewer))
            assert r.status_code == 403
            assert "requests.submit" in r.json()["detail"]

    def test_no_credentials_is_still_refused(self, tmp_path, monkeypatch):
        monkeypatch.setenv("FINESIII_API_KEYS", API_KEY)
        with _client(tmp_path, auth_enabled=True,
                     auth_console_grants_api=True) as client:
            _bootstrap_admin(client)
            assert client.get("/api/v1/requests").status_code == 401
            assert client.get("/api/v1/requests",
                              headers=_auth("garbage")).status_code == 401

    def test_provisional_password_grants_nothing(self, tmp_path,
                                                 monkeypatch):
        monkeypatch.setenv("FINESIII_API_KEYS", API_KEY)
        with _client(tmp_path, auth_enabled=True,
                     auth_console_grants_api=True) as client:
            admin = _bootstrap_admin(client)
            client.post("/api/v1/admin/users", headers=_auth(admin),
                        json={"username": "newbie", "password": PASSWORD,
                              "role": "operator"})
            provisional = _login(client, "newbie", PASSWORD)
            assert client.get("/api/v1/requests",
                              headers=_auth(provisional)).status_code == 428


class TestCancelHasItsOwnPermission:
    def _queued(self, client):
        r = client.post("/api/v1/requests", json=VALID)
        assert r.status_code == 202, r.text
        return r.json()["request_id"]

    def test_cancel_only_role_can_cancel_but_not_retry(self, tmp_path):
        with _client(tmp_path) as client:
            admin = _bootstrap_admin(client)
            canceller = _user_with(client, admin, "carl", "canceller",
                                   ["dashboard.view", "requests.view",
                                    "requests.cancel"])
            rid = self._queued(client)
            r = client.post(f"/api/v1/requests/{rid}/retry",
                            headers=_auth(canceller))
            assert r.status_code == 403
            assert "requests.retry" in r.json()["detail"]
            r = client.delete(f"/api/v1/requests/{rid}",
                              headers=_auth(canceller))
            assert r.status_code == 200
            assert r.json()["status"] == "cancelled"

    def test_retry_only_role_cannot_cancel(self, tmp_path):
        with _client(tmp_path) as client:
            admin = _bootstrap_admin(client)
            retrier = _user_with(client, admin, "rita", "retrier",
                                 ["dashboard.view", "requests.view",
                                  "requests.retry"])
            rid = self._queued(client)
            r = client.delete(f"/api/v1/requests/{rid}",
                              headers=_auth(retrier))
            assert r.status_code == 403
            assert "requests.cancel" in r.json()["detail"]


class TestPing:
    def test_answers_without_credentials_when_auth_is_on(self, tmp_path,
                                                         monkeypatch):
        monkeypatch.setenv("FINESIII_API_KEYS", API_KEY)
        with _client(tmp_path, auth_enabled=True) as client:
            r = client.get("/api/v1/ping")
            assert r.status_code == 200
            assert r.json() == {"status": "ok"}       # and nothing more
            # The informative probe still needs the key.
            assert client.get("/api/v1/health").status_code == 401


class TestClearedEnvOverrideIsRestored:
    def test_second_apply_puts_the_environment_value_back(self, tmp_path,
                                                          monkeypatch):
        from src.core.db import Database
        from src.modules.console.settings_store import (
            SettingsStore, apply_overrides,
        )
        monkeypatch.setenv("ERROR_ALERT_TO", "env@x.com")
        cfg = make_config(tmp_path)
        db = Database.from_config(cfg)
        try:
            store = SettingsStore(db)
            store.set("ERROR_ALERT_TO", "override@x.com")
            apply_overrides(cfg, store)
            assert os.environ["ERROR_ALERT_TO"] == "override@x.com"

            store.clear("ERROR_ALERT_TO")
            apply_overrides(cfg, store)          # the in-process restart
            assert os.environ["ERROR_ALERT_TO"] == "env@x.com"
        finally:
            db.close()

    def test_unset_variable_is_removed_again(self, tmp_path, monkeypatch):
        from src.core.db import Database
        from src.modules.console.settings_store import (
            SettingsStore, apply_overrides,
        )
        monkeypatch.delenv("ERROR_ALERT_CC", raising=False)
        cfg = make_config(tmp_path)
        db = Database.from_config(cfg)
        try:
            store = SettingsStore(db)
            store.set("ERROR_ALERT_CC", "cc@x.com")
            apply_overrides(cfg, store)
            assert os.environ["ERROR_ALERT_CC"] == "cc@x.com"
            store.clear("ERROR_ALERT_CC")
            apply_overrides(cfg, store)
            assert "ERROR_ALERT_CC" not in os.environ
        finally:
            db.close()
