"""F1 of the fix plan (2026-10-04): the two UAT blockers and the sign-out
clean-up.

UAT-01  On a fresh installation every Settings save was refused, because
        two whole-number e-mail settings came back as "30.0" / "24.0".
UAT-02  After sign-out and sign-in in the same tab, Requests and Audit
        trail stayed blank: the clean-up deleted the filter controls the
        tables had borrowed from the page.
UAT-08  Other pages' data stayed in the hidden page after sign-out.

The console has no browser test harness in the suite; the page side is
pinned by its contract here and checked in the browser by the F1 UAT."""
import re
from pathlib import Path

import pytest

from tests.conftest import make_config

PASSWORD = "CorrectHorse42"
UI = Path(__file__).resolve().parents[2] / "desktop" / "ui"
APP = (UI / "app.js").read_text(encoding="utf-8")
KIT = (UI / "ui-kit.js").read_text(encoding="utf-8")
INDEX = (UI / "index.html").read_text(encoding="utf-8")


@pytest.fixture
def data_dir(tmp_path, monkeypatch):
    """A fresh installation: no console overrides, and none of the
    catalogue's environment settings set on this machine."""
    from desktop import vault
    from src.modules.console.settings_catalogue import SETTINGS
    d = tmp_path / "data"
    d.mkdir()
    monkeypatch.setenv("FINESIII_DATA_DIR", str(d))
    previous = vault._vault
    vault.use_vault(vault.MemoryVault())
    for k in vault.SECRET_KEYS:
        monkeypatch.delenv(k, raising=False)
    for s in SETTINGS:
        if s["target"] == "env":
            monkeypatch.delenv(s["key"], raising=False)
    yield d
    vault.use_vault(previous)


def _client(tmp_path):
    from fastapi.testclient import TestClient
    from desktop.server import mount_console_ui
    from src import create_app
    app = create_app(make_config(tmp_path, dispatcher_enabled=False,
                                 terminal_driver="mock",
                                 log_dir=str(tmp_path / "logs")))
    mount_console_ui(app, mode="agent", stop_hook=lambda: None)
    return TestClient(app)


def _token(client):
    client.post("/api/v1/auth/bootstrap",
                json={"username": "alice", "password": PASSWORD})
    return client.post("/api/v1/auth/login", json={
        "username": "alice", "password": PASSWORD}).json()["access_token"]


def _h(t):
    return {"Authorization": f"Bearer {t}"}


# ── UAT-01: whole numbers ──

def test_whole_number_defaults_have_no_decimal_part():
    from src.modules.console.settings_catalogue import defaults_in_force
    d = defaults_in_force(["SMTP_TIMEOUT", "EMAIL_OUTBOX_HOURS"])
    assert d["SMTP_TIMEOUT"] == "30"
    assert d["EMAIL_OUTBOX_HOURS"] == "24"


def test_every_value_returned_passes_its_own_check(tmp_path, data_dir):
    """What GET /console/settings shows on a fresh installation is
    accepted by the server's own check, and every whole-number value is
    written without a decimal part (the page refuses "30.0")."""
    from src.modules.console.settings_catalogue import BY_KEY, coerce
    with _client(tmp_path) as client:
        r = client.get("/api/v1/console/settings",
                       headers=_h(_token(client)))
        assert r.status_code == 200
        problems = []
        for item in r.json()["settings"]:
            spec = BY_KEY[item["key"]]
            value = item["value"]
            # Service settings come from the test configuration here
            # (fast poll intervals); their built-in defaults are checked
            # in the next test.
            if spec["secret"] or spec["target"] != "env" \
                    or value in ("", None):
                continue
            try:
                coerce(spec, value)
            except ValueError as e:
                problems.append(f"{item['key']}={value!r}: {e}")
            if spec["kind"] == "int" and not re.fullmatch(r"-?\d+",
                                                          str(value)):
                problems.append(f"{item['key']}={value!r}: not a whole "
                                f"number as the page checks it")
        assert not problems, problems


@pytest.mark.parametrize("cls_path", ["config.development.DevelopmentConfig",
                                      "config.production.ProductionConfig"])
def test_built_in_service_defaults_pass_their_own_check(cls_path,
                                                        data_dir):
    """The service settings shown on a fresh installation are the
    configuration class defaults: each passes its own check."""
    import importlib
    from src.modules.console.settings_catalogue import SETTINGS, coerce
    module, _, name = cls_path.rpartition(".")
    cfg = getattr(importlib.import_module(module), name)()
    problems = []
    for spec in SETTINGS:
        if spec["target"] != "config" or spec["secret"]:
            continue
        value = getattr(cfg, spec["key"], None)
        if value in ("", None):
            continue
        try:
            coerce(spec, value)
        except ValueError as e:
            problems.append(f"{spec['key']}={value!r}: {e}")
        if spec["kind"] == "int" and not re.fullmatch(r"-?\d+", str(value)):
            problems.append(f"{spec['key']}={value!r}: not a whole number")
    assert not problems, problems


def test_saving_the_values_shown_is_accepted(tmp_path, data_dir):
    """The values shown for the two e-mail settings are accepted by Save,
    so Save no longer fails on a fresh installation."""
    with _client(tmp_path) as client:
        token = _token(client)
        shown = {i["key"]: i["value"] for i in client.get(
            "/api/v1/console/settings", headers=_h(token)).json()["settings"]}
        r = client.put("/api/v1/console/settings", headers=_h(token),
                       json={"SMTP_TIMEOUT": shown["SMTP_TIMEOUT"],
                             "EMAIL_OUTBOX_HOURS":
                                 shown["EMAIL_OUTBOX_HOURS"]})
        assert r.status_code == 200, r.text


# ── UAT-02: the tables give their filter controls back ──

def _function(source, signature):
    body = source[source.index(signature):]
    return body[:body.index("\n}\n") + 2]


def test_table_remembers_and_returns_borrowed_controls():
    ctor = KIT[KIT.index("class DataTable"):KIT.index("savePrefs()")]
    assert "this.homes" in ctor and "parentNode" in ctor
    destroy = KIT[KIT.index("  destroy() {"):]
    destroy = destroy[:destroy.index("\n  }\n")]
    assert "home.appendChild(n)" in destroy
    assert "n.value = ''" in destroy                 # reset for the next user
    assert "this._seq" in destroy                    # late answers dropped
    assert "this.o.host.textContent = ''" in destroy


def test_sign_out_clean_up_uses_destroy_not_the_hosts():
    clean = _function(APP, "function clearSensitive()")
    assert "Object.values(TABLES).forEach(t => t.destroy())" in clean
    for host in ("'req-table'", "'hi-table'", "'au-body'"):
        assert host not in clean, host


def test_borrowed_controls_have_their_hidden_holders():
    for holder, controls in (("req-filters", ["req-status"]),
                             ("au-filters", ["au-cat", "au-sev", "au-req"])):
        start = INDEX.index(f'id="{holder}"')
        block = INDEX[start:INDEX.index("</div>", start)]
        for c in controls:
            assert f'id="{c}"' in block, c


def test_clean_up_runs_before_the_tables_are_forgotten():
    for fn in ("async function signOut(",):
        body = _function(APP, fn)
        assert body.index("clearSensitive()") < body.index("TABLES = {}")


# ── UAT-08: the other pages are cleared too ──

def test_other_pages_are_cleared_on_sign_out():
    clean = _function(APP, "function clearSensitive()")
    for area in ("dash-cards", "set-body", "set-deploy", "set-nav",
                 "sys-cards", "sys-controls", "sys-selftest",
                 "sys-outbox-body", "rp-kpis", "rp-charts", "rp-audit-kpis",
                 "rp-audit-charts", "rl-body", "rules-history-body",
                 "wz-body", "req-actions", "dr-sub"):
        assert f"'{area}'" in clean, area
    assert "$('sys-log').textContent = '—'" in clean
    assert "$('dr-title').textContent = 'Details'" in clean
    assert "delete $('req-actions').dataset.built" in clean
    for form in ("req-form", "us-form", "rl-form"):
        assert f"'{form}'" in clean, form
    for state in ("SETTINGS_META = null", "DEPLOY = null",
                  "USERS_DATA = []", "ROLES_INFO = []"):
        assert state in clean, state


def test_every_area_cleared_exists_in_the_page():
    clean = _function(APP, "function clearSensitive()")
    for area in re.findall(r"'([a-z]+(?:-[a-z]+)+)'", clean):
        assert f'id="{area}"' in INDEX, area
