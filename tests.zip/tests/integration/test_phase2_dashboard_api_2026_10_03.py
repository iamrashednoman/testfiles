"""Phase 2 of the console module review (2026-10-03): the service stays
responsive while heavy work runs, and the Dashboard and Reports say
what they actually know."""
import inspect
from pathlib import Path

import pytest

from tests.conftest import make_config

PASSWORD = "CorrectHorse42"
UI = Path(__file__).resolve().parents[2] / "desktop" / "ui"


@pytest.fixture
def data_dir(tmp_path, monkeypatch):
    from desktop import vault
    d = tmp_path / "data"
    d.mkdir()
    monkeypatch.setenv("FINESIII_DATA_DIR", str(d))
    previous = vault._vault
    vault.use_vault(vault.MemoryVault())
    for k in vault.SECRET_KEYS:
        monkeypatch.delenv(k, raising=False)
    yield d
    vault.use_vault(previous)


def _app(tmp_path, audit=False):
    from desktop.server import mount_console_ui
    from src import create_app
    extra = {}
    if audit:
        extra = dict(audit_enabled=True, audit_backend="sqlite",
                     audit_sqlite_path=str(tmp_path / "audit.db"),
                     audit_spool_path=str(tmp_path / "spool.db"),
                     audit_flush_interval_seconds=0.05)
    app = create_app(make_config(tmp_path, dispatcher_enabled=False,
                                 terminal_driver="mock",
                                 log_dir=str(tmp_path / "logs"), **extra))
    mount_console_ui(app, mode="agent")
    return app


def _client(app):
    from fastapi.testclient import TestClient
    return TestClient(app)


def _token(client, username="alice", password=PASSWORD):
    client.post("/api/v1/auth/bootstrap",
                json={"username": "alice", "password": PASSWORD})
    return client.post("/api/v1/auth/login", json={
        "username": username, "password": password}).json()["access_token"]


def _h(token):
    return {"Authorization": f"Bearer {token}"}


# ── X-01: heavy routes run on the worker pool ──

# Routes that do no blocking work may stay on the event loop.
EVENT_LOOP_OK = {"ping", "put_deployment"}


def test_no_route_blocks_the_event_loop(tmp_path, data_dir):
    from fastapi.routing import APIRoute
    app = _app(tmp_path)
    blocking = [r.endpoint.__name__ for r in app.routes
                if isinstance(r, APIRoute)
                and inspect.iscoroutinefunction(r.endpoint)
                and r.endpoint.__name__ not in EVENT_LOOP_OK]
    assert blocking == []


def test_permission_checks_run_on_the_worker_pool():
    from src.modules.auth.services import (
        build_action_dependency, build_permission_dependency,
        build_session_dependency,
    )
    for dep in (build_permission_dependency(object(), "x"),
                build_session_dependency(object()),
                build_action_dependency(object(), None, "x")):
        assert not inspect.iscoroutinefunction(dep)


def test_audit_database_connection_has_a_time_out(monkeypatch):
    import psycopg
    from src.modules.audit import trail_db
    seen = {}
    monkeypatch.setattr(psycopg, "connect",
                        lambda dsn, **kw: seen.update(kw) or object())
    trail_db.PostgresAuditBackend("postgresql://x@127.0.0.1:1/a")._connect()
    assert seen["connect_timeout"] == trail_db.CONNECT_TIMEOUT_SECONDS == 5


def test_self_test_reports_the_loaded_engine(monkeypatch):
    import importlib.util
    from desktop import selftest
    from src.rpa.vision.ocr import PaddleOcrEngine
    real = importlib.util.find_spec
    monkeypatch.setattr(importlib.util, "find_spec",
                        lambda name, *a: object() if name == "paddleocr"
                        else real(name, *a))
    engine = PaddleOcrEngine()
    engine._pipeline = object()          # loaded by the service
    loads = []
    monkeypatch.setattr(PaddleOcrEngine, "load",
                        lambda self: loads.append(1))
    report = selftest.run_selftest(None, ocr_engine=engine)
    check = next(c for c in report["checks"] if c["name"] == "ocr engine")
    assert "loaded in the running service" in str(check)
    assert loads == []                   # no second engine


# ── DR-01 / DR-02 / DR-08 / DR-12: the dashboard summary ──

def test_whole_history_figures_once_a_minute(tmp_path, data_dir,
                                             monkeypatch):
    app = _app(tmp_path)
    store = app.state.transaction_store
    calls = []
    original = store.statistics
    monkeypatch.setattr(store, "statistics",
                        lambda: calls.append(1) or original())
    with _client(app) as client:
        h = _h(_token(client))
        for _ in range(3):
            body = client.get("/api/v1/console/summary", headers=h).json()
        assert len(calls) == 1
        assert body["generated_at"][:4].isdigit()
        assert body["recent"] == [] and body["statistics"] is not None


def test_unreadable_figures_are_unavailable_not_empty(tmp_path, data_dir,
                                                      monkeypatch):
    app = _app(tmp_path)
    store = app.state.transaction_store

    def broken(*a, **kw):
        raise RuntimeError("database gone")
    monkeypatch.setattr(store, "list_transactions", broken)
    monkeypatch.setattr(store, "statistics", broken)
    with _client(app) as client:
        body = client.get("/api/v1/console/summary",
                          headers=_h(_token(client))).json()
        assert body["recent"] is None
        assert body["statistics"] is None and body["result_codes"] is None


def test_error_screens_of_today_only(tmp_path, data_dir, monkeypatch):
    from src.modules.intake.models import now_jst
    app = _app(tmp_path, audit=True)
    seen = {}
    monkeypatch.setattr(app.state.audit, "query",
                        lambda **kw: seen.update(kw) or [])
    with _client(app) as client:
        client.get("/api/v1/console/summary", headers=_h(_token(client)))
    assert seen["category"] == "rpa_error"
    assert seen["date_from"] == now_jst().date().isoformat()


def test_monitoring_role_does_not_see_employee_codes(tmp_path, data_dir):
    app = _app(tmp_path)
    with _client(app) as client:
        admin = _h(_token(client))
        r = client.post("/api/v1/requests", headers=admin, json={
            "operation": "deprovision", "affiliation_code": "31234",
            "employee_code": "8812345", "ticket_id": "P2-DASH"})
        assert r.status_code == 202, r.text
        # A finished transaction for the recent list.
        from src.modules.queue.dispatcher import build_transaction_record
        from src.modules.intake.models import now_jst
        req = app.state.queue_store.get(r.json()["request_id"])
        app.state.transaction_store.record(build_transaction_record(
            req, "done", "O-0000", "", "", now_jst()))
        assert client.post("/api/v1/admin/roles", headers=admin, json={
            "name": "monitor", "description": "Dashboard only",
            "permissions": ["dashboard.view"]}).status_code in (200, 201)
        assert client.post("/api/v1/admin/users", headers=admin, json={
            "username": "watcher", "password": "Provisional42!x",
            "role": "monitor"}).status_code in (200, 201)
        t = client.post("/api/v1/auth/login", json={
            "username": "watcher", "password": "Provisional42!x"}
        ).json()["access_token"]
        client.post("/api/v1/auth/password", headers=_h(t), json={
            "current_password": "Provisional42!x",
            "new_password": "ObserverOwn42!x"})
        t = client.post("/api/v1/auth/login", json={
            "username": "watcher", "password": "ObserverOwn42!x"}
        ).json()["access_token"]
        mine = client.get("/api/v1/console/summary", headers=_h(t)).json()
        assert mine["recent"] and mine["recent"][0]["employee_code"] == ""
        full = client.get("/api/v1/console/summary", headers=admin).json()
        assert full["recent"][0]["employee_code"] == "8812345"


# ── DR-03: like-for-like comparison ──

def test_today_is_compared_with_the_same_time_yesterday(tmp_path, data_dir,
                                                        monkeypatch):
    app = _app(tmp_path)
    store = app.state.transaction_store
    calls = []
    monkeypatch.setattr(store, "metrics_rows",
                        lambda a, b: calls.append((a, b)) or [])
    with _client(app) as client:
        h = _h(_token(client))
        body = client.get("/api/v1/console/metrics?period=today",
                          headers=h).json()
        previous_to = calls[-1][1]
        assert len(previous_to) > 10 and "T" in previous_to   # a time
        assert body["compared_until"] == previous_to
        calls.clear()
        client.get("/api/v1/console/metrics?period=custom"
                   "&date_from=2026-01-01&date_to=2026-01-07", headers=h)
        assert calls[-1][1] == "2025-12-31"                    # whole day


# ── The console page (UI behaviour, checked in the page script) ──

def _js(name):
    return (UI / name).read_text(encoding="utf-8")


def test_page_script_changes():
    app_js, kit = _js("app.js"), _js("ui-kit.js")
    # X-05: a stale table answer is dropped.
    assert "if (seq !== this._seq) return;" in kit
    # RQ-04: the request is set before the evidence page loads it.
    body = app_js.split("function openEvidence(requestId) {")[1][:400]
    assert body.index("$('ev-id').value = requestId;") \
        < body.index("switchView('evidence');")
    assert "LOADERS.evidence();" not in body.split("}")[0]
    # RQ-05: cleared on sign-out and on sign-in.
    # The sign-out function takes options since F2 (2026-10-04).
    sign_out = app_js.split("async function signOut(")[1].split("\n}\n")[0]
    enter = app_js.split("async function enterConsole(")[1][:3000]
    assert "clearSensitive();" in sign_out and "clearSensitive();" in enter
    # DR-01: no refresh while hidden or still running.
    assert "if (!document.hidden) LOADERS.dashboard();" in app_js
    assert "|| DASH_BUSY) return;" in app_js
    # DR-02 / DR-08 / DR-13 wording.
    assert "'Unavailable', 'bad', 'The queue could not be read'" in app_js
    assert "Error screens recognised (today)" in app_js
    assert "'All requests by status'" in app_js
    # DR-10: a custom export needs both days.
    export = app_js.split("async function exportReportAudit() {")[1][:600]
    assert "Choose the first and last day of the period." in export


def test_page_markup_changes():
    html = _js("index.html")
    assert 'id="dash-updated" role="status"' in html
    assert 'id="rp-printed"' in html
    # DR-11: the period label is outside the Processing section, so
    # audit-only users see it too.
    processing = html.split('<div id="rp-processing">')[1].split(
        '<div id="rp-audit">')[0]
    assert "rp-period-label" not in processing
    assert ".printonly{display:none}" in _js("app.css")
