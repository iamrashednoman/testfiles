"""E-mail module review (2026-09-29) through the real application:
start / stop notices, Test connection and Send test e-mail on the
console, the new E-mail settings, and the console banner while e-mail
delivery fails. SMTP is a fake; no network."""
import logging

import pytest

from tests.conftest import make_config

PASSWORD = "CorrectHorse42"
MAIL_ENV = {"SMTP_ALERTS_ENABLED": "true", "SMTP_HOST": "relay.example.com",
            "SMTP_PORT": "25", "ALERT_FROM": "finesiii-rpa@example.com",
            "ALERT_TO": "ops@example.com"}


@pytest.fixture(autouse=True)
def fast_sleep(monkeypatch):
    monkeypatch.setattr("time.sleep", lambda s: None)


@pytest.fixture
def mail(tmp_path, monkeypatch):
    """E-mail on, with every message caught by a fake server."""
    from desktop import vault
    from src.modules.console.settings_store import _restore_env_overrides
    from src.modules.notifications.log_handler import ALERT_LOGGER_NAMES
    from src.modules.notifications.notifier import EmailNotifier
    data = tmp_path / "data"
    data.mkdir()
    monkeypatch.setenv("FINESIII_DATA_DIR", str(data))
    previous = vault._vault
    vault.use_vault(vault.MemoryVault())
    for k in list(vault.SECRET_KEYS) + ["SMTP_SECURITY", "SMTP_USE_SSL",
                                        "SMTP_USE_STARTTLS"]:
        monkeypatch.delenv(k, raising=False)
    for k, v in MAIL_ENV.items():
        monkeypatch.setenv(k, v)
    sent, state = [], {"down": False}

    class FakeSMTP:
        esmtp_features = {"size": "1048576"}

        def send_message(self, msg, to_addrs=None):
            if state["down"]:
                raise OSError("connection refused")
            sent.append((msg, list(to_addrs or [])))
            return {}

        def noop(self):
            return (250, b"OK")

        def quit(self):
            pass

    def connect(self, info=None):
        if info is not None:
            info.update(starttls_offered=False, encrypted=False,
                        tls_version="", auth_methods="", max_size="1048576")
        return FakeSMTP()
    monkeypatch.setattr(EmailNotifier, "_connect", connect)
    yield sent, state
    vault.use_vault(previous)
    _restore_env_overrides()
    for name in ALERT_LOGGER_NAMES:
        log = logging.getLogger(name)
        for h in list(log.handlers):
            if type(h).__name__ == "EmailAlertHandler":
                log.removeHandler(h)


def _client(tmp_path):
    from fastapi.testclient import TestClient
    from desktop.server import mount_console_ui
    from src import create_app
    cfg = make_config(tmp_path, terminal_driver="mock",
                      dispatcher_enabled=False, log_dir=str(tmp_path / "logs"))
    app = create_app(cfg)
    mount_console_ui(app, mode="agent")
    return TestClient(app)


def _auth(t):
    return {"Authorization": f"Bearer {t}"}


def _admin(client):
    client.post("/api/v1/auth/bootstrap",
                json={"username": "alice", "password": PASSWORD})
    return client.post("/api/v1/auth/login", json={
        "username": "alice", "password": PASSWORD}).json()["access_token"]


def _wait_for(sent, count):
    import threading
    for t in threading.enumerate():
        if t.name == "service-notice":
            t.join(5)
    return len(sent) >= count


class TestServiceNotices:
    def test_started_and_stopping_when_switched_on(self, tmp_path, mail,
                                                    monkeypatch):
        sent, _ = mail
        monkeypatch.setenv("EMAIL_SERVICE_NOTICES", "true")
        with _client(tmp_path):
            assert _wait_for(sent, 1)
            assert "service started" in sent[0][0]["Subject"]
        assert any("stopping" in m["Subject"] for m, _ in sent)

    def test_nothing_on_a_normal_start_by_default(self, tmp_path, mail):
        sent, _ = mail
        with _client(tmp_path):
            _wait_for(sent, 0)
        assert not any("service" in m["Subject"] for m, _ in sent)


class TestConsoleTests:
    def test_test_connection_sends_nothing(self, tmp_path, mail):
        sent, _ = mail
        with _client(tmp_path) as client:
            token = _admin(client)
            r = client.post("/api/v1/system/test-email", headers=_auth(token),
                            json={"send": False}).json()
            assert r["ok"] is True, r
            assert r["security"] == "starttls_if_offered"   # port 25
            assert r["encrypted"] is False and r["login"] is False
            assert not [m for m, _ in sent if "Test" in m["Subject"]]

    def test_send_test_email_to_several_addresses(self, tmp_path, mail):
        sent, _ = mail
        with _client(tmp_path) as client:
            token = _admin(client)
            r = client.post("/api/v1/system/test-email", headers=_auth(token),
                            json={"to": "a@example.com; b@example.com",
                                  "security": "none"}).json()
            assert r["ok"] is True and r["sent"] is True, r
            msg, to = sent[-1]
            assert to == ["a@example.com", "b@example.com"]
            # The service's environment, not the file's "development".
            assert "[PRODUCTION]" in msg["Subject"] or \
                "[DEVELOPMENT]" in msg["Subject"]
            assert "[development]" not in msg["Subject"]

    def test_bad_recipient_refused(self, tmp_path, mail):
        with _client(tmp_path) as client:
            token = _admin(client)
            r = client.post("/api/v1/system/test-email", headers=_auth(token),
                            json={"to": "a@example.com; nonsense"}).json()
            assert r["ok"] is False and "nonsense" in r["error"]


class TestSettings:
    def test_new_settings_saved_and_shown_with_names(self, tmp_path, mail):
        with _client(tmp_path) as client:
            token = _admin(client)
            r = client.put("/api/v1/console/settings", headers=_auth(token),
                           json={"SMTP_SECURITY": "starttls_if_offered",
                                 "EMAIL_LANGUAGE": "ja",
                                 "AUDIENCE_CYBERARK_TO":
                                     "iam1@example.com; iam2@example.com"})
            assert r.status_code == 200, r.text
            items = {s["key"]: s for s in client.get(
                "/api/v1/console/settings",
                headers=_auth(token)).json()["settings"]}
            assert items["SMTP_SECURITY"]["choice_labels"][
                "starttls_if_offered"] == "STARTTLS if the server offers it"
            assert items["AUDIENCE_CYBERARK_TO"]["value"] == \
                "iam1@example.com,iam2@example.com"
            assert items["AUDIENCE_CYBERARK_TO"]["section"] == \
                "Recipients by system"
            import os
            # Live settings apply at once.
            assert os.environ["EMAIL_LANGUAGE"] == "ja"
            r = client.put("/api/v1/console/settings", headers=_auth(token),
                           json={"AUDIENCE_DATABASE_TO": "not-an-address"})
            assert r.status_code == 400


class TestDeliveryBanner:
    def test_banner_while_failing_and_outbox_resends(self, tmp_path, mail):
        sent, state = mail
        from src.modules.notifications import notifier
        from src.modules.notifications.log_handler import EmailAlertHandler

        def problems(client, token):
            # A warning since 2026-10-05 (E2E-L17): requests are still
            # processed while e-mail is not delivered.
            st = client.get("/api/v1/system/status",
                            headers=_auth(token)).json()
            assert not any("E-mail delivery" in p
                           for p in st["startup_problems"])
            return " ".join(st["startup_warnings"])
        with _client(tmp_path) as client:
            token = _admin(client)
            box = notifier.get_outbox()
            assert box is not None and box.pending() == 0
            handler = next(h for h in logging.getLogger(
                "finesiii_rpa_v3").handlers if isinstance(h, EmailAlertHandler))
            state["down"] = True
            with pytest.raises(notifier.NotificationDeferred):
                handler.notifier.send("Support report", "body",
                                      kind="support_report")
            assert box.pending() == 1
            text = problems(client, token)
            assert "E-mail delivery is failing" in text
            assert "1 e-mail(s) are waiting in the outbox" in text
            state["down"] = False
            assert box.run_once()["sent"] == 1
            assert "Support report" in sent[-1][0]["Subject"]
            assert "E-mail delivery is failing" not in problems(client, token)
        # Stopped with the service.
        assert notifier.get_outbox() is None


class TestEmailCheckApis:
    """ET1–ET5: status, routing, preview, sample, outbox."""

    def test_status_shows_settings_without_passwords(self, tmp_path, mail,
                                                     monkeypatch):
        monkeypatch.setenv("SMTP_PASSWORD", "never-shown-1234")
        with _client(tmp_path) as client:
            token = _admin(client)
            r = client.get("/api/v1/system/email/status", headers=_auth(token))
            assert r.status_code == 200
            body = r.json()
            assert body["enabled"] is True and body["problem"] == ""
            assert body["server"]["security"] == "starttls_if_offered"
            assert body["server"]["password_stored"] is True
            assert "never-shown-1234" not in r.text
            assert body["outbox"]["active"] is True
            assert body["delivery"]["failing"] is False

    def test_routing_names_every_email_and_the_system_team(
            self, tmp_path, mail, monkeypatch):
        sent, _ = mail
        monkeypatch.setenv("AUDIENCE_DATABASE_TO", "dba@example.com")
        with _client(tmp_path) as client:
            token = _admin(client)
            before = len(sent)
            rows = client.get("/api/v1/system/email/routing",
                              headers=_auth(token)).json()["emails"]
            kinds = {r["kind"] for r in rows}
            from src.modules.notifications.checks import KINDS
            assert kinds == set(KINDS)
            db = next(r for r in rows
                      if r["kind"] == "outage" and r["system"] == "database")
            assert db["recipients"] == ["dba@example.com", "ops@example.com"]
            snow = next(r for r in rows if r["kind"] == "outage"
                        and r["system"] == "servicenow")
            assert snow["recipients"] == ["ops@example.com"]
            assert len(sent) == before                   # nothing sent

    def test_preview_sends_nothing(self, tmp_path, mail):
        sent, _ = mail
        with _client(tmp_path) as client:
            token = _admin(client)
            before = len(sent)
            r = client.post("/api/v1/system/email/preview",
                            headers=_auth(token),
                            json={"kind": "outage", "system": "database",
                                  "language": "en"})
            assert r.status_code == 200, r.text
            p = r.json()
            assert p["subject"].endswith("Database Not Available")
            assert p["recipients"] == ["ops@example.com"]
            assert "data:image/png;base64," in p["html"]
            assert "Check the database (AWS RDS)" in p["text"]
            assert len(sent) == before
            bad = client.post("/api/v1/system/email/preview",
                              headers=_auth(token), json={"kind": "nope"})
            assert bad.status_code == 400 and "Known:" in bad.text

    def test_sample_goes_only_to_the_typed_addresses(self, tmp_path, mail):
        sent, _ = mail
        with _client(tmp_path) as client:
            token = _admin(client)
            r = client.post("/api/v1/system/email/send-sample",
                            headers=_auth(token),
                            json={"kind": "result_not_confirmed",
                                  "to": "qa1@example.com; qa2@example.com"})
            assert r.status_code == 200 and r.json()["ok"] is True, r.text
            msg, to = sent[-1]
            assert to == ["qa1@example.com", "qa2@example.com"]
            assert str(msg["Subject"]).startswith("[TEST] ")
            assert msg["Cc"] is None
            assert "ops@example.com" not in str(msg["To"])
            r = client.post("/api/v1/system/email/send-sample",
                            headers=_auth(token),
                            json={"kind": "support_report", "to": "oops"})
            assert r.status_code == 400

    def test_outbox_list_and_retry(self, tmp_path, mail):
        sent, state = mail
        from src.modules.notifications import notifier
        from src.modules.notifications.log_handler import EmailAlertHandler
        with _client(tmp_path) as client:
            token = _admin(client)
            handler = next(h for h in logging.getLogger(
                "finesiii_rpa_v3").handlers if isinstance(h, EmailAlertHandler))
            state["down"] = True
            with pytest.raises(notifier.NotificationDeferred):
                handler.notifier.send("Kept report", "body",
                                      to=["support@example.com"])
            box = client.get("/api/v1/system/email/outbox",
                             headers=_auth(token)).json()
            assert box["waiting"] == 1
            (item,) = box["emails"]
            assert item["recipients"] == ["s***@example.com"]
            # The failed attempts and their error are kept (E2E-L17).
            assert "Kept report" in item["subject"]
            assert item["last_error"] and item["attempts"] >= 1
            state["down"] = False
            r = client.post("/api/v1/system/email/outbox/retry",
                            headers=_auth(token)).json()
            assert r["sent"] == 1 and r["waiting"] == 0
            assert "Kept report" in str(sent[-1][0]["Subject"])
