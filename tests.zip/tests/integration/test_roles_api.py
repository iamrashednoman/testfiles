"""Roles, permissions, the seeded default admin, and the follow-up
Phase 4 gaps (rule toggle, session refresh, session purge).

The load-bearing property throughout: the three built-in roles must
keep behaving EXACTLY as they did when they were a fixed enum, while
custom roles become possible alongside them.
"""
import time

import pytest

from tests.conftest import make_config

PASSWORD = "CorrectHorse42"
VALID = {"operation": "provision", "affiliation_code": "30822",
         "employee_code": "1217036", "password": "FUJI@33F"}


@pytest.fixture(autouse=True)
def fast_sleep(monkeypatch):
    monkeypatch.setattr("time.sleep", lambda s: None)


def _client(tmp_path, **overrides):
    from fastapi.testclient import TestClient
    from src import create_app
    cfg = make_config(tmp_path, dispatcher_enabled=False,
                      terminal_driver="mock",
                      log_dir=str(tmp_path / "logs"), **overrides)
    return TestClient(create_app(cfg))


def _auth(t):
    return {"Authorization": f"Bearer {t}"}


def _admin(client):
    client.post("/api/v1/auth/bootstrap",
                json={"username": "alice", "password": PASSWORD})
    return client.post("/api/v1/auth/login", json={
        "username": "alice", "password": PASSWORD}).json()["access_token"]


class TestDefaultAdmin:
    """A fresh install is usable immediately, without someone having to
    create the first account before they can sign in."""

    def test_seeded_on_a_fresh_install(self, tmp_path):
        with _client(tmp_path, auth_seed_default_admin=True) as client:
            assert client.get("/api/v1/auth/status"
                              ).json()["initialised"] is True
            r = client.post("/api/v1/auth/login", json={
                "username": "admin", "password": "ChangeMe!2026"})
            assert r.status_code == 200
            assert r.json()["user"]["role"] == "admin"

    def test_the_seeded_password_grants_nothing(self, tmp_path):
        """This is what makes shipping a known default defensible."""
        with _client(tmp_path, auth_seed_default_admin=True) as client:
            token = client.post("/api/v1/auth/login", json={
                "username": "admin",
                "password": "ChangeMe!2026"}).json()["access_token"]
            r = client.get("/api/v1/console/summary", headers=_auth(token))
            assert r.status_code == 428
            assert "must be changed" in r.json()["detail"]

    def test_usable_after_the_change(self, tmp_path):
        with _client(tmp_path, auth_seed_default_admin=True) as client:
            token = client.post("/api/v1/auth/login", json={
                "username": "admin",
                "password": "ChangeMe!2026"}).json()["access_token"]
            client.post("/api/v1/auth/password", headers=_auth(token),
                        json={"current_password": "ChangeMe!2026",
                              "new_password": "RealSitePass99"})
            token = client.post("/api/v1/auth/login", json={
                "username": "admin",
                "password": "RealSitePass99"}).json()["access_token"]
            assert client.get("/api/v1/console/summary",
                              headers=_auth(token)).status_code == 200

    def test_credentials_are_configurable(self, tmp_path):
        with _client(tmp_path, auth_seed_default_admin=True,
                     auth_default_admin_username="rpaadmin",
                     auth_default_admin_password="SiteChosen4321"
                     ) as client:
            assert client.post("/api/v1/auth/login", json={
                "username": "rpaadmin",
                "password": "SiteChosen4321"}).status_code == 200

    def test_never_seeds_a_second_time(self, tmp_path):
        """It must not resurrect an admin someone deliberately removed,
        nor add a duplicate on every restart."""
        db = str(tmp_path / "shared.db")
        with _client(tmp_path, auth_seed_default_admin=True,
                     sqlite_path=db) as client:
            first = client.get("/api/v1/auth/status").json()
        with _client(tmp_path, auth_seed_default_admin=True,
                     sqlite_path=db) as client:
            token = client.post("/api/v1/auth/login", json={
                "username": "admin",
                "password": "ChangeMe!2026"}).json()["access_token"]
            client.post("/api/v1/auth/password", headers=_auth(token),
                        json={"current_password": "ChangeMe!2026",
                              "new_password": "RealSitePass99"})
            token = client.post("/api/v1/auth/login", json={
                "username": "admin",
                "password": "RealSitePass99"}).json()["access_token"]
            users = client.get("/api/v1/admin/users",
                               headers=_auth(token)).json()
            assert users["count"] == 1
        assert first["initialised"] is True

    def test_can_be_turned_off(self, tmp_path):
        with _client(tmp_path, auth_seed_default_admin=False) as client:
            assert client.get("/api/v1/auth/status"
                              ).json()["initialised"] is False


class TestBuiltInRolesUnchanged:
    def test_the_three_roles_are_seeded(self, tmp_path):
        with _client(tmp_path) as client:
            roles = client.get("/api/v1/admin/roles",
                               headers=_auth(_admin(client))).json()
            names = {r["name"] for r in roles["roles"]}
            assert {"viewer", "operator", "admin"} <= names
            assert all(r["is_builtin"] for r in roles["roles"]
                       if r["name"] in names)

    def test_admin_holds_every_permission(self, tmp_path):
        with _client(tmp_path) as client:
            token = _admin(client)
            catalogue = client.get("/api/v1/admin/permissions",
                                   headers=_auth(token)).json()
            roles = {r["name"]: r for r in client.get(
                "/api/v1/admin/roles", headers=_auth(token)
            ).json()["roles"]}
            assert set(roles["admin"]["permissions"]) == \
                set(catalogue["permissions"])

    def test_viewer_cannot_act_operator_can(self, tmp_path):
        with _client(tmp_path) as client:
            token = _admin(client)
            roles = {r["name"]: set(r["permissions"]) for r in client.get(
                "/api/v1/admin/roles", headers=_auth(token)
            ).json()["roles"]}
            assert "requests.retry" not in roles["viewer"]
            assert "requests.retry" in roles["operator"]
            assert roles["viewer"] < roles["operator"] < roles["admin"]

    def test_builtins_cannot_be_edited_or_deleted(self, tmp_path):
        """They are part of the release, not configuration."""
        with _client(tmp_path) as client:
            token = _admin(client)
            for name in ("viewer", "operator", "admin"):
                assert client.patch(
                    f"/api/v1/admin/roles/{name}", headers=_auth(token),
                    json={"permissions": []}).status_code == 409
                assert client.delete(
                    f"/api/v1/admin/roles/{name}",
                    headers=_auth(token)).status_code == 409

    def test_builtin_permissions_are_refreshed_on_start(self, tmp_path):
        """A permission added in a release must reach admin without a
        migration."""
        from src.core.db import Database
        from src.modules.auth.store import UserStore

        db = Database("sqlite", sqlite_path=str(tmp_path / "r.db"))
        store = UserStore(db)
        store.ensure_builtin_roles()
        role = store.get_role("admin")
        role.permissions = ["dashboard.view"]      # simulate an old row
        store.update_role(role)
        store.ensure_builtin_roles()               # restart
        assert len(store.get_role("admin").permissions) > 1


class TestCustomRoles:
    def test_create_assign_and_enforce(self, tmp_path):
        with _client(tmp_path) as client:
            token = _admin(client)
            r = client.post("/api/v1/admin/roles", headers=_auth(token),
                            json={"name": "compliance",
                                  "description": "Evidence + audit",
                                  "permissions": ["dashboard.view",
                                                  "evidence.view",
                                                  "audit.view"]})
            assert r.status_code == 201

            client.post("/api/v1/admin/users", headers=_auth(token),
                        json={"username": "carol", "password": PASSWORD,
                              "role": "compliance"})
            t = client.post("/api/v1/auth/login", json={
                "username": "carol",
                "password": PASSWORD}).json()["access_token"]
            client.post("/api/v1/auth/password", headers=_auth(t),
                        json={"current_password": PASSWORD,
                              "new_password": "KestrelOwn12345"})
            t = client.post("/api/v1/auth/login", json={
                "username": "carol",
                "password": "KestrelOwn12345"}).json()["access_token"]

            # Granted…
            assert client.get("/api/v1/console/summary",
                              headers=_auth(t)).status_code == 200
            # …and NOT granted.
            assert client.get("/api/v1/admin/users",
                              headers=_auth(t)).status_code == 403

    def test_unknown_permissions_are_rejected(self, tmp_path):
        """A typo would grant nothing while LOOKING granted."""
        with _client(tmp_path) as client:
            r = client.post("/api/v1/admin/roles",
                            headers=_auth(_admin(client)),
                            json={"name": "oops",
                                  "permissions": ["evidence.veiw"]})
            assert r.status_code == 400
            assert "evidence.veiw" in r.json()["detail"]

    def test_editing_a_role_applies_immediately(self, tmp_path):
        """Permissions resolve per request, so a revoked permission
        must not survive until the holder's token expires."""
        with _client(tmp_path) as client:
            token = _admin(client)
            client.post("/api/v1/admin/roles", headers=_auth(token),
                        json={"name": "temp",
                              "permissions": ["dashboard.view"]})
            client.post("/api/v1/admin/users", headers=_auth(token),
                        json={"username": "dave", "password": PASSWORD,
                              "role": "temp"})
            t = client.post("/api/v1/auth/login", json={
                "username": "dave",
                "password": PASSWORD}).json()["access_token"]
            client.post("/api/v1/auth/password", headers=_auth(t),
                        json={"current_password": PASSWORD,
                              "new_password": "HeronOwn123456"})
            t = client.post("/api/v1/auth/login", json={
                "username": "dave",
                "password": "HeronOwn123456"}).json()["access_token"]
            assert client.get("/api/v1/console/summary",
                              headers=_auth(t)).status_code == 200

            # A role keeps at least one permission (E2E-L19): the one
            # the summary needs is taken away.
            assert client.patch("/api/v1/admin/roles/temp", headers=_auth(token),
                                json={"permissions": ["requests.view"]}
                                ).status_code == 200
            # SAME token, no re-login.
            assert client.get("/api/v1/console/summary",
                              headers=_auth(t)).status_code == 403

    def test_a_role_in_use_cannot_be_deleted(self, tmp_path):
        """Deleting it would silently strip those accounts of
        everything."""
        with _client(tmp_path) as client:
            token = _admin(client)
            client.post("/api/v1/admin/roles", headers=_auth(token),
                        json={"name": "temp",
                              "permissions": ["dashboard.view"]})
            client.post("/api/v1/admin/users", headers=_auth(token),
                        json={"username": "eve", "password": PASSWORD,
                              "role": "temp"})
            r = client.delete("/api/v1/admin/roles/temp",
                              headers=_auth(token))
            assert r.status_code == 409
            assert "still use" in r.json()["detail"]

    def test_unknown_role_on_a_user_is_rejected(self, tmp_path):
        with _client(tmp_path) as client:
            r = client.post("/api/v1/admin/users",
                            headers=_auth(_admin(client)),
                            json={"username": "frank",
                                  "password": PASSWORD,
                                  "role": "nonexistent"})
            assert r.status_code == 400

    def test_only_admins_may_manage_roles(self, tmp_path):
        with _client(tmp_path) as client:
            token = _admin(client)
            client.post("/api/v1/admin/users", headers=_auth(token),
                        json={"username": "opr", "password": PASSWORD,
                              "role": "operator"})
            t = client.post("/api/v1/auth/login", json={
                "username": "opr",
                "password": PASSWORD}).json()["access_token"]
            client.post("/api/v1/auth/password", headers=_auth(t),
                        json={"current_password": PASSWORD,
                              "new_password": "OwlOwn12345678"})
            t = client.post("/api/v1/auth/login", json={
                "username": "opr",
                "password": "OwlOwn12345678"}).json()["access_token"]
            assert client.get("/api/v1/admin/roles",
                              headers=_auth(t)).status_code == 403


class TestSessionRefresh:
    def test_refresh_issues_a_new_token(self, tmp_path):
        """A console window stays open all day; without this the
        operator is bounced to sign-in mid-shift."""
        with _client(tmp_path) as client:
            token = _admin(client)
            r = client.post("/api/v1/auth/refresh", headers=_auth(token))
            assert r.status_code == 200
            fresh = r.json()["access_token"]
            assert fresh != token
            assert client.get("/api/v1/auth/me",
                              headers=_auth(fresh)).status_code == 200

    def test_the_old_token_is_revoked(self, tmp_path):
        """A stolen token must not stay usable alongside the real
        one."""
        with _client(tmp_path) as client:
            token = _admin(client)
            client.post("/api/v1/auth/refresh", headers=_auth(token))
            assert client.get("/api/v1/auth/me",
                              headers=_auth(token)).status_code == 401

    def test_an_invalid_token_cannot_be_refreshed(self, tmp_path):
        with _client(tmp_path) as client:
            _admin(client)
            assert client.post("/api/v1/auth/refresh",
                               headers=_auth("garbage")).status_code == 401


class TestSessionPurge:
    def test_expired_sessions_are_deleted(self, tmp_path):
        from src.core.db import Database
        from src.modules.auth.models import AppSession
        from src.modules.auth.store import UserStore

        store = UserStore(Database("sqlite",
                                   sqlite_path=str(tmp_path / "s.db")))
        store.create_session(AppSession(
            user_id="u1", issued_at="2020-01-01T00:00:00+09:00",
            expires_at="2020-01-01T01:00:00+09:00"))
        live = AppSession(user_id="u2",
                          expires_at="2999-01-01T00:00:00+09:00")
        store.create_session(live)
        assert store.purge_expired_sessions() == 1
        assert store.get_session(live.session_id) is not None

    def test_the_dispatcher_sweeps_them(self, tmp_path):
        """app_sessions would otherwise grow without bound."""
        from src.modules.queue.dispatcher import Dispatcher

        swept = []

        class Store:
            def purge_expired_sessions(self):
                swept.append(1)
                return 0

        d = Dispatcher.__new__(Dispatcher)
        d.user_store = Store()
        d._last_session_purge = 0.0
        d.logger = None
        d._maybe_purge_sessions()
        assert swept == [1]
        d._maybe_purge_sessions()          # rate-limited
        assert swept == [1]

    def test_a_purge_failure_never_stops_dispatch(self, tmp_path):
        from src.modules.queue.dispatcher import Dispatcher

        class Broken:
            def purge_expired_sessions(self):
                raise RuntimeError("database gone")

        d = Dispatcher.__new__(Dispatcher)
        d.user_store = Broken()
        d._last_session_purge = 0.0
        d.logger = None
        d._maybe_purge_sessions()          # must not raise


class TestErrorRuleToggle:
    def _catalogue(self, tmp_path):
        import shutil
        src = "config/errors.yaml"
        dst = tmp_path / "errors.yaml"
        shutil.copy(src, dst)
        return str(dst)

    def test_disable_and_reenable(self, tmp_path):
        path = self._catalogue(tmp_path)
        with _client(tmp_path, error_catalog_path=path) as client:
            token = _admin(client)
            r = client.patch(
                "/api/v1/console/error-rules/CENTER_NOT_READY",
                headers=_auth(token), json={"enabled": False, "reason": "test"})
            assert r.status_code == 200
            rules = {x["id"]: x for x in client.get(
                "/api/v1/console/error-rules", headers=_auth(token)
            ).json()["rules"]}
            assert rules["CENTER_NOT_READY"]["enabled"] is False
            client.patch("/api/v1/console/error-rules/CENTER_NOT_READY",
                         headers=_auth(token), json={"enabled": True})
            rules = {x["id"]: x for x in client.get(
                "/api/v1/console/error-rules", headers=_auth(token)
            ).json()["rules"]}
            assert rules["CENTER_NOT_READY"]["enabled"] is True

    def test_comments_and_other_rules_survive(self, tmp_path):
        """errors.yaml is the REVIEWED RECORD of what the bot does —
        116 of its 208 lines document the client's decisions per case.
        A round-trip through yaml.safe_dump deletes every one."""
        import pathlib
        path = self._catalogue(tmp_path)
        before = pathlib.Path(path).read_text(encoding="utf-8")
        comments_before = sum(1 for ln in before.splitlines()
                              if ln.strip().startswith("#"))
        assert comments_before > 50, "fixture lost its comments"

        with _client(tmp_path, error_catalog_path=path) as client:
            client.patch("/api/v1/console/error-rules/CENTER_NOT_READY",
                         headers=_auth(_admin(client)),
                         json={"enabled": False, "reason": "test"})

        after = pathlib.Path(path).read_text(encoding="utf-8")
        assert sum(1 for ln in after.splitlines()
                   if ln.strip().startswith("#")) == comments_before
        assert "センター準備中" in after
        assert "オペレーターコード未登録です" in after

    def test_unknown_rule_is_404(self, tmp_path):
        path = self._catalogue(tmp_path)
        with _client(tmp_path, error_catalog_path=path) as client:
            assert client.patch(
                "/api/v1/console/error-rules/NOPE",
                headers=_auth(_admin(client)),
                json={"enabled": False, "reason": "test"}).status_code == 404

    def test_requires_the_rules_edit_permission(self, tmp_path):
        path = self._catalogue(tmp_path)
        with _client(tmp_path, error_catalog_path=path) as client:
            token = _admin(client)
            client.post("/api/v1/admin/users", headers=_auth(token),
                        json={"username": "vic", "password": PASSWORD,
                              "role": "viewer"})
            t = client.post("/api/v1/auth/login", json={
                "username": "vic",
                "password": PASSWORD}).json()["access_token"]
            client.post("/api/v1/auth/password", headers=_auth(t),
                        json={"current_password": PASSWORD,
                              "new_password": "WrenOwn1234567"})
            t = client.post("/api/v1/auth/login", json={
                "username": "vic",
                "password": "WrenOwn1234567"}).json()["access_token"]
            r = client.patch(
                "/api/v1/console/error-rules/CENTER_NOT_READY",
                headers=_auth(t), json={"enabled": False, "reason": "test"})
            assert r.status_code == 403
            assert "rules.edit" in r.json()["detail"]

    def test_the_toggle_is_audited(self, tmp_path):
        path = self._catalogue(tmp_path)
        with _client(tmp_path, error_catalog_path=path,
                     audit_enabled=True, audit_backend="sqlite",
                     audit_sqlite_path=str(tmp_path / "audit.db"),
                     audit_spool_path=str(tmp_path / "spool.db"),
                     audit_flush_interval_seconds=0.05) as client:
            client.patch("/api/v1/console/error-rules/CENTER_NOT_READY",
                         headers=_auth(_admin(client)),
                         json={"enabled": False, "reason": "test"})
            deadline = time.time() + 5
            events = []
            while time.time() < deadline and not events:
                events = [e for e in client.get(
                    "/api/v1/audit/events?category=console&limit=50"
                ).json()["events"]
                    if e["action"] == "error_rule_toggled"]
            assert events
            detail = events[0]["detail"]
            assert detail["rule"] == "CENTER_NOT_READY"
            assert detail["before"] is True and detail["after"] is False
